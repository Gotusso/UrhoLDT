---
-- Enumeration LockState
--
-- @module LockState

---
-- Enumeration value LOCK_NONE
--
-- @field [parent=#LockState] #number LOCK_NONE

---
-- Enumeration value LOCK_HARDWARE
--
-- @field [parent=#LockState] #number LOCK_HARDWARE

---
-- Enumeration value LOCK_SHADOW
--
-- @field [parent=#LockState] #number LOCK_SHADOW

---
-- Enumeration value LOCK_SCRATCH
--
-- @field [parent=#LockState] #number LOCK_SCRATCH


return nil
