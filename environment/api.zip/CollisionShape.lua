---
-- Module CollisionShape
-- Module CollisionShape extends Component
-- Generated on 2014-03-13
--
-- @module CollisionShape

---
-- Function SetBox
--
-- @function [parent=#CollisionShape] SetBox
-- @param self Self reference
-- @param Vector3#Vector3 size size

---
-- Function SetBox
--
-- @function [parent=#CollisionShape] SetBox
-- @param self Self reference
-- @param Vector3#Vector3 size size
-- @param Vector3#Vector3 position position

---
-- Function SetBox
--
-- @function [parent=#CollisionShape] SetBox
-- @param self Self reference
-- @param Vector3#Vector3 size size
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetSphere
--
-- @function [parent=#CollisionShape] SetSphere
-- @param self Self reference
-- @param #number diameter diameter

---
-- Function SetSphere
--
-- @function [parent=#CollisionShape] SetSphere
-- @param self Self reference
-- @param #number diameter diameter
-- @param Vector3#Vector3 position position

---
-- Function SetSphere
--
-- @function [parent=#CollisionShape] SetSphere
-- @param self Self reference
-- @param #number diameter diameter
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetStaticPlane
--
-- @function [parent=#CollisionShape] SetStaticPlane
-- @param self Self reference

---
-- Function SetStaticPlane
--
-- @function [parent=#CollisionShape] SetStaticPlane
-- @param self Self reference
-- @param Vector3#Vector3 position position

---
-- Function SetStaticPlane
--
-- @function [parent=#CollisionShape] SetStaticPlane
-- @param self Self reference
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetCylinder
--
-- @function [parent=#CollisionShape] SetCylinder
-- @param self Self reference
-- @param #number diameter diameter
-- @param #number height height

---
-- Function SetCylinder
--
-- @function [parent=#CollisionShape] SetCylinder
-- @param self Self reference
-- @param #number diameter diameter
-- @param #number height height
-- @param Vector3#Vector3 position position

---
-- Function SetCylinder
--
-- @function [parent=#CollisionShape] SetCylinder
-- @param self Self reference
-- @param #number diameter diameter
-- @param #number height height
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetCapsule
--
-- @function [parent=#CollisionShape] SetCapsule
-- @param self Self reference
-- @param #number diameter diameter
-- @param #number height height

---
-- Function SetCapsule
--
-- @function [parent=#CollisionShape] SetCapsule
-- @param self Self reference
-- @param #number diameter diameter
-- @param #number height height
-- @param Vector3#Vector3 position position

---
-- Function SetCapsule
--
-- @function [parent=#CollisionShape] SetCapsule
-- @param self Self reference
-- @param #number diameter diameter
-- @param #number height height
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetCone
--
-- @function [parent=#CollisionShape] SetCone
-- @param self Self reference
-- @param #number diameter diameter
-- @param #number height height

---
-- Function SetCone
--
-- @function [parent=#CollisionShape] SetCone
-- @param self Self reference
-- @param #number diameter diameter
-- @param #number height height
-- @param Vector3#Vector3 position position

---
-- Function SetCone
--
-- @function [parent=#CollisionShape] SetCone
-- @param self Self reference
-- @param #number diameter diameter
-- @param #number height height
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetTriangleMesh
--
-- @function [parent=#CollisionShape] SetTriangleMesh
-- @param self Self reference
-- @param Model#Model model model
-- @param #number lodLevel lodLevel

---
-- Function SetTriangleMesh
--
-- @function [parent=#CollisionShape] SetTriangleMesh
-- @param self Self reference
-- @param Model#Model model model
-- @param #number lodLevel lodLevel
-- @param Vector3#Vector3 scale scale

---
-- Function SetTriangleMesh
--
-- @function [parent=#CollisionShape] SetTriangleMesh
-- @param self Self reference
-- @param Model#Model model model
-- @param #number lodLevel lodLevel
-- @param Vector3#Vector3 scale scale
-- @param Vector3#Vector3 position position

---
-- Function SetTriangleMesh
--
-- @function [parent=#CollisionShape] SetTriangleMesh
-- @param self Self reference
-- @param Model#Model model model
-- @param #number lodLevel lodLevel
-- @param Vector3#Vector3 scale scale
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetConvexHull
--
-- @function [parent=#CollisionShape] SetConvexHull
-- @param self Self reference
-- @param Model#Model model model
-- @param #number lodLevel lodLevel

---
-- Function SetConvexHull
--
-- @function [parent=#CollisionShape] SetConvexHull
-- @param self Self reference
-- @param Model#Model model model
-- @param #number lodLevel lodLevel
-- @param Vector3#Vector3 scale scale

---
-- Function SetConvexHull
--
-- @function [parent=#CollisionShape] SetConvexHull
-- @param self Self reference
-- @param Model#Model model model
-- @param #number lodLevel lodLevel
-- @param Vector3#Vector3 scale scale
-- @param Vector3#Vector3 position position

---
-- Function SetConvexHull
--
-- @function [parent=#CollisionShape] SetConvexHull
-- @param self Self reference
-- @param Model#Model model model
-- @param #number lodLevel lodLevel
-- @param Vector3#Vector3 scale scale
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetTerrain
--
-- @function [parent=#CollisionShape] SetTerrain
-- @param self Self reference

---
-- Function SetShapeType
--
-- @function [parent=#CollisionShape] SetShapeType
-- @param self Self reference
-- @param ShapeType#ShapeType type type

---
-- Function SetSize
--
-- @function [parent=#CollisionShape] SetSize
-- @param self Self reference
-- @param Vector3#Vector3 size size

---
-- Function SetPosition
--
-- @function [parent=#CollisionShape] SetPosition
-- @param self Self reference
-- @param Vector3#Vector3 position position

---
-- Function SetRotation
--
-- @function [parent=#CollisionShape] SetRotation
-- @param self Self reference
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetTransform
--
-- @function [parent=#CollisionShape] SetTransform
-- @param self Self reference
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetMargin
--
-- @function [parent=#CollisionShape] SetMargin
-- @param self Self reference
-- @param #number margin margin

---
-- Function SetModel
--
-- @function [parent=#CollisionShape] SetModel
-- @param self Self reference
-- @param Model#Model model model

---
-- Function SetLodLevel
--
-- @function [parent=#CollisionShape] SetLodLevel
-- @param self Self reference
-- @param #number lodLevel lodLevel

---
-- Function GetPhysicsWorld
--
-- @function [parent=#CollisionShape] GetPhysicsWorld
-- @param self Self reference
-- @return PhysicsWorld#PhysicsWorld

---
-- Function GetShapeType
--
-- @function [parent=#CollisionShape] GetShapeType
-- @param self Self reference
-- @return ShapeType#ShapeType

---
-- Function GetSize
--
-- @function [parent=#CollisionShape] GetSize
-- @param self Self reference
-- @return const Vector3#const Vector3

---
-- Function GetPosition
--
-- @function [parent=#CollisionShape] GetPosition
-- @param self Self reference
-- @return const Vector3#const Vector3

---
-- Function GetRotation
--
-- @function [parent=#CollisionShape] GetRotation
-- @param self Self reference
-- @return const Quaternion#const Quaternion

---
-- Function GetMargin
--
-- @function [parent=#CollisionShape] GetMargin
-- @param self Self reference
-- @return #number

---
-- Function GetModel
--
-- @function [parent=#CollisionShape] GetModel
-- @param self Self reference
-- @return Model#Model

---
-- Function GetLodLevel
--
-- @function [parent=#CollisionShape] GetLodLevel
-- @param self Self reference
-- @return #number

---
-- Function GetWorldBoundingBox
--
-- @function [parent=#CollisionShape] GetWorldBoundingBox
-- @param self Self reference
-- @return BoundingBox#BoundingBox

---
-- Field physicsWorld (Read only)
--
-- @field [parent=#CollisionShape] PhysicsWorld#PhysicsWorld physicsWorld

---
-- Field shapeType
--
-- @field [parent=#CollisionShape] ShapeType#ShapeType shapeType

---
-- Field size
--
-- @field [parent=#CollisionShape] Vector3#Vector3 size

---
-- Field position
--
-- @field [parent=#CollisionShape] Vector3#Vector3 position

---
-- Field rotation
--
-- @field [parent=#CollisionShape] Quaternion#Quaternion rotation

---
-- Field margin
--
-- @field [parent=#CollisionShape] #number margin

---
-- Field model
--
-- @field [parent=#CollisionShape] Model#Model model

---
-- Field lodLevel
--
-- @field [parent=#CollisionShape] #number lodLevel

---
-- Field worldBoundingBox (Read only)
--
-- @field [parent=#CollisionShape] BoundingBox#BoundingBox worldBoundingBox

---
-- Field modelAttr
--
-- @field [parent=#CollisionShape] ResourceRef#ResourceRef modelAttr

---
-- Function SetEnabled
--
-- @function [parent=#CollisionShape] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Remove
--
-- @function [parent=#CollisionShape] Remove
-- @param self Self reference

---
-- Function GetID
--
-- @function [parent=#CollisionShape] GetID
-- @param self Self reference
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#CollisionShape] GetNode
-- @param self Self reference
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#CollisionShape] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#CollisionShape] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#CollisionShape] IsEnabledEffective
-- @param self Self reference
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#CollisionShape] GetComponent
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#CollisionShape] GetComponent
-- @param self Self reference
-- @param #string type type
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#CollisionShape] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#CollisionShape] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#CollisionShape] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#CollisionShape] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#CollisionShape] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#CollisionShape] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#CollisionShape] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#CollisionShape] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#CollisionShape] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#CollisionShape] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#CollisionShape] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#CollisionShape] #string category


return nil
