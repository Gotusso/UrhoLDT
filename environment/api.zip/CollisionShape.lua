---
-- Module CollisionShape
-- Extends Component
--
-- @module CollisionShape

---
-- Function SetBox
--
-- @function [parent=#CollisionShape] SetBox
-- @param Vector3#Vector3 sizesize

---
-- Function SetBox
--
-- @function [parent=#CollisionShape] SetBox
-- @param Vector3#Vector3 sizesize
-- @param Vector3#Vector3 positionposition

---
-- Function SetBox
--
-- @function [parent=#CollisionShape] SetBox
-- @param Vector3#Vector3 sizesize
-- @param Vector3#Vector3 positionposition
-- @param Quaternion#Quaternion rotationrotation

---
-- Function SetSphere
--
-- @function [parent=#CollisionShape] SetSphere
-- @param #number diameterdiameter

---
-- Function SetSphere
--
-- @function [parent=#CollisionShape] SetSphere
-- @param #number diameterdiameter
-- @param Vector3#Vector3 positionposition

---
-- Function SetSphere
--
-- @function [parent=#CollisionShape] SetSphere
-- @param #number diameterdiameter
-- @param Vector3#Vector3 positionposition
-- @param Quaternion#Quaternion rotationrotation

---
-- Function SetStaticPlane
--
-- @function [parent=#CollisionShape] SetStaticPlane

---
-- Function SetStaticPlane
--
-- @function [parent=#CollisionShape] SetStaticPlane
-- @param Vector3#Vector3 positionposition

---
-- Function SetStaticPlane
--
-- @function [parent=#CollisionShape] SetStaticPlane
-- @param Vector3#Vector3 positionposition
-- @param Quaternion#Quaternion rotationrotation

---
-- Function SetCylinder
--
-- @function [parent=#CollisionShape] SetCylinder
-- @param #number diameterdiameter
-- @param #number heightheight

---
-- Function SetCylinder
--
-- @function [parent=#CollisionShape] SetCylinder
-- @param #number diameterdiameter
-- @param #number heightheight
-- @param Vector3#Vector3 positionposition

---
-- Function SetCylinder
--
-- @function [parent=#CollisionShape] SetCylinder
-- @param #number diameterdiameter
-- @param #number heightheight
-- @param Vector3#Vector3 positionposition
-- @param Quaternion#Quaternion rotationrotation

---
-- Function SetCapsule
--
-- @function [parent=#CollisionShape] SetCapsule
-- @param #number diameterdiameter
-- @param #number heightheight

---
-- Function SetCapsule
--
-- @function [parent=#CollisionShape] SetCapsule
-- @param #number diameterdiameter
-- @param #number heightheight
-- @param Vector3#Vector3 positionposition

---
-- Function SetCapsule
--
-- @function [parent=#CollisionShape] SetCapsule
-- @param #number diameterdiameter
-- @param #number heightheight
-- @param Vector3#Vector3 positionposition
-- @param Quaternion#Quaternion rotationrotation

---
-- Function SetCone
--
-- @function [parent=#CollisionShape] SetCone
-- @param #number diameterdiameter
-- @param #number heightheight

---
-- Function SetCone
--
-- @function [parent=#CollisionShape] SetCone
-- @param #number diameterdiameter
-- @param #number heightheight
-- @param Vector3#Vector3 positionposition

---
-- Function SetCone
--
-- @function [parent=#CollisionShape] SetCone
-- @param #number diameterdiameter
-- @param #number heightheight
-- @param Vector3#Vector3 positionposition
-- @param Quaternion#Quaternion rotationrotation

---
-- Function SetTriangleMesh
--
-- @function [parent=#CollisionShape] SetTriangleMesh
-- @param Model#Model modelmodel
-- @param #number lodLevellodLevel

---
-- Function SetTriangleMesh
--
-- @function [parent=#CollisionShape] SetTriangleMesh
-- @param Model#Model modelmodel
-- @param #number lodLevellodLevel
-- @param Vector3#Vector3 scalescale

---
-- Function SetTriangleMesh
--
-- @function [parent=#CollisionShape] SetTriangleMesh
-- @param Model#Model modelmodel
-- @param #number lodLevellodLevel
-- @param Vector3#Vector3 scalescale
-- @param Vector3#Vector3 positionposition

---
-- Function SetTriangleMesh
--
-- @function [parent=#CollisionShape] SetTriangleMesh
-- @param Model#Model modelmodel
-- @param #number lodLevellodLevel
-- @param Vector3#Vector3 scalescale
-- @param Vector3#Vector3 positionposition
-- @param Quaternion#Quaternion rotationrotation

---
-- Function SetConvexHull
--
-- @function [parent=#CollisionShape] SetConvexHull
-- @param Model#Model modelmodel
-- @param #number lodLevellodLevel

---
-- Function SetConvexHull
--
-- @function [parent=#CollisionShape] SetConvexHull
-- @param Model#Model modelmodel
-- @param #number lodLevellodLevel
-- @param Vector3#Vector3 scalescale

---
-- Function SetConvexHull
--
-- @function [parent=#CollisionShape] SetConvexHull
-- @param Model#Model modelmodel
-- @param #number lodLevellodLevel
-- @param Vector3#Vector3 scalescale
-- @param Vector3#Vector3 positionposition

---
-- Function SetConvexHull
--
-- @function [parent=#CollisionShape] SetConvexHull
-- @param Model#Model modelmodel
-- @param #number lodLevellodLevel
-- @param Vector3#Vector3 scalescale
-- @param Vector3#Vector3 positionposition
-- @param Quaternion#Quaternion rotationrotation

---
-- Function SetTerrain
--
-- @function [parent=#CollisionShape] SetTerrain

---
-- Function SetShapeType
--
-- @function [parent=#CollisionShape] SetShapeType
-- @param ShapeType#ShapeType typetype

---
-- Function SetSize
--
-- @function [parent=#CollisionShape] SetSize
-- @param Vector3#Vector3 sizesize

---
-- Function SetPosition
--
-- @function [parent=#CollisionShape] SetPosition
-- @param Vector3#Vector3 positionposition

---
-- Function SetRotation
--
-- @function [parent=#CollisionShape] SetRotation
-- @param Quaternion#Quaternion rotationrotation

---
-- Function SetTransform
--
-- @function [parent=#CollisionShape] SetTransform
-- @param Vector3#Vector3 positionposition
-- @param Quaternion#Quaternion rotationrotation

---
-- Function SetMargin
--
-- @function [parent=#CollisionShape] SetMargin
-- @param #number marginmargin

---
-- Function SetModel
--
-- @function [parent=#CollisionShape] SetModel
-- @param Model#Model modelmodel

---
-- Function SetLodLevel
--
-- @function [parent=#CollisionShape] SetLodLevel
-- @param #number lodLevellodLevel

---
-- Function GetPhysicsWorld
--
-- @function [parent=#CollisionShape] GetPhysicsWorld
-- @return PhysicsWorld#PhysicsWorld

---
-- Function GetShapeType
--
-- @function [parent=#CollisionShape] GetShapeType
-- @return ShapeType#ShapeType

---
-- Function GetSize
--
-- @function [parent=#CollisionShape] GetSize
-- @return const Vector3#const Vector3

---
-- Function GetPosition
--
-- @function [parent=#CollisionShape] GetPosition
-- @return const Vector3#const Vector3

---
-- Function GetRotation
--
-- @function [parent=#CollisionShape] GetRotation
-- @return const Quaternion#const Quaternion

---
-- Function GetMargin
--
-- @function [parent=#CollisionShape] GetMargin
-- @return #number

---
-- Function GetModel
--
-- @function [parent=#CollisionShape] GetModel
-- @return Model#Model

---
-- Function GetLodLevel
--
-- @function [parent=#CollisionShape] GetLodLevel
-- @return #number

---
-- Function GetWorldBoundingBox
--
-- @function [parent=#CollisionShape] GetWorldBoundingBox
-- @return BoundingBox#BoundingBox

---
-- Field physicsWorld (Read only)
--
-- @field [parent=#CollisionShape] PhysicsWorld#PhysicsWorld physicsWorld

---
-- Field shapeType
--
-- @field [parent=#CollisionShape] ShapeType#ShapeType shapeType

---
-- Field size
--
-- @field [parent=#CollisionShape] Vector3#Vector3 size

---
-- Field position
--
-- @field [parent=#CollisionShape] Vector3#Vector3 position

---
-- Field rotation
--
-- @field [parent=#CollisionShape] Quaternion#Quaternion rotation

---
-- Field margin
--
-- @field [parent=#CollisionShape] #number margin

---
-- Field model
--
-- @field [parent=#CollisionShape] Model#Model model

---
-- Field lodLevel
--
-- @field [parent=#CollisionShape] #number lodLevel

---
-- Field worldBoundingBox (Read only)
--
-- @field [parent=#CollisionShape] BoundingBox#BoundingBox worldBoundingBox

---
-- Field modelAttr
--
-- @field [parent=#CollisionShape] ResourceRef#ResourceRef modelAttr


return nil
