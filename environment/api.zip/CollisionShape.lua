---
-- Module CollisionShape
-- Module CollisionShape extends Component
-- Generated on 2014-05-31
--
-- @module CollisionShape

---
-- Function SetBox()
-- Set as a box.
--
-- @function [parent=#CollisionShape] SetBox
-- @param self Self reference
-- @param Vector3#Vector3 size size

---
-- Function SetBox()
--
-- @function [parent=#CollisionShape] SetBox
-- @param self Self reference
-- @param Vector3#Vector3 size size
-- @param Vector3#Vector3 position position

---
-- Function SetBox()
--
-- @function [parent=#CollisionShape] SetBox
-- @param self Self reference
-- @param Vector3#Vector3 size size
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetSphere()
-- Set as a sphere.
--
-- @function [parent=#CollisionShape] SetSphere
-- @param self Self reference
-- @param #number diameter diameter

---
-- Function SetSphere()
--
-- @function [parent=#CollisionShape] SetSphere
-- @param self Self reference
-- @param #number diameter diameter
-- @param Vector3#Vector3 position position

---
-- Function SetSphere()
--
-- @function [parent=#CollisionShape] SetSphere
-- @param self Self reference
-- @param #number diameter diameter
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetStaticPlane()
--
-- @function [parent=#CollisionShape] SetStaticPlane
-- @param self Self reference

---
-- Function SetStaticPlane()
-- Set as a static plane.
--
-- @function [parent=#CollisionShape] SetStaticPlane
-- @param self Self reference
-- @param Vector3#Vector3 position position

---
-- Function SetStaticPlane()
--
-- @function [parent=#CollisionShape] SetStaticPlane
-- @param self Self reference
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetCylinder()
-- Set as a cylinder.
--
-- @function [parent=#CollisionShape] SetCylinder
-- @param self Self reference
-- @param #number diameter diameter
-- @param #number height height

---
-- Function SetCylinder()
--
-- @function [parent=#CollisionShape] SetCylinder
-- @param self Self reference
-- @param #number diameter diameter
-- @param #number height height
-- @param Vector3#Vector3 position position

---
-- Function SetCylinder()
--
-- @function [parent=#CollisionShape] SetCylinder
-- @param self Self reference
-- @param #number diameter diameter
-- @param #number height height
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetCapsule()
-- Set as a capsule.
--
-- @function [parent=#CollisionShape] SetCapsule
-- @param self Self reference
-- @param #number diameter diameter
-- @param #number height height

---
-- Function SetCapsule()
--
-- @function [parent=#CollisionShape] SetCapsule
-- @param self Self reference
-- @param #number diameter diameter
-- @param #number height height
-- @param Vector3#Vector3 position position

---
-- Function SetCapsule()
--
-- @function [parent=#CollisionShape] SetCapsule
-- @param self Self reference
-- @param #number diameter diameter
-- @param #number height height
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetCone()
-- Set as a cone.
--
-- @function [parent=#CollisionShape] SetCone
-- @param self Self reference
-- @param #number diameter diameter
-- @param #number height height

---
-- Function SetCone()
--
-- @function [parent=#CollisionShape] SetCone
-- @param self Self reference
-- @param #number diameter diameter
-- @param #number height height
-- @param Vector3#Vector3 position position

---
-- Function SetCone()
--
-- @function [parent=#CollisionShape] SetCone
-- @param self Self reference
-- @param #number diameter diameter
-- @param #number height height
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetTriangleMesh()
-- Set as a triangle mesh.
--
-- @function [parent=#CollisionShape] SetTriangleMesh
-- @param self Self reference
-- @param Model#Model model model
-- @param #number lodLevel lodLevel

---
-- Function SetTriangleMesh()
--
-- @function [parent=#CollisionShape] SetTriangleMesh
-- @param self Self reference
-- @param Model#Model model model
-- @param #number lodLevel lodLevel
-- @param Vector3#Vector3 scale scale

---
-- Function SetTriangleMesh()
--
-- @function [parent=#CollisionShape] SetTriangleMesh
-- @param self Self reference
-- @param Model#Model model model
-- @param #number lodLevel lodLevel
-- @param Vector3#Vector3 scale scale
-- @param Vector3#Vector3 position position

---
-- Function SetTriangleMesh()
--
-- @function [parent=#CollisionShape] SetTriangleMesh
-- @param self Self reference
-- @param Model#Model model model
-- @param #number lodLevel lodLevel
-- @param Vector3#Vector3 scale scale
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetConvexHull()
-- Set as a convex hull from Model.
--
-- @function [parent=#CollisionShape] SetConvexHull
-- @param self Self reference
-- @param Model#Model model model
-- @param #number lodLevel lodLevel

---
-- Function SetConvexHull()
--
-- @function [parent=#CollisionShape] SetConvexHull
-- @param self Self reference
-- @param Model#Model model model
-- @param #number lodLevel lodLevel
-- @param Vector3#Vector3 scale scale

---
-- Function SetConvexHull()
--
-- @function [parent=#CollisionShape] SetConvexHull
-- @param self Self reference
-- @param Model#Model model model
-- @param #number lodLevel lodLevel
-- @param Vector3#Vector3 scale scale
-- @param Vector3#Vector3 position position

---
-- Function SetConvexHull()
--
-- @function [parent=#CollisionShape] SetConvexHull
-- @param self Self reference
-- @param Model#Model model model
-- @param #number lodLevel lodLevel
-- @param Vector3#Vector3 scale scale
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetTerrain()
-- Set as a terrain. Only works if the same scene node contains a Terrain component.
--
-- @function [parent=#CollisionShape] SetTerrain
-- @param self Self reference

---
-- Function SetShapeType()
-- Set shape type.
--
-- @function [parent=#CollisionShape] SetShapeType
-- @param self Self reference
-- @param ShapeType#ShapeType type type

---
-- Function SetSize()
-- Set shape size.
--
-- @function [parent=#CollisionShape] SetSize
-- @param self Self reference
-- @param Vector3#Vector3 size size

---
-- Function SetPosition()
-- Set offset position.
--
-- @function [parent=#CollisionShape] SetPosition
-- @param self Self reference
-- @param Vector3#Vector3 position position

---
-- Function SetRotation()
-- Set offset rotation.
--
-- @function [parent=#CollisionShape] SetRotation
-- @param self Self reference
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetTransform()
-- Set offset transform.
--
-- @function [parent=#CollisionShape] SetTransform
-- @param self Self reference
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetMargin()
-- Set collision margin.
--
-- @function [parent=#CollisionShape] SetMargin
-- @param self Self reference
-- @param #number margin margin

---
-- Function SetModel()
-- Set triangle mesh / convex hull model.
--
-- @function [parent=#CollisionShape] SetModel
-- @param self Self reference
-- @param Model#Model model model

---
-- Function SetLodLevel()
-- Set model LOD level.
--
-- @function [parent=#CollisionShape] SetLodLevel
-- @param self Self reference
-- @param #number lodLevel lodLevel

---
-- Function GetPhysicsWorld()
-- Return physics world.
--
-- @function [parent=#CollisionShape] GetPhysicsWorld
-- @param self Self reference
-- @return PhysicsWorld#PhysicsWorld

---
-- Function GetShapeType()
-- Return shape type.
--
-- @function [parent=#CollisionShape] GetShapeType
-- @param self Self reference
-- @return ShapeType#ShapeType

---
-- Function GetSize()
-- Return shape size.
--
-- @function [parent=#CollisionShape] GetSize
-- @param self Self reference
-- @return const Vector3#const Vector3

---
-- Function GetPosition()
-- Return offset position.
--
-- @function [parent=#CollisionShape] GetPosition
-- @param self Self reference
-- @return const Vector3#const Vector3

---
-- Function GetRotation()
-- Return offset rotation.
--
-- @function [parent=#CollisionShape] GetRotation
-- @param self Self reference
-- @return const Quaternion#const Quaternion

---
-- Function GetMargin()
-- Return collision margin.
--
-- @function [parent=#CollisionShape] GetMargin
-- @param self Self reference
-- @return #number

---
-- Function GetModel()
-- Return triangle mesh / convex hull model.
--
-- @function [parent=#CollisionShape] GetModel
-- @param self Self reference
-- @return Model#Model

---
-- Function GetLodLevel()
-- Return model LOD level.
--
-- @function [parent=#CollisionShape] GetLodLevel
-- @param self Self reference
-- @return #number

---
-- Function GetWorldBoundingBox()
-- Return world-space bounding box.
--
-- @function [parent=#CollisionShape] GetWorldBoundingBox
-- @param self Self reference
-- @return BoundingBox#BoundingBox

---
-- Field physicsWorld (Read only)
--
-- @field [parent=#CollisionShape] PhysicsWorld#PhysicsWorld physicsWorld

---
-- Field shapeType
--
-- @field [parent=#CollisionShape] ShapeType#ShapeType shapeType

---
-- Field size
--
-- @field [parent=#CollisionShape] Vector3#Vector3 size

---
-- Field position
--
-- @field [parent=#CollisionShape] Vector3#Vector3 position

---
-- Field rotation
--
-- @field [parent=#CollisionShape] Quaternion#Quaternion rotation

---
-- Field margin
--
-- @field [parent=#CollisionShape] #number margin

---
-- Field model
--
-- @field [parent=#CollisionShape] Model#Model model

---
-- Field lodLevel
--
-- @field [parent=#CollisionShape] #number lodLevel

---
-- Field worldBoundingBox (Read only)
--
-- @field [parent=#CollisionShape] BoundingBox#BoundingBox worldBoundingBox

---
-- Field modelAttr
--
-- @field [parent=#CollisionShape] ResourceRef#ResourceRef modelAttr


return nil
