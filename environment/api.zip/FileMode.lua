---
-- Enumeration FileMode
--
-- @module FileMode

---
-- Enumeration value FILE_READ
--
-- @field [parent=#FileMode] #number FILE_READ

---
-- Enumeration value FILE_WRITE
--
-- @field [parent=#FileMode] #number FILE_WRITE

---
-- Enumeration value FILE_READWRITE
--
-- @field [parent=#FileMode] #number FILE_READWRITE


return nil
