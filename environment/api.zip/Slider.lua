---
-- Module Slider
-- Module Slider extends BorderImage
-- Generated on 2014-05-31
--
-- @module Slider

---
-- Function Slider()
--
-- @function [parent=#Slider] Slider
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#Slider] new
-- @param self Self reference
-- @return Slider#Slider

---
-- Function delete()
--
-- @function [parent=#Slider] delete
-- @param self Self reference

---
-- Function SetOrientation()
-- Set orientation type.
--
-- @function [parent=#Slider] SetOrientation
-- @param self Self reference
-- @param Orientation#Orientation orientation orientation

---
-- Function SetRange()
-- Set slider range maximum value (minimum value is always 0.)
--
-- @function [parent=#Slider] SetRange
-- @param self Self reference
-- @param #number range range

---
-- Function SetValue()
-- Set slider current value.
--
-- @function [parent=#Slider] SetValue
-- @param self Self reference
-- @param #number value value

---
-- Function ChangeValue()
-- Change value by a delta.
--
-- @function [parent=#Slider] ChangeValue
-- @param self Self reference
-- @param #number delta delta

---
-- Function SetRepeatRate()
-- Set paging minimum repeat rate (number of events per second).
--
-- @function [parent=#Slider] SetRepeatRate
-- @param self Self reference
-- @param #number rate rate

---
-- Function GetOrientation()
-- Return orientation type.
--
-- @function [parent=#Slider] GetOrientation
-- @param self Self reference
-- @return Orientation#Orientation

---
-- Function GetRange()
-- Return slider range.
--
-- @function [parent=#Slider] GetRange
-- @param self Self reference
-- @return #number

---
-- Function GetValue()
-- Return slider current value.
--
-- @function [parent=#Slider] GetValue
-- @param self Self reference
-- @return #number

---
-- Function GetKnob()
-- Return knob element.
--
-- @function [parent=#Slider] GetKnob
-- @param self Self reference
-- @return BorderImage#BorderImage

---
-- Function GetRepeatRate()
-- Return paging minimum repeat rate (number of events per second).
--
-- @function [parent=#Slider] GetRepeatRate
-- @param self Self reference
-- @return #number

---
-- Field orientation
--
-- @field [parent=#Slider] Orientation#Orientation orientation

---
-- Field range
--
-- @field [parent=#Slider] #number range

---
-- Field value
--
-- @field [parent=#Slider] #number value

---
-- Field knob (Read only)
--
-- @field [parent=#Slider] BorderImage#BorderImage knob

---
-- Field repeatRate
--
-- @field [parent=#Slider] #number repeatRate


return nil
