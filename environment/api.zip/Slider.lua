---
-- Module Slider
-- Extends BorderImage
--
-- @module Slider

---
-- Function Slider
--
-- @function [parent=#Slider] Slider

---
-- Function new
--
-- @function [parent=#Slider] new
-- @return Slider#Slider

---
-- Function delete
--
-- @function [parent=#Slider] delete

---
-- Function SetOrientation
--
-- @function [parent=#Slider] SetOrientation
-- @param Orientation#Orientation orientationorientation

---
-- Function SetRange
--
-- @function [parent=#Slider] SetRange
-- @param #number rangerange

---
-- Function SetValue
--
-- @function [parent=#Slider] SetValue
-- @param #number valuevalue

---
-- Function ChangeValue
--
-- @function [parent=#Slider] ChangeValue
-- @param #number deltadelta

---
-- Function SetRepeatRate
--
-- @function [parent=#Slider] SetRepeatRate
-- @param #number raterate

---
-- Function GetOrientation
--
-- @function [parent=#Slider] GetOrientation
-- @return Orientation#Orientation

---
-- Function GetRange
--
-- @function [parent=#Slider] GetRange
-- @return #number

---
-- Function GetValue
--
-- @function [parent=#Slider] GetValue
-- @return #number

---
-- Function GetKnob
--
-- @function [parent=#Slider] GetKnob
-- @return BorderImage#BorderImage

---
-- Function GetRepeatRate
--
-- @function [parent=#Slider] GetRepeatRate
-- @return #number

---
-- Field orientation
--
-- @field [parent=#Slider] Orientation#Orientation orientation

---
-- Field range
--
-- @field [parent=#Slider] #number range

---
-- Field value
--
-- @field [parent=#Slider] #number value

---
-- Field knob (Read only)
--
-- @field [parent=#Slider] BorderImage#BorderImage knob

---
-- Field repeatRate
--
-- @field [parent=#Slider] #number repeatRate


return nil
