---
-- Module Slider
-- Module Slider extends BorderImage
-- Generated on 2014-03-13
--
-- @module Slider

---
-- Function Slider
--
-- @function [parent=#Slider] Slider
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#Slider] new
-- @param self Self reference
-- @return Slider#Slider

---
-- Function delete
--
-- @function [parent=#Slider] delete
-- @param self Self reference

---
-- Function SetOrientation
--
-- @function [parent=#Slider] SetOrientation
-- @param self Self reference
-- @param Orientation#Orientation orientation orientation

---
-- Function SetRange
--
-- @function [parent=#Slider] SetRange
-- @param self Self reference
-- @param #number range range

---
-- Function SetValue
--
-- @function [parent=#Slider] SetValue
-- @param self Self reference
-- @param #number value value

---
-- Function ChangeValue
--
-- @function [parent=#Slider] ChangeValue
-- @param self Self reference
-- @param #number delta delta

---
-- Function SetRepeatRate
--
-- @function [parent=#Slider] SetRepeatRate
-- @param self Self reference
-- @param #number rate rate

---
-- Function GetOrientation
--
-- @function [parent=#Slider] GetOrientation
-- @param self Self reference
-- @return Orientation#Orientation

---
-- Function GetRange
--
-- @function [parent=#Slider] GetRange
-- @param self Self reference
-- @return #number

---
-- Function GetValue
--
-- @function [parent=#Slider] GetValue
-- @param self Self reference
-- @return #number

---
-- Function GetKnob
--
-- @function [parent=#Slider] GetKnob
-- @param self Self reference
-- @return BorderImage#BorderImage

---
-- Function GetRepeatRate
--
-- @function [parent=#Slider] GetRepeatRate
-- @param self Self reference
-- @return #number

---
-- Field orientation
--
-- @field [parent=#Slider] Orientation#Orientation orientation

---
-- Field range
--
-- @field [parent=#Slider] #number range

---
-- Field value
--
-- @field [parent=#Slider] #number value

---
-- Field knob (Read only)
--
-- @field [parent=#Slider] BorderImage#BorderImage knob

---
-- Field repeatRate
--
-- @field [parent=#Slider] #number repeatRate

---
-- Function BorderImage
--
-- @function [parent=#Slider] BorderImage
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#Slider] new
-- @param self Self reference
-- @return BorderImage#BorderImage

---
-- Function delete
--
-- @function [parent=#Slider] delete
-- @param self Self reference

---
-- Function SetTexture
--
-- @function [parent=#Slider] SetTexture
-- @param self Self reference
-- @param Texture#Texture texture texture

---
-- Function SetImageRect
--
-- @function [parent=#Slider] SetImageRect
-- @param self Self reference
-- @param IntRect#IntRect rect rect

---
-- Function SetFullImageRect
--
-- @function [parent=#Slider] SetFullImageRect
-- @param self Self reference

---
-- Function SetBorder
--
-- @function [parent=#Slider] SetBorder
-- @param self Self reference
-- @param IntRect#IntRect rect rect

---
-- Function SetHoverOffset
--
-- @function [parent=#Slider] SetHoverOffset
-- @param self Self reference
-- @param IntVector2#IntVector2 offset offset

---
-- Function SetHoverOffset
--
-- @function [parent=#Slider] SetHoverOffset
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function SetBlendMode
--
-- @function [parent=#Slider] SetBlendMode
-- @param self Self reference
-- @param BlendMode#BlendMode mode mode

---
-- Function SetTiled
--
-- @function [parent=#Slider] SetTiled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function GetTexture
--
-- @function [parent=#Slider] GetTexture
-- @param self Self reference
-- @return Texture#Texture

---
-- Function GetImageRect
--
-- @function [parent=#Slider] GetImageRect
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetBorder
--
-- @function [parent=#Slider] GetBorder
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetHoverOffset
--
-- @function [parent=#Slider] GetHoverOffset
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetBlendMode
--
-- @function [parent=#Slider] GetBlendMode
-- @param self Self reference
-- @return BlendMode#BlendMode

---
-- Function IsTiled
--
-- @function [parent=#Slider] IsTiled
-- @param self Self reference
-- @return #boolean

---
-- Field texture
--
-- @field [parent=#Slider] Texture#Texture texture

---
-- Field imageRect
--
-- @field [parent=#Slider] IntRect#IntRect imageRect

---
-- Field border
--
-- @field [parent=#Slider] IntRect#IntRect border

---
-- Field hoverOffset
--
-- @field [parent=#Slider] IntVector2#IntVector2 hoverOffset

---
-- Field blendMode
--
-- @field [parent=#Slider] BlendMode#BlendMode blendMode

---
-- Field tiled
--
-- @field [parent=#Slider] #boolean tiled

---
-- Function UIElement
--
-- @function [parent=#Slider] UIElement
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#Slider] new
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function delete
--
-- @function [parent=#Slider] delete
-- @param self Self reference

---
-- Function GetScreenPosition
--
-- @function [parent=#Slider] GetScreenPosition
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function LoadXML
--
-- @function [parent=#Slider] LoadXML
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#Slider] SaveXML
-- @param self Self reference
-- @param Serializer#Serializer dest dest
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#Slider] LoadXML
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#Slider] SaveXML
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function FilterAttributes
--
-- @function [parent=#Slider] FilterAttributes
-- @param self Self reference
-- @param XMLElement#XMLElement dest dest
-- @return #boolean

---
-- Function SetName
--
-- @function [parent=#Slider] SetName
-- @param self Self reference
-- @param #string name name

---
-- Function SetPosition
--
-- @function [parent=#Slider] SetPosition
-- @param self Self reference
-- @param IntVector2#IntVector2 position position

---
-- Function SetPosition
--
-- @function [parent=#Slider] SetPosition
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function SetSize
--
-- @function [parent=#Slider] SetSize
-- @param self Self reference
-- @param IntVector2#IntVector2 size size

---
-- Function SetSize
--
-- @function [parent=#Slider] SetSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetWidth
--
-- @function [parent=#Slider] SetWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetHeight
--
-- @function [parent=#Slider] SetHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetMinSize
--
-- @function [parent=#Slider] SetMinSize
-- @param self Self reference
-- @param IntVector2#IntVector2 minSize minSize

---
-- Function SetMinSize
--
-- @function [parent=#Slider] SetMinSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetMinWidth
--
-- @function [parent=#Slider] SetMinWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetMinHeight
--
-- @function [parent=#Slider] SetMinHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetMaxSize
--
-- @function [parent=#Slider] SetMaxSize
-- @param self Self reference
-- @param IntVector2#IntVector2 maxSize maxSize

---
-- Function SetMaxSize
--
-- @function [parent=#Slider] SetMaxSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetMaxWidth
--
-- @function [parent=#Slider] SetMaxWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetMaxHeight
--
-- @function [parent=#Slider] SetMaxHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetFixedSize
--
-- @function [parent=#Slider] SetFixedSize
-- @param self Self reference
-- @param IntVector2#IntVector2 size size

---
-- Function SetFixedSize
--
-- @function [parent=#Slider] SetFixedSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetFixedWidth
--
-- @function [parent=#Slider] SetFixedWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetFixedHeight
--
-- @function [parent=#Slider] SetFixedHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetAlignment
--
-- @function [parent=#Slider] SetAlignment
-- @param self Self reference
-- @param HorizontalAlignment#HorizontalAlignment hAlign hAlign
-- @param VerticalAlignment#VerticalAlignment vAlign vAlign

---
-- Function SetHorizontalAlignment
--
-- @function [parent=#Slider] SetHorizontalAlignment
-- @param self Self reference
-- @param HorizontalAlignment#HorizontalAlignment align align

---
-- Function SetVerticalAlignment
--
-- @function [parent=#Slider] SetVerticalAlignment
-- @param self Self reference
-- @param VerticalAlignment#VerticalAlignment align align

---
-- Function SetClipBorder
--
-- @function [parent=#Slider] SetClipBorder
-- @param self Self reference
-- @param IntRect#IntRect rect rect

---
-- Function SetColor
--
-- @function [parent=#Slider] SetColor
-- @param self Self reference
-- @param Color#Color color color

---
-- Function SetColor
--
-- @function [parent=#Slider] SetColor
-- @param self Self reference
-- @param Corner#Corner corner corner
-- @param Color#Color color color

---
-- Function SetPriority
--
-- @function [parent=#Slider] SetPriority
-- @param self Self reference
-- @param #number priority priority

---
-- Function SetOpacity
--
-- @function [parent=#Slider] SetOpacity
-- @param self Self reference
-- @param #number opacity opacity

---
-- Function SetBringToFront
--
-- @function [parent=#Slider] SetBringToFront
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetBringToBack
--
-- @function [parent=#Slider] SetBringToBack
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetClipChildren
--
-- @function [parent=#Slider] SetClipChildren
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetSortChildren
--
-- @function [parent=#Slider] SetSortChildren
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetUseDerivedOpacity
--
-- @function [parent=#Slider] SetUseDerivedOpacity
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetEnabled
--
-- @function [parent=#Slider] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetEditable
--
-- @function [parent=#Slider] SetEditable
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetFocus
--
-- @function [parent=#Slider] SetFocus
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetSelected
--
-- @function [parent=#Slider] SetSelected
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetVisible
--
-- @function [parent=#Slider] SetVisible
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetFocusMode
--
-- @function [parent=#Slider] SetFocusMode
-- @param self Self reference
-- @param FocusMode#FocusMode mode mode

---
-- Function SetDragDropMode
--
-- @function [parent=#Slider] SetDragDropMode
-- @param self Self reference
-- @param #number mode mode

---
-- Function SetStyle
--
-- @function [parent=#Slider] SetStyle
-- @param self Self reference
-- @param #string styleName styleName
-- @param XMLFile#XMLFile file file
-- @return #boolean

---
-- Function SetStyle
--
-- @function [parent=#Slider] SetStyle
-- @param self Self reference
-- @param XMLElement#XMLElement element element
-- @return #boolean

---
-- Function SetStyleAuto
--
-- @function [parent=#Slider] SetStyleAuto
-- @param self Self reference
-- @param XMLFile#XMLFile file file
-- @return #boolean

---
-- Function SetDefaultStyle
--
-- @function [parent=#Slider] SetDefaultStyle
-- @param self Self reference
-- @param XMLFile#XMLFile style style

---
-- Function SetLayout
--
-- @function [parent=#Slider] SetLayout
-- @param self Self reference
-- @param LayoutMode#LayoutMode mode mode
-- @param #number spacing spacing

---
-- Function SetLayout
--
-- @function [parent=#Slider] SetLayout
-- @param self Self reference
-- @param LayoutMode#LayoutMode mode mode
-- @param #number spacing spacing
-- @param IntRect#IntRect border border

---
-- Function SetLayoutMode
--
-- @function [parent=#Slider] SetLayoutMode
-- @param self Self reference
-- @param LayoutMode#LayoutMode mode mode

---
-- Function SetLayoutSpacing
--
-- @function [parent=#Slider] SetLayoutSpacing
-- @param self Self reference
-- @param #number spacing spacing

---
-- Function SetLayoutBorder
--
-- @function [parent=#Slider] SetLayoutBorder
-- @param self Self reference
-- @param IntRect#IntRect border border

---
-- Function SetIndent
--
-- @function [parent=#Slider] SetIndent
-- @param self Self reference
-- @param #number indent indent

---
-- Function SetIndentSpacing
--
-- @function [parent=#Slider] SetIndentSpacing
-- @param self Self reference
-- @param #number indentSpacing indentSpacing

---
-- Function UpdateLayout
--
-- @function [parent=#Slider] UpdateLayout
-- @param self Self reference

---
-- Function DisableLayoutUpdate
--
-- @function [parent=#Slider] DisableLayoutUpdate
-- @param self Self reference

---
-- Function EnableLayoutUpdate
--
-- @function [parent=#Slider] EnableLayoutUpdate
-- @param self Self reference

---
-- Function BringToFront
--
-- @function [parent=#Slider] BringToFront
-- @param self Self reference

---
-- Function CreateChild
--
-- @function [parent=#Slider] CreateChild
-- @param self Self reference
-- @param #string type type
-- @param #string name name
-- @param #number index index
-- @return UIElement#UIElement

---
-- Function AddChild
--
-- @function [parent=#Slider] AddChild
-- @param self Self reference
-- @param UIElement#UIElement element element

---
-- Function InsertChild
--
-- @function [parent=#Slider] InsertChild
-- @param self Self reference
-- @param #number index index
-- @param UIElement#UIElement element element

---
-- Function RemoveChild
--
-- @function [parent=#Slider] RemoveChild
-- @param self Self reference
-- @param UIElement#UIElement element element
-- @param #number index index

---
-- Function RemoveChildAtIndex
--
-- @function [parent=#Slider] RemoveChildAtIndex
-- @param self Self reference
-- @param #number index index

---
-- Function RemoveAllChildren
--
-- @function [parent=#Slider] RemoveAllChildren
-- @param self Self reference

---
-- Function Remove
--
-- @function [parent=#Slider] Remove
-- @param self Self reference

---
-- Function FindChild
--
-- @function [parent=#Slider] FindChild
-- @param self Self reference
-- @param UIElement#UIElement element element
-- @return #number

---
-- Function SetParent
--
-- @function [parent=#Slider] SetParent
-- @param self Self reference
-- @param UIElement#UIElement parent parent
-- @param #number index index

---
-- Function SetVar
--
-- @function [parent=#Slider] SetVar
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash key key
-- @param Variant#Variant value value

---
-- Function SetInternal
--
-- @function [parent=#Slider] SetInternal
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetTraversalMode
--
-- @function [parent=#Slider] SetTraversalMode
-- @param self Self reference
-- @param TraversalMode#TraversalMode traversalMode traversalMode

---
-- Function SetElementEventSender
--
-- @function [parent=#Slider] SetElementEventSender
-- @param self Self reference
-- @param #boolean flag flag

---
-- Function GetName
--
-- @function [parent=#Slider] GetName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetPosition
--
-- @function [parent=#Slider] GetPosition
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetSize
--
-- @function [parent=#Slider] GetSize
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetWidth
--
-- @function [parent=#Slider] GetWidth
-- @param self Self reference
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#Slider] GetHeight
-- @param self Self reference
-- @return #number

---
-- Function GetMinSize
--
-- @function [parent=#Slider] GetMinSize
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetMinWidth
--
-- @function [parent=#Slider] GetMinWidth
-- @param self Self reference
-- @return #number

---
-- Function GetMinHeight
--
-- @function [parent=#Slider] GetMinHeight
-- @param self Self reference
-- @return #number

---
-- Function GetMaxSize
--
-- @function [parent=#Slider] GetMaxSize
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetMaxWidth
--
-- @function [parent=#Slider] GetMaxWidth
-- @param self Self reference
-- @return #number

---
-- Function GetMaxHeight
--
-- @function [parent=#Slider] GetMaxHeight
-- @param self Self reference
-- @return #number

---
-- Function IsFixedSize
--
-- @function [parent=#Slider] IsFixedSize
-- @param self Self reference
-- @return #boolean

---
-- Function IsFixedWidth
--
-- @function [parent=#Slider] IsFixedWidth
-- @param self Self reference
-- @return #boolean

---
-- Function IsFixedHeight
--
-- @function [parent=#Slider] IsFixedHeight
-- @param self Self reference
-- @return #boolean

---
-- Function GetChildOffset
--
-- @function [parent=#Slider] GetChildOffset
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetHorizontalAlignment
--
-- @function [parent=#Slider] GetHorizontalAlignment
-- @param self Self reference
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetVerticalAlignment
--
-- @function [parent=#Slider] GetVerticalAlignment
-- @param self Self reference
-- @return VerticalAlignment#VerticalAlignment

---
-- Function GetClipBorder
--
-- @function [parent=#Slider] GetClipBorder
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetColor
--
-- @function [parent=#Slider] GetColor
-- @param self Self reference
-- @param Corner#Corner corner corner
-- @return const Color#const Color

---
-- Function GetPriority
--
-- @function [parent=#Slider] GetPriority
-- @param self Self reference
-- @return #number

---
-- Function GetOpacity
--
-- @function [parent=#Slider] GetOpacity
-- @param self Self reference
-- @return #number

---
-- Function GetDerivedOpacity
--
-- @function [parent=#Slider] GetDerivedOpacity
-- @param self Self reference
-- @return #number

---
-- Function GetBringToFront
--
-- @function [parent=#Slider] GetBringToFront
-- @param self Self reference
-- @return #boolean

---
-- Function GetBringToBack
--
-- @function [parent=#Slider] GetBringToBack
-- @param self Self reference
-- @return #boolean

---
-- Function GetClipChildren
--
-- @function [parent=#Slider] GetClipChildren
-- @param self Self reference
-- @return #boolean

---
-- Function GetSortChildren
--
-- @function [parent=#Slider] GetSortChildren
-- @param self Self reference
-- @return #boolean

---
-- Function GetUseDerivedOpacity
--
-- @function [parent=#Slider] GetUseDerivedOpacity
-- @param self Self reference
-- @return #boolean

---
-- Function HasFocus
--
-- @function [parent=#Slider] HasFocus
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabled
--
-- @function [parent=#Slider] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEditable
--
-- @function [parent=#Slider] IsEditable
-- @param self Self reference
-- @return #boolean

---
-- Function IsSelected
--
-- @function [parent=#Slider] IsSelected
-- @param self Self reference
-- @return #boolean

---
-- Function IsVisible
--
-- @function [parent=#Slider] IsVisible
-- @param self Self reference
-- @return #boolean

---
-- Function IsHovering
--
-- @function [parent=#Slider] IsHovering
-- @param self Self reference
-- @return #boolean

---
-- Function IsInternal
--
-- @function [parent=#Slider] IsInternal
-- @param self Self reference
-- @return #boolean

---
-- Function HasColorGradient
--
-- @function [parent=#Slider] HasColorGradient
-- @param self Self reference
-- @return #boolean

---
-- Function GetFocusMode
--
-- @function [parent=#Slider] GetFocusMode
-- @param self Self reference
-- @return FocusMode#FocusMode

---
-- Function GetDragDropMode
--
-- @function [parent=#Slider] GetDragDropMode
-- @param self Self reference
-- @return #number

---
-- Function GetAppliedStyle
--
-- @function [parent=#Slider] GetAppliedStyle
-- @param self Self reference
-- @return const String#const String

---
-- Function GetDefaultStyle
--
-- @function [parent=#Slider] GetDefaultStyle
-- @param self Self reference
-- @param #boolean recursiveUp recursiveUp
-- @return XMLFile#XMLFile

---
-- Function GetLayoutMode
--
-- @function [parent=#Slider] GetLayoutMode
-- @param self Self reference
-- @return LayoutMode#LayoutMode

---
-- Function GetLayoutSpacing
--
-- @function [parent=#Slider] GetLayoutSpacing
-- @param self Self reference
-- @return #number

---
-- Function GetLayoutBorder
--
-- @function [parent=#Slider] GetLayoutBorder
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetNumChildren
--
-- @function [parent=#Slider] GetNumChildren
-- @param self Self reference
-- @param #boolean recursive recursive
-- @return #number

---
-- Function GetChild
--
-- @function [parent=#Slider] GetChild
-- @param self Self reference
-- @param #string name name
-- @param #boolean recursive recursive
-- @return UIElement#UIElement

---
-- Function GetChild
--
-- @function [parent=#Slider] GetChild
-- @param self Self reference
-- @param #number index index
-- @return UIElement#UIElement

---
-- Function GetParent
--
-- @function [parent=#Slider] GetParent
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetRoot
--
-- @function [parent=#Slider] GetRoot
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetDerivedColor
--
-- @function [parent=#Slider] GetDerivedColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetVar
--
-- @function [parent=#Slider] GetVar
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash key key
-- @return const Variant#const Variant

---
-- Function GetVars
--
-- @function [parent=#Slider] GetVars
-- @param self Self reference
-- @return const VariantMap#const VariantMap

---
-- Function ScreenToElement
--
-- @function [parent=#Slider] ScreenToElement
-- @param self Self reference
-- @param IntVector2#IntVector2 screenPosition screenPosition
-- @return IntVector2#IntVector2

---
-- Function ElementToScreen
--
-- @function [parent=#Slider] ElementToScreen
-- @param self Self reference
-- @param IntVector2#IntVector2 position position
-- @return IntVector2#IntVector2

---
-- Function IsInside
--
-- @function [parent=#Slider] IsInside
-- @param self Self reference
-- @param IntVector2#IntVector2 position position
-- @param #boolean isScreen isScreen
-- @return #boolean

---
-- Function IsInsideCombined
--
-- @function [parent=#Slider] IsInsideCombined
-- @param self Self reference
-- @param IntVector2#IntVector2 position position
-- @param #boolean isScreen isScreen
-- @return #boolean

---
-- Function GetCombinedScreenRect
--
-- @function [parent=#Slider] GetCombinedScreenRect
-- @param self Self reference
-- @return IntRect#IntRect

---
-- Function SortChildren
--
-- @function [parent=#Slider] SortChildren
-- @param self Self reference

---
-- Function GetLayoutMinSize
--
-- @function [parent=#Slider] GetLayoutMinSize
-- @param self Self reference
-- @return #number

---
-- Function GetIndent
--
-- @function [parent=#Slider] GetIndent
-- @param self Self reference
-- @return #number

---
-- Function GetIndentSpacing
--
-- @function [parent=#Slider] GetIndentSpacing
-- @param self Self reference
-- @return #number

---
-- Function GetIndentWidth
--
-- @function [parent=#Slider] GetIndentWidth
-- @param self Self reference
-- @return #number

---
-- Function SetChildOffset
--
-- @function [parent=#Slider] SetChildOffset
-- @param self Self reference
-- @param IntVector2#IntVector2 offset offset

---
-- Function SetHovering
--
-- @function [parent=#Slider] SetHovering
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function GetColor
--
-- @function [parent=#Slider] GetColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetTraversalMode
--
-- @function [parent=#Slider] GetTraversalMode
-- @param self Self reference
-- @return TraversalMode#TraversalMode

---
-- Function IsElementEventSender
--
-- @function [parent=#Slider] IsElementEventSender
-- @param self Self reference
-- @return #boolean

---
-- Function GetElementEventSender
--
-- @function [parent=#Slider] GetElementEventSender
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Field screenPosition (Read only)
--
-- @field [parent=#Slider] IntVector2#IntVector2 screenPosition

---
-- Field name
--
-- @field [parent=#Slider] #string name

---
-- Field position
--
-- @field [parent=#Slider] IntVector2#IntVector2 position

---
-- Field size
--
-- @field [parent=#Slider] IntVector2#IntVector2 size

---
-- Field width
--
-- @field [parent=#Slider] #number width

---
-- Field height
--
-- @field [parent=#Slider] #number height

---
-- Field minSize
--
-- @field [parent=#Slider] IntVector2#IntVector2 minSize

---
-- Field minWidth
--
-- @field [parent=#Slider] #number minWidth

---
-- Field minHeight
--
-- @field [parent=#Slider] #number minHeight

---
-- Field maxSize
--
-- @field [parent=#Slider] IntVector2#IntVector2 maxSize

---
-- Field maxWidth
--
-- @field [parent=#Slider] #number maxWidth

---
-- Field maxHeight
--
-- @field [parent=#Slider] #number maxHeight

---
-- Field fixedSize (Read only)
--
-- @field [parent=#Slider] #boolean fixedSize

---
-- Field fixedWidth (Read only)
--
-- @field [parent=#Slider] #boolean fixedWidth

---
-- Field fixedHeight (Read only)
--
-- @field [parent=#Slider] #boolean fixedHeight

---
-- Field childOffset
--
-- @field [parent=#Slider] IntVector2#IntVector2 childOffset

---
-- Field horizontalAlignment
--
-- @field [parent=#Slider] HorizontalAlignment#HorizontalAlignment horizontalAlignment

---
-- Field verticalAlignment
--
-- @field [parent=#Slider] VerticalAlignment#VerticalAlignment verticalAlignment

---
-- Field clipBorder
--
-- @field [parent=#Slider] IntRect#IntRect clipBorder

---
-- Field color
--
-- @field [parent=#Slider] Color#Color color

---
-- Field priority
--
-- @field [parent=#Slider] #number priority

---
-- Field opacity
--
-- @field [parent=#Slider] #number opacity

---
-- Field derivedOpacity (Read only)
--
-- @field [parent=#Slider] #number derivedOpacity

---
-- Field bringToFront
--
-- @field [parent=#Slider] #boolean bringToFront

---
-- Field bringToBack
--
-- @field [parent=#Slider] #boolean bringToBack

---
-- Field clipChildren
--
-- @field [parent=#Slider] #boolean clipChildren

---
-- Field sortChildren
--
-- @field [parent=#Slider] #boolean sortChildren

---
-- Field useDerivedOpacity
--
-- @field [parent=#Slider] #boolean useDerivedOpacity

---
-- Field focus
--
-- @field [parent=#Slider] #boolean focus

---
-- Field enabled
--
-- @field [parent=#Slider] #boolean enabled

---
-- Field editable
--
-- @field [parent=#Slider] #boolean editable

---
-- Field selected
--
-- @field [parent=#Slider] #boolean selected

---
-- Field visible
--
-- @field [parent=#Slider] #boolean visible

---
-- Field hovering
--
-- @field [parent=#Slider] #boolean hovering

---
-- Field internal
--
-- @field [parent=#Slider] #boolean internal

---
-- Field colorGradient (Read only)
--
-- @field [parent=#Slider] #boolean colorGradient

---
-- Field focusMode
--
-- @field [parent=#Slider] FocusMode#FocusMode focusMode

---
-- Field dragDropMode
--
-- @field [parent=#Slider] #number dragDropMode

---
-- Field style
--
-- @field [parent=#Slider] #string style

---
-- Field defaultStyle
--
-- @field [parent=#Slider] XMLFile#XMLFile defaultStyle

---
-- Field layoutMode
--
-- @field [parent=#Slider] LayoutMode#LayoutMode layoutMode

---
-- Field layoutSpacing
--
-- @field [parent=#Slider] #number layoutSpacing

---
-- Field layoutBorder
--
-- @field [parent=#Slider] IntRect#IntRect layoutBorder

---
-- Field numChildren (Read only)
--
-- @field [parent=#Slider] #number numChildren

---
-- Field parent
--
-- @field [parent=#Slider] UIElement#UIElement parent

---
-- Field root (Read only)
--
-- @field [parent=#Slider] UIElement#UIElement root

---
-- Field derivedColor (Read only)
--
-- @field [parent=#Slider] Color#Color derivedColor

---
-- Field combinedScreenRect (Read only)
--
-- @field [parent=#Slider] IntRect#IntRect combinedScreenRect

---
-- Field layoutMinSize (Read only)
--
-- @field [parent=#Slider] #number layoutMinSize

---
-- Field indent
--
-- @field [parent=#Slider] #number indent

---
-- Field indentSpacing
--
-- @field [parent=#Slider] #number indentSpacing

---
-- Field indentWidth (Read only)
--
-- @field [parent=#Slider] #number indentWidth

---
-- Field traversalMode
--
-- @field [parent=#Slider] TraversalMode#TraversalMode traversalMode

---
-- Field elementEventSender
--
-- @field [parent=#Slider] #boolean elementEventSender

---
-- Function SetTemporary
--
-- @function [parent=#Slider] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#Slider] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Slider] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Slider] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Slider] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Slider] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Slider] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Slider] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#Slider] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Slider] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Slider] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Slider] #string category


return nil
