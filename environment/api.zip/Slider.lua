---
-- Module Slider
-- extends BorderImage
--
-- @module Slider

---
-- Function Slider
--
-- @function [parent=#Slider] Slider

---
-- Function new
--
-- @function [parent=#Slider] new
-- @return Slider#Slider

---
-- Function delete
--
-- @function [parent=#Slider] delete

---
-- Function SetOrientation
--
-- @function [parent=#Slider] SetOrientation
-- @param Orientation#Orientation orientationorientation

---
-- Function SetRange
--
-- @function [parent=#Slider] SetRange
-- @param #number rangerange

---
-- Function SetValue
--
-- @function [parent=#Slider] SetValue
-- @param #number valuevalue

---
-- Function ChangeValue
--
-- @function [parent=#Slider] ChangeValue
-- @param #number deltadelta

---
-- Function SetRepeatRate
--
-- @function [parent=#Slider] SetRepeatRate
-- @param #number raterate

---
-- Function GetOrientation
--
-- @function [parent=#Slider] GetOrientation
-- @return Orientation#Orientation

---
-- Function GetRange
--
-- @function [parent=#Slider] GetRange
-- @return #number

---
-- Function GetValue
--
-- @function [parent=#Slider] GetValue
-- @return #number

---
-- Function GetKnob
--
-- @function [parent=#Slider] GetKnob
-- @return BorderImage#BorderImage

---
-- Function GetRepeatRate
--
-- @function [parent=#Slider] GetRepeatRate
-- @return #number

---
-- Field orientation
--
-- @field [parent=#Slider] Orientation#Orientation orientation

---
-- Field range
--
-- @field [parent=#Slider] #number range

---
-- Field value
--
-- @field [parent=#Slider] #number value

---
-- Field knob (Read only)
--
-- @field [parent=#Slider] BorderImage#BorderImage knob

---
-- Field repeatRate
--
-- @field [parent=#Slider] #number repeatRate

---
-- Function BorderImage
--
-- @function [parent=#Slider] BorderImage

---
-- Function new
--
-- @function [parent=#Slider] new
-- @return BorderImage#BorderImage

---
-- Function delete
--
-- @function [parent=#Slider] delete

---
-- Function SetTexture
--
-- @function [parent=#Slider] SetTexture
-- @param Texture#Texture texturetexture

---
-- Function SetImageRect
--
-- @function [parent=#Slider] SetImageRect
-- @param IntRect#IntRect rectrect

---
-- Function SetFullImageRect
--
-- @function [parent=#Slider] SetFullImageRect

---
-- Function SetBorder
--
-- @function [parent=#Slider] SetBorder
-- @param IntRect#IntRect rectrect

---
-- Function SetHoverOffset
--
-- @function [parent=#Slider] SetHoverOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetHoverOffset
--
-- @function [parent=#Slider] SetHoverOffset
-- @param #number xx
-- @param #number yy

---
-- Function SetBlendMode
--
-- @function [parent=#Slider] SetBlendMode
-- @param BlendMode#BlendMode modemode

---
-- Function SetTiled
--
-- @function [parent=#Slider] SetTiled
-- @param #boolean enableenable

---
-- Function GetTexture
--
-- @function [parent=#Slider] GetTexture
-- @return Texture#Texture

---
-- Function GetImageRect
--
-- @function [parent=#Slider] GetImageRect
-- @return const IntRect#const IntRect

---
-- Function GetBorder
--
-- @function [parent=#Slider] GetBorder
-- @return const IntRect#const IntRect

---
-- Function GetHoverOffset
--
-- @function [parent=#Slider] GetHoverOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetBlendMode
--
-- @function [parent=#Slider] GetBlendMode
-- @return BlendMode#BlendMode

---
-- Function IsTiled
--
-- @function [parent=#Slider] IsTiled
-- @return #boolean

---
-- Field texture
--
-- @field [parent=#Slider] Texture#Texture texture

---
-- Field imageRect
--
-- @field [parent=#Slider] IntRect#IntRect imageRect

---
-- Field border
--
-- @field [parent=#Slider] IntRect#IntRect border

---
-- Field hoverOffset
--
-- @field [parent=#Slider] IntVector2#IntVector2 hoverOffset

---
-- Field blendMode
--
-- @field [parent=#Slider] BlendMode#BlendMode blendMode

---
-- Field tiled
--
-- @field [parent=#Slider] #boolean tiled

---
-- Function UIElement
--
-- @function [parent=#Slider] UIElement

---
-- Function new
--
-- @function [parent=#Slider] new
-- @return UIElement#UIElement

---
-- Function delete
--
-- @function [parent=#Slider] delete

---
-- Function GetScreenPosition
--
-- @function [parent=#Slider] GetScreenPosition
-- @return const IntVector2#const IntVector2

---
-- Function LoadXML
--
-- @function [parent=#Slider] LoadXML
-- @param Deserializer#Deserializer sourcesource
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#Slider] SaveXML
-- @param Serializer#Serializer destdest
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#Slider] LoadXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#Slider] SaveXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function FilterAttributes
--
-- @function [parent=#Slider] FilterAttributes
-- @param XMLElement#XMLElement destdest
-- @return #boolean

---
-- Function SetName
--
-- @function [parent=#Slider] SetName
-- @param #string namename

---
-- Function SetPosition
--
-- @function [parent=#Slider] SetPosition
-- @param IntVector2#IntVector2 positionposition

---
-- Function SetPosition
--
-- @function [parent=#Slider] SetPosition
-- @param #number xx
-- @param #number yy

---
-- Function SetSize
--
-- @function [parent=#Slider] SetSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function SetSize
--
-- @function [parent=#Slider] SetSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetWidth
--
-- @function [parent=#Slider] SetWidth
-- @param #number widthwidth

---
-- Function SetHeight
--
-- @function [parent=#Slider] SetHeight
-- @param #number heightheight

---
-- Function SetMinSize
--
-- @function [parent=#Slider] SetMinSize
-- @param IntVector2#IntVector2 minSizeminSize

---
-- Function SetMinSize
--
-- @function [parent=#Slider] SetMinSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetMinWidth
--
-- @function [parent=#Slider] SetMinWidth
-- @param #number widthwidth

---
-- Function SetMinHeight
--
-- @function [parent=#Slider] SetMinHeight
-- @param #number heightheight

---
-- Function SetMaxSize
--
-- @function [parent=#Slider] SetMaxSize
-- @param IntVector2#IntVector2 maxSizemaxSize

---
-- Function SetMaxSize
--
-- @function [parent=#Slider] SetMaxSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetMaxWidth
--
-- @function [parent=#Slider] SetMaxWidth
-- @param #number widthwidth

---
-- Function SetMaxHeight
--
-- @function [parent=#Slider] SetMaxHeight
-- @param #number heightheight

---
-- Function SetFixedSize
--
-- @function [parent=#Slider] SetFixedSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function SetFixedSize
--
-- @function [parent=#Slider] SetFixedSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetFixedWidth
--
-- @function [parent=#Slider] SetFixedWidth
-- @param #number widthwidth

---
-- Function SetFixedHeight
--
-- @function [parent=#Slider] SetFixedHeight
-- @param #number heightheight

---
-- Function SetAlignment
--
-- @function [parent=#Slider] SetAlignment
-- @param HorizontalAlignment#HorizontalAlignment hAlignhAlign
-- @param VerticalAlignment#VerticalAlignment vAlignvAlign

---
-- Function SetHorizontalAlignment
--
-- @function [parent=#Slider] SetHorizontalAlignment
-- @param HorizontalAlignment#HorizontalAlignment alignalign

---
-- Function SetVerticalAlignment
--
-- @function [parent=#Slider] SetVerticalAlignment
-- @param VerticalAlignment#VerticalAlignment alignalign

---
-- Function SetClipBorder
--
-- @function [parent=#Slider] SetClipBorder
-- @param IntRect#IntRect rectrect

---
-- Function SetColor
--
-- @function [parent=#Slider] SetColor
-- @param Color#Color colorcolor

---
-- Function SetColor
--
-- @function [parent=#Slider] SetColor
-- @param Corner#Corner cornercorner
-- @param Color#Color colorcolor

---
-- Function SetPriority
--
-- @function [parent=#Slider] SetPriority
-- @param #number prioritypriority

---
-- Function SetOpacity
--
-- @function [parent=#Slider] SetOpacity
-- @param #number opacityopacity

---
-- Function SetBringToFront
--
-- @function [parent=#Slider] SetBringToFront
-- @param #boolean enableenable

---
-- Function SetBringToBack
--
-- @function [parent=#Slider] SetBringToBack
-- @param #boolean enableenable

---
-- Function SetClipChildren
--
-- @function [parent=#Slider] SetClipChildren
-- @param #boolean enableenable

---
-- Function SetSortChildren
--
-- @function [parent=#Slider] SetSortChildren
-- @param #boolean enableenable

---
-- Function SetUseDerivedOpacity
--
-- @function [parent=#Slider] SetUseDerivedOpacity
-- @param #boolean enableenable

---
-- Function SetEnabled
--
-- @function [parent=#Slider] SetEnabled
-- @param #boolean enableenable

---
-- Function SetEditable
--
-- @function [parent=#Slider] SetEditable
-- @param #boolean enableenable

---
-- Function SetFocus
--
-- @function [parent=#Slider] SetFocus
-- @param #boolean enableenable

---
-- Function SetSelected
--
-- @function [parent=#Slider] SetSelected
-- @param #boolean enableenable

---
-- Function SetVisible
--
-- @function [parent=#Slider] SetVisible
-- @param #boolean enableenable

---
-- Function SetFocusMode
--
-- @function [parent=#Slider] SetFocusMode
-- @param FocusMode#FocusMode modemode

---
-- Function SetDragDropMode
--
-- @function [parent=#Slider] SetDragDropMode
-- @param #number modemode

---
-- Function SetStyle
--
-- @function [parent=#Slider] SetStyle
-- @param #string styleNamestyleName
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetStyle
--
-- @function [parent=#Slider] SetStyle
-- @param XMLElement#XMLElement elementelement
-- @return #boolean

---
-- Function SetStyleAuto
--
-- @function [parent=#Slider] SetStyleAuto
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetDefaultStyle
--
-- @function [parent=#Slider] SetDefaultStyle
-- @param XMLFile#XMLFile stylestyle

---
-- Function SetLayout
--
-- @function [parent=#Slider] SetLayout
-- @param LayoutMode#LayoutMode modemode
-- @param #number spacingspacing

---
-- Function SetLayout
--
-- @function [parent=#Slider] SetLayout
-- @param LayoutMode#LayoutMode modemode
-- @param #number spacingspacing
-- @param IntRect#IntRect borderborder

---
-- Function SetLayoutMode
--
-- @function [parent=#Slider] SetLayoutMode
-- @param LayoutMode#LayoutMode modemode

---
-- Function SetLayoutSpacing
--
-- @function [parent=#Slider] SetLayoutSpacing
-- @param #number spacingspacing

---
-- Function SetLayoutBorder
--
-- @function [parent=#Slider] SetLayoutBorder
-- @param IntRect#IntRect borderborder

---
-- Function SetIndent
--
-- @function [parent=#Slider] SetIndent
-- @param #number indentindent

---
-- Function SetIndentSpacing
--
-- @function [parent=#Slider] SetIndentSpacing
-- @param #number indentSpacingindentSpacing

---
-- Function UpdateLayout
--
-- @function [parent=#Slider] UpdateLayout

---
-- Function DisableLayoutUpdate
--
-- @function [parent=#Slider] DisableLayoutUpdate

---
-- Function EnableLayoutUpdate
--
-- @function [parent=#Slider] EnableLayoutUpdate

---
-- Function BringToFront
--
-- @function [parent=#Slider] BringToFront

---
-- Function CreateChild
--
-- @function [parent=#Slider] CreateChild
-- @param #string typetype
-- @param #string namename
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function AddChild
--
-- @function [parent=#Slider] AddChild
-- @param UIElement#UIElement elementelement

---
-- Function InsertChild
--
-- @function [parent=#Slider] InsertChild
-- @param #number indexindex
-- @param UIElement#UIElement elementelement

---
-- Function RemoveChild
--
-- @function [parent=#Slider] RemoveChild
-- @param UIElement#UIElement elementelement
-- @param #number indexindex

---
-- Function RemoveChildAtIndex
--
-- @function [parent=#Slider] RemoveChildAtIndex
-- @param #number indexindex

---
-- Function RemoveAllChildren
--
-- @function [parent=#Slider] RemoveAllChildren

---
-- Function Remove
--
-- @function [parent=#Slider] Remove

---
-- Function FindChild
--
-- @function [parent=#Slider] FindChild
-- @param UIElement#UIElement elementelement
-- @return #number

---
-- Function SetParent
--
-- @function [parent=#Slider] SetParent
-- @param UIElement#UIElement parentparent
-- @param #number indexindex

---
-- Function SetVar
--
-- @function [parent=#Slider] SetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @param Variant#Variant valuevalue

---
-- Function SetInternal
--
-- @function [parent=#Slider] SetInternal
-- @param #boolean enableenable

---
-- Function SetTraversalMode
--
-- @function [parent=#Slider] SetTraversalMode
-- @param TraversalMode#TraversalMode traversalModetraversalMode

---
-- Function SetElementEventSender
--
-- @function [parent=#Slider] SetElementEventSender
-- @param #boolean flagflag

---
-- Function GetName
--
-- @function [parent=#Slider] GetName
-- @return const String#const String

---
-- Function GetPosition
--
-- @function [parent=#Slider] GetPosition
-- @return const IntVector2#const IntVector2

---
-- Function GetSize
--
-- @function [parent=#Slider] GetSize
-- @return const IntVector2#const IntVector2

---
-- Function GetWidth
--
-- @function [parent=#Slider] GetWidth
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#Slider] GetHeight
-- @return #number

---
-- Function GetMinSize
--
-- @function [parent=#Slider] GetMinSize
-- @return const IntVector2#const IntVector2

---
-- Function GetMinWidth
--
-- @function [parent=#Slider] GetMinWidth
-- @return #number

---
-- Function GetMinHeight
--
-- @function [parent=#Slider] GetMinHeight
-- @return #number

---
-- Function GetMaxSize
--
-- @function [parent=#Slider] GetMaxSize
-- @return const IntVector2#const IntVector2

---
-- Function GetMaxWidth
--
-- @function [parent=#Slider] GetMaxWidth
-- @return #number

---
-- Function GetMaxHeight
--
-- @function [parent=#Slider] GetMaxHeight
-- @return #number

---
-- Function IsFixedSize
--
-- @function [parent=#Slider] IsFixedSize
-- @return #boolean

---
-- Function IsFixedWidth
--
-- @function [parent=#Slider] IsFixedWidth
-- @return #boolean

---
-- Function IsFixedHeight
--
-- @function [parent=#Slider] IsFixedHeight
-- @return #boolean

---
-- Function GetChildOffset
--
-- @function [parent=#Slider] GetChildOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetHorizontalAlignment
--
-- @function [parent=#Slider] GetHorizontalAlignment
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetVerticalAlignment
--
-- @function [parent=#Slider] GetVerticalAlignment
-- @return VerticalAlignment#VerticalAlignment

---
-- Function GetClipBorder
--
-- @function [parent=#Slider] GetClipBorder
-- @return const IntRect#const IntRect

---
-- Function GetColor
--
-- @function [parent=#Slider] GetColor
-- @param Corner#Corner cornercorner
-- @return const Color#const Color

---
-- Function GetPriority
--
-- @function [parent=#Slider] GetPriority
-- @return #number

---
-- Function GetOpacity
--
-- @function [parent=#Slider] GetOpacity
-- @return #number

---
-- Function GetDerivedOpacity
--
-- @function [parent=#Slider] GetDerivedOpacity
-- @return #number

---
-- Function GetBringToFront
--
-- @function [parent=#Slider] GetBringToFront
-- @return #boolean

---
-- Function GetBringToBack
--
-- @function [parent=#Slider] GetBringToBack
-- @return #boolean

---
-- Function GetClipChildren
--
-- @function [parent=#Slider] GetClipChildren
-- @return #boolean

---
-- Function GetSortChildren
--
-- @function [parent=#Slider] GetSortChildren
-- @return #boolean

---
-- Function GetUseDerivedOpacity
--
-- @function [parent=#Slider] GetUseDerivedOpacity
-- @return #boolean

---
-- Function HasFocus
--
-- @function [parent=#Slider] HasFocus
-- @return #boolean

---
-- Function IsEnabled
--
-- @function [parent=#Slider] IsEnabled
-- @return #boolean

---
-- Function IsEditable
--
-- @function [parent=#Slider] IsEditable
-- @return #boolean

---
-- Function IsSelected
--
-- @function [parent=#Slider] IsSelected
-- @return #boolean

---
-- Function IsVisible
--
-- @function [parent=#Slider] IsVisible
-- @return #boolean

---
-- Function IsHovering
--
-- @function [parent=#Slider] IsHovering
-- @return #boolean

---
-- Function IsInternal
--
-- @function [parent=#Slider] IsInternal
-- @return #boolean

---
-- Function HasColorGradient
--
-- @function [parent=#Slider] HasColorGradient
-- @return #boolean

---
-- Function GetFocusMode
--
-- @function [parent=#Slider] GetFocusMode
-- @return FocusMode#FocusMode

---
-- Function GetDragDropMode
--
-- @function [parent=#Slider] GetDragDropMode
-- @return #number

---
-- Function GetAppliedStyle
--
-- @function [parent=#Slider] GetAppliedStyle
-- @return const String#const String

---
-- Function GetDefaultStyle
--
-- @function [parent=#Slider] GetDefaultStyle
-- @param #boolean recursiveUprecursiveUp
-- @return XMLFile#XMLFile

---
-- Function GetLayoutMode
--
-- @function [parent=#Slider] GetLayoutMode
-- @return LayoutMode#LayoutMode

---
-- Function GetLayoutSpacing
--
-- @function [parent=#Slider] GetLayoutSpacing
-- @return #number

---
-- Function GetLayoutBorder
--
-- @function [parent=#Slider] GetLayoutBorder
-- @return const IntRect#const IntRect

---
-- Function GetNumChildren
--
-- @function [parent=#Slider] GetNumChildren
-- @param #boolean recursiverecursive
-- @return #number

---
-- Function GetChild
--
-- @function [parent=#Slider] GetChild
-- @param #string namename
-- @param #boolean recursiverecursive
-- @return UIElement#UIElement

---
-- Function GetChild
--
-- @function [parent=#Slider] GetChild
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function GetParent
--
-- @function [parent=#Slider] GetParent
-- @return UIElement#UIElement

---
-- Function GetRoot
--
-- @function [parent=#Slider] GetRoot
-- @return UIElement#UIElement

---
-- Function GetDerivedColor
--
-- @function [parent=#Slider] GetDerivedColor
-- @return const Color#const Color

---
-- Function GetVar
--
-- @function [parent=#Slider] GetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @return const Variant#const Variant

---
-- Function GetVars
--
-- @function [parent=#Slider] GetVars
-- @return const VariantMap#const VariantMap

---
-- Function ScreenToElement
--
-- @function [parent=#Slider] ScreenToElement
-- @param IntVector2#IntVector2 screenPositionscreenPosition
-- @return IntVector2#IntVector2

---
-- Function ElementToScreen
--
-- @function [parent=#Slider] ElementToScreen
-- @param IntVector2#IntVector2 positionposition
-- @return IntVector2#IntVector2

---
-- Function IsInside
--
-- @function [parent=#Slider] IsInside
-- @param IntVector2#IntVector2 positionposition
-- @param #boolean isScreenisScreen
-- @return #boolean

---
-- Function IsInsideCombined
--
-- @function [parent=#Slider] IsInsideCombined
-- @param IntVector2#IntVector2 positionposition
-- @param #boolean isScreenisScreen
-- @return #boolean

---
-- Function GetCombinedScreenRect
--
-- @function [parent=#Slider] GetCombinedScreenRect
-- @return IntRect#IntRect

---
-- Function SortChildren
--
-- @function [parent=#Slider] SortChildren

---
-- Function GetLayoutMinSize
--
-- @function [parent=#Slider] GetLayoutMinSize
-- @return #number

---
-- Function GetIndent
--
-- @function [parent=#Slider] GetIndent
-- @return #number

---
-- Function GetIndentSpacing
--
-- @function [parent=#Slider] GetIndentSpacing
-- @return #number

---
-- Function GetIndentWidth
--
-- @function [parent=#Slider] GetIndentWidth
-- @return #number

---
-- Function SetChildOffset
--
-- @function [parent=#Slider] SetChildOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetHovering
--
-- @function [parent=#Slider] SetHovering
-- @param #boolean enableenable

---
-- Function GetColor
--
-- @function [parent=#Slider] GetColor
-- @return const Color#const Color

---
-- Function GetTraversalMode
--
-- @function [parent=#Slider] GetTraversalMode
-- @return TraversalMode#TraversalMode

---
-- Function IsElementEventSender
--
-- @function [parent=#Slider] IsElementEventSender
-- @return #boolean

---
-- Function GetElementEventSender
--
-- @function [parent=#Slider] GetElementEventSender
-- @return UIElement#UIElement

---
-- Field screenPosition (Read only)
--
-- @field [parent=#Slider] IntVector2#IntVector2 screenPosition

---
-- Field name
--
-- @field [parent=#Slider] #string name

---
-- Field position
--
-- @field [parent=#Slider] IntVector2#IntVector2 position

---
-- Field size
--
-- @field [parent=#Slider] IntVector2#IntVector2 size

---
-- Field width
--
-- @field [parent=#Slider] #number width

---
-- Field height
--
-- @field [parent=#Slider] #number height

---
-- Field minSize
--
-- @field [parent=#Slider] IntVector2#IntVector2 minSize

---
-- Field minWidth
--
-- @field [parent=#Slider] #number minWidth

---
-- Field minHeight
--
-- @field [parent=#Slider] #number minHeight

---
-- Field maxSize
--
-- @field [parent=#Slider] IntVector2#IntVector2 maxSize

---
-- Field maxWidth
--
-- @field [parent=#Slider] #number maxWidth

---
-- Field maxHeight
--
-- @field [parent=#Slider] #number maxHeight

---
-- Field fixedSize (Read only)
--
-- @field [parent=#Slider] #boolean fixedSize

---
-- Field fixedWidth (Read only)
--
-- @field [parent=#Slider] #boolean fixedWidth

---
-- Field fixedHeight (Read only)
--
-- @field [parent=#Slider] #boolean fixedHeight

---
-- Field childOffset
--
-- @field [parent=#Slider] IntVector2#IntVector2 childOffset

---
-- Field horizontalAlignment
--
-- @field [parent=#Slider] HorizontalAlignment#HorizontalAlignment horizontalAlignment

---
-- Field verticalAlignment
--
-- @field [parent=#Slider] VerticalAlignment#VerticalAlignment verticalAlignment

---
-- Field clipBorder
--
-- @field [parent=#Slider] IntRect#IntRect clipBorder

---
-- Field color
--
-- @field [parent=#Slider] Color#Color color

---
-- Field priority
--
-- @field [parent=#Slider] #number priority

---
-- Field opacity
--
-- @field [parent=#Slider] #number opacity

---
-- Field derivedOpacity (Read only)
--
-- @field [parent=#Slider] #number derivedOpacity

---
-- Field bringToFront
--
-- @field [parent=#Slider] #boolean bringToFront

---
-- Field bringToBack
--
-- @field [parent=#Slider] #boolean bringToBack

---
-- Field clipChildren
--
-- @field [parent=#Slider] #boolean clipChildren

---
-- Field sortChildren
--
-- @field [parent=#Slider] #boolean sortChildren

---
-- Field useDerivedOpacity
--
-- @field [parent=#Slider] #boolean useDerivedOpacity

---
-- Field focus
--
-- @field [parent=#Slider] #boolean focus

---
-- Field enabled
--
-- @field [parent=#Slider] #boolean enabled

---
-- Field editable
--
-- @field [parent=#Slider] #boolean editable

---
-- Field selected
--
-- @field [parent=#Slider] #boolean selected

---
-- Field visible
--
-- @field [parent=#Slider] #boolean visible

---
-- Field hovering
--
-- @field [parent=#Slider] #boolean hovering

---
-- Field internal
--
-- @field [parent=#Slider] #boolean internal

---
-- Field colorGradient (Read only)
--
-- @field [parent=#Slider] #boolean colorGradient

---
-- Field focusMode
--
-- @field [parent=#Slider] FocusMode#FocusMode focusMode

---
-- Field dragDropMode
--
-- @field [parent=#Slider] #number dragDropMode

---
-- Field style
--
-- @field [parent=#Slider] #string style

---
-- Field defaultStyle
--
-- @field [parent=#Slider] XMLFile#XMLFile defaultStyle

---
-- Field layoutMode
--
-- @field [parent=#Slider] LayoutMode#LayoutMode layoutMode

---
-- Field layoutSpacing
--
-- @field [parent=#Slider] #number layoutSpacing

---
-- Field layoutBorder
--
-- @field [parent=#Slider] IntRect#IntRect layoutBorder

---
-- Field numChildren (Read only)
--
-- @field [parent=#Slider] #number numChildren

---
-- Field parent
--
-- @field [parent=#Slider] UIElement#UIElement parent

---
-- Field root (Read only)
--
-- @field [parent=#Slider] UIElement#UIElement root

---
-- Field derivedColor (Read only)
--
-- @field [parent=#Slider] Color#Color derivedColor

---
-- Field combinedScreenRect (Read only)
--
-- @field [parent=#Slider] IntRect#IntRect combinedScreenRect

---
-- Field layoutMinSize (Read only)
--
-- @field [parent=#Slider] #number layoutMinSize

---
-- Field indent
--
-- @field [parent=#Slider] #number indent

---
-- Field indentSpacing
--
-- @field [parent=#Slider] #number indentSpacing

---
-- Field indentWidth (Read only)
--
-- @field [parent=#Slider] #number indentWidth

---
-- Field traversalMode
--
-- @field [parent=#Slider] TraversalMode#TraversalMode traversalMode

---
-- Field elementEventSender
--
-- @field [parent=#Slider] #boolean elementEventSender

---
-- Function SetTemporary
--
-- @function [parent=#Slider] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#Slider] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Slider] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Slider] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Slider] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Slider] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Slider] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Slider] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#Slider] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Slider] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Slider] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Slider] #string category


return nil
