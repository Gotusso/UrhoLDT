---
-- Module DebugHud
-- Module DebugHud extends Object
-- Generated on 2014-03-13
--
-- @module DebugHud

---
-- Function SetDefaultStyle
--
-- @function [parent=#DebugHud] SetDefaultStyle
-- @param self Self reference
-- @param XMLFile#XMLFile style style

---
-- Function SetMode
--
-- @function [parent=#DebugHud] SetMode
-- @param self Self reference
-- @param #number mode mode

---
-- Function SetProfilerMaxDepth
--
-- @function [parent=#DebugHud] SetProfilerMaxDepth
-- @param self Self reference
-- @param #number depth depth

---
-- Function SetProfilerInterval
--
-- @function [parent=#DebugHud] SetProfilerInterval
-- @param self Self reference
-- @param #number interval interval

---
-- Function SetUseRendererStats
--
-- @function [parent=#DebugHud] SetUseRendererStats
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Toggle
--
-- @function [parent=#DebugHud] Toggle
-- @param self Self reference
-- @param #number mode mode

---
-- Function ToggleAll
--
-- @function [parent=#DebugHud] ToggleAll
-- @param self Self reference

---
-- Function GetDefaultStyle
--
-- @function [parent=#DebugHud] GetDefaultStyle
-- @param self Self reference
-- @return XMLFile#XMLFile

---
-- Function GetStatsText
--
-- @function [parent=#DebugHud] GetStatsText
-- @param self Self reference
-- @return Text#Text

---
-- Function GetModeText
--
-- @function [parent=#DebugHud] GetModeText
-- @param self Self reference
-- @return Text#Text

---
-- Function GetProfilerText
--
-- @function [parent=#DebugHud] GetProfilerText
-- @param self Self reference
-- @return Text#Text

---
-- Function GetMode
--
-- @function [parent=#DebugHud] GetMode
-- @param self Self reference
-- @return #number

---
-- Function GetProfilerMaxDepth
--
-- @function [parent=#DebugHud] GetProfilerMaxDepth
-- @param self Self reference
-- @return #number

---
-- Function GetProfilerInterval
--
-- @function [parent=#DebugHud] GetProfilerInterval
-- @param self Self reference
-- @return #number

---
-- Function GetUseRendererStats
--
-- @function [parent=#DebugHud] GetUseRendererStats
-- @param self Self reference
-- @return #boolean

---
-- Function SetAppStats
--
-- @function [parent=#DebugHud] SetAppStats
-- @param self Self reference
-- @param #string label label
-- @param Variant#Variant stats stats

---
-- Function SetAppStats
--
-- @function [parent=#DebugHud] SetAppStats
-- @param self Self reference
-- @param #string label label
-- @param #string stats stats

---
-- Function ResetAppStats
--
-- @function [parent=#DebugHud] ResetAppStats
-- @param self Self reference
-- @param #string label label
-- @return #boolean

---
-- Function ClearAppStats
--
-- @function [parent=#DebugHud] ClearAppStats
-- @param self Self reference

---
-- Field defaultStyle
--
-- @field [parent=#DebugHud] XMLFile#XMLFile defaultStyle

---
-- Field statsText (Read only)
--
-- @field [parent=#DebugHud] Text#Text statsText

---
-- Field modeText (Read only)
--
-- @field [parent=#DebugHud] Text#Text modeText

---
-- Field profilerText (Read only)
--
-- @field [parent=#DebugHud] Text#Text profilerText

---
-- Field mode
--
-- @field [parent=#DebugHud] #number mode

---
-- Field profilerMaxDepth
--
-- @field [parent=#DebugHud] #number profilerMaxDepth

---
-- Field profilerInterval
--
-- @field [parent=#DebugHud] #number profilerInterval

---
-- Field useRendererStats
--
-- @field [parent=#DebugHud] #boolean useRendererStats

---
-- Function GetType
--
-- @function [parent=#DebugHud] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#DebugHud] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#DebugHud] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#DebugHud] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#DebugHud] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#DebugHud] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#DebugHud] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#DebugHud] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#DebugHud] #string category


return nil
