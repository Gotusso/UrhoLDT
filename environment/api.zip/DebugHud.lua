---
-- Module DebugHud
-- Module DebugHud extends Object
-- Generated on 2014-05-31
--
-- @module DebugHud

---
-- Function SetDefaultStyle()
-- Set UI elements' style from an XML file.
--
-- @function [parent=#DebugHud] SetDefaultStyle
-- @param self Self reference
-- @param XMLFile#XMLFile style style

---
-- Function SetMode()
-- Set elements to show.
--
-- @function [parent=#DebugHud] SetMode
-- @param self Self reference
-- @param #number mode mode

---
-- Function SetProfilerMaxDepth()
-- Set maximum profiler block depth, default unlimited.
--
-- @function [parent=#DebugHud] SetProfilerMaxDepth
-- @param self Self reference
-- @param #number depth depth

---
-- Function SetProfilerInterval()
-- Set profiler accumulation interval in seconds.
--
-- @function [parent=#DebugHud] SetProfilerInterval
-- @param self Self reference
-- @param #number interval interval

---
-- Function SetUseRendererStats()
-- Set whether to show 3D geometry primitive/batch count only. Default false.
--
-- @function [parent=#DebugHud] SetUseRendererStats
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Toggle()
-- Toggle elements.
--
-- @function [parent=#DebugHud] Toggle
-- @param self Self reference
-- @param #number mode mode

---
-- Function ToggleAll()
-- Toggle all elements.
--
-- @function [parent=#DebugHud] ToggleAll
-- @param self Self reference

---
-- Function GetDefaultStyle()
-- Return the UI style file.
--
-- @function [parent=#DebugHud] GetDefaultStyle
-- @param self Self reference
-- @return XMLFile#XMLFile

---
-- Function GetStatsText()
-- Return rendering stats text.
--
-- @function [parent=#DebugHud] GetStatsText
-- @param self Self reference
-- @return Text#Text

---
-- Function GetModeText()
-- Return rendering mode text.
--
-- @function [parent=#DebugHud] GetModeText
-- @param self Self reference
-- @return Text#Text

---
-- Function GetProfilerText()
-- Return profiler text.
--
-- @function [parent=#DebugHud] GetProfilerText
-- @param self Self reference
-- @return Text#Text

---
-- Function GetMode()
-- Return currently shown elements.
--
-- @function [parent=#DebugHud] GetMode
-- @param self Self reference
-- @return #number

---
-- Function GetProfilerMaxDepth()
-- Return maximum profiler block depth.
--
-- @function [parent=#DebugHud] GetProfilerMaxDepth
-- @param self Self reference
-- @return #number

---
-- Function GetProfilerInterval()
-- Return profiler accumulation interval in seconds
--
-- @function [parent=#DebugHud] GetProfilerInterval
-- @param self Self reference
-- @return #number

---
-- Function GetUseRendererStats()
-- Return whether showing 3D geometry primitive/batch count only.
--
-- @function [parent=#DebugHud] GetUseRendererStats
-- @param self Self reference
-- @return #boolean

---
-- Function SetAppStats()
-- Set application-specific stats.
--
-- @function [parent=#DebugHud] SetAppStats
-- @param self Self reference
-- @param #string label label
-- @param Variant#Variant stats stats

---
-- Function SetAppStats()
-- Set application-specific stats.
--
-- @function [parent=#DebugHud] SetAppStats
-- @param self Self reference
-- @param #string label label
-- @param #string stats stats

---
-- Function ResetAppStats()
-- Reset application-specific stats. Return true if it was erased successfully.
--
-- @function [parent=#DebugHud] ResetAppStats
-- @param self Self reference
-- @param #string label label
-- @return #boolean

---
-- Function ClearAppStats()
-- Clear all application-specific stats.
--
-- @function [parent=#DebugHud] ClearAppStats
-- @param self Self reference

---
-- Field defaultStyle
--
-- @field [parent=#DebugHud] XMLFile#XMLFile defaultStyle

---
-- Field statsText (Read only)
--
-- @field [parent=#DebugHud] Text#Text statsText

---
-- Field modeText (Read only)
--
-- @field [parent=#DebugHud] Text#Text modeText

---
-- Field profilerText (Read only)
--
-- @field [parent=#DebugHud] Text#Text profilerText

---
-- Field mode
--
-- @field [parent=#DebugHud] #number mode

---
-- Field profilerMaxDepth
--
-- @field [parent=#DebugHud] #number profilerMaxDepth

---
-- Field profilerInterval
--
-- @field [parent=#DebugHud] #number profilerInterval

---
-- Field useRendererStats
--
-- @field [parent=#DebugHud] #boolean useRendererStats


return nil
