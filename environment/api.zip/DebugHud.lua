---
-- Module DebugHud
-- extends Object
--
-- @module DebugHud

---
-- Function SetDefaultStyle
--
-- @function [parent=#DebugHud] SetDefaultStyle
-- @param XMLFile#XMLFile stylestyle

---
-- Function SetMode
--
-- @function [parent=#DebugHud] SetMode
-- @param #number modemode

---
-- Function SetProfilerMaxDepth
--
-- @function [parent=#DebugHud] SetProfilerMaxDepth
-- @param #number depthdepth

---
-- Function SetProfilerInterval
--
-- @function [parent=#DebugHud] SetProfilerInterval
-- @param #number intervalinterval

---
-- Function SetUseRendererStats
--
-- @function [parent=#DebugHud] SetUseRendererStats
-- @param #boolean enableenable

---
-- Function Toggle
--
-- @function [parent=#DebugHud] Toggle
-- @param #number modemode

---
-- Function ToggleAll
--
-- @function [parent=#DebugHud] ToggleAll

---
-- Function GetDefaultStyle
--
-- @function [parent=#DebugHud] GetDefaultStyle
-- @return XMLFile#XMLFile

---
-- Function GetStatsText
--
-- @function [parent=#DebugHud] GetStatsText
-- @return Text#Text

---
-- Function GetModeText
--
-- @function [parent=#DebugHud] GetModeText
-- @return Text#Text

---
-- Function GetProfilerText
--
-- @function [parent=#DebugHud] GetProfilerText
-- @return Text#Text

---
-- Function GetMode
--
-- @function [parent=#DebugHud] GetMode
-- @return #number

---
-- Function GetProfilerMaxDepth
--
-- @function [parent=#DebugHud] GetProfilerMaxDepth
-- @return #number

---
-- Function GetProfilerInterval
--
-- @function [parent=#DebugHud] GetProfilerInterval
-- @return #number

---
-- Function GetUseRendererStats
--
-- @function [parent=#DebugHud] GetUseRendererStats
-- @return #boolean

---
-- Function SetAppStats
--
-- @function [parent=#DebugHud] SetAppStats
-- @param #string labellabel
-- @param Variant#Variant statsstats

---
-- Function SetAppStats
--
-- @function [parent=#DebugHud] SetAppStats
-- @param #string labellabel
-- @param #string statsstats

---
-- Function ResetAppStats
--
-- @function [parent=#DebugHud] ResetAppStats
-- @param #string labellabel
-- @return #boolean

---
-- Function ClearAppStats
--
-- @function [parent=#DebugHud] ClearAppStats

---
-- Field defaultStyle
--
-- @field [parent=#DebugHud] XMLFile#XMLFile defaultStyle

---
-- Field statsText (Read only)
--
-- @field [parent=#DebugHud] Text#Text statsText

---
-- Field modeText (Read only)
--
-- @field [parent=#DebugHud] Text#Text modeText

---
-- Field profilerText (Read only)
--
-- @field [parent=#DebugHud] Text#Text profilerText

---
-- Field mode
--
-- @field [parent=#DebugHud] #number mode

---
-- Field profilerMaxDepth
--
-- @field [parent=#DebugHud] #number profilerMaxDepth

---
-- Field profilerInterval
--
-- @field [parent=#DebugHud] #number profilerInterval

---
-- Field useRendererStats
--
-- @field [parent=#DebugHud] #boolean useRendererStats

---
-- Function GetType
--
-- @function [parent=#DebugHud] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#DebugHud] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#DebugHud] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#DebugHud] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#DebugHud] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#DebugHud] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#DebugHud] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#DebugHud] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#DebugHud] #string category


return nil
