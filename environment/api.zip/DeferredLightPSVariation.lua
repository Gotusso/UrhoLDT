---
-- Enumeration DeferredLightPSVariation
--
-- @module DeferredLightPSVariation

---
-- Enumeration value DLPS_NONE
--
-- @field [parent=#DeferredLightPSVariation] #number DLPS_NONE

---
-- Enumeration value DLPS_SPOT
--
-- @field [parent=#DeferredLightPSVariation] #number DLPS_SPOT

---
-- Enumeration value DLPS_POINT
--
-- @field [parent=#DeferredLightPSVariation] #number DLPS_POINT

---
-- Enumeration value DLPS_POINTMASK
--
-- @field [parent=#DeferredLightPSVariation] #number DLPS_POINTMASK

---
-- Enumeration value DLPS_SPEC
--
-- @field [parent=#DeferredLightPSVariation] #number DLPS_SPEC

---
-- Enumeration value DLPS_SPOTSPEC
--
-- @field [parent=#DeferredLightPSVariation] #number DLPS_SPOTSPEC

---
-- Enumeration value DLPS_POINTSPEC
--
-- @field [parent=#DeferredLightPSVariation] #number DLPS_POINTSPEC

---
-- Enumeration value DLPS_POINTMASKSPEC
--
-- @field [parent=#DeferredLightPSVariation] #number DLPS_POINTMASKSPEC

---
-- Enumeration value DLPS_SHADOW
--
-- @field [parent=#DeferredLightPSVariation] #number DLPS_SHADOW

---
-- Enumeration value DLPS_SPOTSHADOW
--
-- @field [parent=#DeferredLightPSVariation] #number DLPS_SPOTSHADOW

---
-- Enumeration value DLPS_POINTSHADOW
--
-- @field [parent=#DeferredLightPSVariation] #number DLPS_POINTSHADOW

---
-- Enumeration value DLPS_POINTMASKSHADOW
--
-- @field [parent=#DeferredLightPSVariation] #number DLPS_POINTMASKSHADOW

---
-- Enumeration value DLPS_SHADOWSPEC
--
-- @field [parent=#DeferredLightPSVariation] #number DLPS_SHADOWSPEC

---
-- Enumeration value DLPS_SPOTSHADOWSPEC
--
-- @field [parent=#DeferredLightPSVariation] #number DLPS_SPOTSHADOWSPEC

---
-- Enumeration value DLPS_POINTSHADOWSPEC
--
-- @field [parent=#DeferredLightPSVariation] #number DLPS_POINTSHADOWSPEC

---
-- Enumeration value DLPS_POINTMASKSHADOWSPEC
--
-- @field [parent=#DeferredLightPSVariation] #number DLPS_POINTMASKSHADOWSPEC

---
-- Enumeration value DLPS_ORTHO
--
-- @field [parent=#DeferredLightPSVariation] #number DLPS_ORTHO

---
-- Enumeration value DLPS_ORTHOSPOT
--
-- @field [parent=#DeferredLightPSVariation] #number DLPS_ORTHOSPOT

---
-- Enumeration value DLPS_ORTHOPOINT
--
-- @field [parent=#DeferredLightPSVariation] #number DLPS_ORTHOPOINT

---
-- Enumeration value DLPS_ORTHOPOINTMASK
--
-- @field [parent=#DeferredLightPSVariation] #number DLPS_ORTHOPOINTMASK

---
-- Enumeration value DLPS_ORTHOSPEC
--
-- @field [parent=#DeferredLightPSVariation] #number DLPS_ORTHOSPEC

---
-- Enumeration value DLPS_ORTHOSPOTSPEC
--
-- @field [parent=#DeferredLightPSVariation] #number DLPS_ORTHOSPOTSPEC

---
-- Enumeration value DLPS_ORTHOPOINTSPEC
--
-- @field [parent=#DeferredLightPSVariation] #number DLPS_ORTHOPOINTSPEC

---
-- Enumeration value DLPS_ORTHOPOINTMASKSPEC
--
-- @field [parent=#DeferredLightPSVariation] #number DLPS_ORTHOPOINTMASKSPEC

---
-- Enumeration value DLPS_ORTHOSHADOW
--
-- @field [parent=#DeferredLightPSVariation] #number DLPS_ORTHOSHADOW

---
-- Enumeration value DLPS_ORTHOSPOTSHADOW
--
-- @field [parent=#DeferredLightPSVariation] #number DLPS_ORTHOSPOTSHADOW

---
-- Enumeration value DLPS_ORTHOPOINTSHADOW
--
-- @field [parent=#DeferredLightPSVariation] #number DLPS_ORTHOPOINTSHADOW

---
-- Enumeration value DLPS_ORTHOPOINTMASKSHADOW
--
-- @field [parent=#DeferredLightPSVariation] #number DLPS_ORTHOPOINTMASKSHADOW

---
-- Enumeration value DLPS_ORTHOSHADOWSPEC
--
-- @field [parent=#DeferredLightPSVariation] #number DLPS_ORTHOSHADOWSPEC

---
-- Enumeration value DLPS_ORTHOSPOTSHADOWSPEC
--
-- @field [parent=#DeferredLightPSVariation] #number DLPS_ORTHOSPOTSHADOWSPEC

---
-- Enumeration value DLPS_ORTHOPOINTSHADOWSPEC
--
-- @field [parent=#DeferredLightPSVariation] #number DLPS_ORTHOPOINTSHADOWSPEC

---
-- Enumeration value DLPS_ORTHOPOINTMASKSHADOWSPEC
--
-- @field [parent=#DeferredLightPSVariation] #number DLPS_ORTHOPOINTMASKSHADOWSPEC

---
-- Enumeration value MAX_DEFERRED_LIGHT_PS_VARIATIONS
--
-- @field [parent=#DeferredLightPSVariation] #number MAX_DEFERRED_LIGHT_PS_VARIATIONS


return nil
