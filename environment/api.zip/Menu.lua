---
-- Module Menu
-- Module Menu extends Button
-- Generated on 2014-05-31
--
-- @module Menu

---
-- Function Menu()
--
-- @function [parent=#Menu] Menu
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#Menu] new
-- @param self Self reference
-- @return Menu#Menu

---
-- Function delete()
--
-- @function [parent=#Menu] delete
-- @param self Self reference

---
-- Function SetPopup()
-- Set popup element to show on selection.
--
-- @function [parent=#Menu] SetPopup
-- @param self Self reference
-- @param UIElement#UIElement element element

---
-- Function SetPopupOffset()
-- Set popup element offset.
--
-- @function [parent=#Menu] SetPopupOffset
-- @param self Self reference
-- @param IntVector2#IntVector2 offset offset

---
-- Function SetPopupOffset()
-- Set popup element offset.
--
-- @function [parent=#Menu] SetPopupOffset
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function ShowPopup()
-- Force the popup to show or hide.
--
-- @function [parent=#Menu] ShowPopup
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetAccelerator()
-- Set accelerator key (set zero key code to disable.)
--
-- @function [parent=#Menu] SetAccelerator
-- @param self Self reference
-- @param #number key key
-- @param #number qualifiers qualifiers

---
-- Function GetPopup()
-- Return popup element.
--
-- @function [parent=#Menu] GetPopup
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetPopupOffset()
-- Return popup element offset.
--
-- @function [parent=#Menu] GetPopupOffset
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetShowPopup()
-- Return whether popup is open.
--
-- @function [parent=#Menu] GetShowPopup
-- @param self Self reference
-- @return #boolean

---
-- Function GetAcceleratorKey()
-- Return accelerator key code, 0 if disabled.
--
-- @function [parent=#Menu] GetAcceleratorKey
-- @param self Self reference
-- @return #number

---
-- Function GetAcceleratorQualifiers()
-- Return accelerator qualifiers.
--
-- @function [parent=#Menu] GetAcceleratorQualifiers
-- @param self Self reference
-- @return #number

---
-- Field popup
--
-- @field [parent=#Menu] UIElement#UIElement popup

---
-- Field popupOffset
--
-- @field [parent=#Menu] IntVector2#IntVector2 popupOffset

---
-- Field showPopup
--
-- @field [parent=#Menu] #boolean showPopup

---
-- Field acceleratorKey (Read only)
--
-- @field [parent=#Menu] #number acceleratorKey

---
-- Field acceleratorQualifiers (Read only)
--
-- @field [parent=#Menu] #number acceleratorQualifiers


return nil
