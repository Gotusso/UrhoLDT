---
-- Module Menu
-- Module Menu extends Button
-- Generated on 2014-03-13
--
-- @module Menu

---
-- Function Menu
--
-- @function [parent=#Menu] Menu
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#Menu] new
-- @param self Self reference
-- @return Menu#Menu

---
-- Function delete
--
-- @function [parent=#Menu] delete
-- @param self Self reference

---
-- Function SetPopup
--
-- @function [parent=#Menu] SetPopup
-- @param self Self reference
-- @param UIElement#UIElement element element

---
-- Function SetPopupOffset
--
-- @function [parent=#Menu] SetPopupOffset
-- @param self Self reference
-- @param IntVector2#IntVector2 offset offset

---
-- Function SetPopupOffset
--
-- @function [parent=#Menu] SetPopupOffset
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function ShowPopup
--
-- @function [parent=#Menu] ShowPopup
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetAccelerator
--
-- @function [parent=#Menu] SetAccelerator
-- @param self Self reference
-- @param #number key key
-- @param #number qualifiers qualifiers

---
-- Function GetPopup
--
-- @function [parent=#Menu] GetPopup
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetPopupOffset
--
-- @function [parent=#Menu] GetPopupOffset
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetShowPopup
--
-- @function [parent=#Menu] GetShowPopup
-- @param self Self reference
-- @return #boolean

---
-- Function GetAcceleratorKey
--
-- @function [parent=#Menu] GetAcceleratorKey
-- @param self Self reference
-- @return #number

---
-- Function GetAcceleratorQualifiers
--
-- @function [parent=#Menu] GetAcceleratorQualifiers
-- @param self Self reference
-- @return #number

---
-- Field popup
--
-- @field [parent=#Menu] UIElement#UIElement popup

---
-- Field popupOffset
--
-- @field [parent=#Menu] IntVector2#IntVector2 popupOffset

---
-- Field showPopup
--
-- @field [parent=#Menu] #boolean showPopup

---
-- Field acceleratorKey (Read only)
--
-- @field [parent=#Menu] #number acceleratorKey

---
-- Field acceleratorQualifiers (Read only)
--
-- @field [parent=#Menu] #number acceleratorQualifiers

---
-- Function Button
--
-- @function [parent=#Menu] Button
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#Menu] new
-- @param self Self reference
-- @return Button#Button

---
-- Function delete
--
-- @function [parent=#Menu] delete
-- @param self Self reference

---
-- Function SetPressedOffset
--
-- @function [parent=#Menu] SetPressedOffset
-- @param self Self reference
-- @param IntVector2#IntVector2 offset offset

---
-- Function SetPressedOffset
--
-- @function [parent=#Menu] SetPressedOffset
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function SetPressedChildOffset
--
-- @function [parent=#Menu] SetPressedChildOffset
-- @param self Self reference
-- @param IntVector2#IntVector2 offset offset

---
-- Function SetPressedChildOffset
--
-- @function [parent=#Menu] SetPressedChildOffset
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function SetRepeat
--
-- @function [parent=#Menu] SetRepeat
-- @param self Self reference
-- @param #number delay delay
-- @param #number rate rate

---
-- Function SetRepeatDelay
--
-- @function [parent=#Menu] SetRepeatDelay
-- @param self Self reference
-- @param #number delay delay

---
-- Function SetRepeatRate
--
-- @function [parent=#Menu] SetRepeatRate
-- @param self Self reference
-- @param #number rate rate

---
-- Function GetPressedOffset
--
-- @function [parent=#Menu] GetPressedOffset
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetPressedChildOffset
--
-- @function [parent=#Menu] GetPressedChildOffset
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetRepeatDelay
--
-- @function [parent=#Menu] GetRepeatDelay
-- @param self Self reference
-- @return #number

---
-- Function GetRepeatRate
--
-- @function [parent=#Menu] GetRepeatRate
-- @param self Self reference
-- @return #number

---
-- Function IsPressed
--
-- @function [parent=#Menu] IsPressed
-- @param self Self reference
-- @return #boolean

---
-- Field pressedOffset
--
-- @field [parent=#Menu] IntVector2#IntVector2 pressedOffset

---
-- Field pressedChildOffset
--
-- @field [parent=#Menu] IntVector2#IntVector2 pressedChildOffset

---
-- Field repeatDelay
--
-- @field [parent=#Menu] #number repeatDelay

---
-- Field repeatRate
--
-- @field [parent=#Menu] #number repeatRate

---
-- Field pressed (Read only)
--
-- @field [parent=#Menu] #boolean pressed

---
-- Function BorderImage
--
-- @function [parent=#Menu] BorderImage
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#Menu] new
-- @param self Self reference
-- @return BorderImage#BorderImage

---
-- Function delete
--
-- @function [parent=#Menu] delete
-- @param self Self reference

---
-- Function SetTexture
--
-- @function [parent=#Menu] SetTexture
-- @param self Self reference
-- @param Texture#Texture texture texture

---
-- Function SetImageRect
--
-- @function [parent=#Menu] SetImageRect
-- @param self Self reference
-- @param IntRect#IntRect rect rect

---
-- Function SetFullImageRect
--
-- @function [parent=#Menu] SetFullImageRect
-- @param self Self reference

---
-- Function SetBorder
--
-- @function [parent=#Menu] SetBorder
-- @param self Self reference
-- @param IntRect#IntRect rect rect

---
-- Function SetHoverOffset
--
-- @function [parent=#Menu] SetHoverOffset
-- @param self Self reference
-- @param IntVector2#IntVector2 offset offset

---
-- Function SetHoverOffset
--
-- @function [parent=#Menu] SetHoverOffset
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function SetBlendMode
--
-- @function [parent=#Menu] SetBlendMode
-- @param self Self reference
-- @param BlendMode#BlendMode mode mode

---
-- Function SetTiled
--
-- @function [parent=#Menu] SetTiled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function GetTexture
--
-- @function [parent=#Menu] GetTexture
-- @param self Self reference
-- @return Texture#Texture

---
-- Function GetImageRect
--
-- @function [parent=#Menu] GetImageRect
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetBorder
--
-- @function [parent=#Menu] GetBorder
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetHoverOffset
--
-- @function [parent=#Menu] GetHoverOffset
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetBlendMode
--
-- @function [parent=#Menu] GetBlendMode
-- @param self Self reference
-- @return BlendMode#BlendMode

---
-- Function IsTiled
--
-- @function [parent=#Menu] IsTiled
-- @param self Self reference
-- @return #boolean

---
-- Field texture
--
-- @field [parent=#Menu] Texture#Texture texture

---
-- Field imageRect
--
-- @field [parent=#Menu] IntRect#IntRect imageRect

---
-- Field border
--
-- @field [parent=#Menu] IntRect#IntRect border

---
-- Field hoverOffset
--
-- @field [parent=#Menu] IntVector2#IntVector2 hoverOffset

---
-- Field blendMode
--
-- @field [parent=#Menu] BlendMode#BlendMode blendMode

---
-- Field tiled
--
-- @field [parent=#Menu] #boolean tiled

---
-- Function UIElement
--
-- @function [parent=#Menu] UIElement
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#Menu] new
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function delete
--
-- @function [parent=#Menu] delete
-- @param self Self reference

---
-- Function GetScreenPosition
--
-- @function [parent=#Menu] GetScreenPosition
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function LoadXML
--
-- @function [parent=#Menu] LoadXML
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#Menu] SaveXML
-- @param self Self reference
-- @param Serializer#Serializer dest dest
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#Menu] LoadXML
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#Menu] SaveXML
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function FilterAttributes
--
-- @function [parent=#Menu] FilterAttributes
-- @param self Self reference
-- @param XMLElement#XMLElement dest dest
-- @return #boolean

---
-- Function SetName
--
-- @function [parent=#Menu] SetName
-- @param self Self reference
-- @param #string name name

---
-- Function SetPosition
--
-- @function [parent=#Menu] SetPosition
-- @param self Self reference
-- @param IntVector2#IntVector2 position position

---
-- Function SetPosition
--
-- @function [parent=#Menu] SetPosition
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function SetSize
--
-- @function [parent=#Menu] SetSize
-- @param self Self reference
-- @param IntVector2#IntVector2 size size

---
-- Function SetSize
--
-- @function [parent=#Menu] SetSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetWidth
--
-- @function [parent=#Menu] SetWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetHeight
--
-- @function [parent=#Menu] SetHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetMinSize
--
-- @function [parent=#Menu] SetMinSize
-- @param self Self reference
-- @param IntVector2#IntVector2 minSize minSize

---
-- Function SetMinSize
--
-- @function [parent=#Menu] SetMinSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetMinWidth
--
-- @function [parent=#Menu] SetMinWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetMinHeight
--
-- @function [parent=#Menu] SetMinHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetMaxSize
--
-- @function [parent=#Menu] SetMaxSize
-- @param self Self reference
-- @param IntVector2#IntVector2 maxSize maxSize

---
-- Function SetMaxSize
--
-- @function [parent=#Menu] SetMaxSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetMaxWidth
--
-- @function [parent=#Menu] SetMaxWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetMaxHeight
--
-- @function [parent=#Menu] SetMaxHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetFixedSize
--
-- @function [parent=#Menu] SetFixedSize
-- @param self Self reference
-- @param IntVector2#IntVector2 size size

---
-- Function SetFixedSize
--
-- @function [parent=#Menu] SetFixedSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetFixedWidth
--
-- @function [parent=#Menu] SetFixedWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetFixedHeight
--
-- @function [parent=#Menu] SetFixedHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetAlignment
--
-- @function [parent=#Menu] SetAlignment
-- @param self Self reference
-- @param HorizontalAlignment#HorizontalAlignment hAlign hAlign
-- @param VerticalAlignment#VerticalAlignment vAlign vAlign

---
-- Function SetHorizontalAlignment
--
-- @function [parent=#Menu] SetHorizontalAlignment
-- @param self Self reference
-- @param HorizontalAlignment#HorizontalAlignment align align

---
-- Function SetVerticalAlignment
--
-- @function [parent=#Menu] SetVerticalAlignment
-- @param self Self reference
-- @param VerticalAlignment#VerticalAlignment align align

---
-- Function SetClipBorder
--
-- @function [parent=#Menu] SetClipBorder
-- @param self Self reference
-- @param IntRect#IntRect rect rect

---
-- Function SetColor
--
-- @function [parent=#Menu] SetColor
-- @param self Self reference
-- @param Color#Color color color

---
-- Function SetColor
--
-- @function [parent=#Menu] SetColor
-- @param self Self reference
-- @param Corner#Corner corner corner
-- @param Color#Color color color

---
-- Function SetPriority
--
-- @function [parent=#Menu] SetPriority
-- @param self Self reference
-- @param #number priority priority

---
-- Function SetOpacity
--
-- @function [parent=#Menu] SetOpacity
-- @param self Self reference
-- @param #number opacity opacity

---
-- Function SetBringToFront
--
-- @function [parent=#Menu] SetBringToFront
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetBringToBack
--
-- @function [parent=#Menu] SetBringToBack
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetClipChildren
--
-- @function [parent=#Menu] SetClipChildren
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetSortChildren
--
-- @function [parent=#Menu] SetSortChildren
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetUseDerivedOpacity
--
-- @function [parent=#Menu] SetUseDerivedOpacity
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetEnabled
--
-- @function [parent=#Menu] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetEditable
--
-- @function [parent=#Menu] SetEditable
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetFocus
--
-- @function [parent=#Menu] SetFocus
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetSelected
--
-- @function [parent=#Menu] SetSelected
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetVisible
--
-- @function [parent=#Menu] SetVisible
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetFocusMode
--
-- @function [parent=#Menu] SetFocusMode
-- @param self Self reference
-- @param FocusMode#FocusMode mode mode

---
-- Function SetDragDropMode
--
-- @function [parent=#Menu] SetDragDropMode
-- @param self Self reference
-- @param #number mode mode

---
-- Function SetStyle
--
-- @function [parent=#Menu] SetStyle
-- @param self Self reference
-- @param #string styleName styleName
-- @param XMLFile#XMLFile file file
-- @return #boolean

---
-- Function SetStyle
--
-- @function [parent=#Menu] SetStyle
-- @param self Self reference
-- @param XMLElement#XMLElement element element
-- @return #boolean

---
-- Function SetStyleAuto
--
-- @function [parent=#Menu] SetStyleAuto
-- @param self Self reference
-- @param XMLFile#XMLFile file file
-- @return #boolean

---
-- Function SetDefaultStyle
--
-- @function [parent=#Menu] SetDefaultStyle
-- @param self Self reference
-- @param XMLFile#XMLFile style style

---
-- Function SetLayout
--
-- @function [parent=#Menu] SetLayout
-- @param self Self reference
-- @param LayoutMode#LayoutMode mode mode
-- @param #number spacing spacing

---
-- Function SetLayout
--
-- @function [parent=#Menu] SetLayout
-- @param self Self reference
-- @param LayoutMode#LayoutMode mode mode
-- @param #number spacing spacing
-- @param IntRect#IntRect border border

---
-- Function SetLayoutMode
--
-- @function [parent=#Menu] SetLayoutMode
-- @param self Self reference
-- @param LayoutMode#LayoutMode mode mode

---
-- Function SetLayoutSpacing
--
-- @function [parent=#Menu] SetLayoutSpacing
-- @param self Self reference
-- @param #number spacing spacing

---
-- Function SetLayoutBorder
--
-- @function [parent=#Menu] SetLayoutBorder
-- @param self Self reference
-- @param IntRect#IntRect border border

---
-- Function SetIndent
--
-- @function [parent=#Menu] SetIndent
-- @param self Self reference
-- @param #number indent indent

---
-- Function SetIndentSpacing
--
-- @function [parent=#Menu] SetIndentSpacing
-- @param self Self reference
-- @param #number indentSpacing indentSpacing

---
-- Function UpdateLayout
--
-- @function [parent=#Menu] UpdateLayout
-- @param self Self reference

---
-- Function DisableLayoutUpdate
--
-- @function [parent=#Menu] DisableLayoutUpdate
-- @param self Self reference

---
-- Function EnableLayoutUpdate
--
-- @function [parent=#Menu] EnableLayoutUpdate
-- @param self Self reference

---
-- Function BringToFront
--
-- @function [parent=#Menu] BringToFront
-- @param self Self reference

---
-- Function CreateChild
--
-- @function [parent=#Menu] CreateChild
-- @param self Self reference
-- @param #string type type
-- @param #string name name
-- @param #number index index
-- @return UIElement#UIElement

---
-- Function AddChild
--
-- @function [parent=#Menu] AddChild
-- @param self Self reference
-- @param UIElement#UIElement element element

---
-- Function InsertChild
--
-- @function [parent=#Menu] InsertChild
-- @param self Self reference
-- @param #number index index
-- @param UIElement#UIElement element element

---
-- Function RemoveChild
--
-- @function [parent=#Menu] RemoveChild
-- @param self Self reference
-- @param UIElement#UIElement element element
-- @param #number index index

---
-- Function RemoveChildAtIndex
--
-- @function [parent=#Menu] RemoveChildAtIndex
-- @param self Self reference
-- @param #number index index

---
-- Function RemoveAllChildren
--
-- @function [parent=#Menu] RemoveAllChildren
-- @param self Self reference

---
-- Function Remove
--
-- @function [parent=#Menu] Remove
-- @param self Self reference

---
-- Function FindChild
--
-- @function [parent=#Menu] FindChild
-- @param self Self reference
-- @param UIElement#UIElement element element
-- @return #number

---
-- Function SetParent
--
-- @function [parent=#Menu] SetParent
-- @param self Self reference
-- @param UIElement#UIElement parent parent
-- @param #number index index

---
-- Function SetVar
--
-- @function [parent=#Menu] SetVar
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash key key
-- @param Variant#Variant value value

---
-- Function SetInternal
--
-- @function [parent=#Menu] SetInternal
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetTraversalMode
--
-- @function [parent=#Menu] SetTraversalMode
-- @param self Self reference
-- @param TraversalMode#TraversalMode traversalMode traversalMode

---
-- Function SetElementEventSender
--
-- @function [parent=#Menu] SetElementEventSender
-- @param self Self reference
-- @param #boolean flag flag

---
-- Function GetName
--
-- @function [parent=#Menu] GetName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetPosition
--
-- @function [parent=#Menu] GetPosition
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetSize
--
-- @function [parent=#Menu] GetSize
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetWidth
--
-- @function [parent=#Menu] GetWidth
-- @param self Self reference
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#Menu] GetHeight
-- @param self Self reference
-- @return #number

---
-- Function GetMinSize
--
-- @function [parent=#Menu] GetMinSize
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetMinWidth
--
-- @function [parent=#Menu] GetMinWidth
-- @param self Self reference
-- @return #number

---
-- Function GetMinHeight
--
-- @function [parent=#Menu] GetMinHeight
-- @param self Self reference
-- @return #number

---
-- Function GetMaxSize
--
-- @function [parent=#Menu] GetMaxSize
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetMaxWidth
--
-- @function [parent=#Menu] GetMaxWidth
-- @param self Self reference
-- @return #number

---
-- Function GetMaxHeight
--
-- @function [parent=#Menu] GetMaxHeight
-- @param self Self reference
-- @return #number

---
-- Function IsFixedSize
--
-- @function [parent=#Menu] IsFixedSize
-- @param self Self reference
-- @return #boolean

---
-- Function IsFixedWidth
--
-- @function [parent=#Menu] IsFixedWidth
-- @param self Self reference
-- @return #boolean

---
-- Function IsFixedHeight
--
-- @function [parent=#Menu] IsFixedHeight
-- @param self Self reference
-- @return #boolean

---
-- Function GetChildOffset
--
-- @function [parent=#Menu] GetChildOffset
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetHorizontalAlignment
--
-- @function [parent=#Menu] GetHorizontalAlignment
-- @param self Self reference
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetVerticalAlignment
--
-- @function [parent=#Menu] GetVerticalAlignment
-- @param self Self reference
-- @return VerticalAlignment#VerticalAlignment

---
-- Function GetClipBorder
--
-- @function [parent=#Menu] GetClipBorder
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetColor
--
-- @function [parent=#Menu] GetColor
-- @param self Self reference
-- @param Corner#Corner corner corner
-- @return const Color#const Color

---
-- Function GetPriority
--
-- @function [parent=#Menu] GetPriority
-- @param self Self reference
-- @return #number

---
-- Function GetOpacity
--
-- @function [parent=#Menu] GetOpacity
-- @param self Self reference
-- @return #number

---
-- Function GetDerivedOpacity
--
-- @function [parent=#Menu] GetDerivedOpacity
-- @param self Self reference
-- @return #number

---
-- Function GetBringToFront
--
-- @function [parent=#Menu] GetBringToFront
-- @param self Self reference
-- @return #boolean

---
-- Function GetBringToBack
--
-- @function [parent=#Menu] GetBringToBack
-- @param self Self reference
-- @return #boolean

---
-- Function GetClipChildren
--
-- @function [parent=#Menu] GetClipChildren
-- @param self Self reference
-- @return #boolean

---
-- Function GetSortChildren
--
-- @function [parent=#Menu] GetSortChildren
-- @param self Self reference
-- @return #boolean

---
-- Function GetUseDerivedOpacity
--
-- @function [parent=#Menu] GetUseDerivedOpacity
-- @param self Self reference
-- @return #boolean

---
-- Function HasFocus
--
-- @function [parent=#Menu] HasFocus
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabled
--
-- @function [parent=#Menu] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEditable
--
-- @function [parent=#Menu] IsEditable
-- @param self Self reference
-- @return #boolean

---
-- Function IsSelected
--
-- @function [parent=#Menu] IsSelected
-- @param self Self reference
-- @return #boolean

---
-- Function IsVisible
--
-- @function [parent=#Menu] IsVisible
-- @param self Self reference
-- @return #boolean

---
-- Function IsHovering
--
-- @function [parent=#Menu] IsHovering
-- @param self Self reference
-- @return #boolean

---
-- Function IsInternal
--
-- @function [parent=#Menu] IsInternal
-- @param self Self reference
-- @return #boolean

---
-- Function HasColorGradient
--
-- @function [parent=#Menu] HasColorGradient
-- @param self Self reference
-- @return #boolean

---
-- Function GetFocusMode
--
-- @function [parent=#Menu] GetFocusMode
-- @param self Self reference
-- @return FocusMode#FocusMode

---
-- Function GetDragDropMode
--
-- @function [parent=#Menu] GetDragDropMode
-- @param self Self reference
-- @return #number

---
-- Function GetAppliedStyle
--
-- @function [parent=#Menu] GetAppliedStyle
-- @param self Self reference
-- @return const String#const String

---
-- Function GetDefaultStyle
--
-- @function [parent=#Menu] GetDefaultStyle
-- @param self Self reference
-- @param #boolean recursiveUp recursiveUp
-- @return XMLFile#XMLFile

---
-- Function GetLayoutMode
--
-- @function [parent=#Menu] GetLayoutMode
-- @param self Self reference
-- @return LayoutMode#LayoutMode

---
-- Function GetLayoutSpacing
--
-- @function [parent=#Menu] GetLayoutSpacing
-- @param self Self reference
-- @return #number

---
-- Function GetLayoutBorder
--
-- @function [parent=#Menu] GetLayoutBorder
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetNumChildren
--
-- @function [parent=#Menu] GetNumChildren
-- @param self Self reference
-- @param #boolean recursive recursive
-- @return #number

---
-- Function GetChild
--
-- @function [parent=#Menu] GetChild
-- @param self Self reference
-- @param #string name name
-- @param #boolean recursive recursive
-- @return UIElement#UIElement

---
-- Function GetChild
--
-- @function [parent=#Menu] GetChild
-- @param self Self reference
-- @param #number index index
-- @return UIElement#UIElement

---
-- Function GetParent
--
-- @function [parent=#Menu] GetParent
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetRoot
--
-- @function [parent=#Menu] GetRoot
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetDerivedColor
--
-- @function [parent=#Menu] GetDerivedColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetVar
--
-- @function [parent=#Menu] GetVar
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash key key
-- @return const Variant#const Variant

---
-- Function GetVars
--
-- @function [parent=#Menu] GetVars
-- @param self Self reference
-- @return const VariantMap#const VariantMap

---
-- Function ScreenToElement
--
-- @function [parent=#Menu] ScreenToElement
-- @param self Self reference
-- @param IntVector2#IntVector2 screenPosition screenPosition
-- @return IntVector2#IntVector2

---
-- Function ElementToScreen
--
-- @function [parent=#Menu] ElementToScreen
-- @param self Self reference
-- @param IntVector2#IntVector2 position position
-- @return IntVector2#IntVector2

---
-- Function IsInside
--
-- @function [parent=#Menu] IsInside
-- @param self Self reference
-- @param IntVector2#IntVector2 position position
-- @param #boolean isScreen isScreen
-- @return #boolean

---
-- Function IsInsideCombined
--
-- @function [parent=#Menu] IsInsideCombined
-- @param self Self reference
-- @param IntVector2#IntVector2 position position
-- @param #boolean isScreen isScreen
-- @return #boolean

---
-- Function GetCombinedScreenRect
--
-- @function [parent=#Menu] GetCombinedScreenRect
-- @param self Self reference
-- @return IntRect#IntRect

---
-- Function SortChildren
--
-- @function [parent=#Menu] SortChildren
-- @param self Self reference

---
-- Function GetLayoutMinSize
--
-- @function [parent=#Menu] GetLayoutMinSize
-- @param self Self reference
-- @return #number

---
-- Function GetIndent
--
-- @function [parent=#Menu] GetIndent
-- @param self Self reference
-- @return #number

---
-- Function GetIndentSpacing
--
-- @function [parent=#Menu] GetIndentSpacing
-- @param self Self reference
-- @return #number

---
-- Function GetIndentWidth
--
-- @function [parent=#Menu] GetIndentWidth
-- @param self Self reference
-- @return #number

---
-- Function SetChildOffset
--
-- @function [parent=#Menu] SetChildOffset
-- @param self Self reference
-- @param IntVector2#IntVector2 offset offset

---
-- Function SetHovering
--
-- @function [parent=#Menu] SetHovering
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function GetColor
--
-- @function [parent=#Menu] GetColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetTraversalMode
--
-- @function [parent=#Menu] GetTraversalMode
-- @param self Self reference
-- @return TraversalMode#TraversalMode

---
-- Function IsElementEventSender
--
-- @function [parent=#Menu] IsElementEventSender
-- @param self Self reference
-- @return #boolean

---
-- Function GetElementEventSender
--
-- @function [parent=#Menu] GetElementEventSender
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Field screenPosition (Read only)
--
-- @field [parent=#Menu] IntVector2#IntVector2 screenPosition

---
-- Field name
--
-- @field [parent=#Menu] #string name

---
-- Field position
--
-- @field [parent=#Menu] IntVector2#IntVector2 position

---
-- Field size
--
-- @field [parent=#Menu] IntVector2#IntVector2 size

---
-- Field width
--
-- @field [parent=#Menu] #number width

---
-- Field height
--
-- @field [parent=#Menu] #number height

---
-- Field minSize
--
-- @field [parent=#Menu] IntVector2#IntVector2 minSize

---
-- Field minWidth
--
-- @field [parent=#Menu] #number minWidth

---
-- Field minHeight
--
-- @field [parent=#Menu] #number minHeight

---
-- Field maxSize
--
-- @field [parent=#Menu] IntVector2#IntVector2 maxSize

---
-- Field maxWidth
--
-- @field [parent=#Menu] #number maxWidth

---
-- Field maxHeight
--
-- @field [parent=#Menu] #number maxHeight

---
-- Field fixedSize (Read only)
--
-- @field [parent=#Menu] #boolean fixedSize

---
-- Field fixedWidth (Read only)
--
-- @field [parent=#Menu] #boolean fixedWidth

---
-- Field fixedHeight (Read only)
--
-- @field [parent=#Menu] #boolean fixedHeight

---
-- Field childOffset
--
-- @field [parent=#Menu] IntVector2#IntVector2 childOffset

---
-- Field horizontalAlignment
--
-- @field [parent=#Menu] HorizontalAlignment#HorizontalAlignment horizontalAlignment

---
-- Field verticalAlignment
--
-- @field [parent=#Menu] VerticalAlignment#VerticalAlignment verticalAlignment

---
-- Field clipBorder
--
-- @field [parent=#Menu] IntRect#IntRect clipBorder

---
-- Field color
--
-- @field [parent=#Menu] Color#Color color

---
-- Field priority
--
-- @field [parent=#Menu] #number priority

---
-- Field opacity
--
-- @field [parent=#Menu] #number opacity

---
-- Field derivedOpacity (Read only)
--
-- @field [parent=#Menu] #number derivedOpacity

---
-- Field bringToFront
--
-- @field [parent=#Menu] #boolean bringToFront

---
-- Field bringToBack
--
-- @field [parent=#Menu] #boolean bringToBack

---
-- Field clipChildren
--
-- @field [parent=#Menu] #boolean clipChildren

---
-- Field sortChildren
--
-- @field [parent=#Menu] #boolean sortChildren

---
-- Field useDerivedOpacity
--
-- @field [parent=#Menu] #boolean useDerivedOpacity

---
-- Field focus
--
-- @field [parent=#Menu] #boolean focus

---
-- Field enabled
--
-- @field [parent=#Menu] #boolean enabled

---
-- Field editable
--
-- @field [parent=#Menu] #boolean editable

---
-- Field selected
--
-- @field [parent=#Menu] #boolean selected

---
-- Field visible
--
-- @field [parent=#Menu] #boolean visible

---
-- Field hovering
--
-- @field [parent=#Menu] #boolean hovering

---
-- Field internal
--
-- @field [parent=#Menu] #boolean internal

---
-- Field colorGradient (Read only)
--
-- @field [parent=#Menu] #boolean colorGradient

---
-- Field focusMode
--
-- @field [parent=#Menu] FocusMode#FocusMode focusMode

---
-- Field dragDropMode
--
-- @field [parent=#Menu] #number dragDropMode

---
-- Field style
--
-- @field [parent=#Menu] #string style

---
-- Field defaultStyle
--
-- @field [parent=#Menu] XMLFile#XMLFile defaultStyle

---
-- Field layoutMode
--
-- @field [parent=#Menu] LayoutMode#LayoutMode layoutMode

---
-- Field layoutSpacing
--
-- @field [parent=#Menu] #number layoutSpacing

---
-- Field layoutBorder
--
-- @field [parent=#Menu] IntRect#IntRect layoutBorder

---
-- Field numChildren (Read only)
--
-- @field [parent=#Menu] #number numChildren

---
-- Field parent
--
-- @field [parent=#Menu] UIElement#UIElement parent

---
-- Field root (Read only)
--
-- @field [parent=#Menu] UIElement#UIElement root

---
-- Field derivedColor (Read only)
--
-- @field [parent=#Menu] Color#Color derivedColor

---
-- Field combinedScreenRect (Read only)
--
-- @field [parent=#Menu] IntRect#IntRect combinedScreenRect

---
-- Field layoutMinSize (Read only)
--
-- @field [parent=#Menu] #number layoutMinSize

---
-- Field indent
--
-- @field [parent=#Menu] #number indent

---
-- Field indentSpacing
--
-- @field [parent=#Menu] #number indentSpacing

---
-- Field indentWidth (Read only)
--
-- @field [parent=#Menu] #number indentWidth

---
-- Field traversalMode
--
-- @field [parent=#Menu] TraversalMode#TraversalMode traversalMode

---
-- Field elementEventSender
--
-- @field [parent=#Menu] #boolean elementEventSender

---
-- Function SetTemporary
--
-- @function [parent=#Menu] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#Menu] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Menu] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Menu] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Menu] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Menu] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Menu] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Menu] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#Menu] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Menu] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Menu] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Menu] #string category


return nil
