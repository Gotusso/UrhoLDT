---
-- Module Menu
-- extends Button
--
-- @module Menu

---
-- Function Menu
--
-- @function [parent=#Menu] Menu

---
-- Function new
--
-- @function [parent=#Menu] new
-- @return Menu#Menu

---
-- Function delete
--
-- @function [parent=#Menu] delete

---
-- Function SetPopup
--
-- @function [parent=#Menu] SetPopup
-- @param UIElement#UIElement elementelement

---
-- Function SetPopupOffset
--
-- @function [parent=#Menu] SetPopupOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetPopupOffset
--
-- @function [parent=#Menu] SetPopupOffset
-- @param #number xx
-- @param #number yy

---
-- Function ShowPopup
--
-- @function [parent=#Menu] ShowPopup
-- @param #boolean enableenable

---
-- Function SetAccelerator
--
-- @function [parent=#Menu] SetAccelerator
-- @param #number keykey
-- @param #number qualifiersqualifiers

---
-- Function GetPopup
--
-- @function [parent=#Menu] GetPopup
-- @return UIElement#UIElement

---
-- Function GetPopupOffset
--
-- @function [parent=#Menu] GetPopupOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetShowPopup
--
-- @function [parent=#Menu] GetShowPopup
-- @return #boolean

---
-- Function GetAcceleratorKey
--
-- @function [parent=#Menu] GetAcceleratorKey
-- @return #number

---
-- Function GetAcceleratorQualifiers
--
-- @function [parent=#Menu] GetAcceleratorQualifiers
-- @return #number

---
-- Field popup
--
-- @field [parent=#Menu] UIElement#UIElement popup

---
-- Field popupOffset
--
-- @field [parent=#Menu] IntVector2#IntVector2 popupOffset

---
-- Field showPopup
--
-- @field [parent=#Menu] #boolean showPopup

---
-- Field acceleratorKey (Read only)
--
-- @field [parent=#Menu] #number acceleratorKey

---
-- Field acceleratorQualifiers (Read only)
--
-- @field [parent=#Menu] #number acceleratorQualifiers

---
-- Function Button
--
-- @function [parent=#Menu] Button

---
-- Function new
--
-- @function [parent=#Menu] new
-- @return Button#Button

---
-- Function delete
--
-- @function [parent=#Menu] delete

---
-- Function SetPressedOffset
--
-- @function [parent=#Menu] SetPressedOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetPressedOffset
--
-- @function [parent=#Menu] SetPressedOffset
-- @param #number xx
-- @param #number yy

---
-- Function SetPressedChildOffset
--
-- @function [parent=#Menu] SetPressedChildOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetPressedChildOffset
--
-- @function [parent=#Menu] SetPressedChildOffset
-- @param #number xx
-- @param #number yy

---
-- Function SetRepeat
--
-- @function [parent=#Menu] SetRepeat
-- @param #number delaydelay
-- @param #number raterate

---
-- Function SetRepeatDelay
--
-- @function [parent=#Menu] SetRepeatDelay
-- @param #number delaydelay

---
-- Function SetRepeatRate
--
-- @function [parent=#Menu] SetRepeatRate
-- @param #number raterate

---
-- Function GetPressedOffset
--
-- @function [parent=#Menu] GetPressedOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetPressedChildOffset
--
-- @function [parent=#Menu] GetPressedChildOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetRepeatDelay
--
-- @function [parent=#Menu] GetRepeatDelay
-- @return #number

---
-- Function GetRepeatRate
--
-- @function [parent=#Menu] GetRepeatRate
-- @return #number

---
-- Function IsPressed
--
-- @function [parent=#Menu] IsPressed
-- @return #boolean

---
-- Field pressedOffset
--
-- @field [parent=#Menu] IntVector2#IntVector2 pressedOffset

---
-- Field pressedChildOffset
--
-- @field [parent=#Menu] IntVector2#IntVector2 pressedChildOffset

---
-- Field repeatDelay
--
-- @field [parent=#Menu] #number repeatDelay

---
-- Field repeatRate
--
-- @field [parent=#Menu] #number repeatRate

---
-- Field pressed (Read only)
--
-- @field [parent=#Menu] #boolean pressed

---
-- Function BorderImage
--
-- @function [parent=#Menu] BorderImage

---
-- Function new
--
-- @function [parent=#Menu] new
-- @return BorderImage#BorderImage

---
-- Function delete
--
-- @function [parent=#Menu] delete

---
-- Function SetTexture
--
-- @function [parent=#Menu] SetTexture
-- @param Texture#Texture texturetexture

---
-- Function SetImageRect
--
-- @function [parent=#Menu] SetImageRect
-- @param IntRect#IntRect rectrect

---
-- Function SetFullImageRect
--
-- @function [parent=#Menu] SetFullImageRect

---
-- Function SetBorder
--
-- @function [parent=#Menu] SetBorder
-- @param IntRect#IntRect rectrect

---
-- Function SetHoverOffset
--
-- @function [parent=#Menu] SetHoverOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetHoverOffset
--
-- @function [parent=#Menu] SetHoverOffset
-- @param #number xx
-- @param #number yy

---
-- Function SetBlendMode
--
-- @function [parent=#Menu] SetBlendMode
-- @param BlendMode#BlendMode modemode

---
-- Function SetTiled
--
-- @function [parent=#Menu] SetTiled
-- @param #boolean enableenable

---
-- Function GetTexture
--
-- @function [parent=#Menu] GetTexture
-- @return Texture#Texture

---
-- Function GetImageRect
--
-- @function [parent=#Menu] GetImageRect
-- @return const IntRect#const IntRect

---
-- Function GetBorder
--
-- @function [parent=#Menu] GetBorder
-- @return const IntRect#const IntRect

---
-- Function GetHoverOffset
--
-- @function [parent=#Menu] GetHoverOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetBlendMode
--
-- @function [parent=#Menu] GetBlendMode
-- @return BlendMode#BlendMode

---
-- Function IsTiled
--
-- @function [parent=#Menu] IsTiled
-- @return #boolean

---
-- Field texture
--
-- @field [parent=#Menu] Texture#Texture texture

---
-- Field imageRect
--
-- @field [parent=#Menu] IntRect#IntRect imageRect

---
-- Field border
--
-- @field [parent=#Menu] IntRect#IntRect border

---
-- Field hoverOffset
--
-- @field [parent=#Menu] IntVector2#IntVector2 hoverOffset

---
-- Field blendMode
--
-- @field [parent=#Menu] BlendMode#BlendMode blendMode

---
-- Field tiled
--
-- @field [parent=#Menu] #boolean tiled

---
-- Function UIElement
--
-- @function [parent=#Menu] UIElement

---
-- Function new
--
-- @function [parent=#Menu] new
-- @return UIElement#UIElement

---
-- Function delete
--
-- @function [parent=#Menu] delete

---
-- Function GetScreenPosition
--
-- @function [parent=#Menu] GetScreenPosition
-- @return const IntVector2#const IntVector2

---
-- Function LoadXML
--
-- @function [parent=#Menu] LoadXML
-- @param Deserializer#Deserializer sourcesource
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#Menu] SaveXML
-- @param Serializer#Serializer destdest
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#Menu] LoadXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#Menu] SaveXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function FilterAttributes
--
-- @function [parent=#Menu] FilterAttributes
-- @param XMLElement#XMLElement destdest
-- @return #boolean

---
-- Function SetName
--
-- @function [parent=#Menu] SetName
-- @param #string namename

---
-- Function SetPosition
--
-- @function [parent=#Menu] SetPosition
-- @param IntVector2#IntVector2 positionposition

---
-- Function SetPosition
--
-- @function [parent=#Menu] SetPosition
-- @param #number xx
-- @param #number yy

---
-- Function SetSize
--
-- @function [parent=#Menu] SetSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function SetSize
--
-- @function [parent=#Menu] SetSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetWidth
--
-- @function [parent=#Menu] SetWidth
-- @param #number widthwidth

---
-- Function SetHeight
--
-- @function [parent=#Menu] SetHeight
-- @param #number heightheight

---
-- Function SetMinSize
--
-- @function [parent=#Menu] SetMinSize
-- @param IntVector2#IntVector2 minSizeminSize

---
-- Function SetMinSize
--
-- @function [parent=#Menu] SetMinSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetMinWidth
--
-- @function [parent=#Menu] SetMinWidth
-- @param #number widthwidth

---
-- Function SetMinHeight
--
-- @function [parent=#Menu] SetMinHeight
-- @param #number heightheight

---
-- Function SetMaxSize
--
-- @function [parent=#Menu] SetMaxSize
-- @param IntVector2#IntVector2 maxSizemaxSize

---
-- Function SetMaxSize
--
-- @function [parent=#Menu] SetMaxSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetMaxWidth
--
-- @function [parent=#Menu] SetMaxWidth
-- @param #number widthwidth

---
-- Function SetMaxHeight
--
-- @function [parent=#Menu] SetMaxHeight
-- @param #number heightheight

---
-- Function SetFixedSize
--
-- @function [parent=#Menu] SetFixedSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function SetFixedSize
--
-- @function [parent=#Menu] SetFixedSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetFixedWidth
--
-- @function [parent=#Menu] SetFixedWidth
-- @param #number widthwidth

---
-- Function SetFixedHeight
--
-- @function [parent=#Menu] SetFixedHeight
-- @param #number heightheight

---
-- Function SetAlignment
--
-- @function [parent=#Menu] SetAlignment
-- @param HorizontalAlignment#HorizontalAlignment hAlignhAlign
-- @param VerticalAlignment#VerticalAlignment vAlignvAlign

---
-- Function SetHorizontalAlignment
--
-- @function [parent=#Menu] SetHorizontalAlignment
-- @param HorizontalAlignment#HorizontalAlignment alignalign

---
-- Function SetVerticalAlignment
--
-- @function [parent=#Menu] SetVerticalAlignment
-- @param VerticalAlignment#VerticalAlignment alignalign

---
-- Function SetClipBorder
--
-- @function [parent=#Menu] SetClipBorder
-- @param IntRect#IntRect rectrect

---
-- Function SetColor
--
-- @function [parent=#Menu] SetColor
-- @param Color#Color colorcolor

---
-- Function SetColor
--
-- @function [parent=#Menu] SetColor
-- @param Corner#Corner cornercorner
-- @param Color#Color colorcolor

---
-- Function SetPriority
--
-- @function [parent=#Menu] SetPriority
-- @param #number prioritypriority

---
-- Function SetOpacity
--
-- @function [parent=#Menu] SetOpacity
-- @param #number opacityopacity

---
-- Function SetBringToFront
--
-- @function [parent=#Menu] SetBringToFront
-- @param #boolean enableenable

---
-- Function SetBringToBack
--
-- @function [parent=#Menu] SetBringToBack
-- @param #boolean enableenable

---
-- Function SetClipChildren
--
-- @function [parent=#Menu] SetClipChildren
-- @param #boolean enableenable

---
-- Function SetSortChildren
--
-- @function [parent=#Menu] SetSortChildren
-- @param #boolean enableenable

---
-- Function SetUseDerivedOpacity
--
-- @function [parent=#Menu] SetUseDerivedOpacity
-- @param #boolean enableenable

---
-- Function SetEnabled
--
-- @function [parent=#Menu] SetEnabled
-- @param #boolean enableenable

---
-- Function SetEditable
--
-- @function [parent=#Menu] SetEditable
-- @param #boolean enableenable

---
-- Function SetFocus
--
-- @function [parent=#Menu] SetFocus
-- @param #boolean enableenable

---
-- Function SetSelected
--
-- @function [parent=#Menu] SetSelected
-- @param #boolean enableenable

---
-- Function SetVisible
--
-- @function [parent=#Menu] SetVisible
-- @param #boolean enableenable

---
-- Function SetFocusMode
--
-- @function [parent=#Menu] SetFocusMode
-- @param FocusMode#FocusMode modemode

---
-- Function SetDragDropMode
--
-- @function [parent=#Menu] SetDragDropMode
-- @param #number modemode

---
-- Function SetStyle
--
-- @function [parent=#Menu] SetStyle
-- @param #string styleNamestyleName
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetStyle
--
-- @function [parent=#Menu] SetStyle
-- @param XMLElement#XMLElement elementelement
-- @return #boolean

---
-- Function SetStyleAuto
--
-- @function [parent=#Menu] SetStyleAuto
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetDefaultStyle
--
-- @function [parent=#Menu] SetDefaultStyle
-- @param XMLFile#XMLFile stylestyle

---
-- Function SetLayout
--
-- @function [parent=#Menu] SetLayout
-- @param LayoutMode#LayoutMode modemode
-- @param #number spacingspacing

---
-- Function SetLayout
--
-- @function [parent=#Menu] SetLayout
-- @param LayoutMode#LayoutMode modemode
-- @param #number spacingspacing
-- @param IntRect#IntRect borderborder

---
-- Function SetLayoutMode
--
-- @function [parent=#Menu] SetLayoutMode
-- @param LayoutMode#LayoutMode modemode

---
-- Function SetLayoutSpacing
--
-- @function [parent=#Menu] SetLayoutSpacing
-- @param #number spacingspacing

---
-- Function SetLayoutBorder
--
-- @function [parent=#Menu] SetLayoutBorder
-- @param IntRect#IntRect borderborder

---
-- Function SetIndent
--
-- @function [parent=#Menu] SetIndent
-- @param #number indentindent

---
-- Function SetIndentSpacing
--
-- @function [parent=#Menu] SetIndentSpacing
-- @param #number indentSpacingindentSpacing

---
-- Function UpdateLayout
--
-- @function [parent=#Menu] UpdateLayout

---
-- Function DisableLayoutUpdate
--
-- @function [parent=#Menu] DisableLayoutUpdate

---
-- Function EnableLayoutUpdate
--
-- @function [parent=#Menu] EnableLayoutUpdate

---
-- Function BringToFront
--
-- @function [parent=#Menu] BringToFront

---
-- Function CreateChild
--
-- @function [parent=#Menu] CreateChild
-- @param #string typetype
-- @param #string namename
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function AddChild
--
-- @function [parent=#Menu] AddChild
-- @param UIElement#UIElement elementelement

---
-- Function InsertChild
--
-- @function [parent=#Menu] InsertChild
-- @param #number indexindex
-- @param UIElement#UIElement elementelement

---
-- Function RemoveChild
--
-- @function [parent=#Menu] RemoveChild
-- @param UIElement#UIElement elementelement
-- @param #number indexindex

---
-- Function RemoveChildAtIndex
--
-- @function [parent=#Menu] RemoveChildAtIndex
-- @param #number indexindex

---
-- Function RemoveAllChildren
--
-- @function [parent=#Menu] RemoveAllChildren

---
-- Function Remove
--
-- @function [parent=#Menu] Remove

---
-- Function FindChild
--
-- @function [parent=#Menu] FindChild
-- @param UIElement#UIElement elementelement
-- @return #number

---
-- Function SetParent
--
-- @function [parent=#Menu] SetParent
-- @param UIElement#UIElement parentparent
-- @param #number indexindex

---
-- Function SetVar
--
-- @function [parent=#Menu] SetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @param Variant#Variant valuevalue

---
-- Function SetInternal
--
-- @function [parent=#Menu] SetInternal
-- @param #boolean enableenable

---
-- Function SetTraversalMode
--
-- @function [parent=#Menu] SetTraversalMode
-- @param TraversalMode#TraversalMode traversalModetraversalMode

---
-- Function SetElementEventSender
--
-- @function [parent=#Menu] SetElementEventSender
-- @param #boolean flagflag

---
-- Function GetName
--
-- @function [parent=#Menu] GetName
-- @return const String#const String

---
-- Function GetPosition
--
-- @function [parent=#Menu] GetPosition
-- @return const IntVector2#const IntVector2

---
-- Function GetSize
--
-- @function [parent=#Menu] GetSize
-- @return const IntVector2#const IntVector2

---
-- Function GetWidth
--
-- @function [parent=#Menu] GetWidth
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#Menu] GetHeight
-- @return #number

---
-- Function GetMinSize
--
-- @function [parent=#Menu] GetMinSize
-- @return const IntVector2#const IntVector2

---
-- Function GetMinWidth
--
-- @function [parent=#Menu] GetMinWidth
-- @return #number

---
-- Function GetMinHeight
--
-- @function [parent=#Menu] GetMinHeight
-- @return #number

---
-- Function GetMaxSize
--
-- @function [parent=#Menu] GetMaxSize
-- @return const IntVector2#const IntVector2

---
-- Function GetMaxWidth
--
-- @function [parent=#Menu] GetMaxWidth
-- @return #number

---
-- Function GetMaxHeight
--
-- @function [parent=#Menu] GetMaxHeight
-- @return #number

---
-- Function IsFixedSize
--
-- @function [parent=#Menu] IsFixedSize
-- @return #boolean

---
-- Function IsFixedWidth
--
-- @function [parent=#Menu] IsFixedWidth
-- @return #boolean

---
-- Function IsFixedHeight
--
-- @function [parent=#Menu] IsFixedHeight
-- @return #boolean

---
-- Function GetChildOffset
--
-- @function [parent=#Menu] GetChildOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetHorizontalAlignment
--
-- @function [parent=#Menu] GetHorizontalAlignment
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetVerticalAlignment
--
-- @function [parent=#Menu] GetVerticalAlignment
-- @return VerticalAlignment#VerticalAlignment

---
-- Function GetClipBorder
--
-- @function [parent=#Menu] GetClipBorder
-- @return const IntRect#const IntRect

---
-- Function GetColor
--
-- @function [parent=#Menu] GetColor
-- @param Corner#Corner cornercorner
-- @return const Color#const Color

---
-- Function GetPriority
--
-- @function [parent=#Menu] GetPriority
-- @return #number

---
-- Function GetOpacity
--
-- @function [parent=#Menu] GetOpacity
-- @return #number

---
-- Function GetDerivedOpacity
--
-- @function [parent=#Menu] GetDerivedOpacity
-- @return #number

---
-- Function GetBringToFront
--
-- @function [parent=#Menu] GetBringToFront
-- @return #boolean

---
-- Function GetBringToBack
--
-- @function [parent=#Menu] GetBringToBack
-- @return #boolean

---
-- Function GetClipChildren
--
-- @function [parent=#Menu] GetClipChildren
-- @return #boolean

---
-- Function GetSortChildren
--
-- @function [parent=#Menu] GetSortChildren
-- @return #boolean

---
-- Function GetUseDerivedOpacity
--
-- @function [parent=#Menu] GetUseDerivedOpacity
-- @return #boolean

---
-- Function HasFocus
--
-- @function [parent=#Menu] HasFocus
-- @return #boolean

---
-- Function IsEnabled
--
-- @function [parent=#Menu] IsEnabled
-- @return #boolean

---
-- Function IsEditable
--
-- @function [parent=#Menu] IsEditable
-- @return #boolean

---
-- Function IsSelected
--
-- @function [parent=#Menu] IsSelected
-- @return #boolean

---
-- Function IsVisible
--
-- @function [parent=#Menu] IsVisible
-- @return #boolean

---
-- Function IsHovering
--
-- @function [parent=#Menu] IsHovering
-- @return #boolean

---
-- Function IsInternal
--
-- @function [parent=#Menu] IsInternal
-- @return #boolean

---
-- Function HasColorGradient
--
-- @function [parent=#Menu] HasColorGradient
-- @return #boolean

---
-- Function GetFocusMode
--
-- @function [parent=#Menu] GetFocusMode
-- @return FocusMode#FocusMode

---
-- Function GetDragDropMode
--
-- @function [parent=#Menu] GetDragDropMode
-- @return #number

---
-- Function GetAppliedStyle
--
-- @function [parent=#Menu] GetAppliedStyle
-- @return const String#const String

---
-- Function GetDefaultStyle
--
-- @function [parent=#Menu] GetDefaultStyle
-- @param #boolean recursiveUprecursiveUp
-- @return XMLFile#XMLFile

---
-- Function GetLayoutMode
--
-- @function [parent=#Menu] GetLayoutMode
-- @return LayoutMode#LayoutMode

---
-- Function GetLayoutSpacing
--
-- @function [parent=#Menu] GetLayoutSpacing
-- @return #number

---
-- Function GetLayoutBorder
--
-- @function [parent=#Menu] GetLayoutBorder
-- @return const IntRect#const IntRect

---
-- Function GetNumChildren
--
-- @function [parent=#Menu] GetNumChildren
-- @param #boolean recursiverecursive
-- @return #number

---
-- Function GetChild
--
-- @function [parent=#Menu] GetChild
-- @param #string namename
-- @param #boolean recursiverecursive
-- @return UIElement#UIElement

---
-- Function GetChild
--
-- @function [parent=#Menu] GetChild
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function GetParent
--
-- @function [parent=#Menu] GetParent
-- @return UIElement#UIElement

---
-- Function GetRoot
--
-- @function [parent=#Menu] GetRoot
-- @return UIElement#UIElement

---
-- Function GetDerivedColor
--
-- @function [parent=#Menu] GetDerivedColor
-- @return const Color#const Color

---
-- Function GetVar
--
-- @function [parent=#Menu] GetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @return const Variant#const Variant

---
-- Function GetVars
--
-- @function [parent=#Menu] GetVars
-- @return const VariantMap#const VariantMap

---
-- Function ScreenToElement
--
-- @function [parent=#Menu] ScreenToElement
-- @param IntVector2#IntVector2 screenPositionscreenPosition
-- @return IntVector2#IntVector2

---
-- Function ElementToScreen
--
-- @function [parent=#Menu] ElementToScreen
-- @param IntVector2#IntVector2 positionposition
-- @return IntVector2#IntVector2

---
-- Function IsInside
--
-- @function [parent=#Menu] IsInside
-- @param IntVector2#IntVector2 positionposition
-- @param #boolean isScreenisScreen
-- @return #boolean

---
-- Function IsInsideCombined
--
-- @function [parent=#Menu] IsInsideCombined
-- @param IntVector2#IntVector2 positionposition
-- @param #boolean isScreenisScreen
-- @return #boolean

---
-- Function GetCombinedScreenRect
--
-- @function [parent=#Menu] GetCombinedScreenRect
-- @return IntRect#IntRect

---
-- Function SortChildren
--
-- @function [parent=#Menu] SortChildren

---
-- Function GetLayoutMinSize
--
-- @function [parent=#Menu] GetLayoutMinSize
-- @return #number

---
-- Function GetIndent
--
-- @function [parent=#Menu] GetIndent
-- @return #number

---
-- Function GetIndentSpacing
--
-- @function [parent=#Menu] GetIndentSpacing
-- @return #number

---
-- Function GetIndentWidth
--
-- @function [parent=#Menu] GetIndentWidth
-- @return #number

---
-- Function SetChildOffset
--
-- @function [parent=#Menu] SetChildOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetHovering
--
-- @function [parent=#Menu] SetHovering
-- @param #boolean enableenable

---
-- Function GetColor
--
-- @function [parent=#Menu] GetColor
-- @return const Color#const Color

---
-- Function GetTraversalMode
--
-- @function [parent=#Menu] GetTraversalMode
-- @return TraversalMode#TraversalMode

---
-- Function IsElementEventSender
--
-- @function [parent=#Menu] IsElementEventSender
-- @return #boolean

---
-- Function GetElementEventSender
--
-- @function [parent=#Menu] GetElementEventSender
-- @return UIElement#UIElement

---
-- Field screenPosition (Read only)
--
-- @field [parent=#Menu] IntVector2#IntVector2 screenPosition

---
-- Field name
--
-- @field [parent=#Menu] #string name

---
-- Field position
--
-- @field [parent=#Menu] IntVector2#IntVector2 position

---
-- Field size
--
-- @field [parent=#Menu] IntVector2#IntVector2 size

---
-- Field width
--
-- @field [parent=#Menu] #number width

---
-- Field height
--
-- @field [parent=#Menu] #number height

---
-- Field minSize
--
-- @field [parent=#Menu] IntVector2#IntVector2 minSize

---
-- Field minWidth
--
-- @field [parent=#Menu] #number minWidth

---
-- Field minHeight
--
-- @field [parent=#Menu] #number minHeight

---
-- Field maxSize
--
-- @field [parent=#Menu] IntVector2#IntVector2 maxSize

---
-- Field maxWidth
--
-- @field [parent=#Menu] #number maxWidth

---
-- Field maxHeight
--
-- @field [parent=#Menu] #number maxHeight

---
-- Field fixedSize (Read only)
--
-- @field [parent=#Menu] #boolean fixedSize

---
-- Field fixedWidth (Read only)
--
-- @field [parent=#Menu] #boolean fixedWidth

---
-- Field fixedHeight (Read only)
--
-- @field [parent=#Menu] #boolean fixedHeight

---
-- Field childOffset
--
-- @field [parent=#Menu] IntVector2#IntVector2 childOffset

---
-- Field horizontalAlignment
--
-- @field [parent=#Menu] HorizontalAlignment#HorizontalAlignment horizontalAlignment

---
-- Field verticalAlignment
--
-- @field [parent=#Menu] VerticalAlignment#VerticalAlignment verticalAlignment

---
-- Field clipBorder
--
-- @field [parent=#Menu] IntRect#IntRect clipBorder

---
-- Field color
--
-- @field [parent=#Menu] Color#Color color

---
-- Field priority
--
-- @field [parent=#Menu] #number priority

---
-- Field opacity
--
-- @field [parent=#Menu] #number opacity

---
-- Field derivedOpacity (Read only)
--
-- @field [parent=#Menu] #number derivedOpacity

---
-- Field bringToFront
--
-- @field [parent=#Menu] #boolean bringToFront

---
-- Field bringToBack
--
-- @field [parent=#Menu] #boolean bringToBack

---
-- Field clipChildren
--
-- @field [parent=#Menu] #boolean clipChildren

---
-- Field sortChildren
--
-- @field [parent=#Menu] #boolean sortChildren

---
-- Field useDerivedOpacity
--
-- @field [parent=#Menu] #boolean useDerivedOpacity

---
-- Field focus
--
-- @field [parent=#Menu] #boolean focus

---
-- Field enabled
--
-- @field [parent=#Menu] #boolean enabled

---
-- Field editable
--
-- @field [parent=#Menu] #boolean editable

---
-- Field selected
--
-- @field [parent=#Menu] #boolean selected

---
-- Field visible
--
-- @field [parent=#Menu] #boolean visible

---
-- Field hovering
--
-- @field [parent=#Menu] #boolean hovering

---
-- Field internal
--
-- @field [parent=#Menu] #boolean internal

---
-- Field colorGradient (Read only)
--
-- @field [parent=#Menu] #boolean colorGradient

---
-- Field focusMode
--
-- @field [parent=#Menu] FocusMode#FocusMode focusMode

---
-- Field dragDropMode
--
-- @field [parent=#Menu] #number dragDropMode

---
-- Field style
--
-- @field [parent=#Menu] #string style

---
-- Field defaultStyle
--
-- @field [parent=#Menu] XMLFile#XMLFile defaultStyle

---
-- Field layoutMode
--
-- @field [parent=#Menu] LayoutMode#LayoutMode layoutMode

---
-- Field layoutSpacing
--
-- @field [parent=#Menu] #number layoutSpacing

---
-- Field layoutBorder
--
-- @field [parent=#Menu] IntRect#IntRect layoutBorder

---
-- Field numChildren (Read only)
--
-- @field [parent=#Menu] #number numChildren

---
-- Field parent
--
-- @field [parent=#Menu] UIElement#UIElement parent

---
-- Field root (Read only)
--
-- @field [parent=#Menu] UIElement#UIElement root

---
-- Field derivedColor (Read only)
--
-- @field [parent=#Menu] Color#Color derivedColor

---
-- Field combinedScreenRect (Read only)
--
-- @field [parent=#Menu] IntRect#IntRect combinedScreenRect

---
-- Field layoutMinSize (Read only)
--
-- @field [parent=#Menu] #number layoutMinSize

---
-- Field indent
--
-- @field [parent=#Menu] #number indent

---
-- Field indentSpacing
--
-- @field [parent=#Menu] #number indentSpacing

---
-- Field indentWidth (Read only)
--
-- @field [parent=#Menu] #number indentWidth

---
-- Field traversalMode
--
-- @field [parent=#Menu] TraversalMode#TraversalMode traversalMode

---
-- Field elementEventSender
--
-- @field [parent=#Menu] #boolean elementEventSender

---
-- Function SetTemporary
--
-- @function [parent=#Menu] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#Menu] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Menu] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Menu] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Menu] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Menu] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Menu] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Menu] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#Menu] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Menu] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Menu] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Menu] #string category


return nil
