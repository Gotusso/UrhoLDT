---
-- Module Menu
-- Extends Button
--
-- @module Menu

---
-- Function Menu
--
-- @function [parent=#Menu] Menu

---
-- Function new
--
-- @function [parent=#Menu] new
-- @return Menu#Menu

---
-- Function delete
--
-- @function [parent=#Menu] delete

---
-- Function SetPopup
--
-- @function [parent=#Menu] SetPopup
-- @param UIElement#UIElement elementelement

---
-- Function SetPopupOffset
--
-- @function [parent=#Menu] SetPopupOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetPopupOffset
--
-- @function [parent=#Menu] SetPopupOffset
-- @param #number xx
-- @param #number yy

---
-- Function ShowPopup
--
-- @function [parent=#Menu] ShowPopup
-- @param #boolean enableenable

---
-- Function SetAccelerator
--
-- @function [parent=#Menu] SetAccelerator
-- @param #number keykey
-- @param #number qualifiersqualifiers

---
-- Function GetPopup
--
-- @function [parent=#Menu] GetPopup
-- @return UIElement#UIElement

---
-- Function GetPopupOffset
--
-- @function [parent=#Menu] GetPopupOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetShowPopup
--
-- @function [parent=#Menu] GetShowPopup
-- @return #boolean

---
-- Function GetAcceleratorKey
--
-- @function [parent=#Menu] GetAcceleratorKey
-- @return #number

---
-- Function GetAcceleratorQualifiers
--
-- @function [parent=#Menu] GetAcceleratorQualifiers
-- @return #number

---
-- Field popup
--
-- @field [parent=#Menu] UIElement#UIElement popup

---
-- Field popupOffset
--
-- @field [parent=#Menu] IntVector2#IntVector2 popupOffset

---
-- Field showPopup
--
-- @field [parent=#Menu] #boolean showPopup

---
-- Field acceleratorKey (Read only)
--
-- @field [parent=#Menu] #number acceleratorKey

---
-- Field acceleratorQualifiers (Read only)
--
-- @field [parent=#Menu] #number acceleratorQualifiers


return nil
