---
-- Module ResourceRefList
-- Generated on 2014-05-31
--
-- @module ResourceRefList

---
-- Function ResourceRefList()
--
-- @function [parent=#ResourceRefList] ResourceRefList
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#ResourceRefList] new
-- @param self Self reference
-- @return ResourceRefList#ResourceRefList

---
-- Function ResourceRefList()
--
-- @function [parent=#ResourceRefList] ResourceRefList
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type

---
-- Function new()
--
-- @function [parent=#ResourceRefList] new
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return ResourceRefList#ResourceRefList

---
-- Function delete()
--
-- @function [parent=#ResourceRefList] delete
-- @param self Self reference

---
-- Function operator==()
--
-- @function [parent=#ResourceRefList] operator==
-- @param self Self reference
-- @param ResourceRefList#ResourceRefList rhs rhs
-- @return #boolean

---
-- Field type
--
-- @field [parent=#ResourceRefList] ShortStringHash#ShortStringHash type


return nil
