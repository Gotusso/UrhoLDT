---
-- Module ResourceRefList
--
-- @module ResourceRefList

---
-- Function ResourceRefList
--
-- @function [parent=#ResourceRefList] ResourceRefList

---
-- Function new
--
-- @function [parent=#ResourceRefList] new
-- @return ResourceRefList#ResourceRefList

---
-- Function ResourceRefList
--
-- @function [parent=#ResourceRefList] ResourceRefList
-- @param ShortStringHash#ShortStringHash typetype

---
-- Function new
--
-- @function [parent=#ResourceRefList] new
-- @param ShortStringHash#ShortStringHash typetype
-- @return ResourceRefList#ResourceRefList

---
-- Function delete
--
-- @function [parent=#ResourceRefList] delete

---
-- Function operator==
--
-- @function [parent=#ResourceRefList] operator==
-- @param ResourceRefList#ResourceRefList rhsrhs
-- @return #boolean

---
-- Field type
--
-- @field [parent=#ResourceRefList] ShortStringHash#ShortStringHash type


return nil
