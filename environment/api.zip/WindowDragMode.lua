---
-- Enumeration WindowDragMode
--
-- @module WindowDragMode

---
-- Enumeration value DRAG_NONE
--
-- @field [parent=#WindowDragMode] #number DRAG_NONE

---
-- Enumeration value DRAG_MOVE
--
-- @field [parent=#WindowDragMode] #number DRAG_MOVE

---
-- Enumeration value DRAG_RESIZE_TOPLEFT
--
-- @field [parent=#WindowDragMode] #number DRAG_RESIZE_TOPLEFT

---
-- Enumeration value DRAG_RESIZE_TOP
--
-- @field [parent=#WindowDragMode] #number DRAG_RESIZE_TOP

---
-- Enumeration value DRAG_RESIZE_TOPRIGHT
--
-- @field [parent=#WindowDragMode] #number DRAG_RESIZE_TOPRIGHT

---
-- Enumeration value DRAG_RESIZE_RIGHT
--
-- @field [parent=#WindowDragMode] #number DRAG_RESIZE_RIGHT

---
-- Enumeration value DRAG_RESIZE_BOTTOMRIGHT
--
-- @field [parent=#WindowDragMode] #number DRAG_RESIZE_BOTTOMRIGHT

---
-- Enumeration value DRAG_RESIZE_BOTTOM
--
-- @field [parent=#WindowDragMode] #number DRAG_RESIZE_BOTTOM

---
-- Enumeration value DRAG_RESIZE_BOTTOMLEFT
--
-- @field [parent=#WindowDragMode] #number DRAG_RESIZE_BOTTOMLEFT

---
-- Enumeration value DRAG_RESIZE_LEFT
--
-- @field [parent=#WindowDragMode] #number DRAG_RESIZE_LEFT


return nil
