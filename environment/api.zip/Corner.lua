---
-- Enumeration Corner
--
-- @module Corner

---
-- Enumeration value C_TOPLEFT
--
-- @field [parent=#Corner] #number C_TOPLEFT

---
-- Enumeration value C_TOPRIGHT
--
-- @field [parent=#Corner] #number C_TOPRIGHT

---
-- Enumeration value C_BOTTOMLEFT
--
-- @field [parent=#Corner] #number C_BOTTOMLEFT

---
-- Enumeration value C_BOTTOMRIGHT
--
-- @field [parent=#Corner] #number C_BOTTOMRIGHT

---
-- Enumeration value MAX_UIELEMENT_CORNERS
--
-- @field [parent=#Corner] #number MAX_UIELEMENT_CORNERS


return nil
