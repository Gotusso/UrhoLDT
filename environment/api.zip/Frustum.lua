---
-- Module Frustum
-- Generated on 2014-03-13
--
-- @module Frustum

---
-- Function Frustum
--
-- @function [parent=#Frustum] Frustum
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#Frustum] new
-- @param self Self reference
-- @return Frustum#Frustum

---
-- Function Frustum
--
-- @function [parent=#Frustum] Frustum
-- @param self Self reference
-- @param Frustum#Frustum frustum frustum

---
-- Function new
--
-- @function [parent=#Frustum] new
-- @param self Self reference
-- @param Frustum#Frustum frustum frustum
-- @return Frustum#Frustum

---
-- Function delete
--
-- @function [parent=#Frustum] delete
-- @param self Self reference

---
-- Function Define
--
-- @function [parent=#Frustum] Define
-- @param self Self reference
-- @param #number fov fov
-- @param #number aspectRatio aspectRatio
-- @param #number zoom zoom
-- @param #number nearZ nearZ
-- @param #number farZ farZ

---
-- Function Define
--
-- @function [parent=#Frustum] Define
-- @param self Self reference
-- @param #number fov fov
-- @param #number aspectRatio aspectRatio
-- @param #number zoom zoom
-- @param #number nearZ nearZ
-- @param #number farZ farZ
-- @param Matrix3x4#Matrix3x4 transform transform

---
-- Function Define
--
-- @function [parent=#Frustum] Define
-- @param self Self reference
-- @param Vector3#Vector3 near near
-- @param Vector3#Vector3 far far

---
-- Function Define
--
-- @function [parent=#Frustum] Define
-- @param self Self reference
-- @param Vector3#Vector3 near near
-- @param Vector3#Vector3 far far
-- @param Matrix3x4#Matrix3x4 transform transform

---
-- Function Define
--
-- @function [parent=#Frustum] Define
-- @param self Self reference
-- @param BoundingBox#BoundingBox box box

---
-- Function Define
--
-- @function [parent=#Frustum] Define
-- @param self Self reference
-- @param BoundingBox#BoundingBox box box
-- @param Matrix3x4#Matrix3x4 transform transform

---
-- Function DefineOrtho
--
-- @function [parent=#Frustum] DefineOrtho
-- @param self Self reference
-- @param #number orthoSize orthoSize
-- @param #number aspectRatio aspectRatio
-- @param #number zoom zoom
-- @param #number nearZ nearZ
-- @param #number farZ farZ

---
-- Function DefineOrtho
--
-- @function [parent=#Frustum] DefineOrtho
-- @param self Self reference
-- @param #number orthoSize orthoSize
-- @param #number aspectRatio aspectRatio
-- @param #number zoom zoom
-- @param #number nearZ nearZ
-- @param #number farZ farZ
-- @param Matrix3x4#Matrix3x4 transform transform

---
-- Function Transform
--
-- @function [parent=#Frustum] Transform
-- @param self Self reference
-- @param Matrix3#Matrix3 transform transform

---
-- Function Transform
--
-- @function [parent=#Frustum] Transform
-- @param self Self reference
-- @param Matrix3x4#Matrix3x4 transform transform

---
-- Function IsInside
--
-- @function [parent=#Frustum] IsInside
-- @param self Self reference
-- @param Vector3#Vector3 point point
-- @return Intersection#Intersection

---
-- Function IsInside
--
-- @function [parent=#Frustum] IsInside
-- @param self Self reference
-- @param Sphere#Sphere sphere sphere
-- @return Intersection#Intersection

---
-- Function IsInsideFast
--
-- @function [parent=#Frustum] IsInsideFast
-- @param self Self reference
-- @param Sphere#Sphere sphere sphere
-- @return Intersection#Intersection

---
-- Function IsInside
--
-- @function [parent=#Frustum] IsInside
-- @param self Self reference
-- @param BoundingBox#BoundingBox box box
-- @return Intersection#Intersection

---
-- Function IsInsideFast
--
-- @function [parent=#Frustum] IsInsideFast
-- @param self Self reference
-- @param BoundingBox#BoundingBox box box
-- @return Intersection#Intersection

---
-- Function Distance
--
-- @function [parent=#Frustum] Distance
-- @param self Self reference
-- @param Vector3#Vector3 point point
-- @return #number

---
-- Function Transformed
--
-- @function [parent=#Frustum] Transformed
-- @param self Self reference
-- @param Matrix3#Matrix3 transform transform
-- @return Frustum#Frustum

---
-- Function Transformed
--
-- @function [parent=#Frustum] Transformed
-- @param self Self reference
-- @param Matrix3x4#Matrix3x4 transform transform
-- @return Frustum#Frustum

---
-- Function Projected
--
-- @function [parent=#Frustum] Projected
-- @param self Self reference
-- @param Matrix4#Matrix4 transform transform
-- @return Rect#Rect

---
-- Function UpdatePlanes
--
-- @function [parent=#Frustum] UpdatePlanes
-- @param self Self reference


return nil
