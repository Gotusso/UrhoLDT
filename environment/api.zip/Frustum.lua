---
-- Module Frustum
--
-- @module Frustum

---
-- Function Frustum
--
-- @function [parent=#Frustum] Frustum

---
-- Function new
--
-- @function [parent=#Frustum] new
-- @return Frustum#Frustum

---
-- Function Frustum
--
-- @function [parent=#Frustum] Frustum
-- @param Frustum#Frustum frustumfrustum

---
-- Function new
--
-- @function [parent=#Frustum] new
-- @param Frustum#Frustum frustumfrustum
-- @return Frustum#Frustum

---
-- Function delete
--
-- @function [parent=#Frustum] delete

---
-- Function Define
--
-- @function [parent=#Frustum] Define
-- @param #number fovfov
-- @param #number aspectRatioaspectRatio
-- @param #number zoomzoom
-- @param #number nearZnearZ
-- @param #number farZfarZ

---
-- Function Define
--
-- @function [parent=#Frustum] Define
-- @param #number fovfov
-- @param #number aspectRatioaspectRatio
-- @param #number zoomzoom
-- @param #number nearZnearZ
-- @param #number farZfarZ
-- @param Matrix3x4#Matrix3x4 transformtransform

---
-- Function Define
--
-- @function [parent=#Frustum] Define
-- @param Vector3#Vector3 nearnear
-- @param Vector3#Vector3 farfar

---
-- Function Define
--
-- @function [parent=#Frustum] Define
-- @param Vector3#Vector3 nearnear
-- @param Vector3#Vector3 farfar
-- @param Matrix3x4#Matrix3x4 transformtransform

---
-- Function Define
--
-- @function [parent=#Frustum] Define
-- @param BoundingBox#BoundingBox boxbox

---
-- Function Define
--
-- @function [parent=#Frustum] Define
-- @param BoundingBox#BoundingBox boxbox
-- @param Matrix3x4#Matrix3x4 transformtransform

---
-- Function DefineOrtho
--
-- @function [parent=#Frustum] DefineOrtho
-- @param #number orthoSizeorthoSize
-- @param #number aspectRatioaspectRatio
-- @param #number zoomzoom
-- @param #number nearZnearZ
-- @param #number farZfarZ

---
-- Function DefineOrtho
--
-- @function [parent=#Frustum] DefineOrtho
-- @param #number orthoSizeorthoSize
-- @param #number aspectRatioaspectRatio
-- @param #number zoomzoom
-- @param #number nearZnearZ
-- @param #number farZfarZ
-- @param Matrix3x4#Matrix3x4 transformtransform

---
-- Function Transform
--
-- @function [parent=#Frustum] Transform
-- @param Matrix3#Matrix3 transformtransform

---
-- Function Transform
--
-- @function [parent=#Frustum] Transform
-- @param Matrix3x4#Matrix3x4 transformtransform

---
-- Function IsInside
--
-- @function [parent=#Frustum] IsInside
-- @param Vector3#Vector3 pointpoint
-- @return Intersection#Intersection

---
-- Function IsInside
--
-- @function [parent=#Frustum] IsInside
-- @param Sphere#Sphere spheresphere
-- @return Intersection#Intersection

---
-- Function IsInsideFast
--
-- @function [parent=#Frustum] IsInsideFast
-- @param Sphere#Sphere spheresphere
-- @return Intersection#Intersection

---
-- Function IsInside
--
-- @function [parent=#Frustum] IsInside
-- @param BoundingBox#BoundingBox boxbox
-- @return Intersection#Intersection

---
-- Function IsInsideFast
--
-- @function [parent=#Frustum] IsInsideFast
-- @param BoundingBox#BoundingBox boxbox
-- @return Intersection#Intersection

---
-- Function Distance
--
-- @function [parent=#Frustum] Distance
-- @param Vector3#Vector3 pointpoint
-- @return #number

---
-- Function Transformed
--
-- @function [parent=#Frustum] Transformed
-- @param Matrix3#Matrix3 transformtransform
-- @return Frustum#Frustum

---
-- Function Transformed
--
-- @function [parent=#Frustum] Transformed
-- @param Matrix3x4#Matrix3x4 transformtransform
-- @return Frustum#Frustum

---
-- Function Projected
--
-- @function [parent=#Frustum] Projected
-- @param Matrix4#Matrix4 transformtransform
-- @return Rect#Rect

---
-- Function UpdatePlanes
--
-- @function [parent=#Frustum] UpdatePlanes


return nil
