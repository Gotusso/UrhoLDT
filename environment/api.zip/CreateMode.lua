---
-- Enumeration CreateMode
--
-- @module CreateMode

---
-- Enumeration value REPLICATED
--
-- @field [parent=#CreateMode] #number REPLICATED

---
-- Enumeration value LOCAL
--
-- @field [parent=#CreateMode] #number LOCAL


return nil
