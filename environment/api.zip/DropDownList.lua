---
-- Module DropDownList
-- Module DropDownList extends Menu
-- Generated on 2014-05-31
--
-- @module DropDownList

---
-- Function DropDownList()
--
-- @function [parent=#DropDownList] DropDownList
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#DropDownList] new
-- @param self Self reference
-- @return DropDownList#DropDownList

---
-- Function delete()
--
-- @function [parent=#DropDownList] delete
-- @param self Self reference

---
-- Function AddItem()
-- Add item to the end of the list.
--
-- @function [parent=#DropDownList] AddItem
-- @param self Self reference
-- @param UIElement#UIElement item item

---
-- Function InsertItem()
-- Insert item to a specific position.
--
-- @function [parent=#DropDownList] InsertItem
-- @param self Self reference
-- @param #number index index
-- @param UIElement#UIElement item item

---
-- Function RemoveItem()
-- Remove specific item.
--
-- @function [parent=#DropDownList] RemoveItem
-- @param self Self reference
-- @param UIElement#UIElement item item

---
-- Function RemoveItem()
-- Remove item at index.
--
-- @function [parent=#DropDownList] RemoveItem
-- @param self Self reference
-- @param #number index index

---
-- Function RemoveAllItems()
-- Remove all items.
--
-- @function [parent=#DropDownList] RemoveAllItems
-- @param self Self reference

---
-- Function SetSelection()
-- Set selection.
--
-- @function [parent=#DropDownList] SetSelection
-- @param self Self reference
-- @param #number index index

---
-- Function SetPlaceholderText()
-- Set place holder text. This is the text shown when there is no selection in drop down list.
--
-- @function [parent=#DropDownList] SetPlaceholderText
-- @param self Self reference
-- @param #string text text

---
-- Function SetResizePopup()
-- Set whether popup should be automatically resized to match the dropdown button width.
--
-- @function [parent=#DropDownList] SetResizePopup
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function GetNumItems()
-- Return number of items.
--
-- @function [parent=#DropDownList] GetNumItems
-- @param self Self reference
-- @return #number

---
-- Function GetItem()
-- Return item at index.
--
-- @function [parent=#DropDownList] GetItem
-- @param self Self reference
-- @param #number index index
-- @return UIElement#UIElement

---
-- Function GetItems()
-- Return all items.
--
-- @function [parent=#DropDownList] GetItems
-- @param self Self reference
-- @return const PODVector<UIElement*>#const PODVector<UIElement*>

---
-- Function GetSelection()
-- Return selection index, or M_MAX_UNSIGNED if none selected.
--
-- @function [parent=#DropDownList] GetSelection
-- @param self Self reference
-- @return #number

---
-- Function GetSelectedItem()
-- Return selected item, or null if none selected.
--
-- @function [parent=#DropDownList] GetSelectedItem
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetListView()
-- Return listview element.
--
-- @function [parent=#DropDownList] GetListView
-- @param self Self reference
-- @return ListView#ListView

---
-- Function GetPlaceholder()
-- Return selected item placeholder element.
--
-- @function [parent=#DropDownList] GetPlaceholder
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetPlaceholderText()
-- Return place holder text.
--
-- @function [parent=#DropDownList] GetPlaceholderText
-- @param self Self reference
-- @return const String#const String

---
-- Function GetResizePopup()
-- Return whether popup should be automatically resized.
--
-- @function [parent=#DropDownList] GetResizePopup
-- @param self Self reference
-- @return #boolean

---
-- Field numItems (Read only)
--
-- @field [parent=#DropDownList] #number numItems

---
-- Field selection
--
-- @field [parent=#DropDownList] #number selection

---
-- Field selectedItem (Read only)
--
-- @field [parent=#DropDownList] UIElement#UIElement selectedItem

---
-- Field listView (Read only)
--
-- @field [parent=#DropDownList] ListView#ListView listView

---
-- Field placeholder (Read only)
--
-- @field [parent=#DropDownList] UIElement#UIElement placeholder

---
-- Field placeholderText
--
-- @field [parent=#DropDownList] #string placeholderText

---
-- Field resizePopup
--
-- @field [parent=#DropDownList] #boolean resizePopup


return nil
