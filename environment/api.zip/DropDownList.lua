---
-- Module DropDownList
-- Extends Menu
--
-- @module DropDownList

---
-- Function DropDownList
--
-- @function [parent=#DropDownList] DropDownList

---
-- Function new
--
-- @function [parent=#DropDownList] new
-- @return DropDownList#DropDownList

---
-- Function delete
--
-- @function [parent=#DropDownList] delete

---
-- Function AddItem
--
-- @function [parent=#DropDownList] AddItem
-- @param UIElement#UIElement itemitem

---
-- Function InsertItem
--
-- @function [parent=#DropDownList] InsertItem
-- @param #number indexindex
-- @param UIElement#UIElement itemitem

---
-- Function RemoveItem
--
-- @function [parent=#DropDownList] RemoveItem
-- @param UIElement#UIElement itemitem

---
-- Function RemoveItem
--
-- @function [parent=#DropDownList] RemoveItem
-- @param #number indexindex

---
-- Function RemoveAllItems
--
-- @function [parent=#DropDownList] RemoveAllItems

---
-- Function SetSelection
--
-- @function [parent=#DropDownList] SetSelection
-- @param #number indexindex

---
-- Function SetPlaceholderText
--
-- @function [parent=#DropDownList] SetPlaceholderText
-- @param #string texttext

---
-- Function SetResizePopup
--
-- @function [parent=#DropDownList] SetResizePopup
-- @param #boolean enableenable

---
-- Function GetNumItems
--
-- @function [parent=#DropDownList] GetNumItems
-- @return #number

---
-- Function GetItem
--
-- @function [parent=#DropDownList] GetItem
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function GetItems
--
-- @function [parent=#DropDownList] GetItems
-- @return const PODVector<UIElement*>#const PODVector<UIElement*>

---
-- Function GetSelection
--
-- @function [parent=#DropDownList] GetSelection
-- @return #number

---
-- Function GetSelectedItem
--
-- @function [parent=#DropDownList] GetSelectedItem
-- @return UIElement#UIElement

---
-- Function GetListView
--
-- @function [parent=#DropDownList] GetListView
-- @return ListView#ListView

---
-- Function GetPlaceholder
--
-- @function [parent=#DropDownList] GetPlaceholder
-- @return UIElement#UIElement

---
-- Function GetPlaceholderText
--
-- @function [parent=#DropDownList] GetPlaceholderText
-- @return const String#const String

---
-- Function GetResizePopup
--
-- @function [parent=#DropDownList] GetResizePopup
-- @return #boolean

---
-- Field numItems (Read only)
--
-- @field [parent=#DropDownList] #number numItems

---
-- Field selection
--
-- @field [parent=#DropDownList] #number selection

---
-- Field selectedItem (Read only)
--
-- @field [parent=#DropDownList] UIElement#UIElement selectedItem

---
-- Field listView (Read only)
--
-- @field [parent=#DropDownList] ListView#ListView listView

---
-- Field placeholder (Read only)
--
-- @field [parent=#DropDownList] UIElement#UIElement placeholder

---
-- Field placeholderText
--
-- @field [parent=#DropDownList] #string placeholderText

---
-- Field resizePopup
--
-- @field [parent=#DropDownList] #boolean resizePopup


return nil
