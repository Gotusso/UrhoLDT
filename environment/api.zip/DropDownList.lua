---
-- Module DropDownList
-- Module DropDownList extends Menu
-- Generated on 2014-03-13
--
-- @module DropDownList

---
-- Function DropDownList
--
-- @function [parent=#DropDownList] DropDownList
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#DropDownList] new
-- @param self Self reference
-- @return DropDownList#DropDownList

---
-- Function delete
--
-- @function [parent=#DropDownList] delete
-- @param self Self reference

---
-- Function AddItem
--
-- @function [parent=#DropDownList] AddItem
-- @param self Self reference
-- @param UIElement#UIElement item item

---
-- Function InsertItem
--
-- @function [parent=#DropDownList] InsertItem
-- @param self Self reference
-- @param #number index index
-- @param UIElement#UIElement item item

---
-- Function RemoveItem
--
-- @function [parent=#DropDownList] RemoveItem
-- @param self Self reference
-- @param UIElement#UIElement item item

---
-- Function RemoveItem
--
-- @function [parent=#DropDownList] RemoveItem
-- @param self Self reference
-- @param #number index index

---
-- Function RemoveAllItems
--
-- @function [parent=#DropDownList] RemoveAllItems
-- @param self Self reference

---
-- Function SetSelection
--
-- @function [parent=#DropDownList] SetSelection
-- @param self Self reference
-- @param #number index index

---
-- Function SetPlaceholderText
--
-- @function [parent=#DropDownList] SetPlaceholderText
-- @param self Self reference
-- @param #string text text

---
-- Function SetResizePopup
--
-- @function [parent=#DropDownList] SetResizePopup
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function GetNumItems
--
-- @function [parent=#DropDownList] GetNumItems
-- @param self Self reference
-- @return #number

---
-- Function GetItem
--
-- @function [parent=#DropDownList] GetItem
-- @param self Self reference
-- @param #number index index
-- @return UIElement#UIElement

---
-- Function GetItems
--
-- @function [parent=#DropDownList] GetItems
-- @param self Self reference
-- @return const PODVector<UIElement*>#const PODVector<UIElement*>

---
-- Function GetSelection
--
-- @function [parent=#DropDownList] GetSelection
-- @param self Self reference
-- @return #number

---
-- Function GetSelectedItem
--
-- @function [parent=#DropDownList] GetSelectedItem
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetListView
--
-- @function [parent=#DropDownList] GetListView
-- @param self Self reference
-- @return ListView#ListView

---
-- Function GetPlaceholder
--
-- @function [parent=#DropDownList] GetPlaceholder
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetPlaceholderText
--
-- @function [parent=#DropDownList] GetPlaceholderText
-- @param self Self reference
-- @return const String#const String

---
-- Function GetResizePopup
--
-- @function [parent=#DropDownList] GetResizePopup
-- @param self Self reference
-- @return #boolean

---
-- Field numItems (Read only)
--
-- @field [parent=#DropDownList] #number numItems

---
-- Field selection
--
-- @field [parent=#DropDownList] #number selection

---
-- Field selectedItem (Read only)
--
-- @field [parent=#DropDownList] UIElement#UIElement selectedItem

---
-- Field listView (Read only)
--
-- @field [parent=#DropDownList] ListView#ListView listView

---
-- Field placeholder (Read only)
--
-- @field [parent=#DropDownList] UIElement#UIElement placeholder

---
-- Field placeholderText
--
-- @field [parent=#DropDownList] #string placeholderText

---
-- Field resizePopup
--
-- @field [parent=#DropDownList] #boolean resizePopup

---
-- Function Menu
--
-- @function [parent=#DropDownList] Menu
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#DropDownList] new
-- @param self Self reference
-- @return Menu#Menu

---
-- Function delete
--
-- @function [parent=#DropDownList] delete
-- @param self Self reference

---
-- Function SetPopup
--
-- @function [parent=#DropDownList] SetPopup
-- @param self Self reference
-- @param UIElement#UIElement element element

---
-- Function SetPopupOffset
--
-- @function [parent=#DropDownList] SetPopupOffset
-- @param self Self reference
-- @param IntVector2#IntVector2 offset offset

---
-- Function SetPopupOffset
--
-- @function [parent=#DropDownList] SetPopupOffset
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function ShowPopup
--
-- @function [parent=#DropDownList] ShowPopup
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetAccelerator
--
-- @function [parent=#DropDownList] SetAccelerator
-- @param self Self reference
-- @param #number key key
-- @param #number qualifiers qualifiers

---
-- Function GetPopup
--
-- @function [parent=#DropDownList] GetPopup
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetPopupOffset
--
-- @function [parent=#DropDownList] GetPopupOffset
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetShowPopup
--
-- @function [parent=#DropDownList] GetShowPopup
-- @param self Self reference
-- @return #boolean

---
-- Function GetAcceleratorKey
--
-- @function [parent=#DropDownList] GetAcceleratorKey
-- @param self Self reference
-- @return #number

---
-- Function GetAcceleratorQualifiers
--
-- @function [parent=#DropDownList] GetAcceleratorQualifiers
-- @param self Self reference
-- @return #number

---
-- Field popup
--
-- @field [parent=#DropDownList] UIElement#UIElement popup

---
-- Field popupOffset
--
-- @field [parent=#DropDownList] IntVector2#IntVector2 popupOffset

---
-- Field showPopup
--
-- @field [parent=#DropDownList] #boolean showPopup

---
-- Field acceleratorKey (Read only)
--
-- @field [parent=#DropDownList] #number acceleratorKey

---
-- Field acceleratorQualifiers (Read only)
--
-- @field [parent=#DropDownList] #number acceleratorQualifiers

---
-- Function Button
--
-- @function [parent=#DropDownList] Button
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#DropDownList] new
-- @param self Self reference
-- @return Button#Button

---
-- Function delete
--
-- @function [parent=#DropDownList] delete
-- @param self Self reference

---
-- Function SetPressedOffset
--
-- @function [parent=#DropDownList] SetPressedOffset
-- @param self Self reference
-- @param IntVector2#IntVector2 offset offset

---
-- Function SetPressedOffset
--
-- @function [parent=#DropDownList] SetPressedOffset
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function SetPressedChildOffset
--
-- @function [parent=#DropDownList] SetPressedChildOffset
-- @param self Self reference
-- @param IntVector2#IntVector2 offset offset

---
-- Function SetPressedChildOffset
--
-- @function [parent=#DropDownList] SetPressedChildOffset
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function SetRepeat
--
-- @function [parent=#DropDownList] SetRepeat
-- @param self Self reference
-- @param #number delay delay
-- @param #number rate rate

---
-- Function SetRepeatDelay
--
-- @function [parent=#DropDownList] SetRepeatDelay
-- @param self Self reference
-- @param #number delay delay

---
-- Function SetRepeatRate
--
-- @function [parent=#DropDownList] SetRepeatRate
-- @param self Self reference
-- @param #number rate rate

---
-- Function GetPressedOffset
--
-- @function [parent=#DropDownList] GetPressedOffset
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetPressedChildOffset
--
-- @function [parent=#DropDownList] GetPressedChildOffset
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetRepeatDelay
--
-- @function [parent=#DropDownList] GetRepeatDelay
-- @param self Self reference
-- @return #number

---
-- Function GetRepeatRate
--
-- @function [parent=#DropDownList] GetRepeatRate
-- @param self Self reference
-- @return #number

---
-- Function IsPressed
--
-- @function [parent=#DropDownList] IsPressed
-- @param self Self reference
-- @return #boolean

---
-- Field pressedOffset
--
-- @field [parent=#DropDownList] IntVector2#IntVector2 pressedOffset

---
-- Field pressedChildOffset
--
-- @field [parent=#DropDownList] IntVector2#IntVector2 pressedChildOffset

---
-- Field repeatDelay
--
-- @field [parent=#DropDownList] #number repeatDelay

---
-- Field repeatRate
--
-- @field [parent=#DropDownList] #number repeatRate

---
-- Field pressed (Read only)
--
-- @field [parent=#DropDownList] #boolean pressed

---
-- Function BorderImage
--
-- @function [parent=#DropDownList] BorderImage
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#DropDownList] new
-- @param self Self reference
-- @return BorderImage#BorderImage

---
-- Function delete
--
-- @function [parent=#DropDownList] delete
-- @param self Self reference

---
-- Function SetTexture
--
-- @function [parent=#DropDownList] SetTexture
-- @param self Self reference
-- @param Texture#Texture texture texture

---
-- Function SetImageRect
--
-- @function [parent=#DropDownList] SetImageRect
-- @param self Self reference
-- @param IntRect#IntRect rect rect

---
-- Function SetFullImageRect
--
-- @function [parent=#DropDownList] SetFullImageRect
-- @param self Self reference

---
-- Function SetBorder
--
-- @function [parent=#DropDownList] SetBorder
-- @param self Self reference
-- @param IntRect#IntRect rect rect

---
-- Function SetHoverOffset
--
-- @function [parent=#DropDownList] SetHoverOffset
-- @param self Self reference
-- @param IntVector2#IntVector2 offset offset

---
-- Function SetHoverOffset
--
-- @function [parent=#DropDownList] SetHoverOffset
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function SetBlendMode
--
-- @function [parent=#DropDownList] SetBlendMode
-- @param self Self reference
-- @param BlendMode#BlendMode mode mode

---
-- Function SetTiled
--
-- @function [parent=#DropDownList] SetTiled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function GetTexture
--
-- @function [parent=#DropDownList] GetTexture
-- @param self Self reference
-- @return Texture#Texture

---
-- Function GetImageRect
--
-- @function [parent=#DropDownList] GetImageRect
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetBorder
--
-- @function [parent=#DropDownList] GetBorder
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetHoverOffset
--
-- @function [parent=#DropDownList] GetHoverOffset
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetBlendMode
--
-- @function [parent=#DropDownList] GetBlendMode
-- @param self Self reference
-- @return BlendMode#BlendMode

---
-- Function IsTiled
--
-- @function [parent=#DropDownList] IsTiled
-- @param self Self reference
-- @return #boolean

---
-- Field texture
--
-- @field [parent=#DropDownList] Texture#Texture texture

---
-- Field imageRect
--
-- @field [parent=#DropDownList] IntRect#IntRect imageRect

---
-- Field border
--
-- @field [parent=#DropDownList] IntRect#IntRect border

---
-- Field hoverOffset
--
-- @field [parent=#DropDownList] IntVector2#IntVector2 hoverOffset

---
-- Field blendMode
--
-- @field [parent=#DropDownList] BlendMode#BlendMode blendMode

---
-- Field tiled
--
-- @field [parent=#DropDownList] #boolean tiled

---
-- Function UIElement
--
-- @function [parent=#DropDownList] UIElement
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#DropDownList] new
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function delete
--
-- @function [parent=#DropDownList] delete
-- @param self Self reference

---
-- Function GetScreenPosition
--
-- @function [parent=#DropDownList] GetScreenPosition
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function LoadXML
--
-- @function [parent=#DropDownList] LoadXML
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#DropDownList] SaveXML
-- @param self Self reference
-- @param Serializer#Serializer dest dest
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#DropDownList] LoadXML
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#DropDownList] SaveXML
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function FilterAttributes
--
-- @function [parent=#DropDownList] FilterAttributes
-- @param self Self reference
-- @param XMLElement#XMLElement dest dest
-- @return #boolean

---
-- Function SetName
--
-- @function [parent=#DropDownList] SetName
-- @param self Self reference
-- @param #string name name

---
-- Function SetPosition
--
-- @function [parent=#DropDownList] SetPosition
-- @param self Self reference
-- @param IntVector2#IntVector2 position position

---
-- Function SetPosition
--
-- @function [parent=#DropDownList] SetPosition
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function SetSize
--
-- @function [parent=#DropDownList] SetSize
-- @param self Self reference
-- @param IntVector2#IntVector2 size size

---
-- Function SetSize
--
-- @function [parent=#DropDownList] SetSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetWidth
--
-- @function [parent=#DropDownList] SetWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetHeight
--
-- @function [parent=#DropDownList] SetHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetMinSize
--
-- @function [parent=#DropDownList] SetMinSize
-- @param self Self reference
-- @param IntVector2#IntVector2 minSize minSize

---
-- Function SetMinSize
--
-- @function [parent=#DropDownList] SetMinSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetMinWidth
--
-- @function [parent=#DropDownList] SetMinWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetMinHeight
--
-- @function [parent=#DropDownList] SetMinHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetMaxSize
--
-- @function [parent=#DropDownList] SetMaxSize
-- @param self Self reference
-- @param IntVector2#IntVector2 maxSize maxSize

---
-- Function SetMaxSize
--
-- @function [parent=#DropDownList] SetMaxSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetMaxWidth
--
-- @function [parent=#DropDownList] SetMaxWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetMaxHeight
--
-- @function [parent=#DropDownList] SetMaxHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetFixedSize
--
-- @function [parent=#DropDownList] SetFixedSize
-- @param self Self reference
-- @param IntVector2#IntVector2 size size

---
-- Function SetFixedSize
--
-- @function [parent=#DropDownList] SetFixedSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetFixedWidth
--
-- @function [parent=#DropDownList] SetFixedWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetFixedHeight
--
-- @function [parent=#DropDownList] SetFixedHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetAlignment
--
-- @function [parent=#DropDownList] SetAlignment
-- @param self Self reference
-- @param HorizontalAlignment#HorizontalAlignment hAlign hAlign
-- @param VerticalAlignment#VerticalAlignment vAlign vAlign

---
-- Function SetHorizontalAlignment
--
-- @function [parent=#DropDownList] SetHorizontalAlignment
-- @param self Self reference
-- @param HorizontalAlignment#HorizontalAlignment align align

---
-- Function SetVerticalAlignment
--
-- @function [parent=#DropDownList] SetVerticalAlignment
-- @param self Self reference
-- @param VerticalAlignment#VerticalAlignment align align

---
-- Function SetClipBorder
--
-- @function [parent=#DropDownList] SetClipBorder
-- @param self Self reference
-- @param IntRect#IntRect rect rect

---
-- Function SetColor
--
-- @function [parent=#DropDownList] SetColor
-- @param self Self reference
-- @param Color#Color color color

---
-- Function SetColor
--
-- @function [parent=#DropDownList] SetColor
-- @param self Self reference
-- @param Corner#Corner corner corner
-- @param Color#Color color color

---
-- Function SetPriority
--
-- @function [parent=#DropDownList] SetPriority
-- @param self Self reference
-- @param #number priority priority

---
-- Function SetOpacity
--
-- @function [parent=#DropDownList] SetOpacity
-- @param self Self reference
-- @param #number opacity opacity

---
-- Function SetBringToFront
--
-- @function [parent=#DropDownList] SetBringToFront
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetBringToBack
--
-- @function [parent=#DropDownList] SetBringToBack
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetClipChildren
--
-- @function [parent=#DropDownList] SetClipChildren
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetSortChildren
--
-- @function [parent=#DropDownList] SetSortChildren
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetUseDerivedOpacity
--
-- @function [parent=#DropDownList] SetUseDerivedOpacity
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetEnabled
--
-- @function [parent=#DropDownList] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetEditable
--
-- @function [parent=#DropDownList] SetEditable
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetFocus
--
-- @function [parent=#DropDownList] SetFocus
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetSelected
--
-- @function [parent=#DropDownList] SetSelected
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetVisible
--
-- @function [parent=#DropDownList] SetVisible
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetFocusMode
--
-- @function [parent=#DropDownList] SetFocusMode
-- @param self Self reference
-- @param FocusMode#FocusMode mode mode

---
-- Function SetDragDropMode
--
-- @function [parent=#DropDownList] SetDragDropMode
-- @param self Self reference
-- @param #number mode mode

---
-- Function SetStyle
--
-- @function [parent=#DropDownList] SetStyle
-- @param self Self reference
-- @param #string styleName styleName
-- @param XMLFile#XMLFile file file
-- @return #boolean

---
-- Function SetStyle
--
-- @function [parent=#DropDownList] SetStyle
-- @param self Self reference
-- @param XMLElement#XMLElement element element
-- @return #boolean

---
-- Function SetStyleAuto
--
-- @function [parent=#DropDownList] SetStyleAuto
-- @param self Self reference
-- @param XMLFile#XMLFile file file
-- @return #boolean

---
-- Function SetDefaultStyle
--
-- @function [parent=#DropDownList] SetDefaultStyle
-- @param self Self reference
-- @param XMLFile#XMLFile style style

---
-- Function SetLayout
--
-- @function [parent=#DropDownList] SetLayout
-- @param self Self reference
-- @param LayoutMode#LayoutMode mode mode
-- @param #number spacing spacing

---
-- Function SetLayout
--
-- @function [parent=#DropDownList] SetLayout
-- @param self Self reference
-- @param LayoutMode#LayoutMode mode mode
-- @param #number spacing spacing
-- @param IntRect#IntRect border border

---
-- Function SetLayoutMode
--
-- @function [parent=#DropDownList] SetLayoutMode
-- @param self Self reference
-- @param LayoutMode#LayoutMode mode mode

---
-- Function SetLayoutSpacing
--
-- @function [parent=#DropDownList] SetLayoutSpacing
-- @param self Self reference
-- @param #number spacing spacing

---
-- Function SetLayoutBorder
--
-- @function [parent=#DropDownList] SetLayoutBorder
-- @param self Self reference
-- @param IntRect#IntRect border border

---
-- Function SetIndent
--
-- @function [parent=#DropDownList] SetIndent
-- @param self Self reference
-- @param #number indent indent

---
-- Function SetIndentSpacing
--
-- @function [parent=#DropDownList] SetIndentSpacing
-- @param self Self reference
-- @param #number indentSpacing indentSpacing

---
-- Function UpdateLayout
--
-- @function [parent=#DropDownList] UpdateLayout
-- @param self Self reference

---
-- Function DisableLayoutUpdate
--
-- @function [parent=#DropDownList] DisableLayoutUpdate
-- @param self Self reference

---
-- Function EnableLayoutUpdate
--
-- @function [parent=#DropDownList] EnableLayoutUpdate
-- @param self Self reference

---
-- Function BringToFront
--
-- @function [parent=#DropDownList] BringToFront
-- @param self Self reference

---
-- Function CreateChild
--
-- @function [parent=#DropDownList] CreateChild
-- @param self Self reference
-- @param #string type type
-- @param #string name name
-- @param #number index index
-- @return UIElement#UIElement

---
-- Function AddChild
--
-- @function [parent=#DropDownList] AddChild
-- @param self Self reference
-- @param UIElement#UIElement element element

---
-- Function InsertChild
--
-- @function [parent=#DropDownList] InsertChild
-- @param self Self reference
-- @param #number index index
-- @param UIElement#UIElement element element

---
-- Function RemoveChild
--
-- @function [parent=#DropDownList] RemoveChild
-- @param self Self reference
-- @param UIElement#UIElement element element
-- @param #number index index

---
-- Function RemoveChildAtIndex
--
-- @function [parent=#DropDownList] RemoveChildAtIndex
-- @param self Self reference
-- @param #number index index

---
-- Function RemoveAllChildren
--
-- @function [parent=#DropDownList] RemoveAllChildren
-- @param self Self reference

---
-- Function Remove
--
-- @function [parent=#DropDownList] Remove
-- @param self Self reference

---
-- Function FindChild
--
-- @function [parent=#DropDownList] FindChild
-- @param self Self reference
-- @param UIElement#UIElement element element
-- @return #number

---
-- Function SetParent
--
-- @function [parent=#DropDownList] SetParent
-- @param self Self reference
-- @param UIElement#UIElement parent parent
-- @param #number index index

---
-- Function SetVar
--
-- @function [parent=#DropDownList] SetVar
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash key key
-- @param Variant#Variant value value

---
-- Function SetInternal
--
-- @function [parent=#DropDownList] SetInternal
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetTraversalMode
--
-- @function [parent=#DropDownList] SetTraversalMode
-- @param self Self reference
-- @param TraversalMode#TraversalMode traversalMode traversalMode

---
-- Function SetElementEventSender
--
-- @function [parent=#DropDownList] SetElementEventSender
-- @param self Self reference
-- @param #boolean flag flag

---
-- Function GetName
--
-- @function [parent=#DropDownList] GetName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetPosition
--
-- @function [parent=#DropDownList] GetPosition
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetSize
--
-- @function [parent=#DropDownList] GetSize
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetWidth
--
-- @function [parent=#DropDownList] GetWidth
-- @param self Self reference
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#DropDownList] GetHeight
-- @param self Self reference
-- @return #number

---
-- Function GetMinSize
--
-- @function [parent=#DropDownList] GetMinSize
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetMinWidth
--
-- @function [parent=#DropDownList] GetMinWidth
-- @param self Self reference
-- @return #number

---
-- Function GetMinHeight
--
-- @function [parent=#DropDownList] GetMinHeight
-- @param self Self reference
-- @return #number

---
-- Function GetMaxSize
--
-- @function [parent=#DropDownList] GetMaxSize
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetMaxWidth
--
-- @function [parent=#DropDownList] GetMaxWidth
-- @param self Self reference
-- @return #number

---
-- Function GetMaxHeight
--
-- @function [parent=#DropDownList] GetMaxHeight
-- @param self Self reference
-- @return #number

---
-- Function IsFixedSize
--
-- @function [parent=#DropDownList] IsFixedSize
-- @param self Self reference
-- @return #boolean

---
-- Function IsFixedWidth
--
-- @function [parent=#DropDownList] IsFixedWidth
-- @param self Self reference
-- @return #boolean

---
-- Function IsFixedHeight
--
-- @function [parent=#DropDownList] IsFixedHeight
-- @param self Self reference
-- @return #boolean

---
-- Function GetChildOffset
--
-- @function [parent=#DropDownList] GetChildOffset
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetHorizontalAlignment
--
-- @function [parent=#DropDownList] GetHorizontalAlignment
-- @param self Self reference
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetVerticalAlignment
--
-- @function [parent=#DropDownList] GetVerticalAlignment
-- @param self Self reference
-- @return VerticalAlignment#VerticalAlignment

---
-- Function GetClipBorder
--
-- @function [parent=#DropDownList] GetClipBorder
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetColor
--
-- @function [parent=#DropDownList] GetColor
-- @param self Self reference
-- @param Corner#Corner corner corner
-- @return const Color#const Color

---
-- Function GetPriority
--
-- @function [parent=#DropDownList] GetPriority
-- @param self Self reference
-- @return #number

---
-- Function GetOpacity
--
-- @function [parent=#DropDownList] GetOpacity
-- @param self Self reference
-- @return #number

---
-- Function GetDerivedOpacity
--
-- @function [parent=#DropDownList] GetDerivedOpacity
-- @param self Self reference
-- @return #number

---
-- Function GetBringToFront
--
-- @function [parent=#DropDownList] GetBringToFront
-- @param self Self reference
-- @return #boolean

---
-- Function GetBringToBack
--
-- @function [parent=#DropDownList] GetBringToBack
-- @param self Self reference
-- @return #boolean

---
-- Function GetClipChildren
--
-- @function [parent=#DropDownList] GetClipChildren
-- @param self Self reference
-- @return #boolean

---
-- Function GetSortChildren
--
-- @function [parent=#DropDownList] GetSortChildren
-- @param self Self reference
-- @return #boolean

---
-- Function GetUseDerivedOpacity
--
-- @function [parent=#DropDownList] GetUseDerivedOpacity
-- @param self Self reference
-- @return #boolean

---
-- Function HasFocus
--
-- @function [parent=#DropDownList] HasFocus
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabled
--
-- @function [parent=#DropDownList] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEditable
--
-- @function [parent=#DropDownList] IsEditable
-- @param self Self reference
-- @return #boolean

---
-- Function IsSelected
--
-- @function [parent=#DropDownList] IsSelected
-- @param self Self reference
-- @return #boolean

---
-- Function IsVisible
--
-- @function [parent=#DropDownList] IsVisible
-- @param self Self reference
-- @return #boolean

---
-- Function IsHovering
--
-- @function [parent=#DropDownList] IsHovering
-- @param self Self reference
-- @return #boolean

---
-- Function IsInternal
--
-- @function [parent=#DropDownList] IsInternal
-- @param self Self reference
-- @return #boolean

---
-- Function HasColorGradient
--
-- @function [parent=#DropDownList] HasColorGradient
-- @param self Self reference
-- @return #boolean

---
-- Function GetFocusMode
--
-- @function [parent=#DropDownList] GetFocusMode
-- @param self Self reference
-- @return FocusMode#FocusMode

---
-- Function GetDragDropMode
--
-- @function [parent=#DropDownList] GetDragDropMode
-- @param self Self reference
-- @return #number

---
-- Function GetAppliedStyle
--
-- @function [parent=#DropDownList] GetAppliedStyle
-- @param self Self reference
-- @return const String#const String

---
-- Function GetDefaultStyle
--
-- @function [parent=#DropDownList] GetDefaultStyle
-- @param self Self reference
-- @param #boolean recursiveUp recursiveUp
-- @return XMLFile#XMLFile

---
-- Function GetLayoutMode
--
-- @function [parent=#DropDownList] GetLayoutMode
-- @param self Self reference
-- @return LayoutMode#LayoutMode

---
-- Function GetLayoutSpacing
--
-- @function [parent=#DropDownList] GetLayoutSpacing
-- @param self Self reference
-- @return #number

---
-- Function GetLayoutBorder
--
-- @function [parent=#DropDownList] GetLayoutBorder
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetNumChildren
--
-- @function [parent=#DropDownList] GetNumChildren
-- @param self Self reference
-- @param #boolean recursive recursive
-- @return #number

---
-- Function GetChild
--
-- @function [parent=#DropDownList] GetChild
-- @param self Self reference
-- @param #string name name
-- @param #boolean recursive recursive
-- @return UIElement#UIElement

---
-- Function GetChild
--
-- @function [parent=#DropDownList] GetChild
-- @param self Self reference
-- @param #number index index
-- @return UIElement#UIElement

---
-- Function GetParent
--
-- @function [parent=#DropDownList] GetParent
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetRoot
--
-- @function [parent=#DropDownList] GetRoot
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetDerivedColor
--
-- @function [parent=#DropDownList] GetDerivedColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetVar
--
-- @function [parent=#DropDownList] GetVar
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash key key
-- @return const Variant#const Variant

---
-- Function GetVars
--
-- @function [parent=#DropDownList] GetVars
-- @param self Self reference
-- @return const VariantMap#const VariantMap

---
-- Function ScreenToElement
--
-- @function [parent=#DropDownList] ScreenToElement
-- @param self Self reference
-- @param IntVector2#IntVector2 screenPosition screenPosition
-- @return IntVector2#IntVector2

---
-- Function ElementToScreen
--
-- @function [parent=#DropDownList] ElementToScreen
-- @param self Self reference
-- @param IntVector2#IntVector2 position position
-- @return IntVector2#IntVector2

---
-- Function IsInside
--
-- @function [parent=#DropDownList] IsInside
-- @param self Self reference
-- @param IntVector2#IntVector2 position position
-- @param #boolean isScreen isScreen
-- @return #boolean

---
-- Function IsInsideCombined
--
-- @function [parent=#DropDownList] IsInsideCombined
-- @param self Self reference
-- @param IntVector2#IntVector2 position position
-- @param #boolean isScreen isScreen
-- @return #boolean

---
-- Function GetCombinedScreenRect
--
-- @function [parent=#DropDownList] GetCombinedScreenRect
-- @param self Self reference
-- @return IntRect#IntRect

---
-- Function SortChildren
--
-- @function [parent=#DropDownList] SortChildren
-- @param self Self reference

---
-- Function GetLayoutMinSize
--
-- @function [parent=#DropDownList] GetLayoutMinSize
-- @param self Self reference
-- @return #number

---
-- Function GetIndent
--
-- @function [parent=#DropDownList] GetIndent
-- @param self Self reference
-- @return #number

---
-- Function GetIndentSpacing
--
-- @function [parent=#DropDownList] GetIndentSpacing
-- @param self Self reference
-- @return #number

---
-- Function GetIndentWidth
--
-- @function [parent=#DropDownList] GetIndentWidth
-- @param self Self reference
-- @return #number

---
-- Function SetChildOffset
--
-- @function [parent=#DropDownList] SetChildOffset
-- @param self Self reference
-- @param IntVector2#IntVector2 offset offset

---
-- Function SetHovering
--
-- @function [parent=#DropDownList] SetHovering
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function GetColor
--
-- @function [parent=#DropDownList] GetColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetTraversalMode
--
-- @function [parent=#DropDownList] GetTraversalMode
-- @param self Self reference
-- @return TraversalMode#TraversalMode

---
-- Function IsElementEventSender
--
-- @function [parent=#DropDownList] IsElementEventSender
-- @param self Self reference
-- @return #boolean

---
-- Function GetElementEventSender
--
-- @function [parent=#DropDownList] GetElementEventSender
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Field screenPosition (Read only)
--
-- @field [parent=#DropDownList] IntVector2#IntVector2 screenPosition

---
-- Field name
--
-- @field [parent=#DropDownList] #string name

---
-- Field position
--
-- @field [parent=#DropDownList] IntVector2#IntVector2 position

---
-- Field size
--
-- @field [parent=#DropDownList] IntVector2#IntVector2 size

---
-- Field width
--
-- @field [parent=#DropDownList] #number width

---
-- Field height
--
-- @field [parent=#DropDownList] #number height

---
-- Field minSize
--
-- @field [parent=#DropDownList] IntVector2#IntVector2 minSize

---
-- Field minWidth
--
-- @field [parent=#DropDownList] #number minWidth

---
-- Field minHeight
--
-- @field [parent=#DropDownList] #number minHeight

---
-- Field maxSize
--
-- @field [parent=#DropDownList] IntVector2#IntVector2 maxSize

---
-- Field maxWidth
--
-- @field [parent=#DropDownList] #number maxWidth

---
-- Field maxHeight
--
-- @field [parent=#DropDownList] #number maxHeight

---
-- Field fixedSize (Read only)
--
-- @field [parent=#DropDownList] #boolean fixedSize

---
-- Field fixedWidth (Read only)
--
-- @field [parent=#DropDownList] #boolean fixedWidth

---
-- Field fixedHeight (Read only)
--
-- @field [parent=#DropDownList] #boolean fixedHeight

---
-- Field childOffset
--
-- @field [parent=#DropDownList] IntVector2#IntVector2 childOffset

---
-- Field horizontalAlignment
--
-- @field [parent=#DropDownList] HorizontalAlignment#HorizontalAlignment horizontalAlignment

---
-- Field verticalAlignment
--
-- @field [parent=#DropDownList] VerticalAlignment#VerticalAlignment verticalAlignment

---
-- Field clipBorder
--
-- @field [parent=#DropDownList] IntRect#IntRect clipBorder

---
-- Field color
--
-- @field [parent=#DropDownList] Color#Color color

---
-- Field priority
--
-- @field [parent=#DropDownList] #number priority

---
-- Field opacity
--
-- @field [parent=#DropDownList] #number opacity

---
-- Field derivedOpacity (Read only)
--
-- @field [parent=#DropDownList] #number derivedOpacity

---
-- Field bringToFront
--
-- @field [parent=#DropDownList] #boolean bringToFront

---
-- Field bringToBack
--
-- @field [parent=#DropDownList] #boolean bringToBack

---
-- Field clipChildren
--
-- @field [parent=#DropDownList] #boolean clipChildren

---
-- Field sortChildren
--
-- @field [parent=#DropDownList] #boolean sortChildren

---
-- Field useDerivedOpacity
--
-- @field [parent=#DropDownList] #boolean useDerivedOpacity

---
-- Field focus
--
-- @field [parent=#DropDownList] #boolean focus

---
-- Field enabled
--
-- @field [parent=#DropDownList] #boolean enabled

---
-- Field editable
--
-- @field [parent=#DropDownList] #boolean editable

---
-- Field selected
--
-- @field [parent=#DropDownList] #boolean selected

---
-- Field visible
--
-- @field [parent=#DropDownList] #boolean visible

---
-- Field hovering
--
-- @field [parent=#DropDownList] #boolean hovering

---
-- Field internal
--
-- @field [parent=#DropDownList] #boolean internal

---
-- Field colorGradient (Read only)
--
-- @field [parent=#DropDownList] #boolean colorGradient

---
-- Field focusMode
--
-- @field [parent=#DropDownList] FocusMode#FocusMode focusMode

---
-- Field dragDropMode
--
-- @field [parent=#DropDownList] #number dragDropMode

---
-- Field style
--
-- @field [parent=#DropDownList] #string style

---
-- Field defaultStyle
--
-- @field [parent=#DropDownList] XMLFile#XMLFile defaultStyle

---
-- Field layoutMode
--
-- @field [parent=#DropDownList] LayoutMode#LayoutMode layoutMode

---
-- Field layoutSpacing
--
-- @field [parent=#DropDownList] #number layoutSpacing

---
-- Field layoutBorder
--
-- @field [parent=#DropDownList] IntRect#IntRect layoutBorder

---
-- Field numChildren (Read only)
--
-- @field [parent=#DropDownList] #number numChildren

---
-- Field parent
--
-- @field [parent=#DropDownList] UIElement#UIElement parent

---
-- Field root (Read only)
--
-- @field [parent=#DropDownList] UIElement#UIElement root

---
-- Field derivedColor (Read only)
--
-- @field [parent=#DropDownList] Color#Color derivedColor

---
-- Field combinedScreenRect (Read only)
--
-- @field [parent=#DropDownList] IntRect#IntRect combinedScreenRect

---
-- Field layoutMinSize (Read only)
--
-- @field [parent=#DropDownList] #number layoutMinSize

---
-- Field indent
--
-- @field [parent=#DropDownList] #number indent

---
-- Field indentSpacing
--
-- @field [parent=#DropDownList] #number indentSpacing

---
-- Field indentWidth (Read only)
--
-- @field [parent=#DropDownList] #number indentWidth

---
-- Field traversalMode
--
-- @field [parent=#DropDownList] TraversalMode#TraversalMode traversalMode

---
-- Field elementEventSender
--
-- @field [parent=#DropDownList] #boolean elementEventSender

---
-- Function SetTemporary
--
-- @function [parent=#DropDownList] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#DropDownList] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#DropDownList] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#DropDownList] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#DropDownList] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#DropDownList] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#DropDownList] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#DropDownList] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#DropDownList] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#DropDownList] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#DropDownList] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#DropDownList] #string category


return nil
