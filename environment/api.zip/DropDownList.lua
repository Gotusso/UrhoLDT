---
-- Module DropDownList
-- extends Menu
--
-- @module DropDownList

---
-- Function DropDownList
--
-- @function [parent=#DropDownList] DropDownList

---
-- Function new
--
-- @function [parent=#DropDownList] new
-- @return DropDownList#DropDownList

---
-- Function delete
--
-- @function [parent=#DropDownList] delete

---
-- Function AddItem
--
-- @function [parent=#DropDownList] AddItem
-- @param UIElement#UIElement itemitem

---
-- Function InsertItem
--
-- @function [parent=#DropDownList] InsertItem
-- @param #number indexindex
-- @param UIElement#UIElement itemitem

---
-- Function RemoveItem
--
-- @function [parent=#DropDownList] RemoveItem
-- @param UIElement#UIElement itemitem

---
-- Function RemoveItem
--
-- @function [parent=#DropDownList] RemoveItem
-- @param #number indexindex

---
-- Function RemoveAllItems
--
-- @function [parent=#DropDownList] RemoveAllItems

---
-- Function SetSelection
--
-- @function [parent=#DropDownList] SetSelection
-- @param #number indexindex

---
-- Function SetPlaceholderText
--
-- @function [parent=#DropDownList] SetPlaceholderText
-- @param #string texttext

---
-- Function SetResizePopup
--
-- @function [parent=#DropDownList] SetResizePopup
-- @param #boolean enableenable

---
-- Function GetNumItems
--
-- @function [parent=#DropDownList] GetNumItems
-- @return #number

---
-- Function GetItem
--
-- @function [parent=#DropDownList] GetItem
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function GetItems
--
-- @function [parent=#DropDownList] GetItems
-- @return const PODVector<UIElement*>#const PODVector<UIElement*>

---
-- Function GetSelection
--
-- @function [parent=#DropDownList] GetSelection
-- @return #number

---
-- Function GetSelectedItem
--
-- @function [parent=#DropDownList] GetSelectedItem
-- @return UIElement#UIElement

---
-- Function GetListView
--
-- @function [parent=#DropDownList] GetListView
-- @return ListView#ListView

---
-- Function GetPlaceholder
--
-- @function [parent=#DropDownList] GetPlaceholder
-- @return UIElement#UIElement

---
-- Function GetPlaceholderText
--
-- @function [parent=#DropDownList] GetPlaceholderText
-- @return const String#const String

---
-- Function GetResizePopup
--
-- @function [parent=#DropDownList] GetResizePopup
-- @return #boolean

---
-- Field numItems (Read only)
--
-- @field [parent=#DropDownList] #number numItems

---
-- Field selection
--
-- @field [parent=#DropDownList] #number selection

---
-- Field selectedItem (Read only)
--
-- @field [parent=#DropDownList] UIElement#UIElement selectedItem

---
-- Field listView (Read only)
--
-- @field [parent=#DropDownList] ListView#ListView listView

---
-- Field placeholder (Read only)
--
-- @field [parent=#DropDownList] UIElement#UIElement placeholder

---
-- Field placeholderText
--
-- @field [parent=#DropDownList] #string placeholderText

---
-- Field resizePopup
--
-- @field [parent=#DropDownList] #boolean resizePopup

---
-- Function Menu
--
-- @function [parent=#DropDownList] Menu

---
-- Function new
--
-- @function [parent=#DropDownList] new
-- @return Menu#Menu

---
-- Function delete
--
-- @function [parent=#DropDownList] delete

---
-- Function SetPopup
--
-- @function [parent=#DropDownList] SetPopup
-- @param UIElement#UIElement elementelement

---
-- Function SetPopupOffset
--
-- @function [parent=#DropDownList] SetPopupOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetPopupOffset
--
-- @function [parent=#DropDownList] SetPopupOffset
-- @param #number xx
-- @param #number yy

---
-- Function ShowPopup
--
-- @function [parent=#DropDownList] ShowPopup
-- @param #boolean enableenable

---
-- Function SetAccelerator
--
-- @function [parent=#DropDownList] SetAccelerator
-- @param #number keykey
-- @param #number qualifiersqualifiers

---
-- Function GetPopup
--
-- @function [parent=#DropDownList] GetPopup
-- @return UIElement#UIElement

---
-- Function GetPopupOffset
--
-- @function [parent=#DropDownList] GetPopupOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetShowPopup
--
-- @function [parent=#DropDownList] GetShowPopup
-- @return #boolean

---
-- Function GetAcceleratorKey
--
-- @function [parent=#DropDownList] GetAcceleratorKey
-- @return #number

---
-- Function GetAcceleratorQualifiers
--
-- @function [parent=#DropDownList] GetAcceleratorQualifiers
-- @return #number

---
-- Field popup
--
-- @field [parent=#DropDownList] UIElement#UIElement popup

---
-- Field popupOffset
--
-- @field [parent=#DropDownList] IntVector2#IntVector2 popupOffset

---
-- Field showPopup
--
-- @field [parent=#DropDownList] #boolean showPopup

---
-- Field acceleratorKey (Read only)
--
-- @field [parent=#DropDownList] #number acceleratorKey

---
-- Field acceleratorQualifiers (Read only)
--
-- @field [parent=#DropDownList] #number acceleratorQualifiers

---
-- Function Button
--
-- @function [parent=#DropDownList] Button

---
-- Function new
--
-- @function [parent=#DropDownList] new
-- @return Button#Button

---
-- Function delete
--
-- @function [parent=#DropDownList] delete

---
-- Function SetPressedOffset
--
-- @function [parent=#DropDownList] SetPressedOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetPressedOffset
--
-- @function [parent=#DropDownList] SetPressedOffset
-- @param #number xx
-- @param #number yy

---
-- Function SetPressedChildOffset
--
-- @function [parent=#DropDownList] SetPressedChildOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetPressedChildOffset
--
-- @function [parent=#DropDownList] SetPressedChildOffset
-- @param #number xx
-- @param #number yy

---
-- Function SetRepeat
--
-- @function [parent=#DropDownList] SetRepeat
-- @param #number delaydelay
-- @param #number raterate

---
-- Function SetRepeatDelay
--
-- @function [parent=#DropDownList] SetRepeatDelay
-- @param #number delaydelay

---
-- Function SetRepeatRate
--
-- @function [parent=#DropDownList] SetRepeatRate
-- @param #number raterate

---
-- Function GetPressedOffset
--
-- @function [parent=#DropDownList] GetPressedOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetPressedChildOffset
--
-- @function [parent=#DropDownList] GetPressedChildOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetRepeatDelay
--
-- @function [parent=#DropDownList] GetRepeatDelay
-- @return #number

---
-- Function GetRepeatRate
--
-- @function [parent=#DropDownList] GetRepeatRate
-- @return #number

---
-- Function IsPressed
--
-- @function [parent=#DropDownList] IsPressed
-- @return #boolean

---
-- Field pressedOffset
--
-- @field [parent=#DropDownList] IntVector2#IntVector2 pressedOffset

---
-- Field pressedChildOffset
--
-- @field [parent=#DropDownList] IntVector2#IntVector2 pressedChildOffset

---
-- Field repeatDelay
--
-- @field [parent=#DropDownList] #number repeatDelay

---
-- Field repeatRate
--
-- @field [parent=#DropDownList] #number repeatRate

---
-- Field pressed (Read only)
--
-- @field [parent=#DropDownList] #boolean pressed

---
-- Function BorderImage
--
-- @function [parent=#DropDownList] BorderImage

---
-- Function new
--
-- @function [parent=#DropDownList] new
-- @return BorderImage#BorderImage

---
-- Function delete
--
-- @function [parent=#DropDownList] delete

---
-- Function SetTexture
--
-- @function [parent=#DropDownList] SetTexture
-- @param Texture#Texture texturetexture

---
-- Function SetImageRect
--
-- @function [parent=#DropDownList] SetImageRect
-- @param IntRect#IntRect rectrect

---
-- Function SetFullImageRect
--
-- @function [parent=#DropDownList] SetFullImageRect

---
-- Function SetBorder
--
-- @function [parent=#DropDownList] SetBorder
-- @param IntRect#IntRect rectrect

---
-- Function SetHoverOffset
--
-- @function [parent=#DropDownList] SetHoverOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetHoverOffset
--
-- @function [parent=#DropDownList] SetHoverOffset
-- @param #number xx
-- @param #number yy

---
-- Function SetBlendMode
--
-- @function [parent=#DropDownList] SetBlendMode
-- @param BlendMode#BlendMode modemode

---
-- Function SetTiled
--
-- @function [parent=#DropDownList] SetTiled
-- @param #boolean enableenable

---
-- Function GetTexture
--
-- @function [parent=#DropDownList] GetTexture
-- @return Texture#Texture

---
-- Function GetImageRect
--
-- @function [parent=#DropDownList] GetImageRect
-- @return const IntRect#const IntRect

---
-- Function GetBorder
--
-- @function [parent=#DropDownList] GetBorder
-- @return const IntRect#const IntRect

---
-- Function GetHoverOffset
--
-- @function [parent=#DropDownList] GetHoverOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetBlendMode
--
-- @function [parent=#DropDownList] GetBlendMode
-- @return BlendMode#BlendMode

---
-- Function IsTiled
--
-- @function [parent=#DropDownList] IsTiled
-- @return #boolean

---
-- Field texture
--
-- @field [parent=#DropDownList] Texture#Texture texture

---
-- Field imageRect
--
-- @field [parent=#DropDownList] IntRect#IntRect imageRect

---
-- Field border
--
-- @field [parent=#DropDownList] IntRect#IntRect border

---
-- Field hoverOffset
--
-- @field [parent=#DropDownList] IntVector2#IntVector2 hoverOffset

---
-- Field blendMode
--
-- @field [parent=#DropDownList] BlendMode#BlendMode blendMode

---
-- Field tiled
--
-- @field [parent=#DropDownList] #boolean tiled

---
-- Function UIElement
--
-- @function [parent=#DropDownList] UIElement

---
-- Function new
--
-- @function [parent=#DropDownList] new
-- @return UIElement#UIElement

---
-- Function delete
--
-- @function [parent=#DropDownList] delete

---
-- Function GetScreenPosition
--
-- @function [parent=#DropDownList] GetScreenPosition
-- @return const IntVector2#const IntVector2

---
-- Function LoadXML
--
-- @function [parent=#DropDownList] LoadXML
-- @param Deserializer#Deserializer sourcesource
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#DropDownList] SaveXML
-- @param Serializer#Serializer destdest
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#DropDownList] LoadXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#DropDownList] SaveXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function FilterAttributes
--
-- @function [parent=#DropDownList] FilterAttributes
-- @param XMLElement#XMLElement destdest
-- @return #boolean

---
-- Function SetName
--
-- @function [parent=#DropDownList] SetName
-- @param #string namename

---
-- Function SetPosition
--
-- @function [parent=#DropDownList] SetPosition
-- @param IntVector2#IntVector2 positionposition

---
-- Function SetPosition
--
-- @function [parent=#DropDownList] SetPosition
-- @param #number xx
-- @param #number yy

---
-- Function SetSize
--
-- @function [parent=#DropDownList] SetSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function SetSize
--
-- @function [parent=#DropDownList] SetSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetWidth
--
-- @function [parent=#DropDownList] SetWidth
-- @param #number widthwidth

---
-- Function SetHeight
--
-- @function [parent=#DropDownList] SetHeight
-- @param #number heightheight

---
-- Function SetMinSize
--
-- @function [parent=#DropDownList] SetMinSize
-- @param IntVector2#IntVector2 minSizeminSize

---
-- Function SetMinSize
--
-- @function [parent=#DropDownList] SetMinSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetMinWidth
--
-- @function [parent=#DropDownList] SetMinWidth
-- @param #number widthwidth

---
-- Function SetMinHeight
--
-- @function [parent=#DropDownList] SetMinHeight
-- @param #number heightheight

---
-- Function SetMaxSize
--
-- @function [parent=#DropDownList] SetMaxSize
-- @param IntVector2#IntVector2 maxSizemaxSize

---
-- Function SetMaxSize
--
-- @function [parent=#DropDownList] SetMaxSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetMaxWidth
--
-- @function [parent=#DropDownList] SetMaxWidth
-- @param #number widthwidth

---
-- Function SetMaxHeight
--
-- @function [parent=#DropDownList] SetMaxHeight
-- @param #number heightheight

---
-- Function SetFixedSize
--
-- @function [parent=#DropDownList] SetFixedSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function SetFixedSize
--
-- @function [parent=#DropDownList] SetFixedSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetFixedWidth
--
-- @function [parent=#DropDownList] SetFixedWidth
-- @param #number widthwidth

---
-- Function SetFixedHeight
--
-- @function [parent=#DropDownList] SetFixedHeight
-- @param #number heightheight

---
-- Function SetAlignment
--
-- @function [parent=#DropDownList] SetAlignment
-- @param HorizontalAlignment#HorizontalAlignment hAlignhAlign
-- @param VerticalAlignment#VerticalAlignment vAlignvAlign

---
-- Function SetHorizontalAlignment
--
-- @function [parent=#DropDownList] SetHorizontalAlignment
-- @param HorizontalAlignment#HorizontalAlignment alignalign

---
-- Function SetVerticalAlignment
--
-- @function [parent=#DropDownList] SetVerticalAlignment
-- @param VerticalAlignment#VerticalAlignment alignalign

---
-- Function SetClipBorder
--
-- @function [parent=#DropDownList] SetClipBorder
-- @param IntRect#IntRect rectrect

---
-- Function SetColor
--
-- @function [parent=#DropDownList] SetColor
-- @param Color#Color colorcolor

---
-- Function SetColor
--
-- @function [parent=#DropDownList] SetColor
-- @param Corner#Corner cornercorner
-- @param Color#Color colorcolor

---
-- Function SetPriority
--
-- @function [parent=#DropDownList] SetPriority
-- @param #number prioritypriority

---
-- Function SetOpacity
--
-- @function [parent=#DropDownList] SetOpacity
-- @param #number opacityopacity

---
-- Function SetBringToFront
--
-- @function [parent=#DropDownList] SetBringToFront
-- @param #boolean enableenable

---
-- Function SetBringToBack
--
-- @function [parent=#DropDownList] SetBringToBack
-- @param #boolean enableenable

---
-- Function SetClipChildren
--
-- @function [parent=#DropDownList] SetClipChildren
-- @param #boolean enableenable

---
-- Function SetSortChildren
--
-- @function [parent=#DropDownList] SetSortChildren
-- @param #boolean enableenable

---
-- Function SetUseDerivedOpacity
--
-- @function [parent=#DropDownList] SetUseDerivedOpacity
-- @param #boolean enableenable

---
-- Function SetEnabled
--
-- @function [parent=#DropDownList] SetEnabled
-- @param #boolean enableenable

---
-- Function SetEditable
--
-- @function [parent=#DropDownList] SetEditable
-- @param #boolean enableenable

---
-- Function SetFocus
--
-- @function [parent=#DropDownList] SetFocus
-- @param #boolean enableenable

---
-- Function SetSelected
--
-- @function [parent=#DropDownList] SetSelected
-- @param #boolean enableenable

---
-- Function SetVisible
--
-- @function [parent=#DropDownList] SetVisible
-- @param #boolean enableenable

---
-- Function SetFocusMode
--
-- @function [parent=#DropDownList] SetFocusMode
-- @param FocusMode#FocusMode modemode

---
-- Function SetDragDropMode
--
-- @function [parent=#DropDownList] SetDragDropMode
-- @param #number modemode

---
-- Function SetStyle
--
-- @function [parent=#DropDownList] SetStyle
-- @param #string styleNamestyleName
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetStyle
--
-- @function [parent=#DropDownList] SetStyle
-- @param XMLElement#XMLElement elementelement
-- @return #boolean

---
-- Function SetStyleAuto
--
-- @function [parent=#DropDownList] SetStyleAuto
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetDefaultStyle
--
-- @function [parent=#DropDownList] SetDefaultStyle
-- @param XMLFile#XMLFile stylestyle

---
-- Function SetLayout
--
-- @function [parent=#DropDownList] SetLayout
-- @param LayoutMode#LayoutMode modemode
-- @param #number spacingspacing

---
-- Function SetLayout
--
-- @function [parent=#DropDownList] SetLayout
-- @param LayoutMode#LayoutMode modemode
-- @param #number spacingspacing
-- @param IntRect#IntRect borderborder

---
-- Function SetLayoutMode
--
-- @function [parent=#DropDownList] SetLayoutMode
-- @param LayoutMode#LayoutMode modemode

---
-- Function SetLayoutSpacing
--
-- @function [parent=#DropDownList] SetLayoutSpacing
-- @param #number spacingspacing

---
-- Function SetLayoutBorder
--
-- @function [parent=#DropDownList] SetLayoutBorder
-- @param IntRect#IntRect borderborder

---
-- Function SetIndent
--
-- @function [parent=#DropDownList] SetIndent
-- @param #number indentindent

---
-- Function SetIndentSpacing
--
-- @function [parent=#DropDownList] SetIndentSpacing
-- @param #number indentSpacingindentSpacing

---
-- Function UpdateLayout
--
-- @function [parent=#DropDownList] UpdateLayout

---
-- Function DisableLayoutUpdate
--
-- @function [parent=#DropDownList] DisableLayoutUpdate

---
-- Function EnableLayoutUpdate
--
-- @function [parent=#DropDownList] EnableLayoutUpdate

---
-- Function BringToFront
--
-- @function [parent=#DropDownList] BringToFront

---
-- Function CreateChild
--
-- @function [parent=#DropDownList] CreateChild
-- @param #string typetype
-- @param #string namename
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function AddChild
--
-- @function [parent=#DropDownList] AddChild
-- @param UIElement#UIElement elementelement

---
-- Function InsertChild
--
-- @function [parent=#DropDownList] InsertChild
-- @param #number indexindex
-- @param UIElement#UIElement elementelement

---
-- Function RemoveChild
--
-- @function [parent=#DropDownList] RemoveChild
-- @param UIElement#UIElement elementelement
-- @param #number indexindex

---
-- Function RemoveChildAtIndex
--
-- @function [parent=#DropDownList] RemoveChildAtIndex
-- @param #number indexindex

---
-- Function RemoveAllChildren
--
-- @function [parent=#DropDownList] RemoveAllChildren

---
-- Function Remove
--
-- @function [parent=#DropDownList] Remove

---
-- Function FindChild
--
-- @function [parent=#DropDownList] FindChild
-- @param UIElement#UIElement elementelement
-- @return #number

---
-- Function SetParent
--
-- @function [parent=#DropDownList] SetParent
-- @param UIElement#UIElement parentparent
-- @param #number indexindex

---
-- Function SetVar
--
-- @function [parent=#DropDownList] SetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @param Variant#Variant valuevalue

---
-- Function SetInternal
--
-- @function [parent=#DropDownList] SetInternal
-- @param #boolean enableenable

---
-- Function SetTraversalMode
--
-- @function [parent=#DropDownList] SetTraversalMode
-- @param TraversalMode#TraversalMode traversalModetraversalMode

---
-- Function SetElementEventSender
--
-- @function [parent=#DropDownList] SetElementEventSender
-- @param #boolean flagflag

---
-- Function GetName
--
-- @function [parent=#DropDownList] GetName
-- @return const String#const String

---
-- Function GetPosition
--
-- @function [parent=#DropDownList] GetPosition
-- @return const IntVector2#const IntVector2

---
-- Function GetSize
--
-- @function [parent=#DropDownList] GetSize
-- @return const IntVector2#const IntVector2

---
-- Function GetWidth
--
-- @function [parent=#DropDownList] GetWidth
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#DropDownList] GetHeight
-- @return #number

---
-- Function GetMinSize
--
-- @function [parent=#DropDownList] GetMinSize
-- @return const IntVector2#const IntVector2

---
-- Function GetMinWidth
--
-- @function [parent=#DropDownList] GetMinWidth
-- @return #number

---
-- Function GetMinHeight
--
-- @function [parent=#DropDownList] GetMinHeight
-- @return #number

---
-- Function GetMaxSize
--
-- @function [parent=#DropDownList] GetMaxSize
-- @return const IntVector2#const IntVector2

---
-- Function GetMaxWidth
--
-- @function [parent=#DropDownList] GetMaxWidth
-- @return #number

---
-- Function GetMaxHeight
--
-- @function [parent=#DropDownList] GetMaxHeight
-- @return #number

---
-- Function IsFixedSize
--
-- @function [parent=#DropDownList] IsFixedSize
-- @return #boolean

---
-- Function IsFixedWidth
--
-- @function [parent=#DropDownList] IsFixedWidth
-- @return #boolean

---
-- Function IsFixedHeight
--
-- @function [parent=#DropDownList] IsFixedHeight
-- @return #boolean

---
-- Function GetChildOffset
--
-- @function [parent=#DropDownList] GetChildOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetHorizontalAlignment
--
-- @function [parent=#DropDownList] GetHorizontalAlignment
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetVerticalAlignment
--
-- @function [parent=#DropDownList] GetVerticalAlignment
-- @return VerticalAlignment#VerticalAlignment

---
-- Function GetClipBorder
--
-- @function [parent=#DropDownList] GetClipBorder
-- @return const IntRect#const IntRect

---
-- Function GetColor
--
-- @function [parent=#DropDownList] GetColor
-- @param Corner#Corner cornercorner
-- @return const Color#const Color

---
-- Function GetPriority
--
-- @function [parent=#DropDownList] GetPriority
-- @return #number

---
-- Function GetOpacity
--
-- @function [parent=#DropDownList] GetOpacity
-- @return #number

---
-- Function GetDerivedOpacity
--
-- @function [parent=#DropDownList] GetDerivedOpacity
-- @return #number

---
-- Function GetBringToFront
--
-- @function [parent=#DropDownList] GetBringToFront
-- @return #boolean

---
-- Function GetBringToBack
--
-- @function [parent=#DropDownList] GetBringToBack
-- @return #boolean

---
-- Function GetClipChildren
--
-- @function [parent=#DropDownList] GetClipChildren
-- @return #boolean

---
-- Function GetSortChildren
--
-- @function [parent=#DropDownList] GetSortChildren
-- @return #boolean

---
-- Function GetUseDerivedOpacity
--
-- @function [parent=#DropDownList] GetUseDerivedOpacity
-- @return #boolean

---
-- Function HasFocus
--
-- @function [parent=#DropDownList] HasFocus
-- @return #boolean

---
-- Function IsEnabled
--
-- @function [parent=#DropDownList] IsEnabled
-- @return #boolean

---
-- Function IsEditable
--
-- @function [parent=#DropDownList] IsEditable
-- @return #boolean

---
-- Function IsSelected
--
-- @function [parent=#DropDownList] IsSelected
-- @return #boolean

---
-- Function IsVisible
--
-- @function [parent=#DropDownList] IsVisible
-- @return #boolean

---
-- Function IsHovering
--
-- @function [parent=#DropDownList] IsHovering
-- @return #boolean

---
-- Function IsInternal
--
-- @function [parent=#DropDownList] IsInternal
-- @return #boolean

---
-- Function HasColorGradient
--
-- @function [parent=#DropDownList] HasColorGradient
-- @return #boolean

---
-- Function GetFocusMode
--
-- @function [parent=#DropDownList] GetFocusMode
-- @return FocusMode#FocusMode

---
-- Function GetDragDropMode
--
-- @function [parent=#DropDownList] GetDragDropMode
-- @return #number

---
-- Function GetAppliedStyle
--
-- @function [parent=#DropDownList] GetAppliedStyle
-- @return const String#const String

---
-- Function GetDefaultStyle
--
-- @function [parent=#DropDownList] GetDefaultStyle
-- @param #boolean recursiveUprecursiveUp
-- @return XMLFile#XMLFile

---
-- Function GetLayoutMode
--
-- @function [parent=#DropDownList] GetLayoutMode
-- @return LayoutMode#LayoutMode

---
-- Function GetLayoutSpacing
--
-- @function [parent=#DropDownList] GetLayoutSpacing
-- @return #number

---
-- Function GetLayoutBorder
--
-- @function [parent=#DropDownList] GetLayoutBorder
-- @return const IntRect#const IntRect

---
-- Function GetNumChildren
--
-- @function [parent=#DropDownList] GetNumChildren
-- @param #boolean recursiverecursive
-- @return #number

---
-- Function GetChild
--
-- @function [parent=#DropDownList] GetChild
-- @param #string namename
-- @param #boolean recursiverecursive
-- @return UIElement#UIElement

---
-- Function GetChild
--
-- @function [parent=#DropDownList] GetChild
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function GetParent
--
-- @function [parent=#DropDownList] GetParent
-- @return UIElement#UIElement

---
-- Function GetRoot
--
-- @function [parent=#DropDownList] GetRoot
-- @return UIElement#UIElement

---
-- Function GetDerivedColor
--
-- @function [parent=#DropDownList] GetDerivedColor
-- @return const Color#const Color

---
-- Function GetVar
--
-- @function [parent=#DropDownList] GetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @return const Variant#const Variant

---
-- Function GetVars
--
-- @function [parent=#DropDownList] GetVars
-- @return const VariantMap#const VariantMap

---
-- Function ScreenToElement
--
-- @function [parent=#DropDownList] ScreenToElement
-- @param IntVector2#IntVector2 screenPositionscreenPosition
-- @return IntVector2#IntVector2

---
-- Function ElementToScreen
--
-- @function [parent=#DropDownList] ElementToScreen
-- @param IntVector2#IntVector2 positionposition
-- @return IntVector2#IntVector2

---
-- Function IsInside
--
-- @function [parent=#DropDownList] IsInside
-- @param IntVector2#IntVector2 positionposition
-- @param #boolean isScreenisScreen
-- @return #boolean

---
-- Function IsInsideCombined
--
-- @function [parent=#DropDownList] IsInsideCombined
-- @param IntVector2#IntVector2 positionposition
-- @param #boolean isScreenisScreen
-- @return #boolean

---
-- Function GetCombinedScreenRect
--
-- @function [parent=#DropDownList] GetCombinedScreenRect
-- @return IntRect#IntRect

---
-- Function SortChildren
--
-- @function [parent=#DropDownList] SortChildren

---
-- Function GetLayoutMinSize
--
-- @function [parent=#DropDownList] GetLayoutMinSize
-- @return #number

---
-- Function GetIndent
--
-- @function [parent=#DropDownList] GetIndent
-- @return #number

---
-- Function GetIndentSpacing
--
-- @function [parent=#DropDownList] GetIndentSpacing
-- @return #number

---
-- Function GetIndentWidth
--
-- @function [parent=#DropDownList] GetIndentWidth
-- @return #number

---
-- Function SetChildOffset
--
-- @function [parent=#DropDownList] SetChildOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetHovering
--
-- @function [parent=#DropDownList] SetHovering
-- @param #boolean enableenable

---
-- Function GetColor
--
-- @function [parent=#DropDownList] GetColor
-- @return const Color#const Color

---
-- Function GetTraversalMode
--
-- @function [parent=#DropDownList] GetTraversalMode
-- @return TraversalMode#TraversalMode

---
-- Function IsElementEventSender
--
-- @function [parent=#DropDownList] IsElementEventSender
-- @return #boolean

---
-- Function GetElementEventSender
--
-- @function [parent=#DropDownList] GetElementEventSender
-- @return UIElement#UIElement

---
-- Field screenPosition (Read only)
--
-- @field [parent=#DropDownList] IntVector2#IntVector2 screenPosition

---
-- Field name
--
-- @field [parent=#DropDownList] #string name

---
-- Field position
--
-- @field [parent=#DropDownList] IntVector2#IntVector2 position

---
-- Field size
--
-- @field [parent=#DropDownList] IntVector2#IntVector2 size

---
-- Field width
--
-- @field [parent=#DropDownList] #number width

---
-- Field height
--
-- @field [parent=#DropDownList] #number height

---
-- Field minSize
--
-- @field [parent=#DropDownList] IntVector2#IntVector2 minSize

---
-- Field minWidth
--
-- @field [parent=#DropDownList] #number minWidth

---
-- Field minHeight
--
-- @field [parent=#DropDownList] #number minHeight

---
-- Field maxSize
--
-- @field [parent=#DropDownList] IntVector2#IntVector2 maxSize

---
-- Field maxWidth
--
-- @field [parent=#DropDownList] #number maxWidth

---
-- Field maxHeight
--
-- @field [parent=#DropDownList] #number maxHeight

---
-- Field fixedSize (Read only)
--
-- @field [parent=#DropDownList] #boolean fixedSize

---
-- Field fixedWidth (Read only)
--
-- @field [parent=#DropDownList] #boolean fixedWidth

---
-- Field fixedHeight (Read only)
--
-- @field [parent=#DropDownList] #boolean fixedHeight

---
-- Field childOffset
--
-- @field [parent=#DropDownList] IntVector2#IntVector2 childOffset

---
-- Field horizontalAlignment
--
-- @field [parent=#DropDownList] HorizontalAlignment#HorizontalAlignment horizontalAlignment

---
-- Field verticalAlignment
--
-- @field [parent=#DropDownList] VerticalAlignment#VerticalAlignment verticalAlignment

---
-- Field clipBorder
--
-- @field [parent=#DropDownList] IntRect#IntRect clipBorder

---
-- Field color
--
-- @field [parent=#DropDownList] Color#Color color

---
-- Field priority
--
-- @field [parent=#DropDownList] #number priority

---
-- Field opacity
--
-- @field [parent=#DropDownList] #number opacity

---
-- Field derivedOpacity (Read only)
--
-- @field [parent=#DropDownList] #number derivedOpacity

---
-- Field bringToFront
--
-- @field [parent=#DropDownList] #boolean bringToFront

---
-- Field bringToBack
--
-- @field [parent=#DropDownList] #boolean bringToBack

---
-- Field clipChildren
--
-- @field [parent=#DropDownList] #boolean clipChildren

---
-- Field sortChildren
--
-- @field [parent=#DropDownList] #boolean sortChildren

---
-- Field useDerivedOpacity
--
-- @field [parent=#DropDownList] #boolean useDerivedOpacity

---
-- Field focus
--
-- @field [parent=#DropDownList] #boolean focus

---
-- Field enabled
--
-- @field [parent=#DropDownList] #boolean enabled

---
-- Field editable
--
-- @field [parent=#DropDownList] #boolean editable

---
-- Field selected
--
-- @field [parent=#DropDownList] #boolean selected

---
-- Field visible
--
-- @field [parent=#DropDownList] #boolean visible

---
-- Field hovering
--
-- @field [parent=#DropDownList] #boolean hovering

---
-- Field internal
--
-- @field [parent=#DropDownList] #boolean internal

---
-- Field colorGradient (Read only)
--
-- @field [parent=#DropDownList] #boolean colorGradient

---
-- Field focusMode
--
-- @field [parent=#DropDownList] FocusMode#FocusMode focusMode

---
-- Field dragDropMode
--
-- @field [parent=#DropDownList] #number dragDropMode

---
-- Field style
--
-- @field [parent=#DropDownList] #string style

---
-- Field defaultStyle
--
-- @field [parent=#DropDownList] XMLFile#XMLFile defaultStyle

---
-- Field layoutMode
--
-- @field [parent=#DropDownList] LayoutMode#LayoutMode layoutMode

---
-- Field layoutSpacing
--
-- @field [parent=#DropDownList] #number layoutSpacing

---
-- Field layoutBorder
--
-- @field [parent=#DropDownList] IntRect#IntRect layoutBorder

---
-- Field numChildren (Read only)
--
-- @field [parent=#DropDownList] #number numChildren

---
-- Field parent
--
-- @field [parent=#DropDownList] UIElement#UIElement parent

---
-- Field root (Read only)
--
-- @field [parent=#DropDownList] UIElement#UIElement root

---
-- Field derivedColor (Read only)
--
-- @field [parent=#DropDownList] Color#Color derivedColor

---
-- Field combinedScreenRect (Read only)
--
-- @field [parent=#DropDownList] IntRect#IntRect combinedScreenRect

---
-- Field layoutMinSize (Read only)
--
-- @field [parent=#DropDownList] #number layoutMinSize

---
-- Field indent
--
-- @field [parent=#DropDownList] #number indent

---
-- Field indentSpacing
--
-- @field [parent=#DropDownList] #number indentSpacing

---
-- Field indentWidth (Read only)
--
-- @field [parent=#DropDownList] #number indentWidth

---
-- Field traversalMode
--
-- @field [parent=#DropDownList] TraversalMode#TraversalMode traversalMode

---
-- Field elementEventSender
--
-- @field [parent=#DropDownList] #boolean elementEventSender

---
-- Function SetTemporary
--
-- @function [parent=#DropDownList] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#DropDownList] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#DropDownList] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#DropDownList] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#DropDownList] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#DropDownList] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#DropDownList] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#DropDownList] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#DropDownList] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#DropDownList] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#DropDownList] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#DropDownList] #string category


return nil
