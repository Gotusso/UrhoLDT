---
-- Module Plane
--
-- @module Plane

---
-- Function Plane
--
-- @function [parent=#Plane] Plane

---
-- Function new
--
-- @function [parent=#Plane] new
-- @return Plane#Plane

---
-- Function Plane
--
-- @function [parent=#Plane] Plane
-- @param Plane#Plane planeplane

---
-- Function new
--
-- @function [parent=#Plane] new
-- @param Plane#Plane planeplane
-- @return Plane#Plane

---
-- Function Plane
--
-- @function [parent=#Plane] Plane
-- @param Vector3#Vector3 v0v0
-- @param Vector3#Vector3 v1v1
-- @param Vector3#Vector3 v2v2

---
-- Function new
--
-- @function [parent=#Plane] new
-- @param Vector3#Vector3 v0v0
-- @param Vector3#Vector3 v1v1
-- @param Vector3#Vector3 v2v2
-- @return Plane#Plane

---
-- Function Plane
--
-- @function [parent=#Plane] Plane
-- @param Vector3#Vector3 normalnormal
-- @param Vector3#Vector3 pointpoint

---
-- Function new
--
-- @function [parent=#Plane] new
-- @param Vector3#Vector3 normalnormal
-- @param Vector3#Vector3 pointpoint
-- @return Plane#Plane

---
-- Function Plane
--
-- @function [parent=#Plane] Plane
-- @param Vector4#Vector4 planeplane

---
-- Function new
--
-- @function [parent=#Plane] new
-- @param Vector4#Vector4 planeplane
-- @return Plane#Plane

---
-- Function delete
--
-- @function [parent=#Plane] delete

---
-- Function Define
--
-- @function [parent=#Plane] Define
-- @param Vector3#Vector3 v0v0
-- @param Vector3#Vector3 v1v1
-- @param Vector3#Vector3 v2v2

---
-- Function Define
--
-- @function [parent=#Plane] Define
-- @param Vector3#Vector3 normalnormal
-- @param Vector3#Vector3 pointpoint

---
-- Function Define
--
-- @function [parent=#Plane] Define
-- @param Vector4#Vector4 planeplane

---
-- Function Transform
--
-- @function [parent=#Plane] Transform
-- @param Matrix3#Matrix3 transformtransform

---
-- Function Transform
--
-- @function [parent=#Plane] Transform
-- @param Matrix3x4#Matrix3x4 transformtransform

---
-- Function Transform
--
-- @function [parent=#Plane] Transform
-- @param Matrix4#Matrix4 transformtransform

---
-- Function Distance
--
-- @function [parent=#Plane] Distance
-- @param Vector3#Vector3 pointpoint
-- @return #number

---
-- Function Reflect
--
-- @function [parent=#Plane] Reflect
-- @param Vector3#Vector3 directiondirection
-- @return Vector3#Vector3

---
-- Function ReflectionMatrix
--
-- @function [parent=#Plane] ReflectionMatrix
-- @return Matrix3x4#Matrix3x4

---
-- Function Transformed
--
-- @function [parent=#Plane] Transformed
-- @param Matrix3#Matrix3 transformtransform
-- @return Plane#Plane

---
-- Function Transformed
--
-- @function [parent=#Plane] Transformed
-- @param Matrix3x4#Matrix3x4 transformtransform
-- @return Plane#Plane

---
-- Function Transformed
--
-- @function [parent=#Plane] Transformed
-- @param Matrix4#Matrix4 transformtransform
-- @return Plane#Plane

---
-- Function ToVector4
--
-- @function [parent=#Plane] ToVector4
-- @return Vector4#Vector4

---
-- Field normal
--
-- @field [parent=#Plane] Vector3#Vector3 normal

---
-- Field absNormal
--
-- @field [parent=#Plane] Vector3#Vector3 absNormal

---
-- Field d
--
-- @field [parent=#Plane] #number d

---
-- Field UP
--
-- @field [parent=#Plane] Plane#Plane UP


return nil
