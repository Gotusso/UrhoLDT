---
-- Module Plane
-- Generated on 2014-05-31
--
-- @module Plane

---
-- Function Plane()
-- Construct a degenerate plane with zero normal and parameter.
--
-- @function [parent=#Plane] Plane
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#Plane] new
-- @param self Self reference
-- @return Plane#Plane

---
-- Function Plane()
--
-- @function [parent=#Plane] Plane
-- @param self Self reference
-- @param Plane#Plane plane plane

---
-- Function new()
--
-- @function [parent=#Plane] new
-- @param self Self reference
-- @param Plane#Plane plane plane
-- @return Plane#Plane

---
-- Function Plane()
--
-- @function [parent=#Plane] Plane
-- @param self Self reference
-- @param Vector3#Vector3 v0 v0
-- @param Vector3#Vector3 v1 v1
-- @param Vector3#Vector3 v2 v2

---
-- Function new()
--
-- @function [parent=#Plane] new
-- @param self Self reference
-- @param Vector3#Vector3 v0 v0
-- @param Vector3#Vector3 v1 v1
-- @param Vector3#Vector3 v2 v2
-- @return Plane#Plane

---
-- Function Plane()
--
-- @function [parent=#Plane] Plane
-- @param self Self reference
-- @param Vector3#Vector3 normal normal
-- @param Vector3#Vector3 point point

---
-- Function new()
--
-- @function [parent=#Plane] new
-- @param self Self reference
-- @param Vector3#Vector3 normal normal
-- @param Vector3#Vector3 point point
-- @return Plane#Plane

---
-- Function Plane()
--
-- @function [parent=#Plane] Plane
-- @param self Self reference
-- @param Vector4#Vector4 plane plane

---
-- Function new()
--
-- @function [parent=#Plane] new
-- @param self Self reference
-- @param Vector4#Vector4 plane plane
-- @return Plane#Plane

---
-- Function delete()
--
-- @function [parent=#Plane] delete
-- @param self Self reference

---
-- Function Define()
--
-- @function [parent=#Plane] Define
-- @param self Self reference
-- @param Vector3#Vector3 v0 v0
-- @param Vector3#Vector3 v1 v1
-- @param Vector3#Vector3 v2 v2

---
-- Function Define()
--
-- @function [parent=#Plane] Define
-- @param self Self reference
-- @param Vector3#Vector3 normal normal
-- @param Vector3#Vector3 point point

---
-- Function Define()
--
-- @function [parent=#Plane] Define
-- @param self Self reference
-- @param Vector4#Vector4 plane plane

---
-- Function Transform()
--
-- @function [parent=#Plane] Transform
-- @param self Self reference
-- @param Matrix3#Matrix3 transform transform

---
-- Function Transform()
--
-- @function [parent=#Plane] Transform
-- @param self Self reference
-- @param Matrix3x4#Matrix3x4 transform transform

---
-- Function Transform()
--
-- @function [parent=#Plane] Transform
-- @param self Self reference
-- @param Matrix4#Matrix4 transform transform

---
-- Function Project()
--
-- @function [parent=#Plane] Project
-- @param self Self reference
-- @param Vector3#Vector3 point point
-- @return Vector3#Vector3

---
-- Function Distance()
--
-- @function [parent=#Plane] Distance
-- @param self Self reference
-- @param Vector3#Vector3 point point
-- @return #number

---
-- Function Reflect()
--
-- @function [parent=#Plane] Reflect
-- @param self Self reference
-- @param Vector3#Vector3 direction direction
-- @return Vector3#Vector3

---
-- Function ReflectionMatrix()
--
-- @function [parent=#Plane] ReflectionMatrix
-- @param self Self reference
-- @return Matrix3x4#Matrix3x4

---
-- Function Transformed()
--
-- @function [parent=#Plane] Transformed
-- @param self Self reference
-- @param Matrix3#Matrix3 transform transform
-- @return Plane#Plane

---
-- Function Transformed()
--
-- @function [parent=#Plane] Transformed
-- @param self Self reference
-- @param Matrix3x4#Matrix3x4 transform transform
-- @return Plane#Plane

---
-- Function Transformed()
--
-- @function [parent=#Plane] Transformed
-- @param self Self reference
-- @param Matrix4#Matrix4 transform transform
-- @return Plane#Plane

---
-- Function ToVector4()
--
-- @function [parent=#Plane] ToVector4
-- @param self Self reference
-- @return Vector4#Vector4

---
-- Field normal
--
-- @field [parent=#Plane] Vector3#Vector3 normal

---
-- Field absNormal
--
-- @field [parent=#Plane] Vector3#Vector3 absNormal

---
-- Field d
--
-- @field [parent=#Plane] #number d

---
-- Field UP
--
-- @field [parent=#Plane] Plane#Plane UP


return nil
