---
-- Module Matrix4
-- Generated on 2014-05-31
--
-- @module Matrix4

---
-- Function Matrix4()
-- Construct an identity matrix.
--
-- @function [parent=#Matrix4] Matrix4
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#Matrix4] new
-- @param self Self reference
-- @return Matrix4#Matrix4

---
-- Function Matrix4()
--
-- @function [parent=#Matrix4] Matrix4
-- @param self Self reference
-- @param Matrix4#Matrix4 matrix matrix

---
-- Function new()
--
-- @function [parent=#Matrix4] new
-- @param self Self reference
-- @param Matrix4#Matrix4 matrix matrix
-- @return Matrix4#Matrix4

---
-- Function Matrix4()
--
-- @function [parent=#Matrix4] Matrix4
-- @param self Self reference
-- @param Matrix3#Matrix3 matrix matrix

---
-- Function new()
--
-- @function [parent=#Matrix4] new
-- @param self Self reference
-- @param Matrix3#Matrix3 matrix matrix
-- @return Matrix4#Matrix4

---
-- Function Matrix4()
--
-- @function [parent=#Matrix4] Matrix4
-- @param self Self reference
-- @param #number v00 v00
-- @param #number v01 v01
-- @param #number v02 v02
-- @param #number v03 v03
-- @param #number v10 v10
-- @param #number v11 v11
-- @param #number v12 v12
-- @param #number v13 v13
-- @param #number v20 v20
-- @param #number v21 v21
-- @param #number v22 v22
-- @param #number v23 v23
-- @param #number v30 v30
-- @param #number v31 v31
-- @param #number v32 v32
-- @param #number v33 v33

---
-- Function new()
--
-- @function [parent=#Matrix4] new
-- @param self Self reference
-- @param #number v00 v00
-- @param #number v01 v01
-- @param #number v02 v02
-- @param #number v03 v03
-- @param #number v10 v10
-- @param #number v11 v11
-- @param #number v12 v12
-- @param #number v13 v13
-- @param #number v20 v20
-- @param #number v21 v21
-- @param #number v22 v22
-- @param #number v23 v23
-- @param #number v30 v30
-- @param #number v31 v31
-- @param #number v32 v32
-- @param #number v33 v33
-- @return Matrix4#Matrix4

---
-- Function delete()
--
-- @function [parent=#Matrix4] delete
-- @param self Self reference

---
-- Function operator==()
--
-- @function [parent=#Matrix4] operator==
-- @param self Self reference
-- @param Matrix4#Matrix4 rhs rhs
-- @return #boolean

---
-- Function operator*()
--
-- @function [parent=#Matrix4] operator*
-- @param self Self reference
-- @param Vector3#Vector3 rhs rhs
-- @return Vector3#Vector3

---
-- Function operator*()
--
-- @function [parent=#Matrix4] operator*
-- @param self Self reference
-- @param Vector4#Vector4 rhs rhs
-- @return Vector4#Vector4

---
-- Function operator+()
--
-- @function [parent=#Matrix4] operator+
-- @param self Self reference
-- @param Matrix4#Matrix4 rhs rhs
-- @return Matrix4#Matrix4

---
-- Function operator-()
--
-- @function [parent=#Matrix4] operator-
-- @param self Self reference
-- @param Matrix4#Matrix4 rhs rhs
-- @return Matrix4#Matrix4

---
-- Function operator*()
--
-- @function [parent=#Matrix4] operator*
-- @param self Self reference
-- @param #number rhs rhs
-- @return Matrix4#Matrix4

---
-- Function operator*()
--
-- @function [parent=#Matrix4] operator*
-- @param self Self reference
-- @param Matrix4#Matrix4 rhs rhs
-- @return Matrix4#Matrix4

---
-- Function SetTranslation()
--
-- @function [parent=#Matrix4] SetTranslation
-- @param self Self reference
-- @param Vector3#Vector3 translation translation

---
-- Function SetRotation()
--
-- @function [parent=#Matrix4] SetRotation
-- @param self Self reference
-- @param Matrix3#Matrix3 rotation rotation

---
-- Function SetScale()
--
-- @function [parent=#Matrix4] SetScale
-- @param self Self reference
-- @param Vector3#Vector3 scale scale

---
-- Function SetScale()
--
-- @function [parent=#Matrix4] SetScale
-- @param self Self reference
-- @param #number scale scale

---
-- Function ToMatrix3()
--
-- @function [parent=#Matrix4] ToMatrix3
-- @param self Self reference
-- @return Matrix3#Matrix3

---
-- Function RotationMatrix()
--
-- @function [parent=#Matrix4] RotationMatrix
-- @param self Self reference
-- @return Matrix3#Matrix3

---
-- Function Translation()
--
-- @function [parent=#Matrix4] Translation
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function Rotation()
--
-- @function [parent=#Matrix4] Rotation
-- @param self Self reference
-- @return Quaternion#Quaternion

---
-- Function Scale()
--
-- @function [parent=#Matrix4] Scale
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function Transpose()
--
-- @function [parent=#Matrix4] Transpose
-- @param self Self reference
-- @return Matrix4#Matrix4

---
-- Function Equals()
--
-- @function [parent=#Matrix4] Equals
-- @param self Self reference
-- @param Matrix4#Matrix4 rhs rhs
-- @return #boolean

---
-- Function Decompose()
--
-- @function [parent=#Matrix4] Decompose
-- @param self Self reference
-- @param Vector3#Vector3 translation translation
-- @param Quaternion#Quaternion rotation rotation
-- @param Vector3#Vector3 scale scale

---
-- Function Inverse()
--
-- @function [parent=#Matrix4] Inverse
-- @param self Self reference
-- @return Matrix4#Matrix4

---
-- Function ToString()
--
-- @function [parent=#Matrix4] ToString
-- @param self Self reference
-- @return #string

---
-- Field m00
--
-- @field [parent=#Matrix4] #number m00

---
-- Field m01
--
-- @field [parent=#Matrix4] #number m01

---
-- Field m02
--
-- @field [parent=#Matrix4] #number m02

---
-- Field m03
--
-- @field [parent=#Matrix4] #number m03

---
-- Field m10
--
-- @field [parent=#Matrix4] #number m10

---
-- Field m11
--
-- @field [parent=#Matrix4] #number m11

---
-- Field m12
--
-- @field [parent=#Matrix4] #number m12

---
-- Field m13
--
-- @field [parent=#Matrix4] #number m13

---
-- Field m20
--
-- @field [parent=#Matrix4] #number m20

---
-- Field m21
--
-- @field [parent=#Matrix4] #number m21

---
-- Field m22
--
-- @field [parent=#Matrix4] #number m22

---
-- Field m23
--
-- @field [parent=#Matrix4] #number m23

---
-- Field m30
--
-- @field [parent=#Matrix4] #number m30

---
-- Field m31
--
-- @field [parent=#Matrix4] #number m31

---
-- Field m32
--
-- @field [parent=#Matrix4] #number m32

---
-- Field m33
--
-- @field [parent=#Matrix4] #number m33

---
-- Field ZERO
--
-- @field [parent=#Matrix4] Matrix4#Matrix4 ZERO

---
-- Field IDENTITY
--
-- @field [parent=#Matrix4] Matrix4#Matrix4 IDENTITY


return nil
