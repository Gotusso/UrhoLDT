---
-- Module Matrix4
--
-- @module Matrix4

---
-- Function Matrix4
--
-- @function [parent=#Matrix4] Matrix4

---
-- Function new
--
-- @function [parent=#Matrix4] new
-- @return Matrix4#Matrix4

---
-- Function Matrix4
--
-- @function [parent=#Matrix4] Matrix4
-- @param Matrix4#Matrix4 matrixmatrix

---
-- Function new
--
-- @function [parent=#Matrix4] new
-- @param Matrix4#Matrix4 matrixmatrix
-- @return Matrix4#Matrix4

---
-- Function Matrix4
--
-- @function [parent=#Matrix4] Matrix4
-- @param Matrix3#Matrix3 matrixmatrix

---
-- Function new
--
-- @function [parent=#Matrix4] new
-- @param Matrix3#Matrix3 matrixmatrix
-- @return Matrix4#Matrix4

---
-- Function Matrix4
--
-- @function [parent=#Matrix4] Matrix4
-- @param #number v00v00
-- @param #number v01v01
-- @param #number v02v02
-- @param #number v03v03
-- @param #number v10v10
-- @param #number v11v11
-- @param #number v12v12
-- @param #number v13v13
-- @param #number v20v20
-- @param #number v21v21
-- @param #number v22v22
-- @param #number v23v23
-- @param #number v30v30
-- @param #number v31v31
-- @param #number v32v32
-- @param #number v33v33

---
-- Function new
--
-- @function [parent=#Matrix4] new
-- @param #number v00v00
-- @param #number v01v01
-- @param #number v02v02
-- @param #number v03v03
-- @param #number v10v10
-- @param #number v11v11
-- @param #number v12v12
-- @param #number v13v13
-- @param #number v20v20
-- @param #number v21v21
-- @param #number v22v22
-- @param #number v23v23
-- @param #number v30v30
-- @param #number v31v31
-- @param #number v32v32
-- @param #number v33v33
-- @return Matrix4#Matrix4

---
-- Function delete
--
-- @function [parent=#Matrix4] delete

---
-- Function operator==
--
-- @function [parent=#Matrix4] operator==
-- @param Matrix4#Matrix4 rhsrhs
-- @return #boolean

---
-- Function operator*
--
-- @function [parent=#Matrix4] operator*
-- @param Vector3#Vector3 rhsrhs
-- @return Vector3#Vector3

---
-- Function operator*
--
-- @function [parent=#Matrix4] operator*
-- @param Vector4#Vector4 rhsrhs
-- @return Vector4#Vector4

---
-- Function operator+
--
-- @function [parent=#Matrix4] operator+
-- @param Matrix4#Matrix4 rhsrhs
-- @return Matrix4#Matrix4

---
-- Function operator-
--
-- @function [parent=#Matrix4] operator-
-- @param Matrix4#Matrix4 rhsrhs
-- @return Matrix4#Matrix4

---
-- Function operator*
--
-- @function [parent=#Matrix4] operator*
-- @param #number rhsrhs
-- @return Matrix4#Matrix4

---
-- Function operator*
--
-- @function [parent=#Matrix4] operator*
-- @param Matrix4#Matrix4 rhsrhs
-- @return Matrix4#Matrix4

---
-- Function SetTranslation
--
-- @function [parent=#Matrix4] SetTranslation
-- @param Vector3#Vector3 translationtranslation

---
-- Function SetRotation
--
-- @function [parent=#Matrix4] SetRotation
-- @param Matrix3#Matrix3 rotationrotation

---
-- Function SetScale
--
-- @function [parent=#Matrix4] SetScale
-- @param Vector3#Vector3 scalescale

---
-- Function SetScale
--
-- @function [parent=#Matrix4] SetScale
-- @param #number scalescale

---
-- Function ToMatrix3
--
-- @function [parent=#Matrix4] ToMatrix3
-- @return Matrix3#Matrix3

---
-- Function RotationMatrix
--
-- @function [parent=#Matrix4] RotationMatrix
-- @return Matrix3#Matrix3

---
-- Function Translation
--
-- @function [parent=#Matrix4] Translation
-- @return Vector3#Vector3

---
-- Function Rotation
--
-- @function [parent=#Matrix4] Rotation
-- @return Quaternion#Quaternion

---
-- Function Scale
--
-- @function [parent=#Matrix4] Scale
-- @return Vector3#Vector3

---
-- Function Transpose
--
-- @function [parent=#Matrix4] Transpose
-- @return Matrix4#Matrix4

---
-- Function Equals
--
-- @function [parent=#Matrix4] Equals
-- @param Matrix4#Matrix4 rhsrhs
-- @return #boolean

---
-- Function Decompose
--
-- @function [parent=#Matrix4] Decompose
-- @param Vector3#Vector3 translationtranslation
-- @param Quaternion#Quaternion rotationrotation
-- @param Vector3#Vector3 scalescale

---
-- Function Inverse
--
-- @function [parent=#Matrix4] Inverse
-- @return Matrix4#Matrix4

---
-- Field m00
--
-- @field [parent=#Matrix4] #number m00

---
-- Field m01
--
-- @field [parent=#Matrix4] #number m01

---
-- Field m02
--
-- @field [parent=#Matrix4] #number m02

---
-- Field m03
--
-- @field [parent=#Matrix4] #number m03

---
-- Field m10
--
-- @field [parent=#Matrix4] #number m10

---
-- Field m11
--
-- @field [parent=#Matrix4] #number m11

---
-- Field m12
--
-- @field [parent=#Matrix4] #number m12

---
-- Field m13
--
-- @field [parent=#Matrix4] #number m13

---
-- Field m20
--
-- @field [parent=#Matrix4] #number m20

---
-- Field m21
--
-- @field [parent=#Matrix4] #number m21

---
-- Field m22
--
-- @field [parent=#Matrix4] #number m22

---
-- Field m23
--
-- @field [parent=#Matrix4] #number m23

---
-- Field m30
--
-- @field [parent=#Matrix4] #number m30

---
-- Field m31
--
-- @field [parent=#Matrix4] #number m31

---
-- Field m32
--
-- @field [parent=#Matrix4] #number m32

---
-- Field m33
--
-- @field [parent=#Matrix4] #number m33

---
-- Field ZERO
--
-- @field [parent=#Matrix4] Matrix4#Matrix4 ZERO

---
-- Field IDENTITY
--
-- @field [parent=#Matrix4] Matrix4#Matrix4 IDENTITY


return nil
