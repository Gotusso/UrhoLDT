---
-- Module Graphics
-- Extends Object
--
-- @module Graphics

---
-- Function SetWindowTitle
--
-- @function [parent=#Graphics] SetWindowTitle
-- @param #string windowTitlewindowTitle

---
-- Function SetWindowIcon
--
-- @function [parent=#Graphics] SetWindowIcon
-- @param Image#Image windowIconwindowIcon

---
-- Function SetWindowPosition
--
-- @function [parent=#Graphics] SetWindowPosition
-- @param IntVector2#IntVector2 positionposition

---
-- Function SetWindowPosition
--
-- @function [parent=#Graphics] SetWindowPosition
-- @param #number xx
-- @param #number yy

---
-- Function SetMode
--
-- @function [parent=#Graphics] SetMode
-- @param #number widthwidth
-- @param #number heightheight
-- @param #boolean fullscreenfullscreen
-- @param #boolean borderlessborderless
-- @param #boolean resizableresizable
-- @param #boolean vsyncvsync
-- @param #boolean tripleBuffertripleBuffer
-- @param #number multiSamplemultiSample
-- @return #boolean

---
-- Function SetMode
--
-- @function [parent=#Graphics] SetMode
-- @param #number widthwidth
-- @param #number heightheight
-- @return #boolean

---
-- Function SetSRGB
--
-- @function [parent=#Graphics] SetSRGB
-- @param #boolean enableenable

---
-- Function SetFlushGPU
--
-- @function [parent=#Graphics] SetFlushGPU
-- @param #boolean enableenable

---
-- Function ToggleFullscreen
--
-- @function [parent=#Graphics] ToggleFullscreen
-- @return #boolean

---
-- Function Maximize
--
-- @function [parent=#Graphics] Maximize

---
-- Function Minimize
--
-- @function [parent=#Graphics] Minimize

---
-- Function Close
--
-- @function [parent=#Graphics] Close

---
-- Function TakeScreenShot
--
-- @function [parent=#Graphics] TakeScreenShot
-- @param Image#Image destImagedestImage
-- @return #boolean

---
-- Function IsInitialized
--
-- @function [parent=#Graphics] IsInitialized
-- @return #boolean

---
-- Function GetExternalWindow
--
-- @function [parent=#Graphics] GetExternalWindow
-- @return void*#void*

---
-- Function GetWindowTitle
--
-- @function [parent=#Graphics] GetWindowTitle
-- @return const String#const String

---
-- Function GetWindowPosition
--
-- @function [parent=#Graphics] GetWindowPosition
-- @return IntVector2#IntVector2

---
-- Function GetWidth
--
-- @function [parent=#Graphics] GetWidth
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#Graphics] GetHeight
-- @return #number

---
-- Function GetMultiSample
--
-- @function [parent=#Graphics] GetMultiSample
-- @return #number

---
-- Function GetFullscreen
--
-- @function [parent=#Graphics] GetFullscreen
-- @return #boolean

---
-- Function GetResizable
--
-- @function [parent=#Graphics] GetResizable
-- @return #boolean

---
-- Function GetBorderless
--
-- @function [parent=#Graphics] GetBorderless
-- @return #boolean

---
-- Function GetVSync
--
-- @function [parent=#Graphics] GetVSync
-- @return #boolean

---
-- Function GetTripleBuffer
--
-- @function [parent=#Graphics] GetTripleBuffer
-- @return #boolean

---
-- Function GetSRGB
--
-- @function [parent=#Graphics] GetSRGB
-- @return #boolean

---
-- Function GetFlushGPU
--
-- @function [parent=#Graphics] GetFlushGPU
-- @return #boolean

---
-- Function IsDeviceLost
--
-- @function [parent=#Graphics] IsDeviceLost
-- @return #boolean

---
-- Function GetNumPrimitives
--
-- @function [parent=#Graphics] GetNumPrimitives
-- @return #number

---
-- Function GetNumBatches
--
-- @function [parent=#Graphics] GetNumBatches
-- @return #number

---
-- Function GetDummyColorFormat
--
-- @function [parent=#Graphics] GetDummyColorFormat
-- @return #number

---
-- Function GetShadowMapFormat
--
-- @function [parent=#Graphics] GetShadowMapFormat
-- @return #number

---
-- Function GetHiresShadowMapFormat
--
-- @function [parent=#Graphics] GetHiresShadowMapFormat
-- @return #number

---
-- Function GetSM3Support
--
-- @function [parent=#Graphics] GetSM3Support
-- @return #boolean

---
-- Function GetInstancingSupport
--
-- @function [parent=#Graphics] GetInstancingSupport
-- @return #boolean

---
-- Function GetLightPrepassSupport
--
-- @function [parent=#Graphics] GetLightPrepassSupport
-- @return #boolean

---
-- Function GetDeferredSupport
--
-- @function [parent=#Graphics] GetDeferredSupport
-- @return #boolean

---
-- Function GetHardwareShadowSupport
--
-- @function [parent=#Graphics] GetHardwareShadowSupport
-- @return #boolean

---
-- Function GetStreamOffsetSupport
--
-- @function [parent=#Graphics] GetStreamOffsetSupport
-- @return #boolean

---
-- Function GetSRGBSupport
--
-- @function [parent=#Graphics] GetSRGBSupport
-- @return #boolean

---
-- Function GetSRGBWriteSupport
--
-- @function [parent=#Graphics] GetSRGBWriteSupport
-- @return #boolean

---
-- Function GetDesktopResolution
--
-- @function [parent=#Graphics] GetDesktopResolution
-- @return IntVector2#IntVector2

---
-- Function GetRGBFormat
--
-- @function [parent=#Graphics] GetRGBFormat
-- @return #number

---
-- Field initialized (Read only)
--
-- @field [parent=#Graphics] #boolean initialized

---
-- Field windowTitle
--
-- @field [parent=#Graphics] #string windowTitle

---
-- Field windowPosition
--
-- @field [parent=#Graphics] IntVector2#IntVector2 windowPosition

---
-- Field width (Read only)
--
-- @field [parent=#Graphics] #number width

---
-- Field height (Read only)
--
-- @field [parent=#Graphics] #number height

---
-- Field multiSample (Read only)
--
-- @field [parent=#Graphics] #number multiSample

---
-- Field fullscreen (Read only)
--
-- @field [parent=#Graphics] #boolean fullscreen

---
-- Field resizable (Read only)
--
-- @field [parent=#Graphics] #boolean resizable

---
-- Field borderless (Read only)
--
-- @field [parent=#Graphics] #boolean borderless

---
-- Field vSync (Read only)
--
-- @field [parent=#Graphics] #boolean vSync

---
-- Field tripleBuffer (Read only)
--
-- @field [parent=#Graphics] #boolean tripleBuffer

---
-- Field sRGB
--
-- @field [parent=#Graphics] #boolean sRGB

---
-- Field flushGPU
--
-- @field [parent=#Graphics] #boolean flushGPU

---
-- Field deviceLost (Read only)
--
-- @field [parent=#Graphics] #boolean deviceLost

---
-- Field numPrimitives (Read only)
--
-- @field [parent=#Graphics] #number numPrimitives

---
-- Field numBatches (Read only)
--
-- @field [parent=#Graphics] #number numBatches

---
-- Field dummyColorFormat (Read only)
--
-- @field [parent=#Graphics] #number dummyColorFormat

---
-- Field shadowMapFormat (Read only)
--
-- @field [parent=#Graphics] #number shadowMapFormat

---
-- Field hiresShadowMapFormat (Read only)
--
-- @field [parent=#Graphics] #number hiresShadowMapFormat

---
-- Field sM3Support (Read only)
--
-- @field [parent=#Graphics] #boolean sM3Support

---
-- Field instancingSupport (Read only)
--
-- @field [parent=#Graphics] #boolean instancingSupport

---
-- Field lightPrepassSupport (Read only)
--
-- @field [parent=#Graphics] #boolean lightPrepassSupport

---
-- Field deferredSupport (Read only)
--
-- @field [parent=#Graphics] #boolean deferredSupport

---
-- Field hardwareShadowSupport (Read only)
--
-- @field [parent=#Graphics] #boolean hardwareShadowSupport

---
-- Field streamOffsetSupport (Read only)
--
-- @field [parent=#Graphics] #boolean streamOffsetSupport

---
-- Field sRGBSupport (Read only)
--
-- @field [parent=#Graphics] #boolean sRGBSupport

---
-- Field sRGBWriteSupport (Read only)
--
-- @field [parent=#Graphics] #boolean sRGBWriteSupport

---
-- Field desktopResolution (Read only)
--
-- @field [parent=#Graphics] IntVector2#IntVector2 desktopResolution


return nil
