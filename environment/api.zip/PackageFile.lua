---
-- Module PackageFile
-- extends Object
--
-- @module PackageFile

---
-- Function PackageFile
--
-- @function [parent=#PackageFile] PackageFile

---
-- Function new
--
-- @function [parent=#PackageFile] new
-- @return PackageFile#PackageFile

---
-- Function PackageFile
--
-- @function [parent=#PackageFile] PackageFile
-- @param #string fileNamefileName
-- @param #number startOffsetstartOffset

---
-- Function new
--
-- @function [parent=#PackageFile] new
-- @param #string fileNamefileName
-- @param #number startOffsetstartOffset
-- @return PackageFile#PackageFile

---
-- Function delete
--
-- @function [parent=#PackageFile] delete

---
-- Function Open
--
-- @function [parent=#PackageFile] Open
-- @param #string fileNamefileName
-- @param #number startOffsetstartOffset
-- @return #boolean

---
-- Function Exists
--
-- @function [parent=#PackageFile] Exists
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function GetEntry
--
-- @function [parent=#PackageFile] GetEntry
-- @param #string fileNamefileName
-- @return const PackageEntry#const PackageEntry

---
-- Function GetEntries
--
-- @function [parent=#PackageFile] GetEntries
-- @return const HashMap<String,PackageEntry>#const HashMap<String,PackageEntry>

---
-- Function GetName
--
-- @function [parent=#PackageFile] GetName
-- @return const String#const String

---
-- Function GetNameHash
--
-- @function [parent=#PackageFile] GetNameHash
-- @return StringHash#StringHash

---
-- Function GetNumFiles
--
-- @function [parent=#PackageFile] GetNumFiles
-- @return #number

---
-- Function GetTotalSize
--
-- @function [parent=#PackageFile] GetTotalSize
-- @return #number

---
-- Function GetChecksum
--
-- @function [parent=#PackageFile] GetChecksum
-- @return #number

---
-- Function IsCompressed
--
-- @function [parent=#PackageFile] IsCompressed
-- @return #boolean

---
-- Field name (Read only)
--
-- @field [parent=#PackageFile] #string name

---
-- Field nameHash (Read only)
--
-- @field [parent=#PackageFile] StringHash#StringHash nameHash

---
-- Field numFiles (Read only)
--
-- @field [parent=#PackageFile] #number numFiles

---
-- Field totalSize (Read only)
--
-- @field [parent=#PackageFile] #number totalSize

---
-- Field checksum (Read only)
--
-- @field [parent=#PackageFile] #number checksum

---
-- Field compressed (Read only)
--
-- @field [parent=#PackageFile] #boolean compressed

---
-- Function GetType
--
-- @function [parent=#PackageFile] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#PackageFile] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#PackageFile] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#PackageFile] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#PackageFile] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#PackageFile] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#PackageFile] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#PackageFile] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#PackageFile] #string category


return nil
