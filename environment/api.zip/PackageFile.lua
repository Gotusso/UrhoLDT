---
-- Module PackageFile
-- Module PackageFile extends Object
-- Generated on 2014-05-31
--
-- @module PackageFile

---
-- Function PackageFile()
--
-- @function [parent=#PackageFile] PackageFile
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#PackageFile] new
-- @param self Self reference
-- @return PackageFile#PackageFile

---
-- Function PackageFile()
--
-- @function [parent=#PackageFile] PackageFile
-- @param self Self reference
-- @param #string fileName fileName
-- @param #number startOffset startOffset

---
-- Function new()
--
-- @function [parent=#PackageFile] new
-- @param self Self reference
-- @param #string fileName fileName
-- @param #number startOffset startOffset
-- @return PackageFile#PackageFile

---
-- Function delete()
--
-- @function [parent=#PackageFile] delete
-- @param self Self reference

---
-- Function Open()
-- Open the package file. Return true if successful.
--
-- @function [parent=#PackageFile] Open
-- @param self Self reference
-- @param #string fileName fileName
-- @param #number startOffset startOffset
-- @return #boolean

---
-- Function Exists()
-- Check if a file exists within the package file.
--
-- @function [parent=#PackageFile] Exists
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function GetEntry()
-- Return the file entry corresponding to the name, or null if not found.
--
-- @function [parent=#PackageFile] GetEntry
-- @param self Self reference
-- @param #string fileName fileName
-- @return const PackageEntry#const PackageEntry

---
-- Function GetEntries()
-- Return all file entries.
--
-- @function [parent=#PackageFile] GetEntries
-- @param self Self reference
-- @return const HashMap<String,PackageEntry>#const HashMap<String,PackageEntry>

---
-- Function GetName()
-- Return the package file name.
--
-- @function [parent=#PackageFile] GetName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetNameHash()
-- Return hash of the package file name.
--
-- @function [parent=#PackageFile] GetNameHash
-- @param self Self reference
-- @return StringHash#StringHash

---
-- Function GetNumFiles()
-- Return number of files.
--
-- @function [parent=#PackageFile] GetNumFiles
-- @param self Self reference
-- @return #number

---
-- Function GetTotalSize()
-- Return total size of the package file.
--
-- @function [parent=#PackageFile] GetTotalSize
-- @param self Self reference
-- @return #number

---
-- Function GetChecksum()
-- Return checksum of the package file contents.
--
-- @function [parent=#PackageFile] GetChecksum
-- @param self Self reference
-- @return #number

---
-- Function IsCompressed()
-- Return whether the files are compressed.
--
-- @function [parent=#PackageFile] IsCompressed
-- @param self Self reference
-- @return #boolean

---
-- Field name (Read only)
--
-- @field [parent=#PackageFile] #string name

---
-- Field nameHash (Read only)
--
-- @field [parent=#PackageFile] StringHash#StringHash nameHash

---
-- Field numFiles (Read only)
--
-- @field [parent=#PackageFile] #number numFiles

---
-- Field totalSize (Read only)
--
-- @field [parent=#PackageFile] #number totalSize

---
-- Field checksum (Read only)
--
-- @field [parent=#PackageFile] #number checksum

---
-- Field compressed (Read only)
--
-- @field [parent=#PackageFile] #boolean compressed


return nil
