---
-- Module PackageFile
-- Module PackageFile extends Object
-- Generated on 2014-03-13
--
-- @module PackageFile

---
-- Function PackageFile
--
-- @function [parent=#PackageFile] PackageFile
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#PackageFile] new
-- @param self Self reference
-- @return PackageFile#PackageFile

---
-- Function PackageFile
--
-- @function [parent=#PackageFile] PackageFile
-- @param self Self reference
-- @param #string fileName fileName
-- @param #number startOffset startOffset

---
-- Function new
--
-- @function [parent=#PackageFile] new
-- @param self Self reference
-- @param #string fileName fileName
-- @param #number startOffset startOffset
-- @return PackageFile#PackageFile

---
-- Function delete
--
-- @function [parent=#PackageFile] delete
-- @param self Self reference

---
-- Function Open
--
-- @function [parent=#PackageFile] Open
-- @param self Self reference
-- @param #string fileName fileName
-- @param #number startOffset startOffset
-- @return #boolean

---
-- Function Exists
--
-- @function [parent=#PackageFile] Exists
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function GetEntry
--
-- @function [parent=#PackageFile] GetEntry
-- @param self Self reference
-- @param #string fileName fileName
-- @return const PackageEntry#const PackageEntry

---
-- Function GetEntries
--
-- @function [parent=#PackageFile] GetEntries
-- @param self Self reference
-- @return const HashMap<String,PackageEntry>#const HashMap<String,PackageEntry>

---
-- Function GetName
--
-- @function [parent=#PackageFile] GetName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetNameHash
--
-- @function [parent=#PackageFile] GetNameHash
-- @param self Self reference
-- @return StringHash#StringHash

---
-- Function GetNumFiles
--
-- @function [parent=#PackageFile] GetNumFiles
-- @param self Self reference
-- @return #number

---
-- Function GetTotalSize
--
-- @function [parent=#PackageFile] GetTotalSize
-- @param self Self reference
-- @return #number

---
-- Function GetChecksum
--
-- @function [parent=#PackageFile] GetChecksum
-- @param self Self reference
-- @return #number

---
-- Function IsCompressed
--
-- @function [parent=#PackageFile] IsCompressed
-- @param self Self reference
-- @return #boolean

---
-- Field name (Read only)
--
-- @field [parent=#PackageFile] #string name

---
-- Field nameHash (Read only)
--
-- @field [parent=#PackageFile] StringHash#StringHash nameHash

---
-- Field numFiles (Read only)
--
-- @field [parent=#PackageFile] #number numFiles

---
-- Field totalSize (Read only)
--
-- @field [parent=#PackageFile] #number totalSize

---
-- Field checksum (Read only)
--
-- @field [parent=#PackageFile] #number checksum

---
-- Field compressed (Read only)
--
-- @field [parent=#PackageFile] #boolean compressed

---
-- Function GetType
--
-- @function [parent=#PackageFile] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#PackageFile] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#PackageFile] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#PackageFile] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#PackageFile] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#PackageFile] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#PackageFile] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#PackageFile] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#PackageFile] #string category


return nil
