---
-- Module TextureFrame
-- Generated on 2014-03-13
--
-- @module TextureFrame

---
-- Function TextureFrame
--
-- @function [parent=#TextureFrame] TextureFrame
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#TextureFrame] new
-- @param self Self reference
-- @return TextureFrame#TextureFrame

---
-- Function delete
--
-- @function [parent=#TextureFrame] delete
-- @param self Self reference

---
-- Field uv
--
-- @field [parent=#TextureFrame] Rect#Rect uv

---
-- Field time
--
-- @field [parent=#TextureFrame] #number time


return nil
