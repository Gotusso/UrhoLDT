---
-- Module TextureFrame
--
-- @module TextureFrame

---
-- Function TextureFrame
--
-- @function [parent=#TextureFrame] TextureFrame

---
-- Function new
--
-- @function [parent=#TextureFrame] new
-- @return TextureFrame#TextureFrame

---
-- Function delete
--
-- @function [parent=#TextureFrame] delete

---
-- Field uv
--
-- @field [parent=#TextureFrame] Rect#Rect uv

---
-- Field time
--
-- @field [parent=#TextureFrame] #number time


return nil
