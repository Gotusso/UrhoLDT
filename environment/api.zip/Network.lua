---
-- Module Network
-- Generated on 2014-05-31
--
-- @module Network

---
-- Function Connect()
--
-- @function [parent=#Network] Connect
-- @param self Self reference
-- @param #string address address
-- @param short#short port port
-- @param Scene#Scene scene scene
-- @return #boolean

---
-- Function Connect()
--
-- @function [parent=#Network] Connect
-- @param self Self reference
-- @param #string address address
-- @param short#short port port
-- @param Scene#Scene scene scene
-- @param VariantMap#VariantMap identity identity
-- @return #boolean

---
-- Function Disconnect()
-- Disconnect the connection to the server. If wait time is non-zero, will block while waiting for disconnect to finish.
--
-- @function [parent=#Network] Disconnect
-- @param self Self reference
-- @param #number waitMSec waitMSec

---
-- Function StartServer()
--
-- @function [parent=#Network] StartServer
-- @param self Self reference
-- @param short#short port port
-- @return #boolean

---
-- Function StopServer()
-- Stop the server.
--
-- @function [parent=#Network] StopServer
-- @param self Self reference

---
-- Function BroadcastMessage()
-- Broadcast a message with content ID to all client connections.
--
-- @function [parent=#Network] BroadcastMessage
-- @param self Self reference
-- @param #number msgID msgID
-- @param #boolean reliable reliable
-- @param #boolean inOrder inOrder
-- @param VectorBuffer#VectorBuffer msg msg
-- @param #number contentID contentID

---
-- Function BroadcastRemoteEvent()
-- Broadcast a remote event to all client connections.
--
-- @function [parent=#Network] BroadcastRemoteEvent
-- @param self Self reference
-- @param StringHash#StringHash eventType eventType
-- @param #boolean inOrder inOrder

---
-- Function BroadcastRemoteEvent()
--
-- @function [parent=#Network] BroadcastRemoteEvent
-- @param self Self reference
-- @param StringHash#StringHash eventType eventType
-- @param #boolean inOrder inOrder
-- @param VariantMap#VariantMap eventData eventData

---
-- Function BroadcastRemoteEvent()
--
-- @function [parent=#Network] BroadcastRemoteEvent
-- @param self Self reference
-- @param #string eventType eventType
-- @param #boolean inOrder inOrder

---
-- Function BroadcastRemoteEvent()
--
-- @function [parent=#Network] BroadcastRemoteEvent
-- @param self Self reference
-- @param #string eventType eventType
-- @param #boolean inOrder inOrder
-- @param VariantMap#VariantMap eventData eventData

---
-- Function BroadcastRemoteEvent()
-- Broadcast a remote event to all client connections in a specific scene.
--
-- @function [parent=#Network] BroadcastRemoteEvent
-- @param self Self reference
-- @param Scene#Scene scene scene
-- @param StringHash#StringHash eventType eventType
-- @param #boolean inOrder inOrder

---
-- Function BroadcastRemoteEvent()
--
-- @function [parent=#Network] BroadcastRemoteEvent
-- @param self Self reference
-- @param Scene#Scene scene scene
-- @param StringHash#StringHash eventType eventType
-- @param #boolean inOrder inOrder
-- @param VariantMap#VariantMap eventData eventData

---
-- Function BroadcastRemoteEvent()
--
-- @function [parent=#Network] BroadcastRemoteEvent
-- @param self Self reference
-- @param Scene#Scene scene scene
-- @param #string eventType eventType
-- @param #boolean inOrder inOrder

---
-- Function BroadcastRemoteEvent()
--
-- @function [parent=#Network] BroadcastRemoteEvent
-- @param self Self reference
-- @param Scene#Scene scene scene
-- @param #string eventType eventType
-- @param #boolean inOrder inOrder
-- @param VariantMap#VariantMap eventData eventData

---
-- Function BroadcastRemoteEvent()
-- Broadcast a remote event with the specified node as a sender. Is sent to all client connections in the node's scene.
--
-- @function [parent=#Network] BroadcastRemoteEvent
-- @param self Self reference
-- @param Node#Node node node
-- @param StringHash#StringHash eventType eventType
-- @param #boolean inOrder inOrder

---
-- Function BroadcastRemoteEvent()
--
-- @function [parent=#Network] BroadcastRemoteEvent
-- @param self Self reference
-- @param Node#Node node node
-- @param StringHash#StringHash eventType eventType
-- @param #boolean inOrder inOrder
-- @param VariantMap#VariantMap eventData eventData

---
-- Function BroadcastRemoteEvent()
--
-- @function [parent=#Network] BroadcastRemoteEvent
-- @param self Self reference
-- @param Node#Node node node
-- @param #string eventType eventType
-- @param #boolean inOrder inOrder

---
-- Function BroadcastRemoteEvent()
--
-- @function [parent=#Network] BroadcastRemoteEvent
-- @param self Self reference
-- @param Node#Node node node
-- @param #string eventType eventType
-- @param #boolean inOrder inOrder
-- @param VariantMap#VariantMap eventData eventData

---
-- Function SetUpdateFps()
-- Set network update FPS.
--
-- @function [parent=#Network] SetUpdateFps
-- @param self Self reference
-- @param #number fps fps

---
-- Function RegisterRemoteEvent()
-- Register a remote event as allowed to be sent and received. If no events are registered, all are allowed.
--
-- @function [parent=#Network] RegisterRemoteEvent
-- @param self Self reference
-- @param StringHash#StringHash eventType eventType

---
-- Function RegisterRemoteEvent()
--
-- @function [parent=#Network] RegisterRemoteEvent
-- @param self Self reference
-- @param #string eventType eventType

---
-- Function UnregisterRemoteEvent()
-- Unregister a remote event as allowed to be sent and received.
--
-- @function [parent=#Network] UnregisterRemoteEvent
-- @param self Self reference
-- @param StringHash#StringHash eventType eventType

---
-- Function UnregisterRemoteEvent()
--
-- @function [parent=#Network] UnregisterRemoteEvent
-- @param self Self reference
-- @param #string eventType eventType

---
-- Function UnregisterAllRemoteEvents()
-- Unregister all remote events. This results in all being allowed.
--
-- @function [parent=#Network] UnregisterAllRemoteEvents
-- @param self Self reference

---
-- Function SetPackageCacheDir()
-- Set the package download cache directory.
--
-- @function [parent=#Network] SetPackageCacheDir
-- @param self Self reference
-- @param #string path path

---
-- Function MakeHttpRequest()
--
-- @function [parent=#Network] MakeHttpRequest
-- @param self Self reference
-- @param #string url url
-- @param #string verb verb
-- @return HttpRequest#HttpRequest

---
-- Function MakeHttpRequest()
--
-- @function [parent=#Network] MakeHttpRequest
-- @param self Self reference
-- @param #string url url
-- @param #string verb verb
-- @param Vector<String>#Vector<String> headers headers
-- @param #string postData postData
-- @return HttpRequest#HttpRequest

---
-- Function GetUpdateFps()
-- Return network update FPS.
--
-- @function [parent=#Network] GetUpdateFps
-- @param self Self reference
-- @return #number

---
-- Function GetServerConnection()
-- Return the connection to the server. Null if not connected.
--
-- @function [parent=#Network] GetServerConnection
-- @param self Self reference
-- @return Connection#Connection

---
-- Function IsServerRunning()
-- Return whether the server is running.
--
-- @function [parent=#Network] IsServerRunning
-- @param self Self reference
-- @return #boolean

---
-- Function CheckRemoteEvent()
-- Return whether a remote event is allowed to be sent and received. If no events are registered, all are allowed.
--
-- @function [parent=#Network] CheckRemoteEvent
-- @param self Self reference
-- @param StringHash#StringHash eventType eventType
-- @return #boolean

---
-- Function GetPackageCacheDir()
-- Return the package download cache directory.
--
-- @function [parent=#Network] GetPackageCacheDir
-- @param self Self reference
-- @return const String#const String

---
-- Field updateFps
--
-- @field [parent=#Network] #number updateFps

---
-- Field serverConnection (Read only)
--
-- @field [parent=#Network] Connection#Connection serverConnection

---
-- Field serverRunning (Read only)
--
-- @field [parent=#Network] #boolean serverRunning

---
-- Field packageCacheDir
--
-- @field [parent=#Network] #string packageCacheDir


return nil
