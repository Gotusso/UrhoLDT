---
-- Module Network
--
-- @module Network

---
-- Function Connect
--
-- @function [parent=#Network] Connect
-- @param #string addressaddress
-- @param short#short portport
-- @param Scene#Scene scenescene
-- @return #boolean

---
-- Function Connect
--
-- @function [parent=#Network] Connect
-- @param #string addressaddress
-- @param short#short portport
-- @param Scene#Scene scenescene
-- @param VariantMap#VariantMap identityidentity
-- @return #boolean

---
-- Function Disconnect
--
-- @function [parent=#Network] Disconnect
-- @param #number waitMSecwaitMSec

---
-- Function StartServer
--
-- @function [parent=#Network] StartServer
-- @param short#short portport
-- @return #boolean

---
-- Function StopServer
--
-- @function [parent=#Network] StopServer

---
-- Function BroadcastMessage
--
-- @function [parent=#Network] BroadcastMessage
-- @param #number msgIDmsgID
-- @param #boolean reliablereliable
-- @param #boolean inOrderinOrder
-- @param VectorBuffer#VectorBuffer msgmsg
-- @param #number contentIDcontentID

---
-- Function BroadcastRemoteEvent
--
-- @function [parent=#Network] BroadcastRemoteEvent
-- @param StringHash#StringHash eventTypeeventType
-- @param #boolean inOrderinOrder

---
-- Function BroadcastRemoteEvent
--
-- @function [parent=#Network] BroadcastRemoteEvent
-- @param StringHash#StringHash eventTypeeventType
-- @param #boolean inOrderinOrder
-- @param VariantMap#VariantMap eventDataeventData

---
-- Function BroadcastRemoteEvent
--
-- @function [parent=#Network] BroadcastRemoteEvent
-- @param #string eventTypeeventType
-- @param #boolean inOrderinOrder

---
-- Function BroadcastRemoteEvent
--
-- @function [parent=#Network] BroadcastRemoteEvent
-- @param #string eventTypeeventType
-- @param #boolean inOrderinOrder
-- @param VariantMap#VariantMap eventDataeventData

---
-- Function BroadcastRemoteEvent
--
-- @function [parent=#Network] BroadcastRemoteEvent
-- @param Scene#Scene scenescene
-- @param StringHash#StringHash eventTypeeventType
-- @param #boolean inOrderinOrder

---
-- Function BroadcastRemoteEvent
--
-- @function [parent=#Network] BroadcastRemoteEvent
-- @param Scene#Scene scenescene
-- @param StringHash#StringHash eventTypeeventType
-- @param #boolean inOrderinOrder
-- @param VariantMap#VariantMap eventDataeventData

---
-- Function BroadcastRemoteEvent
--
-- @function [parent=#Network] BroadcastRemoteEvent
-- @param Scene#Scene scenescene
-- @param #string eventTypeeventType
-- @param #boolean inOrderinOrder

---
-- Function BroadcastRemoteEvent
--
-- @function [parent=#Network] BroadcastRemoteEvent
-- @param Scene#Scene scenescene
-- @param #string eventTypeeventType
-- @param #boolean inOrderinOrder
-- @param VariantMap#VariantMap eventDataeventData

---
-- Function BroadcastRemoteEvent
--
-- @function [parent=#Network] BroadcastRemoteEvent
-- @param Node#Node nodenode
-- @param StringHash#StringHash eventTypeeventType
-- @param #boolean inOrderinOrder

---
-- Function BroadcastRemoteEvent
--
-- @function [parent=#Network] BroadcastRemoteEvent
-- @param Node#Node nodenode
-- @param StringHash#StringHash eventTypeeventType
-- @param #boolean inOrderinOrder
-- @param VariantMap#VariantMap eventDataeventData

---
-- Function BroadcastRemoteEvent
--
-- @function [parent=#Network] BroadcastRemoteEvent
-- @param Node#Node nodenode
-- @param #string eventTypeeventType
-- @param #boolean inOrderinOrder

---
-- Function BroadcastRemoteEvent
--
-- @function [parent=#Network] BroadcastRemoteEvent
-- @param Node#Node nodenode
-- @param #string eventTypeeventType
-- @param #boolean inOrderinOrder
-- @param VariantMap#VariantMap eventDataeventData

---
-- Function SetUpdateFps
--
-- @function [parent=#Network] SetUpdateFps
-- @param #number fpsfps

---
-- Function RegisterRemoteEvent
--
-- @function [parent=#Network] RegisterRemoteEvent
-- @param StringHash#StringHash eventTypeeventType

---
-- Function RegisterRemoteEvent
--
-- @function [parent=#Network] RegisterRemoteEvent
-- @param #string eventTypeeventType

---
-- Function UnregisterRemoteEvent
--
-- @function [parent=#Network] UnregisterRemoteEvent
-- @param StringHash#StringHash eventTypeeventType

---
-- Function UnregisterRemoteEvent
--
-- @function [parent=#Network] UnregisterRemoteEvent
-- @param #string eventTypeeventType

---
-- Function UnregisterAllRemoteEvents
--
-- @function [parent=#Network] UnregisterAllRemoteEvents

---
-- Function SetPackageCacheDir
--
-- @function [parent=#Network] SetPackageCacheDir
-- @param #string pathpath

---
-- Function MakeHttpRequest
--
-- @function [parent=#Network] MakeHttpRequest
-- @param #string urlurl
-- @param #string verbverb
-- @return HttpRequest#HttpRequest

---
-- Function MakeHttpRequest
--
-- @function [parent=#Network] MakeHttpRequest
-- @param #string urlurl
-- @param #string verbverb
-- @param Vector<String>#Vector<String> headersheaders
-- @param #string postDatapostData
-- @return HttpRequest#HttpRequest

---
-- Function GetUpdateFps
--
-- @function [parent=#Network] GetUpdateFps
-- @return #number

---
-- Function GetServerConnection
--
-- @function [parent=#Network] GetServerConnection
-- @return Connection#Connection

---
-- Function IsServerRunning
--
-- @function [parent=#Network] IsServerRunning
-- @return #boolean

---
-- Function CheckRemoteEvent
--
-- @function [parent=#Network] CheckRemoteEvent
-- @param StringHash#StringHash eventTypeeventType
-- @return #boolean

---
-- Function GetPackageCacheDir
--
-- @function [parent=#Network] GetPackageCacheDir
-- @return const String#const String

---
-- Field updateFps
--
-- @field [parent=#Network] #number updateFps

---
-- Field serverConnection (Read only)
--
-- @field [parent=#Network] Connection#Connection serverConnection

---
-- Field serverRunning (Read only)
--
-- @field [parent=#Network] #boolean serverRunning

---
-- Field packageCacheDir
--
-- @field [parent=#Network] #string packageCacheDir


return nil
