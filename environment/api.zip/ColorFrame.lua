---
-- Module ColorFrame
--
-- @module ColorFrame

---
-- Function ColorFrame
--
-- @function [parent=#ColorFrame] ColorFrame

---
-- Function new
--
-- @function [parent=#ColorFrame] new
-- @return ColorFrame#ColorFrame

---
-- Function ColorFrame
--
-- @function [parent=#ColorFrame] ColorFrame
-- @param Color#Color colorcolor

---
-- Function new
--
-- @function [parent=#ColorFrame] new
-- @param Color#Color colorcolor
-- @return ColorFrame#ColorFrame

---
-- Function ColorFrame
--
-- @function [parent=#ColorFrame] ColorFrame
-- @param Color#Color colorcolor
-- @param #number timetime

---
-- Function new
--
-- @function [parent=#ColorFrame] new
-- @param Color#Color colorcolor
-- @param #number timetime
-- @return ColorFrame#ColorFrame

---
-- Function delete
--
-- @function [parent=#ColorFrame] delete

---
-- Function Interpolate
--
-- @function [parent=#ColorFrame] Interpolate
-- @param ColorFrame#ColorFrame nextnext
-- @param #number timetime
-- @return Color#Color

---
-- Field color
--
-- @field [parent=#ColorFrame] Color#Color color

---
-- Field time
--
-- @field [parent=#ColorFrame] #number time


return nil
