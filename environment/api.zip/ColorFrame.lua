---
-- Module ColorFrame
-- Generated on 2014-05-31
--
-- @module ColorFrame

---
-- Function ColorFrame()
--
-- @function [parent=#ColorFrame] ColorFrame
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#ColorFrame] new
-- @param self Self reference
-- @return ColorFrame#ColorFrame

---
-- Function ColorFrame()
--
-- @function [parent=#ColorFrame] ColorFrame
-- @param self Self reference
-- @param Color#Color color color

---
-- Function new()
--
-- @function [parent=#ColorFrame] new
-- @param self Self reference
-- @param Color#Color color color
-- @return ColorFrame#ColorFrame

---
-- Function ColorFrame()
--
-- @function [parent=#ColorFrame] ColorFrame
-- @param self Self reference
-- @param Color#Color color color
-- @param #number time time

---
-- Function new()
--
-- @function [parent=#ColorFrame] new
-- @param self Self reference
-- @param Color#Color color color
-- @param #number time time
-- @return ColorFrame#ColorFrame

---
-- Function delete()
--
-- @function [parent=#ColorFrame] delete
-- @param self Self reference

---
-- Function Interpolate()
--
-- @function [parent=#ColorFrame] Interpolate
-- @param self Self reference
-- @param ColorFrame#ColorFrame next next
-- @param #number time time
-- @return Color#Color

---
-- Field color
--
-- @field [parent=#ColorFrame] Color#Color color

---
-- Field time
--
-- @field [parent=#ColorFrame] #number time


return nil
