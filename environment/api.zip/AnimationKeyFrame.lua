---
-- Module AnimationKeyFrame
-- Generated on 2014-05-31
--
-- @module AnimationKeyFrame

---
-- Field time
--
-- @field [parent=#AnimationKeyFrame] #number time

---
-- Field position
--
-- @field [parent=#AnimationKeyFrame] Vector3#Vector3 position

---
-- Field rotation
--
-- @field [parent=#AnimationKeyFrame] Quaternion#Quaternion rotation

---
-- Field scale
--
-- @field [parent=#AnimationKeyFrame] Vector3#Vector3 scale


return nil
