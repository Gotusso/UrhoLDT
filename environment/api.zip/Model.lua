---
-- Module Model
-- Module Model extends Resource
-- Generated on 2014-05-31
--
-- @module Model

---
-- Function GetBoundingBox()
-- Return bounding box.
--
-- @function [parent=#Model] GetBoundingBox
-- @param self Self reference
-- @return const BoundingBox#const BoundingBox

---
-- Function GetSkeleton()
-- Return skeleton.
--
-- @function [parent=#Model] GetSkeleton
-- @param self Self reference
-- @return Skeleton#Skeleton

---
-- Function GetNumGeometries()
-- Return number of geometries.
--
-- @function [parent=#Model] GetNumGeometries
-- @param self Self reference
-- @return #number

---
-- Function GetNumGeometryLodLevels()
-- Return number of LOD levels in geometry.
--
-- @function [parent=#Model] GetNumGeometryLodLevels
-- @param self Self reference
-- @param #number index index
-- @return #number

---
-- Function GetGeometry()
-- Return geometry by index and LOD level. The LOD level is clamped if out of range.
--
-- @function [parent=#Model] GetGeometry
-- @param self Self reference
-- @param #number index index
-- @param #number lodLevel lodLevel
-- @return Geometry#Geometry

---
-- Function GetNumMorphs()
-- Return number of vertex morphs.
--
-- @function [parent=#Model] GetNumMorphs
-- @param self Self reference
-- @return #number

---
-- Function GetMorph()
-- Return vertex morph by name.
--
-- @function [parent=#Model] GetMorph
-- @param self Self reference
-- @param #string name name
-- @return const ModelMorph#const ModelMorph

---
-- Function GetMorph()
-- Return vertex morph by name hash.
--
-- @function [parent=#Model] GetMorph
-- @param self Self reference
-- @param StringHash#StringHash nameHash nameHash
-- @return const ModelMorph#const ModelMorph

---
-- Function GetMorph()
-- Return vertex morph by index.
--
-- @function [parent=#Model] GetMorph
-- @param self Self reference
-- @param #number index index
-- @return const ModelMorph#const ModelMorph

---
-- Function GetMorphRangeStart()
-- Return vertex buffer morph range start.
--
-- @function [parent=#Model] GetMorphRangeStart
-- @param self Self reference
-- @param #number bufferIndex bufferIndex
-- @return #number

---
-- Function GetMorphRangeCount()
-- Return vertex buffer morph range vertex count.
--
-- @function [parent=#Model] GetMorphRangeCount
-- @param self Self reference
-- @param #number bufferIndex bufferIndex
-- @return #number

---
-- Field boundingBox (Read only)
--
-- @field [parent=#Model] BoundingBox#BoundingBox boundingBox

---
-- Field skeleton (Read only)
--
-- @field [parent=#Model] Skeleton#Skeleton skeleton

---
-- Field numGeometries (Read only)
--
-- @field [parent=#Model] #number numGeometries

---
-- Field numMorphs (Read only)
--
-- @field [parent=#Model] #number numMorphs


return nil
