---
-- Module Model
-- Module Model extends Resource
-- Generated on 2014-03-13
--
-- @module Model

---
-- Function GetBoundingBox
--
-- @function [parent=#Model] GetBoundingBox
-- @param self Self reference
-- @return const BoundingBox#const BoundingBox

---
-- Function GetSkeleton
--
-- @function [parent=#Model] GetSkeleton
-- @param self Self reference
-- @return Skeleton#Skeleton

---
-- Function GetNumGeometries
--
-- @function [parent=#Model] GetNumGeometries
-- @param self Self reference
-- @return #number

---
-- Function GetNumGeometryLodLevels
--
-- @function [parent=#Model] GetNumGeometryLodLevels
-- @param self Self reference
-- @param #number index index
-- @return #number

---
-- Function GetGeometry
--
-- @function [parent=#Model] GetGeometry
-- @param self Self reference
-- @param #number index index
-- @param #number lodLevel lodLevel
-- @return Geometry#Geometry

---
-- Function GetNumMorphs
--
-- @function [parent=#Model] GetNumMorphs
-- @param self Self reference
-- @return #number

---
-- Function GetMorph
--
-- @function [parent=#Model] GetMorph
-- @param self Self reference
-- @param #string name name
-- @return const ModelMorph#const ModelMorph

---
-- Function GetMorph
--
-- @function [parent=#Model] GetMorph
-- @param self Self reference
-- @param StringHash#StringHash nameHash nameHash
-- @return const ModelMorph#const ModelMorph

---
-- Function GetMorph
--
-- @function [parent=#Model] GetMorph
-- @param self Self reference
-- @param #number index index
-- @return const ModelMorph#const ModelMorph

---
-- Function GetMorphRangeStart
--
-- @function [parent=#Model] GetMorphRangeStart
-- @param self Self reference
-- @param #number bufferIndex bufferIndex
-- @return #number

---
-- Function GetMorphRangeCount
--
-- @function [parent=#Model] GetMorphRangeCount
-- @param self Self reference
-- @param #number bufferIndex bufferIndex
-- @return #number

---
-- Field boundingBox (Read only)
--
-- @field [parent=#Model] BoundingBox#BoundingBox boundingBox

---
-- Field skeleton (Read only)
--
-- @field [parent=#Model] Skeleton#Skeleton skeleton

---
-- Field numGeometries (Read only)
--
-- @field [parent=#Model] #number numGeometries

---
-- Field numMorphs (Read only)
--
-- @field [parent=#Model] #number numMorphs

---
-- Function Load
--
-- @function [parent=#Model] Load
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#Model] Save
-- @param self Self reference
-- @param Serializer#Serializer dest dest
-- @return #boolean

---
-- Function Load
--
-- @function [parent=#Model] Load
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#Model] Save
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function GetName
--
-- @function [parent=#Model] GetName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetNameHash
--
-- @function [parent=#Model] GetNameHash
-- @param self Self reference
-- @return StringHash#StringHash

---
-- Function GetMemoryUse
--
-- @function [parent=#Model] GetMemoryUse
-- @param self Self reference
-- @return #number

---
-- Field name (Read only)
--
-- @field [parent=#Model] #string name

---
-- Field nameHash (Read only)
--
-- @field [parent=#Model] StringHash#StringHash nameHash

---
-- Field memoryUse (Read only)
--
-- @field [parent=#Model] #number memoryUse


return nil
