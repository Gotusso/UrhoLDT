---
-- Module Model
-- Extends Resource
--
-- @module Model

---
-- Function GetBoundingBox
--
-- @function [parent=#Model] GetBoundingBox
-- @return const BoundingBox#const BoundingBox

---
-- Function GetSkeleton
--
-- @function [parent=#Model] GetSkeleton
-- @return Skeleton#Skeleton

---
-- Function GetNumGeometries
--
-- @function [parent=#Model] GetNumGeometries
-- @return #number

---
-- Function GetNumGeometryLodLevels
--
-- @function [parent=#Model] GetNumGeometryLodLevels
-- @param #number indexindex
-- @return #number

---
-- Function GetGeometry
--
-- @function [parent=#Model] GetGeometry
-- @param #number indexindex
-- @param #number lodLevellodLevel
-- @return Geometry#Geometry

---
-- Function GetNumMorphs
--
-- @function [parent=#Model] GetNumMorphs
-- @return #number

---
-- Function GetMorph
--
-- @function [parent=#Model] GetMorph
-- @param #string namename
-- @return const ModelMorph#const ModelMorph

---
-- Function GetMorph
--
-- @function [parent=#Model] GetMorph
-- @param StringHash#StringHash nameHashnameHash
-- @return const ModelMorph#const ModelMorph

---
-- Function GetMorph
--
-- @function [parent=#Model] GetMorph
-- @param #number indexindex
-- @return const ModelMorph#const ModelMorph

---
-- Function GetMorphRangeStart
--
-- @function [parent=#Model] GetMorphRangeStart
-- @param #number bufferIndexbufferIndex
-- @return #number

---
-- Function GetMorphRangeCount
--
-- @function [parent=#Model] GetMorphRangeCount
-- @param #number bufferIndexbufferIndex
-- @return #number

---
-- Field boundingBox (Read only)
--
-- @field [parent=#Model] BoundingBox#BoundingBox boundingBox

---
-- Field skeleton (Read only)
--
-- @field [parent=#Model] Skeleton#Skeleton skeleton

---
-- Field numGeometries (Read only)
--
-- @field [parent=#Model] #number numGeometries

---
-- Field numMorphs (Read only)
--
-- @field [parent=#Model] #number numMorphs


return nil
