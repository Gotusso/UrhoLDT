---
-- Module TerrainPatch
-- Module TerrainPatch extends Drawable
-- Generated on 2014-05-31
--
-- @module TerrainPatch

---
-- Function SetOwner()
-- Set owner terrain.
--
-- @function [parent=#TerrainPatch] SetOwner
-- @param self Self reference
-- @param Terrain#Terrain terrain terrain

---
-- Function SetNeighbors()
-- Set neighbor patches.
--
-- @function [parent=#TerrainPatch] SetNeighbors
-- @param self Self reference
-- @param TerrainPatch#TerrainPatch north north
-- @param TerrainPatch#TerrainPatch south south
-- @param TerrainPatch#TerrainPatch west west
-- @param TerrainPatch#TerrainPatch east east

---
-- Function SetMaterial()
-- Set material.
--
-- @function [parent=#TerrainPatch] SetMaterial
-- @param self Self reference
-- @param Material#Material material material

---
-- Function SetBoundingBox()
-- Set local-space bounding box.
--
-- @function [parent=#TerrainPatch] SetBoundingBox
-- @param self Self reference
-- @param BoundingBox#BoundingBox box box

---
-- Function SetCoordinates()
-- Set patch coordinates.
--
-- @function [parent=#TerrainPatch] SetCoordinates
-- @param self Self reference
-- @param IntVector2#IntVector2 coordinates coordinates

---
-- Function SetOcclusionOffset()
-- Set vertical offset for occlusion geometry. Should be negative.
--
-- @function [parent=#TerrainPatch] SetOcclusionOffset
-- @param self Self reference
-- @param #number offset offset

---
-- Function ResetLod()
-- Reset to LOD level 0.
--
-- @function [parent=#TerrainPatch] ResetLod
-- @param self Self reference

---
-- Function GetGeometry()
-- Return visible geometry.
--
-- @function [parent=#TerrainPatch] GetGeometry
-- @param self Self reference
-- @return Geometry#Geometry

---
-- Function GetMaxLodGeometry()
-- Return max LOD geometry.
--
-- @function [parent=#TerrainPatch] GetMaxLodGeometry
-- @param self Self reference
-- @return Geometry#Geometry

---
-- Function GetMinLodGeometry()
-- Return min LOD geometry.
--
-- @function [parent=#TerrainPatch] GetMinLodGeometry
-- @param self Self reference
-- @return Geometry#Geometry

---
-- Function GetVertexBuffer()
-- Return vertex buffer.
--
-- @function [parent=#TerrainPatch] GetVertexBuffer
-- @param self Self reference
-- @return VertexBuffer#VertexBuffer

---
-- Function GetOwner()
-- Return owner terrain.
--
-- @function [parent=#TerrainPatch] GetOwner
-- @param self Self reference
-- @return Terrain#Terrain

---
-- Function GetNorthPatch()
-- Return north neighbor patch.
--
-- @function [parent=#TerrainPatch] GetNorthPatch
-- @param self Self reference
-- @return TerrainPatch#TerrainPatch

---
-- Function GetSouthPatch()
-- Return south neighbor patch.
--
-- @function [parent=#TerrainPatch] GetSouthPatch
-- @param self Self reference
-- @return TerrainPatch#TerrainPatch

---
-- Function GetWestPatch()
-- Return west neighbor patch.
--
-- @function [parent=#TerrainPatch] GetWestPatch
-- @param self Self reference
-- @return TerrainPatch#TerrainPatch

---
-- Function GetEastPatch()
-- Return east neighbor patch.
--
-- @function [parent=#TerrainPatch] GetEastPatch
-- @param self Self reference
-- @return TerrainPatch#TerrainPatch

---
-- Function GetCoordinates()
-- Return patch coordinates.
--
-- @function [parent=#TerrainPatch] GetCoordinates
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetLodLevel()
-- Return current LOD level.
--
-- @function [parent=#TerrainPatch] GetLodLevel
-- @param self Self reference
-- @return #number

---
-- Function GetOcclusionOffset()
-- Return vertical offset for occlusion geometry..
--
-- @function [parent=#TerrainPatch] GetOcclusionOffset
-- @param self Self reference
-- @return #number

---
-- Field geometry (Read only)
--
-- @field [parent=#TerrainPatch] Geometry#Geometry geometry

---
-- Field maxLodGeometry (Read only)
--
-- @field [parent=#TerrainPatch] Geometry#Geometry maxLodGeometry

---
-- Field minLodGeometry (Read only)
--
-- @field [parent=#TerrainPatch] Geometry#Geometry minLodGeometry

---
-- Field vertexBuffer (Read only)
--
-- @field [parent=#TerrainPatch] VertexBuffer#VertexBuffer vertexBuffer

---
-- Field owner
--
-- @field [parent=#TerrainPatch] Terrain#Terrain owner

---
-- Field northPatch (Read only)
--
-- @field [parent=#TerrainPatch] TerrainPatch#TerrainPatch northPatch

---
-- Field southPatch (Read only)
--
-- @field [parent=#TerrainPatch] TerrainPatch#TerrainPatch southPatch

---
-- Field westPatch (Read only)
--
-- @field [parent=#TerrainPatch] TerrainPatch#TerrainPatch westPatch

---
-- Field eastPatch (Read only)
--
-- @field [parent=#TerrainPatch] TerrainPatch#TerrainPatch eastPatch

---
-- Field boundingBox
--
-- @field [parent=#TerrainPatch] BoundingBox#BoundingBox boundingBox

---
-- Field coordinates
--
-- @field [parent=#TerrainPatch] IntVector2#IntVector2 coordinates

---
-- Field lodLevel (Read only)
--
-- @field [parent=#TerrainPatch] #number lodLevel

---
-- Field occlusionOffset
--
-- @field [parent=#TerrainPatch] #number occlusionOffset


return nil
