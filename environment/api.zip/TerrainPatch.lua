---
-- Module TerrainPatch
-- extends Drawable
--
-- @module TerrainPatch

---
-- Function SetOwner
--
-- @function [parent=#TerrainPatch] SetOwner
-- @param Terrain#Terrain terrainterrain

---
-- Function SetNeighbors
--
-- @function [parent=#TerrainPatch] SetNeighbors
-- @param TerrainPatch#TerrainPatch northnorth
-- @param TerrainPatch#TerrainPatch southsouth
-- @param TerrainPatch#TerrainPatch westwest
-- @param TerrainPatch#TerrainPatch easteast

---
-- Function SetMaterial
--
-- @function [parent=#TerrainPatch] SetMaterial
-- @param Material#Material materialmaterial

---
-- Function SetBoundingBox
--
-- @function [parent=#TerrainPatch] SetBoundingBox
-- @param BoundingBox#BoundingBox boxbox

---
-- Function SetCoordinates
--
-- @function [parent=#TerrainPatch] SetCoordinates
-- @param IntVector2#IntVector2 coordinatescoordinates

---
-- Function SetOcclusionOffset
--
-- @function [parent=#TerrainPatch] SetOcclusionOffset
-- @param #number offsetoffset

---
-- Function ResetLod
--
-- @function [parent=#TerrainPatch] ResetLod

---
-- Function GetGeometry
--
-- @function [parent=#TerrainPatch] GetGeometry
-- @return Geometry#Geometry

---
-- Function GetMaxLodGeometry
--
-- @function [parent=#TerrainPatch] GetMaxLodGeometry
-- @return Geometry#Geometry

---
-- Function GetMinLodGeometry
--
-- @function [parent=#TerrainPatch] GetMinLodGeometry
-- @return Geometry#Geometry

---
-- Function GetVertexBuffer
--
-- @function [parent=#TerrainPatch] GetVertexBuffer
-- @return VertexBuffer#VertexBuffer

---
-- Function GetOwner
--
-- @function [parent=#TerrainPatch] GetOwner
-- @return Terrain#Terrain

---
-- Function GetNorthPatch
--
-- @function [parent=#TerrainPatch] GetNorthPatch
-- @return TerrainPatch#TerrainPatch

---
-- Function GetSouthPatch
--
-- @function [parent=#TerrainPatch] GetSouthPatch
-- @return TerrainPatch#TerrainPatch

---
-- Function GetWestPatch
--
-- @function [parent=#TerrainPatch] GetWestPatch
-- @return TerrainPatch#TerrainPatch

---
-- Function GetEastPatch
--
-- @function [parent=#TerrainPatch] GetEastPatch
-- @return TerrainPatch#TerrainPatch

---
-- Function GetCoordinates
--
-- @function [parent=#TerrainPatch] GetCoordinates
-- @return const IntVector2#const IntVector2

---
-- Function GetLodLevel
--
-- @function [parent=#TerrainPatch] GetLodLevel
-- @return #number

---
-- Function GetOcclusionOffset
--
-- @function [parent=#TerrainPatch] GetOcclusionOffset
-- @return #number

---
-- Field geometry (Read only)
--
-- @field [parent=#TerrainPatch] Geometry#Geometry geometry

---
-- Field maxLodGeometry (Read only)
--
-- @field [parent=#TerrainPatch] Geometry#Geometry maxLodGeometry

---
-- Field minLodGeometry (Read only)
--
-- @field [parent=#TerrainPatch] Geometry#Geometry minLodGeometry

---
-- Field vertexBuffer (Read only)
--
-- @field [parent=#TerrainPatch] VertexBuffer#VertexBuffer vertexBuffer

---
-- Field owner
--
-- @field [parent=#TerrainPatch] Terrain#Terrain owner

---
-- Field northPatch (Read only)
--
-- @field [parent=#TerrainPatch] TerrainPatch#TerrainPatch northPatch

---
-- Field southPatch (Read only)
--
-- @field [parent=#TerrainPatch] TerrainPatch#TerrainPatch southPatch

---
-- Field westPatch (Read only)
--
-- @field [parent=#TerrainPatch] TerrainPatch#TerrainPatch westPatch

---
-- Field eastPatch (Read only)
--
-- @field [parent=#TerrainPatch] TerrainPatch#TerrainPatch eastPatch

---
-- Field boundingBox
--
-- @field [parent=#TerrainPatch] BoundingBox#BoundingBox boundingBox

---
-- Field coordinates
--
-- @field [parent=#TerrainPatch] IntVector2#IntVector2 coordinates

---
-- Field lodLevel (Read only)
--
-- @field [parent=#TerrainPatch] #number lodLevel

---
-- Field occlusionOffset
--
-- @field [parent=#TerrainPatch] #number occlusionOffset

---
-- Function SetDrawDistance
--
-- @function [parent=#TerrainPatch] SetDrawDistance
-- @param #number distancedistance

---
-- Function SetShadowDistance
--
-- @function [parent=#TerrainPatch] SetShadowDistance
-- @param #number distancedistance

---
-- Function SetLodBias
--
-- @function [parent=#TerrainPatch] SetLodBias
-- @param #number biasbias

---
-- Function SetViewMask
--
-- @function [parent=#TerrainPatch] SetViewMask
-- @param #number maskmask

---
-- Function SetLightMask
--
-- @function [parent=#TerrainPatch] SetLightMask
-- @param #number maskmask

---
-- Function SetShadowMask
--
-- @function [parent=#TerrainPatch] SetShadowMask
-- @param #number maskmask

---
-- Function SetZoneMask
--
-- @function [parent=#TerrainPatch] SetZoneMask
-- @param #number maskmask

---
-- Function SetMaxLights
--
-- @function [parent=#TerrainPatch] SetMaxLights
-- @param #number numnum

---
-- Function SetCastShadows
--
-- @function [parent=#TerrainPatch] SetCastShadows
-- @param #boolean enableenable

---
-- Function SetOccluder
--
-- @function [parent=#TerrainPatch] SetOccluder
-- @param #boolean enableenable

---
-- Function SetOccludee
--
-- @function [parent=#TerrainPatch] SetOccludee
-- @param #boolean enableenable

---
-- Function MarkForUpdate
--
-- @function [parent=#TerrainPatch] MarkForUpdate

---
-- Function GetBoundingBox
--
-- @function [parent=#TerrainPatch] GetBoundingBox
-- @return const BoundingBox#const BoundingBox

---
-- Function GetWorldBoundingBox
--
-- @function [parent=#TerrainPatch] GetWorldBoundingBox
-- @return const BoundingBox#const BoundingBox

---
-- Function GetDrawableFlags
--
-- @function [parent=#TerrainPatch] GetDrawableFlags
-- @return #string

---
-- Function GetDrawDistance
--
-- @function [parent=#TerrainPatch] GetDrawDistance
-- @return #number

---
-- Function GetShadowDistance
--
-- @function [parent=#TerrainPatch] GetShadowDistance
-- @return #number

---
-- Function GetLodBias
--
-- @function [parent=#TerrainPatch] GetLodBias
-- @return #number

---
-- Function GetViewMask
--
-- @function [parent=#TerrainPatch] GetViewMask
-- @return #number

---
-- Function GetLightMask
--
-- @function [parent=#TerrainPatch] GetLightMask
-- @return #number

---
-- Function GetShadowMask
--
-- @function [parent=#TerrainPatch] GetShadowMask
-- @return #number

---
-- Function GetZoneMask
--
-- @function [parent=#TerrainPatch] GetZoneMask
-- @return #number

---
-- Function GetMaxLights
--
-- @function [parent=#TerrainPatch] GetMaxLights
-- @return #number

---
-- Function GetCastShadows
--
-- @function [parent=#TerrainPatch] GetCastShadows
-- @return #boolean

---
-- Function IsOccluder
--
-- @function [parent=#TerrainPatch] IsOccluder
-- @return #boolean

---
-- Function IsOccludee
--
-- @function [parent=#TerrainPatch] IsOccludee
-- @return #boolean

---
-- Function SetZone
--
-- @function [parent=#TerrainPatch] SetZone
-- @param Zone#Zone zonezone
-- @param #boolean temporarytemporary

---
-- Function SetSortValue
--
-- @function [parent=#TerrainPatch] SetSortValue
-- @param #number valuevalue

---
-- Function SetMinMaxZ
--
-- @function [parent=#TerrainPatch] SetMinMaxZ
-- @param #number minZminZ
-- @param #number maxZmaxZ

---
-- Function MarkInView
--
-- @function [parent=#TerrainPatch] MarkInView
-- @param FrameInfo#FrameInfo frameframe
-- @param #boolean mainViewmainView

---
-- Function ClearLights
--
-- @function [parent=#TerrainPatch] ClearLights

---
-- Function AddLight
--
-- @function [parent=#TerrainPatch] AddLight
-- @param Light#Light lightlight

---
-- Function AddVertexLight
--
-- @function [parent=#TerrainPatch] AddVertexLight
-- @param Light#Light lightlight

---
-- Function LimitLights
--
-- @function [parent=#TerrainPatch] LimitLights

---
-- Function LimitVertexLights
--
-- @function [parent=#TerrainPatch] LimitVertexLights

---
-- Function SetBasePass
--
-- @function [parent=#TerrainPatch] SetBasePass
-- @param #number batchIndexbatchIndex

---
-- Function GetOctant
--
-- @function [parent=#TerrainPatch] GetOctant
-- @return Octant#Octant

---
-- Function GetZone
--
-- @function [parent=#TerrainPatch] GetZone
-- @return Zone#Zone

---
-- Function GetLastZone
--
-- @function [parent=#TerrainPatch] GetLastZone
-- @return Zone#Zone

---
-- Function IsZoneDirty
--
-- @function [parent=#TerrainPatch] IsZoneDirty
-- @return #boolean

---
-- Function GetDistance
--
-- @function [parent=#TerrainPatch] GetDistance
-- @return #number

---
-- Function GetLodDistance
--
-- @function [parent=#TerrainPatch] GetLodDistance
-- @return #number

---
-- Function GetSortValue
--
-- @function [parent=#TerrainPatch] GetSortValue
-- @return #number

---
-- Function IsInView
--
-- @function [parent=#TerrainPatch] IsInView
-- @param #number frameNumberframeNumber
-- @return #boolean

---
-- Function IsInView
--
-- @function [parent=#TerrainPatch] IsInView
-- @param FrameInfo#FrameInfo frameframe
-- @param #boolean mainViewmainView
-- @return #boolean

---
-- Function HasBasePass
--
-- @function [parent=#TerrainPatch] HasBasePass
-- @param #number batchIndexbatchIndex
-- @return #boolean

---
-- Function GetFirstLight
--
-- @function [parent=#TerrainPatch] GetFirstLight
-- @return Light#Light

---
-- Function GetMinZ
--
-- @function [parent=#TerrainPatch] GetMinZ
-- @return #number

---
-- Function GetMaxZ
--
-- @function [parent=#TerrainPatch] GetMaxZ
-- @return #number

---
-- Field worldBoundingBox (Read only)
--
-- @field [parent=#TerrainPatch] BoundingBox#BoundingBox worldBoundingBox

---
-- Field drawableFlags (Read only)
--
-- @field [parent=#TerrainPatch] #string drawableFlags

---
-- Field drawDistance
--
-- @field [parent=#TerrainPatch] #number drawDistance

---
-- Field shadowDistance
--
-- @field [parent=#TerrainPatch] #number shadowDistance

---
-- Field lodBias
--
-- @field [parent=#TerrainPatch] #number lodBias

---
-- Field viewMask
--
-- @field [parent=#TerrainPatch] #number viewMask

---
-- Field lightMask
--
-- @field [parent=#TerrainPatch] #number lightMask

---
-- Field shadowMask
--
-- @field [parent=#TerrainPatch] #number shadowMask

---
-- Field zoneMask
--
-- @field [parent=#TerrainPatch] #number zoneMask

---
-- Field maxLights
--
-- @field [parent=#TerrainPatch] #number maxLights

---
-- Field castShadows
--
-- @field [parent=#TerrainPatch] #boolean castShadows

---
-- Field occluder
--
-- @field [parent=#TerrainPatch] #boolean occluder

---
-- Field occludee
--
-- @field [parent=#TerrainPatch] #boolean occludee

---
-- Field octant (Read only)
--
-- @field [parent=#TerrainPatch] Octant#Octant octant

---
-- Field zone
--
-- @field [parent=#TerrainPatch] Zone#Zone zone

---
-- Field lastZone (Read only)
--
-- @field [parent=#TerrainPatch] Zone#Zone lastZone

---
-- Field zoneDirty (Read only)
--
-- @field [parent=#TerrainPatch] #boolean zoneDirty

---
-- Field distance (Read only)
--
-- @field [parent=#TerrainPatch] #number distance

---
-- Field lodDistance (Read only)
--
-- @field [parent=#TerrainPatch] #number lodDistance

---
-- Field sortValue
--
-- @field [parent=#TerrainPatch] #number sortValue

---
-- Field firstLight (Read only)
--
-- @field [parent=#TerrainPatch] Light#Light firstLight

---
-- Field minZ (Read only)
--
-- @field [parent=#TerrainPatch] #number minZ

---
-- Field maxZ (Read only)
--
-- @field [parent=#TerrainPatch] #number maxZ

---
-- Function SetEnabled
--
-- @function [parent=#TerrainPatch] SetEnabled
-- @param #boolean enableenable

---
-- Function Remove
--
-- @function [parent=#TerrainPatch] Remove

---
-- Function GetID
--
-- @function [parent=#TerrainPatch] GetID
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#TerrainPatch] GetNode
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#TerrainPatch] GetScene
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#TerrainPatch] IsEnabled
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#TerrainPatch] IsEnabledEffective
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#TerrainPatch] GetComponent
-- @param ShortStringHash#ShortStringHash typetype
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#TerrainPatch] GetComponent
-- @param #string typetype
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#TerrainPatch] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#TerrainPatch] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#TerrainPatch] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#TerrainPatch] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#TerrainPatch] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#TerrainPatch] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#TerrainPatch] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#TerrainPatch] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#TerrainPatch] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#TerrainPatch] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#TerrainPatch] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#TerrainPatch] #string category


return nil
