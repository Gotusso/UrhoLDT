---
-- Module TerrainPatch
-- Module TerrainPatch extends Drawable
-- Generated on 2014-03-13
--
-- @module TerrainPatch

---
-- Function SetOwner
--
-- @function [parent=#TerrainPatch] SetOwner
-- @param self Self reference
-- @param Terrain#Terrain terrain terrain

---
-- Function SetNeighbors
--
-- @function [parent=#TerrainPatch] SetNeighbors
-- @param self Self reference
-- @param TerrainPatch#TerrainPatch north north
-- @param TerrainPatch#TerrainPatch south south
-- @param TerrainPatch#TerrainPatch west west
-- @param TerrainPatch#TerrainPatch east east

---
-- Function SetMaterial
--
-- @function [parent=#TerrainPatch] SetMaterial
-- @param self Self reference
-- @param Material#Material material material

---
-- Function SetBoundingBox
--
-- @function [parent=#TerrainPatch] SetBoundingBox
-- @param self Self reference
-- @param BoundingBox#BoundingBox box box

---
-- Function SetCoordinates
--
-- @function [parent=#TerrainPatch] SetCoordinates
-- @param self Self reference
-- @param IntVector2#IntVector2 coordinates coordinates

---
-- Function SetOcclusionOffset
--
-- @function [parent=#TerrainPatch] SetOcclusionOffset
-- @param self Self reference
-- @param #number offset offset

---
-- Function ResetLod
--
-- @function [parent=#TerrainPatch] ResetLod
-- @param self Self reference

---
-- Function GetGeometry
--
-- @function [parent=#TerrainPatch] GetGeometry
-- @param self Self reference
-- @return Geometry#Geometry

---
-- Function GetMaxLodGeometry
--
-- @function [parent=#TerrainPatch] GetMaxLodGeometry
-- @param self Self reference
-- @return Geometry#Geometry

---
-- Function GetMinLodGeometry
--
-- @function [parent=#TerrainPatch] GetMinLodGeometry
-- @param self Self reference
-- @return Geometry#Geometry

---
-- Function GetVertexBuffer
--
-- @function [parent=#TerrainPatch] GetVertexBuffer
-- @param self Self reference
-- @return VertexBuffer#VertexBuffer

---
-- Function GetOwner
--
-- @function [parent=#TerrainPatch] GetOwner
-- @param self Self reference
-- @return Terrain#Terrain

---
-- Function GetNorthPatch
--
-- @function [parent=#TerrainPatch] GetNorthPatch
-- @param self Self reference
-- @return TerrainPatch#TerrainPatch

---
-- Function GetSouthPatch
--
-- @function [parent=#TerrainPatch] GetSouthPatch
-- @param self Self reference
-- @return TerrainPatch#TerrainPatch

---
-- Function GetWestPatch
--
-- @function [parent=#TerrainPatch] GetWestPatch
-- @param self Self reference
-- @return TerrainPatch#TerrainPatch

---
-- Function GetEastPatch
--
-- @function [parent=#TerrainPatch] GetEastPatch
-- @param self Self reference
-- @return TerrainPatch#TerrainPatch

---
-- Function GetCoordinates
--
-- @function [parent=#TerrainPatch] GetCoordinates
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetLodLevel
--
-- @function [parent=#TerrainPatch] GetLodLevel
-- @param self Self reference
-- @return #number

---
-- Function GetOcclusionOffset
--
-- @function [parent=#TerrainPatch] GetOcclusionOffset
-- @param self Self reference
-- @return #number

---
-- Field geometry (Read only)
--
-- @field [parent=#TerrainPatch] Geometry#Geometry geometry

---
-- Field maxLodGeometry (Read only)
--
-- @field [parent=#TerrainPatch] Geometry#Geometry maxLodGeometry

---
-- Field minLodGeometry (Read only)
--
-- @field [parent=#TerrainPatch] Geometry#Geometry minLodGeometry

---
-- Field vertexBuffer (Read only)
--
-- @field [parent=#TerrainPatch] VertexBuffer#VertexBuffer vertexBuffer

---
-- Field owner
--
-- @field [parent=#TerrainPatch] Terrain#Terrain owner

---
-- Field northPatch (Read only)
--
-- @field [parent=#TerrainPatch] TerrainPatch#TerrainPatch northPatch

---
-- Field southPatch (Read only)
--
-- @field [parent=#TerrainPatch] TerrainPatch#TerrainPatch southPatch

---
-- Field westPatch (Read only)
--
-- @field [parent=#TerrainPatch] TerrainPatch#TerrainPatch westPatch

---
-- Field eastPatch (Read only)
--
-- @field [parent=#TerrainPatch] TerrainPatch#TerrainPatch eastPatch

---
-- Field boundingBox
--
-- @field [parent=#TerrainPatch] BoundingBox#BoundingBox boundingBox

---
-- Field coordinates
--
-- @field [parent=#TerrainPatch] IntVector2#IntVector2 coordinates

---
-- Field lodLevel (Read only)
--
-- @field [parent=#TerrainPatch] #number lodLevel

---
-- Field occlusionOffset
--
-- @field [parent=#TerrainPatch] #number occlusionOffset

---
-- Function SetDrawDistance
--
-- @function [parent=#TerrainPatch] SetDrawDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetShadowDistance
--
-- @function [parent=#TerrainPatch] SetShadowDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetLodBias
--
-- @function [parent=#TerrainPatch] SetLodBias
-- @param self Self reference
-- @param #number bias bias

---
-- Function SetViewMask
--
-- @function [parent=#TerrainPatch] SetViewMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetLightMask
--
-- @function [parent=#TerrainPatch] SetLightMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetShadowMask
--
-- @function [parent=#TerrainPatch] SetShadowMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetZoneMask
--
-- @function [parent=#TerrainPatch] SetZoneMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetMaxLights
--
-- @function [parent=#TerrainPatch] SetMaxLights
-- @param self Self reference
-- @param #number num num

---
-- Function SetCastShadows
--
-- @function [parent=#TerrainPatch] SetCastShadows
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetOccluder
--
-- @function [parent=#TerrainPatch] SetOccluder
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetOccludee
--
-- @function [parent=#TerrainPatch] SetOccludee
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function MarkForUpdate
--
-- @function [parent=#TerrainPatch] MarkForUpdate
-- @param self Self reference

---
-- Function GetBoundingBox
--
-- @function [parent=#TerrainPatch] GetBoundingBox
-- @param self Self reference
-- @return const BoundingBox#const BoundingBox

---
-- Function GetWorldBoundingBox
--
-- @function [parent=#TerrainPatch] GetWorldBoundingBox
-- @param self Self reference
-- @return const BoundingBox#const BoundingBox

---
-- Function GetDrawableFlags
--
-- @function [parent=#TerrainPatch] GetDrawableFlags
-- @param self Self reference
-- @return #string

---
-- Function GetDrawDistance
--
-- @function [parent=#TerrainPatch] GetDrawDistance
-- @param self Self reference
-- @return #number

---
-- Function GetShadowDistance
--
-- @function [parent=#TerrainPatch] GetShadowDistance
-- @param self Self reference
-- @return #number

---
-- Function GetLodBias
--
-- @function [parent=#TerrainPatch] GetLodBias
-- @param self Self reference
-- @return #number

---
-- Function GetViewMask
--
-- @function [parent=#TerrainPatch] GetViewMask
-- @param self Self reference
-- @return #number

---
-- Function GetLightMask
--
-- @function [parent=#TerrainPatch] GetLightMask
-- @param self Self reference
-- @return #number

---
-- Function GetShadowMask
--
-- @function [parent=#TerrainPatch] GetShadowMask
-- @param self Self reference
-- @return #number

---
-- Function GetZoneMask
--
-- @function [parent=#TerrainPatch] GetZoneMask
-- @param self Self reference
-- @return #number

---
-- Function GetMaxLights
--
-- @function [parent=#TerrainPatch] GetMaxLights
-- @param self Self reference
-- @return #number

---
-- Function GetCastShadows
--
-- @function [parent=#TerrainPatch] GetCastShadows
-- @param self Self reference
-- @return #boolean

---
-- Function IsOccluder
--
-- @function [parent=#TerrainPatch] IsOccluder
-- @param self Self reference
-- @return #boolean

---
-- Function IsOccludee
--
-- @function [parent=#TerrainPatch] IsOccludee
-- @param self Self reference
-- @return #boolean

---
-- Function SetZone
--
-- @function [parent=#TerrainPatch] SetZone
-- @param self Self reference
-- @param Zone#Zone zone zone
-- @param #boolean temporary temporary

---
-- Function SetSortValue
--
-- @function [parent=#TerrainPatch] SetSortValue
-- @param self Self reference
-- @param #number value value

---
-- Function SetMinMaxZ
--
-- @function [parent=#TerrainPatch] SetMinMaxZ
-- @param self Self reference
-- @param #number minZ minZ
-- @param #number maxZ maxZ

---
-- Function MarkInView
--
-- @function [parent=#TerrainPatch] MarkInView
-- @param self Self reference
-- @param FrameInfo#FrameInfo frame frame
-- @param #boolean mainView mainView

---
-- Function ClearLights
--
-- @function [parent=#TerrainPatch] ClearLights
-- @param self Self reference

---
-- Function AddLight
--
-- @function [parent=#TerrainPatch] AddLight
-- @param self Self reference
-- @param Light#Light light light

---
-- Function AddVertexLight
--
-- @function [parent=#TerrainPatch] AddVertexLight
-- @param self Self reference
-- @param Light#Light light light

---
-- Function LimitLights
--
-- @function [parent=#TerrainPatch] LimitLights
-- @param self Self reference

---
-- Function LimitVertexLights
--
-- @function [parent=#TerrainPatch] LimitVertexLights
-- @param self Self reference

---
-- Function SetBasePass
--
-- @function [parent=#TerrainPatch] SetBasePass
-- @param self Self reference
-- @param #number batchIndex batchIndex

---
-- Function GetOctant
--
-- @function [parent=#TerrainPatch] GetOctant
-- @param self Self reference
-- @return Octant#Octant

---
-- Function GetZone
--
-- @function [parent=#TerrainPatch] GetZone
-- @param self Self reference
-- @return Zone#Zone

---
-- Function GetLastZone
--
-- @function [parent=#TerrainPatch] GetLastZone
-- @param self Self reference
-- @return Zone#Zone

---
-- Function IsZoneDirty
--
-- @function [parent=#TerrainPatch] IsZoneDirty
-- @param self Self reference
-- @return #boolean

---
-- Function GetDistance
--
-- @function [parent=#TerrainPatch] GetDistance
-- @param self Self reference
-- @return #number

---
-- Function GetLodDistance
--
-- @function [parent=#TerrainPatch] GetLodDistance
-- @param self Self reference
-- @return #number

---
-- Function GetSortValue
--
-- @function [parent=#TerrainPatch] GetSortValue
-- @param self Self reference
-- @return #number

---
-- Function IsInView
--
-- @function [parent=#TerrainPatch] IsInView
-- @param self Self reference
-- @param #number frameNumber frameNumber
-- @return #boolean

---
-- Function IsInView
--
-- @function [parent=#TerrainPatch] IsInView
-- @param self Self reference
-- @param FrameInfo#FrameInfo frame frame
-- @param #boolean mainView mainView
-- @return #boolean

---
-- Function HasBasePass
--
-- @function [parent=#TerrainPatch] HasBasePass
-- @param self Self reference
-- @param #number batchIndex batchIndex
-- @return #boolean

---
-- Function GetFirstLight
--
-- @function [parent=#TerrainPatch] GetFirstLight
-- @param self Self reference
-- @return Light#Light

---
-- Function GetMinZ
--
-- @function [parent=#TerrainPatch] GetMinZ
-- @param self Self reference
-- @return #number

---
-- Function GetMaxZ
--
-- @function [parent=#TerrainPatch] GetMaxZ
-- @param self Self reference
-- @return #number

---
-- Field worldBoundingBox (Read only)
--
-- @field [parent=#TerrainPatch] BoundingBox#BoundingBox worldBoundingBox

---
-- Field drawableFlags (Read only)
--
-- @field [parent=#TerrainPatch] #string drawableFlags

---
-- Field drawDistance
--
-- @field [parent=#TerrainPatch] #number drawDistance

---
-- Field shadowDistance
--
-- @field [parent=#TerrainPatch] #number shadowDistance

---
-- Field lodBias
--
-- @field [parent=#TerrainPatch] #number lodBias

---
-- Field viewMask
--
-- @field [parent=#TerrainPatch] #number viewMask

---
-- Field lightMask
--
-- @field [parent=#TerrainPatch] #number lightMask

---
-- Field shadowMask
--
-- @field [parent=#TerrainPatch] #number shadowMask

---
-- Field zoneMask
--
-- @field [parent=#TerrainPatch] #number zoneMask

---
-- Field maxLights
--
-- @field [parent=#TerrainPatch] #number maxLights

---
-- Field castShadows
--
-- @field [parent=#TerrainPatch] #boolean castShadows

---
-- Field occluder
--
-- @field [parent=#TerrainPatch] #boolean occluder

---
-- Field occludee
--
-- @field [parent=#TerrainPatch] #boolean occludee

---
-- Field octant (Read only)
--
-- @field [parent=#TerrainPatch] Octant#Octant octant

---
-- Field zone
--
-- @field [parent=#TerrainPatch] Zone#Zone zone

---
-- Field lastZone (Read only)
--
-- @field [parent=#TerrainPatch] Zone#Zone lastZone

---
-- Field zoneDirty (Read only)
--
-- @field [parent=#TerrainPatch] #boolean zoneDirty

---
-- Field distance (Read only)
--
-- @field [parent=#TerrainPatch] #number distance

---
-- Field lodDistance (Read only)
--
-- @field [parent=#TerrainPatch] #number lodDistance

---
-- Field sortValue
--
-- @field [parent=#TerrainPatch] #number sortValue

---
-- Field firstLight (Read only)
--
-- @field [parent=#TerrainPatch] Light#Light firstLight

---
-- Field minZ (Read only)
--
-- @field [parent=#TerrainPatch] #number minZ

---
-- Field maxZ (Read only)
--
-- @field [parent=#TerrainPatch] #number maxZ

---
-- Function SetEnabled
--
-- @function [parent=#TerrainPatch] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Remove
--
-- @function [parent=#TerrainPatch] Remove
-- @param self Self reference

---
-- Function GetID
--
-- @function [parent=#TerrainPatch] GetID
-- @param self Self reference
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#TerrainPatch] GetNode
-- @param self Self reference
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#TerrainPatch] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#TerrainPatch] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#TerrainPatch] IsEnabledEffective
-- @param self Self reference
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#TerrainPatch] GetComponent
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#TerrainPatch] GetComponent
-- @param self Self reference
-- @param #string type type
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#TerrainPatch] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#TerrainPatch] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#TerrainPatch] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#TerrainPatch] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#TerrainPatch] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#TerrainPatch] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#TerrainPatch] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#TerrainPatch] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#TerrainPatch] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#TerrainPatch] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#TerrainPatch] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#TerrainPatch] #string category


return nil
