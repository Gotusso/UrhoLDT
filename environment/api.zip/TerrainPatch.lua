---
-- Module TerrainPatch
-- Extends Drawable
--
-- @module TerrainPatch

---
-- Function SetOwner
--
-- @function [parent=#TerrainPatch] SetOwner
-- @param Terrain#Terrain terrainterrain

---
-- Function SetNeighbors
--
-- @function [parent=#TerrainPatch] SetNeighbors
-- @param TerrainPatch#TerrainPatch northnorth
-- @param TerrainPatch#TerrainPatch southsouth
-- @param TerrainPatch#TerrainPatch westwest
-- @param TerrainPatch#TerrainPatch easteast

---
-- Function SetMaterial
--
-- @function [parent=#TerrainPatch] SetMaterial
-- @param Material#Material materialmaterial

---
-- Function SetBoundingBox
--
-- @function [parent=#TerrainPatch] SetBoundingBox
-- @param BoundingBox#BoundingBox boxbox

---
-- Function SetCoordinates
--
-- @function [parent=#TerrainPatch] SetCoordinates
-- @param IntVector2#IntVector2 coordinatescoordinates

---
-- Function SetOcclusionOffset
--
-- @function [parent=#TerrainPatch] SetOcclusionOffset
-- @param #number offsetoffset

---
-- Function ResetLod
--
-- @function [parent=#TerrainPatch] ResetLod

---
-- Function GetGeometry
--
-- @function [parent=#TerrainPatch] GetGeometry
-- @return Geometry#Geometry

---
-- Function GetMaxLodGeometry
--
-- @function [parent=#TerrainPatch] GetMaxLodGeometry
-- @return Geometry#Geometry

---
-- Function GetMinLodGeometry
--
-- @function [parent=#TerrainPatch] GetMinLodGeometry
-- @return Geometry#Geometry

---
-- Function GetVertexBuffer
--
-- @function [parent=#TerrainPatch] GetVertexBuffer
-- @return VertexBuffer#VertexBuffer

---
-- Function GetOwner
--
-- @function [parent=#TerrainPatch] GetOwner
-- @return Terrain#Terrain

---
-- Function GetNorthPatch
--
-- @function [parent=#TerrainPatch] GetNorthPatch
-- @return TerrainPatch#TerrainPatch

---
-- Function GetSouthPatch
--
-- @function [parent=#TerrainPatch] GetSouthPatch
-- @return TerrainPatch#TerrainPatch

---
-- Function GetWestPatch
--
-- @function [parent=#TerrainPatch] GetWestPatch
-- @return TerrainPatch#TerrainPatch

---
-- Function GetEastPatch
--
-- @function [parent=#TerrainPatch] GetEastPatch
-- @return TerrainPatch#TerrainPatch

---
-- Function GetCoordinates
--
-- @function [parent=#TerrainPatch] GetCoordinates
-- @return const IntVector2#const IntVector2

---
-- Function GetLodLevel
--
-- @function [parent=#TerrainPatch] GetLodLevel
-- @return #number

---
-- Function GetOcclusionOffset
--
-- @function [parent=#TerrainPatch] GetOcclusionOffset
-- @return #number

---
-- Field geometry (Read only)
--
-- @field [parent=#TerrainPatch] Geometry#Geometry geometry

---
-- Field maxLodGeometry (Read only)
--
-- @field [parent=#TerrainPatch] Geometry#Geometry maxLodGeometry

---
-- Field minLodGeometry (Read only)
--
-- @field [parent=#TerrainPatch] Geometry#Geometry minLodGeometry

---
-- Field vertexBuffer (Read only)
--
-- @field [parent=#TerrainPatch] VertexBuffer#VertexBuffer vertexBuffer

---
-- Field owner
--
-- @field [parent=#TerrainPatch] Terrain#Terrain owner

---
-- Field northPatch (Read only)
--
-- @field [parent=#TerrainPatch] TerrainPatch#TerrainPatch northPatch

---
-- Field southPatch (Read only)
--
-- @field [parent=#TerrainPatch] TerrainPatch#TerrainPatch southPatch

---
-- Field westPatch (Read only)
--
-- @field [parent=#TerrainPatch] TerrainPatch#TerrainPatch westPatch

---
-- Field eastPatch (Read only)
--
-- @field [parent=#TerrainPatch] TerrainPatch#TerrainPatch eastPatch

---
-- Field boundingBox
--
-- @field [parent=#TerrainPatch] BoundingBox#BoundingBox boundingBox

---
-- Field coordinates
--
-- @field [parent=#TerrainPatch] IntVector2#IntVector2 coordinates

---
-- Field lodLevel (Read only)
--
-- @field [parent=#TerrainPatch] #number lodLevel

---
-- Field occlusionOffset
--
-- @field [parent=#TerrainPatch] #number occlusionOffset


return nil
