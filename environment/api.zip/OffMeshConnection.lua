---
-- Module OffMeshConnection
-- Module OffMeshConnection extends Component
-- Generated on 2014-03-13
--
-- @module OffMeshConnection

---
-- Function SetEndPoint
--
-- @function [parent=#OffMeshConnection] SetEndPoint
-- @param self Self reference
-- @param Node#Node node node

---
-- Function SetRadius
--
-- @function [parent=#OffMeshConnection] SetRadius
-- @param self Self reference
-- @param #number radius radius

---
-- Function SetBidirectional
--
-- @function [parent=#OffMeshConnection] SetBidirectional
-- @param self Self reference
-- @param #boolean enabled enabled

---
-- Function GetEndPoint
--
-- @function [parent=#OffMeshConnection] GetEndPoint
-- @param self Self reference
-- @return Node#Node

---
-- Function GetRadius
--
-- @function [parent=#OffMeshConnection] GetRadius
-- @param self Self reference
-- @return #number

---
-- Function IsBidirectional
--
-- @function [parent=#OffMeshConnection] IsBidirectional
-- @param self Self reference
-- @return #boolean

---
-- Field endPoint
--
-- @field [parent=#OffMeshConnection] Node#Node endPoint

---
-- Field radius
--
-- @field [parent=#OffMeshConnection] #number radius

---
-- Field bidirectional
--
-- @field [parent=#OffMeshConnection] #boolean bidirectional

---
-- Function SetEnabled
--
-- @function [parent=#OffMeshConnection] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Remove
--
-- @function [parent=#OffMeshConnection] Remove
-- @param self Self reference

---
-- Function GetID
--
-- @function [parent=#OffMeshConnection] GetID
-- @param self Self reference
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#OffMeshConnection] GetNode
-- @param self Self reference
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#OffMeshConnection] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#OffMeshConnection] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#OffMeshConnection] IsEnabledEffective
-- @param self Self reference
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#OffMeshConnection] GetComponent
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#OffMeshConnection] GetComponent
-- @param self Self reference
-- @param #string type type
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#OffMeshConnection] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#OffMeshConnection] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#OffMeshConnection] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#OffMeshConnection] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#OffMeshConnection] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#OffMeshConnection] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#OffMeshConnection] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#OffMeshConnection] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#OffMeshConnection] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#OffMeshConnection] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#OffMeshConnection] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#OffMeshConnection] #string category


return nil
