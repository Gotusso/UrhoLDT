---
-- Module OffMeshConnection
-- Module OffMeshConnection extends Component
-- Generated on 2014-05-31
--
-- @module OffMeshConnection

---
-- Function SetEndPoint()
-- Set endpoint node.
--
-- @function [parent=#OffMeshConnection] SetEndPoint
-- @param self Self reference
-- @param Node#Node node node

---
-- Function SetRadius()
-- Set radius.
--
-- @function [parent=#OffMeshConnection] SetRadius
-- @param self Self reference
-- @param #number radius radius

---
-- Function SetBidirectional()
-- Set bidirectional flag. Default true.
--
-- @function [parent=#OffMeshConnection] SetBidirectional
-- @param self Self reference
-- @param #boolean enabled enabled

---
-- Function GetEndPoint()
-- Return endpoint node.
--
-- @function [parent=#OffMeshConnection] GetEndPoint
-- @param self Self reference
-- @return Node#Node

---
-- Function GetRadius()
-- Return radius.
--
-- @function [parent=#OffMeshConnection] GetRadius
-- @param self Self reference
-- @return #number

---
-- Function IsBidirectional()
-- Return whether is bidirectional.
--
-- @function [parent=#OffMeshConnection] IsBidirectional
-- @param self Self reference
-- @return #boolean

---
-- Field endPoint
--
-- @field [parent=#OffMeshConnection] Node#Node endPoint

---
-- Field radius
--
-- @field [parent=#OffMeshConnection] #number radius

---
-- Field bidirectional
--
-- @field [parent=#OffMeshConnection] #boolean bidirectional


return nil
