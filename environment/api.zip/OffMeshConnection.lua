---
-- Module OffMeshConnection
-- extends Component
--
-- @module OffMeshConnection

---
-- Function SetEndPoint
--
-- @function [parent=#OffMeshConnection] SetEndPoint
-- @param Node#Node nodenode

---
-- Function SetRadius
--
-- @function [parent=#OffMeshConnection] SetRadius
-- @param #number radiusradius

---
-- Function SetBidirectional
--
-- @function [parent=#OffMeshConnection] SetBidirectional
-- @param #boolean enabledenabled

---
-- Function GetEndPoint
--
-- @function [parent=#OffMeshConnection] GetEndPoint
-- @return Node#Node

---
-- Function GetRadius
--
-- @function [parent=#OffMeshConnection] GetRadius
-- @return #number

---
-- Function IsBidirectional
--
-- @function [parent=#OffMeshConnection] IsBidirectional
-- @return #boolean

---
-- Field endPoint
--
-- @field [parent=#OffMeshConnection] Node#Node endPoint

---
-- Field radius
--
-- @field [parent=#OffMeshConnection] #number radius

---
-- Field bidirectional
--
-- @field [parent=#OffMeshConnection] #boolean bidirectional

---
-- Function SetEnabled
--
-- @function [parent=#OffMeshConnection] SetEnabled
-- @param #boolean enableenable

---
-- Function Remove
--
-- @function [parent=#OffMeshConnection] Remove

---
-- Function GetID
--
-- @function [parent=#OffMeshConnection] GetID
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#OffMeshConnection] GetNode
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#OffMeshConnection] GetScene
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#OffMeshConnection] IsEnabled
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#OffMeshConnection] IsEnabledEffective
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#OffMeshConnection] GetComponent
-- @param ShortStringHash#ShortStringHash typetype
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#OffMeshConnection] GetComponent
-- @param #string typetype
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#OffMeshConnection] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#OffMeshConnection] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#OffMeshConnection] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#OffMeshConnection] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#OffMeshConnection] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#OffMeshConnection] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#OffMeshConnection] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#OffMeshConnection] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#OffMeshConnection] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#OffMeshConnection] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#OffMeshConnection] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#OffMeshConnection] #string category


return nil
