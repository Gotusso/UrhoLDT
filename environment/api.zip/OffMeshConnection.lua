---
-- Module OffMeshConnection
-- Extends Component
--
-- @module OffMeshConnection

---
-- Function SetEndPoint
--
-- @function [parent=#OffMeshConnection] SetEndPoint
-- @param Node#Node nodenode

---
-- Function SetRadius
--
-- @function [parent=#OffMeshConnection] SetRadius
-- @param #number radiusradius

---
-- Function SetBidirectional
--
-- @function [parent=#OffMeshConnection] SetBidirectional
-- @param #boolean enabledenabled

---
-- Function GetEndPoint
--
-- @function [parent=#OffMeshConnection] GetEndPoint
-- @return Node#Node

---
-- Function GetRadius
--
-- @function [parent=#OffMeshConnection] GetRadius
-- @return #number

---
-- Function IsBidirectional
--
-- @function [parent=#OffMeshConnection] IsBidirectional
-- @return #boolean

---
-- Field endPoint
--
-- @field [parent=#OffMeshConnection] Node#Node endPoint

---
-- Field radius
--
-- @field [parent=#OffMeshConnection] #number radius

---
-- Field bidirectional
--
-- @field [parent=#OffMeshConnection] #boolean bidirectional


return nil
