---
-- Module Variant
-- Generated on 2014-05-31
--
-- @module Variant

---
-- Function Variant()
-- Construct empty.
--
-- @function [parent=#Variant] Variant
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#Variant] new
-- @param self Self reference
-- @return Variant#Variant

---
-- Function Variant()
--
-- @function [parent=#Variant] Variant
-- @param self Self reference
-- @param #number value value

---
-- Function new()
--
-- @function [parent=#Variant] new
-- @param self Self reference
-- @param #number value value
-- @return Variant#Variant

---
-- Function Variant()
--
-- @function [parent=#Variant] Variant
-- @param self Self reference
-- @param #number value value

---
-- Function new()
--
-- @function [parent=#Variant] new
-- @param self Self reference
-- @param #number value value
-- @return Variant#Variant

---
-- Function Variant()
--
-- @function [parent=#Variant] Variant
-- @param self Self reference
-- @param StringHash#StringHash value value

---
-- Function new()
--
-- @function [parent=#Variant] new
-- @param self Self reference
-- @param StringHash#StringHash value value
-- @return Variant#Variant

---
-- Function Variant()
--
-- @function [parent=#Variant] Variant
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash value value

---
-- Function new()
--
-- @function [parent=#Variant] new
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash value value
-- @return Variant#Variant

---
-- Function Variant()
--
-- @function [parent=#Variant] Variant
-- @param self Self reference
-- @param #boolean value value

---
-- Function new()
--
-- @function [parent=#Variant] new
-- @param self Self reference
-- @param #boolean value value
-- @return Variant#Variant

---
-- Function Variant()
--
-- @function [parent=#Variant] Variant
-- @param self Self reference
-- @param #number value value

---
-- Function new()
--
-- @function [parent=#Variant] new
-- @param self Self reference
-- @param #number value value
-- @return Variant#Variant

---
-- Function Variant()
--
-- @function [parent=#Variant] Variant
-- @param self Self reference
-- @param Vector2#Vector2 value value

---
-- Function new()
--
-- @function [parent=#Variant] new
-- @param self Self reference
-- @param Vector2#Vector2 value value
-- @return Variant#Variant

---
-- Function Variant()
--
-- @function [parent=#Variant] Variant
-- @param self Self reference
-- @param Vector3#Vector3 value value

---
-- Function new()
--
-- @function [parent=#Variant] new
-- @param self Self reference
-- @param Vector3#Vector3 value value
-- @return Variant#Variant

---
-- Function Variant()
--
-- @function [parent=#Variant] Variant
-- @param self Self reference
-- @param Vector4#Vector4 value value

---
-- Function new()
--
-- @function [parent=#Variant] new
-- @param self Self reference
-- @param Vector4#Vector4 value value
-- @return Variant#Variant

---
-- Function Variant()
--
-- @function [parent=#Variant] Variant
-- @param self Self reference
-- @param Quaternion#Quaternion value value

---
-- Function new()
--
-- @function [parent=#Variant] new
-- @param self Self reference
-- @param Quaternion#Quaternion value value
-- @return Variant#Variant

---
-- Function Variant()
--
-- @function [parent=#Variant] Variant
-- @param self Self reference
-- @param Color#Color value value

---
-- Function new()
--
-- @function [parent=#Variant] new
-- @param self Self reference
-- @param Color#Color value value
-- @return Variant#Variant

---
-- Function Variant()
--
-- @function [parent=#Variant] Variant
-- @param self Self reference
-- @param #string value value

---
-- Function new()
--
-- @function [parent=#Variant] new
-- @param self Self reference
-- @param #string value value
-- @return Variant#Variant

---
-- Function Variant()
--
-- @function [parent=#Variant] Variant
-- @param self Self reference
-- @param char*#char* value value

---
-- Function new()
--
-- @function [parent=#Variant] new
-- @param self Self reference
-- @param char*#char* value value
-- @return Variant#Variant

---
-- Function Variant()
--
-- @function [parent=#Variant] Variant
-- @param self Self reference
-- @param ResourceRef#ResourceRef value value

---
-- Function new()
--
-- @function [parent=#Variant] new
-- @param self Self reference
-- @param ResourceRef#ResourceRef value value
-- @return Variant#Variant

---
-- Function Variant()
--
-- @function [parent=#Variant] Variant
-- @param self Self reference
-- @param ResourceRefList#ResourceRefList value value

---
-- Function new()
--
-- @function [parent=#Variant] new
-- @param self Self reference
-- @param ResourceRefList#ResourceRefList value value
-- @return Variant#Variant

---
-- Function Variant()
--
-- @function [parent=#Variant] Variant
-- @param self Self reference
-- @param IntRect#IntRect value value

---
-- Function new()
--
-- @function [parent=#Variant] new
-- @param self Self reference
-- @param IntRect#IntRect value value
-- @return Variant#Variant

---
-- Function Variant()
--
-- @function [parent=#Variant] Variant
-- @param self Self reference
-- @param IntVector2#IntVector2 value value

---
-- Function new()
--
-- @function [parent=#Variant] new
-- @param self Self reference
-- @param IntVector2#IntVector2 value value
-- @return Variant#Variant

---
-- Function Variant()
--
-- @function [parent=#Variant] Variant
-- @param self Self reference
-- @param Matrix3#Matrix3 value value

---
-- Function new()
--
-- @function [parent=#Variant] new
-- @param self Self reference
-- @param Matrix3#Matrix3 value value
-- @return Variant#Variant

---
-- Function Variant()
--
-- @function [parent=#Variant] Variant
-- @param self Self reference
-- @param Matrix3x4#Matrix3x4 value value

---
-- Function new()
--
-- @function [parent=#Variant] new
-- @param self Self reference
-- @param Matrix3x4#Matrix3x4 value value
-- @return Variant#Variant

---
-- Function Variant()
--
-- @function [parent=#Variant] Variant
-- @param self Self reference
-- @param Matrix4#Matrix4 value value

---
-- Function new()
--
-- @function [parent=#Variant] new
-- @param self Self reference
-- @param Matrix4#Matrix4 value value
-- @return Variant#Variant

---
-- Function Variant()
--
-- @function [parent=#Variant] Variant
-- @param self Self reference
-- @param #string type type
-- @param #string value value

---
-- Function new()
--
-- @function [parent=#Variant] new
-- @param self Self reference
-- @param #string type type
-- @param #string value value
-- @return Variant#Variant

---
-- Function Variant()
--
-- @function [parent=#Variant] Variant
-- @param self Self reference
-- @param VariantType#VariantType type type
-- @param #string value value

---
-- Function new()
--
-- @function [parent=#Variant] new
-- @param self Self reference
-- @param VariantType#VariantType type type
-- @param #string value value
-- @return Variant#Variant

---
-- Function Variant()
--
-- @function [parent=#Variant] Variant
-- @param self Self reference
-- @param VariantType#VariantType type type
-- @param char*#char* value value

---
-- Function new()
--
-- @function [parent=#Variant] new
-- @param self Self reference
-- @param VariantType#VariantType type type
-- @param char*#char* value value
-- @return Variant#Variant

---
-- Function Variant()
--
-- @function [parent=#Variant] Variant
-- @param self Self reference
-- @param Variant#Variant value value

---
-- Function new()
--
-- @function [parent=#Variant] new
-- @param self Self reference
-- @param Variant#Variant value value
-- @return Variant#Variant

---
-- Function delete()
--
-- @function [parent=#Variant] delete
-- @param self Self reference

---
-- Function Clear()
--
-- @function [parent=#Variant] Clear
-- @param self Self reference

---
-- Function operator==()
--
-- @function [parent=#Variant] operator==
-- @param self Self reference
-- @param Variant#Variant rhs rhs
-- @return #boolean

---
-- Function operator==()
--
-- @function [parent=#Variant] operator==
-- @param self Self reference
-- @param #number rhs rhs
-- @return #boolean

---
-- Function operator==()
--
-- @function [parent=#Variant] operator==
-- @param self Self reference
-- @param #number rhs rhs
-- @return #boolean

---
-- Function operator==()
--
-- @function [parent=#Variant] operator==
-- @param self Self reference
-- @param #boolean rhs rhs
-- @return #boolean

---
-- Function operator==()
--
-- @function [parent=#Variant] operator==
-- @param self Self reference
-- @param #number rhs rhs
-- @return #boolean

---
-- Function operator==()
--
-- @function [parent=#Variant] operator==
-- @param self Self reference
-- @param Vector2#Vector2 rhs rhs
-- @return #boolean

---
-- Function operator==()
--
-- @function [parent=#Variant] operator==
-- @param self Self reference
-- @param Vector3#Vector3 rhs rhs
-- @return #boolean

---
-- Function operator==()
--
-- @function [parent=#Variant] operator==
-- @param self Self reference
-- @param Vector4#Vector4 rhs rhs
-- @return #boolean

---
-- Function operator==()
--
-- @function [parent=#Variant] operator==
-- @param self Self reference
-- @param Quaternion#Quaternion rhs rhs
-- @return #boolean

---
-- Function operator==()
--
-- @function [parent=#Variant] operator==
-- @param self Self reference
-- @param Color#Color rhs rhs
-- @return #boolean

---
-- Function operator==()
--
-- @function [parent=#Variant] operator==
-- @param self Self reference
-- @param #string rhs rhs
-- @return #boolean

---
-- Function operator==()
--
-- @function [parent=#Variant] operator==
-- @param self Self reference
-- @param ResourceRef#ResourceRef rhs rhs
-- @return #boolean

---
-- Function operator==()
--
-- @function [parent=#Variant] operator==
-- @param self Self reference
-- @param ResourceRefList#ResourceRefList rhs rhs
-- @return #boolean

---
-- Function operator==()
--
-- @function [parent=#Variant] operator==
-- @param self Self reference
-- @param IntRect#IntRect rhs rhs
-- @return #boolean

---
-- Function operator==()
--
-- @function [parent=#Variant] operator==
-- @param self Self reference
-- @param IntVector2#IntVector2 rhs rhs
-- @return #boolean

---
-- Function operator==()
--
-- @function [parent=#Variant] operator==
-- @param self Self reference
-- @param StringHash#StringHash rhs rhs
-- @return #boolean

---
-- Function operator==()
--
-- @function [parent=#Variant] operator==
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash rhs rhs
-- @return #boolean

---
-- Function operator==()
--
-- @function [parent=#Variant] operator==
-- @param self Self reference
-- @param Matrix3#Matrix3 rhs rhs
-- @return #boolean

---
-- Function operator==()
--
-- @function [parent=#Variant] operator==
-- @param self Self reference
-- @param Matrix3x4#Matrix3x4 rhs rhs
-- @return #boolean

---
-- Function operator==()
--
-- @function [parent=#Variant] operator==
-- @param self Self reference
-- @param Matrix4#Matrix4 rhs rhs
-- @return #boolean

---
-- Function SetInt()
--
-- @function [parent=#Variant] SetInt
-- @param self Self reference
-- @param #number value value

---
-- Function SetUint()
--
-- @function [parent=#Variant] SetUint
-- @param self Self reference
-- @param #number value value

---
-- Function SetStringHash()
--
-- @function [parent=#Variant] SetStringHash
-- @param self Self reference
-- @param StringHash#StringHash value value

---
-- Function SetShortStringHash()
--
-- @function [parent=#Variant] SetShortStringHash
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash value value

---
-- Function SetBool()
--
-- @function [parent=#Variant] SetBool
-- @param self Self reference
-- @param #boolean value value

---
-- Function SetFloat()
--
-- @function [parent=#Variant] SetFloat
-- @param self Self reference
-- @param #number value value

---
-- Function SetVector2()
--
-- @function [parent=#Variant] SetVector2
-- @param self Self reference
-- @param Vector2#Vector2 value value

---
-- Function SetVector3()
--
-- @function [parent=#Variant] SetVector3
-- @param self Self reference
-- @param Vector3#Vector3 value value

---
-- Function SetVector4()
--
-- @function [parent=#Variant] SetVector4
-- @param self Self reference
-- @param Vector4#Vector4 value value

---
-- Function SetQuaternion()
--
-- @function [parent=#Variant] SetQuaternion
-- @param self Self reference
-- @param Quaternion#Quaternion value value

---
-- Function SetColor()
--
-- @function [parent=#Variant] SetColor
-- @param self Self reference
-- @param Color#Color value value

---
-- Function SetString()
--
-- @function [parent=#Variant] SetString
-- @param self Self reference
-- @param #string value value

---
-- Function SetBuffer()
--
-- @function [parent=#Variant] SetBuffer
-- @param self Self reference
-- @param VectorBuffer#VectorBuffer value value

---
-- Function SetResourceRef()
--
-- @function [parent=#Variant] SetResourceRef
-- @param self Self reference
-- @param ResourceRef#ResourceRef value value

---
-- Function SetResourceRefList()
--
-- @function [parent=#Variant] SetResourceRefList
-- @param self Self reference
-- @param ResourceRefList#ResourceRefList value value

---
-- Function SetIntRect()
--
-- @function [parent=#Variant] SetIntRect
-- @param self Self reference
-- @param IntRect#IntRect value value

---
-- Function SetIntVector2()
--
-- @function [parent=#Variant] SetIntVector2
-- @param self Self reference
-- @param IntVector2#IntVector2 value value

---
-- Function SetMatrix3()
--
-- @function [parent=#Variant] SetMatrix3
-- @param self Self reference
-- @param Matrix3#Matrix3 value value

---
-- Function SetMatrix3x4()
--
-- @function [parent=#Variant] SetMatrix3x4
-- @param self Self reference
-- @param Matrix3x4#Matrix3x4 value value

---
-- Function SetMatrix4()
--
-- @function [parent=#Variant] SetMatrix4
-- @param self Self reference
-- @param Matrix4#Matrix4 value value

---
-- Function GetInt()
--
-- @function [parent=#Variant] GetInt
-- @param self Self reference
-- @return #number

---
-- Function GetUInt()
--
-- @function [parent=#Variant] GetUInt
-- @param self Self reference
-- @return #number

---
-- Function GetStringHash()
--
-- @function [parent=#Variant] GetStringHash
-- @param self Self reference
-- @return StringHash#StringHash

---
-- Function GetShortStringHash()
--
-- @function [parent=#Variant] GetShortStringHash
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBool()
--
-- @function [parent=#Variant] GetBool
-- @param self Self reference
-- @return #boolean

---
-- Function GetFloat()
--
-- @function [parent=#Variant] GetFloat
-- @param self Self reference
-- @return #number

---
-- Function GetVector2()
--
-- @function [parent=#Variant] GetVector2
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Function GetVector3()
--
-- @function [parent=#Variant] GetVector3
-- @param self Self reference
-- @return const Vector3#const Vector3

---
-- Function GetVector4()
--
-- @function [parent=#Variant] GetVector4
-- @param self Self reference
-- @return const Vector4#const Vector4

---
-- Function GetQuaternion()
--
-- @function [parent=#Variant] GetQuaternion
-- @param self Self reference
-- @return const Quaternion#const Quaternion

---
-- Function GetColor()
--
-- @function [parent=#Variant] GetColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetString()
--
-- @function [parent=#Variant] GetString
-- @param self Self reference
-- @return const String#const String

---
-- Function GetBuffer()
--
-- @function [parent=#Variant] GetBuffer
-- @param self Self reference
-- @return VectorBuffer#VectorBuffer

---
-- Function GetResourceRef()
--
-- @function [parent=#Variant] GetResourceRef
-- @param self Self reference
-- @return const ResourceRef#const ResourceRef

---
-- Function GetResourceRefList()
--
-- @function [parent=#Variant] GetResourceRefList
-- @param self Self reference
-- @return const ResourceRefList#const ResourceRefList

---
-- Function GetIntRect()
--
-- @function [parent=#Variant] GetIntRect
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetIntVector2()
--
-- @function [parent=#Variant] GetIntVector2
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetMatrix3()
--
-- @function [parent=#Variant] GetMatrix3
-- @param self Self reference
-- @return const Matrix3#const Matrix3

---
-- Function GetMatrix3x4()
--
-- @function [parent=#Variant] GetMatrix3x4
-- @param self Self reference
-- @return const Matrix3x4#const Matrix3x4

---
-- Function GetMatrix4()
--
-- @function [parent=#Variant] GetMatrix4
-- @param self Self reference
-- @return const Matrix4#const Matrix4

---
-- Function GetType()
--
-- @function [parent=#Variant] GetType
-- @param self Self reference
-- @return VariantType#VariantType

---
-- Function GetTypeName()
--
-- @function [parent=#Variant] GetTypeName
-- @param self Self reference
-- @return #string

---
-- Function ToString()
--
-- @function [parent=#Variant] ToString
-- @param self Self reference
-- @return #string

---
-- Function IsZero()
--
-- @function [parent=#Variant] IsZero
-- @param self Self reference
-- @return #boolean

---
-- Function IsEmpty()
--
-- @function [parent=#Variant] IsEmpty
-- @param self Self reference
-- @return #boolean

---
-- Field type (Read only)
--
-- @field [parent=#Variant] VariantType#VariantType type

---
-- Field typeName (Read only)
--
-- @field [parent=#Variant] #string typeName

---
-- Field zero (Read only)
--
-- @field [parent=#Variant] #boolean zero

---
-- Field empty (Read only)
--
-- @field [parent=#Variant] #boolean empty


return nil
