---
-- Module Variant
--
-- @module Variant

---
-- Function Variant
--
-- @function [parent=#Variant] Variant

---
-- Function new
--
-- @function [parent=#Variant] new
-- @return Variant#Variant

---
-- Function Variant
--
-- @function [parent=#Variant] Variant
-- @param #number valuevalue

---
-- Function new
--
-- @function [parent=#Variant] new
-- @param #number valuevalue
-- @return Variant#Variant

---
-- Function Variant
--
-- @function [parent=#Variant] Variant
-- @param #number valuevalue

---
-- Function new
--
-- @function [parent=#Variant] new
-- @param #number valuevalue
-- @return Variant#Variant

---
-- Function Variant
--
-- @function [parent=#Variant] Variant
-- @param StringHash#StringHash valuevalue

---
-- Function new
--
-- @function [parent=#Variant] new
-- @param StringHash#StringHash valuevalue
-- @return Variant#Variant

---
-- Function Variant
--
-- @function [parent=#Variant] Variant
-- @param ShortStringHash#ShortStringHash valuevalue

---
-- Function new
--
-- @function [parent=#Variant] new
-- @param ShortStringHash#ShortStringHash valuevalue
-- @return Variant#Variant

---
-- Function Variant
--
-- @function [parent=#Variant] Variant
-- @param #boolean valuevalue

---
-- Function new
--
-- @function [parent=#Variant] new
-- @param #boolean valuevalue
-- @return Variant#Variant

---
-- Function Variant
--
-- @function [parent=#Variant] Variant
-- @param #number valuevalue

---
-- Function new
--
-- @function [parent=#Variant] new
-- @param #number valuevalue
-- @return Variant#Variant

---
-- Function Variant
--
-- @function [parent=#Variant] Variant
-- @param Vector2#Vector2 valuevalue

---
-- Function new
--
-- @function [parent=#Variant] new
-- @param Vector2#Vector2 valuevalue
-- @return Variant#Variant

---
-- Function Variant
--
-- @function [parent=#Variant] Variant
-- @param Vector3#Vector3 valuevalue

---
-- Function new
--
-- @function [parent=#Variant] new
-- @param Vector3#Vector3 valuevalue
-- @return Variant#Variant

---
-- Function Variant
--
-- @function [parent=#Variant] Variant
-- @param Vector4#Vector4 valuevalue

---
-- Function new
--
-- @function [parent=#Variant] new
-- @param Vector4#Vector4 valuevalue
-- @return Variant#Variant

---
-- Function Variant
--
-- @function [parent=#Variant] Variant
-- @param Quaternion#Quaternion valuevalue

---
-- Function new
--
-- @function [parent=#Variant] new
-- @param Quaternion#Quaternion valuevalue
-- @return Variant#Variant

---
-- Function Variant
--
-- @function [parent=#Variant] Variant
-- @param Color#Color valuevalue

---
-- Function new
--
-- @function [parent=#Variant] new
-- @param Color#Color valuevalue
-- @return Variant#Variant

---
-- Function Variant
--
-- @function [parent=#Variant] Variant
-- @param #string valuevalue

---
-- Function new
--
-- @function [parent=#Variant] new
-- @param #string valuevalue
-- @return Variant#Variant

---
-- Function Variant
--
-- @function [parent=#Variant] Variant
-- @param char*#char* valuevalue

---
-- Function new
--
-- @function [parent=#Variant] new
-- @param char*#char* valuevalue
-- @return Variant#Variant

---
-- Function Variant
--
-- @function [parent=#Variant] Variant
-- @param ResourceRef#ResourceRef valuevalue

---
-- Function new
--
-- @function [parent=#Variant] new
-- @param ResourceRef#ResourceRef valuevalue
-- @return Variant#Variant

---
-- Function Variant
--
-- @function [parent=#Variant] Variant
-- @param ResourceRefList#ResourceRefList valuevalue

---
-- Function new
--
-- @function [parent=#Variant] new
-- @param ResourceRefList#ResourceRefList valuevalue
-- @return Variant#Variant

---
-- Function Variant
--
-- @function [parent=#Variant] Variant
-- @param IntRect#IntRect valuevalue

---
-- Function new
--
-- @function [parent=#Variant] new
-- @param IntRect#IntRect valuevalue
-- @return Variant#Variant

---
-- Function Variant
--
-- @function [parent=#Variant] Variant
-- @param IntVector2#IntVector2 valuevalue

---
-- Function new
--
-- @function [parent=#Variant] new
-- @param IntVector2#IntVector2 valuevalue
-- @return Variant#Variant

---
-- Function Variant
--
-- @function [parent=#Variant] Variant
-- @param #string typetype
-- @param #string valuevalue

---
-- Function new
--
-- @function [parent=#Variant] new
-- @param #string typetype
-- @param #string valuevalue
-- @return Variant#Variant

---
-- Function Variant
--
-- @function [parent=#Variant] Variant
-- @param VariantType#VariantType typetype
-- @param #string valuevalue

---
-- Function new
--
-- @function [parent=#Variant] new
-- @param VariantType#VariantType typetype
-- @param #string valuevalue
-- @return Variant#Variant

---
-- Function Variant
--
-- @function [parent=#Variant] Variant
-- @param VariantType#VariantType typetype
-- @param char*#char* valuevalue

---
-- Function new
--
-- @function [parent=#Variant] new
-- @param VariantType#VariantType typetype
-- @param char*#char* valuevalue
-- @return Variant#Variant

---
-- Function Variant
--
-- @function [parent=#Variant] Variant
-- @param Variant#Variant valuevalue

---
-- Function new
--
-- @function [parent=#Variant] new
-- @param Variant#Variant valuevalue
-- @return Variant#Variant

---
-- Function delete
--
-- @function [parent=#Variant] delete

---
-- Function Clear
--
-- @function [parent=#Variant] Clear

---
-- Function operator==
--
-- @function [parent=#Variant] operator==
-- @param Variant#Variant rhsrhs
-- @return #boolean

---
-- Function operator==
--
-- @function [parent=#Variant] operator==
-- @param #number rhsrhs
-- @return #boolean

---
-- Function operator==
--
-- @function [parent=#Variant] operator==
-- @param #number rhsrhs
-- @return #boolean

---
-- Function operator==
--
-- @function [parent=#Variant] operator==
-- @param #boolean rhsrhs
-- @return #boolean

---
-- Function operator==
--
-- @function [parent=#Variant] operator==
-- @param #number rhsrhs
-- @return #boolean

---
-- Function operator==
--
-- @function [parent=#Variant] operator==
-- @param Vector2#Vector2 rhsrhs
-- @return #boolean

---
-- Function operator==
--
-- @function [parent=#Variant] operator==
-- @param Vector3#Vector3 rhsrhs
-- @return #boolean

---
-- Function operator==
--
-- @function [parent=#Variant] operator==
-- @param Vector4#Vector4 rhsrhs
-- @return #boolean

---
-- Function operator==
--
-- @function [parent=#Variant] operator==
-- @param Quaternion#Quaternion rhsrhs
-- @return #boolean

---
-- Function operator==
--
-- @function [parent=#Variant] operator==
-- @param Color#Color rhsrhs
-- @return #boolean

---
-- Function operator==
--
-- @function [parent=#Variant] operator==
-- @param #string rhsrhs
-- @return #boolean

---
-- Function operator==
--
-- @function [parent=#Variant] operator==
-- @param ResourceRef#ResourceRef rhsrhs
-- @return #boolean

---
-- Function operator==
--
-- @function [parent=#Variant] operator==
-- @param ResourceRefList#ResourceRefList rhsrhs
-- @return #boolean

---
-- Function operator==
--
-- @function [parent=#Variant] operator==
-- @param IntRect#IntRect rhsrhs
-- @return #boolean

---
-- Function operator==
--
-- @function [parent=#Variant] operator==
-- @param IntVector2#IntVector2 rhsrhs
-- @return #boolean

---
-- Function operator==
--
-- @function [parent=#Variant] operator==
-- @param StringHash#StringHash rhsrhs
-- @return #boolean

---
-- Function operator==
--
-- @function [parent=#Variant] operator==
-- @param ShortStringHash#ShortStringHash rhsrhs
-- @return #boolean

---
-- Function SetInt
--
-- @function [parent=#Variant] SetInt
-- @param #number valuevalue

---
-- Function SetUint
--
-- @function [parent=#Variant] SetUint
-- @param #number valuevalue

---
-- Function SetStringHash
--
-- @function [parent=#Variant] SetStringHash
-- @param StringHash#StringHash valuevalue

---
-- Function SetShortStringHash
--
-- @function [parent=#Variant] SetShortStringHash
-- @param ShortStringHash#ShortStringHash valuevalue

---
-- Function SetBool
--
-- @function [parent=#Variant] SetBool
-- @param #boolean valuevalue

---
-- Function SetFloat
--
-- @function [parent=#Variant] SetFloat
-- @param #number valuevalue

---
-- Function SetVector2
--
-- @function [parent=#Variant] SetVector2
-- @param Vector2#Vector2 valuevalue

---
-- Function SetVector3
--
-- @function [parent=#Variant] SetVector3
-- @param Vector3#Vector3 valuevalue

---
-- Function SetVector4
--
-- @function [parent=#Variant] SetVector4
-- @param Vector4#Vector4 valuevalue

---
-- Function SetQuaternion
--
-- @function [parent=#Variant] SetQuaternion
-- @param Quaternion#Quaternion valuevalue

---
-- Function SetColor
--
-- @function [parent=#Variant] SetColor
-- @param Color#Color valuevalue

---
-- Function SetString
--
-- @function [parent=#Variant] SetString
-- @param #string valuevalue

---
-- Function SetBuffer
--
-- @function [parent=#Variant] SetBuffer
-- @param VectorBuffer#VectorBuffer valuevalue

---
-- Function SetResourceRef
--
-- @function [parent=#Variant] SetResourceRef
-- @param ResourceRef#ResourceRef valuevalue

---
-- Function SetResourceRefList
--
-- @function [parent=#Variant] SetResourceRefList
-- @param ResourceRefList#ResourceRefList valuevalue

---
-- Function SetIntRect
--
-- @function [parent=#Variant] SetIntRect
-- @param IntRect#IntRect valuevalue

---
-- Function SetIntVector2
--
-- @function [parent=#Variant] SetIntVector2
-- @param IntVector2#IntVector2 valuevalue

---
-- Function GetInt
--
-- @function [parent=#Variant] GetInt
-- @return #number

---
-- Function GetUInt
--
-- @function [parent=#Variant] GetUInt
-- @return #number

---
-- Function GetStringHash
--
-- @function [parent=#Variant] GetStringHash
-- @return StringHash#StringHash

---
-- Function GetShortStringHash
--
-- @function [parent=#Variant] GetShortStringHash
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBool
--
-- @function [parent=#Variant] GetBool
-- @return #boolean

---
-- Function GetFloat
--
-- @function [parent=#Variant] GetFloat
-- @return #number

---
-- Function GetVector2
--
-- @function [parent=#Variant] GetVector2
-- @return const Vector2#const Vector2

---
-- Function GetVector3
--
-- @function [parent=#Variant] GetVector3
-- @return const Vector3#const Vector3

---
-- Function GetVector4
--
-- @function [parent=#Variant] GetVector4
-- @return const Vector4#const Vector4

---
-- Function GetQuaternion
--
-- @function [parent=#Variant] GetQuaternion
-- @return const Quaternion#const Quaternion

---
-- Function GetColor
--
-- @function [parent=#Variant] GetColor
-- @return const Color#const Color

---
-- Function GetString
--
-- @function [parent=#Variant] GetString
-- @return const String#const String

---
-- Function GetBuffer
--
-- @function [parent=#Variant] GetBuffer
-- @return VectorBuffer#VectorBuffer

---
-- Function GetResourceRef
--
-- @function [parent=#Variant] GetResourceRef
-- @return const ResourceRef#const ResourceRef

---
-- Function GetResourceRefList
--
-- @function [parent=#Variant] GetResourceRefList
-- @return const ResourceRefList#const ResourceRefList

---
-- Function GetIntRect
--
-- @function [parent=#Variant] GetIntRect
-- @return const IntRect#const IntRect

---
-- Function GetIntVector2
--
-- @function [parent=#Variant] GetIntVector2
-- @return const IntVector2#const IntVector2

---
-- Function GetType
--
-- @function [parent=#Variant] GetType
-- @return VariantType#VariantType

---
-- Function GetTypeName
--
-- @function [parent=#Variant] GetTypeName
-- @return #string

---
-- Function ToString
--
-- @function [parent=#Variant] ToString
-- @return #string

---
-- Function IsZero
--
-- @function [parent=#Variant] IsZero
-- @return #boolean

---
-- Function IsEmpty
--
-- @function [parent=#Variant] IsEmpty
-- @return #boolean

---
-- Field type (Read only)
--
-- @field [parent=#Variant] VariantType#VariantType type

---
-- Field typeName (Read only)
--
-- @field [parent=#Variant] #string typeName

---
-- Field zero (Read only)
--
-- @field [parent=#Variant] #boolean zero

---
-- Field empty (Read only)
--
-- @field [parent=#Variant] #boolean empty


return nil
