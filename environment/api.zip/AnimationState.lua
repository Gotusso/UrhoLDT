---
-- Module AnimationState
--
-- @module AnimationState

---
-- Function AnimationState
--
-- @function [parent=#AnimationState] AnimationState
-- @param AnimatedModel#AnimatedModel modelmodel
-- @param Animation#Animation animationanimation

---
-- Function new
--
-- @function [parent=#AnimationState] new
-- @param AnimatedModel#AnimatedModel modelmodel
-- @param Animation#Animation animationanimation
-- @return AnimationState#AnimationState

---
-- Function AnimationState
--
-- @function [parent=#AnimationState] AnimationState
-- @param Node#Node nodenode
-- @param Animation#Animation animationanimation

---
-- Function new
--
-- @function [parent=#AnimationState] new
-- @param Node#Node nodenode
-- @param Animation#Animation animationanimation
-- @return AnimationState#AnimationState

---
-- Function delete
--
-- @function [parent=#AnimationState] delete

---
-- Function SetStartBone
--
-- @function [parent=#AnimationState] SetStartBone
-- @param Bone#Bone bonebone

---
-- Function SetLooped
--
-- @function [parent=#AnimationState] SetLooped
-- @param #boolean loopedlooped

---
-- Function SetWeight
--
-- @function [parent=#AnimationState] SetWeight
-- @param #number weightweight

---
-- Function SetTime
--
-- @function [parent=#AnimationState] SetTime
-- @param #number timetime

---
-- Function SetBoneWeight
--
-- @function [parent=#AnimationState] SetBoneWeight
-- @param #string namename
-- @param #number weightweight
-- @param #boolean recursiverecursive

---
-- Function SetBoneWeight
--
-- @function [parent=#AnimationState] SetBoneWeight
-- @param StringHash#StringHash nameHashnameHash
-- @param #number weightweight
-- @param #boolean recursiverecursive

---
-- Function SetBoneWeight
--
-- @function [parent=#AnimationState] SetBoneWeight
-- @param #number indexindex
-- @param #number weightweight
-- @param #boolean recursiverecursive

---
-- Function AddWeight
--
-- @function [parent=#AnimationState] AddWeight
-- @param #number deltadelta

---
-- Function AddTime
--
-- @function [parent=#AnimationState] AddTime
-- @param #number deltadelta

---
-- Function SetLayer
--
-- @function [parent=#AnimationState] SetLayer
-- @param #string layerlayer

---
-- Function GetAnimation
--
-- @function [parent=#AnimationState] GetAnimation
-- @return Animation#Animation

---
-- Function GetStartBone
--
-- @function [parent=#AnimationState] GetStartBone
-- @return Bone#Bone

---
-- Function GetBoneWeight
--
-- @function [parent=#AnimationState] GetBoneWeight
-- @param #string namename
-- @return #number

---
-- Function GetBoneWeight
--
-- @function [parent=#AnimationState] GetBoneWeight
-- @param StringHash#StringHash nameHashnameHash
-- @return #number

---
-- Function GetBoneWeight
--
-- @function [parent=#AnimationState] GetBoneWeight
-- @param #number indexindex
-- @return #number

---
-- Function GetTrackIndex
--
-- @function [parent=#AnimationState] GetTrackIndex
-- @param #string namename
-- @return #number

---
-- Function GetTrackIndex
--
-- @function [parent=#AnimationState] GetTrackIndex
-- @param StringHash#StringHash nameHashnameHash
-- @return #number

---
-- Function IsEnabled
--
-- @function [parent=#AnimationState] IsEnabled
-- @return #boolean

---
-- Function IsLooped
--
-- @function [parent=#AnimationState] IsLooped
-- @return #boolean

---
-- Function GetWeight
--
-- @function [parent=#AnimationState] GetWeight
-- @return #number

---
-- Function GetTime
--
-- @function [parent=#AnimationState] GetTime
-- @return #number

---
-- Function GetLength
--
-- @function [parent=#AnimationState] GetLength
-- @return #number

---
-- Function GetLayer
--
-- @function [parent=#AnimationState] GetLayer
-- @return #string

---
-- Field animation (Read only)
--
-- @field [parent=#AnimationState] Animation#Animation animation

---
-- Field startBone
--
-- @field [parent=#AnimationState] Bone#Bone startBone

---
-- Field enabled (Read only)
--
-- @field [parent=#AnimationState] #boolean enabled

---
-- Field looped
--
-- @field [parent=#AnimationState] #boolean looped

---
-- Field weight
--
-- @field [parent=#AnimationState] #number weight

---
-- Field time
--
-- @field [parent=#AnimationState] #number time

---
-- Field length (Read only)
--
-- @field [parent=#AnimationState] #number length

---
-- Field layer
--
-- @field [parent=#AnimationState] #string layer


return nil
