---
-- Module AnimationState
-- Generated on 2014-03-13
--
-- @module AnimationState

---
-- Function AnimationState
--
-- @function [parent=#AnimationState] AnimationState
-- @param self Self reference
-- @param AnimatedModel#AnimatedModel model model
-- @param Animation#Animation animation animation

---
-- Function new
--
-- @function [parent=#AnimationState] new
-- @param self Self reference
-- @param AnimatedModel#AnimatedModel model model
-- @param Animation#Animation animation animation
-- @return AnimationState#AnimationState

---
-- Function AnimationState
--
-- @function [parent=#AnimationState] AnimationState
-- @param self Self reference
-- @param Node#Node node node
-- @param Animation#Animation animation animation

---
-- Function new
--
-- @function [parent=#AnimationState] new
-- @param self Self reference
-- @param Node#Node node node
-- @param Animation#Animation animation animation
-- @return AnimationState#AnimationState

---
-- Function delete
--
-- @function [parent=#AnimationState] delete
-- @param self Self reference

---
-- Function SetStartBone
--
-- @function [parent=#AnimationState] SetStartBone
-- @param self Self reference
-- @param Bone#Bone bone bone

---
-- Function SetLooped
--
-- @function [parent=#AnimationState] SetLooped
-- @param self Self reference
-- @param #boolean looped looped

---
-- Function SetWeight
--
-- @function [parent=#AnimationState] SetWeight
-- @param self Self reference
-- @param #number weight weight

---
-- Function SetTime
--
-- @function [parent=#AnimationState] SetTime
-- @param self Self reference
-- @param #number time time

---
-- Function SetBoneWeight
--
-- @function [parent=#AnimationState] SetBoneWeight
-- @param self Self reference
-- @param #string name name
-- @param #number weight weight
-- @param #boolean recursive recursive

---
-- Function SetBoneWeight
--
-- @function [parent=#AnimationState] SetBoneWeight
-- @param self Self reference
-- @param StringHash#StringHash nameHash nameHash
-- @param #number weight weight
-- @param #boolean recursive recursive

---
-- Function SetBoneWeight
--
-- @function [parent=#AnimationState] SetBoneWeight
-- @param self Self reference
-- @param #number index index
-- @param #number weight weight
-- @param #boolean recursive recursive

---
-- Function AddWeight
--
-- @function [parent=#AnimationState] AddWeight
-- @param self Self reference
-- @param #number delta delta

---
-- Function AddTime
--
-- @function [parent=#AnimationState] AddTime
-- @param self Self reference
-- @param #number delta delta

---
-- Function SetLayer
--
-- @function [parent=#AnimationState] SetLayer
-- @param self Self reference
-- @param #string layer layer

---
-- Function GetAnimation
--
-- @function [parent=#AnimationState] GetAnimation
-- @param self Self reference
-- @return Animation#Animation

---
-- Function GetStartBone
--
-- @function [parent=#AnimationState] GetStartBone
-- @param self Self reference
-- @return Bone#Bone

---
-- Function GetBoneWeight
--
-- @function [parent=#AnimationState] GetBoneWeight
-- @param self Self reference
-- @param #string name name
-- @return #number

---
-- Function GetBoneWeight
--
-- @function [parent=#AnimationState] GetBoneWeight
-- @param self Self reference
-- @param StringHash#StringHash nameHash nameHash
-- @return #number

---
-- Function GetBoneWeight
--
-- @function [parent=#AnimationState] GetBoneWeight
-- @param self Self reference
-- @param #number index index
-- @return #number

---
-- Function GetTrackIndex
--
-- @function [parent=#AnimationState] GetTrackIndex
-- @param self Self reference
-- @param #string name name
-- @return #number

---
-- Function GetTrackIndex
--
-- @function [parent=#AnimationState] GetTrackIndex
-- @param self Self reference
-- @param StringHash#StringHash nameHash nameHash
-- @return #number

---
-- Function IsEnabled
--
-- @function [parent=#AnimationState] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsLooped
--
-- @function [parent=#AnimationState] IsLooped
-- @param self Self reference
-- @return #boolean

---
-- Function GetWeight
--
-- @function [parent=#AnimationState] GetWeight
-- @param self Self reference
-- @return #number

---
-- Function GetTime
--
-- @function [parent=#AnimationState] GetTime
-- @param self Self reference
-- @return #number

---
-- Function GetLength
--
-- @function [parent=#AnimationState] GetLength
-- @param self Self reference
-- @return #number

---
-- Function GetLayer
--
-- @function [parent=#AnimationState] GetLayer
-- @param self Self reference
-- @return #string

---
-- Field animation (Read only)
--
-- @field [parent=#AnimationState] Animation#Animation animation

---
-- Field startBone
--
-- @field [parent=#AnimationState] Bone#Bone startBone

---
-- Field enabled (Read only)
--
-- @field [parent=#AnimationState] #boolean enabled

---
-- Field looped
--
-- @field [parent=#AnimationState] #boolean looped

---
-- Field weight
--
-- @field [parent=#AnimationState] #number weight

---
-- Field time
--
-- @field [parent=#AnimationState] #number time

---
-- Field length (Read only)
--
-- @field [parent=#AnimationState] #number length

---
-- Field layer
--
-- @field [parent=#AnimationState] #string layer


return nil
