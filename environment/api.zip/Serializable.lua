---
-- Module Serializable
-- Module Serializable extends Object
-- Generated on 2014-05-31
--
-- @module Serializable

---
-- Function SetTemporary()
-- Set temporary flag. Temporary objects will not be saved.
--
-- @function [parent=#Serializable] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary()
-- Return whether is temporary.
--
-- @function [parent=#Serializable] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Serializable] #boolean temporary


return nil
