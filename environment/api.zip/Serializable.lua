---
-- Module Serializable
-- extends Object
--
-- @module Serializable

---
-- Function SetTemporary
--
-- @function [parent=#Serializable] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#Serializable] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Serializable] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Serializable] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Serializable] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Serializable] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Serializable] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Serializable] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#Serializable] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Serializable] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Serializable] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Serializable] #string category


return nil
