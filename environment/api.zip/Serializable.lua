---
-- Module Serializable
-- Extends Object
--
-- @module Serializable

---
-- Function SetTemporary
--
-- @function [parent=#Serializable] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#Serializable] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Serializable] #boolean temporary


return nil
