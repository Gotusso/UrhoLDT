---
-- Module Octree
-- Extends Component
--
-- @module Octree

---
-- Function SetSize
--
-- @function [parent=#Octree] SetSize
-- @param BoundingBox#BoundingBox boxbox
-- @param #number numLevelsnumLevels

---
-- Function Update
--
-- @function [parent=#Octree] Update
-- @param FrameInfo#FrameInfo frameframe

---
-- Function AddManualDrawable
--
-- @function [parent=#Octree] AddManualDrawable
-- @param Drawable#Drawable drawabledrawable

---
-- Function RemoveManualDrawable
--
-- @function [parent=#Octree] RemoveManualDrawable
-- @param Drawable#Drawable drawabledrawable

---
-- Function GetDrawables
--
-- @function [parent=#Octree] GetDrawables
-- @param Vector3#Vector3 pointpoint
-- @param #string drawableFlagsdrawableFlags
-- @param #number viewMaskviewMask
-- @return const PODVector<OctreeQueryResult>#const PODVector<OctreeQueryResult>

---
-- Function GetDrawables
--
-- @function [parent=#Octree] GetDrawables
-- @param BoundingBox#BoundingBox boxbox
-- @param #string drawableFlagsdrawableFlags
-- @param #number viewMaskviewMask
-- @return const PODVector<OctreeQueryResult>#const PODVector<OctreeQueryResult>

---
-- Function GetDrawables
--
-- @function [parent=#Octree] GetDrawables
-- @param Frustum#Frustum frustumfrustum
-- @param #string drawableFlagsdrawableFlags
-- @param #number viewMaskviewMask
-- @return const PODVector<OctreeQueryResult>#const PODVector<OctreeQueryResult>

---
-- Function GetDrawables
--
-- @function [parent=#Octree] GetDrawables
-- @param Sphere#Sphere spheresphere
-- @param #string drawableFlagsdrawableFlags
-- @param #number viewMaskviewMask
-- @return const PODVector<OctreeQueryResult>#const PODVector<OctreeQueryResult>

---
-- Function Raycast
--
-- @function [parent=#Octree] Raycast
-- @param Ray#Ray rayray
-- @param RayQueryLevel#RayQueryLevel levellevel
-- @param #number maxDistancemaxDistance
-- @param #string drawableFlagsdrawableFlags
-- @return const PODVector<RayQueryResult>#const PODVector<RayQueryResult>

---
-- Function RaycastSingle
--
-- @function [parent=#Octree] RaycastSingle
-- @param Ray#Ray rayray
-- @param RayQueryLevel#RayQueryLevel levellevel
-- @param #number maxDistancemaxDistance
-- @param #string drawableFlagsdrawableFlags
-- @return RayQueryResult#RayQueryResult

---
-- Function GetNumLevels
--
-- @function [parent=#Octree] GetNumLevels
-- @return #number

---
-- Function QueueUpdate
--
-- @function [parent=#Octree] QueueUpdate
-- @param Drawable#Drawable drawabledrawable

---
-- Function DrawDebugGeometry
--
-- @function [parent=#Octree] DrawDebugGeometry
-- @param #boolean depthTestdepthTest

---
-- Field numLevels (Read only)
--
-- @field [parent=#Octree] #number numLevels


return nil
