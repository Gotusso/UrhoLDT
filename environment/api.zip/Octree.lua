---
-- Module Octree
-- extends Component
--
-- @module Octree

---
-- Function SetSize
--
-- @function [parent=#Octree] SetSize
-- @param BoundingBox#BoundingBox boxbox
-- @param #number numLevelsnumLevels

---
-- Function Update
--
-- @function [parent=#Octree] Update
-- @param FrameInfo#FrameInfo frameframe

---
-- Function AddManualDrawable
--
-- @function [parent=#Octree] AddManualDrawable
-- @param Drawable#Drawable drawabledrawable

---
-- Function RemoveManualDrawable
--
-- @function [parent=#Octree] RemoveManualDrawable
-- @param Drawable#Drawable drawabledrawable

---
-- Function GetDrawables
--
-- @function [parent=#Octree] GetDrawables
-- @param Vector3#Vector3 pointpoint
-- @param #string drawableFlagsdrawableFlags
-- @param #number viewMaskviewMask
-- @return const PODVector<OctreeQueryResult>#const PODVector<OctreeQueryResult>

---
-- Function GetDrawables
--
-- @function [parent=#Octree] GetDrawables
-- @param BoundingBox#BoundingBox boxbox
-- @param #string drawableFlagsdrawableFlags
-- @param #number viewMaskviewMask
-- @return const PODVector<OctreeQueryResult>#const PODVector<OctreeQueryResult>

---
-- Function GetDrawables
--
-- @function [parent=#Octree] GetDrawables
-- @param Frustum#Frustum frustumfrustum
-- @param #string drawableFlagsdrawableFlags
-- @param #number viewMaskviewMask
-- @return const PODVector<OctreeQueryResult>#const PODVector<OctreeQueryResult>

---
-- Function GetDrawables
--
-- @function [parent=#Octree] GetDrawables
-- @param Sphere#Sphere spheresphere
-- @param #string drawableFlagsdrawableFlags
-- @param #number viewMaskviewMask
-- @return const PODVector<OctreeQueryResult>#const PODVector<OctreeQueryResult>

---
-- Function Raycast
--
-- @function [parent=#Octree] Raycast
-- @param Ray#Ray rayray
-- @param RayQueryLevel#RayQueryLevel levellevel
-- @param #number maxDistancemaxDistance
-- @param #string drawableFlagsdrawableFlags
-- @return const PODVector<RayQueryResult>#const PODVector<RayQueryResult>

---
-- Function RaycastSingle
--
-- @function [parent=#Octree] RaycastSingle
-- @param Ray#Ray rayray
-- @param RayQueryLevel#RayQueryLevel levellevel
-- @param #number maxDistancemaxDistance
-- @param #string drawableFlagsdrawableFlags
-- @return RayQueryResult#RayQueryResult

---
-- Function GetNumLevels
--
-- @function [parent=#Octree] GetNumLevels
-- @return #number

---
-- Function QueueUpdate
--
-- @function [parent=#Octree] QueueUpdate
-- @param Drawable#Drawable drawabledrawable

---
-- Function DrawDebugGeometry
--
-- @function [parent=#Octree] DrawDebugGeometry
-- @param #boolean depthTestdepthTest

---
-- Field numLevels (Read only)
--
-- @field [parent=#Octree] #number numLevels

---
-- Function SetEnabled
--
-- @function [parent=#Octree] SetEnabled
-- @param #boolean enableenable

---
-- Function Remove
--
-- @function [parent=#Octree] Remove

---
-- Function GetID
--
-- @function [parent=#Octree] GetID
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#Octree] GetNode
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#Octree] GetScene
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#Octree] IsEnabled
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#Octree] IsEnabledEffective
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#Octree] GetComponent
-- @param ShortStringHash#ShortStringHash typetype
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#Octree] GetComponent
-- @param #string typetype
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#Octree] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#Octree] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Octree] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Octree] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Octree] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Octree] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Octree] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Octree] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#Octree] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Octree] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Octree] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Octree] #string category


return nil
