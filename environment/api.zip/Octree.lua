---
-- Module Octree
-- Module Octree extends Component
-- Generated on 2014-03-13
--
-- @module Octree

---
-- Function SetSize
--
-- @function [parent=#Octree] SetSize
-- @param self Self reference
-- @param BoundingBox#BoundingBox box box
-- @param #number numLevels numLevels

---
-- Function Update
--
-- @function [parent=#Octree] Update
-- @param self Self reference
-- @param FrameInfo#FrameInfo frame frame

---
-- Function AddManualDrawable
--
-- @function [parent=#Octree] AddManualDrawable
-- @param self Self reference
-- @param Drawable#Drawable drawable drawable

---
-- Function RemoveManualDrawable
--
-- @function [parent=#Octree] RemoveManualDrawable
-- @param self Self reference
-- @param Drawable#Drawable drawable drawable

---
-- Function GetDrawables
--
-- @function [parent=#Octree] GetDrawables
-- @param self Self reference
-- @param Vector3#Vector3 point point
-- @param #string drawableFlags drawableFlags
-- @param #number viewMask viewMask
-- @return const PODVector<OctreeQueryResult>#const PODVector<OctreeQueryResult>

---
-- Function GetDrawables
--
-- @function [parent=#Octree] GetDrawables
-- @param self Self reference
-- @param BoundingBox#BoundingBox box box
-- @param #string drawableFlags drawableFlags
-- @param #number viewMask viewMask
-- @return const PODVector<OctreeQueryResult>#const PODVector<OctreeQueryResult>

---
-- Function GetDrawables
--
-- @function [parent=#Octree] GetDrawables
-- @param self Self reference
-- @param Frustum#Frustum frustum frustum
-- @param #string drawableFlags drawableFlags
-- @param #number viewMask viewMask
-- @return const PODVector<OctreeQueryResult>#const PODVector<OctreeQueryResult>

---
-- Function GetDrawables
--
-- @function [parent=#Octree] GetDrawables
-- @param self Self reference
-- @param Sphere#Sphere sphere sphere
-- @param #string drawableFlags drawableFlags
-- @param #number viewMask viewMask
-- @return const PODVector<OctreeQueryResult>#const PODVector<OctreeQueryResult>

---
-- Function Raycast
--
-- @function [parent=#Octree] Raycast
-- @param self Self reference
-- @param Ray#Ray ray ray
-- @param RayQueryLevel#RayQueryLevel level level
-- @param #number maxDistance maxDistance
-- @param #string drawableFlags drawableFlags
-- @return const PODVector<RayQueryResult>#const PODVector<RayQueryResult>

---
-- Function RaycastSingle
--
-- @function [parent=#Octree] RaycastSingle
-- @param self Self reference
-- @param Ray#Ray ray ray
-- @param RayQueryLevel#RayQueryLevel level level
-- @param #number maxDistance maxDistance
-- @param #string drawableFlags drawableFlags
-- @return RayQueryResult#RayQueryResult

---
-- Function GetNumLevels
--
-- @function [parent=#Octree] GetNumLevels
-- @param self Self reference
-- @return #number

---
-- Function QueueUpdate
--
-- @function [parent=#Octree] QueueUpdate
-- @param self Self reference
-- @param Drawable#Drawable drawable drawable

---
-- Function DrawDebugGeometry
--
-- @function [parent=#Octree] DrawDebugGeometry
-- @param self Self reference
-- @param #boolean depthTest depthTest

---
-- Field numLevels (Read only)
--
-- @field [parent=#Octree] #number numLevels

---
-- Function SetEnabled
--
-- @function [parent=#Octree] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Remove
--
-- @function [parent=#Octree] Remove
-- @param self Self reference

---
-- Function GetID
--
-- @function [parent=#Octree] GetID
-- @param self Self reference
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#Octree] GetNode
-- @param self Self reference
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#Octree] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#Octree] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#Octree] IsEnabledEffective
-- @param self Self reference
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#Octree] GetComponent
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#Octree] GetComponent
-- @param self Self reference
-- @param #string type type
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#Octree] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#Octree] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Octree] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Octree] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Octree] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Octree] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Octree] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Octree] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#Octree] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Octree] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Octree] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Octree] #string category


return nil
