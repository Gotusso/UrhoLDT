---
-- Module SoundListener
-- extends Component
--
-- @module SoundListener

---
-- Function SetEnabled
--
-- @function [parent=#SoundListener] SetEnabled
-- @param #boolean enableenable

---
-- Function Remove
--
-- @function [parent=#SoundListener] Remove

---
-- Function GetID
--
-- @function [parent=#SoundListener] GetID
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#SoundListener] GetNode
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#SoundListener] GetScene
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#SoundListener] IsEnabled
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#SoundListener] IsEnabledEffective
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#SoundListener] GetComponent
-- @param ShortStringHash#ShortStringHash typetype
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#SoundListener] GetComponent
-- @param #string typetype
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#SoundListener] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#SoundListener] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#SoundListener] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#SoundListener] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#SoundListener] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#SoundListener] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#SoundListener] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#SoundListener] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#SoundListener] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#SoundListener] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#SoundListener] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#SoundListener] #string category


return nil
