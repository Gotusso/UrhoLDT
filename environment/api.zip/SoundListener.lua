---
-- Module SoundListener
-- Module SoundListener extends Component
-- Generated on 2014-03-13
--
-- @module SoundListener

---
-- Function SetEnabled
--
-- @function [parent=#SoundListener] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Remove
--
-- @function [parent=#SoundListener] Remove
-- @param self Self reference

---
-- Function GetID
--
-- @function [parent=#SoundListener] GetID
-- @param self Self reference
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#SoundListener] GetNode
-- @param self Self reference
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#SoundListener] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#SoundListener] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#SoundListener] IsEnabledEffective
-- @param self Self reference
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#SoundListener] GetComponent
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#SoundListener] GetComponent
-- @param self Self reference
-- @param #string type type
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#SoundListener] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#SoundListener] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#SoundListener] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#SoundListener] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#SoundListener] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#SoundListener] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#SoundListener] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#SoundListener] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#SoundListener] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#SoundListener] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#SoundListener] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#SoundListener] #string category


return nil
