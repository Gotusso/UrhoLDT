---
-- Module SoundListener
-- Extends Component
--
-- @module SoundListener


return nil
