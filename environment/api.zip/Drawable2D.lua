---
-- Module Drawable2D
-- Module Drawable2D extends Drawable
-- Generated on 2014-05-31
--
-- @module Drawable2D

---
-- Function SetLayer()
-- Set layer.
--
-- @function [parent=#Drawable2D] SetLayer
-- @param self Self reference
-- @param #number layer layer

---
-- Function SetOrderInLayer()
-- Set order in layer.
--
-- @function [parent=#Drawable2D] SetOrderInLayer
-- @param self Self reference
-- @param #number orderInLayer orderInLayer

---
-- Function SetSprite()
-- Set sprite.
--
-- @function [parent=#Drawable2D] SetSprite
-- @param self Self reference
-- @param Sprite2D#Sprite2D sprite sprite

---
-- Function SetBlendMode()
-- Set blend mode.
--
-- @function [parent=#Drawable2D] SetBlendMode
-- @param self Self reference
-- @param BlendMode#BlendMode mode mode

---
-- Function SetMaterial()
-- Set material.
--
-- @function [parent=#Drawable2D] SetMaterial
-- @param self Self reference
-- @param Material#Material material material

---
-- Function GetLayer()
-- Return layer.
--
-- @function [parent=#Drawable2D] GetLayer
-- @param self Self reference
-- @return #number

---
-- Function GetOrderInLayer()
-- Return order in layer.
--
-- @function [parent=#Drawable2D] GetOrderInLayer
-- @param self Self reference
-- @return #number

---
-- Function GetSprite()
-- Return sprite.
--
-- @function [parent=#Drawable2D] GetSprite
-- @param self Self reference
-- @return Sprite2D#Sprite2D

---
-- Function GetTexture()
-- Return texture.
--
-- @function [parent=#Drawable2D] GetTexture
-- @param self Self reference
-- @return Texture2D#Texture2D

---
-- Function GetBlendMode()
-- Return blend mode.
--
-- @function [parent=#Drawable2D] GetBlendMode
-- @param self Self reference
-- @return BlendMode#BlendMode

---
-- Function GetMaterial()
-- Return material.
--
-- @function [parent=#Drawable2D] GetMaterial
-- @param self Self reference
-- @return Material#Material

---
-- Field layer
--
-- @field [parent=#Drawable2D] #number layer

---
-- Field orderInLayer
--
-- @field [parent=#Drawable2D] #number orderInLayer

---
-- Field sprite
--
-- @field [parent=#Drawable2D] Sprite2D#Sprite2D sprite

---
-- Field texture (Read only)
--
-- @field [parent=#Drawable2D] Texture2D#Texture2D texture

---
-- Field blendMode
--
-- @field [parent=#Drawable2D] BlendMode#BlendMode blendMode

---
-- Field material
--
-- @field [parent=#Drawable2D] Material#Material material


return nil
