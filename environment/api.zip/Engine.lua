---
-- Module Engine
-- extends Object
--
-- @module Engine

---
-- Function RunFrame
--
-- @function [parent=#Engine] RunFrame

---
-- Function CreateConsole
--
-- @function [parent=#Engine] CreateConsole
-- @return Console#Console

---
-- Function CreateDebugHud
--
-- @function [parent=#Engine] CreateDebugHud
-- @return DebugHud#DebugHud

---
-- Function SetMinFps
--
-- @function [parent=#Engine] SetMinFps
-- @param #number fpsfps

---
-- Function SetMaxFps
--
-- @function [parent=#Engine] SetMaxFps
-- @param #number fpsfps

---
-- Function SetMaxInactiveFps
--
-- @function [parent=#Engine] SetMaxInactiveFps
-- @param #number fpsfps

---
-- Function SetTimeStepSmoothing
--
-- @function [parent=#Engine] SetTimeStepSmoothing
-- @param #number framesframes

---
-- Function SetPauseMinimized
--
-- @function [parent=#Engine] SetPauseMinimized
-- @param #boolean enableenable

---
-- Function SetAutoExit
--
-- @function [parent=#Engine] SetAutoExit
-- @param #boolean enableenable

---
-- Function Exit
--
-- @function [parent=#Engine] Exit

---
-- Function DumpProfiler
--
-- @function [parent=#Engine] DumpProfiler

---
-- Function DumpResources
--
-- @function [parent=#Engine] DumpResources

---
-- Function DumpMemory
--
-- @function [parent=#Engine] DumpMemory

---
-- Function GetMinFps
--
-- @function [parent=#Engine] GetMinFps
-- @return #number

---
-- Function GetMaxFps
--
-- @function [parent=#Engine] GetMaxFps
-- @return #number

---
-- Function GetMaxInactiveFps
--
-- @function [parent=#Engine] GetMaxInactiveFps
-- @return #number

---
-- Function GetTimeStepSmoothing
--
-- @function [parent=#Engine] GetTimeStepSmoothing
-- @return #number

---
-- Function GetPauseMinimized
--
-- @function [parent=#Engine] GetPauseMinimized
-- @return #boolean

---
-- Function GetAutoExit
--
-- @function [parent=#Engine] GetAutoExit
-- @return #boolean

---
-- Function IsInitialized
--
-- @function [parent=#Engine] IsInitialized
-- @return #boolean

---
-- Function IsExiting
--
-- @function [parent=#Engine] IsExiting
-- @return #boolean

---
-- Function IsHeadless
--
-- @function [parent=#Engine] IsHeadless
-- @return #boolean

---
-- Field minFps
--
-- @field [parent=#Engine] #number minFps

---
-- Field maxFps
--
-- @field [parent=#Engine] #number maxFps

---
-- Field maxInactiveFps
--
-- @field [parent=#Engine] #number maxInactiveFps

---
-- Field timeStepSmoothing
--
-- @field [parent=#Engine] #number timeStepSmoothing

---
-- Field pauseMinimized
--
-- @field [parent=#Engine] #boolean pauseMinimized

---
-- Field autoExit
--
-- @field [parent=#Engine] #boolean autoExit

---
-- Field initialized (Read only)
--
-- @field [parent=#Engine] #boolean initialized

---
-- Field exiting (Read only)
--
-- @field [parent=#Engine] #boolean exiting

---
-- Field headless (Read only)
--
-- @field [parent=#Engine] #boolean headless

---
-- Function GetType
--
-- @function [parent=#Engine] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Engine] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Engine] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Engine] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Engine] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#Engine] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Engine] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Engine] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Engine] #string category


return nil
