---
-- Module Engine
-- Module Engine extends Object
-- Generated on 2014-05-31
--
-- @module Engine

---
-- Function RunFrame()
-- Run one frame.
--
-- @function [parent=#Engine] RunFrame
-- @param self Self reference

---
-- Function CreateConsole()
-- Create the console and return it. May return null if engine configuration does not allow creation (headless mode.)
--
-- @function [parent=#Engine] CreateConsole
-- @param self Self reference
-- @return Console#Console

---
-- Function CreateDebugHud()
-- Create the debug hud.
--
-- @function [parent=#Engine] CreateDebugHud
-- @param self Self reference
-- @return DebugHud#DebugHud

---
-- Function SetMinFps()
-- Set minimum frames per second. If FPS goes lower than this, time will appear to slow down.
--
-- @function [parent=#Engine] SetMinFps
-- @param self Self reference
-- @param #number fps fps

---
-- Function SetMaxFps()
-- Set maximum frames per second. The engine will sleep if FPS is higher than this.
--
-- @function [parent=#Engine] SetMaxFps
-- @param self Self reference
-- @param #number fps fps

---
-- Function SetMaxInactiveFps()
-- Set maximum frames per second when the application does not have input focus.
--
-- @function [parent=#Engine] SetMaxInactiveFps
-- @param self Self reference
-- @param #number fps fps

---
-- Function SetTimeStepSmoothing()
-- Set how many frames to average for timestep smoothing. Default is 2. 1 disables smoothing.
--
-- @function [parent=#Engine] SetTimeStepSmoothing
-- @param self Self reference
-- @param #number frames frames

---
-- Function SetPauseMinimized()
-- Set whether to pause update events and audio when minimized.
--
-- @function [parent=#Engine] SetPauseMinimized
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetAutoExit()
-- Set whether to exit automatically on exit request (window close button.)
--
-- @function [parent=#Engine] SetAutoExit
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Exit()
-- Close the graphics window and set the exit flag. No-op on iOS, as an iOS application can not legally exit.
--
-- @function [parent=#Engine] Exit
-- @param self Self reference

---
-- Function DumpProfiler()
-- Dump profiling information to the log.
--
-- @function [parent=#Engine] DumpProfiler
-- @param self Self reference

---
-- Function DumpResources()
-- Dump information of all resources to the log.
--
-- @function [parent=#Engine] DumpResources
-- @param self Self reference

---
-- Function DumpMemory()
-- Dump information of all memory allocations to the log. Supported in MSVC debug mode only.
--
-- @function [parent=#Engine] DumpMemory
-- @param self Self reference

---
-- Function GetMinFps()
-- Return the minimum frames per second.
--
-- @function [parent=#Engine] GetMinFps
-- @param self Self reference
-- @return #number

---
-- Function GetMaxFps()
-- Return the maximum frames per second.
--
-- @function [parent=#Engine] GetMaxFps
-- @param self Self reference
-- @return #number

---
-- Function GetMaxInactiveFps()
-- Return the maximum frames per second when the application does not have input focus.
--
-- @function [parent=#Engine] GetMaxInactiveFps
-- @param self Self reference
-- @return #number

---
-- Function GetTimeStepSmoothing()
-- Return how many frames to average for timestep smoothing.
--
-- @function [parent=#Engine] GetTimeStepSmoothing
-- @param self Self reference
-- @return #number

---
-- Function GetPauseMinimized()
-- Return whether to pause update events and audio when minimized.
--
-- @function [parent=#Engine] GetPauseMinimized
-- @param self Self reference
-- @return #boolean

---
-- Function GetAutoExit()
-- Return whether to exit automatically on exit request.
--
-- @function [parent=#Engine] GetAutoExit
-- @param self Self reference
-- @return #boolean

---
-- Function IsInitialized()
-- Return whether engine has been initialized.
--
-- @function [parent=#Engine] IsInitialized
-- @param self Self reference
-- @return #boolean

---
-- Function IsExiting()
-- Return whether exit has been requested.
--
-- @function [parent=#Engine] IsExiting
-- @param self Self reference
-- @return #boolean

---
-- Function IsHeadless()
-- Return whether the engine has been created in headless mode.
--
-- @function [parent=#Engine] IsHeadless
-- @param self Self reference
-- @return #boolean

---
-- Field minFps
--
-- @field [parent=#Engine] #number minFps

---
-- Field maxFps
--
-- @field [parent=#Engine] #number maxFps

---
-- Field maxInactiveFps
--
-- @field [parent=#Engine] #number maxInactiveFps

---
-- Field timeStepSmoothing
--
-- @field [parent=#Engine] #number timeStepSmoothing

---
-- Field pauseMinimized
--
-- @field [parent=#Engine] #boolean pauseMinimized

---
-- Field autoExit
--
-- @field [parent=#Engine] #boolean autoExit

---
-- Field initialized (Read only)
--
-- @field [parent=#Engine] #boolean initialized

---
-- Field exiting (Read only)
--
-- @field [parent=#Engine] #boolean exiting

---
-- Field headless (Read only)
--
-- @field [parent=#Engine] #boolean headless


return nil
