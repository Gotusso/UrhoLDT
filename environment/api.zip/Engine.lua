---
-- Module Engine
-- Module Engine extends Object
-- Generated on 2014-03-13
--
-- @module Engine

---
-- Function RunFrame
--
-- @function [parent=#Engine] RunFrame
-- @param self Self reference

---
-- Function CreateConsole
--
-- @function [parent=#Engine] CreateConsole
-- @param self Self reference
-- @return Console#Console

---
-- Function CreateDebugHud
--
-- @function [parent=#Engine] CreateDebugHud
-- @param self Self reference
-- @return DebugHud#DebugHud

---
-- Function SetMinFps
--
-- @function [parent=#Engine] SetMinFps
-- @param self Self reference
-- @param #number fps fps

---
-- Function SetMaxFps
--
-- @function [parent=#Engine] SetMaxFps
-- @param self Self reference
-- @param #number fps fps

---
-- Function SetMaxInactiveFps
--
-- @function [parent=#Engine] SetMaxInactiveFps
-- @param self Self reference
-- @param #number fps fps

---
-- Function SetTimeStepSmoothing
--
-- @function [parent=#Engine] SetTimeStepSmoothing
-- @param self Self reference
-- @param #number frames frames

---
-- Function SetPauseMinimized
--
-- @function [parent=#Engine] SetPauseMinimized
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetAutoExit
--
-- @function [parent=#Engine] SetAutoExit
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Exit
--
-- @function [parent=#Engine] Exit
-- @param self Self reference

---
-- Function DumpProfiler
--
-- @function [parent=#Engine] DumpProfiler
-- @param self Self reference

---
-- Function DumpResources
--
-- @function [parent=#Engine] DumpResources
-- @param self Self reference

---
-- Function DumpMemory
--
-- @function [parent=#Engine] DumpMemory
-- @param self Self reference

---
-- Function GetMinFps
--
-- @function [parent=#Engine] GetMinFps
-- @param self Self reference
-- @return #number

---
-- Function GetMaxFps
--
-- @function [parent=#Engine] GetMaxFps
-- @param self Self reference
-- @return #number

---
-- Function GetMaxInactiveFps
--
-- @function [parent=#Engine] GetMaxInactiveFps
-- @param self Self reference
-- @return #number

---
-- Function GetTimeStepSmoothing
--
-- @function [parent=#Engine] GetTimeStepSmoothing
-- @param self Self reference
-- @return #number

---
-- Function GetPauseMinimized
--
-- @function [parent=#Engine] GetPauseMinimized
-- @param self Self reference
-- @return #boolean

---
-- Function GetAutoExit
--
-- @function [parent=#Engine] GetAutoExit
-- @param self Self reference
-- @return #boolean

---
-- Function IsInitialized
--
-- @function [parent=#Engine] IsInitialized
-- @param self Self reference
-- @return #boolean

---
-- Function IsExiting
--
-- @function [parent=#Engine] IsExiting
-- @param self Self reference
-- @return #boolean

---
-- Function IsHeadless
--
-- @function [parent=#Engine] IsHeadless
-- @param self Self reference
-- @return #boolean

---
-- Field minFps
--
-- @field [parent=#Engine] #number minFps

---
-- Field maxFps
--
-- @field [parent=#Engine] #number maxFps

---
-- Field maxInactiveFps
--
-- @field [parent=#Engine] #number maxInactiveFps

---
-- Field timeStepSmoothing
--
-- @field [parent=#Engine] #number timeStepSmoothing

---
-- Field pauseMinimized
--
-- @field [parent=#Engine] #boolean pauseMinimized

---
-- Field autoExit
--
-- @field [parent=#Engine] #boolean autoExit

---
-- Field initialized (Read only)
--
-- @field [parent=#Engine] #boolean initialized

---
-- Field exiting (Read only)
--
-- @field [parent=#Engine] #boolean exiting

---
-- Field headless (Read only)
--
-- @field [parent=#Engine] #boolean headless

---
-- Function GetType
--
-- @function [parent=#Engine] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Engine] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Engine] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Engine] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Engine] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#Engine] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Engine] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Engine] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Engine] #string category


return nil
