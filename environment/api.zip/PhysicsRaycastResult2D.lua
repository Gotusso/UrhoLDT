---
-- Module PhysicsRaycastResult2D
-- Generated on 2014-05-31
--
-- @module PhysicsRaycastResult2D

---
-- Function PhysicsRaycastResult2D()
--
-- @function [parent=#PhysicsRaycastResult2D] PhysicsRaycastResult2D
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#PhysicsRaycastResult2D] new
-- @param self Self reference
-- @return PhysicsRaycastResult2D#PhysicsRaycastResult2D

---
-- Function delete()
--
-- @function [parent=#PhysicsRaycastResult2D] delete
-- @param self Self reference

---
-- Field position
--
-- @field [parent=#PhysicsRaycastResult2D] Vector2#Vector2 position

---
-- Field normal
--
-- @field [parent=#PhysicsRaycastResult2D] Vector2#Vector2 normal

---
-- Field distance
--
-- @field [parent=#PhysicsRaycastResult2D] #number distance

---
-- Field body
--
-- @field [parent=#PhysicsRaycastResult2D] RigidBody2D#RigidBody2D body


return nil
