---
-- Module Pass
-- Module Pass extends RefCounted
-- Generated on 2014-05-31
--
-- @module Pass

---
-- Function IsSM3()
-- Return whether requires %Shader %Model 3.
--
-- @function [parent=#Pass] IsSM3
-- @param self Self reference
-- @return #boolean

---
-- Field SM3 (Read only)
--
-- @field [parent=#Pass] #boolean SM3


return nil
