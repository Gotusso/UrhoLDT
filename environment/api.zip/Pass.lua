---
-- Module Pass
-- Module Pass extends RefCounted
-- Generated on 2014-03-13
--
-- @module Pass


return nil
