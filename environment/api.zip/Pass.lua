---
-- Module Pass
-- Extends RefCounted
--
-- @module Pass


return nil
