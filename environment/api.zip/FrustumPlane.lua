---
-- Enumeration FrustumPlane
--
-- @module FrustumPlane

---
-- Enumeration value PLANE_NEAR
--
-- @field [parent=#FrustumPlane] #number PLANE_NEAR

---
-- Enumeration value PLANE_LEFT
--
-- @field [parent=#FrustumPlane] #number PLANE_LEFT

---
-- Enumeration value PLANE_RIGHT
--
-- @field [parent=#FrustumPlane] #number PLANE_RIGHT

---
-- Enumeration value PLANE_UP
--
-- @field [parent=#FrustumPlane] #number PLANE_UP

---
-- Enumeration value PLANE_DOWN
--
-- @field [parent=#FrustumPlane] #number PLANE_DOWN

---
-- Enumeration value PLANE_FAR
--
-- @field [parent=#FrustumPlane] #number PLANE_FAR


return nil
