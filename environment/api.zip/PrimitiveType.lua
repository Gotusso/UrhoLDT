---
-- Enumeration PrimitiveType
--
-- @module PrimitiveType

---
-- Enumeration value TRIANGLE_LIST
--
-- @field [parent=#PrimitiveType] #number TRIANGLE_LIST

---
-- Enumeration value LINE_LIST
--
-- @field [parent=#PrimitiveType] #number LINE_LIST


return nil
