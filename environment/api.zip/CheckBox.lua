---
-- Module CheckBox
-- Module CheckBox extends BorderImage
-- Generated on 2014-05-31
--
-- @module CheckBox

---
-- Function CheckBox()
--
-- @function [parent=#CheckBox] CheckBox
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#CheckBox] new
-- @param self Self reference
-- @return CheckBox#CheckBox

---
-- Function delete()
--
-- @function [parent=#CheckBox] delete
-- @param self Self reference

---
-- Function SetChecked()
-- Set checked state.
--
-- @function [parent=#CheckBox] SetChecked
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetCheckedOffset()
-- Set checked image offset.
--
-- @function [parent=#CheckBox] SetCheckedOffset
-- @param self Self reference
-- @param IntVector2#IntVector2 rect rect

---
-- Function SetCheckedOffset()
-- Set checked image offset.
--
-- @function [parent=#CheckBox] SetCheckedOffset
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function IsChecked()
-- Return whether is checked.
--
-- @function [parent=#CheckBox] IsChecked
-- @param self Self reference
-- @return #boolean

---
-- Function GetCheckedOffset()
-- Return checked image offset.
--
-- @function [parent=#CheckBox] GetCheckedOffset
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Field checked
--
-- @field [parent=#CheckBox] #boolean checked

---
-- Field checkedOffset
--
-- @field [parent=#CheckBox] IntVector2#IntVector2 checkedOffset


return nil
