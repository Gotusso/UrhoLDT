---
-- Module CheckBox
-- Module CheckBox extends BorderImage
-- Generated on 2014-03-13
--
-- @module CheckBox

---
-- Function CheckBox
--
-- @function [parent=#CheckBox] CheckBox
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#CheckBox] new
-- @param self Self reference
-- @return CheckBox#CheckBox

---
-- Function delete
--
-- @function [parent=#CheckBox] delete
-- @param self Self reference

---
-- Function SetChecked
--
-- @function [parent=#CheckBox] SetChecked
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetCheckedOffset
--
-- @function [parent=#CheckBox] SetCheckedOffset
-- @param self Self reference
-- @param IntVector2#IntVector2 rect rect

---
-- Function SetCheckedOffset
--
-- @function [parent=#CheckBox] SetCheckedOffset
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function IsChecked
--
-- @function [parent=#CheckBox] IsChecked
-- @param self Self reference
-- @return #boolean

---
-- Function GetCheckedOffset
--
-- @function [parent=#CheckBox] GetCheckedOffset
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Field checked
--
-- @field [parent=#CheckBox] #boolean checked

---
-- Field checkedOffset
--
-- @field [parent=#CheckBox] IntVector2#IntVector2 checkedOffset

---
-- Function BorderImage
--
-- @function [parent=#CheckBox] BorderImage
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#CheckBox] new
-- @param self Self reference
-- @return BorderImage#BorderImage

---
-- Function delete
--
-- @function [parent=#CheckBox] delete
-- @param self Self reference

---
-- Function SetTexture
--
-- @function [parent=#CheckBox] SetTexture
-- @param self Self reference
-- @param Texture#Texture texture texture

---
-- Function SetImageRect
--
-- @function [parent=#CheckBox] SetImageRect
-- @param self Self reference
-- @param IntRect#IntRect rect rect

---
-- Function SetFullImageRect
--
-- @function [parent=#CheckBox] SetFullImageRect
-- @param self Self reference

---
-- Function SetBorder
--
-- @function [parent=#CheckBox] SetBorder
-- @param self Self reference
-- @param IntRect#IntRect rect rect

---
-- Function SetHoverOffset
--
-- @function [parent=#CheckBox] SetHoverOffset
-- @param self Self reference
-- @param IntVector2#IntVector2 offset offset

---
-- Function SetHoverOffset
--
-- @function [parent=#CheckBox] SetHoverOffset
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function SetBlendMode
--
-- @function [parent=#CheckBox] SetBlendMode
-- @param self Self reference
-- @param BlendMode#BlendMode mode mode

---
-- Function SetTiled
--
-- @function [parent=#CheckBox] SetTiled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function GetTexture
--
-- @function [parent=#CheckBox] GetTexture
-- @param self Self reference
-- @return Texture#Texture

---
-- Function GetImageRect
--
-- @function [parent=#CheckBox] GetImageRect
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetBorder
--
-- @function [parent=#CheckBox] GetBorder
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetHoverOffset
--
-- @function [parent=#CheckBox] GetHoverOffset
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetBlendMode
--
-- @function [parent=#CheckBox] GetBlendMode
-- @param self Self reference
-- @return BlendMode#BlendMode

---
-- Function IsTiled
--
-- @function [parent=#CheckBox] IsTiled
-- @param self Self reference
-- @return #boolean

---
-- Field texture
--
-- @field [parent=#CheckBox] Texture#Texture texture

---
-- Field imageRect
--
-- @field [parent=#CheckBox] IntRect#IntRect imageRect

---
-- Field border
--
-- @field [parent=#CheckBox] IntRect#IntRect border

---
-- Field hoverOffset
--
-- @field [parent=#CheckBox] IntVector2#IntVector2 hoverOffset

---
-- Field blendMode
--
-- @field [parent=#CheckBox] BlendMode#BlendMode blendMode

---
-- Field tiled
--
-- @field [parent=#CheckBox] #boolean tiled

---
-- Function UIElement
--
-- @function [parent=#CheckBox] UIElement
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#CheckBox] new
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function delete
--
-- @function [parent=#CheckBox] delete
-- @param self Self reference

---
-- Function GetScreenPosition
--
-- @function [parent=#CheckBox] GetScreenPosition
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function LoadXML
--
-- @function [parent=#CheckBox] LoadXML
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#CheckBox] SaveXML
-- @param self Self reference
-- @param Serializer#Serializer dest dest
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#CheckBox] LoadXML
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#CheckBox] SaveXML
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function FilterAttributes
--
-- @function [parent=#CheckBox] FilterAttributes
-- @param self Self reference
-- @param XMLElement#XMLElement dest dest
-- @return #boolean

---
-- Function SetName
--
-- @function [parent=#CheckBox] SetName
-- @param self Self reference
-- @param #string name name

---
-- Function SetPosition
--
-- @function [parent=#CheckBox] SetPosition
-- @param self Self reference
-- @param IntVector2#IntVector2 position position

---
-- Function SetPosition
--
-- @function [parent=#CheckBox] SetPosition
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function SetSize
--
-- @function [parent=#CheckBox] SetSize
-- @param self Self reference
-- @param IntVector2#IntVector2 size size

---
-- Function SetSize
--
-- @function [parent=#CheckBox] SetSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetWidth
--
-- @function [parent=#CheckBox] SetWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetHeight
--
-- @function [parent=#CheckBox] SetHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetMinSize
--
-- @function [parent=#CheckBox] SetMinSize
-- @param self Self reference
-- @param IntVector2#IntVector2 minSize minSize

---
-- Function SetMinSize
--
-- @function [parent=#CheckBox] SetMinSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetMinWidth
--
-- @function [parent=#CheckBox] SetMinWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetMinHeight
--
-- @function [parent=#CheckBox] SetMinHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetMaxSize
--
-- @function [parent=#CheckBox] SetMaxSize
-- @param self Self reference
-- @param IntVector2#IntVector2 maxSize maxSize

---
-- Function SetMaxSize
--
-- @function [parent=#CheckBox] SetMaxSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetMaxWidth
--
-- @function [parent=#CheckBox] SetMaxWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetMaxHeight
--
-- @function [parent=#CheckBox] SetMaxHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetFixedSize
--
-- @function [parent=#CheckBox] SetFixedSize
-- @param self Self reference
-- @param IntVector2#IntVector2 size size

---
-- Function SetFixedSize
--
-- @function [parent=#CheckBox] SetFixedSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetFixedWidth
--
-- @function [parent=#CheckBox] SetFixedWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetFixedHeight
--
-- @function [parent=#CheckBox] SetFixedHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetAlignment
--
-- @function [parent=#CheckBox] SetAlignment
-- @param self Self reference
-- @param HorizontalAlignment#HorizontalAlignment hAlign hAlign
-- @param VerticalAlignment#VerticalAlignment vAlign vAlign

---
-- Function SetHorizontalAlignment
--
-- @function [parent=#CheckBox] SetHorizontalAlignment
-- @param self Self reference
-- @param HorizontalAlignment#HorizontalAlignment align align

---
-- Function SetVerticalAlignment
--
-- @function [parent=#CheckBox] SetVerticalAlignment
-- @param self Self reference
-- @param VerticalAlignment#VerticalAlignment align align

---
-- Function SetClipBorder
--
-- @function [parent=#CheckBox] SetClipBorder
-- @param self Self reference
-- @param IntRect#IntRect rect rect

---
-- Function SetColor
--
-- @function [parent=#CheckBox] SetColor
-- @param self Self reference
-- @param Color#Color color color

---
-- Function SetColor
--
-- @function [parent=#CheckBox] SetColor
-- @param self Self reference
-- @param Corner#Corner corner corner
-- @param Color#Color color color

---
-- Function SetPriority
--
-- @function [parent=#CheckBox] SetPriority
-- @param self Self reference
-- @param #number priority priority

---
-- Function SetOpacity
--
-- @function [parent=#CheckBox] SetOpacity
-- @param self Self reference
-- @param #number opacity opacity

---
-- Function SetBringToFront
--
-- @function [parent=#CheckBox] SetBringToFront
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetBringToBack
--
-- @function [parent=#CheckBox] SetBringToBack
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetClipChildren
--
-- @function [parent=#CheckBox] SetClipChildren
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetSortChildren
--
-- @function [parent=#CheckBox] SetSortChildren
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetUseDerivedOpacity
--
-- @function [parent=#CheckBox] SetUseDerivedOpacity
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetEnabled
--
-- @function [parent=#CheckBox] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetEditable
--
-- @function [parent=#CheckBox] SetEditable
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetFocus
--
-- @function [parent=#CheckBox] SetFocus
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetSelected
--
-- @function [parent=#CheckBox] SetSelected
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetVisible
--
-- @function [parent=#CheckBox] SetVisible
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetFocusMode
--
-- @function [parent=#CheckBox] SetFocusMode
-- @param self Self reference
-- @param FocusMode#FocusMode mode mode

---
-- Function SetDragDropMode
--
-- @function [parent=#CheckBox] SetDragDropMode
-- @param self Self reference
-- @param #number mode mode

---
-- Function SetStyle
--
-- @function [parent=#CheckBox] SetStyle
-- @param self Self reference
-- @param #string styleName styleName
-- @param XMLFile#XMLFile file file
-- @return #boolean

---
-- Function SetStyle
--
-- @function [parent=#CheckBox] SetStyle
-- @param self Self reference
-- @param XMLElement#XMLElement element element
-- @return #boolean

---
-- Function SetStyleAuto
--
-- @function [parent=#CheckBox] SetStyleAuto
-- @param self Self reference
-- @param XMLFile#XMLFile file file
-- @return #boolean

---
-- Function SetDefaultStyle
--
-- @function [parent=#CheckBox] SetDefaultStyle
-- @param self Self reference
-- @param XMLFile#XMLFile style style

---
-- Function SetLayout
--
-- @function [parent=#CheckBox] SetLayout
-- @param self Self reference
-- @param LayoutMode#LayoutMode mode mode
-- @param #number spacing spacing

---
-- Function SetLayout
--
-- @function [parent=#CheckBox] SetLayout
-- @param self Self reference
-- @param LayoutMode#LayoutMode mode mode
-- @param #number spacing spacing
-- @param IntRect#IntRect border border

---
-- Function SetLayoutMode
--
-- @function [parent=#CheckBox] SetLayoutMode
-- @param self Self reference
-- @param LayoutMode#LayoutMode mode mode

---
-- Function SetLayoutSpacing
--
-- @function [parent=#CheckBox] SetLayoutSpacing
-- @param self Self reference
-- @param #number spacing spacing

---
-- Function SetLayoutBorder
--
-- @function [parent=#CheckBox] SetLayoutBorder
-- @param self Self reference
-- @param IntRect#IntRect border border

---
-- Function SetIndent
--
-- @function [parent=#CheckBox] SetIndent
-- @param self Self reference
-- @param #number indent indent

---
-- Function SetIndentSpacing
--
-- @function [parent=#CheckBox] SetIndentSpacing
-- @param self Self reference
-- @param #number indentSpacing indentSpacing

---
-- Function UpdateLayout
--
-- @function [parent=#CheckBox] UpdateLayout
-- @param self Self reference

---
-- Function DisableLayoutUpdate
--
-- @function [parent=#CheckBox] DisableLayoutUpdate
-- @param self Self reference

---
-- Function EnableLayoutUpdate
--
-- @function [parent=#CheckBox] EnableLayoutUpdate
-- @param self Self reference

---
-- Function BringToFront
--
-- @function [parent=#CheckBox] BringToFront
-- @param self Self reference

---
-- Function CreateChild
--
-- @function [parent=#CheckBox] CreateChild
-- @param self Self reference
-- @param #string type type
-- @param #string name name
-- @param #number index index
-- @return UIElement#UIElement

---
-- Function AddChild
--
-- @function [parent=#CheckBox] AddChild
-- @param self Self reference
-- @param UIElement#UIElement element element

---
-- Function InsertChild
--
-- @function [parent=#CheckBox] InsertChild
-- @param self Self reference
-- @param #number index index
-- @param UIElement#UIElement element element

---
-- Function RemoveChild
--
-- @function [parent=#CheckBox] RemoveChild
-- @param self Self reference
-- @param UIElement#UIElement element element
-- @param #number index index

---
-- Function RemoveChildAtIndex
--
-- @function [parent=#CheckBox] RemoveChildAtIndex
-- @param self Self reference
-- @param #number index index

---
-- Function RemoveAllChildren
--
-- @function [parent=#CheckBox] RemoveAllChildren
-- @param self Self reference

---
-- Function Remove
--
-- @function [parent=#CheckBox] Remove
-- @param self Self reference

---
-- Function FindChild
--
-- @function [parent=#CheckBox] FindChild
-- @param self Self reference
-- @param UIElement#UIElement element element
-- @return #number

---
-- Function SetParent
--
-- @function [parent=#CheckBox] SetParent
-- @param self Self reference
-- @param UIElement#UIElement parent parent
-- @param #number index index

---
-- Function SetVar
--
-- @function [parent=#CheckBox] SetVar
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash key key
-- @param Variant#Variant value value

---
-- Function SetInternal
--
-- @function [parent=#CheckBox] SetInternal
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetTraversalMode
--
-- @function [parent=#CheckBox] SetTraversalMode
-- @param self Self reference
-- @param TraversalMode#TraversalMode traversalMode traversalMode

---
-- Function SetElementEventSender
--
-- @function [parent=#CheckBox] SetElementEventSender
-- @param self Self reference
-- @param #boolean flag flag

---
-- Function GetName
--
-- @function [parent=#CheckBox] GetName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetPosition
--
-- @function [parent=#CheckBox] GetPosition
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetSize
--
-- @function [parent=#CheckBox] GetSize
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetWidth
--
-- @function [parent=#CheckBox] GetWidth
-- @param self Self reference
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#CheckBox] GetHeight
-- @param self Self reference
-- @return #number

---
-- Function GetMinSize
--
-- @function [parent=#CheckBox] GetMinSize
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetMinWidth
--
-- @function [parent=#CheckBox] GetMinWidth
-- @param self Self reference
-- @return #number

---
-- Function GetMinHeight
--
-- @function [parent=#CheckBox] GetMinHeight
-- @param self Self reference
-- @return #number

---
-- Function GetMaxSize
--
-- @function [parent=#CheckBox] GetMaxSize
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetMaxWidth
--
-- @function [parent=#CheckBox] GetMaxWidth
-- @param self Self reference
-- @return #number

---
-- Function GetMaxHeight
--
-- @function [parent=#CheckBox] GetMaxHeight
-- @param self Self reference
-- @return #number

---
-- Function IsFixedSize
--
-- @function [parent=#CheckBox] IsFixedSize
-- @param self Self reference
-- @return #boolean

---
-- Function IsFixedWidth
--
-- @function [parent=#CheckBox] IsFixedWidth
-- @param self Self reference
-- @return #boolean

---
-- Function IsFixedHeight
--
-- @function [parent=#CheckBox] IsFixedHeight
-- @param self Self reference
-- @return #boolean

---
-- Function GetChildOffset
--
-- @function [parent=#CheckBox] GetChildOffset
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetHorizontalAlignment
--
-- @function [parent=#CheckBox] GetHorizontalAlignment
-- @param self Self reference
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetVerticalAlignment
--
-- @function [parent=#CheckBox] GetVerticalAlignment
-- @param self Self reference
-- @return VerticalAlignment#VerticalAlignment

---
-- Function GetClipBorder
--
-- @function [parent=#CheckBox] GetClipBorder
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetColor
--
-- @function [parent=#CheckBox] GetColor
-- @param self Self reference
-- @param Corner#Corner corner corner
-- @return const Color#const Color

---
-- Function GetPriority
--
-- @function [parent=#CheckBox] GetPriority
-- @param self Self reference
-- @return #number

---
-- Function GetOpacity
--
-- @function [parent=#CheckBox] GetOpacity
-- @param self Self reference
-- @return #number

---
-- Function GetDerivedOpacity
--
-- @function [parent=#CheckBox] GetDerivedOpacity
-- @param self Self reference
-- @return #number

---
-- Function GetBringToFront
--
-- @function [parent=#CheckBox] GetBringToFront
-- @param self Self reference
-- @return #boolean

---
-- Function GetBringToBack
--
-- @function [parent=#CheckBox] GetBringToBack
-- @param self Self reference
-- @return #boolean

---
-- Function GetClipChildren
--
-- @function [parent=#CheckBox] GetClipChildren
-- @param self Self reference
-- @return #boolean

---
-- Function GetSortChildren
--
-- @function [parent=#CheckBox] GetSortChildren
-- @param self Self reference
-- @return #boolean

---
-- Function GetUseDerivedOpacity
--
-- @function [parent=#CheckBox] GetUseDerivedOpacity
-- @param self Self reference
-- @return #boolean

---
-- Function HasFocus
--
-- @function [parent=#CheckBox] HasFocus
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabled
--
-- @function [parent=#CheckBox] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEditable
--
-- @function [parent=#CheckBox] IsEditable
-- @param self Self reference
-- @return #boolean

---
-- Function IsSelected
--
-- @function [parent=#CheckBox] IsSelected
-- @param self Self reference
-- @return #boolean

---
-- Function IsVisible
--
-- @function [parent=#CheckBox] IsVisible
-- @param self Self reference
-- @return #boolean

---
-- Function IsHovering
--
-- @function [parent=#CheckBox] IsHovering
-- @param self Self reference
-- @return #boolean

---
-- Function IsInternal
--
-- @function [parent=#CheckBox] IsInternal
-- @param self Self reference
-- @return #boolean

---
-- Function HasColorGradient
--
-- @function [parent=#CheckBox] HasColorGradient
-- @param self Self reference
-- @return #boolean

---
-- Function GetFocusMode
--
-- @function [parent=#CheckBox] GetFocusMode
-- @param self Self reference
-- @return FocusMode#FocusMode

---
-- Function GetDragDropMode
--
-- @function [parent=#CheckBox] GetDragDropMode
-- @param self Self reference
-- @return #number

---
-- Function GetAppliedStyle
--
-- @function [parent=#CheckBox] GetAppliedStyle
-- @param self Self reference
-- @return const String#const String

---
-- Function GetDefaultStyle
--
-- @function [parent=#CheckBox] GetDefaultStyle
-- @param self Self reference
-- @param #boolean recursiveUp recursiveUp
-- @return XMLFile#XMLFile

---
-- Function GetLayoutMode
--
-- @function [parent=#CheckBox] GetLayoutMode
-- @param self Self reference
-- @return LayoutMode#LayoutMode

---
-- Function GetLayoutSpacing
--
-- @function [parent=#CheckBox] GetLayoutSpacing
-- @param self Self reference
-- @return #number

---
-- Function GetLayoutBorder
--
-- @function [parent=#CheckBox] GetLayoutBorder
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetNumChildren
--
-- @function [parent=#CheckBox] GetNumChildren
-- @param self Self reference
-- @param #boolean recursive recursive
-- @return #number

---
-- Function GetChild
--
-- @function [parent=#CheckBox] GetChild
-- @param self Self reference
-- @param #string name name
-- @param #boolean recursive recursive
-- @return UIElement#UIElement

---
-- Function GetChild
--
-- @function [parent=#CheckBox] GetChild
-- @param self Self reference
-- @param #number index index
-- @return UIElement#UIElement

---
-- Function GetParent
--
-- @function [parent=#CheckBox] GetParent
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetRoot
--
-- @function [parent=#CheckBox] GetRoot
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetDerivedColor
--
-- @function [parent=#CheckBox] GetDerivedColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetVar
--
-- @function [parent=#CheckBox] GetVar
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash key key
-- @return const Variant#const Variant

---
-- Function GetVars
--
-- @function [parent=#CheckBox] GetVars
-- @param self Self reference
-- @return const VariantMap#const VariantMap

---
-- Function ScreenToElement
--
-- @function [parent=#CheckBox] ScreenToElement
-- @param self Self reference
-- @param IntVector2#IntVector2 screenPosition screenPosition
-- @return IntVector2#IntVector2

---
-- Function ElementToScreen
--
-- @function [parent=#CheckBox] ElementToScreen
-- @param self Self reference
-- @param IntVector2#IntVector2 position position
-- @return IntVector2#IntVector2

---
-- Function IsInside
--
-- @function [parent=#CheckBox] IsInside
-- @param self Self reference
-- @param IntVector2#IntVector2 position position
-- @param #boolean isScreen isScreen
-- @return #boolean

---
-- Function IsInsideCombined
--
-- @function [parent=#CheckBox] IsInsideCombined
-- @param self Self reference
-- @param IntVector2#IntVector2 position position
-- @param #boolean isScreen isScreen
-- @return #boolean

---
-- Function GetCombinedScreenRect
--
-- @function [parent=#CheckBox] GetCombinedScreenRect
-- @param self Self reference
-- @return IntRect#IntRect

---
-- Function SortChildren
--
-- @function [parent=#CheckBox] SortChildren
-- @param self Self reference

---
-- Function GetLayoutMinSize
--
-- @function [parent=#CheckBox] GetLayoutMinSize
-- @param self Self reference
-- @return #number

---
-- Function GetIndent
--
-- @function [parent=#CheckBox] GetIndent
-- @param self Self reference
-- @return #number

---
-- Function GetIndentSpacing
--
-- @function [parent=#CheckBox] GetIndentSpacing
-- @param self Self reference
-- @return #number

---
-- Function GetIndentWidth
--
-- @function [parent=#CheckBox] GetIndentWidth
-- @param self Self reference
-- @return #number

---
-- Function SetChildOffset
--
-- @function [parent=#CheckBox] SetChildOffset
-- @param self Self reference
-- @param IntVector2#IntVector2 offset offset

---
-- Function SetHovering
--
-- @function [parent=#CheckBox] SetHovering
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function GetColor
--
-- @function [parent=#CheckBox] GetColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetTraversalMode
--
-- @function [parent=#CheckBox] GetTraversalMode
-- @param self Self reference
-- @return TraversalMode#TraversalMode

---
-- Function IsElementEventSender
--
-- @function [parent=#CheckBox] IsElementEventSender
-- @param self Self reference
-- @return #boolean

---
-- Function GetElementEventSender
--
-- @function [parent=#CheckBox] GetElementEventSender
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Field screenPosition (Read only)
--
-- @field [parent=#CheckBox] IntVector2#IntVector2 screenPosition

---
-- Field name
--
-- @field [parent=#CheckBox] #string name

---
-- Field position
--
-- @field [parent=#CheckBox] IntVector2#IntVector2 position

---
-- Field size
--
-- @field [parent=#CheckBox] IntVector2#IntVector2 size

---
-- Field width
--
-- @field [parent=#CheckBox] #number width

---
-- Field height
--
-- @field [parent=#CheckBox] #number height

---
-- Field minSize
--
-- @field [parent=#CheckBox] IntVector2#IntVector2 minSize

---
-- Field minWidth
--
-- @field [parent=#CheckBox] #number minWidth

---
-- Field minHeight
--
-- @field [parent=#CheckBox] #number minHeight

---
-- Field maxSize
--
-- @field [parent=#CheckBox] IntVector2#IntVector2 maxSize

---
-- Field maxWidth
--
-- @field [parent=#CheckBox] #number maxWidth

---
-- Field maxHeight
--
-- @field [parent=#CheckBox] #number maxHeight

---
-- Field fixedSize (Read only)
--
-- @field [parent=#CheckBox] #boolean fixedSize

---
-- Field fixedWidth (Read only)
--
-- @field [parent=#CheckBox] #boolean fixedWidth

---
-- Field fixedHeight (Read only)
--
-- @field [parent=#CheckBox] #boolean fixedHeight

---
-- Field childOffset
--
-- @field [parent=#CheckBox] IntVector2#IntVector2 childOffset

---
-- Field horizontalAlignment
--
-- @field [parent=#CheckBox] HorizontalAlignment#HorizontalAlignment horizontalAlignment

---
-- Field verticalAlignment
--
-- @field [parent=#CheckBox] VerticalAlignment#VerticalAlignment verticalAlignment

---
-- Field clipBorder
--
-- @field [parent=#CheckBox] IntRect#IntRect clipBorder

---
-- Field color
--
-- @field [parent=#CheckBox] Color#Color color

---
-- Field priority
--
-- @field [parent=#CheckBox] #number priority

---
-- Field opacity
--
-- @field [parent=#CheckBox] #number opacity

---
-- Field derivedOpacity (Read only)
--
-- @field [parent=#CheckBox] #number derivedOpacity

---
-- Field bringToFront
--
-- @field [parent=#CheckBox] #boolean bringToFront

---
-- Field bringToBack
--
-- @field [parent=#CheckBox] #boolean bringToBack

---
-- Field clipChildren
--
-- @field [parent=#CheckBox] #boolean clipChildren

---
-- Field sortChildren
--
-- @field [parent=#CheckBox] #boolean sortChildren

---
-- Field useDerivedOpacity
--
-- @field [parent=#CheckBox] #boolean useDerivedOpacity

---
-- Field focus
--
-- @field [parent=#CheckBox] #boolean focus

---
-- Field enabled
--
-- @field [parent=#CheckBox] #boolean enabled

---
-- Field editable
--
-- @field [parent=#CheckBox] #boolean editable

---
-- Field selected
--
-- @field [parent=#CheckBox] #boolean selected

---
-- Field visible
--
-- @field [parent=#CheckBox] #boolean visible

---
-- Field hovering
--
-- @field [parent=#CheckBox] #boolean hovering

---
-- Field internal
--
-- @field [parent=#CheckBox] #boolean internal

---
-- Field colorGradient (Read only)
--
-- @field [parent=#CheckBox] #boolean colorGradient

---
-- Field focusMode
--
-- @field [parent=#CheckBox] FocusMode#FocusMode focusMode

---
-- Field dragDropMode
--
-- @field [parent=#CheckBox] #number dragDropMode

---
-- Field style
--
-- @field [parent=#CheckBox] #string style

---
-- Field defaultStyle
--
-- @field [parent=#CheckBox] XMLFile#XMLFile defaultStyle

---
-- Field layoutMode
--
-- @field [parent=#CheckBox] LayoutMode#LayoutMode layoutMode

---
-- Field layoutSpacing
--
-- @field [parent=#CheckBox] #number layoutSpacing

---
-- Field layoutBorder
--
-- @field [parent=#CheckBox] IntRect#IntRect layoutBorder

---
-- Field numChildren (Read only)
--
-- @field [parent=#CheckBox] #number numChildren

---
-- Field parent
--
-- @field [parent=#CheckBox] UIElement#UIElement parent

---
-- Field root (Read only)
--
-- @field [parent=#CheckBox] UIElement#UIElement root

---
-- Field derivedColor (Read only)
--
-- @field [parent=#CheckBox] Color#Color derivedColor

---
-- Field combinedScreenRect (Read only)
--
-- @field [parent=#CheckBox] IntRect#IntRect combinedScreenRect

---
-- Field layoutMinSize (Read only)
--
-- @field [parent=#CheckBox] #number layoutMinSize

---
-- Field indent
--
-- @field [parent=#CheckBox] #number indent

---
-- Field indentSpacing
--
-- @field [parent=#CheckBox] #number indentSpacing

---
-- Field indentWidth (Read only)
--
-- @field [parent=#CheckBox] #number indentWidth

---
-- Field traversalMode
--
-- @field [parent=#CheckBox] TraversalMode#TraversalMode traversalMode

---
-- Field elementEventSender
--
-- @field [parent=#CheckBox] #boolean elementEventSender

---
-- Function SetTemporary
--
-- @function [parent=#CheckBox] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#CheckBox] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#CheckBox] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#CheckBox] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#CheckBox] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#CheckBox] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#CheckBox] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#CheckBox] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#CheckBox] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#CheckBox] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#CheckBox] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#CheckBox] #string category


return nil
