---
-- Module CheckBox
-- Extends BorderImage
--
-- @module CheckBox

---
-- Function CheckBox
--
-- @function [parent=#CheckBox] CheckBox

---
-- Function new
--
-- @function [parent=#CheckBox] new
-- @return CheckBox#CheckBox

---
-- Function delete
--
-- @function [parent=#CheckBox] delete

---
-- Function SetChecked
--
-- @function [parent=#CheckBox] SetChecked
-- @param #boolean enableenable

---
-- Function SetCheckedOffset
--
-- @function [parent=#CheckBox] SetCheckedOffset
-- @param IntVector2#IntVector2 rectrect

---
-- Function SetCheckedOffset
--
-- @function [parent=#CheckBox] SetCheckedOffset
-- @param #number xx
-- @param #number yy

---
-- Function IsChecked
--
-- @function [parent=#CheckBox] IsChecked
-- @return #boolean

---
-- Function GetCheckedOffset
--
-- @function [parent=#CheckBox] GetCheckedOffset
-- @return const IntVector2#const IntVector2

---
-- Field checked
--
-- @field [parent=#CheckBox] #boolean checked

---
-- Field checkedOffset
--
-- @field [parent=#CheckBox] IntVector2#IntVector2 checkedOffset


return nil
