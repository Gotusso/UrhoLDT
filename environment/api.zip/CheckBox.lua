---
-- Module CheckBox
-- extends BorderImage
--
-- @module CheckBox

---
-- Function CheckBox
--
-- @function [parent=#CheckBox] CheckBox

---
-- Function new
--
-- @function [parent=#CheckBox] new
-- @return CheckBox#CheckBox

---
-- Function delete
--
-- @function [parent=#CheckBox] delete

---
-- Function SetChecked
--
-- @function [parent=#CheckBox] SetChecked
-- @param #boolean enableenable

---
-- Function SetCheckedOffset
--
-- @function [parent=#CheckBox] SetCheckedOffset
-- @param IntVector2#IntVector2 rectrect

---
-- Function SetCheckedOffset
--
-- @function [parent=#CheckBox] SetCheckedOffset
-- @param #number xx
-- @param #number yy

---
-- Function IsChecked
--
-- @function [parent=#CheckBox] IsChecked
-- @return #boolean

---
-- Function GetCheckedOffset
--
-- @function [parent=#CheckBox] GetCheckedOffset
-- @return const IntVector2#const IntVector2

---
-- Field checked
--
-- @field [parent=#CheckBox] #boolean checked

---
-- Field checkedOffset
--
-- @field [parent=#CheckBox] IntVector2#IntVector2 checkedOffset

---
-- Function BorderImage
--
-- @function [parent=#CheckBox] BorderImage

---
-- Function new
--
-- @function [parent=#CheckBox] new
-- @return BorderImage#BorderImage

---
-- Function delete
--
-- @function [parent=#CheckBox] delete

---
-- Function SetTexture
--
-- @function [parent=#CheckBox] SetTexture
-- @param Texture#Texture texturetexture

---
-- Function SetImageRect
--
-- @function [parent=#CheckBox] SetImageRect
-- @param IntRect#IntRect rectrect

---
-- Function SetFullImageRect
--
-- @function [parent=#CheckBox] SetFullImageRect

---
-- Function SetBorder
--
-- @function [parent=#CheckBox] SetBorder
-- @param IntRect#IntRect rectrect

---
-- Function SetHoverOffset
--
-- @function [parent=#CheckBox] SetHoverOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetHoverOffset
--
-- @function [parent=#CheckBox] SetHoverOffset
-- @param #number xx
-- @param #number yy

---
-- Function SetBlendMode
--
-- @function [parent=#CheckBox] SetBlendMode
-- @param BlendMode#BlendMode modemode

---
-- Function SetTiled
--
-- @function [parent=#CheckBox] SetTiled
-- @param #boolean enableenable

---
-- Function GetTexture
--
-- @function [parent=#CheckBox] GetTexture
-- @return Texture#Texture

---
-- Function GetImageRect
--
-- @function [parent=#CheckBox] GetImageRect
-- @return const IntRect#const IntRect

---
-- Function GetBorder
--
-- @function [parent=#CheckBox] GetBorder
-- @return const IntRect#const IntRect

---
-- Function GetHoverOffset
--
-- @function [parent=#CheckBox] GetHoverOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetBlendMode
--
-- @function [parent=#CheckBox] GetBlendMode
-- @return BlendMode#BlendMode

---
-- Function IsTiled
--
-- @function [parent=#CheckBox] IsTiled
-- @return #boolean

---
-- Field texture
--
-- @field [parent=#CheckBox] Texture#Texture texture

---
-- Field imageRect
--
-- @field [parent=#CheckBox] IntRect#IntRect imageRect

---
-- Field border
--
-- @field [parent=#CheckBox] IntRect#IntRect border

---
-- Field hoverOffset
--
-- @field [parent=#CheckBox] IntVector2#IntVector2 hoverOffset

---
-- Field blendMode
--
-- @field [parent=#CheckBox] BlendMode#BlendMode blendMode

---
-- Field tiled
--
-- @field [parent=#CheckBox] #boolean tiled

---
-- Function UIElement
--
-- @function [parent=#CheckBox] UIElement

---
-- Function new
--
-- @function [parent=#CheckBox] new
-- @return UIElement#UIElement

---
-- Function delete
--
-- @function [parent=#CheckBox] delete

---
-- Function GetScreenPosition
--
-- @function [parent=#CheckBox] GetScreenPosition
-- @return const IntVector2#const IntVector2

---
-- Function LoadXML
--
-- @function [parent=#CheckBox] LoadXML
-- @param Deserializer#Deserializer sourcesource
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#CheckBox] SaveXML
-- @param Serializer#Serializer destdest
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#CheckBox] LoadXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#CheckBox] SaveXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function FilterAttributes
--
-- @function [parent=#CheckBox] FilterAttributes
-- @param XMLElement#XMLElement destdest
-- @return #boolean

---
-- Function SetName
--
-- @function [parent=#CheckBox] SetName
-- @param #string namename

---
-- Function SetPosition
--
-- @function [parent=#CheckBox] SetPosition
-- @param IntVector2#IntVector2 positionposition

---
-- Function SetPosition
--
-- @function [parent=#CheckBox] SetPosition
-- @param #number xx
-- @param #number yy

---
-- Function SetSize
--
-- @function [parent=#CheckBox] SetSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function SetSize
--
-- @function [parent=#CheckBox] SetSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetWidth
--
-- @function [parent=#CheckBox] SetWidth
-- @param #number widthwidth

---
-- Function SetHeight
--
-- @function [parent=#CheckBox] SetHeight
-- @param #number heightheight

---
-- Function SetMinSize
--
-- @function [parent=#CheckBox] SetMinSize
-- @param IntVector2#IntVector2 minSizeminSize

---
-- Function SetMinSize
--
-- @function [parent=#CheckBox] SetMinSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetMinWidth
--
-- @function [parent=#CheckBox] SetMinWidth
-- @param #number widthwidth

---
-- Function SetMinHeight
--
-- @function [parent=#CheckBox] SetMinHeight
-- @param #number heightheight

---
-- Function SetMaxSize
--
-- @function [parent=#CheckBox] SetMaxSize
-- @param IntVector2#IntVector2 maxSizemaxSize

---
-- Function SetMaxSize
--
-- @function [parent=#CheckBox] SetMaxSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetMaxWidth
--
-- @function [parent=#CheckBox] SetMaxWidth
-- @param #number widthwidth

---
-- Function SetMaxHeight
--
-- @function [parent=#CheckBox] SetMaxHeight
-- @param #number heightheight

---
-- Function SetFixedSize
--
-- @function [parent=#CheckBox] SetFixedSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function SetFixedSize
--
-- @function [parent=#CheckBox] SetFixedSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetFixedWidth
--
-- @function [parent=#CheckBox] SetFixedWidth
-- @param #number widthwidth

---
-- Function SetFixedHeight
--
-- @function [parent=#CheckBox] SetFixedHeight
-- @param #number heightheight

---
-- Function SetAlignment
--
-- @function [parent=#CheckBox] SetAlignment
-- @param HorizontalAlignment#HorizontalAlignment hAlignhAlign
-- @param VerticalAlignment#VerticalAlignment vAlignvAlign

---
-- Function SetHorizontalAlignment
--
-- @function [parent=#CheckBox] SetHorizontalAlignment
-- @param HorizontalAlignment#HorizontalAlignment alignalign

---
-- Function SetVerticalAlignment
--
-- @function [parent=#CheckBox] SetVerticalAlignment
-- @param VerticalAlignment#VerticalAlignment alignalign

---
-- Function SetClipBorder
--
-- @function [parent=#CheckBox] SetClipBorder
-- @param IntRect#IntRect rectrect

---
-- Function SetColor
--
-- @function [parent=#CheckBox] SetColor
-- @param Color#Color colorcolor

---
-- Function SetColor
--
-- @function [parent=#CheckBox] SetColor
-- @param Corner#Corner cornercorner
-- @param Color#Color colorcolor

---
-- Function SetPriority
--
-- @function [parent=#CheckBox] SetPriority
-- @param #number prioritypriority

---
-- Function SetOpacity
--
-- @function [parent=#CheckBox] SetOpacity
-- @param #number opacityopacity

---
-- Function SetBringToFront
--
-- @function [parent=#CheckBox] SetBringToFront
-- @param #boolean enableenable

---
-- Function SetBringToBack
--
-- @function [parent=#CheckBox] SetBringToBack
-- @param #boolean enableenable

---
-- Function SetClipChildren
--
-- @function [parent=#CheckBox] SetClipChildren
-- @param #boolean enableenable

---
-- Function SetSortChildren
--
-- @function [parent=#CheckBox] SetSortChildren
-- @param #boolean enableenable

---
-- Function SetUseDerivedOpacity
--
-- @function [parent=#CheckBox] SetUseDerivedOpacity
-- @param #boolean enableenable

---
-- Function SetEnabled
--
-- @function [parent=#CheckBox] SetEnabled
-- @param #boolean enableenable

---
-- Function SetEditable
--
-- @function [parent=#CheckBox] SetEditable
-- @param #boolean enableenable

---
-- Function SetFocus
--
-- @function [parent=#CheckBox] SetFocus
-- @param #boolean enableenable

---
-- Function SetSelected
--
-- @function [parent=#CheckBox] SetSelected
-- @param #boolean enableenable

---
-- Function SetVisible
--
-- @function [parent=#CheckBox] SetVisible
-- @param #boolean enableenable

---
-- Function SetFocusMode
--
-- @function [parent=#CheckBox] SetFocusMode
-- @param FocusMode#FocusMode modemode

---
-- Function SetDragDropMode
--
-- @function [parent=#CheckBox] SetDragDropMode
-- @param #number modemode

---
-- Function SetStyle
--
-- @function [parent=#CheckBox] SetStyle
-- @param #string styleNamestyleName
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetStyle
--
-- @function [parent=#CheckBox] SetStyle
-- @param XMLElement#XMLElement elementelement
-- @return #boolean

---
-- Function SetStyleAuto
--
-- @function [parent=#CheckBox] SetStyleAuto
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetDefaultStyle
--
-- @function [parent=#CheckBox] SetDefaultStyle
-- @param XMLFile#XMLFile stylestyle

---
-- Function SetLayout
--
-- @function [parent=#CheckBox] SetLayout
-- @param LayoutMode#LayoutMode modemode
-- @param #number spacingspacing

---
-- Function SetLayout
--
-- @function [parent=#CheckBox] SetLayout
-- @param LayoutMode#LayoutMode modemode
-- @param #number spacingspacing
-- @param IntRect#IntRect borderborder

---
-- Function SetLayoutMode
--
-- @function [parent=#CheckBox] SetLayoutMode
-- @param LayoutMode#LayoutMode modemode

---
-- Function SetLayoutSpacing
--
-- @function [parent=#CheckBox] SetLayoutSpacing
-- @param #number spacingspacing

---
-- Function SetLayoutBorder
--
-- @function [parent=#CheckBox] SetLayoutBorder
-- @param IntRect#IntRect borderborder

---
-- Function SetIndent
--
-- @function [parent=#CheckBox] SetIndent
-- @param #number indentindent

---
-- Function SetIndentSpacing
--
-- @function [parent=#CheckBox] SetIndentSpacing
-- @param #number indentSpacingindentSpacing

---
-- Function UpdateLayout
--
-- @function [parent=#CheckBox] UpdateLayout

---
-- Function DisableLayoutUpdate
--
-- @function [parent=#CheckBox] DisableLayoutUpdate

---
-- Function EnableLayoutUpdate
--
-- @function [parent=#CheckBox] EnableLayoutUpdate

---
-- Function BringToFront
--
-- @function [parent=#CheckBox] BringToFront

---
-- Function CreateChild
--
-- @function [parent=#CheckBox] CreateChild
-- @param #string typetype
-- @param #string namename
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function AddChild
--
-- @function [parent=#CheckBox] AddChild
-- @param UIElement#UIElement elementelement

---
-- Function InsertChild
--
-- @function [parent=#CheckBox] InsertChild
-- @param #number indexindex
-- @param UIElement#UIElement elementelement

---
-- Function RemoveChild
--
-- @function [parent=#CheckBox] RemoveChild
-- @param UIElement#UIElement elementelement
-- @param #number indexindex

---
-- Function RemoveChildAtIndex
--
-- @function [parent=#CheckBox] RemoveChildAtIndex
-- @param #number indexindex

---
-- Function RemoveAllChildren
--
-- @function [parent=#CheckBox] RemoveAllChildren

---
-- Function Remove
--
-- @function [parent=#CheckBox] Remove

---
-- Function FindChild
--
-- @function [parent=#CheckBox] FindChild
-- @param UIElement#UIElement elementelement
-- @return #number

---
-- Function SetParent
--
-- @function [parent=#CheckBox] SetParent
-- @param UIElement#UIElement parentparent
-- @param #number indexindex

---
-- Function SetVar
--
-- @function [parent=#CheckBox] SetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @param Variant#Variant valuevalue

---
-- Function SetInternal
--
-- @function [parent=#CheckBox] SetInternal
-- @param #boolean enableenable

---
-- Function SetTraversalMode
--
-- @function [parent=#CheckBox] SetTraversalMode
-- @param TraversalMode#TraversalMode traversalModetraversalMode

---
-- Function SetElementEventSender
--
-- @function [parent=#CheckBox] SetElementEventSender
-- @param #boolean flagflag

---
-- Function GetName
--
-- @function [parent=#CheckBox] GetName
-- @return const String#const String

---
-- Function GetPosition
--
-- @function [parent=#CheckBox] GetPosition
-- @return const IntVector2#const IntVector2

---
-- Function GetSize
--
-- @function [parent=#CheckBox] GetSize
-- @return const IntVector2#const IntVector2

---
-- Function GetWidth
--
-- @function [parent=#CheckBox] GetWidth
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#CheckBox] GetHeight
-- @return #number

---
-- Function GetMinSize
--
-- @function [parent=#CheckBox] GetMinSize
-- @return const IntVector2#const IntVector2

---
-- Function GetMinWidth
--
-- @function [parent=#CheckBox] GetMinWidth
-- @return #number

---
-- Function GetMinHeight
--
-- @function [parent=#CheckBox] GetMinHeight
-- @return #number

---
-- Function GetMaxSize
--
-- @function [parent=#CheckBox] GetMaxSize
-- @return const IntVector2#const IntVector2

---
-- Function GetMaxWidth
--
-- @function [parent=#CheckBox] GetMaxWidth
-- @return #number

---
-- Function GetMaxHeight
--
-- @function [parent=#CheckBox] GetMaxHeight
-- @return #number

---
-- Function IsFixedSize
--
-- @function [parent=#CheckBox] IsFixedSize
-- @return #boolean

---
-- Function IsFixedWidth
--
-- @function [parent=#CheckBox] IsFixedWidth
-- @return #boolean

---
-- Function IsFixedHeight
--
-- @function [parent=#CheckBox] IsFixedHeight
-- @return #boolean

---
-- Function GetChildOffset
--
-- @function [parent=#CheckBox] GetChildOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetHorizontalAlignment
--
-- @function [parent=#CheckBox] GetHorizontalAlignment
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetVerticalAlignment
--
-- @function [parent=#CheckBox] GetVerticalAlignment
-- @return VerticalAlignment#VerticalAlignment

---
-- Function GetClipBorder
--
-- @function [parent=#CheckBox] GetClipBorder
-- @return const IntRect#const IntRect

---
-- Function GetColor
--
-- @function [parent=#CheckBox] GetColor
-- @param Corner#Corner cornercorner
-- @return const Color#const Color

---
-- Function GetPriority
--
-- @function [parent=#CheckBox] GetPriority
-- @return #number

---
-- Function GetOpacity
--
-- @function [parent=#CheckBox] GetOpacity
-- @return #number

---
-- Function GetDerivedOpacity
--
-- @function [parent=#CheckBox] GetDerivedOpacity
-- @return #number

---
-- Function GetBringToFront
--
-- @function [parent=#CheckBox] GetBringToFront
-- @return #boolean

---
-- Function GetBringToBack
--
-- @function [parent=#CheckBox] GetBringToBack
-- @return #boolean

---
-- Function GetClipChildren
--
-- @function [parent=#CheckBox] GetClipChildren
-- @return #boolean

---
-- Function GetSortChildren
--
-- @function [parent=#CheckBox] GetSortChildren
-- @return #boolean

---
-- Function GetUseDerivedOpacity
--
-- @function [parent=#CheckBox] GetUseDerivedOpacity
-- @return #boolean

---
-- Function HasFocus
--
-- @function [parent=#CheckBox] HasFocus
-- @return #boolean

---
-- Function IsEnabled
--
-- @function [parent=#CheckBox] IsEnabled
-- @return #boolean

---
-- Function IsEditable
--
-- @function [parent=#CheckBox] IsEditable
-- @return #boolean

---
-- Function IsSelected
--
-- @function [parent=#CheckBox] IsSelected
-- @return #boolean

---
-- Function IsVisible
--
-- @function [parent=#CheckBox] IsVisible
-- @return #boolean

---
-- Function IsHovering
--
-- @function [parent=#CheckBox] IsHovering
-- @return #boolean

---
-- Function IsInternal
--
-- @function [parent=#CheckBox] IsInternal
-- @return #boolean

---
-- Function HasColorGradient
--
-- @function [parent=#CheckBox] HasColorGradient
-- @return #boolean

---
-- Function GetFocusMode
--
-- @function [parent=#CheckBox] GetFocusMode
-- @return FocusMode#FocusMode

---
-- Function GetDragDropMode
--
-- @function [parent=#CheckBox] GetDragDropMode
-- @return #number

---
-- Function GetAppliedStyle
--
-- @function [parent=#CheckBox] GetAppliedStyle
-- @return const String#const String

---
-- Function GetDefaultStyle
--
-- @function [parent=#CheckBox] GetDefaultStyle
-- @param #boolean recursiveUprecursiveUp
-- @return XMLFile#XMLFile

---
-- Function GetLayoutMode
--
-- @function [parent=#CheckBox] GetLayoutMode
-- @return LayoutMode#LayoutMode

---
-- Function GetLayoutSpacing
--
-- @function [parent=#CheckBox] GetLayoutSpacing
-- @return #number

---
-- Function GetLayoutBorder
--
-- @function [parent=#CheckBox] GetLayoutBorder
-- @return const IntRect#const IntRect

---
-- Function GetNumChildren
--
-- @function [parent=#CheckBox] GetNumChildren
-- @param #boolean recursiverecursive
-- @return #number

---
-- Function GetChild
--
-- @function [parent=#CheckBox] GetChild
-- @param #string namename
-- @param #boolean recursiverecursive
-- @return UIElement#UIElement

---
-- Function GetChild
--
-- @function [parent=#CheckBox] GetChild
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function GetParent
--
-- @function [parent=#CheckBox] GetParent
-- @return UIElement#UIElement

---
-- Function GetRoot
--
-- @function [parent=#CheckBox] GetRoot
-- @return UIElement#UIElement

---
-- Function GetDerivedColor
--
-- @function [parent=#CheckBox] GetDerivedColor
-- @return const Color#const Color

---
-- Function GetVar
--
-- @function [parent=#CheckBox] GetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @return const Variant#const Variant

---
-- Function GetVars
--
-- @function [parent=#CheckBox] GetVars
-- @return const VariantMap#const VariantMap

---
-- Function ScreenToElement
--
-- @function [parent=#CheckBox] ScreenToElement
-- @param IntVector2#IntVector2 screenPositionscreenPosition
-- @return IntVector2#IntVector2

---
-- Function ElementToScreen
--
-- @function [parent=#CheckBox] ElementToScreen
-- @param IntVector2#IntVector2 positionposition
-- @return IntVector2#IntVector2

---
-- Function IsInside
--
-- @function [parent=#CheckBox] IsInside
-- @param IntVector2#IntVector2 positionposition
-- @param #boolean isScreenisScreen
-- @return #boolean

---
-- Function IsInsideCombined
--
-- @function [parent=#CheckBox] IsInsideCombined
-- @param IntVector2#IntVector2 positionposition
-- @param #boolean isScreenisScreen
-- @return #boolean

---
-- Function GetCombinedScreenRect
--
-- @function [parent=#CheckBox] GetCombinedScreenRect
-- @return IntRect#IntRect

---
-- Function SortChildren
--
-- @function [parent=#CheckBox] SortChildren

---
-- Function GetLayoutMinSize
--
-- @function [parent=#CheckBox] GetLayoutMinSize
-- @return #number

---
-- Function GetIndent
--
-- @function [parent=#CheckBox] GetIndent
-- @return #number

---
-- Function GetIndentSpacing
--
-- @function [parent=#CheckBox] GetIndentSpacing
-- @return #number

---
-- Function GetIndentWidth
--
-- @function [parent=#CheckBox] GetIndentWidth
-- @return #number

---
-- Function SetChildOffset
--
-- @function [parent=#CheckBox] SetChildOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetHovering
--
-- @function [parent=#CheckBox] SetHovering
-- @param #boolean enableenable

---
-- Function GetColor
--
-- @function [parent=#CheckBox] GetColor
-- @return const Color#const Color

---
-- Function GetTraversalMode
--
-- @function [parent=#CheckBox] GetTraversalMode
-- @return TraversalMode#TraversalMode

---
-- Function IsElementEventSender
--
-- @function [parent=#CheckBox] IsElementEventSender
-- @return #boolean

---
-- Function GetElementEventSender
--
-- @function [parent=#CheckBox] GetElementEventSender
-- @return UIElement#UIElement

---
-- Field screenPosition (Read only)
--
-- @field [parent=#CheckBox] IntVector2#IntVector2 screenPosition

---
-- Field name
--
-- @field [parent=#CheckBox] #string name

---
-- Field position
--
-- @field [parent=#CheckBox] IntVector2#IntVector2 position

---
-- Field size
--
-- @field [parent=#CheckBox] IntVector2#IntVector2 size

---
-- Field width
--
-- @field [parent=#CheckBox] #number width

---
-- Field height
--
-- @field [parent=#CheckBox] #number height

---
-- Field minSize
--
-- @field [parent=#CheckBox] IntVector2#IntVector2 minSize

---
-- Field minWidth
--
-- @field [parent=#CheckBox] #number minWidth

---
-- Field minHeight
--
-- @field [parent=#CheckBox] #number minHeight

---
-- Field maxSize
--
-- @field [parent=#CheckBox] IntVector2#IntVector2 maxSize

---
-- Field maxWidth
--
-- @field [parent=#CheckBox] #number maxWidth

---
-- Field maxHeight
--
-- @field [parent=#CheckBox] #number maxHeight

---
-- Field fixedSize (Read only)
--
-- @field [parent=#CheckBox] #boolean fixedSize

---
-- Field fixedWidth (Read only)
--
-- @field [parent=#CheckBox] #boolean fixedWidth

---
-- Field fixedHeight (Read only)
--
-- @field [parent=#CheckBox] #boolean fixedHeight

---
-- Field childOffset
--
-- @field [parent=#CheckBox] IntVector2#IntVector2 childOffset

---
-- Field horizontalAlignment
--
-- @field [parent=#CheckBox] HorizontalAlignment#HorizontalAlignment horizontalAlignment

---
-- Field verticalAlignment
--
-- @field [parent=#CheckBox] VerticalAlignment#VerticalAlignment verticalAlignment

---
-- Field clipBorder
--
-- @field [parent=#CheckBox] IntRect#IntRect clipBorder

---
-- Field color
--
-- @field [parent=#CheckBox] Color#Color color

---
-- Field priority
--
-- @field [parent=#CheckBox] #number priority

---
-- Field opacity
--
-- @field [parent=#CheckBox] #number opacity

---
-- Field derivedOpacity (Read only)
--
-- @field [parent=#CheckBox] #number derivedOpacity

---
-- Field bringToFront
--
-- @field [parent=#CheckBox] #boolean bringToFront

---
-- Field bringToBack
--
-- @field [parent=#CheckBox] #boolean bringToBack

---
-- Field clipChildren
--
-- @field [parent=#CheckBox] #boolean clipChildren

---
-- Field sortChildren
--
-- @field [parent=#CheckBox] #boolean sortChildren

---
-- Field useDerivedOpacity
--
-- @field [parent=#CheckBox] #boolean useDerivedOpacity

---
-- Field focus
--
-- @field [parent=#CheckBox] #boolean focus

---
-- Field enabled
--
-- @field [parent=#CheckBox] #boolean enabled

---
-- Field editable
--
-- @field [parent=#CheckBox] #boolean editable

---
-- Field selected
--
-- @field [parent=#CheckBox] #boolean selected

---
-- Field visible
--
-- @field [parent=#CheckBox] #boolean visible

---
-- Field hovering
--
-- @field [parent=#CheckBox] #boolean hovering

---
-- Field internal
--
-- @field [parent=#CheckBox] #boolean internal

---
-- Field colorGradient (Read only)
--
-- @field [parent=#CheckBox] #boolean colorGradient

---
-- Field focusMode
--
-- @field [parent=#CheckBox] FocusMode#FocusMode focusMode

---
-- Field dragDropMode
--
-- @field [parent=#CheckBox] #number dragDropMode

---
-- Field style
--
-- @field [parent=#CheckBox] #string style

---
-- Field defaultStyle
--
-- @field [parent=#CheckBox] XMLFile#XMLFile defaultStyle

---
-- Field layoutMode
--
-- @field [parent=#CheckBox] LayoutMode#LayoutMode layoutMode

---
-- Field layoutSpacing
--
-- @field [parent=#CheckBox] #number layoutSpacing

---
-- Field layoutBorder
--
-- @field [parent=#CheckBox] IntRect#IntRect layoutBorder

---
-- Field numChildren (Read only)
--
-- @field [parent=#CheckBox] #number numChildren

---
-- Field parent
--
-- @field [parent=#CheckBox] UIElement#UIElement parent

---
-- Field root (Read only)
--
-- @field [parent=#CheckBox] UIElement#UIElement root

---
-- Field derivedColor (Read only)
--
-- @field [parent=#CheckBox] Color#Color derivedColor

---
-- Field combinedScreenRect (Read only)
--
-- @field [parent=#CheckBox] IntRect#IntRect combinedScreenRect

---
-- Field layoutMinSize (Read only)
--
-- @field [parent=#CheckBox] #number layoutMinSize

---
-- Field indent
--
-- @field [parent=#CheckBox] #number indent

---
-- Field indentSpacing
--
-- @field [parent=#CheckBox] #number indentSpacing

---
-- Field indentWidth (Read only)
--
-- @field [parent=#CheckBox] #number indentWidth

---
-- Field traversalMode
--
-- @field [parent=#CheckBox] TraversalMode#TraversalMode traversalMode

---
-- Field elementEventSender
--
-- @field [parent=#CheckBox] #boolean elementEventSender

---
-- Function SetTemporary
--
-- @function [parent=#CheckBox] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#CheckBox] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#CheckBox] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#CheckBox] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#CheckBox] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#CheckBox] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#CheckBox] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#CheckBox] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#CheckBox] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#CheckBox] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#CheckBox] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#CheckBox] #string category


return nil
