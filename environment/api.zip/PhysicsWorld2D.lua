---
-- Module PhysicsWorld2D
-- Module PhysicsWorld2D extends Component
-- Generated on 2014-05-31
--
-- @module PhysicsWorld2D

---
-- Function DrawDebugGeometry()
-- Add debug geometry to the debug renderer.
--
-- @function [parent=#PhysicsWorld2D] DrawDebugGeometry
-- @param self Self reference

---
-- Function SetDrawShape()
-- Set draw shape.
--
-- @function [parent=#PhysicsWorld2D] SetDrawShape
-- @param self Self reference
-- @param #boolean drawShape drawShape

---
-- Function SetDrawJoint()
-- Set draw joint.
--
-- @function [parent=#PhysicsWorld2D] SetDrawJoint
-- @param self Self reference
-- @param #boolean drawJoint drawJoint

---
-- Function SetDrawAabb()
-- Set draw aabb.
--
-- @function [parent=#PhysicsWorld2D] SetDrawAabb
-- @param self Self reference
-- @param #boolean drawAabb drawAabb

---
-- Function SetDrawPair()
-- Set draw pair.
--
-- @function [parent=#PhysicsWorld2D] SetDrawPair
-- @param self Self reference
-- @param #boolean drawPair drawPair

---
-- Function SetDrawCenterOfMass()
-- Set draw center of mass.
--
-- @function [parent=#PhysicsWorld2D] SetDrawCenterOfMass
-- @param self Self reference
-- @param #boolean drawCenterOfMass drawCenterOfMass

---
-- Function SetAllowSleeping()
-- Set allow sleeping.
--
-- @function [parent=#PhysicsWorld2D] SetAllowSleeping
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetWarmStarting()
-- Set warm starting.
--
-- @function [parent=#PhysicsWorld2D] SetWarmStarting
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetContinuousPhysics()
-- Set continuous physics.
--
-- @function [parent=#PhysicsWorld2D] SetContinuousPhysics
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetSubStepping()
-- Set sub stepping.
--
-- @function [parent=#PhysicsWorld2D] SetSubStepping
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetGravity()
-- Set gravity.
--
-- @function [parent=#PhysicsWorld2D] SetGravity
-- @param self Self reference
-- @param Vector2#Vector2 gravity gravity

---
-- Function SetAutoClearForces()
-- Set auto clear forces.
--
-- @function [parent=#PhysicsWorld2D] SetAutoClearForces
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetVelocityIterations()
-- Set velocity iterations.
--
-- @function [parent=#PhysicsWorld2D] SetVelocityIterations
-- @param self Self reference
-- @param #number velocityIterations velocityIterations

---
-- Function SetPositionIterations()
-- Set position iterations.
--
-- @function [parent=#PhysicsWorld2D] SetPositionIterations
-- @param self Self reference
-- @param #number positionIterations positionIterations

---
-- Function Raycast()
--
-- @function [parent=#PhysicsWorld2D] Raycast
-- @param self Self reference
-- @param Vector2#Vector2 startPoint startPoint
-- @param Vector2#Vector2 endPoint endPoint
-- @param #number collisionMask collisionMask
-- @return const PODVector<PhysicsRaycastResult2D>#const PODVector<PhysicsRaycastResult2D>

---
-- Function RaycastSingle()
--
-- @function [parent=#PhysicsWorld2D] RaycastSingle
-- @param self Self reference
-- @param Vector2#Vector2 startPoint startPoint
-- @param Vector2#Vector2 endPoint endPoint
-- @param #number collisionMask collisionMask
-- @return PhysicsRaycastResult2D#PhysicsRaycastResult2D

---
-- Function GetRigidBody()
-- Return rigid body at point.
--
-- @function [parent=#PhysicsWorld2D] GetRigidBody
-- @param self Self reference
-- @param Vector2#Vector2 point point
-- @param #number collisionMask collisionMask
-- @return RigidBody2D#RigidBody2D

---
-- Function GetRigidBody()
-- Return rigid body at screen point, if camera is 0, it will use first camera in scene. when viewport size was not equal to window size it may have problem.
--
-- @function [parent=#PhysicsWorld2D] GetRigidBody
-- @param self Self reference
-- @param #number screenX screenX
-- @param #number screenY screenY
-- @param #number collisionMask collisionMask
-- @param Camera#Camera camera camera
-- @return RigidBody2D#RigidBody2D

---
-- Function GetRigidBodies()
--
-- @function [parent=#PhysicsWorld2D] GetRigidBodies
-- @param self Self reference
-- @param Rect#Rect aabb aabb
-- @param #number collisionMask collisionMask
-- @return const PODVector<RigidBody2D*>#const PODVector<RigidBody2D*>

---
-- Function GetDrawShape()
--
-- @function [parent=#PhysicsWorld2D] GetDrawShape
-- @param self Self reference
-- @return #boolean

---
-- Function GetDrawJoint()
--
-- @function [parent=#PhysicsWorld2D] GetDrawJoint
-- @param self Self reference
-- @return #boolean

---
-- Function GetDrawAabb()
--
-- @function [parent=#PhysicsWorld2D] GetDrawAabb
-- @param self Self reference
-- @return #boolean

---
-- Function GetDrawPair()
--
-- @function [parent=#PhysicsWorld2D] GetDrawPair
-- @param self Self reference
-- @return #boolean

---
-- Function GetDrawCenterOfMass()
--
-- @function [parent=#PhysicsWorld2D] GetDrawCenterOfMass
-- @param self Self reference
-- @return #boolean

---
-- Function GetAllowSleeping()
-- Return allow sleeping.
--
-- @function [parent=#PhysicsWorld2D] GetAllowSleeping
-- @param self Self reference
-- @return #boolean

---
-- Function GetWarmStarting()
-- Return warm starting.
--
-- @function [parent=#PhysicsWorld2D] GetWarmStarting
-- @param self Self reference
-- @return #boolean

---
-- Function GetContinuousPhysics()
-- Return continuous physics.
--
-- @function [parent=#PhysicsWorld2D] GetContinuousPhysics
-- @param self Self reference
-- @return #boolean

---
-- Function GetSubStepping()
-- Return sub stepping.
--
-- @function [parent=#PhysicsWorld2D] GetSubStepping
-- @param self Self reference
-- @return #boolean

---
-- Function GetAutoClearForces()
-- Return auto clear forces.
--
-- @function [parent=#PhysicsWorld2D] GetAutoClearForces
-- @param self Self reference
-- @return #boolean

---
-- Function GetGravity()
-- Return gravity.
--
-- @function [parent=#PhysicsWorld2D] GetGravity
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Function GetVelocityIterations()
-- Return velocity iterations.
--
-- @function [parent=#PhysicsWorld2D] GetVelocityIterations
-- @param self Self reference
-- @return #number

---
-- Function GetPositionIterations()
-- Return position iterations.
--
-- @function [parent=#PhysicsWorld2D] GetPositionIterations
-- @param self Self reference
-- @return #number

---
-- Field drawShape
--
-- @field [parent=#PhysicsWorld2D] #boolean drawShape

---
-- Field drawJoint
--
-- @field [parent=#PhysicsWorld2D] #boolean drawJoint

---
-- Field drawAabb
--
-- @field [parent=#PhysicsWorld2D] #boolean drawAabb

---
-- Field drawPair
--
-- @field [parent=#PhysicsWorld2D] #boolean drawPair

---
-- Field drawCenterOfMass
--
-- @field [parent=#PhysicsWorld2D] #boolean drawCenterOfMass

---
-- Field allowSleeping
--
-- @field [parent=#PhysicsWorld2D] #boolean allowSleeping

---
-- Field warmStarting
--
-- @field [parent=#PhysicsWorld2D] #boolean warmStarting

---
-- Field continuousPhysics
--
-- @field [parent=#PhysicsWorld2D] #boolean continuousPhysics

---
-- Field subStepping
--
-- @field [parent=#PhysicsWorld2D] #boolean subStepping

---
-- Field autoClearForces
--
-- @field [parent=#PhysicsWorld2D] #boolean autoClearForces

---
-- Field gravity
--
-- @field [parent=#PhysicsWorld2D] Vector2#Vector2 gravity

---
-- Field velocityIterations
--
-- @field [parent=#PhysicsWorld2D] #number velocityIterations

---
-- Field positionIterations
--
-- @field [parent=#PhysicsWorld2D] #number positionIterations


return nil
