---
-- Module ScrollBar
-- Module ScrollBar extends UIElement
-- Generated on 2014-05-31
--
-- @module ScrollBar

---
-- Function ScrollBar()
--
-- @function [parent=#ScrollBar] ScrollBar
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#ScrollBar] new
-- @param self Self reference
-- @return ScrollBar#ScrollBar

---
-- Function delete()
--
-- @function [parent=#ScrollBar] delete
-- @param self Self reference

---
-- Function SetOrientation()
-- Set orientation type.
--
-- @function [parent=#ScrollBar] SetOrientation
-- @param self Self reference
-- @param Orientation#Orientation orientation orientation

---
-- Function SetRange()
-- Set slider range maximum value (minimum value is always 0.)
--
-- @function [parent=#ScrollBar] SetRange
-- @param self Self reference
-- @param #number range range

---
-- Function SetValue()
-- Set slider current value.
--
-- @function [parent=#ScrollBar] SetValue
-- @param self Self reference
-- @param #number value value

---
-- Function ChangeValue()
-- Change slider current value by a delta.
--
-- @function [parent=#ScrollBar] ChangeValue
-- @param self Self reference
-- @param #number delta delta

---
-- Function SetScrollStep()
-- Set button scroll step.
--
-- @function [parent=#ScrollBar] SetScrollStep
-- @param self Self reference
-- @param #number step step

---
-- Function SetStepFactor()
-- Set button step factor, can be used to adjust the step for constant pixel size.
--
-- @function [parent=#ScrollBar] SetStepFactor
-- @param self Self reference
-- @param #number factor factor

---
-- Function StepBack()
-- Scroll back one step.
--
-- @function [parent=#ScrollBar] StepBack
-- @param self Self reference

---
-- Function StepForward()
-- Scroll forward one step.
--
-- @function [parent=#ScrollBar] StepForward
-- @param self Self reference

---
-- Function GetOrientation()
-- Return scrollbar orientation.
--
-- @function [parent=#ScrollBar] GetOrientation
-- @param self Self reference
-- @return Orientation#Orientation

---
-- Function GetRange()
-- Return slider range.
--
-- @function [parent=#ScrollBar] GetRange
-- @param self Self reference
-- @return #number

---
-- Function GetValue()
-- Return slider current value.
--
-- @function [parent=#ScrollBar] GetValue
-- @param self Self reference
-- @return #number

---
-- Function GetScrollStep()
-- Return button scroll step.
--
-- @function [parent=#ScrollBar] GetScrollStep
-- @param self Self reference
-- @return #number

---
-- Function GetStepFactor()
-- Return button step factor.
--
-- @function [parent=#ScrollBar] GetStepFactor
-- @param self Self reference
-- @return #number

---
-- Function GetEffectiveScrollStep()
-- Return scroll step multiplied by factor.
--
-- @function [parent=#ScrollBar] GetEffectiveScrollStep
-- @param self Self reference
-- @return #number

---
-- Function GetBackButton()
-- Return back button element.
--
-- @function [parent=#ScrollBar] GetBackButton
-- @param self Self reference
-- @return Button#Button

---
-- Function GetForwardButton()
-- Return forward button element.
--
-- @function [parent=#ScrollBar] GetForwardButton
-- @param self Self reference
-- @return Button#Button

---
-- Function GetSlider()
-- Return slider element.
--
-- @function [parent=#ScrollBar] GetSlider
-- @param self Self reference
-- @return Slider#Slider

---
-- Field orientation
--
-- @field [parent=#ScrollBar] Orientation#Orientation orientation

---
-- Field range
--
-- @field [parent=#ScrollBar] #number range

---
-- Field value
--
-- @field [parent=#ScrollBar] #number value

---
-- Field scrollStep
--
-- @field [parent=#ScrollBar] #number scrollStep

---
-- Field stepFactor
--
-- @field [parent=#ScrollBar] #number stepFactor

---
-- Field effectiveScrollStep (Read only)
--
-- @field [parent=#ScrollBar] #number effectiveScrollStep

---
-- Field backButton (Read only)
--
-- @field [parent=#ScrollBar] Button#Button backButton

---
-- Field forwardButton (Read only)
--
-- @field [parent=#ScrollBar] Button#Button forwardButton

---
-- Field slider (Read only)
--
-- @field [parent=#ScrollBar] Slider#Slider slider


return nil
