---
-- Module ScrollBar
-- extends UIElement
--
-- @module ScrollBar

---
-- Function ScrollBar
--
-- @function [parent=#ScrollBar] ScrollBar

---
-- Function new
--
-- @function [parent=#ScrollBar] new
-- @return ScrollBar#ScrollBar

---
-- Function delete
--
-- @function [parent=#ScrollBar] delete

---
-- Function SetOrientation
--
-- @function [parent=#ScrollBar] SetOrientation
-- @param Orientation#Orientation orientationorientation

---
-- Function SetRange
--
-- @function [parent=#ScrollBar] SetRange
-- @param #number rangerange

---
-- Function SetValue
--
-- @function [parent=#ScrollBar] SetValue
-- @param #number valuevalue

---
-- Function ChangeValue
--
-- @function [parent=#ScrollBar] ChangeValue
-- @param #number deltadelta

---
-- Function SetScrollStep
--
-- @function [parent=#ScrollBar] SetScrollStep
-- @param #number stepstep

---
-- Function SetStepFactor
--
-- @function [parent=#ScrollBar] SetStepFactor
-- @param #number factorfactor

---
-- Function StepBack
--
-- @function [parent=#ScrollBar] StepBack

---
-- Function StepForward
--
-- @function [parent=#ScrollBar] StepForward

---
-- Function GetOrientation
--
-- @function [parent=#ScrollBar] GetOrientation
-- @return Orientation#Orientation

---
-- Function GetRange
--
-- @function [parent=#ScrollBar] GetRange
-- @return #number

---
-- Function GetValue
--
-- @function [parent=#ScrollBar] GetValue
-- @return #number

---
-- Function GetScrollStep
--
-- @function [parent=#ScrollBar] GetScrollStep
-- @return #number

---
-- Function GetStepFactor
--
-- @function [parent=#ScrollBar] GetStepFactor
-- @return #number

---
-- Function GetEffectiveScrollStep
--
-- @function [parent=#ScrollBar] GetEffectiveScrollStep
-- @return #number

---
-- Function GetBackButton
--
-- @function [parent=#ScrollBar] GetBackButton
-- @return Button#Button

---
-- Function GetForwardButton
--
-- @function [parent=#ScrollBar] GetForwardButton
-- @return Button#Button

---
-- Function GetSlider
--
-- @function [parent=#ScrollBar] GetSlider
-- @return Slider#Slider

---
-- Field orientation
--
-- @field [parent=#ScrollBar] Orientation#Orientation orientation

---
-- Field range
--
-- @field [parent=#ScrollBar] #number range

---
-- Field value
--
-- @field [parent=#ScrollBar] #number value

---
-- Field scrollStep
--
-- @field [parent=#ScrollBar] #number scrollStep

---
-- Field stepFactor
--
-- @field [parent=#ScrollBar] #number stepFactor

---
-- Field effectiveScrollStep (Read only)
--
-- @field [parent=#ScrollBar] #number effectiveScrollStep

---
-- Field backButton (Read only)
--
-- @field [parent=#ScrollBar] Button#Button backButton

---
-- Field forwardButton (Read only)
--
-- @field [parent=#ScrollBar] Button#Button forwardButton

---
-- Field slider (Read only)
--
-- @field [parent=#ScrollBar] Slider#Slider slider

---
-- Function UIElement
--
-- @function [parent=#ScrollBar] UIElement

---
-- Function new
--
-- @function [parent=#ScrollBar] new
-- @return UIElement#UIElement

---
-- Function delete
--
-- @function [parent=#ScrollBar] delete

---
-- Function GetScreenPosition
--
-- @function [parent=#ScrollBar] GetScreenPosition
-- @return const IntVector2#const IntVector2

---
-- Function LoadXML
--
-- @function [parent=#ScrollBar] LoadXML
-- @param Deserializer#Deserializer sourcesource
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#ScrollBar] SaveXML
-- @param Serializer#Serializer destdest
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#ScrollBar] LoadXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#ScrollBar] SaveXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function FilterAttributes
--
-- @function [parent=#ScrollBar] FilterAttributes
-- @param XMLElement#XMLElement destdest
-- @return #boolean

---
-- Function SetName
--
-- @function [parent=#ScrollBar] SetName
-- @param #string namename

---
-- Function SetPosition
--
-- @function [parent=#ScrollBar] SetPosition
-- @param IntVector2#IntVector2 positionposition

---
-- Function SetPosition
--
-- @function [parent=#ScrollBar] SetPosition
-- @param #number xx
-- @param #number yy

---
-- Function SetSize
--
-- @function [parent=#ScrollBar] SetSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function SetSize
--
-- @function [parent=#ScrollBar] SetSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetWidth
--
-- @function [parent=#ScrollBar] SetWidth
-- @param #number widthwidth

---
-- Function SetHeight
--
-- @function [parent=#ScrollBar] SetHeight
-- @param #number heightheight

---
-- Function SetMinSize
--
-- @function [parent=#ScrollBar] SetMinSize
-- @param IntVector2#IntVector2 minSizeminSize

---
-- Function SetMinSize
--
-- @function [parent=#ScrollBar] SetMinSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetMinWidth
--
-- @function [parent=#ScrollBar] SetMinWidth
-- @param #number widthwidth

---
-- Function SetMinHeight
--
-- @function [parent=#ScrollBar] SetMinHeight
-- @param #number heightheight

---
-- Function SetMaxSize
--
-- @function [parent=#ScrollBar] SetMaxSize
-- @param IntVector2#IntVector2 maxSizemaxSize

---
-- Function SetMaxSize
--
-- @function [parent=#ScrollBar] SetMaxSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetMaxWidth
--
-- @function [parent=#ScrollBar] SetMaxWidth
-- @param #number widthwidth

---
-- Function SetMaxHeight
--
-- @function [parent=#ScrollBar] SetMaxHeight
-- @param #number heightheight

---
-- Function SetFixedSize
--
-- @function [parent=#ScrollBar] SetFixedSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function SetFixedSize
--
-- @function [parent=#ScrollBar] SetFixedSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetFixedWidth
--
-- @function [parent=#ScrollBar] SetFixedWidth
-- @param #number widthwidth

---
-- Function SetFixedHeight
--
-- @function [parent=#ScrollBar] SetFixedHeight
-- @param #number heightheight

---
-- Function SetAlignment
--
-- @function [parent=#ScrollBar] SetAlignment
-- @param HorizontalAlignment#HorizontalAlignment hAlignhAlign
-- @param VerticalAlignment#VerticalAlignment vAlignvAlign

---
-- Function SetHorizontalAlignment
--
-- @function [parent=#ScrollBar] SetHorizontalAlignment
-- @param HorizontalAlignment#HorizontalAlignment alignalign

---
-- Function SetVerticalAlignment
--
-- @function [parent=#ScrollBar] SetVerticalAlignment
-- @param VerticalAlignment#VerticalAlignment alignalign

---
-- Function SetClipBorder
--
-- @function [parent=#ScrollBar] SetClipBorder
-- @param IntRect#IntRect rectrect

---
-- Function SetColor
--
-- @function [parent=#ScrollBar] SetColor
-- @param Color#Color colorcolor

---
-- Function SetColor
--
-- @function [parent=#ScrollBar] SetColor
-- @param Corner#Corner cornercorner
-- @param Color#Color colorcolor

---
-- Function SetPriority
--
-- @function [parent=#ScrollBar] SetPriority
-- @param #number prioritypriority

---
-- Function SetOpacity
--
-- @function [parent=#ScrollBar] SetOpacity
-- @param #number opacityopacity

---
-- Function SetBringToFront
--
-- @function [parent=#ScrollBar] SetBringToFront
-- @param #boolean enableenable

---
-- Function SetBringToBack
--
-- @function [parent=#ScrollBar] SetBringToBack
-- @param #boolean enableenable

---
-- Function SetClipChildren
--
-- @function [parent=#ScrollBar] SetClipChildren
-- @param #boolean enableenable

---
-- Function SetSortChildren
--
-- @function [parent=#ScrollBar] SetSortChildren
-- @param #boolean enableenable

---
-- Function SetUseDerivedOpacity
--
-- @function [parent=#ScrollBar] SetUseDerivedOpacity
-- @param #boolean enableenable

---
-- Function SetEnabled
--
-- @function [parent=#ScrollBar] SetEnabled
-- @param #boolean enableenable

---
-- Function SetEditable
--
-- @function [parent=#ScrollBar] SetEditable
-- @param #boolean enableenable

---
-- Function SetFocus
--
-- @function [parent=#ScrollBar] SetFocus
-- @param #boolean enableenable

---
-- Function SetSelected
--
-- @function [parent=#ScrollBar] SetSelected
-- @param #boolean enableenable

---
-- Function SetVisible
--
-- @function [parent=#ScrollBar] SetVisible
-- @param #boolean enableenable

---
-- Function SetFocusMode
--
-- @function [parent=#ScrollBar] SetFocusMode
-- @param FocusMode#FocusMode modemode

---
-- Function SetDragDropMode
--
-- @function [parent=#ScrollBar] SetDragDropMode
-- @param #number modemode

---
-- Function SetStyle
--
-- @function [parent=#ScrollBar] SetStyle
-- @param #string styleNamestyleName
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetStyle
--
-- @function [parent=#ScrollBar] SetStyle
-- @param XMLElement#XMLElement elementelement
-- @return #boolean

---
-- Function SetStyleAuto
--
-- @function [parent=#ScrollBar] SetStyleAuto
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetDefaultStyle
--
-- @function [parent=#ScrollBar] SetDefaultStyle
-- @param XMLFile#XMLFile stylestyle

---
-- Function SetLayout
--
-- @function [parent=#ScrollBar] SetLayout
-- @param LayoutMode#LayoutMode modemode
-- @param #number spacingspacing

---
-- Function SetLayout
--
-- @function [parent=#ScrollBar] SetLayout
-- @param LayoutMode#LayoutMode modemode
-- @param #number spacingspacing
-- @param IntRect#IntRect borderborder

---
-- Function SetLayoutMode
--
-- @function [parent=#ScrollBar] SetLayoutMode
-- @param LayoutMode#LayoutMode modemode

---
-- Function SetLayoutSpacing
--
-- @function [parent=#ScrollBar] SetLayoutSpacing
-- @param #number spacingspacing

---
-- Function SetLayoutBorder
--
-- @function [parent=#ScrollBar] SetLayoutBorder
-- @param IntRect#IntRect borderborder

---
-- Function SetIndent
--
-- @function [parent=#ScrollBar] SetIndent
-- @param #number indentindent

---
-- Function SetIndentSpacing
--
-- @function [parent=#ScrollBar] SetIndentSpacing
-- @param #number indentSpacingindentSpacing

---
-- Function UpdateLayout
--
-- @function [parent=#ScrollBar] UpdateLayout

---
-- Function DisableLayoutUpdate
--
-- @function [parent=#ScrollBar] DisableLayoutUpdate

---
-- Function EnableLayoutUpdate
--
-- @function [parent=#ScrollBar] EnableLayoutUpdate

---
-- Function BringToFront
--
-- @function [parent=#ScrollBar] BringToFront

---
-- Function CreateChild
--
-- @function [parent=#ScrollBar] CreateChild
-- @param #string typetype
-- @param #string namename
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function AddChild
--
-- @function [parent=#ScrollBar] AddChild
-- @param UIElement#UIElement elementelement

---
-- Function InsertChild
--
-- @function [parent=#ScrollBar] InsertChild
-- @param #number indexindex
-- @param UIElement#UIElement elementelement

---
-- Function RemoveChild
--
-- @function [parent=#ScrollBar] RemoveChild
-- @param UIElement#UIElement elementelement
-- @param #number indexindex

---
-- Function RemoveChildAtIndex
--
-- @function [parent=#ScrollBar] RemoveChildAtIndex
-- @param #number indexindex

---
-- Function RemoveAllChildren
--
-- @function [parent=#ScrollBar] RemoveAllChildren

---
-- Function Remove
--
-- @function [parent=#ScrollBar] Remove

---
-- Function FindChild
--
-- @function [parent=#ScrollBar] FindChild
-- @param UIElement#UIElement elementelement
-- @return #number

---
-- Function SetParent
--
-- @function [parent=#ScrollBar] SetParent
-- @param UIElement#UIElement parentparent
-- @param #number indexindex

---
-- Function SetVar
--
-- @function [parent=#ScrollBar] SetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @param Variant#Variant valuevalue

---
-- Function SetInternal
--
-- @function [parent=#ScrollBar] SetInternal
-- @param #boolean enableenable

---
-- Function SetTraversalMode
--
-- @function [parent=#ScrollBar] SetTraversalMode
-- @param TraversalMode#TraversalMode traversalModetraversalMode

---
-- Function SetElementEventSender
--
-- @function [parent=#ScrollBar] SetElementEventSender
-- @param #boolean flagflag

---
-- Function GetName
--
-- @function [parent=#ScrollBar] GetName
-- @return const String#const String

---
-- Function GetPosition
--
-- @function [parent=#ScrollBar] GetPosition
-- @return const IntVector2#const IntVector2

---
-- Function GetSize
--
-- @function [parent=#ScrollBar] GetSize
-- @return const IntVector2#const IntVector2

---
-- Function GetWidth
--
-- @function [parent=#ScrollBar] GetWidth
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#ScrollBar] GetHeight
-- @return #number

---
-- Function GetMinSize
--
-- @function [parent=#ScrollBar] GetMinSize
-- @return const IntVector2#const IntVector2

---
-- Function GetMinWidth
--
-- @function [parent=#ScrollBar] GetMinWidth
-- @return #number

---
-- Function GetMinHeight
--
-- @function [parent=#ScrollBar] GetMinHeight
-- @return #number

---
-- Function GetMaxSize
--
-- @function [parent=#ScrollBar] GetMaxSize
-- @return const IntVector2#const IntVector2

---
-- Function GetMaxWidth
--
-- @function [parent=#ScrollBar] GetMaxWidth
-- @return #number

---
-- Function GetMaxHeight
--
-- @function [parent=#ScrollBar] GetMaxHeight
-- @return #number

---
-- Function IsFixedSize
--
-- @function [parent=#ScrollBar] IsFixedSize
-- @return #boolean

---
-- Function IsFixedWidth
--
-- @function [parent=#ScrollBar] IsFixedWidth
-- @return #boolean

---
-- Function IsFixedHeight
--
-- @function [parent=#ScrollBar] IsFixedHeight
-- @return #boolean

---
-- Function GetChildOffset
--
-- @function [parent=#ScrollBar] GetChildOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetHorizontalAlignment
--
-- @function [parent=#ScrollBar] GetHorizontalAlignment
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetVerticalAlignment
--
-- @function [parent=#ScrollBar] GetVerticalAlignment
-- @return VerticalAlignment#VerticalAlignment

---
-- Function GetClipBorder
--
-- @function [parent=#ScrollBar] GetClipBorder
-- @return const IntRect#const IntRect

---
-- Function GetColor
--
-- @function [parent=#ScrollBar] GetColor
-- @param Corner#Corner cornercorner
-- @return const Color#const Color

---
-- Function GetPriority
--
-- @function [parent=#ScrollBar] GetPriority
-- @return #number

---
-- Function GetOpacity
--
-- @function [parent=#ScrollBar] GetOpacity
-- @return #number

---
-- Function GetDerivedOpacity
--
-- @function [parent=#ScrollBar] GetDerivedOpacity
-- @return #number

---
-- Function GetBringToFront
--
-- @function [parent=#ScrollBar] GetBringToFront
-- @return #boolean

---
-- Function GetBringToBack
--
-- @function [parent=#ScrollBar] GetBringToBack
-- @return #boolean

---
-- Function GetClipChildren
--
-- @function [parent=#ScrollBar] GetClipChildren
-- @return #boolean

---
-- Function GetSortChildren
--
-- @function [parent=#ScrollBar] GetSortChildren
-- @return #boolean

---
-- Function GetUseDerivedOpacity
--
-- @function [parent=#ScrollBar] GetUseDerivedOpacity
-- @return #boolean

---
-- Function HasFocus
--
-- @function [parent=#ScrollBar] HasFocus
-- @return #boolean

---
-- Function IsEnabled
--
-- @function [parent=#ScrollBar] IsEnabled
-- @return #boolean

---
-- Function IsEditable
--
-- @function [parent=#ScrollBar] IsEditable
-- @return #boolean

---
-- Function IsSelected
--
-- @function [parent=#ScrollBar] IsSelected
-- @return #boolean

---
-- Function IsVisible
--
-- @function [parent=#ScrollBar] IsVisible
-- @return #boolean

---
-- Function IsHovering
--
-- @function [parent=#ScrollBar] IsHovering
-- @return #boolean

---
-- Function IsInternal
--
-- @function [parent=#ScrollBar] IsInternal
-- @return #boolean

---
-- Function HasColorGradient
--
-- @function [parent=#ScrollBar] HasColorGradient
-- @return #boolean

---
-- Function GetFocusMode
--
-- @function [parent=#ScrollBar] GetFocusMode
-- @return FocusMode#FocusMode

---
-- Function GetDragDropMode
--
-- @function [parent=#ScrollBar] GetDragDropMode
-- @return #number

---
-- Function GetAppliedStyle
--
-- @function [parent=#ScrollBar] GetAppliedStyle
-- @return const String#const String

---
-- Function GetDefaultStyle
--
-- @function [parent=#ScrollBar] GetDefaultStyle
-- @param #boolean recursiveUprecursiveUp
-- @return XMLFile#XMLFile

---
-- Function GetLayoutMode
--
-- @function [parent=#ScrollBar] GetLayoutMode
-- @return LayoutMode#LayoutMode

---
-- Function GetLayoutSpacing
--
-- @function [parent=#ScrollBar] GetLayoutSpacing
-- @return #number

---
-- Function GetLayoutBorder
--
-- @function [parent=#ScrollBar] GetLayoutBorder
-- @return const IntRect#const IntRect

---
-- Function GetNumChildren
--
-- @function [parent=#ScrollBar] GetNumChildren
-- @param #boolean recursiverecursive
-- @return #number

---
-- Function GetChild
--
-- @function [parent=#ScrollBar] GetChild
-- @param #string namename
-- @param #boolean recursiverecursive
-- @return UIElement#UIElement

---
-- Function GetChild
--
-- @function [parent=#ScrollBar] GetChild
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function GetParent
--
-- @function [parent=#ScrollBar] GetParent
-- @return UIElement#UIElement

---
-- Function GetRoot
--
-- @function [parent=#ScrollBar] GetRoot
-- @return UIElement#UIElement

---
-- Function GetDerivedColor
--
-- @function [parent=#ScrollBar] GetDerivedColor
-- @return const Color#const Color

---
-- Function GetVar
--
-- @function [parent=#ScrollBar] GetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @return const Variant#const Variant

---
-- Function GetVars
--
-- @function [parent=#ScrollBar] GetVars
-- @return const VariantMap#const VariantMap

---
-- Function ScreenToElement
--
-- @function [parent=#ScrollBar] ScreenToElement
-- @param IntVector2#IntVector2 screenPositionscreenPosition
-- @return IntVector2#IntVector2

---
-- Function ElementToScreen
--
-- @function [parent=#ScrollBar] ElementToScreen
-- @param IntVector2#IntVector2 positionposition
-- @return IntVector2#IntVector2

---
-- Function IsInside
--
-- @function [parent=#ScrollBar] IsInside
-- @param IntVector2#IntVector2 positionposition
-- @param #boolean isScreenisScreen
-- @return #boolean

---
-- Function IsInsideCombined
--
-- @function [parent=#ScrollBar] IsInsideCombined
-- @param IntVector2#IntVector2 positionposition
-- @param #boolean isScreenisScreen
-- @return #boolean

---
-- Function GetCombinedScreenRect
--
-- @function [parent=#ScrollBar] GetCombinedScreenRect
-- @return IntRect#IntRect

---
-- Function SortChildren
--
-- @function [parent=#ScrollBar] SortChildren

---
-- Function GetLayoutMinSize
--
-- @function [parent=#ScrollBar] GetLayoutMinSize
-- @return #number

---
-- Function GetIndent
--
-- @function [parent=#ScrollBar] GetIndent
-- @return #number

---
-- Function GetIndentSpacing
--
-- @function [parent=#ScrollBar] GetIndentSpacing
-- @return #number

---
-- Function GetIndentWidth
--
-- @function [parent=#ScrollBar] GetIndentWidth
-- @return #number

---
-- Function SetChildOffset
--
-- @function [parent=#ScrollBar] SetChildOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetHovering
--
-- @function [parent=#ScrollBar] SetHovering
-- @param #boolean enableenable

---
-- Function GetColor
--
-- @function [parent=#ScrollBar] GetColor
-- @return const Color#const Color

---
-- Function GetTraversalMode
--
-- @function [parent=#ScrollBar] GetTraversalMode
-- @return TraversalMode#TraversalMode

---
-- Function IsElementEventSender
--
-- @function [parent=#ScrollBar] IsElementEventSender
-- @return #boolean

---
-- Function GetElementEventSender
--
-- @function [parent=#ScrollBar] GetElementEventSender
-- @return UIElement#UIElement

---
-- Field screenPosition (Read only)
--
-- @field [parent=#ScrollBar] IntVector2#IntVector2 screenPosition

---
-- Field name
--
-- @field [parent=#ScrollBar] #string name

---
-- Field position
--
-- @field [parent=#ScrollBar] IntVector2#IntVector2 position

---
-- Field size
--
-- @field [parent=#ScrollBar] IntVector2#IntVector2 size

---
-- Field width
--
-- @field [parent=#ScrollBar] #number width

---
-- Field height
--
-- @field [parent=#ScrollBar] #number height

---
-- Field minSize
--
-- @field [parent=#ScrollBar] IntVector2#IntVector2 minSize

---
-- Field minWidth
--
-- @field [parent=#ScrollBar] #number minWidth

---
-- Field minHeight
--
-- @field [parent=#ScrollBar] #number minHeight

---
-- Field maxSize
--
-- @field [parent=#ScrollBar] IntVector2#IntVector2 maxSize

---
-- Field maxWidth
--
-- @field [parent=#ScrollBar] #number maxWidth

---
-- Field maxHeight
--
-- @field [parent=#ScrollBar] #number maxHeight

---
-- Field fixedSize (Read only)
--
-- @field [parent=#ScrollBar] #boolean fixedSize

---
-- Field fixedWidth (Read only)
--
-- @field [parent=#ScrollBar] #boolean fixedWidth

---
-- Field fixedHeight (Read only)
--
-- @field [parent=#ScrollBar] #boolean fixedHeight

---
-- Field childOffset
--
-- @field [parent=#ScrollBar] IntVector2#IntVector2 childOffset

---
-- Field horizontalAlignment
--
-- @field [parent=#ScrollBar] HorizontalAlignment#HorizontalAlignment horizontalAlignment

---
-- Field verticalAlignment
--
-- @field [parent=#ScrollBar] VerticalAlignment#VerticalAlignment verticalAlignment

---
-- Field clipBorder
--
-- @field [parent=#ScrollBar] IntRect#IntRect clipBorder

---
-- Field color
--
-- @field [parent=#ScrollBar] Color#Color color

---
-- Field priority
--
-- @field [parent=#ScrollBar] #number priority

---
-- Field opacity
--
-- @field [parent=#ScrollBar] #number opacity

---
-- Field derivedOpacity (Read only)
--
-- @field [parent=#ScrollBar] #number derivedOpacity

---
-- Field bringToFront
--
-- @field [parent=#ScrollBar] #boolean bringToFront

---
-- Field bringToBack
--
-- @field [parent=#ScrollBar] #boolean bringToBack

---
-- Field clipChildren
--
-- @field [parent=#ScrollBar] #boolean clipChildren

---
-- Field sortChildren
--
-- @field [parent=#ScrollBar] #boolean sortChildren

---
-- Field useDerivedOpacity
--
-- @field [parent=#ScrollBar] #boolean useDerivedOpacity

---
-- Field focus
--
-- @field [parent=#ScrollBar] #boolean focus

---
-- Field enabled
--
-- @field [parent=#ScrollBar] #boolean enabled

---
-- Field editable
--
-- @field [parent=#ScrollBar] #boolean editable

---
-- Field selected
--
-- @field [parent=#ScrollBar] #boolean selected

---
-- Field visible
--
-- @field [parent=#ScrollBar] #boolean visible

---
-- Field hovering
--
-- @field [parent=#ScrollBar] #boolean hovering

---
-- Field internal
--
-- @field [parent=#ScrollBar] #boolean internal

---
-- Field colorGradient (Read only)
--
-- @field [parent=#ScrollBar] #boolean colorGradient

---
-- Field focusMode
--
-- @field [parent=#ScrollBar] FocusMode#FocusMode focusMode

---
-- Field dragDropMode
--
-- @field [parent=#ScrollBar] #number dragDropMode

---
-- Field style
--
-- @field [parent=#ScrollBar] #string style

---
-- Field defaultStyle
--
-- @field [parent=#ScrollBar] XMLFile#XMLFile defaultStyle

---
-- Field layoutMode
--
-- @field [parent=#ScrollBar] LayoutMode#LayoutMode layoutMode

---
-- Field layoutSpacing
--
-- @field [parent=#ScrollBar] #number layoutSpacing

---
-- Field layoutBorder
--
-- @field [parent=#ScrollBar] IntRect#IntRect layoutBorder

---
-- Field numChildren (Read only)
--
-- @field [parent=#ScrollBar] #number numChildren

---
-- Field parent
--
-- @field [parent=#ScrollBar] UIElement#UIElement parent

---
-- Field root (Read only)
--
-- @field [parent=#ScrollBar] UIElement#UIElement root

---
-- Field derivedColor (Read only)
--
-- @field [parent=#ScrollBar] Color#Color derivedColor

---
-- Field combinedScreenRect (Read only)
--
-- @field [parent=#ScrollBar] IntRect#IntRect combinedScreenRect

---
-- Field layoutMinSize (Read only)
--
-- @field [parent=#ScrollBar] #number layoutMinSize

---
-- Field indent
--
-- @field [parent=#ScrollBar] #number indent

---
-- Field indentSpacing
--
-- @field [parent=#ScrollBar] #number indentSpacing

---
-- Field indentWidth (Read only)
--
-- @field [parent=#ScrollBar] #number indentWidth

---
-- Field traversalMode
--
-- @field [parent=#ScrollBar] TraversalMode#TraversalMode traversalMode

---
-- Field elementEventSender
--
-- @field [parent=#ScrollBar] #boolean elementEventSender

---
-- Function SetTemporary
--
-- @function [parent=#ScrollBar] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#ScrollBar] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#ScrollBar] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#ScrollBar] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#ScrollBar] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#ScrollBar] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#ScrollBar] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#ScrollBar] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#ScrollBar] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#ScrollBar] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#ScrollBar] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#ScrollBar] #string category


return nil
