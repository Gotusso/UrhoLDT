---
-- Module ScrollBar
-- Extends UIElement
--
-- @module ScrollBar

---
-- Function ScrollBar
--
-- @function [parent=#ScrollBar] ScrollBar

---
-- Function new
--
-- @function [parent=#ScrollBar] new
-- @return ScrollBar#ScrollBar

---
-- Function delete
--
-- @function [parent=#ScrollBar] delete

---
-- Function SetOrientation
--
-- @function [parent=#ScrollBar] SetOrientation
-- @param Orientation#Orientation orientationorientation

---
-- Function SetRange
--
-- @function [parent=#ScrollBar] SetRange
-- @param #number rangerange

---
-- Function SetValue
--
-- @function [parent=#ScrollBar] SetValue
-- @param #number valuevalue

---
-- Function ChangeValue
--
-- @function [parent=#ScrollBar] ChangeValue
-- @param #number deltadelta

---
-- Function SetScrollStep
--
-- @function [parent=#ScrollBar] SetScrollStep
-- @param #number stepstep

---
-- Function SetStepFactor
--
-- @function [parent=#ScrollBar] SetStepFactor
-- @param #number factorfactor

---
-- Function StepBack
--
-- @function [parent=#ScrollBar] StepBack

---
-- Function StepForward
--
-- @function [parent=#ScrollBar] StepForward

---
-- Function GetOrientation
--
-- @function [parent=#ScrollBar] GetOrientation
-- @return Orientation#Orientation

---
-- Function GetRange
--
-- @function [parent=#ScrollBar] GetRange
-- @return #number

---
-- Function GetValue
--
-- @function [parent=#ScrollBar] GetValue
-- @return #number

---
-- Function GetScrollStep
--
-- @function [parent=#ScrollBar] GetScrollStep
-- @return #number

---
-- Function GetStepFactor
--
-- @function [parent=#ScrollBar] GetStepFactor
-- @return #number

---
-- Function GetEffectiveScrollStep
--
-- @function [parent=#ScrollBar] GetEffectiveScrollStep
-- @return #number

---
-- Function GetBackButton
--
-- @function [parent=#ScrollBar] GetBackButton
-- @return Button#Button

---
-- Function GetForwardButton
--
-- @function [parent=#ScrollBar] GetForwardButton
-- @return Button#Button

---
-- Function GetSlider
--
-- @function [parent=#ScrollBar] GetSlider
-- @return Slider#Slider

---
-- Field orientation
--
-- @field [parent=#ScrollBar] Orientation#Orientation orientation

---
-- Field range
--
-- @field [parent=#ScrollBar] #number range

---
-- Field value
--
-- @field [parent=#ScrollBar] #number value

---
-- Field scrollStep
--
-- @field [parent=#ScrollBar] #number scrollStep

---
-- Field stepFactor
--
-- @field [parent=#ScrollBar] #number stepFactor

---
-- Field effectiveScrollStep (Read only)
--
-- @field [parent=#ScrollBar] #number effectiveScrollStep

---
-- Field backButton (Read only)
--
-- @field [parent=#ScrollBar] Button#Button backButton

---
-- Field forwardButton (Read only)
--
-- @field [parent=#ScrollBar] Button#Button forwardButton

---
-- Field slider (Read only)
--
-- @field [parent=#ScrollBar] Slider#Slider slider


return nil
