---
-- Module ScrollBar
-- Module ScrollBar extends UIElement
-- Generated on 2014-03-13
--
-- @module ScrollBar

---
-- Function ScrollBar
--
-- @function [parent=#ScrollBar] ScrollBar
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#ScrollBar] new
-- @param self Self reference
-- @return ScrollBar#ScrollBar

---
-- Function delete
--
-- @function [parent=#ScrollBar] delete
-- @param self Self reference

---
-- Function SetOrientation
--
-- @function [parent=#ScrollBar] SetOrientation
-- @param self Self reference
-- @param Orientation#Orientation orientation orientation

---
-- Function SetRange
--
-- @function [parent=#ScrollBar] SetRange
-- @param self Self reference
-- @param #number range range

---
-- Function SetValue
--
-- @function [parent=#ScrollBar] SetValue
-- @param self Self reference
-- @param #number value value

---
-- Function ChangeValue
--
-- @function [parent=#ScrollBar] ChangeValue
-- @param self Self reference
-- @param #number delta delta

---
-- Function SetScrollStep
--
-- @function [parent=#ScrollBar] SetScrollStep
-- @param self Self reference
-- @param #number step step

---
-- Function SetStepFactor
--
-- @function [parent=#ScrollBar] SetStepFactor
-- @param self Self reference
-- @param #number factor factor

---
-- Function StepBack
--
-- @function [parent=#ScrollBar] StepBack
-- @param self Self reference

---
-- Function StepForward
--
-- @function [parent=#ScrollBar] StepForward
-- @param self Self reference

---
-- Function GetOrientation
--
-- @function [parent=#ScrollBar] GetOrientation
-- @param self Self reference
-- @return Orientation#Orientation

---
-- Function GetRange
--
-- @function [parent=#ScrollBar] GetRange
-- @param self Self reference
-- @return #number

---
-- Function GetValue
--
-- @function [parent=#ScrollBar] GetValue
-- @param self Self reference
-- @return #number

---
-- Function GetScrollStep
--
-- @function [parent=#ScrollBar] GetScrollStep
-- @param self Self reference
-- @return #number

---
-- Function GetStepFactor
--
-- @function [parent=#ScrollBar] GetStepFactor
-- @param self Self reference
-- @return #number

---
-- Function GetEffectiveScrollStep
--
-- @function [parent=#ScrollBar] GetEffectiveScrollStep
-- @param self Self reference
-- @return #number

---
-- Function GetBackButton
--
-- @function [parent=#ScrollBar] GetBackButton
-- @param self Self reference
-- @return Button#Button

---
-- Function GetForwardButton
--
-- @function [parent=#ScrollBar] GetForwardButton
-- @param self Self reference
-- @return Button#Button

---
-- Function GetSlider
--
-- @function [parent=#ScrollBar] GetSlider
-- @param self Self reference
-- @return Slider#Slider

---
-- Field orientation
--
-- @field [parent=#ScrollBar] Orientation#Orientation orientation

---
-- Field range
--
-- @field [parent=#ScrollBar] #number range

---
-- Field value
--
-- @field [parent=#ScrollBar] #number value

---
-- Field scrollStep
--
-- @field [parent=#ScrollBar] #number scrollStep

---
-- Field stepFactor
--
-- @field [parent=#ScrollBar] #number stepFactor

---
-- Field effectiveScrollStep (Read only)
--
-- @field [parent=#ScrollBar] #number effectiveScrollStep

---
-- Field backButton (Read only)
--
-- @field [parent=#ScrollBar] Button#Button backButton

---
-- Field forwardButton (Read only)
--
-- @field [parent=#ScrollBar] Button#Button forwardButton

---
-- Field slider (Read only)
--
-- @field [parent=#ScrollBar] Slider#Slider slider

---
-- Function UIElement
--
-- @function [parent=#ScrollBar] UIElement
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#ScrollBar] new
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function delete
--
-- @function [parent=#ScrollBar] delete
-- @param self Self reference

---
-- Function GetScreenPosition
--
-- @function [parent=#ScrollBar] GetScreenPosition
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function LoadXML
--
-- @function [parent=#ScrollBar] LoadXML
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#ScrollBar] SaveXML
-- @param self Self reference
-- @param Serializer#Serializer dest dest
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#ScrollBar] LoadXML
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#ScrollBar] SaveXML
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function FilterAttributes
--
-- @function [parent=#ScrollBar] FilterAttributes
-- @param self Self reference
-- @param XMLElement#XMLElement dest dest
-- @return #boolean

---
-- Function SetName
--
-- @function [parent=#ScrollBar] SetName
-- @param self Self reference
-- @param #string name name

---
-- Function SetPosition
--
-- @function [parent=#ScrollBar] SetPosition
-- @param self Self reference
-- @param IntVector2#IntVector2 position position

---
-- Function SetPosition
--
-- @function [parent=#ScrollBar] SetPosition
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function SetSize
--
-- @function [parent=#ScrollBar] SetSize
-- @param self Self reference
-- @param IntVector2#IntVector2 size size

---
-- Function SetSize
--
-- @function [parent=#ScrollBar] SetSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetWidth
--
-- @function [parent=#ScrollBar] SetWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetHeight
--
-- @function [parent=#ScrollBar] SetHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetMinSize
--
-- @function [parent=#ScrollBar] SetMinSize
-- @param self Self reference
-- @param IntVector2#IntVector2 minSize minSize

---
-- Function SetMinSize
--
-- @function [parent=#ScrollBar] SetMinSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetMinWidth
--
-- @function [parent=#ScrollBar] SetMinWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetMinHeight
--
-- @function [parent=#ScrollBar] SetMinHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetMaxSize
--
-- @function [parent=#ScrollBar] SetMaxSize
-- @param self Self reference
-- @param IntVector2#IntVector2 maxSize maxSize

---
-- Function SetMaxSize
--
-- @function [parent=#ScrollBar] SetMaxSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetMaxWidth
--
-- @function [parent=#ScrollBar] SetMaxWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetMaxHeight
--
-- @function [parent=#ScrollBar] SetMaxHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetFixedSize
--
-- @function [parent=#ScrollBar] SetFixedSize
-- @param self Self reference
-- @param IntVector2#IntVector2 size size

---
-- Function SetFixedSize
--
-- @function [parent=#ScrollBar] SetFixedSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetFixedWidth
--
-- @function [parent=#ScrollBar] SetFixedWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetFixedHeight
--
-- @function [parent=#ScrollBar] SetFixedHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetAlignment
--
-- @function [parent=#ScrollBar] SetAlignment
-- @param self Self reference
-- @param HorizontalAlignment#HorizontalAlignment hAlign hAlign
-- @param VerticalAlignment#VerticalAlignment vAlign vAlign

---
-- Function SetHorizontalAlignment
--
-- @function [parent=#ScrollBar] SetHorizontalAlignment
-- @param self Self reference
-- @param HorizontalAlignment#HorizontalAlignment align align

---
-- Function SetVerticalAlignment
--
-- @function [parent=#ScrollBar] SetVerticalAlignment
-- @param self Self reference
-- @param VerticalAlignment#VerticalAlignment align align

---
-- Function SetClipBorder
--
-- @function [parent=#ScrollBar] SetClipBorder
-- @param self Self reference
-- @param IntRect#IntRect rect rect

---
-- Function SetColor
--
-- @function [parent=#ScrollBar] SetColor
-- @param self Self reference
-- @param Color#Color color color

---
-- Function SetColor
--
-- @function [parent=#ScrollBar] SetColor
-- @param self Self reference
-- @param Corner#Corner corner corner
-- @param Color#Color color color

---
-- Function SetPriority
--
-- @function [parent=#ScrollBar] SetPriority
-- @param self Self reference
-- @param #number priority priority

---
-- Function SetOpacity
--
-- @function [parent=#ScrollBar] SetOpacity
-- @param self Self reference
-- @param #number opacity opacity

---
-- Function SetBringToFront
--
-- @function [parent=#ScrollBar] SetBringToFront
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetBringToBack
--
-- @function [parent=#ScrollBar] SetBringToBack
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetClipChildren
--
-- @function [parent=#ScrollBar] SetClipChildren
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetSortChildren
--
-- @function [parent=#ScrollBar] SetSortChildren
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetUseDerivedOpacity
--
-- @function [parent=#ScrollBar] SetUseDerivedOpacity
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetEnabled
--
-- @function [parent=#ScrollBar] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetEditable
--
-- @function [parent=#ScrollBar] SetEditable
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetFocus
--
-- @function [parent=#ScrollBar] SetFocus
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetSelected
--
-- @function [parent=#ScrollBar] SetSelected
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetVisible
--
-- @function [parent=#ScrollBar] SetVisible
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetFocusMode
--
-- @function [parent=#ScrollBar] SetFocusMode
-- @param self Self reference
-- @param FocusMode#FocusMode mode mode

---
-- Function SetDragDropMode
--
-- @function [parent=#ScrollBar] SetDragDropMode
-- @param self Self reference
-- @param #number mode mode

---
-- Function SetStyle
--
-- @function [parent=#ScrollBar] SetStyle
-- @param self Self reference
-- @param #string styleName styleName
-- @param XMLFile#XMLFile file file
-- @return #boolean

---
-- Function SetStyle
--
-- @function [parent=#ScrollBar] SetStyle
-- @param self Self reference
-- @param XMLElement#XMLElement element element
-- @return #boolean

---
-- Function SetStyleAuto
--
-- @function [parent=#ScrollBar] SetStyleAuto
-- @param self Self reference
-- @param XMLFile#XMLFile file file
-- @return #boolean

---
-- Function SetDefaultStyle
--
-- @function [parent=#ScrollBar] SetDefaultStyle
-- @param self Self reference
-- @param XMLFile#XMLFile style style

---
-- Function SetLayout
--
-- @function [parent=#ScrollBar] SetLayout
-- @param self Self reference
-- @param LayoutMode#LayoutMode mode mode
-- @param #number spacing spacing

---
-- Function SetLayout
--
-- @function [parent=#ScrollBar] SetLayout
-- @param self Self reference
-- @param LayoutMode#LayoutMode mode mode
-- @param #number spacing spacing
-- @param IntRect#IntRect border border

---
-- Function SetLayoutMode
--
-- @function [parent=#ScrollBar] SetLayoutMode
-- @param self Self reference
-- @param LayoutMode#LayoutMode mode mode

---
-- Function SetLayoutSpacing
--
-- @function [parent=#ScrollBar] SetLayoutSpacing
-- @param self Self reference
-- @param #number spacing spacing

---
-- Function SetLayoutBorder
--
-- @function [parent=#ScrollBar] SetLayoutBorder
-- @param self Self reference
-- @param IntRect#IntRect border border

---
-- Function SetIndent
--
-- @function [parent=#ScrollBar] SetIndent
-- @param self Self reference
-- @param #number indent indent

---
-- Function SetIndentSpacing
--
-- @function [parent=#ScrollBar] SetIndentSpacing
-- @param self Self reference
-- @param #number indentSpacing indentSpacing

---
-- Function UpdateLayout
--
-- @function [parent=#ScrollBar] UpdateLayout
-- @param self Self reference

---
-- Function DisableLayoutUpdate
--
-- @function [parent=#ScrollBar] DisableLayoutUpdate
-- @param self Self reference

---
-- Function EnableLayoutUpdate
--
-- @function [parent=#ScrollBar] EnableLayoutUpdate
-- @param self Self reference

---
-- Function BringToFront
--
-- @function [parent=#ScrollBar] BringToFront
-- @param self Self reference

---
-- Function CreateChild
--
-- @function [parent=#ScrollBar] CreateChild
-- @param self Self reference
-- @param #string type type
-- @param #string name name
-- @param #number index index
-- @return UIElement#UIElement

---
-- Function AddChild
--
-- @function [parent=#ScrollBar] AddChild
-- @param self Self reference
-- @param UIElement#UIElement element element

---
-- Function InsertChild
--
-- @function [parent=#ScrollBar] InsertChild
-- @param self Self reference
-- @param #number index index
-- @param UIElement#UIElement element element

---
-- Function RemoveChild
--
-- @function [parent=#ScrollBar] RemoveChild
-- @param self Self reference
-- @param UIElement#UIElement element element
-- @param #number index index

---
-- Function RemoveChildAtIndex
--
-- @function [parent=#ScrollBar] RemoveChildAtIndex
-- @param self Self reference
-- @param #number index index

---
-- Function RemoveAllChildren
--
-- @function [parent=#ScrollBar] RemoveAllChildren
-- @param self Self reference

---
-- Function Remove
--
-- @function [parent=#ScrollBar] Remove
-- @param self Self reference

---
-- Function FindChild
--
-- @function [parent=#ScrollBar] FindChild
-- @param self Self reference
-- @param UIElement#UIElement element element
-- @return #number

---
-- Function SetParent
--
-- @function [parent=#ScrollBar] SetParent
-- @param self Self reference
-- @param UIElement#UIElement parent parent
-- @param #number index index

---
-- Function SetVar
--
-- @function [parent=#ScrollBar] SetVar
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash key key
-- @param Variant#Variant value value

---
-- Function SetInternal
--
-- @function [parent=#ScrollBar] SetInternal
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetTraversalMode
--
-- @function [parent=#ScrollBar] SetTraversalMode
-- @param self Self reference
-- @param TraversalMode#TraversalMode traversalMode traversalMode

---
-- Function SetElementEventSender
--
-- @function [parent=#ScrollBar] SetElementEventSender
-- @param self Self reference
-- @param #boolean flag flag

---
-- Function GetName
--
-- @function [parent=#ScrollBar] GetName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetPosition
--
-- @function [parent=#ScrollBar] GetPosition
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetSize
--
-- @function [parent=#ScrollBar] GetSize
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetWidth
--
-- @function [parent=#ScrollBar] GetWidth
-- @param self Self reference
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#ScrollBar] GetHeight
-- @param self Self reference
-- @return #number

---
-- Function GetMinSize
--
-- @function [parent=#ScrollBar] GetMinSize
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetMinWidth
--
-- @function [parent=#ScrollBar] GetMinWidth
-- @param self Self reference
-- @return #number

---
-- Function GetMinHeight
--
-- @function [parent=#ScrollBar] GetMinHeight
-- @param self Self reference
-- @return #number

---
-- Function GetMaxSize
--
-- @function [parent=#ScrollBar] GetMaxSize
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetMaxWidth
--
-- @function [parent=#ScrollBar] GetMaxWidth
-- @param self Self reference
-- @return #number

---
-- Function GetMaxHeight
--
-- @function [parent=#ScrollBar] GetMaxHeight
-- @param self Self reference
-- @return #number

---
-- Function IsFixedSize
--
-- @function [parent=#ScrollBar] IsFixedSize
-- @param self Self reference
-- @return #boolean

---
-- Function IsFixedWidth
--
-- @function [parent=#ScrollBar] IsFixedWidth
-- @param self Self reference
-- @return #boolean

---
-- Function IsFixedHeight
--
-- @function [parent=#ScrollBar] IsFixedHeight
-- @param self Self reference
-- @return #boolean

---
-- Function GetChildOffset
--
-- @function [parent=#ScrollBar] GetChildOffset
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetHorizontalAlignment
--
-- @function [parent=#ScrollBar] GetHorizontalAlignment
-- @param self Self reference
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetVerticalAlignment
--
-- @function [parent=#ScrollBar] GetVerticalAlignment
-- @param self Self reference
-- @return VerticalAlignment#VerticalAlignment

---
-- Function GetClipBorder
--
-- @function [parent=#ScrollBar] GetClipBorder
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetColor
--
-- @function [parent=#ScrollBar] GetColor
-- @param self Self reference
-- @param Corner#Corner corner corner
-- @return const Color#const Color

---
-- Function GetPriority
--
-- @function [parent=#ScrollBar] GetPriority
-- @param self Self reference
-- @return #number

---
-- Function GetOpacity
--
-- @function [parent=#ScrollBar] GetOpacity
-- @param self Self reference
-- @return #number

---
-- Function GetDerivedOpacity
--
-- @function [parent=#ScrollBar] GetDerivedOpacity
-- @param self Self reference
-- @return #number

---
-- Function GetBringToFront
--
-- @function [parent=#ScrollBar] GetBringToFront
-- @param self Self reference
-- @return #boolean

---
-- Function GetBringToBack
--
-- @function [parent=#ScrollBar] GetBringToBack
-- @param self Self reference
-- @return #boolean

---
-- Function GetClipChildren
--
-- @function [parent=#ScrollBar] GetClipChildren
-- @param self Self reference
-- @return #boolean

---
-- Function GetSortChildren
--
-- @function [parent=#ScrollBar] GetSortChildren
-- @param self Self reference
-- @return #boolean

---
-- Function GetUseDerivedOpacity
--
-- @function [parent=#ScrollBar] GetUseDerivedOpacity
-- @param self Self reference
-- @return #boolean

---
-- Function HasFocus
--
-- @function [parent=#ScrollBar] HasFocus
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabled
--
-- @function [parent=#ScrollBar] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEditable
--
-- @function [parent=#ScrollBar] IsEditable
-- @param self Self reference
-- @return #boolean

---
-- Function IsSelected
--
-- @function [parent=#ScrollBar] IsSelected
-- @param self Self reference
-- @return #boolean

---
-- Function IsVisible
--
-- @function [parent=#ScrollBar] IsVisible
-- @param self Self reference
-- @return #boolean

---
-- Function IsHovering
--
-- @function [parent=#ScrollBar] IsHovering
-- @param self Self reference
-- @return #boolean

---
-- Function IsInternal
--
-- @function [parent=#ScrollBar] IsInternal
-- @param self Self reference
-- @return #boolean

---
-- Function HasColorGradient
--
-- @function [parent=#ScrollBar] HasColorGradient
-- @param self Self reference
-- @return #boolean

---
-- Function GetFocusMode
--
-- @function [parent=#ScrollBar] GetFocusMode
-- @param self Self reference
-- @return FocusMode#FocusMode

---
-- Function GetDragDropMode
--
-- @function [parent=#ScrollBar] GetDragDropMode
-- @param self Self reference
-- @return #number

---
-- Function GetAppliedStyle
--
-- @function [parent=#ScrollBar] GetAppliedStyle
-- @param self Self reference
-- @return const String#const String

---
-- Function GetDefaultStyle
--
-- @function [parent=#ScrollBar] GetDefaultStyle
-- @param self Self reference
-- @param #boolean recursiveUp recursiveUp
-- @return XMLFile#XMLFile

---
-- Function GetLayoutMode
--
-- @function [parent=#ScrollBar] GetLayoutMode
-- @param self Self reference
-- @return LayoutMode#LayoutMode

---
-- Function GetLayoutSpacing
--
-- @function [parent=#ScrollBar] GetLayoutSpacing
-- @param self Self reference
-- @return #number

---
-- Function GetLayoutBorder
--
-- @function [parent=#ScrollBar] GetLayoutBorder
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetNumChildren
--
-- @function [parent=#ScrollBar] GetNumChildren
-- @param self Self reference
-- @param #boolean recursive recursive
-- @return #number

---
-- Function GetChild
--
-- @function [parent=#ScrollBar] GetChild
-- @param self Self reference
-- @param #string name name
-- @param #boolean recursive recursive
-- @return UIElement#UIElement

---
-- Function GetChild
--
-- @function [parent=#ScrollBar] GetChild
-- @param self Self reference
-- @param #number index index
-- @return UIElement#UIElement

---
-- Function GetParent
--
-- @function [parent=#ScrollBar] GetParent
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetRoot
--
-- @function [parent=#ScrollBar] GetRoot
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetDerivedColor
--
-- @function [parent=#ScrollBar] GetDerivedColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetVar
--
-- @function [parent=#ScrollBar] GetVar
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash key key
-- @return const Variant#const Variant

---
-- Function GetVars
--
-- @function [parent=#ScrollBar] GetVars
-- @param self Self reference
-- @return const VariantMap#const VariantMap

---
-- Function ScreenToElement
--
-- @function [parent=#ScrollBar] ScreenToElement
-- @param self Self reference
-- @param IntVector2#IntVector2 screenPosition screenPosition
-- @return IntVector2#IntVector2

---
-- Function ElementToScreen
--
-- @function [parent=#ScrollBar] ElementToScreen
-- @param self Self reference
-- @param IntVector2#IntVector2 position position
-- @return IntVector2#IntVector2

---
-- Function IsInside
--
-- @function [parent=#ScrollBar] IsInside
-- @param self Self reference
-- @param IntVector2#IntVector2 position position
-- @param #boolean isScreen isScreen
-- @return #boolean

---
-- Function IsInsideCombined
--
-- @function [parent=#ScrollBar] IsInsideCombined
-- @param self Self reference
-- @param IntVector2#IntVector2 position position
-- @param #boolean isScreen isScreen
-- @return #boolean

---
-- Function GetCombinedScreenRect
--
-- @function [parent=#ScrollBar] GetCombinedScreenRect
-- @param self Self reference
-- @return IntRect#IntRect

---
-- Function SortChildren
--
-- @function [parent=#ScrollBar] SortChildren
-- @param self Self reference

---
-- Function GetLayoutMinSize
--
-- @function [parent=#ScrollBar] GetLayoutMinSize
-- @param self Self reference
-- @return #number

---
-- Function GetIndent
--
-- @function [parent=#ScrollBar] GetIndent
-- @param self Self reference
-- @return #number

---
-- Function GetIndentSpacing
--
-- @function [parent=#ScrollBar] GetIndentSpacing
-- @param self Self reference
-- @return #number

---
-- Function GetIndentWidth
--
-- @function [parent=#ScrollBar] GetIndentWidth
-- @param self Self reference
-- @return #number

---
-- Function SetChildOffset
--
-- @function [parent=#ScrollBar] SetChildOffset
-- @param self Self reference
-- @param IntVector2#IntVector2 offset offset

---
-- Function SetHovering
--
-- @function [parent=#ScrollBar] SetHovering
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function GetColor
--
-- @function [parent=#ScrollBar] GetColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetTraversalMode
--
-- @function [parent=#ScrollBar] GetTraversalMode
-- @param self Self reference
-- @return TraversalMode#TraversalMode

---
-- Function IsElementEventSender
--
-- @function [parent=#ScrollBar] IsElementEventSender
-- @param self Self reference
-- @return #boolean

---
-- Function GetElementEventSender
--
-- @function [parent=#ScrollBar] GetElementEventSender
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Field screenPosition (Read only)
--
-- @field [parent=#ScrollBar] IntVector2#IntVector2 screenPosition

---
-- Field name
--
-- @field [parent=#ScrollBar] #string name

---
-- Field position
--
-- @field [parent=#ScrollBar] IntVector2#IntVector2 position

---
-- Field size
--
-- @field [parent=#ScrollBar] IntVector2#IntVector2 size

---
-- Field width
--
-- @field [parent=#ScrollBar] #number width

---
-- Field height
--
-- @field [parent=#ScrollBar] #number height

---
-- Field minSize
--
-- @field [parent=#ScrollBar] IntVector2#IntVector2 minSize

---
-- Field minWidth
--
-- @field [parent=#ScrollBar] #number minWidth

---
-- Field minHeight
--
-- @field [parent=#ScrollBar] #number minHeight

---
-- Field maxSize
--
-- @field [parent=#ScrollBar] IntVector2#IntVector2 maxSize

---
-- Field maxWidth
--
-- @field [parent=#ScrollBar] #number maxWidth

---
-- Field maxHeight
--
-- @field [parent=#ScrollBar] #number maxHeight

---
-- Field fixedSize (Read only)
--
-- @field [parent=#ScrollBar] #boolean fixedSize

---
-- Field fixedWidth (Read only)
--
-- @field [parent=#ScrollBar] #boolean fixedWidth

---
-- Field fixedHeight (Read only)
--
-- @field [parent=#ScrollBar] #boolean fixedHeight

---
-- Field childOffset
--
-- @field [parent=#ScrollBar] IntVector2#IntVector2 childOffset

---
-- Field horizontalAlignment
--
-- @field [parent=#ScrollBar] HorizontalAlignment#HorizontalAlignment horizontalAlignment

---
-- Field verticalAlignment
--
-- @field [parent=#ScrollBar] VerticalAlignment#VerticalAlignment verticalAlignment

---
-- Field clipBorder
--
-- @field [parent=#ScrollBar] IntRect#IntRect clipBorder

---
-- Field color
--
-- @field [parent=#ScrollBar] Color#Color color

---
-- Field priority
--
-- @field [parent=#ScrollBar] #number priority

---
-- Field opacity
--
-- @field [parent=#ScrollBar] #number opacity

---
-- Field derivedOpacity (Read only)
--
-- @field [parent=#ScrollBar] #number derivedOpacity

---
-- Field bringToFront
--
-- @field [parent=#ScrollBar] #boolean bringToFront

---
-- Field bringToBack
--
-- @field [parent=#ScrollBar] #boolean bringToBack

---
-- Field clipChildren
--
-- @field [parent=#ScrollBar] #boolean clipChildren

---
-- Field sortChildren
--
-- @field [parent=#ScrollBar] #boolean sortChildren

---
-- Field useDerivedOpacity
--
-- @field [parent=#ScrollBar] #boolean useDerivedOpacity

---
-- Field focus
--
-- @field [parent=#ScrollBar] #boolean focus

---
-- Field enabled
--
-- @field [parent=#ScrollBar] #boolean enabled

---
-- Field editable
--
-- @field [parent=#ScrollBar] #boolean editable

---
-- Field selected
--
-- @field [parent=#ScrollBar] #boolean selected

---
-- Field visible
--
-- @field [parent=#ScrollBar] #boolean visible

---
-- Field hovering
--
-- @field [parent=#ScrollBar] #boolean hovering

---
-- Field internal
--
-- @field [parent=#ScrollBar] #boolean internal

---
-- Field colorGradient (Read only)
--
-- @field [parent=#ScrollBar] #boolean colorGradient

---
-- Field focusMode
--
-- @field [parent=#ScrollBar] FocusMode#FocusMode focusMode

---
-- Field dragDropMode
--
-- @field [parent=#ScrollBar] #number dragDropMode

---
-- Field style
--
-- @field [parent=#ScrollBar] #string style

---
-- Field defaultStyle
--
-- @field [parent=#ScrollBar] XMLFile#XMLFile defaultStyle

---
-- Field layoutMode
--
-- @field [parent=#ScrollBar] LayoutMode#LayoutMode layoutMode

---
-- Field layoutSpacing
--
-- @field [parent=#ScrollBar] #number layoutSpacing

---
-- Field layoutBorder
--
-- @field [parent=#ScrollBar] IntRect#IntRect layoutBorder

---
-- Field numChildren (Read only)
--
-- @field [parent=#ScrollBar] #number numChildren

---
-- Field parent
--
-- @field [parent=#ScrollBar] UIElement#UIElement parent

---
-- Field root (Read only)
--
-- @field [parent=#ScrollBar] UIElement#UIElement root

---
-- Field derivedColor (Read only)
--
-- @field [parent=#ScrollBar] Color#Color derivedColor

---
-- Field combinedScreenRect (Read only)
--
-- @field [parent=#ScrollBar] IntRect#IntRect combinedScreenRect

---
-- Field layoutMinSize (Read only)
--
-- @field [parent=#ScrollBar] #number layoutMinSize

---
-- Field indent
--
-- @field [parent=#ScrollBar] #number indent

---
-- Field indentSpacing
--
-- @field [parent=#ScrollBar] #number indentSpacing

---
-- Field indentWidth (Read only)
--
-- @field [parent=#ScrollBar] #number indentWidth

---
-- Field traversalMode
--
-- @field [parent=#ScrollBar] TraversalMode#TraversalMode traversalMode

---
-- Field elementEventSender
--
-- @field [parent=#ScrollBar] #boolean elementEventSender

---
-- Function SetTemporary
--
-- @function [parent=#ScrollBar] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#ScrollBar] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#ScrollBar] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#ScrollBar] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#ScrollBar] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#ScrollBar] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#ScrollBar] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#ScrollBar] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#ScrollBar] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#ScrollBar] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#ScrollBar] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#ScrollBar] #string category


return nil
