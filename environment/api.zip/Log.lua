---
-- Module Log
-- Module Log extends Object
-- Generated on 2014-05-31
--
-- @module Log

---
-- Function Open()
-- Open the log file.
--
-- @function [parent=#Log] Open
-- @param self Self reference
-- @param #string fileName fileName

---
-- Function Close()
-- Close the log file.
--
-- @function [parent=#Log] Close
-- @param self Self reference

---
-- Function SetLevel()
-- Set logging level.
--
-- @function [parent=#Log] SetLevel
-- @param self Self reference
-- @param #number level level

---
-- Function SetTimeStamp()
-- Set whether to timestamp log messages.
--
-- @function [parent=#Log] SetTimeStamp
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetQuiet()
-- Set quiet mode ie. only print error entries to standard error stream (which is normally redirected to console also). Output to log file is not affected by this mode.
--
-- @function [parent=#Log] SetQuiet
-- @param self Self reference
-- @param #boolean quiet quiet

---
-- Function GetLevel()
-- Return logging level.
--
-- @function [parent=#Log] GetLevel
-- @param self Self reference
-- @return #number

---
-- Function GetTimeStamp()
-- Return whether log messages are timestamped.
--
-- @function [parent=#Log] GetTimeStamp
-- @param self Self reference
-- @return #boolean

---
-- Function GetLastMessage()
-- Return last log message.
--
-- @function [parent=#Log] GetLastMessage
-- @param self Self reference
-- @return #string

---
-- Function IsQuiet()
-- Return whether log is in quiet mode (only errors printed to standard error stream).
--
-- @function [parent=#Log] IsQuiet
-- @param self Self reference
-- @return #boolean

---
-- Function Write()
-- Write to the log. If logging level is higher than the level of the message, the message is ignored.
--
-- @function [parent=#Log] Write
-- @param self Self reference
-- @param #number level level
-- @param #string message message

---
-- Function WriteRaw()
-- Write raw output to the log.
--
-- @function [parent=#Log] WriteRaw
-- @param self Self reference
-- @param #string message message
-- @param #boolean error error

---
-- Field level
--
-- @field [parent=#Log] #number level

---
-- Field timeStamp
--
-- @field [parent=#Log] #boolean timeStamp

---
-- Field quiet
--
-- @field [parent=#Log] #boolean quiet


return nil
