---
-- Module Log
-- extends Object
--
-- @module Log

---
-- Function Open
--
-- @function [parent=#Log] Open
-- @param #string fileNamefileName

---
-- Function Close
--
-- @function [parent=#Log] Close

---
-- Function SetLevel
--
-- @function [parent=#Log] SetLevel
-- @param #number levellevel

---
-- Function SetTimeStamp
--
-- @function [parent=#Log] SetTimeStamp
-- @param #boolean enableenable

---
-- Function SetQuiet
--
-- @function [parent=#Log] SetQuiet
-- @param #boolean quietquiet

---
-- Function GetLevel
--
-- @function [parent=#Log] GetLevel
-- @return #number

---
-- Function GetTimeStamp
--
-- @function [parent=#Log] GetTimeStamp
-- @return #boolean

---
-- Function GetLastMessage
--
-- @function [parent=#Log] GetLastMessage
-- @return #string

---
-- Function IsQuiet
--
-- @function [parent=#Log] IsQuiet
-- @return #boolean

---
-- Function Write
--
-- @function [parent=#Log] Write
-- @param #number levellevel
-- @param #string messagemessage

---
-- Function WriteRaw
--
-- @function [parent=#Log] WriteRaw
-- @param #string messagemessage
-- @param #boolean errorerror

---
-- Field level
--
-- @field [parent=#Log] #number level

---
-- Field timeStamp
--
-- @field [parent=#Log] #boolean timeStamp

---
-- Field quiet
--
-- @field [parent=#Log] #boolean quiet

---
-- Function GetType
--
-- @function [parent=#Log] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Log] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Log] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Log] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Log] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#Log] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Log] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Log] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Log] #string category


return nil
