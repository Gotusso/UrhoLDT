---
-- Module Log
-- Module Log extends Object
-- Generated on 2014-03-13
--
-- @module Log

---
-- Function Open
--
-- @function [parent=#Log] Open
-- @param self Self reference
-- @param #string fileName fileName

---
-- Function Close
--
-- @function [parent=#Log] Close
-- @param self Self reference

---
-- Function SetLevel
--
-- @function [parent=#Log] SetLevel
-- @param self Self reference
-- @param #number level level

---
-- Function SetTimeStamp
--
-- @function [parent=#Log] SetTimeStamp
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetQuiet
--
-- @function [parent=#Log] SetQuiet
-- @param self Self reference
-- @param #boolean quiet quiet

---
-- Function GetLevel
--
-- @function [parent=#Log] GetLevel
-- @param self Self reference
-- @return #number

---
-- Function GetTimeStamp
--
-- @function [parent=#Log] GetTimeStamp
-- @param self Self reference
-- @return #boolean

---
-- Function GetLastMessage
--
-- @function [parent=#Log] GetLastMessage
-- @param self Self reference
-- @return #string

---
-- Function IsQuiet
--
-- @function [parent=#Log] IsQuiet
-- @param self Self reference
-- @return #boolean

---
-- Function Write
--
-- @function [parent=#Log] Write
-- @param self Self reference
-- @param #number level level
-- @param #string message message

---
-- Function WriteRaw
--
-- @function [parent=#Log] WriteRaw
-- @param self Self reference
-- @param #string message message
-- @param #boolean error error

---
-- Field level
--
-- @field [parent=#Log] #number level

---
-- Field timeStamp
--
-- @field [parent=#Log] #boolean timeStamp

---
-- Field quiet
--
-- @field [parent=#Log] #boolean quiet

---
-- Function GetType
--
-- @function [parent=#Log] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Log] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Log] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Log] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Log] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#Log] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Log] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Log] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Log] #string category


return nil
