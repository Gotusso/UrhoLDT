---
-- Module File
-- Module File extends Object
-- Generated on 2014-03-13
--
-- @module File

---
-- Function File
--
-- @function [parent=#File] File
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#File] new
-- @param self Self reference
-- @return File#File

---
-- Function File
--
-- @function [parent=#File] File
-- @param self Self reference
-- @param #string fileName fileName
-- @param FileMode#FileMode mode mode

---
-- Function new
--
-- @function [parent=#File] new
-- @param self Self reference
-- @param #string fileName fileName
-- @param FileMode#FileMode mode mode
-- @return File#File

---
-- Function File
--
-- @function [parent=#File] File
-- @param self Self reference
-- @param PackageFile#PackageFile package package
-- @param #string fileName fileName

---
-- Function new
--
-- @function [parent=#File] new
-- @param self Self reference
-- @param PackageFile#PackageFile package package
-- @param #string fileName fileName
-- @return File#File

---
-- Function delete
--
-- @function [parent=#File] delete
-- @param self Self reference

---
-- Function Open
--
-- @function [parent=#File] Open
-- @param self Self reference
-- @param #string fileName fileName
-- @param FileMode#FileMode mode mode
-- @return #boolean

---
-- Function Open
--
-- @function [parent=#File] Open
-- @param self Self reference
-- @param PackageFile#PackageFile package package
-- @param #string fileName fileName
-- @return #boolean

---
-- Function Close
--
-- @function [parent=#File] Close
-- @param self Self reference

---
-- Function Flush
--
-- @function [parent=#File] Flush
-- @param self Self reference

---
-- Function SetName
--
-- @function [parent=#File] SetName
-- @param self Self reference
-- @param #string name name

---
-- Function GetMode
--
-- @function [parent=#File] GetMode
-- @param self Self reference
-- @return FileMode#FileMode

---
-- Function IsOpen
--
-- @function [parent=#File] IsOpen
-- @param self Self reference
-- @return #boolean

---
-- Function GetHandle
--
-- @function [parent=#File] GetHandle
-- @param self Self reference
-- @return void*#void*

---
-- Function IsPackaged
--
-- @function [parent=#File] IsPackaged
-- @param self Self reference
-- @return #boolean

---
-- Function Read
--
-- @function [parent=#File] Read
-- @param self Self reference
-- @param #number size size
-- @return VectorBuffer#VectorBuffer

---
-- Function Seek
--
-- @function [parent=#File] Seek
-- @param self Self reference
-- @param #number position position
-- @return #number

---
-- Function GetName
--
-- @function [parent=#File] GetName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetChecksum
--
-- @function [parent=#File] GetChecksum
-- @param self Self reference
-- @return #number

---
-- Function GetPosition
--
-- @function [parent=#File] GetPosition
-- @param self Self reference
-- @return #number

---
-- Function GetSize
--
-- @function [parent=#File] GetSize
-- @param self Self reference
-- @return #number

---
-- Function IsEof
--
-- @function [parent=#File] IsEof
-- @param self Self reference
-- @return #boolean

---
-- Function ReadInt
--
-- @function [parent=#File] ReadInt
-- @param self Self reference
-- @return #number

---
-- Function ReadShort
--
-- @function [parent=#File] ReadShort
-- @param self Self reference
-- @return short#short

---
-- Function ReadByte
--
-- @function [parent=#File] ReadByte
-- @param self Self reference
-- @return #string

---
-- Function ReadUInt
--
-- @function [parent=#File] ReadUInt
-- @param self Self reference
-- @return #number

---
-- Function ReadUShort
--
-- @function [parent=#File] ReadUShort
-- @param self Self reference
-- @return short#short

---
-- Function ReadUByte
--
-- @function [parent=#File] ReadUByte
-- @param self Self reference
-- @return #string

---
-- Function ReadBool
--
-- @function [parent=#File] ReadBool
-- @param self Self reference
-- @return #boolean

---
-- Function ReadFloat
--
-- @function [parent=#File] ReadFloat
-- @param self Self reference
-- @return #number

---
-- Function ReadIntRect
--
-- @function [parent=#File] ReadIntRect
-- @param self Self reference
-- @return IntRect#IntRect

---
-- Function ReadIntVector2
--
-- @function [parent=#File] ReadIntVector2
-- @param self Self reference
-- @return IntVector2#IntVector2

---
-- Function ReadRect
--
-- @function [parent=#File] ReadRect
-- @param self Self reference
-- @return Rect#Rect

---
-- Function ReadVector2
--
-- @function [parent=#File] ReadVector2
-- @param self Self reference
-- @return Vector2#Vector2

---
-- Function ReadVector3
--
-- @function [parent=#File] ReadVector3
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function ReadPackedVector3
--
-- @function [parent=#File] ReadPackedVector3
-- @param self Self reference
-- @param #number maxAbsCoord maxAbsCoord
-- @return Vector3#Vector3

---
-- Function ReadVector4
--
-- @function [parent=#File] ReadVector4
-- @param self Self reference
-- @return Vector4#Vector4

---
-- Function ReadQuaternion
--
-- @function [parent=#File] ReadQuaternion
-- @param self Self reference
-- @return Quaternion#Quaternion

---
-- Function ReadPackedQuaternion
--
-- @function [parent=#File] ReadPackedQuaternion
-- @param self Self reference
-- @return Quaternion#Quaternion

---
-- Function ReadColor
--
-- @function [parent=#File] ReadColor
-- @param self Self reference
-- @return Color#Color

---
-- Function ReadBoundingBox
--
-- @function [parent=#File] ReadBoundingBox
-- @param self Self reference
-- @return BoundingBox#BoundingBox

---
-- Function ReadString
--
-- @function [parent=#File] ReadString
-- @param self Self reference
-- @return #string

---
-- Function ReadFileID
--
-- @function [parent=#File] ReadFileID
-- @param self Self reference
-- @return #string

---
-- Function ReadStringHash
--
-- @function [parent=#File] ReadStringHash
-- @param self Self reference
-- @return StringHash#StringHash

---
-- Function ReadShortStringHash
--
-- @function [parent=#File] ReadShortStringHash
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function ReadBuffer
--
-- @function [parent=#File] ReadBuffer
-- @param self Self reference
-- @return VectorBuffer#VectorBuffer

---
-- Function ReadResourceRef
--
-- @function [parent=#File] ReadResourceRef
-- @param self Self reference
-- @return ResourceRef#ResourceRef

---
-- Function ReadResourceRefList
--
-- @function [parent=#File] ReadResourceRefList
-- @param self Self reference
-- @return ResourceRefList#ResourceRefList

---
-- Function ReadVariant
--
-- @function [parent=#File] ReadVariant
-- @param self Self reference
-- @return Variant#Variant

---
-- Function ReadVariant
--
-- @function [parent=#File] ReadVariant
-- @param self Self reference
-- @param VariantType#VariantType type type
-- @return Variant#Variant

---
-- Function ReadVariantVector
--
-- @function [parent=#File] ReadVariantVector
-- @param self Self reference
-- @return VariantVector#VariantVector

---
-- Function ReadVariantMap
--
-- @function [parent=#File] ReadVariantMap
-- @param self Self reference
-- @return VariantMap#VariantMap

---
-- Function ReadVLE
--
-- @function [parent=#File] ReadVLE
-- @param self Self reference
-- @return #number

---
-- Function ReadNetID
--
-- @function [parent=#File] ReadNetID
-- @param self Self reference
-- @return #number

---
-- Function ReadLine
--
-- @function [parent=#File] ReadLine
-- @param self Self reference
-- @return #string

---
-- Function Write
--
-- @function [parent=#File] Write
-- @param self Self reference
-- @param VectorBuffer#VectorBuffer buffer buffer
-- @return #number

---
-- Function WriteInt
--
-- @function [parent=#File] WriteInt
-- @param self Self reference
-- @param #number value value
-- @return #boolean

---
-- Function WriteShort
--
-- @function [parent=#File] WriteShort
-- @param self Self reference
-- @param short#short value value
-- @return #boolean

---
-- Function WriteByte
--
-- @function [parent=#File] WriteByte
-- @param self Self reference
-- @param #string value value
-- @return #boolean

---
-- Function WriteUInt
--
-- @function [parent=#File] WriteUInt
-- @param self Self reference
-- @param #number value value
-- @return #boolean

---
-- Function WriteUShort
--
-- @function [parent=#File] WriteUShort
-- @param self Self reference
-- @param short#short value value
-- @return #boolean

---
-- Function WriteUByte
--
-- @function [parent=#File] WriteUByte
-- @param self Self reference
-- @param #string value value
-- @return #boolean

---
-- Function WriteBool
--
-- @function [parent=#File] WriteBool
-- @param self Self reference
-- @param #boolean value value
-- @return #boolean

---
-- Function WriteFloat
--
-- @function [parent=#File] WriteFloat
-- @param self Self reference
-- @param #number value value
-- @return #boolean

---
-- Function WriteIntRect
--
-- @function [parent=#File] WriteIntRect
-- @param self Self reference
-- @param IntRect#IntRect value value
-- @return #boolean

---
-- Function WriteIntVector2
--
-- @function [parent=#File] WriteIntVector2
-- @param self Self reference
-- @param IntVector2#IntVector2 value value
-- @return #boolean

---
-- Function WriteRect
--
-- @function [parent=#File] WriteRect
-- @param self Self reference
-- @param Rect#Rect value value
-- @return #boolean

---
-- Function WriteVector2
--
-- @function [parent=#File] WriteVector2
-- @param self Self reference
-- @param Vector2#Vector2 value value
-- @return #boolean

---
-- Function WriteVector3
--
-- @function [parent=#File] WriteVector3
-- @param self Self reference
-- @param Vector3#Vector3 value value
-- @return #boolean

---
-- Function WritePackedVector3
--
-- @function [parent=#File] WritePackedVector3
-- @param self Self reference
-- @param Vector3#Vector3 value value
-- @param #number maxAbsCoord maxAbsCoord
-- @return #boolean

---
-- Function WriteVector4
--
-- @function [parent=#File] WriteVector4
-- @param self Self reference
-- @param Vector4#Vector4 value value
-- @return #boolean

---
-- Function WriteQuaternion
--
-- @function [parent=#File] WriteQuaternion
-- @param self Self reference
-- @param Quaternion#Quaternion value value
-- @return #boolean

---
-- Function WritePackedQuaternion
--
-- @function [parent=#File] WritePackedQuaternion
-- @param self Self reference
-- @param Quaternion#Quaternion value value
-- @return #boolean

---
-- Function WriteColor
--
-- @function [parent=#File] WriteColor
-- @param self Self reference
-- @param Color#Color value value
-- @return #boolean

---
-- Function WriteBoundingBox
--
-- @function [parent=#File] WriteBoundingBox
-- @param self Self reference
-- @param BoundingBox#BoundingBox value value
-- @return #boolean

---
-- Function WriteString
--
-- @function [parent=#File] WriteString
-- @param self Self reference
-- @param #string value value
-- @return #boolean

---
-- Function WriteFileID
--
-- @function [parent=#File] WriteFileID
-- @param self Self reference
-- @param #string value value
-- @return #boolean

---
-- Function WriteStringHash
--
-- @function [parent=#File] WriteStringHash
-- @param self Self reference
-- @param StringHash#StringHash value value
-- @return #boolean

---
-- Function WriteShortStringHash
--
-- @function [parent=#File] WriteShortStringHash
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash value value
-- @return #boolean

---
-- Function WriteBuffer
--
-- @function [parent=#File] WriteBuffer
-- @param self Self reference
-- @param VectorBuffer#VectorBuffer buffer buffer
-- @return #boolean

---
-- Function WriteResourceRef
--
-- @function [parent=#File] WriteResourceRef
-- @param self Self reference
-- @param ResourceRef#ResourceRef value value
-- @return #boolean

---
-- Function WriteResourceRefList
--
-- @function [parent=#File] WriteResourceRefList
-- @param self Self reference
-- @param ResourceRefList#ResourceRefList value value
-- @return #boolean

---
-- Function WriteVariant
--
-- @function [parent=#File] WriteVariant
-- @param self Self reference
-- @param Variant#Variant value value
-- @return #boolean

---
-- Function WriteVariantData
--
-- @function [parent=#File] WriteVariantData
-- @param self Self reference
-- @param Variant#Variant value value
-- @return #boolean

---
-- Function WriteVariantVector
--
-- @function [parent=#File] WriteVariantVector
-- @param self Self reference
-- @param VariantVector#VariantVector value value
-- @return #boolean

---
-- Function WriteVariantMap
--
-- @function [parent=#File] WriteVariantMap
-- @param self Self reference
-- @param VariantMap#VariantMap value value
-- @return #boolean

---
-- Function WriteVLE
--
-- @function [parent=#File] WriteVLE
-- @param self Self reference
-- @param #number value value
-- @return #boolean

---
-- Function WriteNetID
--
-- @function [parent=#File] WriteNetID
-- @param self Self reference
-- @param #number value value
-- @return #boolean

---
-- Function WriteLine
--
-- @function [parent=#File] WriteLine
-- @param self Self reference
-- @param #string value value
-- @return #boolean

---
-- Field mode (Read only)
--
-- @field [parent=#File] FileMode#FileMode mode

---
-- Field open (Read only)
--
-- @field [parent=#File] #boolean open

---
-- Field packaged (Read only)
--
-- @field [parent=#File] #boolean packaged

---
-- Field name (Read only)
--
-- @field [parent=#File] #string name

---
-- Field checksum (Read only)
--
-- @field [parent=#File] #number checksum

---
-- Field position (Read only)
--
-- @field [parent=#File] #number position

---
-- Field size (Read only)
--
-- @field [parent=#File] #number size

---
-- Field eof (Read only)
--
-- @field [parent=#File] #boolean eof

---
-- Function GetType
--
-- @function [parent=#File] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#File] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#File] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#File] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#File] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#File] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#File] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#File] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#File] #string category


return nil
