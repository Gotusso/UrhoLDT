---
-- Module File
-- Extends Object
--
-- @module File

---
-- Function File
--
-- @function [parent=#File] File

---
-- Function new
--
-- @function [parent=#File] new
-- @return File#File

---
-- Function File
--
-- @function [parent=#File] File
-- @param #string fileNamefileName
-- @param FileMode#FileMode modemode

---
-- Function new
--
-- @function [parent=#File] new
-- @param #string fileNamefileName
-- @param FileMode#FileMode modemode
-- @return File#File

---
-- Function File
--
-- @function [parent=#File] File
-- @param PackageFile#PackageFile packagepackage
-- @param #string fileNamefileName

---
-- Function new
--
-- @function [parent=#File] new
-- @param PackageFile#PackageFile packagepackage
-- @param #string fileNamefileName
-- @return File#File

---
-- Function delete
--
-- @function [parent=#File] delete

---
-- Function Open
--
-- @function [parent=#File] Open
-- @param #string fileNamefileName
-- @param FileMode#FileMode modemode
-- @return #boolean

---
-- Function Open
--
-- @function [parent=#File] Open
-- @param PackageFile#PackageFile packagepackage
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function Close
--
-- @function [parent=#File] Close

---
-- Function Flush
--
-- @function [parent=#File] Flush

---
-- Function SetName
--
-- @function [parent=#File] SetName
-- @param #string namename

---
-- Function GetMode
--
-- @function [parent=#File] GetMode
-- @return FileMode#FileMode

---
-- Function IsOpen
--
-- @function [parent=#File] IsOpen
-- @return #boolean

---
-- Function GetHandle
--
-- @function [parent=#File] GetHandle
-- @return void*#void*

---
-- Function IsPackaged
--
-- @function [parent=#File] IsPackaged
-- @return #boolean

---
-- Function Read
--
-- @function [parent=#File] Read
-- @param #number sizesize
-- @return VectorBuffer#VectorBuffer

---
-- Function Seek
--
-- @function [parent=#File] Seek
-- @param #number positionposition
-- @return #number

---
-- Function GetName
--
-- @function [parent=#File] GetName
-- @return const String#const String

---
-- Function GetChecksum
--
-- @function [parent=#File] GetChecksum
-- @return #number

---
-- Function GetPosition
--
-- @function [parent=#File] GetPosition
-- @return #number

---
-- Function GetSize
--
-- @function [parent=#File] GetSize
-- @return #number

---
-- Function IsEof
--
-- @function [parent=#File] IsEof
-- @return #boolean

---
-- Function ReadInt
--
-- @function [parent=#File] ReadInt
-- @return #number

---
-- Function ReadShort
--
-- @function [parent=#File] ReadShort
-- @return short#short

---
-- Function ReadByte
--
-- @function [parent=#File] ReadByte
-- @return #string

---
-- Function ReadUInt
--
-- @function [parent=#File] ReadUInt
-- @return #number

---
-- Function ReadUShort
--
-- @function [parent=#File] ReadUShort
-- @return short#short

---
-- Function ReadUByte
--
-- @function [parent=#File] ReadUByte
-- @return #string

---
-- Function ReadBool
--
-- @function [parent=#File] ReadBool
-- @return #boolean

---
-- Function ReadFloat
--
-- @function [parent=#File] ReadFloat
-- @return #number

---
-- Function ReadIntRect
--
-- @function [parent=#File] ReadIntRect
-- @return IntRect#IntRect

---
-- Function ReadIntVector2
--
-- @function [parent=#File] ReadIntVector2
-- @return IntVector2#IntVector2

---
-- Function ReadRect
--
-- @function [parent=#File] ReadRect
-- @return Rect#Rect

---
-- Function ReadVector2
--
-- @function [parent=#File] ReadVector2
-- @return Vector2#Vector2

---
-- Function ReadVector3
--
-- @function [parent=#File] ReadVector3
-- @return Vector3#Vector3

---
-- Function ReadPackedVector3
--
-- @function [parent=#File] ReadPackedVector3
-- @param #number maxAbsCoordmaxAbsCoord
-- @return Vector3#Vector3

---
-- Function ReadVector4
--
-- @function [parent=#File] ReadVector4
-- @return Vector4#Vector4

---
-- Function ReadQuaternion
--
-- @function [parent=#File] ReadQuaternion
-- @return Quaternion#Quaternion

---
-- Function ReadPackedQuaternion
--
-- @function [parent=#File] ReadPackedQuaternion
-- @return Quaternion#Quaternion

---
-- Function ReadColor
--
-- @function [parent=#File] ReadColor
-- @return Color#Color

---
-- Function ReadBoundingBox
--
-- @function [parent=#File] ReadBoundingBox
-- @return BoundingBox#BoundingBox

---
-- Function ReadString
--
-- @function [parent=#File] ReadString
-- @return #string

---
-- Function ReadFileID
--
-- @function [parent=#File] ReadFileID
-- @return #string

---
-- Function ReadStringHash
--
-- @function [parent=#File] ReadStringHash
-- @return StringHash#StringHash

---
-- Function ReadShortStringHash
--
-- @function [parent=#File] ReadShortStringHash
-- @return ShortStringHash#ShortStringHash

---
-- Function ReadBuffer
--
-- @function [parent=#File] ReadBuffer
-- @return VectorBuffer#VectorBuffer

---
-- Function ReadResourceRef
--
-- @function [parent=#File] ReadResourceRef
-- @return ResourceRef#ResourceRef

---
-- Function ReadResourceRefList
--
-- @function [parent=#File] ReadResourceRefList
-- @return ResourceRefList#ResourceRefList

---
-- Function ReadVariant
--
-- @function [parent=#File] ReadVariant
-- @return Variant#Variant

---
-- Function ReadVariant
--
-- @function [parent=#File] ReadVariant
-- @param VariantType#VariantType typetype
-- @return Variant#Variant

---
-- Function ReadVariantVector
--
-- @function [parent=#File] ReadVariantVector
-- @return VariantVector#VariantVector

---
-- Function ReadVariantMap
--
-- @function [parent=#File] ReadVariantMap
-- @return VariantMap#VariantMap

---
-- Function ReadVLE
--
-- @function [parent=#File] ReadVLE
-- @return #number

---
-- Function ReadNetID
--
-- @function [parent=#File] ReadNetID
-- @return #number

---
-- Function ReadLine
--
-- @function [parent=#File] ReadLine
-- @return #string

---
-- Function Write
--
-- @function [parent=#File] Write
-- @param VectorBuffer#VectorBuffer bufferbuffer
-- @return #number

---
-- Function WriteInt
--
-- @function [parent=#File] WriteInt
-- @param #number valuevalue
-- @return #boolean

---
-- Function WriteShort
--
-- @function [parent=#File] WriteShort
-- @param short#short valuevalue
-- @return #boolean

---
-- Function WriteByte
--
-- @function [parent=#File] WriteByte
-- @param #string valuevalue
-- @return #boolean

---
-- Function WriteUInt
--
-- @function [parent=#File] WriteUInt
-- @param #number valuevalue
-- @return #boolean

---
-- Function WriteUShort
--
-- @function [parent=#File] WriteUShort
-- @param short#short valuevalue
-- @return #boolean

---
-- Function WriteUByte
--
-- @function [parent=#File] WriteUByte
-- @param #string valuevalue
-- @return #boolean

---
-- Function WriteBool
--
-- @function [parent=#File] WriteBool
-- @param #boolean valuevalue
-- @return #boolean

---
-- Function WriteFloat
--
-- @function [parent=#File] WriteFloat
-- @param #number valuevalue
-- @return #boolean

---
-- Function WriteIntRect
--
-- @function [parent=#File] WriteIntRect
-- @param IntRect#IntRect valuevalue
-- @return #boolean

---
-- Function WriteIntVector2
--
-- @function [parent=#File] WriteIntVector2
-- @param IntVector2#IntVector2 valuevalue
-- @return #boolean

---
-- Function WriteRect
--
-- @function [parent=#File] WriteRect
-- @param Rect#Rect valuevalue
-- @return #boolean

---
-- Function WriteVector2
--
-- @function [parent=#File] WriteVector2
-- @param Vector2#Vector2 valuevalue
-- @return #boolean

---
-- Function WriteVector3
--
-- @function [parent=#File] WriteVector3
-- @param Vector3#Vector3 valuevalue
-- @return #boolean

---
-- Function WritePackedVector3
--
-- @function [parent=#File] WritePackedVector3
-- @param Vector3#Vector3 valuevalue
-- @param #number maxAbsCoordmaxAbsCoord
-- @return #boolean

---
-- Function WriteVector4
--
-- @function [parent=#File] WriteVector4
-- @param Vector4#Vector4 valuevalue
-- @return #boolean

---
-- Function WriteQuaternion
--
-- @function [parent=#File] WriteQuaternion
-- @param Quaternion#Quaternion valuevalue
-- @return #boolean

---
-- Function WritePackedQuaternion
--
-- @function [parent=#File] WritePackedQuaternion
-- @param Quaternion#Quaternion valuevalue
-- @return #boolean

---
-- Function WriteColor
--
-- @function [parent=#File] WriteColor
-- @param Color#Color valuevalue
-- @return #boolean

---
-- Function WriteBoundingBox
--
-- @function [parent=#File] WriteBoundingBox
-- @param BoundingBox#BoundingBox valuevalue
-- @return #boolean

---
-- Function WriteString
--
-- @function [parent=#File] WriteString
-- @param #string valuevalue
-- @return #boolean

---
-- Function WriteFileID
--
-- @function [parent=#File] WriteFileID
-- @param #string valuevalue
-- @return #boolean

---
-- Function WriteStringHash
--
-- @function [parent=#File] WriteStringHash
-- @param StringHash#StringHash valuevalue
-- @return #boolean

---
-- Function WriteShortStringHash
--
-- @function [parent=#File] WriteShortStringHash
-- @param ShortStringHash#ShortStringHash valuevalue
-- @return #boolean

---
-- Function WriteBuffer
--
-- @function [parent=#File] WriteBuffer
-- @param VectorBuffer#VectorBuffer bufferbuffer
-- @return #boolean

---
-- Function WriteResourceRef
--
-- @function [parent=#File] WriteResourceRef
-- @param ResourceRef#ResourceRef valuevalue
-- @return #boolean

---
-- Function WriteResourceRefList
--
-- @function [parent=#File] WriteResourceRefList
-- @param ResourceRefList#ResourceRefList valuevalue
-- @return #boolean

---
-- Function WriteVariant
--
-- @function [parent=#File] WriteVariant
-- @param Variant#Variant valuevalue
-- @return #boolean

---
-- Function WriteVariantData
--
-- @function [parent=#File] WriteVariantData
-- @param Variant#Variant valuevalue
-- @return #boolean

---
-- Function WriteVariantVector
--
-- @function [parent=#File] WriteVariantVector
-- @param VariantVector#VariantVector valuevalue
-- @return #boolean

---
-- Function WriteVariantMap
--
-- @function [parent=#File] WriteVariantMap
-- @param VariantMap#VariantMap valuevalue
-- @return #boolean

---
-- Function WriteVLE
--
-- @function [parent=#File] WriteVLE
-- @param #number valuevalue
-- @return #boolean

---
-- Function WriteNetID
--
-- @function [parent=#File] WriteNetID
-- @param #number valuevalue
-- @return #boolean

---
-- Function WriteLine
--
-- @function [parent=#File] WriteLine
-- @param #string valuevalue
-- @return #boolean

---
-- Field mode (Read only)
--
-- @field [parent=#File] FileMode#FileMode mode

---
-- Field open (Read only)
--
-- @field [parent=#File] #boolean open

---
-- Field packaged (Read only)
--
-- @field [parent=#File] #boolean packaged

---
-- Field name (Read only)
--
-- @field [parent=#File] #string name

---
-- Field checksum (Read only)
--
-- @field [parent=#File] #number checksum

---
-- Field position (Read only)
--
-- @field [parent=#File] #number position

---
-- Field size (Read only)
--
-- @field [parent=#File] #number size

---
-- Field eof (Read only)
--
-- @field [parent=#File] #boolean eof


return nil
