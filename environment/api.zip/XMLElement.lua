---
-- Module XMLElement
--
-- @module XMLElement

---
-- Function CreateChild
--
-- @function [parent=#XMLElement] CreateChild
-- @param #string namename
-- @return XMLElement#XMLElement

---
-- Function RemoveChild
--
-- @function [parent=#XMLElement] RemoveChild
-- @param XMLElement#XMLElement elementelement
-- @return #boolean

---
-- Function RemoveChild
--
-- @function [parent=#XMLElement] RemoveChild
-- @param #string namename
-- @return #boolean

---
-- Function RemoveChildren
--
-- @function [parent=#XMLElement] RemoveChildren
-- @param #string namename
-- @return #boolean

---
-- Function RemoveAttribute
--
-- @function [parent=#XMLElement] RemoveAttribute
-- @param #string namename
-- @return #boolean

---
-- Function SetValue
--
-- @function [parent=#XMLElement] SetValue
-- @param #string valuevalue
-- @return #boolean

---
-- Function SetAttribute
--
-- @function [parent=#XMLElement] SetAttribute
-- @param #string namename
-- @param #string valuevalue
-- @return #boolean

---
-- Function SetBool
--
-- @function [parent=#XMLElement] SetBool
-- @param #string namename
-- @param #boolean valuevalue
-- @return #boolean

---
-- Function SetBoundingBox
--
-- @function [parent=#XMLElement] SetBoundingBox
-- @param BoundingBox#BoundingBox valuevalue
-- @return #boolean

---
-- Function SetColor
--
-- @function [parent=#XMLElement] SetColor
-- @param #string namename
-- @param Color#Color valuevalue
-- @return #boolean

---
-- Function SetFloat
--
-- @function [parent=#XMLElement] SetFloat
-- @param #string namename
-- @param #number valuevalue
-- @return #boolean

---
-- Function SetUInt
--
-- @function [parent=#XMLElement] SetUInt
-- @param #string namename
-- @param #number valuevalue
-- @return #boolean

---
-- Function SetInt
--
-- @function [parent=#XMLElement] SetInt
-- @param #string namename
-- @param #number valuevalue
-- @return #boolean

---
-- Function SetIntRect
--
-- @function [parent=#XMLElement] SetIntRect
-- @param #string namename
-- @param IntRect#IntRect valuevalue
-- @return #boolean

---
-- Function SetIntVector2
--
-- @function [parent=#XMLElement] SetIntVector2
-- @param #string namename
-- @param IntVector2#IntVector2 valuevalue
-- @return #boolean

---
-- Function SetRect
--
-- @function [parent=#XMLElement] SetRect
-- @param #string namename
-- @param Rect#Rect valuevalue
-- @return #boolean

---
-- Function SetQuaternion
--
-- @function [parent=#XMLElement] SetQuaternion
-- @param #string namename
-- @param Quaternion#Quaternion valuevalue
-- @return #boolean

---
-- Function SetString
--
-- @function [parent=#XMLElement] SetString
-- @param #string namename
-- @param #string valuevalue
-- @return #boolean

---
-- Function SetVariant
--
-- @function [parent=#XMLElement] SetVariant
-- @param Variant#Variant valuevalue
-- @return #boolean

---
-- Function SetVariantValue
--
-- @function [parent=#XMLElement] SetVariantValue
-- @param Variant#Variant valuevalue
-- @return #boolean

---
-- Function SetResourceRef
--
-- @function [parent=#XMLElement] SetResourceRef
-- @param ResourceRef#ResourceRef valuevalue
-- @return #boolean

---
-- Function SetResourceRefList
--
-- @function [parent=#XMLElement] SetResourceRefList
-- @param ResourceRefList#ResourceRefList valuevalue
-- @return #boolean

---
-- Function SetVector2
--
-- @function [parent=#XMLElement] SetVector2
-- @param #string namename
-- @param Vector2#Vector2 valuevalue
-- @return #boolean

---
-- Function SetVector3
--
-- @function [parent=#XMLElement] SetVector3
-- @param #string namename
-- @param Vector3#Vector3 valuevalue
-- @return #boolean

---
-- Function SetVector4
--
-- @function [parent=#XMLElement] SetVector4
-- @param #string namename
-- @param Vector4#Vector4 valuevalue
-- @return #boolean

---
-- Function SetVectorVariant
--
-- @function [parent=#XMLElement] SetVectorVariant
-- @param #string namename
-- @param Variant#Variant valuevalue
-- @return #boolean

---
-- Function IsNull
--
-- @function [parent=#XMLElement] IsNull
-- @return #boolean

---
-- Function NotNull
--
-- @function [parent=#XMLElement] NotNull
-- @return #boolean

---
-- Function operatorbool
--
-- @function [parent=#XMLElement] operatorbool
-- @return #boolean

---
-- Function GetName
--
-- @function [parent=#XMLElement] GetName
-- @return #string

---
-- Function HasChild
--
-- @function [parent=#XMLElement] HasChild
-- @param #string namename
-- @return #boolean

---
-- Function GetChild
--
-- @function [parent=#XMLElement] GetChild
-- @param #string namename
-- @return XMLElement#XMLElement

---
-- Function GetNext
--
-- @function [parent=#XMLElement] GetNext
-- @param #string namename
-- @return XMLElement#XMLElement

---
-- Function GetParent
--
-- @function [parent=#XMLElement] GetParent
-- @return XMLElement#XMLElement

---
-- Function GetNumAttributes
--
-- @function [parent=#XMLElement] GetNumAttributes
-- @return #number

---
-- Function HasAttribute
--
-- @function [parent=#XMLElement] HasAttribute
-- @param #string namename
-- @return #boolean

---
-- Function GetBool
--
-- @function [parent=#XMLElement] GetBool
-- @param #string namename
-- @return #boolean

---
-- Function GetBoundingBox
--
-- @function [parent=#XMLElement] GetBoundingBox
-- @return BoundingBox#BoundingBox

---
-- Function GetValue
--
-- @function [parent=#XMLElement] GetValue
-- @return #string

---
-- Function GetColor
--
-- @function [parent=#XMLElement] GetColor
-- @param #string namename
-- @return Color#Color

---
-- Function GetFloat
--
-- @function [parent=#XMLElement] GetFloat
-- @param #string namename
-- @return #number

---
-- Function GetUInt
--
-- @function [parent=#XMLElement] GetUInt
-- @param #string namename
-- @return #number

---
-- Function GetInt
--
-- @function [parent=#XMLElement] GetInt
-- @param #string namename
-- @return #number

---
-- Function GetIntRect
--
-- @function [parent=#XMLElement] GetIntRect
-- @param #string namename
-- @return IntRect#IntRect

---
-- Function GetIntVector2
--
-- @function [parent=#XMLElement] GetIntVector2
-- @param #string namename
-- @return IntVector2#IntVector2

---
-- Function GetRect
--
-- @function [parent=#XMLElement] GetRect
-- @param #string namename
-- @return Rect#Rect

---
-- Function GetQuaternion
--
-- @function [parent=#XMLElement] GetQuaternion
-- @param #string namename
-- @return Quaternion#Quaternion

---
-- Function GetVariant
--
-- @function [parent=#XMLElement] GetVariant
-- @return Variant#Variant

---
-- Function GetVariantValue
--
-- @function [parent=#XMLElement] GetVariantValue
-- @param VariantType#VariantType typetype
-- @return Variant#Variant

---
-- Function GetResourceRef
--
-- @function [parent=#XMLElement] GetResourceRef
-- @return ResourceRef#ResourceRef

---
-- Function GetResourceRefList
--
-- @function [parent=#XMLElement] GetResourceRefList
-- @return ResourceRefList#ResourceRefList

---
-- Function GetVariantMap
--
-- @function [parent=#XMLElement] GetVariantMap
-- @return VariantMap#VariantMap

---
-- Function GetVector2
--
-- @function [parent=#XMLElement] GetVector2
-- @param #string namename
-- @return Vector2#Vector2

---
-- Function GetVector3
--
-- @function [parent=#XMLElement] GetVector3
-- @param #string namename
-- @return Vector3#Vector3

---
-- Function GetVector4
--
-- @function [parent=#XMLElement] GetVector4
-- @param #string namename
-- @return Vector4#Vector4

---
-- Function GetVector
--
-- @function [parent=#XMLElement] GetVector
-- @param #string namename
-- @return Vector4#Vector4

---
-- Function GetFile
--
-- @function [parent=#XMLElement] GetFile
-- @return XMLFile#XMLFile

---
-- Field EMPTY
--
-- @field [parent=#XMLElement] XMLElement#XMLElement EMPTY

---
-- Field null (Read only)
--
-- @field [parent=#XMLElement] #boolean null

---
-- Field name (Read only)
--
-- @field [parent=#XMLElement] #string name

---
-- Field value (Read only)
--
-- @field [parent=#XMLElement] #string value

---
-- Field parent (Read only)
--
-- @field [parent=#XMLElement] XMLElement#XMLElement parent

---
-- Field numAttributes (Read only)
--
-- @field [parent=#XMLElement] #number numAttributes

---
-- Field file (Read only)
--
-- @field [parent=#XMLElement] XMLFile#XMLFile file


return nil
