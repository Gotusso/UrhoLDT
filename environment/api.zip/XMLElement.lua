---
-- Module XMLElement
-- Generated on 2014-05-31
--
-- @module XMLElement

---
-- Function CreateChild()
-- Create a child element.
--
-- @function [parent=#XMLElement] CreateChild
-- @param self Self reference
-- @param #string name name
-- @return XMLElement#XMLElement

---
-- Function RemoveChild()
-- Remove a child element. Return true if successful.
--
-- @function [parent=#XMLElement] RemoveChild
-- @param self Self reference
-- @param XMLElement#XMLElement element element
-- @return #boolean

---
-- Function RemoveChild()
-- Remove a child element by name. Return true if successful.
--
-- @function [parent=#XMLElement] RemoveChild
-- @param self Self reference
-- @param #string name name
-- @return #boolean

---
-- Function RemoveChildren()
-- Remove child elements of certain name, or all child elements if name is empty. Return true if successful.
--
-- @function [parent=#XMLElement] RemoveChildren
-- @param self Self reference
-- @param #string name name
-- @return #boolean

---
-- Function RemoveAttribute()
-- Remove an attribute by name. Return true if successful.
--
-- @function [parent=#XMLElement] RemoveAttribute
-- @param self Self reference
-- @param #string name name
-- @return #boolean

---
-- Function SetValue()
-- Set the value for an inner node in the following format <node>value</node>.
--
-- @function [parent=#XMLElement] SetValue
-- @param self Self reference
-- @param #string value value
-- @return #boolean

---
-- Function SetAttribute()
-- Set an attribute.
-- Set an attribute. Only valid if it is an attribute only XPath query result.
--
-- @function [parent=#XMLElement] SetAttribute
-- @param self Self reference
-- @param #string name name
-- @param #string value value
-- @return #boolean

---
-- Function SetAttribute()
--
-- @function [parent=#XMLElement] SetAttribute
-- @param self Self reference
-- @param #string value value
-- @return #boolean

---
-- Function SetBool()
-- Set a bool attribute.
--
-- @function [parent=#XMLElement] SetBool
-- @param self Self reference
-- @param #string name name
-- @param #boolean value value
-- @return #boolean

---
-- Function SetBoundingBox()
-- Set a BoundingBox attribute.
--
-- @function [parent=#XMLElement] SetBoundingBox
-- @param self Self reference
-- @param BoundingBox#BoundingBox value value
-- @return #boolean

---
-- Function SetColor()
-- Set a color attribute.
--
-- @function [parent=#XMLElement] SetColor
-- @param self Self reference
-- @param #string name name
-- @param Color#Color value value
-- @return #boolean

---
-- Function SetFloat()
-- Set a float attribute.
--
-- @function [parent=#XMLElement] SetFloat
-- @param self Self reference
-- @param #string name name
-- @param #number value value
-- @return #boolean

---
-- Function SetUInt()
-- Set an unsigned integer attribute.
--
-- @function [parent=#XMLElement] SetUInt
-- @param self Self reference
-- @param #string name name
-- @param #number value value
-- @return #boolean

---
-- Function SetInt()
-- Set an integer attribute.
--
-- @function [parent=#XMLElement] SetInt
-- @param self Self reference
-- @param #string name name
-- @param #number value value
-- @return #boolean

---
-- Function SetIntRect()
-- Set an IntRect attribute.
--
-- @function [parent=#XMLElement] SetIntRect
-- @param self Self reference
-- @param #string name name
-- @param IntRect#IntRect value value
-- @return #boolean

---
-- Function SetIntVector2()
-- Set an IntVector2 attribute.
--
-- @function [parent=#XMLElement] SetIntVector2
-- @param self Self reference
-- @param #string name name
-- @param IntVector2#IntVector2 value value
-- @return #boolean

---
-- Function SetRect()
-- Set a Rect attribute.
--
-- @function [parent=#XMLElement] SetRect
-- @param self Self reference
-- @param #string name name
-- @param Rect#Rect value value
-- @return #boolean

---
-- Function SetQuaternion()
-- Set a quaternion attribute.
--
-- @function [parent=#XMLElement] SetQuaternion
-- @param self Self reference
-- @param #string name name
-- @param Quaternion#Quaternion value value
-- @return #boolean

---
-- Function SetString()
-- Set a string attribute.
--
-- @function [parent=#XMLElement] SetString
-- @param self Self reference
-- @param #string name name
-- @param #string value value
-- @return #boolean

---
-- Function SetVariant()
-- Set a variant attribute.
--
-- @function [parent=#XMLElement] SetVariant
-- @param self Self reference
-- @param Variant#Variant value value
-- @return #boolean

---
-- Function SetVariantValue()
-- Set a variant attribute excluding the type.
--
-- @function [parent=#XMLElement] SetVariantValue
-- @param self Self reference
-- @param Variant#Variant value value
-- @return #boolean

---
-- Function SetResourceRef()
-- Set a resource reference attribute.
--
-- @function [parent=#XMLElement] SetResourceRef
-- @param self Self reference
-- @param ResourceRef#ResourceRef value value
-- @return #boolean

---
-- Function SetResourceRefList()
-- Set a resource referene list attribute.
--
-- @function [parent=#XMLElement] SetResourceRefList
-- @param self Self reference
-- @param ResourceRefList#ResourceRefList value value
-- @return #boolean

---
-- Function SetVector2()
-- Set a Vector2 attribute.
--
-- @function [parent=#XMLElement] SetVector2
-- @param self Self reference
-- @param #string name name
-- @param Vector2#Vector2 value value
-- @return #boolean

---
-- Function SetVector3()
-- Set a Vector3 attribute.
--
-- @function [parent=#XMLElement] SetVector3
-- @param self Self reference
-- @param #string name name
-- @param Vector3#Vector3 value value
-- @return #boolean

---
-- Function SetVector4()
-- Set a Vector4 attribute.
--
-- @function [parent=#XMLElement] SetVector4
-- @param self Self reference
-- @param #string name name
-- @param Vector4#Vector4 value value
-- @return #boolean

---
-- Function SetVectorVariant()
-- Set a float, Vector or Matrix attribute stored in a variant.
--
-- @function [parent=#XMLElement] SetVectorVariant
-- @param self Self reference
-- @param #string name name
-- @param Variant#Variant value value
-- @return #boolean

---
-- Function SetMatrix3()
-- Set a Matrix3 attribute.
--
-- @function [parent=#XMLElement] SetMatrix3
-- @param self Self reference
-- @param #string name name
-- @param Matrix3#Matrix3 value value
-- @return #boolean

---
-- Function SetMatrix3x4()
-- Set a Matrix3x4 attribute.
--
-- @function [parent=#XMLElement] SetMatrix3x4
-- @param self Self reference
-- @param #string name name
-- @param Matrix3x4#Matrix3x4 value value
-- @return #boolean

---
-- Function SetMatrix4()
-- Set a Matrix4 attribute.
--
-- @function [parent=#XMLElement] SetMatrix4
-- @param self Self reference
-- @param #string name name
-- @param Matrix4#Matrix4 value value
-- @return #boolean

---
-- Function IsNull()
-- Return whether does not refer to an element or an XPath node.
--
-- @function [parent=#XMLElement] IsNull
-- @param self Self reference
-- @return #boolean

---
-- Function NotNull()
-- Return whether refers to an element or an XPath node.
--
-- @function [parent=#XMLElement] NotNull
-- @param self Self reference
-- @return #boolean

---
-- Function operatorbool()
--
-- @function [parent=#XMLElement] operatorbool
-- @param self Self reference
-- @return #boolean

---
-- Function GetName()
-- Return element name (or attribute name if it is an attribute only XPath query result).
--
-- @function [parent=#XMLElement] GetName
-- @param self Self reference
-- @return #string

---
-- Function HasChild()
-- Return whether has a child element.
--
-- @function [parent=#XMLElement] HasChild
-- @param self Self reference
-- @param #string name name
-- @return #boolean

---
-- Function GetChild()
-- Return child element, or null if missing.
--
-- @function [parent=#XMLElement] GetChild
-- @param self Self reference
-- @param #string name name
-- @return XMLElement#XMLElement

---
-- Function GetNext()
-- Return next sibling element.
--
-- @function [parent=#XMLElement] GetNext
-- @param self Self reference
-- @param #string name name
-- @return XMLElement#XMLElement

---
-- Function GetParent()
-- Return parent element.
--
-- @function [parent=#XMLElement] GetParent
-- @param self Self reference
-- @return XMLElement#XMLElement

---
-- Function GetNumAttributes()
-- Return number of attributes.
--
-- @function [parent=#XMLElement] GetNumAttributes
-- @param self Self reference
-- @return #number

---
-- Function HasAttribute()
-- Return whether has an attribute.
--
-- @function [parent=#XMLElement] HasAttribute
-- @param self Self reference
-- @param #string name name
-- @return #boolean

---
-- Function GetValue()
-- Return inner value, or empty if missing for nodes like <node>value</node>
--
-- @function [parent=#XMLElement] GetValue
-- @param self Self reference
-- @return #string

---
-- Function GetAttribute()
-- Return attribute, or empty if missing.
--
-- @function [parent=#XMLElement] GetAttribute
-- @param self Self reference
-- @param #string name name
-- @return #string

---
-- Function GetAttributeLower()
-- Return attribute in lowercase, or empty if missing.
--
-- @function [parent=#XMLElement] GetAttributeLower
-- @param self Self reference
-- @param #string name name
-- @return #string

---
-- Function GetAttributeUpper()
-- Return attribute in lowercase, or empty if missing.
--
-- @function [parent=#XMLElement] GetAttributeUpper
-- @param self Self reference
-- @param #string name name
-- @return #string

---
-- Function GetAttributeNames()
-- Return names of all attributes.
--
-- @function [parent=#XMLElement] GetAttributeNames
-- @param self Self reference
-- @return Vector<String>#Vector<String>

---
-- Function GetBool()
-- Return bool attribute, or false if missing.
--
-- @function [parent=#XMLElement] GetBool
-- @param self Self reference
-- @param #string name name
-- @return #boolean

---
-- Function GetBoundingBox()
-- Return bounding box attribute, or empty if missing.
--
-- @function [parent=#XMLElement] GetBoundingBox
-- @param self Self reference
-- @return BoundingBox#BoundingBox

---
-- Function GetColor()
-- Return a color attribute, or default if missing.
--
-- @function [parent=#XMLElement] GetColor
-- @param self Self reference
-- @param #string name name
-- @return Color#Color

---
-- Function GetFloat()
-- Return a float attribute, or zero if missing.
--
-- @function [parent=#XMLElement] GetFloat
-- @param self Self reference
-- @param #string name name
-- @return #number

---
-- Function GetUInt()
-- Return an unsigned integer attribute, or zero if missing.
--
-- @function [parent=#XMLElement] GetUInt
-- @param self Self reference
-- @param #string name name
-- @return #number

---
-- Function GetInt()
-- Return an integer attribute, or zero if missing.
--
-- @function [parent=#XMLElement] GetInt
-- @param self Self reference
-- @param #string name name
-- @return #number

---
-- Function GetIntRect()
-- Return an IntRect attribute, or default if missing.
--
-- @function [parent=#XMLElement] GetIntRect
-- @param self Self reference
-- @param #string name name
-- @return IntRect#IntRect

---
-- Function GetIntVector2()
-- Return an IntVector2 attribute, or default if missing.
--
-- @function [parent=#XMLElement] GetIntVector2
-- @param self Self reference
-- @param #string name name
-- @return IntVector2#IntVector2

---
-- Function GetRect()
-- Return a Rect attribute, or default if missing.
--
-- @function [parent=#XMLElement] GetRect
-- @param self Self reference
-- @param #string name name
-- @return Rect#Rect

---
-- Function GetQuaternion()
-- Return a quaternion attribute, or default if missing.
--
-- @function [parent=#XMLElement] GetQuaternion
-- @param self Self reference
-- @param #string name name
-- @return Quaternion#Quaternion

---
-- Function GetVariant()
-- Return a variant attribute, or empty if missing.
--
-- @function [parent=#XMLElement] GetVariant
-- @param self Self reference
-- @return Variant#Variant

---
-- Function GetVariantValue()
-- Return a variant attribute with static type.
--
-- @function [parent=#XMLElement] GetVariantValue
-- @param self Self reference
-- @param VariantType#VariantType type type
-- @return Variant#Variant

---
-- Function GetResourceRef()
-- Return a resource reference attribute, or empty if missing.
--
-- @function [parent=#XMLElement] GetResourceRef
-- @param self Self reference
-- @return ResourceRef#ResourceRef

---
-- Function GetResourceRefList()
-- Return a resource reference list attribute, or empty if missing.
--
-- @function [parent=#XMLElement] GetResourceRefList
-- @param self Self reference
-- @return ResourceRefList#ResourceRefList

---
-- Function GetVariantMap()
-- Return a variant map attribute, or empty if missing.
--
-- @function [parent=#XMLElement] GetVariantMap
-- @param self Self reference
-- @return VariantMap#VariantMap

---
-- Function GetVector2()
-- Return a Vector2 attribute, or zero vector if missing.
--
-- @function [parent=#XMLElement] GetVector2
-- @param self Self reference
-- @param #string name name
-- @return Vector2#Vector2

---
-- Function GetVector3()
-- Return a Vector3 attribute, or zero vector if missing.
--
-- @function [parent=#XMLElement] GetVector3
-- @param self Self reference
-- @param #string name name
-- @return Vector3#Vector3

---
-- Function GetVector4()
-- Return a Vector4 attribute, or zero vector if missing.
--
-- @function [parent=#XMLElement] GetVector4
-- @param self Self reference
-- @param #string name name
-- @return Vector4#Vector4

---
-- Function GetVector()
-- Return any Vector attribute as Vector4. Missing coordinates will be zero.
--
-- @function [parent=#XMLElement] GetVector
-- @param self Self reference
-- @param #string name name
-- @return Vector4#Vector4

---
-- Function GetMatrix3()
-- Return a Matrix3 attribute, or zero matrix if missing.
--
-- @function [parent=#XMLElement] GetMatrix3
-- @param self Self reference
-- @param #string name name
-- @return Matrix3#Matrix3

---
-- Function GetMatrix3x4()
-- Return a Matrix3x4 attribute, or zero matrix if missing.
--
-- @function [parent=#XMLElement] GetMatrix3x4
-- @param self Self reference
-- @param #string name name
-- @return Matrix3x4#Matrix3x4

---
-- Function GetMatrix4()
-- Return a Matrix4 attribute, or zero matrix if missing.
--
-- @function [parent=#XMLElement] GetMatrix4
-- @param self Self reference
-- @param #string name name
-- @return Matrix4#Matrix4

---
-- Function GetFile()
-- Return XML file.
--
-- @function [parent=#XMLElement] GetFile
-- @param self Self reference
-- @return XMLFile#XMLFile

---
-- Field EMPTY
--
-- @field [parent=#XMLElement] XMLElement#XMLElement EMPTY

---
-- Field null (Read only)
--
-- @field [parent=#XMLElement] #boolean null

---
-- Field name (Read only)
--
-- @field [parent=#XMLElement] #string name

---
-- Field parent (Read only)
--
-- @field [parent=#XMLElement] XMLElement#XMLElement parent

---
-- Field value (Read only)
--
-- @field [parent=#XMLElement] #string value

---
-- Field numAttributes (Read only)
--
-- @field [parent=#XMLElement] #number numAttributes

---
-- Field file (Read only)
--
-- @field [parent=#XMLElement] XMLFile#XMLFile file


return nil
