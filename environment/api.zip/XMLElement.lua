---
-- Module XMLElement
-- Generated on 2014-03-13
--
-- @module XMLElement

---
-- Function CreateChild
--
-- @function [parent=#XMLElement] CreateChild
-- @param self Self reference
-- @param #string name name
-- @return XMLElement#XMLElement

---
-- Function RemoveChild
--
-- @function [parent=#XMLElement] RemoveChild
-- @param self Self reference
-- @param XMLElement#XMLElement element element
-- @return #boolean

---
-- Function RemoveChild
--
-- @function [parent=#XMLElement] RemoveChild
-- @param self Self reference
-- @param #string name name
-- @return #boolean

---
-- Function RemoveChildren
--
-- @function [parent=#XMLElement] RemoveChildren
-- @param self Self reference
-- @param #string name name
-- @return #boolean

---
-- Function RemoveAttribute
--
-- @function [parent=#XMLElement] RemoveAttribute
-- @param self Self reference
-- @param #string name name
-- @return #boolean

---
-- Function SetValue
--
-- @function [parent=#XMLElement] SetValue
-- @param self Self reference
-- @param #string value value
-- @return #boolean

---
-- Function SetAttribute
--
-- @function [parent=#XMLElement] SetAttribute
-- @param self Self reference
-- @param #string name name
-- @param #string value value
-- @return #boolean

---
-- Function SetBool
--
-- @function [parent=#XMLElement] SetBool
-- @param self Self reference
-- @param #string name name
-- @param #boolean value value
-- @return #boolean

---
-- Function SetBoundingBox
--
-- @function [parent=#XMLElement] SetBoundingBox
-- @param self Self reference
-- @param BoundingBox#BoundingBox value value
-- @return #boolean

---
-- Function SetColor
--
-- @function [parent=#XMLElement] SetColor
-- @param self Self reference
-- @param #string name name
-- @param Color#Color value value
-- @return #boolean

---
-- Function SetFloat
--
-- @function [parent=#XMLElement] SetFloat
-- @param self Self reference
-- @param #string name name
-- @param #number value value
-- @return #boolean

---
-- Function SetUInt
--
-- @function [parent=#XMLElement] SetUInt
-- @param self Self reference
-- @param #string name name
-- @param #number value value
-- @return #boolean

---
-- Function SetInt
--
-- @function [parent=#XMLElement] SetInt
-- @param self Self reference
-- @param #string name name
-- @param #number value value
-- @return #boolean

---
-- Function SetIntRect
--
-- @function [parent=#XMLElement] SetIntRect
-- @param self Self reference
-- @param #string name name
-- @param IntRect#IntRect value value
-- @return #boolean

---
-- Function SetIntVector2
--
-- @function [parent=#XMLElement] SetIntVector2
-- @param self Self reference
-- @param #string name name
-- @param IntVector2#IntVector2 value value
-- @return #boolean

---
-- Function SetRect
--
-- @function [parent=#XMLElement] SetRect
-- @param self Self reference
-- @param #string name name
-- @param Rect#Rect value value
-- @return #boolean

---
-- Function SetQuaternion
--
-- @function [parent=#XMLElement] SetQuaternion
-- @param self Self reference
-- @param #string name name
-- @param Quaternion#Quaternion value value
-- @return #boolean

---
-- Function SetString
--
-- @function [parent=#XMLElement] SetString
-- @param self Self reference
-- @param #string name name
-- @param #string value value
-- @return #boolean

---
-- Function SetVariant
--
-- @function [parent=#XMLElement] SetVariant
-- @param self Self reference
-- @param Variant#Variant value value
-- @return #boolean

---
-- Function SetVariantValue
--
-- @function [parent=#XMLElement] SetVariantValue
-- @param self Self reference
-- @param Variant#Variant value value
-- @return #boolean

---
-- Function SetResourceRef
--
-- @function [parent=#XMLElement] SetResourceRef
-- @param self Self reference
-- @param ResourceRef#ResourceRef value value
-- @return #boolean

---
-- Function SetResourceRefList
--
-- @function [parent=#XMLElement] SetResourceRefList
-- @param self Self reference
-- @param ResourceRefList#ResourceRefList value value
-- @return #boolean

---
-- Function SetVector2
--
-- @function [parent=#XMLElement] SetVector2
-- @param self Self reference
-- @param #string name name
-- @param Vector2#Vector2 value value
-- @return #boolean

---
-- Function SetVector3
--
-- @function [parent=#XMLElement] SetVector3
-- @param self Self reference
-- @param #string name name
-- @param Vector3#Vector3 value value
-- @return #boolean

---
-- Function SetVector4
--
-- @function [parent=#XMLElement] SetVector4
-- @param self Self reference
-- @param #string name name
-- @param Vector4#Vector4 value value
-- @return #boolean

---
-- Function SetVectorVariant
--
-- @function [parent=#XMLElement] SetVectorVariant
-- @param self Self reference
-- @param #string name name
-- @param Variant#Variant value value
-- @return #boolean

---
-- Function IsNull
--
-- @function [parent=#XMLElement] IsNull
-- @param self Self reference
-- @return #boolean

---
-- Function NotNull
--
-- @function [parent=#XMLElement] NotNull
-- @param self Self reference
-- @return #boolean

---
-- Function operatorbool
--
-- @function [parent=#XMLElement] operatorbool
-- @param self Self reference
-- @return #boolean

---
-- Function GetName
--
-- @function [parent=#XMLElement] GetName
-- @param self Self reference
-- @return #string

---
-- Function HasChild
--
-- @function [parent=#XMLElement] HasChild
-- @param self Self reference
-- @param #string name name
-- @return #boolean

---
-- Function GetChild
--
-- @function [parent=#XMLElement] GetChild
-- @param self Self reference
-- @param #string name name
-- @return XMLElement#XMLElement

---
-- Function GetNext
--
-- @function [parent=#XMLElement] GetNext
-- @param self Self reference
-- @param #string name name
-- @return XMLElement#XMLElement

---
-- Function GetParent
--
-- @function [parent=#XMLElement] GetParent
-- @param self Self reference
-- @return XMLElement#XMLElement

---
-- Function GetNumAttributes
--
-- @function [parent=#XMLElement] GetNumAttributes
-- @param self Self reference
-- @return #number

---
-- Function HasAttribute
--
-- @function [parent=#XMLElement] HasAttribute
-- @param self Self reference
-- @param #string name name
-- @return #boolean

---
-- Function GetBool
--
-- @function [parent=#XMLElement] GetBool
-- @param self Self reference
-- @param #string name name
-- @return #boolean

---
-- Function GetBoundingBox
--
-- @function [parent=#XMLElement] GetBoundingBox
-- @param self Self reference
-- @return BoundingBox#BoundingBox

---
-- Function GetValue
--
-- @function [parent=#XMLElement] GetValue
-- @param self Self reference
-- @return #string

---
-- Function GetColor
--
-- @function [parent=#XMLElement] GetColor
-- @param self Self reference
-- @param #string name name
-- @return Color#Color

---
-- Function GetFloat
--
-- @function [parent=#XMLElement] GetFloat
-- @param self Self reference
-- @param #string name name
-- @return #number

---
-- Function GetUInt
--
-- @function [parent=#XMLElement] GetUInt
-- @param self Self reference
-- @param #string name name
-- @return #number

---
-- Function GetInt
--
-- @function [parent=#XMLElement] GetInt
-- @param self Self reference
-- @param #string name name
-- @return #number

---
-- Function GetIntRect
--
-- @function [parent=#XMLElement] GetIntRect
-- @param self Self reference
-- @param #string name name
-- @return IntRect#IntRect

---
-- Function GetIntVector2
--
-- @function [parent=#XMLElement] GetIntVector2
-- @param self Self reference
-- @param #string name name
-- @return IntVector2#IntVector2

---
-- Function GetRect
--
-- @function [parent=#XMLElement] GetRect
-- @param self Self reference
-- @param #string name name
-- @return Rect#Rect

---
-- Function GetQuaternion
--
-- @function [parent=#XMLElement] GetQuaternion
-- @param self Self reference
-- @param #string name name
-- @return Quaternion#Quaternion

---
-- Function GetVariant
--
-- @function [parent=#XMLElement] GetVariant
-- @param self Self reference
-- @return Variant#Variant

---
-- Function GetVariantValue
--
-- @function [parent=#XMLElement] GetVariantValue
-- @param self Self reference
-- @param VariantType#VariantType type type
-- @return Variant#Variant

---
-- Function GetResourceRef
--
-- @function [parent=#XMLElement] GetResourceRef
-- @param self Self reference
-- @return ResourceRef#ResourceRef

---
-- Function GetResourceRefList
--
-- @function [parent=#XMLElement] GetResourceRefList
-- @param self Self reference
-- @return ResourceRefList#ResourceRefList

---
-- Function GetVariantMap
--
-- @function [parent=#XMLElement] GetVariantMap
-- @param self Self reference
-- @return VariantMap#VariantMap

---
-- Function GetVector2
--
-- @function [parent=#XMLElement] GetVector2
-- @param self Self reference
-- @param #string name name
-- @return Vector2#Vector2

---
-- Function GetVector3
--
-- @function [parent=#XMLElement] GetVector3
-- @param self Self reference
-- @param #string name name
-- @return Vector3#Vector3

---
-- Function GetVector4
--
-- @function [parent=#XMLElement] GetVector4
-- @param self Self reference
-- @param #string name name
-- @return Vector4#Vector4

---
-- Function GetVector
--
-- @function [parent=#XMLElement] GetVector
-- @param self Self reference
-- @param #string name name
-- @return Vector4#Vector4

---
-- Function GetFile
--
-- @function [parent=#XMLElement] GetFile
-- @param self Self reference
-- @return XMLFile#XMLFile

---
-- Field EMPTY
--
-- @field [parent=#XMLElement] XMLElement#XMLElement EMPTY

---
-- Field null (Read only)
--
-- @field [parent=#XMLElement] #boolean null

---
-- Field name (Read only)
--
-- @field [parent=#XMLElement] #string name

---
-- Field value (Read only)
--
-- @field [parent=#XMLElement] #string value

---
-- Field parent (Read only)
--
-- @field [parent=#XMLElement] XMLElement#XMLElement parent

---
-- Field numAttributes (Read only)
--
-- @field [parent=#XMLElement] #number numAttributes

---
-- Field file (Read only)
--
-- @field [parent=#XMLElement] XMLFile#XMLFile file


return nil
