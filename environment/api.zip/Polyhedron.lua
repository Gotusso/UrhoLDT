---
-- Module Polyhedron
--
-- @module Polyhedron

---
-- Function Polyhedron
--
-- @function [parent=#Polyhedron] Polyhedron

---
-- Function new
--
-- @function [parent=#Polyhedron] new
-- @return Polyhedron#Polyhedron

---
-- Function Polyhedron
--
-- @function [parent=#Polyhedron] Polyhedron
-- @param Polyhedron#Polyhedron polyhedronpolyhedron

---
-- Function new
--
-- @function [parent=#Polyhedron] new
-- @param Polyhedron#Polyhedron polyhedronpolyhedron
-- @return Polyhedron#Polyhedron

---
-- Function Polyhedron
--
-- @function [parent=#Polyhedron] Polyhedron
-- @param BoundingBox#BoundingBox boxbox

---
-- Function new
--
-- @function [parent=#Polyhedron] new
-- @param BoundingBox#BoundingBox boxbox
-- @return Polyhedron#Polyhedron

---
-- Function Polyhedron
--
-- @function [parent=#Polyhedron] Polyhedron
-- @param Frustum#Frustum frustumfrustum

---
-- Function new
--
-- @function [parent=#Polyhedron] new
-- @param Frustum#Frustum frustumfrustum
-- @return Polyhedron#Polyhedron

---
-- Function delete
--
-- @function [parent=#Polyhedron] delete

---
-- Function Define
--
-- @function [parent=#Polyhedron] Define
-- @param BoundingBox#BoundingBox boxbox

---
-- Function Define
--
-- @function [parent=#Polyhedron] Define
-- @param Frustum#Frustum frustumfrustum

---
-- Function AddFace
--
-- @function [parent=#Polyhedron] AddFace
-- @param Vector3#Vector3 v0v0
-- @param Vector3#Vector3 v1v1
-- @param Vector3#Vector3 v2v2

---
-- Function AddFace
--
-- @function [parent=#Polyhedron] AddFace
-- @param Vector3#Vector3 v0v0
-- @param Vector3#Vector3 v1v1
-- @param Vector3#Vector3 v2v2
-- @param Vector3#Vector3 v3v3

---
-- Function Clip
--
-- @function [parent=#Polyhedron] Clip
-- @param Plane#Plane planeplane

---
-- Function Clip
--
-- @function [parent=#Polyhedron] Clip
-- @param BoundingBox#BoundingBox boxbox

---
-- Function Clip
--
-- @function [parent=#Polyhedron] Clip
-- @param Frustum#Frustum boxbox

---
-- Function Clear
--
-- @function [parent=#Polyhedron] Clear

---
-- Function Transform
--
-- @function [parent=#Polyhedron] Transform
-- @param Matrix3#Matrix3 transformtransform

---
-- Function Transform
--
-- @function [parent=#Polyhedron] Transform
-- @param Matrix3x4#Matrix3x4 transformtransform

---
-- Function Transformed
--
-- @function [parent=#Polyhedron] Transformed
-- @param Matrix3#Matrix3 transformtransform
-- @return Polyhedron#Polyhedron

---
-- Function Transformed
--
-- @function [parent=#Polyhedron] Transformed
-- @param Matrix3x4#Matrix3x4 transformtransform
-- @return Polyhedron#Polyhedron

---
-- Function Empty
--
-- @function [parent=#Polyhedron] Empty
-- @return #boolean

---
-- Field empty (Read only)
--
-- @field [parent=#Polyhedron] #boolean empty


return nil
