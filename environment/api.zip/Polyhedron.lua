---
-- Module Polyhedron
-- Generated on 2014-05-31
--
-- @module Polyhedron

---
-- Function Polyhedron()
-- Construct empty.
--
-- @function [parent=#Polyhedron] Polyhedron
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#Polyhedron] new
-- @param self Self reference
-- @return Polyhedron#Polyhedron

---
-- Function Polyhedron()
--
-- @function [parent=#Polyhedron] Polyhedron
-- @param self Self reference
-- @param Polyhedron#Polyhedron polyhedron polyhedron

---
-- Function new()
--
-- @function [parent=#Polyhedron] new
-- @param self Self reference
-- @param Polyhedron#Polyhedron polyhedron polyhedron
-- @return Polyhedron#Polyhedron

---
-- Function Polyhedron()
--
-- @function [parent=#Polyhedron] Polyhedron
-- @param self Self reference
-- @param BoundingBox#BoundingBox box box

---
-- Function new()
--
-- @function [parent=#Polyhedron] new
-- @param self Self reference
-- @param BoundingBox#BoundingBox box box
-- @return Polyhedron#Polyhedron

---
-- Function Polyhedron()
--
-- @function [parent=#Polyhedron] Polyhedron
-- @param self Self reference
-- @param Frustum#Frustum frustum frustum

---
-- Function new()
--
-- @function [parent=#Polyhedron] new
-- @param self Self reference
-- @param Frustum#Frustum frustum frustum
-- @return Polyhedron#Polyhedron

---
-- Function delete()
--
-- @function [parent=#Polyhedron] delete
-- @param self Self reference

---
-- Function Define()
--
-- @function [parent=#Polyhedron] Define
-- @param self Self reference
-- @param BoundingBox#BoundingBox box box

---
-- Function Define()
--
-- @function [parent=#Polyhedron] Define
-- @param self Self reference
-- @param Frustum#Frustum frustum frustum

---
-- Function AddFace()
--
-- @function [parent=#Polyhedron] AddFace
-- @param self Self reference
-- @param Vector3#Vector3 v0 v0
-- @param Vector3#Vector3 v1 v1
-- @param Vector3#Vector3 v2 v2

---
-- Function AddFace()
--
-- @function [parent=#Polyhedron] AddFace
-- @param self Self reference
-- @param Vector3#Vector3 v0 v0
-- @param Vector3#Vector3 v1 v1
-- @param Vector3#Vector3 v2 v2
-- @param Vector3#Vector3 v3 v3

---
-- Function Clip()
--
-- @function [parent=#Polyhedron] Clip
-- @param self Self reference
-- @param Plane#Plane plane plane

---
-- Function Clip()
--
-- @function [parent=#Polyhedron] Clip
-- @param self Self reference
-- @param BoundingBox#BoundingBox box box

---
-- Function Clip()
--
-- @function [parent=#Polyhedron] Clip
-- @param self Self reference
-- @param Frustum#Frustum box box

---
-- Function Clear()
--
-- @function [parent=#Polyhedron] Clear
-- @param self Self reference

---
-- Function Transform()
--
-- @function [parent=#Polyhedron] Transform
-- @param self Self reference
-- @param Matrix3#Matrix3 transform transform

---
-- Function Transform()
--
-- @function [parent=#Polyhedron] Transform
-- @param self Self reference
-- @param Matrix3x4#Matrix3x4 transform transform

---
-- Function Transformed()
--
-- @function [parent=#Polyhedron] Transformed
-- @param self Self reference
-- @param Matrix3#Matrix3 transform transform
-- @return Polyhedron#Polyhedron

---
-- Function Transformed()
--
-- @function [parent=#Polyhedron] Transformed
-- @param self Self reference
-- @param Matrix3x4#Matrix3x4 transform transform
-- @return Polyhedron#Polyhedron

---
-- Function Empty()
--
-- @function [parent=#Polyhedron] Empty
-- @param self Self reference
-- @return #boolean

---
-- Field empty (Read only)
--
-- @field [parent=#Polyhedron] #boolean empty


return nil
