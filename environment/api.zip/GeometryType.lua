---
-- Enumeration GeometryType
--
-- @module GeometryType

---
-- Enumeration value GEOM_STATIC
--
-- @field [parent=#GeometryType] #number GEOM_STATIC

---
-- Enumeration value GEOM_SKINNED
--
-- @field [parent=#GeometryType] #number GEOM_SKINNED

---
-- Enumeration value GEOM_INSTANCED
--
-- @field [parent=#GeometryType] #number GEOM_INSTANCED

---
-- Enumeration value GEOM_BILLBOARD
--
-- @field [parent=#GeometryType] #number GEOM_BILLBOARD

---
-- Enumeration value GEOM_STATIC_NOINSTANCING
--
-- @field [parent=#GeometryType] #number GEOM_STATIC_NOINSTANCING

---
-- Enumeration value MAX_GEOMETRYTYPES
--
-- @field [parent=#GeometryType] #number MAX_GEOMETRYTYPES


return nil
