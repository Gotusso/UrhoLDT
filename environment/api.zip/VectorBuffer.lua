---
-- Module VectorBuffer
--
-- @module VectorBuffer

---
-- Function VectorBuffer
--
-- @function [parent=#VectorBuffer] VectorBuffer

---
-- Function new
--
-- @function [parent=#VectorBuffer] new
-- @return VectorBuffer#VectorBuffer

---
-- Function VectorBuffer
--
-- @function [parent=#VectorBuffer] VectorBuffer
-- @param Deserializer#Deserializer sourcesource
-- @param #number sizesize

---
-- Function new
--
-- @function [parent=#VectorBuffer] new
-- @param Deserializer#Deserializer sourcesource
-- @param #number sizesize
-- @return VectorBuffer#VectorBuffer

---
-- Function delete
--
-- @function [parent=#VectorBuffer] delete

---
-- Function SetData
--
-- @function [parent=#VectorBuffer] SetData
-- @param Deserializer#Deserializer sourcesource
-- @param #number sizesize

---
-- Function Clear
--
-- @function [parent=#VectorBuffer] Clear

---
-- Function Resize
--
-- @function [parent=#VectorBuffer] Resize
-- @param #number sizesize

---
-- Function GetData
--
-- @function [parent=#VectorBuffer] GetData
-- @return const void*#const void*

---
-- Function GetModifiableData
--
-- @function [parent=#VectorBuffer] GetModifiableData
-- @return void*#void*

---
-- Function Read
--
-- @function [parent=#VectorBuffer] Read
-- @param #number sizesize
-- @return VectorBuffer#VectorBuffer

---
-- Function Seek
--
-- @function [parent=#VectorBuffer] Seek
-- @param #number positionposition
-- @return #number

---
-- Function GetName
--
-- @function [parent=#VectorBuffer] GetName
-- @return const String#const String

---
-- Function GetChecksum
--
-- @function [parent=#VectorBuffer] GetChecksum
-- @return #number

---
-- Function GetPosition
--
-- @function [parent=#VectorBuffer] GetPosition
-- @return #number

---
-- Function GetSize
--
-- @function [parent=#VectorBuffer] GetSize
-- @return #number

---
-- Function IsEof
--
-- @function [parent=#VectorBuffer] IsEof
-- @return #boolean

---
-- Function ReadInt
--
-- @function [parent=#VectorBuffer] ReadInt
-- @return #number

---
-- Function ReadShort
--
-- @function [parent=#VectorBuffer] ReadShort
-- @return short#short

---
-- Function ReadByte
--
-- @function [parent=#VectorBuffer] ReadByte
-- @return #string

---
-- Function ReadUInt
--
-- @function [parent=#VectorBuffer] ReadUInt
-- @return #number

---
-- Function ReadUShort
--
-- @function [parent=#VectorBuffer] ReadUShort
-- @return short#short

---
-- Function ReadUByte
--
-- @function [parent=#VectorBuffer] ReadUByte
-- @return #string

---
-- Function ReadBool
--
-- @function [parent=#VectorBuffer] ReadBool
-- @return #boolean

---
-- Function ReadFloat
--
-- @function [parent=#VectorBuffer] ReadFloat
-- @return #number

---
-- Function ReadIntRect
--
-- @function [parent=#VectorBuffer] ReadIntRect
-- @return IntRect#IntRect

---
-- Function ReadIntVector2
--
-- @function [parent=#VectorBuffer] ReadIntVector2
-- @return IntVector2#IntVector2

---
-- Function ReadRect
--
-- @function [parent=#VectorBuffer] ReadRect
-- @return Rect#Rect

---
-- Function ReadVector2
--
-- @function [parent=#VectorBuffer] ReadVector2
-- @return Vector2#Vector2

---
-- Function ReadVector3
--
-- @function [parent=#VectorBuffer] ReadVector3
-- @return Vector3#Vector3

---
-- Function ReadPackedVector3
--
-- @function [parent=#VectorBuffer] ReadPackedVector3
-- @param #number maxAbsCoordmaxAbsCoord
-- @return Vector3#Vector3

---
-- Function ReadVector4
--
-- @function [parent=#VectorBuffer] ReadVector4
-- @return Vector4#Vector4

---
-- Function ReadQuaternion
--
-- @function [parent=#VectorBuffer] ReadQuaternion
-- @return Quaternion#Quaternion

---
-- Function ReadPackedQuaternion
--
-- @function [parent=#VectorBuffer] ReadPackedQuaternion
-- @return Quaternion#Quaternion

---
-- Function ReadColor
--
-- @function [parent=#VectorBuffer] ReadColor
-- @return Color#Color

---
-- Function ReadBoundingBox
--
-- @function [parent=#VectorBuffer] ReadBoundingBox
-- @return BoundingBox#BoundingBox

---
-- Function ReadString
--
-- @function [parent=#VectorBuffer] ReadString
-- @return #string

---
-- Function ReadFileID
--
-- @function [parent=#VectorBuffer] ReadFileID
-- @return #string

---
-- Function ReadStringHash
--
-- @function [parent=#VectorBuffer] ReadStringHash
-- @return StringHash#StringHash

---
-- Function ReadShortStringHash
--
-- @function [parent=#VectorBuffer] ReadShortStringHash
-- @return ShortStringHash#ShortStringHash

---
-- Function ReadBuffer
--
-- @function [parent=#VectorBuffer] ReadBuffer
-- @return VectorBuffer#VectorBuffer

---
-- Function ReadResourceRef
--
-- @function [parent=#VectorBuffer] ReadResourceRef
-- @return ResourceRef#ResourceRef

---
-- Function ReadResourceRefList
--
-- @function [parent=#VectorBuffer] ReadResourceRefList
-- @return ResourceRefList#ResourceRefList

---
-- Function ReadVariant
--
-- @function [parent=#VectorBuffer] ReadVariant
-- @return Variant#Variant

---
-- Function ReadVariant
--
-- @function [parent=#VectorBuffer] ReadVariant
-- @param VariantType#VariantType typetype
-- @return Variant#Variant

---
-- Function ReadVariantVector
--
-- @function [parent=#VectorBuffer] ReadVariantVector
-- @return VariantVector#VariantVector

---
-- Function ReadVariantMap
--
-- @function [parent=#VectorBuffer] ReadVariantMap
-- @return VariantMap#VariantMap

---
-- Function ReadVLE
--
-- @function [parent=#VectorBuffer] ReadVLE
-- @return #number

---
-- Function ReadNetID
--
-- @function [parent=#VectorBuffer] ReadNetID
-- @return #number

---
-- Function ReadLine
--
-- @function [parent=#VectorBuffer] ReadLine
-- @return #string

---
-- Function Write
--
-- @function [parent=#VectorBuffer] Write
-- @param VectorBuffer#VectorBuffer bufferbuffer
-- @return #number

---
-- Function WriteInt
--
-- @function [parent=#VectorBuffer] WriteInt
-- @param #number valuevalue
-- @return #boolean

---
-- Function WriteShort
--
-- @function [parent=#VectorBuffer] WriteShort
-- @param short#short valuevalue
-- @return #boolean

---
-- Function WriteByte
--
-- @function [parent=#VectorBuffer] WriteByte
-- @param #string valuevalue
-- @return #boolean

---
-- Function WriteUInt
--
-- @function [parent=#VectorBuffer] WriteUInt
-- @param #number valuevalue
-- @return #boolean

---
-- Function WriteUShort
--
-- @function [parent=#VectorBuffer] WriteUShort
-- @param short#short valuevalue
-- @return #boolean

---
-- Function WriteUByte
--
-- @function [parent=#VectorBuffer] WriteUByte
-- @param #string valuevalue
-- @return #boolean

---
-- Function WriteBool
--
-- @function [parent=#VectorBuffer] WriteBool
-- @param #boolean valuevalue
-- @return #boolean

---
-- Function WriteFloat
--
-- @function [parent=#VectorBuffer] WriteFloat
-- @param #number valuevalue
-- @return #boolean

---
-- Function WriteIntRect
--
-- @function [parent=#VectorBuffer] WriteIntRect
-- @param IntRect#IntRect valuevalue
-- @return #boolean

---
-- Function WriteIntVector2
--
-- @function [parent=#VectorBuffer] WriteIntVector2
-- @param IntVector2#IntVector2 valuevalue
-- @return #boolean

---
-- Function WriteRect
--
-- @function [parent=#VectorBuffer] WriteRect
-- @param Rect#Rect valuevalue
-- @return #boolean

---
-- Function WriteVector2
--
-- @function [parent=#VectorBuffer] WriteVector2
-- @param Vector2#Vector2 valuevalue
-- @return #boolean

---
-- Function WriteVector3
--
-- @function [parent=#VectorBuffer] WriteVector3
-- @param Vector3#Vector3 valuevalue
-- @return #boolean

---
-- Function WritePackedVector3
--
-- @function [parent=#VectorBuffer] WritePackedVector3
-- @param Vector3#Vector3 valuevalue
-- @param #number maxAbsCoordmaxAbsCoord
-- @return #boolean

---
-- Function WriteVector4
--
-- @function [parent=#VectorBuffer] WriteVector4
-- @param Vector4#Vector4 valuevalue
-- @return #boolean

---
-- Function WriteQuaternion
--
-- @function [parent=#VectorBuffer] WriteQuaternion
-- @param Quaternion#Quaternion valuevalue
-- @return #boolean

---
-- Function WritePackedQuaternion
--
-- @function [parent=#VectorBuffer] WritePackedQuaternion
-- @param Quaternion#Quaternion valuevalue
-- @return #boolean

---
-- Function WriteColor
--
-- @function [parent=#VectorBuffer] WriteColor
-- @param Color#Color valuevalue
-- @return #boolean

---
-- Function WriteBoundingBox
--
-- @function [parent=#VectorBuffer] WriteBoundingBox
-- @param BoundingBox#BoundingBox valuevalue
-- @return #boolean

---
-- Function WriteString
--
-- @function [parent=#VectorBuffer] WriteString
-- @param #string valuevalue
-- @return #boolean

---
-- Function WriteFileID
--
-- @function [parent=#VectorBuffer] WriteFileID
-- @param #string valuevalue
-- @return #boolean

---
-- Function WriteStringHash
--
-- @function [parent=#VectorBuffer] WriteStringHash
-- @param StringHash#StringHash valuevalue
-- @return #boolean

---
-- Function WriteShortStringHash
--
-- @function [parent=#VectorBuffer] WriteShortStringHash
-- @param ShortStringHash#ShortStringHash valuevalue
-- @return #boolean

---
-- Function WriteBuffer
--
-- @function [parent=#VectorBuffer] WriteBuffer
-- @param VectorBuffer#VectorBuffer bufferbuffer
-- @return #boolean

---
-- Function WriteResourceRef
--
-- @function [parent=#VectorBuffer] WriteResourceRef
-- @param ResourceRef#ResourceRef valuevalue
-- @return #boolean

---
-- Function WriteResourceRefList
--
-- @function [parent=#VectorBuffer] WriteResourceRefList
-- @param ResourceRefList#ResourceRefList valuevalue
-- @return #boolean

---
-- Function WriteVariant
--
-- @function [parent=#VectorBuffer] WriteVariant
-- @param Variant#Variant valuevalue
-- @return #boolean

---
-- Function WriteVariantData
--
-- @function [parent=#VectorBuffer] WriteVariantData
-- @param Variant#Variant valuevalue
-- @return #boolean

---
-- Function WriteVariantVector
--
-- @function [parent=#VectorBuffer] WriteVariantVector
-- @param VariantVector#VariantVector valuevalue
-- @return #boolean

---
-- Function WriteVariantMap
--
-- @function [parent=#VectorBuffer] WriteVariantMap
-- @param VariantMap#VariantMap valuevalue
-- @return #boolean

---
-- Function WriteVLE
--
-- @function [parent=#VectorBuffer] WriteVLE
-- @param #number valuevalue
-- @return #boolean

---
-- Function WriteNetID
--
-- @function [parent=#VectorBuffer] WriteNetID
-- @param #number valuevalue
-- @return #boolean

---
-- Function WriteLine
--
-- @function [parent=#VectorBuffer] WriteLine
-- @param #string valuevalue
-- @return #boolean

---
-- Field name (Read only)
--
-- @field [parent=#VectorBuffer] #string name

---
-- Field checksum (Read only)
--
-- @field [parent=#VectorBuffer] #number checksum

---
-- Field position (Read only)
--
-- @field [parent=#VectorBuffer] #number position

---
-- Field size (Read only)
--
-- @field [parent=#VectorBuffer] #number size

---
-- Field eof (Read only)
--
-- @field [parent=#VectorBuffer] #boolean eof


return nil
