---
-- Module VectorBuffer
-- Generated on 2014-05-31
--
-- @module VectorBuffer

---
-- Function VectorBuffer()
-- Construct an empty buffer.
--
-- @function [parent=#VectorBuffer] VectorBuffer
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#VectorBuffer] new
-- @param self Self reference
-- @return VectorBuffer#VectorBuffer

---
-- Function VectorBuffer()
-- Construct from a stream.
--
-- @function [parent=#VectorBuffer] VectorBuffer
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @param #number size size

---
-- Function new()
--
-- @function [parent=#VectorBuffer] new
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @param #number size size
-- @return VectorBuffer#VectorBuffer

---
-- Function delete()
--
-- @function [parent=#VectorBuffer] delete
-- @param self Self reference

---
-- Function SetData()
-- Set data from a stream.
--
-- @function [parent=#VectorBuffer] SetData
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @param #number size size

---
-- Function Clear()
-- Reset to zero size.
--
-- @function [parent=#VectorBuffer] Clear
-- @param self Self reference

---
-- Function Resize()
-- Set size.
--
-- @function [parent=#VectorBuffer] Resize
-- @param self Self reference
-- @param #number size size

---
-- Function GetData()
-- Return data.
--
-- @function [parent=#VectorBuffer] GetData
-- @param self Self reference
-- @return const void*#const void*

---
-- Function GetModifiableData()
-- Return non-const data.
--
-- @function [parent=#VectorBuffer] GetModifiableData
-- @param self Self reference
-- @return void*#void*

---
-- Function Read()
--
-- @function [parent=#VectorBuffer] Read
-- @param self Self reference
-- @param #number size size
-- @return VectorBuffer#VectorBuffer

---
-- Function Seek()
-- Set position from the beginning of the buffer.
--
-- @function [parent=#VectorBuffer] Seek
-- @param self Self reference
-- @param #number position position
-- @return #number

---
-- Function GetName()
--
-- @function [parent=#VectorBuffer] GetName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetChecksum()
--
-- @function [parent=#VectorBuffer] GetChecksum
-- @param self Self reference
-- @return #number

---
-- Function GetPosition()
--
-- @function [parent=#VectorBuffer] GetPosition
-- @param self Self reference
-- @return #number

---
-- Function GetSize()
--
-- @function [parent=#VectorBuffer] GetSize
-- @param self Self reference
-- @return #number

---
-- Function IsEof()
--
-- @function [parent=#VectorBuffer] IsEof
-- @param self Self reference
-- @return #boolean

---
-- Function ReadInt()
--
-- @function [parent=#VectorBuffer] ReadInt
-- @param self Self reference
-- @return #number

---
-- Function ReadShort()
--
-- @function [parent=#VectorBuffer] ReadShort
-- @param self Self reference
-- @return short#short

---
-- Function ReadByte()
--
-- @function [parent=#VectorBuffer] ReadByte
-- @param self Self reference
-- @return #string

---
-- Function ReadUInt()
--
-- @function [parent=#VectorBuffer] ReadUInt
-- @param self Self reference
-- @return #number

---
-- Function ReadUShort()
--
-- @function [parent=#VectorBuffer] ReadUShort
-- @param self Self reference
-- @return short#short

---
-- Function ReadUByte()
--
-- @function [parent=#VectorBuffer] ReadUByte
-- @param self Self reference
-- @return #string

---
-- Function ReadBool()
--
-- @function [parent=#VectorBuffer] ReadBool
-- @param self Self reference
-- @return #boolean

---
-- Function ReadFloat()
--
-- @function [parent=#VectorBuffer] ReadFloat
-- @param self Self reference
-- @return #number

---
-- Function ReadIntRect()
--
-- @function [parent=#VectorBuffer] ReadIntRect
-- @param self Self reference
-- @return IntRect#IntRect

---
-- Function ReadIntVector2()
--
-- @function [parent=#VectorBuffer] ReadIntVector2
-- @param self Self reference
-- @return IntVector2#IntVector2

---
-- Function ReadRect()
--
-- @function [parent=#VectorBuffer] ReadRect
-- @param self Self reference
-- @return Rect#Rect

---
-- Function ReadVector2()
--
-- @function [parent=#VectorBuffer] ReadVector2
-- @param self Self reference
-- @return Vector2#Vector2

---
-- Function ReadVector3()
--
-- @function [parent=#VectorBuffer] ReadVector3
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function ReadPackedVector3()
--
-- @function [parent=#VectorBuffer] ReadPackedVector3
-- @param self Self reference
-- @param #number maxAbsCoord maxAbsCoord
-- @return Vector3#Vector3

---
-- Function ReadVector4()
--
-- @function [parent=#VectorBuffer] ReadVector4
-- @param self Self reference
-- @return Vector4#Vector4

---
-- Function ReadQuaternion()
--
-- @function [parent=#VectorBuffer] ReadQuaternion
-- @param self Self reference
-- @return Quaternion#Quaternion

---
-- Function ReadPackedQuaternion()
--
-- @function [parent=#VectorBuffer] ReadPackedQuaternion
-- @param self Self reference
-- @return Quaternion#Quaternion

---
-- Function ReadMatrix3()
--
-- @function [parent=#VectorBuffer] ReadMatrix3
-- @param self Self reference
-- @return Matrix3#Matrix3

---
-- Function ReadMatrix3x4()
--
-- @function [parent=#VectorBuffer] ReadMatrix3x4
-- @param self Self reference
-- @return Matrix3x4#Matrix3x4

---
-- Function ReadMatrix4()
--
-- @function [parent=#VectorBuffer] ReadMatrix4
-- @param self Self reference
-- @return Matrix4#Matrix4

---
-- Function ReadColor()
--
-- @function [parent=#VectorBuffer] ReadColor
-- @param self Self reference
-- @return Color#Color

---
-- Function ReadBoundingBox()
--
-- @function [parent=#VectorBuffer] ReadBoundingBox
-- @param self Self reference
-- @return BoundingBox#BoundingBox

---
-- Function ReadString()
--
-- @function [parent=#VectorBuffer] ReadString
-- @param self Self reference
-- @return #string

---
-- Function ReadFileID()
--
-- @function [parent=#VectorBuffer] ReadFileID
-- @param self Self reference
-- @return #string

---
-- Function ReadStringHash()
--
-- @function [parent=#VectorBuffer] ReadStringHash
-- @param self Self reference
-- @return StringHash#StringHash

---
-- Function ReadShortStringHash()
--
-- @function [parent=#VectorBuffer] ReadShortStringHash
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function ReadBuffer()
--
-- @function [parent=#VectorBuffer] ReadBuffer
-- @param self Self reference
-- @return VectorBuffer#VectorBuffer

---
-- Function ReadResourceRef()
--
-- @function [parent=#VectorBuffer] ReadResourceRef
-- @param self Self reference
-- @return ResourceRef#ResourceRef

---
-- Function ReadResourceRefList()
--
-- @function [parent=#VectorBuffer] ReadResourceRefList
-- @param self Self reference
-- @return ResourceRefList#ResourceRefList

---
-- Function ReadVariant()
--
-- @function [parent=#VectorBuffer] ReadVariant
-- @param self Self reference
-- @return Variant#Variant

---
-- Function ReadVariant()
--
-- @function [parent=#VectorBuffer] ReadVariant
-- @param self Self reference
-- @param VariantType#VariantType type type
-- @return Variant#Variant

---
-- Function ReadVariantVector()
--
-- @function [parent=#VectorBuffer] ReadVariantVector
-- @param self Self reference
-- @return VariantVector#VariantVector

---
-- Function ReadVariantMap()
--
-- @function [parent=#VectorBuffer] ReadVariantMap
-- @param self Self reference
-- @return VariantMap#VariantMap

---
-- Function ReadVLE()
--
-- @function [parent=#VectorBuffer] ReadVLE
-- @param self Self reference
-- @return #number

---
-- Function ReadNetID()
--
-- @function [parent=#VectorBuffer] ReadNetID
-- @param self Self reference
-- @return #number

---
-- Function ReadLine()
--
-- @function [parent=#VectorBuffer] ReadLine
-- @param self Self reference
-- @return #string

---
-- Function Write()
--
-- @function [parent=#VectorBuffer] Write
-- @param self Self reference
-- @param VectorBuffer#VectorBuffer buffer buffer
-- @return #number

---
-- Function WriteInt()
--
-- @function [parent=#VectorBuffer] WriteInt
-- @param self Self reference
-- @param #number value value
-- @return #boolean

---
-- Function WriteShort()
--
-- @function [parent=#VectorBuffer] WriteShort
-- @param self Self reference
-- @param short#short value value
-- @return #boolean

---
-- Function WriteByte()
--
-- @function [parent=#VectorBuffer] WriteByte
-- @param self Self reference
-- @param #string value value
-- @return #boolean

---
-- Function WriteUInt()
--
-- @function [parent=#VectorBuffer] WriteUInt
-- @param self Self reference
-- @param #number value value
-- @return #boolean

---
-- Function WriteUShort()
--
-- @function [parent=#VectorBuffer] WriteUShort
-- @param self Self reference
-- @param short#short value value
-- @return #boolean

---
-- Function WriteUByte()
--
-- @function [parent=#VectorBuffer] WriteUByte
-- @param self Self reference
-- @param #string value value
-- @return #boolean

---
-- Function WriteBool()
--
-- @function [parent=#VectorBuffer] WriteBool
-- @param self Self reference
-- @param #boolean value value
-- @return #boolean

---
-- Function WriteFloat()
--
-- @function [parent=#VectorBuffer] WriteFloat
-- @param self Self reference
-- @param #number value value
-- @return #boolean

---
-- Function WriteIntRect()
--
-- @function [parent=#VectorBuffer] WriteIntRect
-- @param self Self reference
-- @param IntRect#IntRect value value
-- @return #boolean

---
-- Function WriteIntVector2()
--
-- @function [parent=#VectorBuffer] WriteIntVector2
-- @param self Self reference
-- @param IntVector2#IntVector2 value value
-- @return #boolean

---
-- Function WriteRect()
--
-- @function [parent=#VectorBuffer] WriteRect
-- @param self Self reference
-- @param Rect#Rect value value
-- @return #boolean

---
-- Function WriteVector2()
--
-- @function [parent=#VectorBuffer] WriteVector2
-- @param self Self reference
-- @param Vector2#Vector2 value value
-- @return #boolean

---
-- Function WriteVector3()
--
-- @function [parent=#VectorBuffer] WriteVector3
-- @param self Self reference
-- @param Vector3#Vector3 value value
-- @return #boolean

---
-- Function WritePackedVector3()
--
-- @function [parent=#VectorBuffer] WritePackedVector3
-- @param self Self reference
-- @param Vector3#Vector3 value value
-- @param #number maxAbsCoord maxAbsCoord
-- @return #boolean

---
-- Function WriteVector4()
--
-- @function [parent=#VectorBuffer] WriteVector4
-- @param self Self reference
-- @param Vector4#Vector4 value value
-- @return #boolean

---
-- Function WriteQuaternion()
--
-- @function [parent=#VectorBuffer] WriteQuaternion
-- @param self Self reference
-- @param Quaternion#Quaternion value value
-- @return #boolean

---
-- Function WritePackedQuaternion()
--
-- @function [parent=#VectorBuffer] WritePackedQuaternion
-- @param self Self reference
-- @param Quaternion#Quaternion value value
-- @return #boolean

---
-- Function WriteMatrix3()
--
-- @function [parent=#VectorBuffer] WriteMatrix3
-- @param self Self reference
-- @param Matrix3#Matrix3 value value
-- @return #boolean

---
-- Function WriteMatrix3x4()
--
-- @function [parent=#VectorBuffer] WriteMatrix3x4
-- @param self Self reference
-- @param Matrix3x4#Matrix3x4 value value
-- @return #boolean

---
-- Function WriteMatrix4()
--
-- @function [parent=#VectorBuffer] WriteMatrix4
-- @param self Self reference
-- @param Matrix4#Matrix4 value value
-- @return #boolean

---
-- Function WriteColor()
--
-- @function [parent=#VectorBuffer] WriteColor
-- @param self Self reference
-- @param Color#Color value value
-- @return #boolean

---
-- Function WriteBoundingBox()
--
-- @function [parent=#VectorBuffer] WriteBoundingBox
-- @param self Self reference
-- @param BoundingBox#BoundingBox value value
-- @return #boolean

---
-- Function WriteString()
--
-- @function [parent=#VectorBuffer] WriteString
-- @param self Self reference
-- @param #string value value
-- @return #boolean

---
-- Function WriteFileID()
--
-- @function [parent=#VectorBuffer] WriteFileID
-- @param self Self reference
-- @param #string value value
-- @return #boolean

---
-- Function WriteStringHash()
--
-- @function [parent=#VectorBuffer] WriteStringHash
-- @param self Self reference
-- @param StringHash#StringHash value value
-- @return #boolean

---
-- Function WriteShortStringHash()
--
-- @function [parent=#VectorBuffer] WriteShortStringHash
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash value value
-- @return #boolean

---
-- Function WriteBuffer()
--
-- @function [parent=#VectorBuffer] WriteBuffer
-- @param self Self reference
-- @param VectorBuffer#VectorBuffer buffer buffer
-- @return #boolean

---
-- Function WriteResourceRef()
--
-- @function [parent=#VectorBuffer] WriteResourceRef
-- @param self Self reference
-- @param ResourceRef#ResourceRef value value
-- @return #boolean

---
-- Function WriteResourceRefList()
--
-- @function [parent=#VectorBuffer] WriteResourceRefList
-- @param self Self reference
-- @param ResourceRefList#ResourceRefList value value
-- @return #boolean

---
-- Function WriteVariant()
--
-- @function [parent=#VectorBuffer] WriteVariant
-- @param self Self reference
-- @param Variant#Variant value value
-- @return #boolean

---
-- Function WriteVariantData()
--
-- @function [parent=#VectorBuffer] WriteVariantData
-- @param self Self reference
-- @param Variant#Variant value value
-- @return #boolean

---
-- Function WriteVariantVector()
--
-- @function [parent=#VectorBuffer] WriteVariantVector
-- @param self Self reference
-- @param VariantVector#VariantVector value value
-- @return #boolean

---
-- Function WriteVariantMap()
--
-- @function [parent=#VectorBuffer] WriteVariantMap
-- @param self Self reference
-- @param VariantMap#VariantMap value value
-- @return #boolean

---
-- Function WriteVLE()
--
-- @function [parent=#VectorBuffer] WriteVLE
-- @param self Self reference
-- @param #number value value
-- @return #boolean

---
-- Function WriteNetID()
--
-- @function [parent=#VectorBuffer] WriteNetID
-- @param self Self reference
-- @param #number value value
-- @return #boolean

---
-- Function WriteLine()
--
-- @function [parent=#VectorBuffer] WriteLine
-- @param self Self reference
-- @param #string value value
-- @return #boolean

---
-- Field name (Read only)
--
-- @field [parent=#VectorBuffer] #string name

---
-- Field checksum (Read only)
--
-- @field [parent=#VectorBuffer] #number checksum

---
-- Field position (Read only)
--
-- @field [parent=#VectorBuffer] #number position

---
-- Field size (Read only)
--
-- @field [parent=#VectorBuffer] #number size

---
-- Field eof (Read only)
--
-- @field [parent=#VectorBuffer] #boolean eof


return nil
