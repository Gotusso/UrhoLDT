---
-- Enumeration LightType
--
-- @module LightType

---
-- Enumeration value LIGHT_DIRECTIONAL
--
-- @field [parent=#LightType] #number LIGHT_DIRECTIONAL

---
-- Enumeration value LIGHT_SPOT
--
-- @field [parent=#LightType] #number LIGHT_SPOT

---
-- Enumeration value LIGHT_POINT
--
-- @field [parent=#LightType] #number LIGHT_POINT


return nil
