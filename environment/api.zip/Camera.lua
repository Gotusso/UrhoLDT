---
-- Module Camera
-- Module Camera extends Component
-- Generated on 2014-05-31
--
-- @module Camera

---
-- Function SetNearClip()
-- Set near clip distance.
--
-- @function [parent=#Camera] SetNearClip
-- @param self Self reference
-- @param #number nearClip nearClip

---
-- Function SetFarClip()
-- Set far clip distance.
--
-- @function [parent=#Camera] SetFarClip
-- @param self Self reference
-- @param #number farClip farClip

---
-- Function SetFov()
-- Set vertical field of view in degrees.
--
-- @function [parent=#Camera] SetFov
-- @param self Self reference
-- @param #number fov fov

---
-- Function SetOrthoSize()
-- Set orthographic mode view uniform size.
--
-- @function [parent=#Camera] SetOrthoSize
-- @param self Self reference
-- @param #number orthoSize orthoSize

---
-- Function SetOrthoSize()
-- Set orthographic mode view non-uniform size. Disables the auto aspect ratio -mode.
--
-- @function [parent=#Camera] SetOrthoSize
-- @param self Self reference
-- @param Vector2#Vector2 orthoSize orthoSize

---
-- Function SetAspectRatio()
-- Set aspect ratio manually. Disables the auto aspect ratio -mode.
--
-- @function [parent=#Camera] SetAspectRatio
-- @param self Self reference
-- @param #number aspectRatio aspectRatio

---
-- Function SetFillMode()
-- Set polygon fill mode to use when rendering a scene.
--
-- @function [parent=#Camera] SetFillMode
-- @param self Self reference
-- @param FillMode#FillMode mode mode

---
-- Function SetZoom()
-- Set zoom.
--
-- @function [parent=#Camera] SetZoom
-- @param self Self reference
-- @param #number zoom zoom

---
-- Function SetLodBias()
-- Set LOD bias.
--
-- @function [parent=#Camera] SetLodBias
-- @param self Self reference
-- @param #number bias bias

---
-- Function SetViewMask()
-- Set view mask. Will be and'ed with object's view mask to see if the object should be rendered.
--
-- @function [parent=#Camera] SetViewMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetViewOverrideFlags()
-- Set view override flags.
--
-- @function [parent=#Camera] SetViewOverrideFlags
-- @param self Self reference
-- @param #number flags flags

---
-- Function SetOrthographic()
-- Set orthographic mode enabled/disabled.
--
-- @function [parent=#Camera] SetOrthographic
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetAutoAspectRatio()
-- Set automatic aspect ratio based on viewport dimensions. Enabled by default.
--
-- @function [parent=#Camera] SetAutoAspectRatio
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetProjectionOffset()
-- Set projection offset. It needs to be calculated as (offset in pixels) / (viewport dimensions.)
--
-- @function [parent=#Camera] SetProjectionOffset
-- @param self Self reference
-- @param Vector2#Vector2 offset offset

---
-- Function SetUseReflection()
-- Set reflection mode.
--
-- @function [parent=#Camera] SetUseReflection
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetReflectionPlane()
-- Set reflection plane in world space for reflection mode.
--
-- @function [parent=#Camera] SetReflectionPlane
-- @param self Self reference
-- @param Plane#Plane reflectionPlane reflectionPlane

---
-- Function SetUseClipping()
-- Set whether to use a custom clip plane.
--
-- @function [parent=#Camera] SetUseClipping
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetClipPlane()
-- Set custom clipping plane in world space.
--
-- @function [parent=#Camera] SetClipPlane
-- @param self Self reference
-- @param Plane#Plane clipPlane clipPlane

---
-- Function GetFarClip()
-- Return far clip distance.
--
-- @function [parent=#Camera] GetFarClip
-- @param self Self reference
-- @return #number

---
-- Function GetNearClip()
-- Return near clip distance.
--
-- @function [parent=#Camera] GetNearClip
-- @param self Self reference
-- @return #number

---
-- Function GetFov()
-- Return vertical field of view in degrees.
--
-- @function [parent=#Camera] GetFov
-- @param self Self reference
-- @return #number

---
-- Function GetOrthoSize()
-- Return orthographic mode size.
--
-- @function [parent=#Camera] GetOrthoSize
-- @param self Self reference
-- @return #number

---
-- Function GetAspectRatio()
-- Return aspect ratio.
--
-- @function [parent=#Camera] GetAspectRatio
-- @param self Self reference
-- @return #number

---
-- Function GetZoom()
-- Return zoom.
--
-- @function [parent=#Camera] GetZoom
-- @param self Self reference
-- @return #number

---
-- Function GetLodBias()
-- Return LOD bias.
--
-- @function [parent=#Camera] GetLodBias
-- @param self Self reference
-- @return #number

---
-- Function GetViewMask()
-- Return view mask.
--
-- @function [parent=#Camera] GetViewMask
-- @param self Self reference
-- @return #number

---
-- Function GetViewOverrideFlags()
-- Return view override flags.
--
-- @function [parent=#Camera] GetViewOverrideFlags
-- @param self Self reference
-- @return #number

---
-- Function GetFillMode()
-- Return fill mode.
--
-- @function [parent=#Camera] GetFillMode
-- @param self Self reference
-- @return FillMode#FillMode

---
-- Function IsOrthographic()
-- Return orthographic flag.
--
-- @function [parent=#Camera] IsOrthographic
-- @param self Self reference
-- @return #boolean

---
-- Function GetAutoAspectRatio()
-- Return auto aspect ratio flag.
--
-- @function [parent=#Camera] GetAutoAspectRatio
-- @param self Self reference
-- @return #boolean

---
-- Function GetFrustum()
-- Return frustum in world space.
--
-- @function [parent=#Camera] GetFrustum
-- @param self Self reference
-- @return const Frustum#const Frustum

---
-- Function GetProjection()
-- Return API-specific projection matrix.
--
-- @function [parent=#Camera] GetProjection
-- @param self Self reference
-- @return const Matrix4#const Matrix4

---
-- Function GetView()
-- Return view matrix.
--
-- @function [parent=#Camera] GetView
-- @param self Self reference
-- @return const Matrix3x4#const Matrix3x4

---
-- Function GetFrustumSize()
-- Return frustum near and far sizes.
--
-- @function [parent=#Camera] GetFrustumSize
-- @param self Self reference
-- @param Vector3#Vector3 near near
-- @param Vector3#Vector3 far far

---
-- Function GetHalfViewSize()
-- Return half view size.
--
-- @function [parent=#Camera] GetHalfViewSize
-- @param self Self reference
-- @return #number

---
-- Function GetSplitFrustum()
-- Return frustum split by custom near and far clip distances.
--
-- @function [parent=#Camera] GetSplitFrustum
-- @param self Self reference
-- @param #number nearClip nearClip
-- @param #number farClip farClip
-- @return Frustum#Frustum

---
-- Function GetViewSpaceFrustum()
-- Return frustum in view space.
--
-- @function [parent=#Camera] GetViewSpaceFrustum
-- @param self Self reference
-- @return Frustum#Frustum

---
-- Function GetViewSpaceSplitFrustum()
-- Return split frustum in view space.
--
-- @function [parent=#Camera] GetViewSpaceSplitFrustum
-- @param self Self reference
-- @param #number nearClip nearClip
-- @param #number farClip farClip
-- @return Frustum#Frustum

---
-- Function GetScreenRay()
-- Return ray corresponding to normalized screen coordinates (0.0 to 1.0.)
--
-- @function [parent=#Camera] GetScreenRay
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @return Ray#Ray

---
-- Function WorldToScreenPoint()
--
-- @function [parent=#Camera] WorldToScreenPoint
-- @param self Self reference
-- @param Vector3#Vector3 worldPos worldPos
-- @return Vector2#Vector2

---
-- Function ScreenToWorldPoint()
--
-- @function [parent=#Camera] ScreenToWorldPoint
-- @param self Self reference
-- @param Vector3#Vector3 screenPos screenPos
-- @return Vector3#Vector3

---
-- Function GetProjectionOffset()
-- Return projection offset.
--
-- @function [parent=#Camera] GetProjectionOffset
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Function GetUseReflection()
-- Return whether is using reflection.
--
-- @function [parent=#Camera] GetUseReflection
-- @param self Self reference
-- @return #boolean

---
-- Function GetReflectionPlane()
-- Return the reflection plane.
--
-- @function [parent=#Camera] GetReflectionPlane
-- @param self Self reference
-- @return const Plane#const Plane

---
-- Function GetUseClipping()
-- Return whether is using a custom clipping plane.
--
-- @function [parent=#Camera] GetUseClipping
-- @param self Self reference
-- @return #boolean

---
-- Function GetClipPlane()
-- Return the custom clipping plane.
--
-- @function [parent=#Camera] GetClipPlane
-- @param self Self reference
-- @return const Plane#const Plane

---
-- Function GetDistance()
-- Return distance to position. In orthographic mode uses only Z coordinate.
--
-- @function [parent=#Camera] GetDistance
-- @param self Self reference
-- @param Vector3#Vector3 worldPos worldPos
-- @return #number

---
-- Function GetDistanceSquared()
-- Return squared distance to position. In orthographic mode uses only Z coordinate.
--
-- @function [parent=#Camera] GetDistanceSquared
-- @param self Self reference
-- @param Vector3#Vector3 worldPos worldPos
-- @return #number

---
-- Function GetLodDistance()
-- Return a scene node's LOD scaled distance.
--
-- @function [parent=#Camera] GetLodDistance
-- @param self Self reference
-- @param #number distance distance
-- @param #number scale scale
-- @param #number bias bias
-- @return #number

---
-- Function IsProjectionValid()
-- Return if projection parameters are valid for rendering and raycasting.
--
-- @function [parent=#Camera] IsProjectionValid
-- @param self Self reference
-- @return #boolean

---
-- Function GetEffectiveWorldTransform()
-- Get effective world transform for matrix and frustum calculations including reflection but excluding node scaling.
--
-- @function [parent=#Camera] GetEffectiveWorldTransform
-- @param self Self reference
-- @return Matrix3x4#Matrix3x4

---
-- Field farClip
--
-- @field [parent=#Camera] #number farClip

---
-- Field nearClip
--
-- @field [parent=#Camera] #number nearClip

---
-- Field fov
--
-- @field [parent=#Camera] #number fov

---
-- Field orthoSize
--
-- @field [parent=#Camera] #number orthoSize

---
-- Field aspectRatio
--
-- @field [parent=#Camera] #number aspectRatio

---
-- Field zoom
--
-- @field [parent=#Camera] #number zoom

---
-- Field lodBias
--
-- @field [parent=#Camera] #number lodBias

---
-- Field viewMask
--
-- @field [parent=#Camera] #number viewMask

---
-- Field viewOverrideFlags
--
-- @field [parent=#Camera] #number viewOverrideFlags

---
-- Field fillMode
--
-- @field [parent=#Camera] FillMode#FillMode fillMode

---
-- Field orthographic
--
-- @field [parent=#Camera] #boolean orthographic

---
-- Field autoAspectRatio
--
-- @field [parent=#Camera] #boolean autoAspectRatio

---
-- Field frustum (Read only)
--
-- @field [parent=#Camera] Frustum#Frustum frustum

---
-- Field projection (Read only)
--
-- @field [parent=#Camera] Matrix4#Matrix4 projection

---
-- Field view (Read only)
--
-- @field [parent=#Camera] Matrix3x4#Matrix3x4 view

---
-- Field halfViewSize (Read only)
--
-- @field [parent=#Camera] #number halfViewSize

---
-- Field viewSpaceFrustum (Read only)
--
-- @field [parent=#Camera] Frustum#Frustum viewSpaceFrustum

---
-- Field projectionOffset
--
-- @field [parent=#Camera] Vector2#Vector2 projectionOffset

---
-- Field useReflection
--
-- @field [parent=#Camera] #boolean useReflection

---
-- Field reflectionPlane
--
-- @field [parent=#Camera] Plane#Plane reflectionPlane

---
-- Field useClipping
--
-- @field [parent=#Camera] #boolean useClipping

---
-- Field clipPlane
--
-- @field [parent=#Camera] Plane#Plane clipPlane

---
-- Field projectionValid (Read only)
--
-- @field [parent=#Camera] #boolean projectionValid

---
-- Field effectiveWorldTransform (Read only)
--
-- @field [parent=#Camera] Matrix3x4#Matrix3x4 effectiveWorldTransform


return nil
