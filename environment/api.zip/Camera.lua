---
-- Module Camera
-- extends Component
--
-- @module Camera

---
-- Function SetNearClip
--
-- @function [parent=#Camera] SetNearClip
-- @param #number nearClipnearClip

---
-- Function SetFarClip
--
-- @function [parent=#Camera] SetFarClip
-- @param #number farClipfarClip

---
-- Function SetFov
--
-- @function [parent=#Camera] SetFov
-- @param #number fovfov

---
-- Function SetOrthoSize
--
-- @function [parent=#Camera] SetOrthoSize
-- @param #number orthoSizeorthoSize

---
-- Function SetOrthoSize
--
-- @function [parent=#Camera] SetOrthoSize
-- @param Vector2#Vector2 orthoSizeorthoSize

---
-- Function SetAspectRatio
--
-- @function [parent=#Camera] SetAspectRatio
-- @param #number aspectRatioaspectRatio

---
-- Function SetFillMode
--
-- @function [parent=#Camera] SetFillMode
-- @param FillMode#FillMode modemode

---
-- Function SetZoom
--
-- @function [parent=#Camera] SetZoom
-- @param #number zoomzoom

---
-- Function SetLodBias
--
-- @function [parent=#Camera] SetLodBias
-- @param #number biasbias

---
-- Function SetViewMask
--
-- @function [parent=#Camera] SetViewMask
-- @param #number maskmask

---
-- Function SetViewOverrideFlags
--
-- @function [parent=#Camera] SetViewOverrideFlags
-- @param #number flagsflags

---
-- Function SetOrthographic
--
-- @function [parent=#Camera] SetOrthographic
-- @param #boolean enableenable

---
-- Function SetAutoAspectRatio
--
-- @function [parent=#Camera] SetAutoAspectRatio
-- @param #boolean enableenable

---
-- Function SetProjectionOffset
--
-- @function [parent=#Camera] SetProjectionOffset
-- @param Vector2#Vector2 offsetoffset

---
-- Function SetUseReflection
--
-- @function [parent=#Camera] SetUseReflection
-- @param #boolean enableenable

---
-- Function SetReflectionPlane
--
-- @function [parent=#Camera] SetReflectionPlane
-- @param Plane#Plane reflectionPlanereflectionPlane

---
-- Function SetUseClipping
--
-- @function [parent=#Camera] SetUseClipping
-- @param #boolean enableenable

---
-- Function SetClipPlane
--
-- @function [parent=#Camera] SetClipPlane
-- @param Plane#Plane clipPlaneclipPlane

---
-- Function GetFarClip
--
-- @function [parent=#Camera] GetFarClip
-- @return #number

---
-- Function GetNearClip
--
-- @function [parent=#Camera] GetNearClip
-- @return #number

---
-- Function GetFov
--
-- @function [parent=#Camera] GetFov
-- @return #number

---
-- Function GetOrthoSize
--
-- @function [parent=#Camera] GetOrthoSize
-- @return #number

---
-- Function GetAspectRatio
--
-- @function [parent=#Camera] GetAspectRatio
-- @return #number

---
-- Function GetZoom
--
-- @function [parent=#Camera] GetZoom
-- @return #number

---
-- Function GetLodBias
--
-- @function [parent=#Camera] GetLodBias
-- @return #number

---
-- Function GetViewMask
--
-- @function [parent=#Camera] GetViewMask
-- @return #number

---
-- Function GetViewOverrideFlags
--
-- @function [parent=#Camera] GetViewOverrideFlags
-- @return #number

---
-- Function GetFillMode
--
-- @function [parent=#Camera] GetFillMode
-- @return FillMode#FillMode

---
-- Function IsOrthographic
--
-- @function [parent=#Camera] IsOrthographic
-- @return #boolean

---
-- Function GetAutoAspectRatio
--
-- @function [parent=#Camera] GetAutoAspectRatio
-- @return #boolean

---
-- Function GetFrustum
--
-- @function [parent=#Camera] GetFrustum
-- @return const Frustum#const Frustum

---
-- Function GetProjection
--
-- @function [parent=#Camera] GetProjection
-- @return const Matrix4#const Matrix4

---
-- Function GetView
--
-- @function [parent=#Camera] GetView
-- @return const Matrix3x4#const Matrix3x4

---
-- Function GetFrustumSize
--
-- @function [parent=#Camera] GetFrustumSize
-- @param Vector3#Vector3 nearnear
-- @param Vector3#Vector3 farfar

---
-- Function GetHalfViewSize
--
-- @function [parent=#Camera] GetHalfViewSize
-- @return #number

---
-- Function GetSplitFrustum
--
-- @function [parent=#Camera] GetSplitFrustum
-- @param #number nearClipnearClip
-- @param #number farClipfarClip
-- @return Frustum#Frustum

---
-- Function GetViewSpaceFrustum
--
-- @function [parent=#Camera] GetViewSpaceFrustum
-- @return Frustum#Frustum

---
-- Function GetViewSpaceSplitFrustum
--
-- @function [parent=#Camera] GetViewSpaceSplitFrustum
-- @param #number nearClipnearClip
-- @param #number farClipfarClip
-- @return Frustum#Frustum

---
-- Function GetScreenRay
--
-- @function [parent=#Camera] GetScreenRay
-- @param #number xx
-- @param #number yy
-- @return Ray#Ray

---
-- Function WorldToScreenPoint
--
-- @function [parent=#Camera] WorldToScreenPoint
-- @param Vector3#Vector3 worldPosworldPos
-- @return Vector2#Vector2

---
-- Function ScreenToWorldPoint
--
-- @function [parent=#Camera] ScreenToWorldPoint
-- @param Vector3#Vector3 screenPosscreenPos
-- @return Vector3#Vector3

---
-- Function GetProjectionOffset
--
-- @function [parent=#Camera] GetProjectionOffset
-- @return const Vector2#const Vector2

---
-- Function GetUseReflection
--
-- @function [parent=#Camera] GetUseReflection
-- @return #boolean

---
-- Function GetReflectionPlane
--
-- @function [parent=#Camera] GetReflectionPlane
-- @return const Plane#const Plane

---
-- Function GetUseClipping
--
-- @function [parent=#Camera] GetUseClipping
-- @return #boolean

---
-- Function GetClipPlane
--
-- @function [parent=#Camera] GetClipPlane
-- @return const Plane#const Plane

---
-- Function GetDistance
--
-- @function [parent=#Camera] GetDistance
-- @param Vector3#Vector3 worldPosworldPos
-- @return #number

---
-- Function GetDistanceSquared
--
-- @function [parent=#Camera] GetDistanceSquared
-- @param Vector3#Vector3 worldPosworldPos
-- @return #number

---
-- Function GetLodDistance
--
-- @function [parent=#Camera] GetLodDistance
-- @param #number distancedistance
-- @param #number scalescale
-- @param #number biasbias
-- @return #number

---
-- Function IsProjectionValid
--
-- @function [parent=#Camera] IsProjectionValid
-- @return #boolean

---
-- Function GetEffectiveWorldTransform
--
-- @function [parent=#Camera] GetEffectiveWorldTransform
-- @return Matrix3x4#Matrix3x4

---
-- Field farClip
--
-- @field [parent=#Camera] #number farClip

---
-- Field nearClip
--
-- @field [parent=#Camera] #number nearClip

---
-- Field fov
--
-- @field [parent=#Camera] #number fov

---
-- Field orthoSize
--
-- @field [parent=#Camera] #number orthoSize

---
-- Field aspectRatio
--
-- @field [parent=#Camera] #number aspectRatio

---
-- Field zoom
--
-- @field [parent=#Camera] #number zoom

---
-- Field lodBias
--
-- @field [parent=#Camera] #number lodBias

---
-- Field viewMask
--
-- @field [parent=#Camera] #number viewMask

---
-- Field viewOverrideFlags
--
-- @field [parent=#Camera] #number viewOverrideFlags

---
-- Field fillMode
--
-- @field [parent=#Camera] FillMode#FillMode fillMode

---
-- Field orthographic
--
-- @field [parent=#Camera] #boolean orthographic

---
-- Field autoAspectRatio
--
-- @field [parent=#Camera] #boolean autoAspectRatio

---
-- Field frustum (Read only)
--
-- @field [parent=#Camera] Frustum#Frustum frustum

---
-- Field projection (Read only)
--
-- @field [parent=#Camera] Matrix4#Matrix4 projection

---
-- Field view (Read only)
--
-- @field [parent=#Camera] Matrix3x4#Matrix3x4 view

---
-- Field halfViewSize (Read only)
--
-- @field [parent=#Camera] #number halfViewSize

---
-- Field viewSpaceFrustum (Read only)
--
-- @field [parent=#Camera] Frustum#Frustum viewSpaceFrustum

---
-- Field projectionOffset
--
-- @field [parent=#Camera] Vector2#Vector2 projectionOffset

---
-- Field useReflection
--
-- @field [parent=#Camera] #boolean useReflection

---
-- Field reflectionPlane
--
-- @field [parent=#Camera] Plane#Plane reflectionPlane

---
-- Field useClipping
--
-- @field [parent=#Camera] #boolean useClipping

---
-- Field clipPlane
--
-- @field [parent=#Camera] Plane#Plane clipPlane

---
-- Field projectionValid (Read only)
--
-- @field [parent=#Camera] #boolean projectionValid

---
-- Field effectiveWorldTransform (Read only)
--
-- @field [parent=#Camera] Matrix3x4#Matrix3x4 effectiveWorldTransform

---
-- Function SetEnabled
--
-- @function [parent=#Camera] SetEnabled
-- @param #boolean enableenable

---
-- Function Remove
--
-- @function [parent=#Camera] Remove

---
-- Function GetID
--
-- @function [parent=#Camera] GetID
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#Camera] GetNode
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#Camera] GetScene
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#Camera] IsEnabled
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#Camera] IsEnabledEffective
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#Camera] GetComponent
-- @param ShortStringHash#ShortStringHash typetype
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#Camera] GetComponent
-- @param #string typetype
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#Camera] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#Camera] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Camera] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Camera] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Camera] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Camera] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Camera] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Camera] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#Camera] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Camera] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Camera] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Camera] #string category


return nil
