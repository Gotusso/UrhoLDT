---
-- Module RigidBody
-- extends Component
--
-- @module RigidBody

---
-- Function SetMass
--
-- @function [parent=#RigidBody] SetMass
-- @param #number massmass

---
-- Function SetPosition
--
-- @function [parent=#RigidBody] SetPosition
-- @param Vector3#Vector3 positionposition

---
-- Function SetRotation
--
-- @function [parent=#RigidBody] SetRotation
-- @param Quaternion#Quaternion rotationrotation

---
-- Function SetTransform
--
-- @function [parent=#RigidBody] SetTransform
-- @param Vector3#Vector3 positionposition
-- @param Quaternion#Quaternion rotationrotation

---
-- Function SetLinearVelocity
--
-- @function [parent=#RigidBody] SetLinearVelocity
-- @param Vector3#Vector3 velocityvelocity

---
-- Function SetLinearFactor
--
-- @function [parent=#RigidBody] SetLinearFactor
-- @param Vector3#Vector3 factorfactor

---
-- Function SetLinearRestThreshold
--
-- @function [parent=#RigidBody] SetLinearRestThreshold
-- @param #number thresholdthreshold

---
-- Function SetLinearDamping
--
-- @function [parent=#RigidBody] SetLinearDamping
-- @param #number dampingdamping

---
-- Function SetAngularVelocity
--
-- @function [parent=#RigidBody] SetAngularVelocity
-- @param Vector3#Vector3 angularVelocityangularVelocity

---
-- Function SetAngularFactor
--
-- @function [parent=#RigidBody] SetAngularFactor
-- @param Vector3#Vector3 factorfactor

---
-- Function SetAngularRestThreshold
--
-- @function [parent=#RigidBody] SetAngularRestThreshold
-- @param #number thresholdthreshold

---
-- Function SetAngularDamping
--
-- @function [parent=#RigidBody] SetAngularDamping
-- @param #number factorfactor

---
-- Function SetFriction
--
-- @function [parent=#RigidBody] SetFriction
-- @param #number frictionfriction

---
-- Function SetAnisotropicFriction
--
-- @function [parent=#RigidBody] SetAnisotropicFriction
-- @param Vector3#Vector3 frictionfriction

---
-- Function SetRollingFriction
--
-- @function [parent=#RigidBody] SetRollingFriction
-- @param #number frictionfriction

---
-- Function SetRestitution
--
-- @function [parent=#RigidBody] SetRestitution
-- @param #number restitutionrestitution

---
-- Function SetContactProcessingThreshold
--
-- @function [parent=#RigidBody] SetContactProcessingThreshold
-- @param #number thresholdthreshold

---
-- Function SetCcdRadius
--
-- @function [parent=#RigidBody] SetCcdRadius
-- @param #number radiusradius

---
-- Function SetCcdMotionThreshold
--
-- @function [parent=#RigidBody] SetCcdMotionThreshold
-- @param #number thresholdthreshold

---
-- Function SetUseGravity
--
-- @function [parent=#RigidBody] SetUseGravity
-- @param #boolean enableenable

---
-- Function SetGravityOverride
--
-- @function [parent=#RigidBody] SetGravityOverride
-- @param Vector3#Vector3 gravitygravity

---
-- Function SetKinematic
--
-- @function [parent=#RigidBody] SetKinematic
-- @param #boolean enableenable

---
-- Function SetPhantom
--
-- @function [parent=#RigidBody] SetPhantom
-- @param #boolean enableenable

---
-- Function SetCollisionLayer
--
-- @function [parent=#RigidBody] SetCollisionLayer
-- @param #number layerlayer

---
-- Function SetCollisionMask
--
-- @function [parent=#RigidBody] SetCollisionMask
-- @param #number maskmask

---
-- Function SetCollisionLayerAndMask
--
-- @function [parent=#RigidBody] SetCollisionLayerAndMask
-- @param #number layerlayer
-- @param #number maskmask

---
-- Function SetCollisionEventMode
--
-- @function [parent=#RigidBody] SetCollisionEventMode
-- @param CollisionEventMode#CollisionEventMode modemode

---
-- Function ApplyForce
--
-- @function [parent=#RigidBody] ApplyForce
-- @param Vector3#Vector3 forceforce

---
-- Function ApplyForce
--
-- @function [parent=#RigidBody] ApplyForce
-- @param Vector3#Vector3 forceforce
-- @param Vector3#Vector3 positionposition

---
-- Function ApplyTorque
--
-- @function [parent=#RigidBody] ApplyTorque
-- @param Vector3#Vector3 torquetorque

---
-- Function ApplyImpulse
--
-- @function [parent=#RigidBody] ApplyImpulse
-- @param Vector3#Vector3 impulseimpulse

---
-- Function ApplyImpulse
--
-- @function [parent=#RigidBody] ApplyImpulse
-- @param Vector3#Vector3 impulseimpulse
-- @param Vector3#Vector3 positionposition

---
-- Function ApplyTorqueImpulse
--
-- @function [parent=#RigidBody] ApplyTorqueImpulse
-- @param Vector3#Vector3 torquetorque

---
-- Function ResetForces
--
-- @function [parent=#RigidBody] ResetForces

---
-- Function Activate
--
-- @function [parent=#RigidBody] Activate

---
-- Function ReAddBodyToWorld
--
-- @function [parent=#RigidBody] ReAddBodyToWorld

---
-- Function GetPhysicsWorld
--
-- @function [parent=#RigidBody] GetPhysicsWorld
-- @return PhysicsWorld#PhysicsWorld

---
-- Function GetMass
--
-- @function [parent=#RigidBody] GetMass
-- @return #number

---
-- Function GetPosition
--
-- @function [parent=#RigidBody] GetPosition
-- @return Vector3#Vector3

---
-- Function GetRotation
--
-- @function [parent=#RigidBody] GetRotation
-- @return Quaternion#Quaternion

---
-- Function GetLinearVelocity
--
-- @function [parent=#RigidBody] GetLinearVelocity
-- @return Vector3#Vector3

---
-- Function GetLinearFactor
--
-- @function [parent=#RigidBody] GetLinearFactor
-- @return Vector3#Vector3

---
-- Function GetVelocityAtPoint
--
-- @function [parent=#RigidBody] GetVelocityAtPoint
-- @param Vector3#Vector3 positionposition
-- @return Vector3#Vector3

---
-- Function GetLinearRestThreshold
--
-- @function [parent=#RigidBody] GetLinearRestThreshold
-- @return #number

---
-- Function GetLinearDamping
--
-- @function [parent=#RigidBody] GetLinearDamping
-- @return #number

---
-- Function GetAngularVelocity
--
-- @function [parent=#RigidBody] GetAngularVelocity
-- @return Vector3#Vector3

---
-- Function GetAngularFactor
--
-- @function [parent=#RigidBody] GetAngularFactor
-- @return Vector3#Vector3

---
-- Function GetAngularRestThreshold
--
-- @function [parent=#RigidBody] GetAngularRestThreshold
-- @return #number

---
-- Function GetAngularDamping
--
-- @function [parent=#RigidBody] GetAngularDamping
-- @return #number

---
-- Function GetFriction
--
-- @function [parent=#RigidBody] GetFriction
-- @return #number

---
-- Function GetAnisotropicFriction
--
-- @function [parent=#RigidBody] GetAnisotropicFriction
-- @return Vector3#Vector3

---
-- Function GetRollingFriction
--
-- @function [parent=#RigidBody] GetRollingFriction
-- @return #number

---
-- Function GetRestitution
--
-- @function [parent=#RigidBody] GetRestitution
-- @return #number

---
-- Function GetContactProcessingThreshold
--
-- @function [parent=#RigidBody] GetContactProcessingThreshold
-- @return #number

---
-- Function GetCcdRadius
--
-- @function [parent=#RigidBody] GetCcdRadius
-- @return #number

---
-- Function GetCcdMotionThreshold
--
-- @function [parent=#RigidBody] GetCcdMotionThreshold
-- @return #number

---
-- Function GetUseGravity
--
-- @function [parent=#RigidBody] GetUseGravity
-- @return #boolean

---
-- Function GetGravityOverride
--
-- @function [parent=#RigidBody] GetGravityOverride
-- @return const Vector3#const Vector3

---
-- Function GetCenterOfMass
--
-- @function [parent=#RigidBody] GetCenterOfMass
-- @return const Vector3#const Vector3

---
-- Function IsKinematic
--
-- @function [parent=#RigidBody] IsKinematic
-- @return #boolean

---
-- Function IsPhantom
--
-- @function [parent=#RigidBody] IsPhantom
-- @return #boolean

---
-- Function IsActive
--
-- @function [parent=#RigidBody] IsActive
-- @return #boolean

---
-- Function GetCollisionLayer
--
-- @function [parent=#RigidBody] GetCollisionLayer
-- @return #number

---
-- Function GetCollisionMask
--
-- @function [parent=#RigidBody] GetCollisionMask
-- @return #number

---
-- Function GetCollisionEventMode
--
-- @function [parent=#RigidBody] GetCollisionEventMode
-- @return CollisionEventMode#CollisionEventMode

---
-- Field physicsWorld (Read only)
--
-- @field [parent=#RigidBody] PhysicsWorld#PhysicsWorld physicsWorld

---
-- Field mass
--
-- @field [parent=#RigidBody] #number mass

---
-- Field position
--
-- @field [parent=#RigidBody] Vector3#Vector3 position

---
-- Field rotation
--
-- @field [parent=#RigidBody] Quaternion#Quaternion rotation

---
-- Field linearVelocity
--
-- @field [parent=#RigidBody] Vector3#Vector3 linearVelocity

---
-- Field linearFactor
--
-- @field [parent=#RigidBody] Vector3#Vector3 linearFactor

---
-- Field linearRestThreshold
--
-- @field [parent=#RigidBody] #number linearRestThreshold

---
-- Field linearDamping
--
-- @field [parent=#RigidBody] #number linearDamping

---
-- Field angularVelocity
--
-- @field [parent=#RigidBody] Vector3#Vector3 angularVelocity

---
-- Field angularFactor
--
-- @field [parent=#RigidBody] Vector3#Vector3 angularFactor

---
-- Field angularRestThreshold
--
-- @field [parent=#RigidBody] #number angularRestThreshold

---
-- Field angularDamping
--
-- @field [parent=#RigidBody] #number angularDamping

---
-- Field friction
--
-- @field [parent=#RigidBody] #number friction

---
-- Field anisotropicFriction
--
-- @field [parent=#RigidBody] Vector3#Vector3 anisotropicFriction

---
-- Field rollingFriction
--
-- @field [parent=#RigidBody] #number rollingFriction

---
-- Field restitution
--
-- @field [parent=#RigidBody] #number restitution

---
-- Field contactProcessingThreshold
--
-- @field [parent=#RigidBody] #number contactProcessingThreshold

---
-- Field ccdRadius
--
-- @field [parent=#RigidBody] #number ccdRadius

---
-- Field ccdMotionThreshold
--
-- @field [parent=#RigidBody] #number ccdMotionThreshold

---
-- Field useGravity
--
-- @field [parent=#RigidBody] #boolean useGravity

---
-- Field gravityOverride
--
-- @field [parent=#RigidBody] Vector3#Vector3 gravityOverride

---
-- Field centerOfMass (Read only)
--
-- @field [parent=#RigidBody] Vector3#Vector3 centerOfMass

---
-- Field kinematic
--
-- @field [parent=#RigidBody] #boolean kinematic

---
-- Field phantom
--
-- @field [parent=#RigidBody] #boolean phantom

---
-- Field active (Read only)
--
-- @field [parent=#RigidBody] #boolean active

---
-- Field collisionLayer
--
-- @field [parent=#RigidBody] #number collisionLayer

---
-- Field collisionMask
--
-- @field [parent=#RigidBody] #number collisionMask

---
-- Field collisionEventMode
--
-- @field [parent=#RigidBody] CollisionEventMode#CollisionEventMode collisionEventMode

---
-- Function SetEnabled
--
-- @function [parent=#RigidBody] SetEnabled
-- @param #boolean enableenable

---
-- Function Remove
--
-- @function [parent=#RigidBody] Remove

---
-- Function GetID
--
-- @function [parent=#RigidBody] GetID
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#RigidBody] GetNode
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#RigidBody] GetScene
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#RigidBody] IsEnabled
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#RigidBody] IsEnabledEffective
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#RigidBody] GetComponent
-- @param ShortStringHash#ShortStringHash typetype
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#RigidBody] GetComponent
-- @param #string typetype
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#RigidBody] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#RigidBody] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#RigidBody] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#RigidBody] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#RigidBody] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#RigidBody] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#RigidBody] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#RigidBody] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#RigidBody] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#RigidBody] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#RigidBody] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#RigidBody] #string category


return nil
