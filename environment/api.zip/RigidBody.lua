---
-- Module RigidBody
-- Module RigidBody extends Component
-- Generated on 2014-05-31
--
-- @module RigidBody

---
-- Function SetMass()
-- Set mass. Zero mass makes the body static.
--
-- @function [parent=#RigidBody] SetMass
-- @param self Self reference
-- @param #number mass mass

---
-- Function SetPosition()
-- Set rigid body position in world space.
--
-- @function [parent=#RigidBody] SetPosition
-- @param self Self reference
-- @param Vector3#Vector3 position position

---
-- Function SetRotation()
-- Set rigid body rotation in world space.
--
-- @function [parent=#RigidBody] SetRotation
-- @param self Self reference
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetTransform()
-- Set rigid body position and rotation in world space as an atomic operation.
--
-- @function [parent=#RigidBody] SetTransform
-- @param self Self reference
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetLinearVelocity()
-- Set linear velocity.
--
-- @function [parent=#RigidBody] SetLinearVelocity
-- @param self Self reference
-- @param Vector3#Vector3 velocity velocity

---
-- Function SetLinearFactor()
-- Set linear degrees of freedom. Use 1 to enable an axis or 0 to disable. Default is all axes enabled (1, 1, 1).
--
-- @function [parent=#RigidBody] SetLinearFactor
-- @param self Self reference
-- @param Vector3#Vector3 factor factor

---
-- Function SetLinearRestThreshold()
-- Set linear velocity deactivation threshold.
--
-- @function [parent=#RigidBody] SetLinearRestThreshold
-- @param self Self reference
-- @param #number threshold threshold

---
-- Function SetLinearDamping()
-- Set linear velocity damping factor.
--
-- @function [parent=#RigidBody] SetLinearDamping
-- @param self Self reference
-- @param #number damping damping

---
-- Function SetAngularVelocity()
-- Set angular velocity.
--
-- @function [parent=#RigidBody] SetAngularVelocity
-- @param self Self reference
-- @param Vector3#Vector3 angularVelocity angularVelocity

---
-- Function SetAngularFactor()
-- Set angular degrees of freedom. Use 1 to enable an axis or 0 to disable. Default is all axes enabled (1, 1, 1).
--
-- @function [parent=#RigidBody] SetAngularFactor
-- @param self Self reference
-- @param Vector3#Vector3 factor factor

---
-- Function SetAngularRestThreshold()
-- Set angular velocity deactivation threshold.
--
-- @function [parent=#RigidBody] SetAngularRestThreshold
-- @param self Self reference
-- @param #number threshold threshold

---
-- Function SetAngularDamping()
-- Set angular velocity damping factor.
--
-- @function [parent=#RigidBody] SetAngularDamping
-- @param self Self reference
-- @param #number factor factor

---
-- Function SetFriction()
-- Set friction coefficient.
--
-- @function [parent=#RigidBody] SetFriction
-- @param self Self reference
-- @param #number friction friction

---
-- Function SetAnisotropicFriction()
-- Set anisotropic friction.
--
-- @function [parent=#RigidBody] SetAnisotropicFriction
-- @param self Self reference
-- @param Vector3#Vector3 friction friction

---
-- Function SetRollingFriction()
-- Set rolling friction coefficient.
--
-- @function [parent=#RigidBody] SetRollingFriction
-- @param self Self reference
-- @param #number friction friction

---
-- Function SetRestitution()
-- Set restitution coefficient.
--
-- @function [parent=#RigidBody] SetRestitution
-- @param self Self reference
-- @param #number restitution restitution

---
-- Function SetContactProcessingThreshold()
-- Set contact processing threshold.
--
-- @function [parent=#RigidBody] SetContactProcessingThreshold
-- @param self Self reference
-- @param #number threshold threshold

---
-- Function SetCcdRadius()
-- Set continuous collision detection swept sphere radius.
--
-- @function [parent=#RigidBody] SetCcdRadius
-- @param self Self reference
-- @param #number radius radius

---
-- Function SetCcdMotionThreshold()
-- Set continuous collision detection motion-per-simulation-step threshold. 0 disables, which is the default.
--
-- @function [parent=#RigidBody] SetCcdMotionThreshold
-- @param self Self reference
-- @param #number threshold threshold

---
-- Function SetUseGravity()
-- Set whether gravity is applied to rigid body.
--
-- @function [parent=#RigidBody] SetUseGravity
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetGravityOverride()
-- Set gravity override. If zero, uses physics world's gravity.
--
-- @function [parent=#RigidBody] SetGravityOverride
-- @param self Self reference
-- @param Vector3#Vector3 gravity gravity

---
-- Function SetKinematic()
-- Set rigid body kinematic mode. In kinematic mode forces are not applied to the rigid body.
--
-- @function [parent=#RigidBody] SetKinematic
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetTrigger()
-- Set rigid body trigger mode. In trigger mode collisions are reported but do not apply forces.
--
-- @function [parent=#RigidBody] SetTrigger
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetCollisionLayer()
-- Set collision layer.
--
-- @function [parent=#RigidBody] SetCollisionLayer
-- @param self Self reference
-- @param #number layer layer

---
-- Function SetCollisionMask()
-- Set collision mask.
--
-- @function [parent=#RigidBody] SetCollisionMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetCollisionLayerAndMask()
-- Set collision group and mask.
--
-- @function [parent=#RigidBody] SetCollisionLayerAndMask
-- @param self Self reference
-- @param #number layer layer
-- @param #number mask mask

---
-- Function SetCollisionEventMode()
-- Set collision event signaling mode. Default is to signal when rigid bodies are active.
--
-- @function [parent=#RigidBody] SetCollisionEventMode
-- @param self Self reference
-- @param CollisionEventMode#CollisionEventMode mode mode

---
-- Function ApplyForce()
-- Apply force to center of mass.
--
-- @function [parent=#RigidBody] ApplyForce
-- @param self Self reference
-- @param Vector3#Vector3 force force

---
-- Function ApplyForce()
-- Apply force at local position.
--
-- @function [parent=#RigidBody] ApplyForce
-- @param self Self reference
-- @param Vector3#Vector3 force force
-- @param Vector3#Vector3 position position

---
-- Function ApplyTorque()
-- Apply torque.
--
-- @function [parent=#RigidBody] ApplyTorque
-- @param self Self reference
-- @param Vector3#Vector3 torque torque

---
-- Function ApplyImpulse()
-- Apply impulse to center of mass.
--
-- @function [parent=#RigidBody] ApplyImpulse
-- @param self Self reference
-- @param Vector3#Vector3 impulse impulse

---
-- Function ApplyImpulse()
-- Apply impulse at local position.
--
-- @function [parent=#RigidBody] ApplyImpulse
-- @param self Self reference
-- @param Vector3#Vector3 impulse impulse
-- @param Vector3#Vector3 position position

---
-- Function ApplyTorqueImpulse()
-- Apply torque impulse.
--
-- @function [parent=#RigidBody] ApplyTorqueImpulse
-- @param self Self reference
-- @param Vector3#Vector3 torque torque

---
-- Function ResetForces()
-- Reset accumulated forces.
--
-- @function [parent=#RigidBody] ResetForces
-- @param self Self reference

---
-- Function Activate()
-- Activate rigid body if it was resting.
--
-- @function [parent=#RigidBody] Activate
-- @param self Self reference

---
-- Function ReAddBodyToWorld()
-- Readd rigid body to the physics world to clean up internal state like stale contacts.
--
-- @function [parent=#RigidBody] ReAddBodyToWorld
-- @param self Self reference

---
-- Function GetPhysicsWorld()
-- Return physics world.
--
-- @function [parent=#RigidBody] GetPhysicsWorld
-- @param self Self reference
-- @return PhysicsWorld#PhysicsWorld

---
-- Function GetMass()
-- Return mass.
--
-- @function [parent=#RigidBody] GetMass
-- @param self Self reference
-- @return #number

---
-- Function GetPosition()
-- Return rigid body position in world space.
--
-- @function [parent=#RigidBody] GetPosition
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetRotation()
-- Return rigid body rotation in world space.
--
-- @function [parent=#RigidBody] GetRotation
-- @param self Self reference
-- @return Quaternion#Quaternion

---
-- Function GetLinearVelocity()
-- Return linear velocity.
--
-- @function [parent=#RigidBody] GetLinearVelocity
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetLinearFactor()
-- Return linear degrees of freedom.
--
-- @function [parent=#RigidBody] GetLinearFactor
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetVelocityAtPoint()
-- Return linear velocity at local point.
--
-- @function [parent=#RigidBody] GetVelocityAtPoint
-- @param self Self reference
-- @param Vector3#Vector3 position position
-- @return Vector3#Vector3

---
-- Function GetLinearRestThreshold()
-- Return linear velocity deactivation threshold.
--
-- @function [parent=#RigidBody] GetLinearRestThreshold
-- @param self Self reference
-- @return #number

---
-- Function GetLinearDamping()
-- Return linear velocity damping factor.
--
-- @function [parent=#RigidBody] GetLinearDamping
-- @param self Self reference
-- @return #number

---
-- Function GetAngularVelocity()
-- Return angular velocity.
--
-- @function [parent=#RigidBody] GetAngularVelocity
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetAngularFactor()
-- Return angular degrees of freedom.
--
-- @function [parent=#RigidBody] GetAngularFactor
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetAngularRestThreshold()
-- Return angular velocity deactivation threshold.
--
-- @function [parent=#RigidBody] GetAngularRestThreshold
-- @param self Self reference
-- @return #number

---
-- Function GetAngularDamping()
-- Return angular velocity damping factor.
--
-- @function [parent=#RigidBody] GetAngularDamping
-- @param self Self reference
-- @return #number

---
-- Function GetFriction()
-- Return friction coefficient.
--
-- @function [parent=#RigidBody] GetFriction
-- @param self Self reference
-- @return #number

---
-- Function GetAnisotropicFriction()
-- Return anisotropic friction.
--
-- @function [parent=#RigidBody] GetAnisotropicFriction
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetRollingFriction()
-- Return rolling friction coefficient.
--
-- @function [parent=#RigidBody] GetRollingFriction
-- @param self Self reference
-- @return #number

---
-- Function GetRestitution()
-- Return restitution coefficient.
--
-- @function [parent=#RigidBody] GetRestitution
-- @param self Self reference
-- @return #number

---
-- Function GetContactProcessingThreshold()
-- Return contact processing threshold.
--
-- @function [parent=#RigidBody] GetContactProcessingThreshold
-- @param self Self reference
-- @return #number

---
-- Function GetCcdRadius()
-- Return continuous collision detection swept sphere radius.
--
-- @function [parent=#RigidBody] GetCcdRadius
-- @param self Self reference
-- @return #number

---
-- Function GetCcdMotionThreshold()
-- Return continuous collision detection motion-per-simulation-step threshold.
--
-- @function [parent=#RigidBody] GetCcdMotionThreshold
-- @param self Self reference
-- @return #number

---
-- Function GetUseGravity()
-- Return whether rigid body uses gravity.
--
-- @function [parent=#RigidBody] GetUseGravity
-- @param self Self reference
-- @return #boolean

---
-- Function GetGravityOverride()
-- Return gravity override. If zero (default), uses the physics world's gravity.
--
-- @function [parent=#RigidBody] GetGravityOverride
-- @param self Self reference
-- @return const Vector3#const Vector3

---
-- Function GetCenterOfMass()
-- Return center of mass offset.
--
-- @function [parent=#RigidBody] GetCenterOfMass
-- @param self Self reference
-- @return const Vector3#const Vector3

---
-- Function IsKinematic()
-- Return kinematic mode flag.
--
-- @function [parent=#RigidBody] IsKinematic
-- @param self Self reference
-- @return #boolean

---
-- Function IsTrigger()
-- Return whether this RigidBody is acting as a trigger.
--
-- @function [parent=#RigidBody] IsTrigger
-- @param self Self reference
-- @return #boolean

---
-- Function IsActive()
-- Return whether rigid body is active (not sleeping.)
--
-- @function [parent=#RigidBody] IsActive
-- @param self Self reference
-- @return #boolean

---
-- Function GetCollisionLayer()
-- Return collision layer.
--
-- @function [parent=#RigidBody] GetCollisionLayer
-- @param self Self reference
-- @return #number

---
-- Function GetCollisionMask()
-- Return collision mask.
--
-- @function [parent=#RigidBody] GetCollisionMask
-- @param self Self reference
-- @return #number

---
-- Function GetCollisionEventMode()
-- Return collision event signaling mode.
--
-- @function [parent=#RigidBody] GetCollisionEventMode
-- @param self Self reference
-- @return CollisionEventMode#CollisionEventMode

---
-- Field physicsWorld (Read only)
--
-- @field [parent=#RigidBody] PhysicsWorld#PhysicsWorld physicsWorld

---
-- Field mass
--
-- @field [parent=#RigidBody] #number mass

---
-- Field position
--
-- @field [parent=#RigidBody] Vector3#Vector3 position

---
-- Field rotation
--
-- @field [parent=#RigidBody] Quaternion#Quaternion rotation

---
-- Field linearVelocity
--
-- @field [parent=#RigidBody] Vector3#Vector3 linearVelocity

---
-- Field linearFactor
--
-- @field [parent=#RigidBody] Vector3#Vector3 linearFactor

---
-- Field linearRestThreshold
--
-- @field [parent=#RigidBody] #number linearRestThreshold

---
-- Field linearDamping
--
-- @field [parent=#RigidBody] #number linearDamping

---
-- Field angularVelocity
--
-- @field [parent=#RigidBody] Vector3#Vector3 angularVelocity

---
-- Field angularFactor
--
-- @field [parent=#RigidBody] Vector3#Vector3 angularFactor

---
-- Field angularRestThreshold
--
-- @field [parent=#RigidBody] #number angularRestThreshold

---
-- Field angularDamping
--
-- @field [parent=#RigidBody] #number angularDamping

---
-- Field friction
--
-- @field [parent=#RigidBody] #number friction

---
-- Field anisotropicFriction
--
-- @field [parent=#RigidBody] Vector3#Vector3 anisotropicFriction

---
-- Field rollingFriction
--
-- @field [parent=#RigidBody] #number rollingFriction

---
-- Field restitution
--
-- @field [parent=#RigidBody] #number restitution

---
-- Field contactProcessingThreshold
--
-- @field [parent=#RigidBody] #number contactProcessingThreshold

---
-- Field ccdRadius
--
-- @field [parent=#RigidBody] #number ccdRadius

---
-- Field ccdMotionThreshold
--
-- @field [parent=#RigidBody] #number ccdMotionThreshold

---
-- Field useGravity
--
-- @field [parent=#RigidBody] #boolean useGravity

---
-- Field gravityOverride
--
-- @field [parent=#RigidBody] Vector3#Vector3 gravityOverride

---
-- Field centerOfMass (Read only)
--
-- @field [parent=#RigidBody] Vector3#Vector3 centerOfMass

---
-- Field kinematic
--
-- @field [parent=#RigidBody] #boolean kinematic

---
-- Field trigger
--
-- @field [parent=#RigidBody] #boolean trigger

---
-- Field active (Read only)
--
-- @field [parent=#RigidBody] #boolean active

---
-- Field collisionLayer
--
-- @field [parent=#RigidBody] #number collisionLayer

---
-- Field collisionMask
--
-- @field [parent=#RigidBody] #number collisionMask

---
-- Field collisionEventMode
--
-- @field [parent=#RigidBody] CollisionEventMode#CollisionEventMode collisionEventMode


return nil
