---
-- Module RigidBody
-- Module RigidBody extends Component
-- Generated on 2014-03-13
--
-- @module RigidBody

---
-- Function SetMass
--
-- @function [parent=#RigidBody] SetMass
-- @param self Self reference
-- @param #number mass mass

---
-- Function SetPosition
--
-- @function [parent=#RigidBody] SetPosition
-- @param self Self reference
-- @param Vector3#Vector3 position position

---
-- Function SetRotation
--
-- @function [parent=#RigidBody] SetRotation
-- @param self Self reference
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetTransform
--
-- @function [parent=#RigidBody] SetTransform
-- @param self Self reference
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetLinearVelocity
--
-- @function [parent=#RigidBody] SetLinearVelocity
-- @param self Self reference
-- @param Vector3#Vector3 velocity velocity

---
-- Function SetLinearFactor
--
-- @function [parent=#RigidBody] SetLinearFactor
-- @param self Self reference
-- @param Vector3#Vector3 factor factor

---
-- Function SetLinearRestThreshold
--
-- @function [parent=#RigidBody] SetLinearRestThreshold
-- @param self Self reference
-- @param #number threshold threshold

---
-- Function SetLinearDamping
--
-- @function [parent=#RigidBody] SetLinearDamping
-- @param self Self reference
-- @param #number damping damping

---
-- Function SetAngularVelocity
--
-- @function [parent=#RigidBody] SetAngularVelocity
-- @param self Self reference
-- @param Vector3#Vector3 angularVelocity angularVelocity

---
-- Function SetAngularFactor
--
-- @function [parent=#RigidBody] SetAngularFactor
-- @param self Self reference
-- @param Vector3#Vector3 factor factor

---
-- Function SetAngularRestThreshold
--
-- @function [parent=#RigidBody] SetAngularRestThreshold
-- @param self Self reference
-- @param #number threshold threshold

---
-- Function SetAngularDamping
--
-- @function [parent=#RigidBody] SetAngularDamping
-- @param self Self reference
-- @param #number factor factor

---
-- Function SetFriction
--
-- @function [parent=#RigidBody] SetFriction
-- @param self Self reference
-- @param #number friction friction

---
-- Function SetAnisotropicFriction
--
-- @function [parent=#RigidBody] SetAnisotropicFriction
-- @param self Self reference
-- @param Vector3#Vector3 friction friction

---
-- Function SetRollingFriction
--
-- @function [parent=#RigidBody] SetRollingFriction
-- @param self Self reference
-- @param #number friction friction

---
-- Function SetRestitution
--
-- @function [parent=#RigidBody] SetRestitution
-- @param self Self reference
-- @param #number restitution restitution

---
-- Function SetContactProcessingThreshold
--
-- @function [parent=#RigidBody] SetContactProcessingThreshold
-- @param self Self reference
-- @param #number threshold threshold

---
-- Function SetCcdRadius
--
-- @function [parent=#RigidBody] SetCcdRadius
-- @param self Self reference
-- @param #number radius radius

---
-- Function SetCcdMotionThreshold
--
-- @function [parent=#RigidBody] SetCcdMotionThreshold
-- @param self Self reference
-- @param #number threshold threshold

---
-- Function SetUseGravity
--
-- @function [parent=#RigidBody] SetUseGravity
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetGravityOverride
--
-- @function [parent=#RigidBody] SetGravityOverride
-- @param self Self reference
-- @param Vector3#Vector3 gravity gravity

---
-- Function SetKinematic
--
-- @function [parent=#RigidBody] SetKinematic
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetPhantom
--
-- @function [parent=#RigidBody] SetPhantom
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetCollisionLayer
--
-- @function [parent=#RigidBody] SetCollisionLayer
-- @param self Self reference
-- @param #number layer layer

---
-- Function SetCollisionMask
--
-- @function [parent=#RigidBody] SetCollisionMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetCollisionLayerAndMask
--
-- @function [parent=#RigidBody] SetCollisionLayerAndMask
-- @param self Self reference
-- @param #number layer layer
-- @param #number mask mask

---
-- Function SetCollisionEventMode
--
-- @function [parent=#RigidBody] SetCollisionEventMode
-- @param self Self reference
-- @param CollisionEventMode#CollisionEventMode mode mode

---
-- Function ApplyForce
--
-- @function [parent=#RigidBody] ApplyForce
-- @param self Self reference
-- @param Vector3#Vector3 force force

---
-- Function ApplyForce
--
-- @function [parent=#RigidBody] ApplyForce
-- @param self Self reference
-- @param Vector3#Vector3 force force
-- @param Vector3#Vector3 position position

---
-- Function ApplyTorque
--
-- @function [parent=#RigidBody] ApplyTorque
-- @param self Self reference
-- @param Vector3#Vector3 torque torque

---
-- Function ApplyImpulse
--
-- @function [parent=#RigidBody] ApplyImpulse
-- @param self Self reference
-- @param Vector3#Vector3 impulse impulse

---
-- Function ApplyImpulse
--
-- @function [parent=#RigidBody] ApplyImpulse
-- @param self Self reference
-- @param Vector3#Vector3 impulse impulse
-- @param Vector3#Vector3 position position

---
-- Function ApplyTorqueImpulse
--
-- @function [parent=#RigidBody] ApplyTorqueImpulse
-- @param self Self reference
-- @param Vector3#Vector3 torque torque

---
-- Function ResetForces
--
-- @function [parent=#RigidBody] ResetForces
-- @param self Self reference

---
-- Function Activate
--
-- @function [parent=#RigidBody] Activate
-- @param self Self reference

---
-- Function ReAddBodyToWorld
--
-- @function [parent=#RigidBody] ReAddBodyToWorld
-- @param self Self reference

---
-- Function GetPhysicsWorld
--
-- @function [parent=#RigidBody] GetPhysicsWorld
-- @param self Self reference
-- @return PhysicsWorld#PhysicsWorld

---
-- Function GetMass
--
-- @function [parent=#RigidBody] GetMass
-- @param self Self reference
-- @return #number

---
-- Function GetPosition
--
-- @function [parent=#RigidBody] GetPosition
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetRotation
--
-- @function [parent=#RigidBody] GetRotation
-- @param self Self reference
-- @return Quaternion#Quaternion

---
-- Function GetLinearVelocity
--
-- @function [parent=#RigidBody] GetLinearVelocity
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetLinearFactor
--
-- @function [parent=#RigidBody] GetLinearFactor
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetVelocityAtPoint
--
-- @function [parent=#RigidBody] GetVelocityAtPoint
-- @param self Self reference
-- @param Vector3#Vector3 position position
-- @return Vector3#Vector3

---
-- Function GetLinearRestThreshold
--
-- @function [parent=#RigidBody] GetLinearRestThreshold
-- @param self Self reference
-- @return #number

---
-- Function GetLinearDamping
--
-- @function [parent=#RigidBody] GetLinearDamping
-- @param self Self reference
-- @return #number

---
-- Function GetAngularVelocity
--
-- @function [parent=#RigidBody] GetAngularVelocity
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetAngularFactor
--
-- @function [parent=#RigidBody] GetAngularFactor
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetAngularRestThreshold
--
-- @function [parent=#RigidBody] GetAngularRestThreshold
-- @param self Self reference
-- @return #number

---
-- Function GetAngularDamping
--
-- @function [parent=#RigidBody] GetAngularDamping
-- @param self Self reference
-- @return #number

---
-- Function GetFriction
--
-- @function [parent=#RigidBody] GetFriction
-- @param self Self reference
-- @return #number

---
-- Function GetAnisotropicFriction
--
-- @function [parent=#RigidBody] GetAnisotropicFriction
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetRollingFriction
--
-- @function [parent=#RigidBody] GetRollingFriction
-- @param self Self reference
-- @return #number

---
-- Function GetRestitution
--
-- @function [parent=#RigidBody] GetRestitution
-- @param self Self reference
-- @return #number

---
-- Function GetContactProcessingThreshold
--
-- @function [parent=#RigidBody] GetContactProcessingThreshold
-- @param self Self reference
-- @return #number

---
-- Function GetCcdRadius
--
-- @function [parent=#RigidBody] GetCcdRadius
-- @param self Self reference
-- @return #number

---
-- Function GetCcdMotionThreshold
--
-- @function [parent=#RigidBody] GetCcdMotionThreshold
-- @param self Self reference
-- @return #number

---
-- Function GetUseGravity
--
-- @function [parent=#RigidBody] GetUseGravity
-- @param self Self reference
-- @return #boolean

---
-- Function GetGravityOverride
--
-- @function [parent=#RigidBody] GetGravityOverride
-- @param self Self reference
-- @return const Vector3#const Vector3

---
-- Function GetCenterOfMass
--
-- @function [parent=#RigidBody] GetCenterOfMass
-- @param self Self reference
-- @return const Vector3#const Vector3

---
-- Function IsKinematic
--
-- @function [parent=#RigidBody] IsKinematic
-- @param self Self reference
-- @return #boolean

---
-- Function IsPhantom
--
-- @function [parent=#RigidBody] IsPhantom
-- @param self Self reference
-- @return #boolean

---
-- Function IsActive
--
-- @function [parent=#RigidBody] IsActive
-- @param self Self reference
-- @return #boolean

---
-- Function GetCollisionLayer
--
-- @function [parent=#RigidBody] GetCollisionLayer
-- @param self Self reference
-- @return #number

---
-- Function GetCollisionMask
--
-- @function [parent=#RigidBody] GetCollisionMask
-- @param self Self reference
-- @return #number

---
-- Function GetCollisionEventMode
--
-- @function [parent=#RigidBody] GetCollisionEventMode
-- @param self Self reference
-- @return CollisionEventMode#CollisionEventMode

---
-- Field physicsWorld (Read only)
--
-- @field [parent=#RigidBody] PhysicsWorld#PhysicsWorld physicsWorld

---
-- Field mass
--
-- @field [parent=#RigidBody] #number mass

---
-- Field position
--
-- @field [parent=#RigidBody] Vector3#Vector3 position

---
-- Field rotation
--
-- @field [parent=#RigidBody] Quaternion#Quaternion rotation

---
-- Field linearVelocity
--
-- @field [parent=#RigidBody] Vector3#Vector3 linearVelocity

---
-- Field linearFactor
--
-- @field [parent=#RigidBody] Vector3#Vector3 linearFactor

---
-- Field linearRestThreshold
--
-- @field [parent=#RigidBody] #number linearRestThreshold

---
-- Field linearDamping
--
-- @field [parent=#RigidBody] #number linearDamping

---
-- Field angularVelocity
--
-- @field [parent=#RigidBody] Vector3#Vector3 angularVelocity

---
-- Field angularFactor
--
-- @field [parent=#RigidBody] Vector3#Vector3 angularFactor

---
-- Field angularRestThreshold
--
-- @field [parent=#RigidBody] #number angularRestThreshold

---
-- Field angularDamping
--
-- @field [parent=#RigidBody] #number angularDamping

---
-- Field friction
--
-- @field [parent=#RigidBody] #number friction

---
-- Field anisotropicFriction
--
-- @field [parent=#RigidBody] Vector3#Vector3 anisotropicFriction

---
-- Field rollingFriction
--
-- @field [parent=#RigidBody] #number rollingFriction

---
-- Field restitution
--
-- @field [parent=#RigidBody] #number restitution

---
-- Field contactProcessingThreshold
--
-- @field [parent=#RigidBody] #number contactProcessingThreshold

---
-- Field ccdRadius
--
-- @field [parent=#RigidBody] #number ccdRadius

---
-- Field ccdMotionThreshold
--
-- @field [parent=#RigidBody] #number ccdMotionThreshold

---
-- Field useGravity
--
-- @field [parent=#RigidBody] #boolean useGravity

---
-- Field gravityOverride
--
-- @field [parent=#RigidBody] Vector3#Vector3 gravityOverride

---
-- Field centerOfMass (Read only)
--
-- @field [parent=#RigidBody] Vector3#Vector3 centerOfMass

---
-- Field kinematic
--
-- @field [parent=#RigidBody] #boolean kinematic

---
-- Field phantom
--
-- @field [parent=#RigidBody] #boolean phantom

---
-- Field active (Read only)
--
-- @field [parent=#RigidBody] #boolean active

---
-- Field collisionLayer
--
-- @field [parent=#RigidBody] #number collisionLayer

---
-- Field collisionMask
--
-- @field [parent=#RigidBody] #number collisionMask

---
-- Field collisionEventMode
--
-- @field [parent=#RigidBody] CollisionEventMode#CollisionEventMode collisionEventMode

---
-- Function SetEnabled
--
-- @function [parent=#RigidBody] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Remove
--
-- @function [parent=#RigidBody] Remove
-- @param self Self reference

---
-- Function GetID
--
-- @function [parent=#RigidBody] GetID
-- @param self Self reference
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#RigidBody] GetNode
-- @param self Self reference
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#RigidBody] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#RigidBody] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#RigidBody] IsEnabledEffective
-- @param self Self reference
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#RigidBody] GetComponent
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#RigidBody] GetComponent
-- @param self Self reference
-- @param #string type type
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#RigidBody] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#RigidBody] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#RigidBody] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#RigidBody] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#RigidBody] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#RigidBody] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#RigidBody] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#RigidBody] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#RigidBody] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#RigidBody] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#RigidBody] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#RigidBody] #string category


return nil
