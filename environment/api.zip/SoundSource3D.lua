---
-- Module SoundSource3D
-- Module SoundSource3D extends SoundSource
-- Generated on 2014-03-13
--
-- @module SoundSource3D

---
-- Function SetDistanceAttenuation
--
-- @function [parent=#SoundSource3D] SetDistanceAttenuation
-- @param self Self reference
-- @param #number nearDistance nearDistance
-- @param #number farDistance farDistance
-- @param #number rolloffFactor rolloffFactor

---
-- Function SetAngleAttenuation
--
-- @function [parent=#SoundSource3D] SetAngleAttenuation
-- @param self Self reference
-- @param #number innerAngle innerAngle
-- @param #number outerAngle outerAngle

---
-- Function SetNearDistance
--
-- @function [parent=#SoundSource3D] SetNearDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetFarDistance
--
-- @function [parent=#SoundSource3D] SetFarDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetInnerAngle
--
-- @function [parent=#SoundSource3D] SetInnerAngle
-- @param self Self reference
-- @param #number angle angle

---
-- Function SetOuterAngle
--
-- @function [parent=#SoundSource3D] SetOuterAngle
-- @param self Self reference
-- @param #number angle angle

---
-- Function SetRolloffFactor
--
-- @function [parent=#SoundSource3D] SetRolloffFactor
-- @param self Self reference
-- @param #number factor factor

---
-- Function CalculateAttenuation
--
-- @function [parent=#SoundSource3D] CalculateAttenuation
-- @param self Self reference

---
-- Function GetNearDistance
--
-- @function [parent=#SoundSource3D] GetNearDistance
-- @param self Self reference
-- @return #number

---
-- Function GetFarDistance
--
-- @function [parent=#SoundSource3D] GetFarDistance
-- @param self Self reference
-- @return #number

---
-- Function GetInnerAngle
--
-- @function [parent=#SoundSource3D] GetInnerAngle
-- @param self Self reference
-- @return #number

---
-- Function GetOuterAngle
--
-- @function [parent=#SoundSource3D] GetOuterAngle
-- @param self Self reference
-- @return #number

---
-- Function RollAngleoffFactor
--
-- @function [parent=#SoundSource3D] RollAngleoffFactor
-- @param self Self reference
-- @return #number

---
-- Field nearDistance
--
-- @field [parent=#SoundSource3D] #number nearDistance

---
-- Field farDistance
--
-- @field [parent=#SoundSource3D] #number farDistance

---
-- Field innerAngle
--
-- @field [parent=#SoundSource3D] #number innerAngle

---
-- Field outerAngle
--
-- @field [parent=#SoundSource3D] #number outerAngle

---
-- Field rolloffFactor
--
-- @field [parent=#SoundSource3D] #number rolloffFactor

---
-- Function Play
--
-- @function [parent=#SoundSource3D] Play
-- @param self Self reference
-- @param Sound#Sound sound sound

---
-- Function Play
--
-- @function [parent=#SoundSource3D] Play
-- @param self Self reference
-- @param Sound#Sound sound sound
-- @param #number frequency frequency

---
-- Function Play
--
-- @function [parent=#SoundSource3D] Play
-- @param self Self reference
-- @param Sound#Sound sound sound
-- @param #number frequency frequency
-- @param #number gain gain

---
-- Function Play
--
-- @function [parent=#SoundSource3D] Play
-- @param self Self reference
-- @param Sound#Sound sound sound
-- @param #number frequency frequency
-- @param #number gain gain
-- @param #number panning panning

---
-- Function Stop
--
-- @function [parent=#SoundSource3D] Stop
-- @param self Self reference

---
-- Function SetSoundType
--
-- @function [parent=#SoundSource3D] SetSoundType
-- @param self Self reference
-- @param SoundType#SoundType type type

---
-- Function SetFrequency
--
-- @function [parent=#SoundSource3D] SetFrequency
-- @param self Self reference
-- @param #number frequency frequency

---
-- Function SetGain
--
-- @function [parent=#SoundSource3D] SetGain
-- @param self Self reference
-- @param #number gain gain

---
-- Function SetAttenuation
--
-- @function [parent=#SoundSource3D] SetAttenuation
-- @param self Self reference
-- @param #number attenuation attenuation

---
-- Function SetPanning
--
-- @function [parent=#SoundSource3D] SetPanning
-- @param self Self reference
-- @param #number panning panning

---
-- Function SetAutoRemove
--
-- @function [parent=#SoundSource3D] SetAutoRemove
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function GetSound
--
-- @function [parent=#SoundSource3D] GetSound
-- @param self Self reference
-- @return Sound#Sound

---
-- Function GetSoundType
--
-- @function [parent=#SoundSource3D] GetSoundType
-- @param self Self reference
-- @return SoundType#SoundType

---
-- Function GetTimePosition
--
-- @function [parent=#SoundSource3D] GetTimePosition
-- @param self Self reference
-- @return #number

---
-- Function GetFrequency
--
-- @function [parent=#SoundSource3D] GetFrequency
-- @param self Self reference
-- @return #number

---
-- Function GetGain
--
-- @function [parent=#SoundSource3D] GetGain
-- @param self Self reference
-- @return #number

---
-- Function GetAttenuation
--
-- @function [parent=#SoundSource3D] GetAttenuation
-- @param self Self reference
-- @return #number

---
-- Function GetPanning
--
-- @function [parent=#SoundSource3D] GetPanning
-- @param self Self reference
-- @return #number

---
-- Function GetAutoRemove
--
-- @function [parent=#SoundSource3D] GetAutoRemove
-- @param self Self reference
-- @return #boolean

---
-- Function IsPlaying
--
-- @function [parent=#SoundSource3D] IsPlaying
-- @param self Self reference
-- @return #boolean

---
-- Function PlayLockless
--
-- @function [parent=#SoundSource3D] PlayLockless
-- @param self Self reference
-- @param Sound#Sound sound sound

---
-- Function StopLockless
--
-- @function [parent=#SoundSource3D] StopLockless
-- @param self Self reference

---
-- Field sound (Read only)
--
-- @field [parent=#SoundSource3D] Sound#Sound sound

---
-- Field soundType
--
-- @field [parent=#SoundSource3D] SoundType#SoundType soundType

---
-- Field timePosition (Read only)
--
-- @field [parent=#SoundSource3D] #number timePosition

---
-- Field frequency
--
-- @field [parent=#SoundSource3D] #number frequency

---
-- Field gain
--
-- @field [parent=#SoundSource3D] #number gain

---
-- Field attenuation
--
-- @field [parent=#SoundSource3D] #number attenuation

---
-- Field panning
--
-- @field [parent=#SoundSource3D] #number panning

---
-- Field autoRemove
--
-- @field [parent=#SoundSource3D] #boolean autoRemove

---
-- Field playing (Read only)
--
-- @field [parent=#SoundSource3D] #boolean playing

---
-- Function SetEnabled
--
-- @function [parent=#SoundSource3D] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Remove
--
-- @function [parent=#SoundSource3D] Remove
-- @param self Self reference

---
-- Function GetID
--
-- @function [parent=#SoundSource3D] GetID
-- @param self Self reference
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#SoundSource3D] GetNode
-- @param self Self reference
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#SoundSource3D] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#SoundSource3D] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#SoundSource3D] IsEnabledEffective
-- @param self Self reference
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#SoundSource3D] GetComponent
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#SoundSource3D] GetComponent
-- @param self Self reference
-- @param #string type type
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#SoundSource3D] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#SoundSource3D] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#SoundSource3D] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#SoundSource3D] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#SoundSource3D] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#SoundSource3D] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#SoundSource3D] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#SoundSource3D] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#SoundSource3D] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#SoundSource3D] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#SoundSource3D] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#SoundSource3D] #string category


return nil
