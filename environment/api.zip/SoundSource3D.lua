---
-- Module SoundSource3D
-- Extends SoundSource
--
-- @module SoundSource3D

---
-- Function SetDistanceAttenuation
--
-- @function [parent=#SoundSource3D] SetDistanceAttenuation
-- @param #number nearDistancenearDistance
-- @param #number farDistancefarDistance
-- @param #number rolloffFactorrolloffFactor

---
-- Function SetAngleAttenuation
--
-- @function [parent=#SoundSource3D] SetAngleAttenuation
-- @param #number innerAngleinnerAngle
-- @param #number outerAngleouterAngle

---
-- Function SetNearDistance
--
-- @function [parent=#SoundSource3D] SetNearDistance
-- @param #number distancedistance

---
-- Function SetFarDistance
--
-- @function [parent=#SoundSource3D] SetFarDistance
-- @param #number distancedistance

---
-- Function SetInnerAngle
--
-- @function [parent=#SoundSource3D] SetInnerAngle
-- @param #number angleangle

---
-- Function SetOuterAngle
--
-- @function [parent=#SoundSource3D] SetOuterAngle
-- @param #number angleangle

---
-- Function SetRolloffFactor
--
-- @function [parent=#SoundSource3D] SetRolloffFactor
-- @param #number factorfactor

---
-- Function CalculateAttenuation
--
-- @function [parent=#SoundSource3D] CalculateAttenuation

---
-- Function GetNearDistance
--
-- @function [parent=#SoundSource3D] GetNearDistance
-- @return #number

---
-- Function GetFarDistance
--
-- @function [parent=#SoundSource3D] GetFarDistance
-- @return #number

---
-- Function GetInnerAngle
--
-- @function [parent=#SoundSource3D] GetInnerAngle
-- @return #number

---
-- Function GetOuterAngle
--
-- @function [parent=#SoundSource3D] GetOuterAngle
-- @return #number

---
-- Function RollAngleoffFactor
--
-- @function [parent=#SoundSource3D] RollAngleoffFactor
-- @return #number

---
-- Field nearDistance
--
-- @field [parent=#SoundSource3D] #number nearDistance

---
-- Field farDistance
--
-- @field [parent=#SoundSource3D] #number farDistance

---
-- Field innerAngle
--
-- @field [parent=#SoundSource3D] #number innerAngle

---
-- Field outerAngle
--
-- @field [parent=#SoundSource3D] #number outerAngle

---
-- Field rolloffFactor
--
-- @field [parent=#SoundSource3D] #number rolloffFactor


return nil
