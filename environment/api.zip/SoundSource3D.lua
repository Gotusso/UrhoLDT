---
-- Module SoundSource3D
-- extends SoundSource
--
-- @module SoundSource3D

---
-- Function SetDistanceAttenuation
--
-- @function [parent=#SoundSource3D] SetDistanceAttenuation
-- @param #number nearDistancenearDistance
-- @param #number farDistancefarDistance
-- @param #number rolloffFactorrolloffFactor

---
-- Function SetAngleAttenuation
--
-- @function [parent=#SoundSource3D] SetAngleAttenuation
-- @param #number innerAngleinnerAngle
-- @param #number outerAngleouterAngle

---
-- Function SetNearDistance
--
-- @function [parent=#SoundSource3D] SetNearDistance
-- @param #number distancedistance

---
-- Function SetFarDistance
--
-- @function [parent=#SoundSource3D] SetFarDistance
-- @param #number distancedistance

---
-- Function SetInnerAngle
--
-- @function [parent=#SoundSource3D] SetInnerAngle
-- @param #number angleangle

---
-- Function SetOuterAngle
--
-- @function [parent=#SoundSource3D] SetOuterAngle
-- @param #number angleangle

---
-- Function SetRolloffFactor
--
-- @function [parent=#SoundSource3D] SetRolloffFactor
-- @param #number factorfactor

---
-- Function CalculateAttenuation
--
-- @function [parent=#SoundSource3D] CalculateAttenuation

---
-- Function GetNearDistance
--
-- @function [parent=#SoundSource3D] GetNearDistance
-- @return #number

---
-- Function GetFarDistance
--
-- @function [parent=#SoundSource3D] GetFarDistance
-- @return #number

---
-- Function GetInnerAngle
--
-- @function [parent=#SoundSource3D] GetInnerAngle
-- @return #number

---
-- Function GetOuterAngle
--
-- @function [parent=#SoundSource3D] GetOuterAngle
-- @return #number

---
-- Function RollAngleoffFactor
--
-- @function [parent=#SoundSource3D] RollAngleoffFactor
-- @return #number

---
-- Field nearDistance
--
-- @field [parent=#SoundSource3D] #number nearDistance

---
-- Field farDistance
--
-- @field [parent=#SoundSource3D] #number farDistance

---
-- Field innerAngle
--
-- @field [parent=#SoundSource3D] #number innerAngle

---
-- Field outerAngle
--
-- @field [parent=#SoundSource3D] #number outerAngle

---
-- Field rolloffFactor
--
-- @field [parent=#SoundSource3D] #number rolloffFactor

---
-- Function Play
--
-- @function [parent=#SoundSource3D] Play
-- @param Sound#Sound soundsound

---
-- Function Play
--
-- @function [parent=#SoundSource3D] Play
-- @param Sound#Sound soundsound
-- @param #number frequencyfrequency

---
-- Function Play
--
-- @function [parent=#SoundSource3D] Play
-- @param Sound#Sound soundsound
-- @param #number frequencyfrequency
-- @param #number gaingain

---
-- Function Play
--
-- @function [parent=#SoundSource3D] Play
-- @param Sound#Sound soundsound
-- @param #number frequencyfrequency
-- @param #number gaingain
-- @param #number panningpanning

---
-- Function Stop
--
-- @function [parent=#SoundSource3D] Stop

---
-- Function SetSoundType
--
-- @function [parent=#SoundSource3D] SetSoundType
-- @param SoundType#SoundType typetype

---
-- Function SetFrequency
--
-- @function [parent=#SoundSource3D] SetFrequency
-- @param #number frequencyfrequency

---
-- Function SetGain
--
-- @function [parent=#SoundSource3D] SetGain
-- @param #number gaingain

---
-- Function SetAttenuation
--
-- @function [parent=#SoundSource3D] SetAttenuation
-- @param #number attenuationattenuation

---
-- Function SetPanning
--
-- @function [parent=#SoundSource3D] SetPanning
-- @param #number panningpanning

---
-- Function SetAutoRemove
--
-- @function [parent=#SoundSource3D] SetAutoRemove
-- @param #boolean enableenable

---
-- Function GetSound
--
-- @function [parent=#SoundSource3D] GetSound
-- @return Sound#Sound

---
-- Function GetSoundType
--
-- @function [parent=#SoundSource3D] GetSoundType
-- @return SoundType#SoundType

---
-- Function GetTimePosition
--
-- @function [parent=#SoundSource3D] GetTimePosition
-- @return #number

---
-- Function GetFrequency
--
-- @function [parent=#SoundSource3D] GetFrequency
-- @return #number

---
-- Function GetGain
--
-- @function [parent=#SoundSource3D] GetGain
-- @return #number

---
-- Function GetAttenuation
--
-- @function [parent=#SoundSource3D] GetAttenuation
-- @return #number

---
-- Function GetPanning
--
-- @function [parent=#SoundSource3D] GetPanning
-- @return #number

---
-- Function GetAutoRemove
--
-- @function [parent=#SoundSource3D] GetAutoRemove
-- @return #boolean

---
-- Function IsPlaying
--
-- @function [parent=#SoundSource3D] IsPlaying
-- @return #boolean

---
-- Function PlayLockless
--
-- @function [parent=#SoundSource3D] PlayLockless
-- @param Sound#Sound soundsound

---
-- Function StopLockless
--
-- @function [parent=#SoundSource3D] StopLockless

---
-- Field sound (Read only)
--
-- @field [parent=#SoundSource3D] Sound#Sound sound

---
-- Field soundType
--
-- @field [parent=#SoundSource3D] SoundType#SoundType soundType

---
-- Field timePosition (Read only)
--
-- @field [parent=#SoundSource3D] #number timePosition

---
-- Field frequency
--
-- @field [parent=#SoundSource3D] #number frequency

---
-- Field gain
--
-- @field [parent=#SoundSource3D] #number gain

---
-- Field attenuation
--
-- @field [parent=#SoundSource3D] #number attenuation

---
-- Field panning
--
-- @field [parent=#SoundSource3D] #number panning

---
-- Field autoRemove
--
-- @field [parent=#SoundSource3D] #boolean autoRemove

---
-- Field playing (Read only)
--
-- @field [parent=#SoundSource3D] #boolean playing

---
-- Function SetEnabled
--
-- @function [parent=#SoundSource3D] SetEnabled
-- @param #boolean enableenable

---
-- Function Remove
--
-- @function [parent=#SoundSource3D] Remove

---
-- Function GetID
--
-- @function [parent=#SoundSource3D] GetID
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#SoundSource3D] GetNode
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#SoundSource3D] GetScene
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#SoundSource3D] IsEnabled
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#SoundSource3D] IsEnabledEffective
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#SoundSource3D] GetComponent
-- @param ShortStringHash#ShortStringHash typetype
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#SoundSource3D] GetComponent
-- @param #string typetype
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#SoundSource3D] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#SoundSource3D] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#SoundSource3D] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#SoundSource3D] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#SoundSource3D] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#SoundSource3D] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#SoundSource3D] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#SoundSource3D] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#SoundSource3D] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#SoundSource3D] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#SoundSource3D] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#SoundSource3D] #string category


return nil
