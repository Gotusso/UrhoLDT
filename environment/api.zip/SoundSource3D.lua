---
-- Module SoundSource3D
-- Module SoundSource3D extends SoundSource
-- Generated on 2014-05-31
--
-- @module SoundSource3D

---
-- Function SetDistanceAttenuation()
-- Set attenuation parameters.
--
-- @function [parent=#SoundSource3D] SetDistanceAttenuation
-- @param self Self reference
-- @param #number nearDistance nearDistance
-- @param #number farDistance farDistance
-- @param #number rolloffFactor rolloffFactor

---
-- Function SetAngleAttenuation()
-- Set angle attenuation parameters.
--
-- @function [parent=#SoundSource3D] SetAngleAttenuation
-- @param self Self reference
-- @param #number innerAngle innerAngle
-- @param #number outerAngle outerAngle

---
-- Function SetNearDistance()
-- Set near distance. Inside this range sound will not be attenuated.
--
-- @function [parent=#SoundSource3D] SetNearDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetFarDistance()
-- Set far distance. Outside this range sound will be completely attenuated.
--
-- @function [parent=#SoundSource3D] SetFarDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetInnerAngle()
-- Set inner angle in degrees. Inside this angle sound will not be attenuated.By default 360, meaning direction never has an effect.
--
-- @function [parent=#SoundSource3D] SetInnerAngle
-- @param self Self reference
-- @param #number angle angle

---
-- Function SetOuterAngle()
-- Set outer angle in degrees. Outside this angle sound will be completely attenuated. By default 360, meaning direction never has an effect.
--
-- @function [parent=#SoundSource3D] SetOuterAngle
-- @param self Self reference
-- @param #number angle angle

---
-- Function SetRolloffFactor()
-- Set rolloff power factor, defines attenuation function shape.
--
-- @function [parent=#SoundSource3D] SetRolloffFactor
-- @param self Self reference
-- @param #number factor factor

---
-- Function CalculateAttenuation()
-- Calculate attenuation and panning based on current position and listener position.
--
-- @function [parent=#SoundSource3D] CalculateAttenuation
-- @param self Self reference

---
-- Function GetNearDistance()
-- Return near distance.
--
-- @function [parent=#SoundSource3D] GetNearDistance
-- @param self Self reference
-- @return #number

---
-- Function GetFarDistance()
-- Return far distance.
--
-- @function [parent=#SoundSource3D] GetFarDistance
-- @param self Self reference
-- @return #number

---
-- Function GetInnerAngle()
-- Return inner angle in degrees.
--
-- @function [parent=#SoundSource3D] GetInnerAngle
-- @param self Self reference
-- @return #number

---
-- Function GetOuterAngle()
-- Return outer angle in degrees.
--
-- @function [parent=#SoundSource3D] GetOuterAngle
-- @param self Self reference
-- @return #number

---
-- Function RollAngleoffFactor()
-- Return rolloff power factor.
--
-- @function [parent=#SoundSource3D] RollAngleoffFactor
-- @param self Self reference
-- @return #number

---
-- Field nearDistance
--
-- @field [parent=#SoundSource3D] #number nearDistance

---
-- Field farDistance
--
-- @field [parent=#SoundSource3D] #number farDistance

---
-- Field innerAngle
--
-- @field [parent=#SoundSource3D] #number innerAngle

---
-- Field outerAngle
--
-- @field [parent=#SoundSource3D] #number outerAngle

---
-- Field rolloffFactor
--
-- @field [parent=#SoundSource3D] #number rolloffFactor


return nil
