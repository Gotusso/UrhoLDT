---
-- Enumeration VertexElement
--
-- @module VertexElement

---
-- Enumeration value ELEMENT_POSITION
--
-- @field [parent=#VertexElement] #number ELEMENT_POSITION

---
-- Enumeration value ELEMENT_NORMAL
--
-- @field [parent=#VertexElement] #number ELEMENT_NORMAL

---
-- Enumeration value ELEMENT_COLOR
--
-- @field [parent=#VertexElement] #number ELEMENT_COLOR

---
-- Enumeration value ELEMENT_TEXCOORD1
--
-- @field [parent=#VertexElement] #number ELEMENT_TEXCOORD1

---
-- Enumeration value ELEMENT_TEXCOORD2
--
-- @field [parent=#VertexElement] #number ELEMENT_TEXCOORD2

---
-- Enumeration value ELEMENT_CUBETEXCOORD1
--
-- @field [parent=#VertexElement] #number ELEMENT_CUBETEXCOORD1

---
-- Enumeration value ELEMENT_CUBETEXCOORD2
--
-- @field [parent=#VertexElement] #number ELEMENT_CUBETEXCOORD2

---
-- Enumeration value ELEMENT_TANGENT
--
-- @field [parent=#VertexElement] #number ELEMENT_TANGENT

---
-- Enumeration value ELEMENT_BLENDWEIGHTS
--
-- @field [parent=#VertexElement] #number ELEMENT_BLENDWEIGHTS

---
-- Enumeration value ELEMENT_BLENDINDICES
--
-- @field [parent=#VertexElement] #number ELEMENT_BLENDINDICES

---
-- Enumeration value ELEMENT_INSTANCEMATRIX1
--
-- @field [parent=#VertexElement] #number ELEMENT_INSTANCEMATRIX1

---
-- Enumeration value ELEMENT_INSTANCEMATRIX2
--
-- @field [parent=#VertexElement] #number ELEMENT_INSTANCEMATRIX2

---
-- Enumeration value ELEMENT_INSTANCEMATRIX3
--
-- @field [parent=#VertexElement] #number ELEMENT_INSTANCEMATRIX3

---
-- Enumeration value MAX_VERTEX_ELEMENTS
--
-- @field [parent=#VertexElement] #number MAX_VERTEX_ELEMENTS


return nil
