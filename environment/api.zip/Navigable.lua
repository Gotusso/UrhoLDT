---
-- Module Navigable
-- Module Navigable extends Component
-- Generated on 2014-05-31
--
-- @module Navigable

---
-- Function SetRecursive()
-- Set whether geometry is automatically collected from child nodes. Default true.
--
-- @function [parent=#Navigable] SetRecursive
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsRecursive()
-- Return whether geometry is automatically collected from child nodes.
--
-- @function [parent=#Navigable] IsRecursive
-- @param self Self reference
-- @return #boolean

---
-- Field recursive
--
-- @field [parent=#Navigable] #boolean recursive


return nil
