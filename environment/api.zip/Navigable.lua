---
-- Module Navigable
-- Module Navigable extends Component
-- Generated on 2014-03-13
--
-- @module Navigable

---
-- Function SetRecursive
--
-- @function [parent=#Navigable] SetRecursive
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsRecursive
--
-- @function [parent=#Navigable] IsRecursive
-- @param self Self reference
-- @return #boolean

---
-- Field recursive
--
-- @field [parent=#Navigable] #boolean recursive

---
-- Function SetEnabled
--
-- @function [parent=#Navigable] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Remove
--
-- @function [parent=#Navigable] Remove
-- @param self Self reference

---
-- Function GetID
--
-- @function [parent=#Navigable] GetID
-- @param self Self reference
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#Navigable] GetNode
-- @param self Self reference
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#Navigable] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#Navigable] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#Navigable] IsEnabledEffective
-- @param self Self reference
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#Navigable] GetComponent
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#Navigable] GetComponent
-- @param self Self reference
-- @param #string type type
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#Navigable] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#Navigable] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Navigable] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Navigable] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Navigable] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Navigable] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Navigable] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Navigable] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#Navigable] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Navigable] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Navigable] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Navigable] #string category


return nil
