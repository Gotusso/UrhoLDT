---
-- Module Navigable
-- extends Component
--
-- @module Navigable

---
-- Function SetRecursive
--
-- @function [parent=#Navigable] SetRecursive
-- @param #boolean enableenable

---
-- Function IsRecursive
--
-- @function [parent=#Navigable] IsRecursive
-- @return #boolean

---
-- Field recursive
--
-- @field [parent=#Navigable] #boolean recursive

---
-- Function SetEnabled
--
-- @function [parent=#Navigable] SetEnabled
-- @param #boolean enableenable

---
-- Function Remove
--
-- @function [parent=#Navigable] Remove

---
-- Function GetID
--
-- @function [parent=#Navigable] GetID
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#Navigable] GetNode
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#Navigable] GetScene
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#Navigable] IsEnabled
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#Navigable] IsEnabledEffective
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#Navigable] GetComponent
-- @param ShortStringHash#ShortStringHash typetype
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#Navigable] GetComponent
-- @param #string typetype
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#Navigable] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#Navigable] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Navigable] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Navigable] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Navigable] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Navigable] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Navigable] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Navigable] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#Navigable] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Navigable] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Navigable] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Navigable] #string category


return nil
