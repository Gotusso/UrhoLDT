---
-- Module Navigable
-- Extends Component
--
-- @module Navigable

---
-- Function SetRecursive
--
-- @function [parent=#Navigable] SetRecursive
-- @param #boolean enableenable

---
-- Function IsRecursive
--
-- @function [parent=#Navigable] IsRecursive
-- @return #boolean

---
-- Field recursive
--
-- @field [parent=#Navigable] #boolean recursive


return nil
