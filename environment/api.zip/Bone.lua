---
-- Module Bone
--
-- @module Bone

---
-- Function Bone
--
-- @function [parent=#Bone] Bone

---
-- Function new
--
-- @function [parent=#Bone] new
-- @return Bone#Bone

---
-- Function delete
--
-- @function [parent=#Bone] delete

---
-- Field name
--
-- @field [parent=#Bone] #string name

---
-- Field nameHash
--
-- @field [parent=#Bone] StringHash#StringHash nameHash

---
-- Field parentIndex
--
-- @field [parent=#Bone] #number parentIndex

---
-- Field initialPosition
--
-- @field [parent=#Bone] Vector3#Vector3 initialPosition

---
-- Field initialRotation
--
-- @field [parent=#Bone] Quaternion#Quaternion initialRotation

---
-- Field initialScale
--
-- @field [parent=#Bone] Vector3#Vector3 initialScale

---
-- Field offsetMatrix
--
-- @field [parent=#Bone] Matrix3x4#Matrix3x4 offsetMatrix

---
-- Field animated
--
-- @field [parent=#Bone] #boolean animated

---
-- Field collisionMask
--
-- @field [parent=#Bone] #string collisionMask

---
-- Field radius
--
-- @field [parent=#Bone] #number radius

---
-- Field boundingBox
--
-- @field [parent=#Bone] BoundingBox#BoundingBox boundingBox

---
-- Field node
--
-- @field [parent=#Bone] Node#Node node


return nil
