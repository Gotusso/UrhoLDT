---
-- Module View3D
-- Module View3D extends Window
-- Generated on 2014-03-13
--
-- @module View3D

---
-- Function View3D
--
-- @function [parent=#View3D] View3D
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#View3D] new
-- @param self Self reference
-- @return View3D#View3D

---
-- Function delete
--
-- @function [parent=#View3D] delete
-- @param self Self reference

---
-- Function SetView
--
-- @function [parent=#View3D] SetView
-- @param self Self reference
-- @param Scene#Scene scene scene
-- @param Camera#Camera camera camera

---
-- Function SetFormat
--
-- @function [parent=#View3D] SetFormat
-- @param self Self reference
-- @param #number format format

---
-- Function SetAutoUpdate
--
-- @function [parent=#View3D] SetAutoUpdate
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function QueueUpdate
--
-- @function [parent=#View3D] QueueUpdate
-- @param self Self reference

---
-- Function GetFormat
--
-- @function [parent=#View3D] GetFormat
-- @param self Self reference
-- @return #number

---
-- Function GetAutoUpdate
--
-- @function [parent=#View3D] GetAutoUpdate
-- @param self Self reference
-- @return #boolean

---
-- Function GetScene
--
-- @function [parent=#View3D] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function GetCameraNode
--
-- @function [parent=#View3D] GetCameraNode
-- @param self Self reference
-- @return Node#Node

---
-- Function GetRenderTexture
--
-- @function [parent=#View3D] GetRenderTexture
-- @param self Self reference
-- @return Texture2D#Texture2D

---
-- Function GetDepthTexture
--
-- @function [parent=#View3D] GetDepthTexture
-- @param self Self reference
-- @return Texture2D#Texture2D

---
-- Function GetViewport
--
-- @function [parent=#View3D] GetViewport
-- @param self Self reference
-- @return Viewport#Viewport

---
-- Field format
--
-- @field [parent=#View3D] #number format

---
-- Field autoUpdate
--
-- @field [parent=#View3D] #boolean autoUpdate

---
-- Function Window
--
-- @function [parent=#View3D] Window
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#View3D] new
-- @param self Self reference
-- @return Window#Window

---
-- Function delete
--
-- @function [parent=#View3D] delete
-- @param self Self reference

---
-- Function SetMovable
--
-- @function [parent=#View3D] SetMovable
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetResizable
--
-- @function [parent=#View3D] SetResizable
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetFixedWidthResizing
--
-- @function [parent=#View3D] SetFixedWidthResizing
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetFixedHeightResizing
--
-- @function [parent=#View3D] SetFixedHeightResizing
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetResizeBorder
--
-- @function [parent=#View3D] SetResizeBorder
-- @param self Self reference
-- @param IntRect#IntRect rect rect

---
-- Function SetModal
--
-- @function [parent=#View3D] SetModal
-- @param self Self reference
-- @param #boolean modal modal

---
-- Function SetModalShadeColor
--
-- @function [parent=#View3D] SetModalShadeColor
-- @param self Self reference
-- @param Color#Color color color

---
-- Function SetModalFrameColor
--
-- @function [parent=#View3D] SetModalFrameColor
-- @param self Self reference
-- @param Color#Color color color

---
-- Function SetModalFrameSize
--
-- @function [parent=#View3D] SetModalFrameSize
-- @param self Self reference
-- @param IntVector2#IntVector2 size size

---
-- Function IsMovable
--
-- @function [parent=#View3D] IsMovable
-- @param self Self reference
-- @return #boolean

---
-- Function IsResizable
--
-- @function [parent=#View3D] IsResizable
-- @param self Self reference
-- @return #boolean

---
-- Function GetFixedWidthResizing
--
-- @function [parent=#View3D] GetFixedWidthResizing
-- @param self Self reference
-- @return #boolean

---
-- Function GetFixedHeightResizing
--
-- @function [parent=#View3D] GetFixedHeightResizing
-- @param self Self reference
-- @return #boolean

---
-- Function GetResizeBorder
--
-- @function [parent=#View3D] GetResizeBorder
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function IsModal
--
-- @function [parent=#View3D] IsModal
-- @param self Self reference
-- @return #boolean

---
-- Function GetModalShadeColor
--
-- @function [parent=#View3D] GetModalShadeColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetModalFrameColor
--
-- @function [parent=#View3D] GetModalFrameColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetModalFrameSize
--
-- @function [parent=#View3D] GetModalFrameSize
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Field movable
--
-- @field [parent=#View3D] #boolean movable

---
-- Field resizable
--
-- @field [parent=#View3D] #boolean resizable

---
-- Field fixedWidthResizing
--
-- @field [parent=#View3D] #boolean fixedWidthResizing

---
-- Field fixedHeightResizing
--
-- @field [parent=#View3D] #boolean fixedHeightResizing

---
-- Field resizeBorder
--
-- @field [parent=#View3D] IntRect#IntRect resizeBorder

---
-- Field modal
--
-- @field [parent=#View3D] #boolean modal

---
-- Field modalShadeColor
--
-- @field [parent=#View3D] Color#Color modalShadeColor

---
-- Field modalFrameColor
--
-- @field [parent=#View3D] Color#Color modalFrameColor

---
-- Field modalFrameSize
--
-- @field [parent=#View3D] IntVector2#IntVector2 modalFrameSize

---
-- Function BorderImage
--
-- @function [parent=#View3D] BorderImage
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#View3D] new
-- @param self Self reference
-- @return BorderImage#BorderImage

---
-- Function delete
--
-- @function [parent=#View3D] delete
-- @param self Self reference

---
-- Function SetTexture
--
-- @function [parent=#View3D] SetTexture
-- @param self Self reference
-- @param Texture#Texture texture texture

---
-- Function SetImageRect
--
-- @function [parent=#View3D] SetImageRect
-- @param self Self reference
-- @param IntRect#IntRect rect rect

---
-- Function SetFullImageRect
--
-- @function [parent=#View3D] SetFullImageRect
-- @param self Self reference

---
-- Function SetBorder
--
-- @function [parent=#View3D] SetBorder
-- @param self Self reference
-- @param IntRect#IntRect rect rect

---
-- Function SetHoverOffset
--
-- @function [parent=#View3D] SetHoverOffset
-- @param self Self reference
-- @param IntVector2#IntVector2 offset offset

---
-- Function SetHoverOffset
--
-- @function [parent=#View3D] SetHoverOffset
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function SetBlendMode
--
-- @function [parent=#View3D] SetBlendMode
-- @param self Self reference
-- @param BlendMode#BlendMode mode mode

---
-- Function SetTiled
--
-- @function [parent=#View3D] SetTiled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function GetTexture
--
-- @function [parent=#View3D] GetTexture
-- @param self Self reference
-- @return Texture#Texture

---
-- Function GetImageRect
--
-- @function [parent=#View3D] GetImageRect
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetBorder
--
-- @function [parent=#View3D] GetBorder
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetHoverOffset
--
-- @function [parent=#View3D] GetHoverOffset
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetBlendMode
--
-- @function [parent=#View3D] GetBlendMode
-- @param self Self reference
-- @return BlendMode#BlendMode

---
-- Function IsTiled
--
-- @function [parent=#View3D] IsTiled
-- @param self Self reference
-- @return #boolean

---
-- Field texture
--
-- @field [parent=#View3D] Texture#Texture texture

---
-- Field imageRect
--
-- @field [parent=#View3D] IntRect#IntRect imageRect

---
-- Field border
--
-- @field [parent=#View3D] IntRect#IntRect border

---
-- Field hoverOffset
--
-- @field [parent=#View3D] IntVector2#IntVector2 hoverOffset

---
-- Field blendMode
--
-- @field [parent=#View3D] BlendMode#BlendMode blendMode

---
-- Field tiled
--
-- @field [parent=#View3D] #boolean tiled

---
-- Function UIElement
--
-- @function [parent=#View3D] UIElement
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#View3D] new
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function delete
--
-- @function [parent=#View3D] delete
-- @param self Self reference

---
-- Function GetScreenPosition
--
-- @function [parent=#View3D] GetScreenPosition
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function LoadXML
--
-- @function [parent=#View3D] LoadXML
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#View3D] SaveXML
-- @param self Self reference
-- @param Serializer#Serializer dest dest
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#View3D] LoadXML
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#View3D] SaveXML
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function FilterAttributes
--
-- @function [parent=#View3D] FilterAttributes
-- @param self Self reference
-- @param XMLElement#XMLElement dest dest
-- @return #boolean

---
-- Function SetName
--
-- @function [parent=#View3D] SetName
-- @param self Self reference
-- @param #string name name

---
-- Function SetPosition
--
-- @function [parent=#View3D] SetPosition
-- @param self Self reference
-- @param IntVector2#IntVector2 position position

---
-- Function SetPosition
--
-- @function [parent=#View3D] SetPosition
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function SetSize
--
-- @function [parent=#View3D] SetSize
-- @param self Self reference
-- @param IntVector2#IntVector2 size size

---
-- Function SetSize
--
-- @function [parent=#View3D] SetSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetWidth
--
-- @function [parent=#View3D] SetWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetHeight
--
-- @function [parent=#View3D] SetHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetMinSize
--
-- @function [parent=#View3D] SetMinSize
-- @param self Self reference
-- @param IntVector2#IntVector2 minSize minSize

---
-- Function SetMinSize
--
-- @function [parent=#View3D] SetMinSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetMinWidth
--
-- @function [parent=#View3D] SetMinWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetMinHeight
--
-- @function [parent=#View3D] SetMinHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetMaxSize
--
-- @function [parent=#View3D] SetMaxSize
-- @param self Self reference
-- @param IntVector2#IntVector2 maxSize maxSize

---
-- Function SetMaxSize
--
-- @function [parent=#View3D] SetMaxSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetMaxWidth
--
-- @function [parent=#View3D] SetMaxWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetMaxHeight
--
-- @function [parent=#View3D] SetMaxHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetFixedSize
--
-- @function [parent=#View3D] SetFixedSize
-- @param self Self reference
-- @param IntVector2#IntVector2 size size

---
-- Function SetFixedSize
--
-- @function [parent=#View3D] SetFixedSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetFixedWidth
--
-- @function [parent=#View3D] SetFixedWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetFixedHeight
--
-- @function [parent=#View3D] SetFixedHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetAlignment
--
-- @function [parent=#View3D] SetAlignment
-- @param self Self reference
-- @param HorizontalAlignment#HorizontalAlignment hAlign hAlign
-- @param VerticalAlignment#VerticalAlignment vAlign vAlign

---
-- Function SetHorizontalAlignment
--
-- @function [parent=#View3D] SetHorizontalAlignment
-- @param self Self reference
-- @param HorizontalAlignment#HorizontalAlignment align align

---
-- Function SetVerticalAlignment
--
-- @function [parent=#View3D] SetVerticalAlignment
-- @param self Self reference
-- @param VerticalAlignment#VerticalAlignment align align

---
-- Function SetClipBorder
--
-- @function [parent=#View3D] SetClipBorder
-- @param self Self reference
-- @param IntRect#IntRect rect rect

---
-- Function SetColor
--
-- @function [parent=#View3D] SetColor
-- @param self Self reference
-- @param Color#Color color color

---
-- Function SetColor
--
-- @function [parent=#View3D] SetColor
-- @param self Self reference
-- @param Corner#Corner corner corner
-- @param Color#Color color color

---
-- Function SetPriority
--
-- @function [parent=#View3D] SetPriority
-- @param self Self reference
-- @param #number priority priority

---
-- Function SetOpacity
--
-- @function [parent=#View3D] SetOpacity
-- @param self Self reference
-- @param #number opacity opacity

---
-- Function SetBringToFront
--
-- @function [parent=#View3D] SetBringToFront
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetBringToBack
--
-- @function [parent=#View3D] SetBringToBack
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetClipChildren
--
-- @function [parent=#View3D] SetClipChildren
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetSortChildren
--
-- @function [parent=#View3D] SetSortChildren
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetUseDerivedOpacity
--
-- @function [parent=#View3D] SetUseDerivedOpacity
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetEnabled
--
-- @function [parent=#View3D] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetEditable
--
-- @function [parent=#View3D] SetEditable
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetFocus
--
-- @function [parent=#View3D] SetFocus
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetSelected
--
-- @function [parent=#View3D] SetSelected
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetVisible
--
-- @function [parent=#View3D] SetVisible
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetFocusMode
--
-- @function [parent=#View3D] SetFocusMode
-- @param self Self reference
-- @param FocusMode#FocusMode mode mode

---
-- Function SetDragDropMode
--
-- @function [parent=#View3D] SetDragDropMode
-- @param self Self reference
-- @param #number mode mode

---
-- Function SetStyle
--
-- @function [parent=#View3D] SetStyle
-- @param self Self reference
-- @param #string styleName styleName
-- @param XMLFile#XMLFile file file
-- @return #boolean

---
-- Function SetStyle
--
-- @function [parent=#View3D] SetStyle
-- @param self Self reference
-- @param XMLElement#XMLElement element element
-- @return #boolean

---
-- Function SetStyleAuto
--
-- @function [parent=#View3D] SetStyleAuto
-- @param self Self reference
-- @param XMLFile#XMLFile file file
-- @return #boolean

---
-- Function SetDefaultStyle
--
-- @function [parent=#View3D] SetDefaultStyle
-- @param self Self reference
-- @param XMLFile#XMLFile style style

---
-- Function SetLayout
--
-- @function [parent=#View3D] SetLayout
-- @param self Self reference
-- @param LayoutMode#LayoutMode mode mode
-- @param #number spacing spacing

---
-- Function SetLayout
--
-- @function [parent=#View3D] SetLayout
-- @param self Self reference
-- @param LayoutMode#LayoutMode mode mode
-- @param #number spacing spacing
-- @param IntRect#IntRect border border

---
-- Function SetLayoutMode
--
-- @function [parent=#View3D] SetLayoutMode
-- @param self Self reference
-- @param LayoutMode#LayoutMode mode mode

---
-- Function SetLayoutSpacing
--
-- @function [parent=#View3D] SetLayoutSpacing
-- @param self Self reference
-- @param #number spacing spacing

---
-- Function SetLayoutBorder
--
-- @function [parent=#View3D] SetLayoutBorder
-- @param self Self reference
-- @param IntRect#IntRect border border

---
-- Function SetIndent
--
-- @function [parent=#View3D] SetIndent
-- @param self Self reference
-- @param #number indent indent

---
-- Function SetIndentSpacing
--
-- @function [parent=#View3D] SetIndentSpacing
-- @param self Self reference
-- @param #number indentSpacing indentSpacing

---
-- Function UpdateLayout
--
-- @function [parent=#View3D] UpdateLayout
-- @param self Self reference

---
-- Function DisableLayoutUpdate
--
-- @function [parent=#View3D] DisableLayoutUpdate
-- @param self Self reference

---
-- Function EnableLayoutUpdate
--
-- @function [parent=#View3D] EnableLayoutUpdate
-- @param self Self reference

---
-- Function BringToFront
--
-- @function [parent=#View3D] BringToFront
-- @param self Self reference

---
-- Function CreateChild
--
-- @function [parent=#View3D] CreateChild
-- @param self Self reference
-- @param #string type type
-- @param #string name name
-- @param #number index index
-- @return UIElement#UIElement

---
-- Function AddChild
--
-- @function [parent=#View3D] AddChild
-- @param self Self reference
-- @param UIElement#UIElement element element

---
-- Function InsertChild
--
-- @function [parent=#View3D] InsertChild
-- @param self Self reference
-- @param #number index index
-- @param UIElement#UIElement element element

---
-- Function RemoveChild
--
-- @function [parent=#View3D] RemoveChild
-- @param self Self reference
-- @param UIElement#UIElement element element
-- @param #number index index

---
-- Function RemoveChildAtIndex
--
-- @function [parent=#View3D] RemoveChildAtIndex
-- @param self Self reference
-- @param #number index index

---
-- Function RemoveAllChildren
--
-- @function [parent=#View3D] RemoveAllChildren
-- @param self Self reference

---
-- Function Remove
--
-- @function [parent=#View3D] Remove
-- @param self Self reference

---
-- Function FindChild
--
-- @function [parent=#View3D] FindChild
-- @param self Self reference
-- @param UIElement#UIElement element element
-- @return #number

---
-- Function SetParent
--
-- @function [parent=#View3D] SetParent
-- @param self Self reference
-- @param UIElement#UIElement parent parent
-- @param #number index index

---
-- Function SetVar
--
-- @function [parent=#View3D] SetVar
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash key key
-- @param Variant#Variant value value

---
-- Function SetInternal
--
-- @function [parent=#View3D] SetInternal
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetTraversalMode
--
-- @function [parent=#View3D] SetTraversalMode
-- @param self Self reference
-- @param TraversalMode#TraversalMode traversalMode traversalMode

---
-- Function SetElementEventSender
--
-- @function [parent=#View3D] SetElementEventSender
-- @param self Self reference
-- @param #boolean flag flag

---
-- Function GetName
--
-- @function [parent=#View3D] GetName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetPosition
--
-- @function [parent=#View3D] GetPosition
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetSize
--
-- @function [parent=#View3D] GetSize
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetWidth
--
-- @function [parent=#View3D] GetWidth
-- @param self Self reference
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#View3D] GetHeight
-- @param self Self reference
-- @return #number

---
-- Function GetMinSize
--
-- @function [parent=#View3D] GetMinSize
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetMinWidth
--
-- @function [parent=#View3D] GetMinWidth
-- @param self Self reference
-- @return #number

---
-- Function GetMinHeight
--
-- @function [parent=#View3D] GetMinHeight
-- @param self Self reference
-- @return #number

---
-- Function GetMaxSize
--
-- @function [parent=#View3D] GetMaxSize
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetMaxWidth
--
-- @function [parent=#View3D] GetMaxWidth
-- @param self Self reference
-- @return #number

---
-- Function GetMaxHeight
--
-- @function [parent=#View3D] GetMaxHeight
-- @param self Self reference
-- @return #number

---
-- Function IsFixedSize
--
-- @function [parent=#View3D] IsFixedSize
-- @param self Self reference
-- @return #boolean

---
-- Function IsFixedWidth
--
-- @function [parent=#View3D] IsFixedWidth
-- @param self Self reference
-- @return #boolean

---
-- Function IsFixedHeight
--
-- @function [parent=#View3D] IsFixedHeight
-- @param self Self reference
-- @return #boolean

---
-- Function GetChildOffset
--
-- @function [parent=#View3D] GetChildOffset
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetHorizontalAlignment
--
-- @function [parent=#View3D] GetHorizontalAlignment
-- @param self Self reference
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetVerticalAlignment
--
-- @function [parent=#View3D] GetVerticalAlignment
-- @param self Self reference
-- @return VerticalAlignment#VerticalAlignment

---
-- Function GetClipBorder
--
-- @function [parent=#View3D] GetClipBorder
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetColor
--
-- @function [parent=#View3D] GetColor
-- @param self Self reference
-- @param Corner#Corner corner corner
-- @return const Color#const Color

---
-- Function GetPriority
--
-- @function [parent=#View3D] GetPriority
-- @param self Self reference
-- @return #number

---
-- Function GetOpacity
--
-- @function [parent=#View3D] GetOpacity
-- @param self Self reference
-- @return #number

---
-- Function GetDerivedOpacity
--
-- @function [parent=#View3D] GetDerivedOpacity
-- @param self Self reference
-- @return #number

---
-- Function GetBringToFront
--
-- @function [parent=#View3D] GetBringToFront
-- @param self Self reference
-- @return #boolean

---
-- Function GetBringToBack
--
-- @function [parent=#View3D] GetBringToBack
-- @param self Self reference
-- @return #boolean

---
-- Function GetClipChildren
--
-- @function [parent=#View3D] GetClipChildren
-- @param self Self reference
-- @return #boolean

---
-- Function GetSortChildren
--
-- @function [parent=#View3D] GetSortChildren
-- @param self Self reference
-- @return #boolean

---
-- Function GetUseDerivedOpacity
--
-- @function [parent=#View3D] GetUseDerivedOpacity
-- @param self Self reference
-- @return #boolean

---
-- Function HasFocus
--
-- @function [parent=#View3D] HasFocus
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabled
--
-- @function [parent=#View3D] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEditable
--
-- @function [parent=#View3D] IsEditable
-- @param self Self reference
-- @return #boolean

---
-- Function IsSelected
--
-- @function [parent=#View3D] IsSelected
-- @param self Self reference
-- @return #boolean

---
-- Function IsVisible
--
-- @function [parent=#View3D] IsVisible
-- @param self Self reference
-- @return #boolean

---
-- Function IsHovering
--
-- @function [parent=#View3D] IsHovering
-- @param self Self reference
-- @return #boolean

---
-- Function IsInternal
--
-- @function [parent=#View3D] IsInternal
-- @param self Self reference
-- @return #boolean

---
-- Function HasColorGradient
--
-- @function [parent=#View3D] HasColorGradient
-- @param self Self reference
-- @return #boolean

---
-- Function GetFocusMode
--
-- @function [parent=#View3D] GetFocusMode
-- @param self Self reference
-- @return FocusMode#FocusMode

---
-- Function GetDragDropMode
--
-- @function [parent=#View3D] GetDragDropMode
-- @param self Self reference
-- @return #number

---
-- Function GetAppliedStyle
--
-- @function [parent=#View3D] GetAppliedStyle
-- @param self Self reference
-- @return const String#const String

---
-- Function GetDefaultStyle
--
-- @function [parent=#View3D] GetDefaultStyle
-- @param self Self reference
-- @param #boolean recursiveUp recursiveUp
-- @return XMLFile#XMLFile

---
-- Function GetLayoutMode
--
-- @function [parent=#View3D] GetLayoutMode
-- @param self Self reference
-- @return LayoutMode#LayoutMode

---
-- Function GetLayoutSpacing
--
-- @function [parent=#View3D] GetLayoutSpacing
-- @param self Self reference
-- @return #number

---
-- Function GetLayoutBorder
--
-- @function [parent=#View3D] GetLayoutBorder
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetNumChildren
--
-- @function [parent=#View3D] GetNumChildren
-- @param self Self reference
-- @param #boolean recursive recursive
-- @return #number

---
-- Function GetChild
--
-- @function [parent=#View3D] GetChild
-- @param self Self reference
-- @param #string name name
-- @param #boolean recursive recursive
-- @return UIElement#UIElement

---
-- Function GetChild
--
-- @function [parent=#View3D] GetChild
-- @param self Self reference
-- @param #number index index
-- @return UIElement#UIElement

---
-- Function GetParent
--
-- @function [parent=#View3D] GetParent
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetRoot
--
-- @function [parent=#View3D] GetRoot
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetDerivedColor
--
-- @function [parent=#View3D] GetDerivedColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetVar
--
-- @function [parent=#View3D] GetVar
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash key key
-- @return const Variant#const Variant

---
-- Function GetVars
--
-- @function [parent=#View3D] GetVars
-- @param self Self reference
-- @return const VariantMap#const VariantMap

---
-- Function ScreenToElement
--
-- @function [parent=#View3D] ScreenToElement
-- @param self Self reference
-- @param IntVector2#IntVector2 screenPosition screenPosition
-- @return IntVector2#IntVector2

---
-- Function ElementToScreen
--
-- @function [parent=#View3D] ElementToScreen
-- @param self Self reference
-- @param IntVector2#IntVector2 position position
-- @return IntVector2#IntVector2

---
-- Function IsInside
--
-- @function [parent=#View3D] IsInside
-- @param self Self reference
-- @param IntVector2#IntVector2 position position
-- @param #boolean isScreen isScreen
-- @return #boolean

---
-- Function IsInsideCombined
--
-- @function [parent=#View3D] IsInsideCombined
-- @param self Self reference
-- @param IntVector2#IntVector2 position position
-- @param #boolean isScreen isScreen
-- @return #boolean

---
-- Function GetCombinedScreenRect
--
-- @function [parent=#View3D] GetCombinedScreenRect
-- @param self Self reference
-- @return IntRect#IntRect

---
-- Function SortChildren
--
-- @function [parent=#View3D] SortChildren
-- @param self Self reference

---
-- Function GetLayoutMinSize
--
-- @function [parent=#View3D] GetLayoutMinSize
-- @param self Self reference
-- @return #number

---
-- Function GetIndent
--
-- @function [parent=#View3D] GetIndent
-- @param self Self reference
-- @return #number

---
-- Function GetIndentSpacing
--
-- @function [parent=#View3D] GetIndentSpacing
-- @param self Self reference
-- @return #number

---
-- Function GetIndentWidth
--
-- @function [parent=#View3D] GetIndentWidth
-- @param self Self reference
-- @return #number

---
-- Function SetChildOffset
--
-- @function [parent=#View3D] SetChildOffset
-- @param self Self reference
-- @param IntVector2#IntVector2 offset offset

---
-- Function SetHovering
--
-- @function [parent=#View3D] SetHovering
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function GetColor
--
-- @function [parent=#View3D] GetColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetTraversalMode
--
-- @function [parent=#View3D] GetTraversalMode
-- @param self Self reference
-- @return TraversalMode#TraversalMode

---
-- Function IsElementEventSender
--
-- @function [parent=#View3D] IsElementEventSender
-- @param self Self reference
-- @return #boolean

---
-- Function GetElementEventSender
--
-- @function [parent=#View3D] GetElementEventSender
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Field screenPosition (Read only)
--
-- @field [parent=#View3D] IntVector2#IntVector2 screenPosition

---
-- Field name
--
-- @field [parent=#View3D] #string name

---
-- Field position
--
-- @field [parent=#View3D] IntVector2#IntVector2 position

---
-- Field size
--
-- @field [parent=#View3D] IntVector2#IntVector2 size

---
-- Field width
--
-- @field [parent=#View3D] #number width

---
-- Field height
--
-- @field [parent=#View3D] #number height

---
-- Field minSize
--
-- @field [parent=#View3D] IntVector2#IntVector2 minSize

---
-- Field minWidth
--
-- @field [parent=#View3D] #number minWidth

---
-- Field minHeight
--
-- @field [parent=#View3D] #number minHeight

---
-- Field maxSize
--
-- @field [parent=#View3D] IntVector2#IntVector2 maxSize

---
-- Field maxWidth
--
-- @field [parent=#View3D] #number maxWidth

---
-- Field maxHeight
--
-- @field [parent=#View3D] #number maxHeight

---
-- Field fixedSize (Read only)
--
-- @field [parent=#View3D] #boolean fixedSize

---
-- Field fixedWidth (Read only)
--
-- @field [parent=#View3D] #boolean fixedWidth

---
-- Field fixedHeight (Read only)
--
-- @field [parent=#View3D] #boolean fixedHeight

---
-- Field childOffset
--
-- @field [parent=#View3D] IntVector2#IntVector2 childOffset

---
-- Field horizontalAlignment
--
-- @field [parent=#View3D] HorizontalAlignment#HorizontalAlignment horizontalAlignment

---
-- Field verticalAlignment
--
-- @field [parent=#View3D] VerticalAlignment#VerticalAlignment verticalAlignment

---
-- Field clipBorder
--
-- @field [parent=#View3D] IntRect#IntRect clipBorder

---
-- Field color
--
-- @field [parent=#View3D] Color#Color color

---
-- Field priority
--
-- @field [parent=#View3D] #number priority

---
-- Field opacity
--
-- @field [parent=#View3D] #number opacity

---
-- Field derivedOpacity (Read only)
--
-- @field [parent=#View3D] #number derivedOpacity

---
-- Field bringToFront
--
-- @field [parent=#View3D] #boolean bringToFront

---
-- Field bringToBack
--
-- @field [parent=#View3D] #boolean bringToBack

---
-- Field clipChildren
--
-- @field [parent=#View3D] #boolean clipChildren

---
-- Field sortChildren
--
-- @field [parent=#View3D] #boolean sortChildren

---
-- Field useDerivedOpacity
--
-- @field [parent=#View3D] #boolean useDerivedOpacity

---
-- Field focus
--
-- @field [parent=#View3D] #boolean focus

---
-- Field enabled
--
-- @field [parent=#View3D] #boolean enabled

---
-- Field editable
--
-- @field [parent=#View3D] #boolean editable

---
-- Field selected
--
-- @field [parent=#View3D] #boolean selected

---
-- Field visible
--
-- @field [parent=#View3D] #boolean visible

---
-- Field hovering
--
-- @field [parent=#View3D] #boolean hovering

---
-- Field internal
--
-- @field [parent=#View3D] #boolean internal

---
-- Field colorGradient (Read only)
--
-- @field [parent=#View3D] #boolean colorGradient

---
-- Field focusMode
--
-- @field [parent=#View3D] FocusMode#FocusMode focusMode

---
-- Field dragDropMode
--
-- @field [parent=#View3D] #number dragDropMode

---
-- Field style
--
-- @field [parent=#View3D] #string style

---
-- Field defaultStyle
--
-- @field [parent=#View3D] XMLFile#XMLFile defaultStyle

---
-- Field layoutMode
--
-- @field [parent=#View3D] LayoutMode#LayoutMode layoutMode

---
-- Field layoutSpacing
--
-- @field [parent=#View3D] #number layoutSpacing

---
-- Field layoutBorder
--
-- @field [parent=#View3D] IntRect#IntRect layoutBorder

---
-- Field numChildren (Read only)
--
-- @field [parent=#View3D] #number numChildren

---
-- Field parent
--
-- @field [parent=#View3D] UIElement#UIElement parent

---
-- Field root (Read only)
--
-- @field [parent=#View3D] UIElement#UIElement root

---
-- Field derivedColor (Read only)
--
-- @field [parent=#View3D] Color#Color derivedColor

---
-- Field combinedScreenRect (Read only)
--
-- @field [parent=#View3D] IntRect#IntRect combinedScreenRect

---
-- Field layoutMinSize (Read only)
--
-- @field [parent=#View3D] #number layoutMinSize

---
-- Field indent
--
-- @field [parent=#View3D] #number indent

---
-- Field indentSpacing
--
-- @field [parent=#View3D] #number indentSpacing

---
-- Field indentWidth (Read only)
--
-- @field [parent=#View3D] #number indentWidth

---
-- Field traversalMode
--
-- @field [parent=#View3D] TraversalMode#TraversalMode traversalMode

---
-- Field elementEventSender
--
-- @field [parent=#View3D] #boolean elementEventSender

---
-- Function SetTemporary
--
-- @function [parent=#View3D] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#View3D] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#View3D] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#View3D] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#View3D] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#View3D] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#View3D] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#View3D] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#View3D] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#View3D] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#View3D] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#View3D] #string category


return nil
