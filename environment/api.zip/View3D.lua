---
-- Module View3D
-- Extends Window
--
-- @module View3D

---
-- Function View3D
--
-- @function [parent=#View3D] View3D

---
-- Function new
--
-- @function [parent=#View3D] new
-- @return View3D#View3D

---
-- Function delete
--
-- @function [parent=#View3D] delete

---
-- Function SetView
--
-- @function [parent=#View3D] SetView
-- @param Scene#Scene scenescene
-- @param Camera#Camera cameracamera

---
-- Function SetFormat
--
-- @function [parent=#View3D] SetFormat
-- @param #number formatformat

---
-- Function SetAutoUpdate
--
-- @function [parent=#View3D] SetAutoUpdate
-- @param #boolean enableenable

---
-- Function QueueUpdate
--
-- @function [parent=#View3D] QueueUpdate

---
-- Function GetFormat
--
-- @function [parent=#View3D] GetFormat
-- @return #number

---
-- Function GetAutoUpdate
--
-- @function [parent=#View3D] GetAutoUpdate
-- @return #boolean

---
-- Function GetScene
--
-- @function [parent=#View3D] GetScene
-- @return Scene#Scene

---
-- Function GetCameraNode
--
-- @function [parent=#View3D] GetCameraNode
-- @return Node#Node

---
-- Function GetRenderTexture
--
-- @function [parent=#View3D] GetRenderTexture
-- @return Texture2D#Texture2D

---
-- Function GetDepthTexture
--
-- @function [parent=#View3D] GetDepthTexture
-- @return Texture2D#Texture2D

---
-- Function GetViewport
--
-- @function [parent=#View3D] GetViewport
-- @return Viewport#Viewport

---
-- Field format
--
-- @field [parent=#View3D] #number format

---
-- Field autoUpdate
--
-- @field [parent=#View3D] #boolean autoUpdate


return nil
