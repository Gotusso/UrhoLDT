---
-- Module View3D
-- Module View3D extends Window
-- Generated on 2014-05-31
--
-- @module View3D

---
-- Function View3D()
--
-- @function [parent=#View3D] View3D
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#View3D] new
-- @param self Self reference
-- @return View3D#View3D

---
-- Function delete()
--
-- @function [parent=#View3D] delete
-- @param self Self reference

---
-- Function SetView()
-- Define the scene and camera to use in rendering. The View3D will take ownership of them with shared pointers.
--
-- @function [parent=#View3D] SetView
-- @param self Self reference
-- @param Scene#Scene scene scene
-- @param Camera#Camera camera camera

---
-- Function SetFormat()
-- Set render texture pixel format. Default is RGB.
--
-- @function [parent=#View3D] SetFormat
-- @param self Self reference
-- @param #number format format

---
-- Function SetAutoUpdate()
-- Set render target auto update mode. Default is true.
--
-- @function [parent=#View3D] SetAutoUpdate
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function QueueUpdate()
-- Queue manual update on the render texture.
--
-- @function [parent=#View3D] QueueUpdate
-- @param self Self reference

---
-- Function GetFormat()
-- Return render texture pixel format.
--
-- @function [parent=#View3D] GetFormat
-- @param self Self reference
-- @return #number

---
-- Function GetAutoUpdate()
-- Return whether render target updates automatically.
--
-- @function [parent=#View3D] GetAutoUpdate
-- @param self Self reference
-- @return #boolean

---
-- Function GetScene()
-- Return scene.
--
-- @function [parent=#View3D] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function GetCameraNode()
-- Return camera scene node.
--
-- @function [parent=#View3D] GetCameraNode
-- @param self Self reference
-- @return Node#Node

---
-- Function GetRenderTexture()
-- Return render texture.
--
-- @function [parent=#View3D] GetRenderTexture
-- @param self Self reference
-- @return Texture2D#Texture2D

---
-- Function GetDepthTexture()
-- Return depth stencil texture.
--
-- @function [parent=#View3D] GetDepthTexture
-- @param self Self reference
-- @return Texture2D#Texture2D

---
-- Function GetViewport()
-- Return viewport.
--
-- @function [parent=#View3D] GetViewport
-- @param self Self reference
-- @return Viewport#Viewport

---
-- Field format
--
-- @field [parent=#View3D] #number format

---
-- Field autoUpdate
--
-- @field [parent=#View3D] #boolean autoUpdate


return nil
