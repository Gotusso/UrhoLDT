---
-- Module View3D
-- extends Window
--
-- @module View3D

---
-- Function View3D
--
-- @function [parent=#View3D] View3D

---
-- Function new
--
-- @function [parent=#View3D] new
-- @return View3D#View3D

---
-- Function delete
--
-- @function [parent=#View3D] delete

---
-- Function SetView
--
-- @function [parent=#View3D] SetView
-- @param Scene#Scene scenescene
-- @param Camera#Camera cameracamera

---
-- Function SetFormat
--
-- @function [parent=#View3D] SetFormat
-- @param #number formatformat

---
-- Function SetAutoUpdate
--
-- @function [parent=#View3D] SetAutoUpdate
-- @param #boolean enableenable

---
-- Function QueueUpdate
--
-- @function [parent=#View3D] QueueUpdate

---
-- Function GetFormat
--
-- @function [parent=#View3D] GetFormat
-- @return #number

---
-- Function GetAutoUpdate
--
-- @function [parent=#View3D] GetAutoUpdate
-- @return #boolean

---
-- Function GetScene
--
-- @function [parent=#View3D] GetScene
-- @return Scene#Scene

---
-- Function GetCameraNode
--
-- @function [parent=#View3D] GetCameraNode
-- @return Node#Node

---
-- Function GetRenderTexture
--
-- @function [parent=#View3D] GetRenderTexture
-- @return Texture2D#Texture2D

---
-- Function GetDepthTexture
--
-- @function [parent=#View3D] GetDepthTexture
-- @return Texture2D#Texture2D

---
-- Function GetViewport
--
-- @function [parent=#View3D] GetViewport
-- @return Viewport#Viewport

---
-- Field format
--
-- @field [parent=#View3D] #number format

---
-- Field autoUpdate
--
-- @field [parent=#View3D] #boolean autoUpdate

---
-- Function Window
--
-- @function [parent=#View3D] Window

---
-- Function new
--
-- @function [parent=#View3D] new
-- @return Window#Window

---
-- Function delete
--
-- @function [parent=#View3D] delete

---
-- Function SetMovable
--
-- @function [parent=#View3D] SetMovable
-- @param #boolean enableenable

---
-- Function SetResizable
--
-- @function [parent=#View3D] SetResizable
-- @param #boolean enableenable

---
-- Function SetFixedWidthResizing
--
-- @function [parent=#View3D] SetFixedWidthResizing
-- @param #boolean enableenable

---
-- Function SetFixedHeightResizing
--
-- @function [parent=#View3D] SetFixedHeightResizing
-- @param #boolean enableenable

---
-- Function SetResizeBorder
--
-- @function [parent=#View3D] SetResizeBorder
-- @param IntRect#IntRect rectrect

---
-- Function SetModal
--
-- @function [parent=#View3D] SetModal
-- @param #boolean modalmodal

---
-- Function SetModalShadeColor
--
-- @function [parent=#View3D] SetModalShadeColor
-- @param Color#Color colorcolor

---
-- Function SetModalFrameColor
--
-- @function [parent=#View3D] SetModalFrameColor
-- @param Color#Color colorcolor

---
-- Function SetModalFrameSize
--
-- @function [parent=#View3D] SetModalFrameSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function IsMovable
--
-- @function [parent=#View3D] IsMovable
-- @return #boolean

---
-- Function IsResizable
--
-- @function [parent=#View3D] IsResizable
-- @return #boolean

---
-- Function GetFixedWidthResizing
--
-- @function [parent=#View3D] GetFixedWidthResizing
-- @return #boolean

---
-- Function GetFixedHeightResizing
--
-- @function [parent=#View3D] GetFixedHeightResizing
-- @return #boolean

---
-- Function GetResizeBorder
--
-- @function [parent=#View3D] GetResizeBorder
-- @return const IntRect#const IntRect

---
-- Function IsModal
--
-- @function [parent=#View3D] IsModal
-- @return #boolean

---
-- Function GetModalShadeColor
--
-- @function [parent=#View3D] GetModalShadeColor
-- @return const Color#const Color

---
-- Function GetModalFrameColor
--
-- @function [parent=#View3D] GetModalFrameColor
-- @return const Color#const Color

---
-- Function GetModalFrameSize
--
-- @function [parent=#View3D] GetModalFrameSize
-- @return const IntVector2#const IntVector2

---
-- Field movable
--
-- @field [parent=#View3D] #boolean movable

---
-- Field resizable
--
-- @field [parent=#View3D] #boolean resizable

---
-- Field fixedWidthResizing
--
-- @field [parent=#View3D] #boolean fixedWidthResizing

---
-- Field fixedHeightResizing
--
-- @field [parent=#View3D] #boolean fixedHeightResizing

---
-- Field resizeBorder
--
-- @field [parent=#View3D] IntRect#IntRect resizeBorder

---
-- Field modal
--
-- @field [parent=#View3D] #boolean modal

---
-- Field modalShadeColor
--
-- @field [parent=#View3D] Color#Color modalShadeColor

---
-- Field modalFrameColor
--
-- @field [parent=#View3D] Color#Color modalFrameColor

---
-- Field modalFrameSize
--
-- @field [parent=#View3D] IntVector2#IntVector2 modalFrameSize

---
-- Function BorderImage
--
-- @function [parent=#View3D] BorderImage

---
-- Function new
--
-- @function [parent=#View3D] new
-- @return BorderImage#BorderImage

---
-- Function delete
--
-- @function [parent=#View3D] delete

---
-- Function SetTexture
--
-- @function [parent=#View3D] SetTexture
-- @param Texture#Texture texturetexture

---
-- Function SetImageRect
--
-- @function [parent=#View3D] SetImageRect
-- @param IntRect#IntRect rectrect

---
-- Function SetFullImageRect
--
-- @function [parent=#View3D] SetFullImageRect

---
-- Function SetBorder
--
-- @function [parent=#View3D] SetBorder
-- @param IntRect#IntRect rectrect

---
-- Function SetHoverOffset
--
-- @function [parent=#View3D] SetHoverOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetHoverOffset
--
-- @function [parent=#View3D] SetHoverOffset
-- @param #number xx
-- @param #number yy

---
-- Function SetBlendMode
--
-- @function [parent=#View3D] SetBlendMode
-- @param BlendMode#BlendMode modemode

---
-- Function SetTiled
--
-- @function [parent=#View3D] SetTiled
-- @param #boolean enableenable

---
-- Function GetTexture
--
-- @function [parent=#View3D] GetTexture
-- @return Texture#Texture

---
-- Function GetImageRect
--
-- @function [parent=#View3D] GetImageRect
-- @return const IntRect#const IntRect

---
-- Function GetBorder
--
-- @function [parent=#View3D] GetBorder
-- @return const IntRect#const IntRect

---
-- Function GetHoverOffset
--
-- @function [parent=#View3D] GetHoverOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetBlendMode
--
-- @function [parent=#View3D] GetBlendMode
-- @return BlendMode#BlendMode

---
-- Function IsTiled
--
-- @function [parent=#View3D] IsTiled
-- @return #boolean

---
-- Field texture
--
-- @field [parent=#View3D] Texture#Texture texture

---
-- Field imageRect
--
-- @field [parent=#View3D] IntRect#IntRect imageRect

---
-- Field border
--
-- @field [parent=#View3D] IntRect#IntRect border

---
-- Field hoverOffset
--
-- @field [parent=#View3D] IntVector2#IntVector2 hoverOffset

---
-- Field blendMode
--
-- @field [parent=#View3D] BlendMode#BlendMode blendMode

---
-- Field tiled
--
-- @field [parent=#View3D] #boolean tiled

---
-- Function UIElement
--
-- @function [parent=#View3D] UIElement

---
-- Function new
--
-- @function [parent=#View3D] new
-- @return UIElement#UIElement

---
-- Function delete
--
-- @function [parent=#View3D] delete

---
-- Function GetScreenPosition
--
-- @function [parent=#View3D] GetScreenPosition
-- @return const IntVector2#const IntVector2

---
-- Function LoadXML
--
-- @function [parent=#View3D] LoadXML
-- @param Deserializer#Deserializer sourcesource
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#View3D] SaveXML
-- @param Serializer#Serializer destdest
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#View3D] LoadXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#View3D] SaveXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function FilterAttributes
--
-- @function [parent=#View3D] FilterAttributes
-- @param XMLElement#XMLElement destdest
-- @return #boolean

---
-- Function SetName
--
-- @function [parent=#View3D] SetName
-- @param #string namename

---
-- Function SetPosition
--
-- @function [parent=#View3D] SetPosition
-- @param IntVector2#IntVector2 positionposition

---
-- Function SetPosition
--
-- @function [parent=#View3D] SetPosition
-- @param #number xx
-- @param #number yy

---
-- Function SetSize
--
-- @function [parent=#View3D] SetSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function SetSize
--
-- @function [parent=#View3D] SetSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetWidth
--
-- @function [parent=#View3D] SetWidth
-- @param #number widthwidth

---
-- Function SetHeight
--
-- @function [parent=#View3D] SetHeight
-- @param #number heightheight

---
-- Function SetMinSize
--
-- @function [parent=#View3D] SetMinSize
-- @param IntVector2#IntVector2 minSizeminSize

---
-- Function SetMinSize
--
-- @function [parent=#View3D] SetMinSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetMinWidth
--
-- @function [parent=#View3D] SetMinWidth
-- @param #number widthwidth

---
-- Function SetMinHeight
--
-- @function [parent=#View3D] SetMinHeight
-- @param #number heightheight

---
-- Function SetMaxSize
--
-- @function [parent=#View3D] SetMaxSize
-- @param IntVector2#IntVector2 maxSizemaxSize

---
-- Function SetMaxSize
--
-- @function [parent=#View3D] SetMaxSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetMaxWidth
--
-- @function [parent=#View3D] SetMaxWidth
-- @param #number widthwidth

---
-- Function SetMaxHeight
--
-- @function [parent=#View3D] SetMaxHeight
-- @param #number heightheight

---
-- Function SetFixedSize
--
-- @function [parent=#View3D] SetFixedSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function SetFixedSize
--
-- @function [parent=#View3D] SetFixedSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetFixedWidth
--
-- @function [parent=#View3D] SetFixedWidth
-- @param #number widthwidth

---
-- Function SetFixedHeight
--
-- @function [parent=#View3D] SetFixedHeight
-- @param #number heightheight

---
-- Function SetAlignment
--
-- @function [parent=#View3D] SetAlignment
-- @param HorizontalAlignment#HorizontalAlignment hAlignhAlign
-- @param VerticalAlignment#VerticalAlignment vAlignvAlign

---
-- Function SetHorizontalAlignment
--
-- @function [parent=#View3D] SetHorizontalAlignment
-- @param HorizontalAlignment#HorizontalAlignment alignalign

---
-- Function SetVerticalAlignment
--
-- @function [parent=#View3D] SetVerticalAlignment
-- @param VerticalAlignment#VerticalAlignment alignalign

---
-- Function SetClipBorder
--
-- @function [parent=#View3D] SetClipBorder
-- @param IntRect#IntRect rectrect

---
-- Function SetColor
--
-- @function [parent=#View3D] SetColor
-- @param Color#Color colorcolor

---
-- Function SetColor
--
-- @function [parent=#View3D] SetColor
-- @param Corner#Corner cornercorner
-- @param Color#Color colorcolor

---
-- Function SetPriority
--
-- @function [parent=#View3D] SetPriority
-- @param #number prioritypriority

---
-- Function SetOpacity
--
-- @function [parent=#View3D] SetOpacity
-- @param #number opacityopacity

---
-- Function SetBringToFront
--
-- @function [parent=#View3D] SetBringToFront
-- @param #boolean enableenable

---
-- Function SetBringToBack
--
-- @function [parent=#View3D] SetBringToBack
-- @param #boolean enableenable

---
-- Function SetClipChildren
--
-- @function [parent=#View3D] SetClipChildren
-- @param #boolean enableenable

---
-- Function SetSortChildren
--
-- @function [parent=#View3D] SetSortChildren
-- @param #boolean enableenable

---
-- Function SetUseDerivedOpacity
--
-- @function [parent=#View3D] SetUseDerivedOpacity
-- @param #boolean enableenable

---
-- Function SetEnabled
--
-- @function [parent=#View3D] SetEnabled
-- @param #boolean enableenable

---
-- Function SetEditable
--
-- @function [parent=#View3D] SetEditable
-- @param #boolean enableenable

---
-- Function SetFocus
--
-- @function [parent=#View3D] SetFocus
-- @param #boolean enableenable

---
-- Function SetSelected
--
-- @function [parent=#View3D] SetSelected
-- @param #boolean enableenable

---
-- Function SetVisible
--
-- @function [parent=#View3D] SetVisible
-- @param #boolean enableenable

---
-- Function SetFocusMode
--
-- @function [parent=#View3D] SetFocusMode
-- @param FocusMode#FocusMode modemode

---
-- Function SetDragDropMode
--
-- @function [parent=#View3D] SetDragDropMode
-- @param #number modemode

---
-- Function SetStyle
--
-- @function [parent=#View3D] SetStyle
-- @param #string styleNamestyleName
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetStyle
--
-- @function [parent=#View3D] SetStyle
-- @param XMLElement#XMLElement elementelement
-- @return #boolean

---
-- Function SetStyleAuto
--
-- @function [parent=#View3D] SetStyleAuto
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetDefaultStyle
--
-- @function [parent=#View3D] SetDefaultStyle
-- @param XMLFile#XMLFile stylestyle

---
-- Function SetLayout
--
-- @function [parent=#View3D] SetLayout
-- @param LayoutMode#LayoutMode modemode
-- @param #number spacingspacing

---
-- Function SetLayout
--
-- @function [parent=#View3D] SetLayout
-- @param LayoutMode#LayoutMode modemode
-- @param #number spacingspacing
-- @param IntRect#IntRect borderborder

---
-- Function SetLayoutMode
--
-- @function [parent=#View3D] SetLayoutMode
-- @param LayoutMode#LayoutMode modemode

---
-- Function SetLayoutSpacing
--
-- @function [parent=#View3D] SetLayoutSpacing
-- @param #number spacingspacing

---
-- Function SetLayoutBorder
--
-- @function [parent=#View3D] SetLayoutBorder
-- @param IntRect#IntRect borderborder

---
-- Function SetIndent
--
-- @function [parent=#View3D] SetIndent
-- @param #number indentindent

---
-- Function SetIndentSpacing
--
-- @function [parent=#View3D] SetIndentSpacing
-- @param #number indentSpacingindentSpacing

---
-- Function UpdateLayout
--
-- @function [parent=#View3D] UpdateLayout

---
-- Function DisableLayoutUpdate
--
-- @function [parent=#View3D] DisableLayoutUpdate

---
-- Function EnableLayoutUpdate
--
-- @function [parent=#View3D] EnableLayoutUpdate

---
-- Function BringToFront
--
-- @function [parent=#View3D] BringToFront

---
-- Function CreateChild
--
-- @function [parent=#View3D] CreateChild
-- @param #string typetype
-- @param #string namename
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function AddChild
--
-- @function [parent=#View3D] AddChild
-- @param UIElement#UIElement elementelement

---
-- Function InsertChild
--
-- @function [parent=#View3D] InsertChild
-- @param #number indexindex
-- @param UIElement#UIElement elementelement

---
-- Function RemoveChild
--
-- @function [parent=#View3D] RemoveChild
-- @param UIElement#UIElement elementelement
-- @param #number indexindex

---
-- Function RemoveChildAtIndex
--
-- @function [parent=#View3D] RemoveChildAtIndex
-- @param #number indexindex

---
-- Function RemoveAllChildren
--
-- @function [parent=#View3D] RemoveAllChildren

---
-- Function Remove
--
-- @function [parent=#View3D] Remove

---
-- Function FindChild
--
-- @function [parent=#View3D] FindChild
-- @param UIElement#UIElement elementelement
-- @return #number

---
-- Function SetParent
--
-- @function [parent=#View3D] SetParent
-- @param UIElement#UIElement parentparent
-- @param #number indexindex

---
-- Function SetVar
--
-- @function [parent=#View3D] SetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @param Variant#Variant valuevalue

---
-- Function SetInternal
--
-- @function [parent=#View3D] SetInternal
-- @param #boolean enableenable

---
-- Function SetTraversalMode
--
-- @function [parent=#View3D] SetTraversalMode
-- @param TraversalMode#TraversalMode traversalModetraversalMode

---
-- Function SetElementEventSender
--
-- @function [parent=#View3D] SetElementEventSender
-- @param #boolean flagflag

---
-- Function GetName
--
-- @function [parent=#View3D] GetName
-- @return const String#const String

---
-- Function GetPosition
--
-- @function [parent=#View3D] GetPosition
-- @return const IntVector2#const IntVector2

---
-- Function GetSize
--
-- @function [parent=#View3D] GetSize
-- @return const IntVector2#const IntVector2

---
-- Function GetWidth
--
-- @function [parent=#View3D] GetWidth
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#View3D] GetHeight
-- @return #number

---
-- Function GetMinSize
--
-- @function [parent=#View3D] GetMinSize
-- @return const IntVector2#const IntVector2

---
-- Function GetMinWidth
--
-- @function [parent=#View3D] GetMinWidth
-- @return #number

---
-- Function GetMinHeight
--
-- @function [parent=#View3D] GetMinHeight
-- @return #number

---
-- Function GetMaxSize
--
-- @function [parent=#View3D] GetMaxSize
-- @return const IntVector2#const IntVector2

---
-- Function GetMaxWidth
--
-- @function [parent=#View3D] GetMaxWidth
-- @return #number

---
-- Function GetMaxHeight
--
-- @function [parent=#View3D] GetMaxHeight
-- @return #number

---
-- Function IsFixedSize
--
-- @function [parent=#View3D] IsFixedSize
-- @return #boolean

---
-- Function IsFixedWidth
--
-- @function [parent=#View3D] IsFixedWidth
-- @return #boolean

---
-- Function IsFixedHeight
--
-- @function [parent=#View3D] IsFixedHeight
-- @return #boolean

---
-- Function GetChildOffset
--
-- @function [parent=#View3D] GetChildOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetHorizontalAlignment
--
-- @function [parent=#View3D] GetHorizontalAlignment
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetVerticalAlignment
--
-- @function [parent=#View3D] GetVerticalAlignment
-- @return VerticalAlignment#VerticalAlignment

---
-- Function GetClipBorder
--
-- @function [parent=#View3D] GetClipBorder
-- @return const IntRect#const IntRect

---
-- Function GetColor
--
-- @function [parent=#View3D] GetColor
-- @param Corner#Corner cornercorner
-- @return const Color#const Color

---
-- Function GetPriority
--
-- @function [parent=#View3D] GetPriority
-- @return #number

---
-- Function GetOpacity
--
-- @function [parent=#View3D] GetOpacity
-- @return #number

---
-- Function GetDerivedOpacity
--
-- @function [parent=#View3D] GetDerivedOpacity
-- @return #number

---
-- Function GetBringToFront
--
-- @function [parent=#View3D] GetBringToFront
-- @return #boolean

---
-- Function GetBringToBack
--
-- @function [parent=#View3D] GetBringToBack
-- @return #boolean

---
-- Function GetClipChildren
--
-- @function [parent=#View3D] GetClipChildren
-- @return #boolean

---
-- Function GetSortChildren
--
-- @function [parent=#View3D] GetSortChildren
-- @return #boolean

---
-- Function GetUseDerivedOpacity
--
-- @function [parent=#View3D] GetUseDerivedOpacity
-- @return #boolean

---
-- Function HasFocus
--
-- @function [parent=#View3D] HasFocus
-- @return #boolean

---
-- Function IsEnabled
--
-- @function [parent=#View3D] IsEnabled
-- @return #boolean

---
-- Function IsEditable
--
-- @function [parent=#View3D] IsEditable
-- @return #boolean

---
-- Function IsSelected
--
-- @function [parent=#View3D] IsSelected
-- @return #boolean

---
-- Function IsVisible
--
-- @function [parent=#View3D] IsVisible
-- @return #boolean

---
-- Function IsHovering
--
-- @function [parent=#View3D] IsHovering
-- @return #boolean

---
-- Function IsInternal
--
-- @function [parent=#View3D] IsInternal
-- @return #boolean

---
-- Function HasColorGradient
--
-- @function [parent=#View3D] HasColorGradient
-- @return #boolean

---
-- Function GetFocusMode
--
-- @function [parent=#View3D] GetFocusMode
-- @return FocusMode#FocusMode

---
-- Function GetDragDropMode
--
-- @function [parent=#View3D] GetDragDropMode
-- @return #number

---
-- Function GetAppliedStyle
--
-- @function [parent=#View3D] GetAppliedStyle
-- @return const String#const String

---
-- Function GetDefaultStyle
--
-- @function [parent=#View3D] GetDefaultStyle
-- @param #boolean recursiveUprecursiveUp
-- @return XMLFile#XMLFile

---
-- Function GetLayoutMode
--
-- @function [parent=#View3D] GetLayoutMode
-- @return LayoutMode#LayoutMode

---
-- Function GetLayoutSpacing
--
-- @function [parent=#View3D] GetLayoutSpacing
-- @return #number

---
-- Function GetLayoutBorder
--
-- @function [parent=#View3D] GetLayoutBorder
-- @return const IntRect#const IntRect

---
-- Function GetNumChildren
--
-- @function [parent=#View3D] GetNumChildren
-- @param #boolean recursiverecursive
-- @return #number

---
-- Function GetChild
--
-- @function [parent=#View3D] GetChild
-- @param #string namename
-- @param #boolean recursiverecursive
-- @return UIElement#UIElement

---
-- Function GetChild
--
-- @function [parent=#View3D] GetChild
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function GetParent
--
-- @function [parent=#View3D] GetParent
-- @return UIElement#UIElement

---
-- Function GetRoot
--
-- @function [parent=#View3D] GetRoot
-- @return UIElement#UIElement

---
-- Function GetDerivedColor
--
-- @function [parent=#View3D] GetDerivedColor
-- @return const Color#const Color

---
-- Function GetVar
--
-- @function [parent=#View3D] GetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @return const Variant#const Variant

---
-- Function GetVars
--
-- @function [parent=#View3D] GetVars
-- @return const VariantMap#const VariantMap

---
-- Function ScreenToElement
--
-- @function [parent=#View3D] ScreenToElement
-- @param IntVector2#IntVector2 screenPositionscreenPosition
-- @return IntVector2#IntVector2

---
-- Function ElementToScreen
--
-- @function [parent=#View3D] ElementToScreen
-- @param IntVector2#IntVector2 positionposition
-- @return IntVector2#IntVector2

---
-- Function IsInside
--
-- @function [parent=#View3D] IsInside
-- @param IntVector2#IntVector2 positionposition
-- @param #boolean isScreenisScreen
-- @return #boolean

---
-- Function IsInsideCombined
--
-- @function [parent=#View3D] IsInsideCombined
-- @param IntVector2#IntVector2 positionposition
-- @param #boolean isScreenisScreen
-- @return #boolean

---
-- Function GetCombinedScreenRect
--
-- @function [parent=#View3D] GetCombinedScreenRect
-- @return IntRect#IntRect

---
-- Function SortChildren
--
-- @function [parent=#View3D] SortChildren

---
-- Function GetLayoutMinSize
--
-- @function [parent=#View3D] GetLayoutMinSize
-- @return #number

---
-- Function GetIndent
--
-- @function [parent=#View3D] GetIndent
-- @return #number

---
-- Function GetIndentSpacing
--
-- @function [parent=#View3D] GetIndentSpacing
-- @return #number

---
-- Function GetIndentWidth
--
-- @function [parent=#View3D] GetIndentWidth
-- @return #number

---
-- Function SetChildOffset
--
-- @function [parent=#View3D] SetChildOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetHovering
--
-- @function [parent=#View3D] SetHovering
-- @param #boolean enableenable

---
-- Function GetColor
--
-- @function [parent=#View3D] GetColor
-- @return const Color#const Color

---
-- Function GetTraversalMode
--
-- @function [parent=#View3D] GetTraversalMode
-- @return TraversalMode#TraversalMode

---
-- Function IsElementEventSender
--
-- @function [parent=#View3D] IsElementEventSender
-- @return #boolean

---
-- Function GetElementEventSender
--
-- @function [parent=#View3D] GetElementEventSender
-- @return UIElement#UIElement

---
-- Field screenPosition (Read only)
--
-- @field [parent=#View3D] IntVector2#IntVector2 screenPosition

---
-- Field name
--
-- @field [parent=#View3D] #string name

---
-- Field position
--
-- @field [parent=#View3D] IntVector2#IntVector2 position

---
-- Field size
--
-- @field [parent=#View3D] IntVector2#IntVector2 size

---
-- Field width
--
-- @field [parent=#View3D] #number width

---
-- Field height
--
-- @field [parent=#View3D] #number height

---
-- Field minSize
--
-- @field [parent=#View3D] IntVector2#IntVector2 minSize

---
-- Field minWidth
--
-- @field [parent=#View3D] #number minWidth

---
-- Field minHeight
--
-- @field [parent=#View3D] #number minHeight

---
-- Field maxSize
--
-- @field [parent=#View3D] IntVector2#IntVector2 maxSize

---
-- Field maxWidth
--
-- @field [parent=#View3D] #number maxWidth

---
-- Field maxHeight
--
-- @field [parent=#View3D] #number maxHeight

---
-- Field fixedSize (Read only)
--
-- @field [parent=#View3D] #boolean fixedSize

---
-- Field fixedWidth (Read only)
--
-- @field [parent=#View3D] #boolean fixedWidth

---
-- Field fixedHeight (Read only)
--
-- @field [parent=#View3D] #boolean fixedHeight

---
-- Field childOffset
--
-- @field [parent=#View3D] IntVector2#IntVector2 childOffset

---
-- Field horizontalAlignment
--
-- @field [parent=#View3D] HorizontalAlignment#HorizontalAlignment horizontalAlignment

---
-- Field verticalAlignment
--
-- @field [parent=#View3D] VerticalAlignment#VerticalAlignment verticalAlignment

---
-- Field clipBorder
--
-- @field [parent=#View3D] IntRect#IntRect clipBorder

---
-- Field color
--
-- @field [parent=#View3D] Color#Color color

---
-- Field priority
--
-- @field [parent=#View3D] #number priority

---
-- Field opacity
--
-- @field [parent=#View3D] #number opacity

---
-- Field derivedOpacity (Read only)
--
-- @field [parent=#View3D] #number derivedOpacity

---
-- Field bringToFront
--
-- @field [parent=#View3D] #boolean bringToFront

---
-- Field bringToBack
--
-- @field [parent=#View3D] #boolean bringToBack

---
-- Field clipChildren
--
-- @field [parent=#View3D] #boolean clipChildren

---
-- Field sortChildren
--
-- @field [parent=#View3D] #boolean sortChildren

---
-- Field useDerivedOpacity
--
-- @field [parent=#View3D] #boolean useDerivedOpacity

---
-- Field focus
--
-- @field [parent=#View3D] #boolean focus

---
-- Field enabled
--
-- @field [parent=#View3D] #boolean enabled

---
-- Field editable
--
-- @field [parent=#View3D] #boolean editable

---
-- Field selected
--
-- @field [parent=#View3D] #boolean selected

---
-- Field visible
--
-- @field [parent=#View3D] #boolean visible

---
-- Field hovering
--
-- @field [parent=#View3D] #boolean hovering

---
-- Field internal
--
-- @field [parent=#View3D] #boolean internal

---
-- Field colorGradient (Read only)
--
-- @field [parent=#View3D] #boolean colorGradient

---
-- Field focusMode
--
-- @field [parent=#View3D] FocusMode#FocusMode focusMode

---
-- Field dragDropMode
--
-- @field [parent=#View3D] #number dragDropMode

---
-- Field style
--
-- @field [parent=#View3D] #string style

---
-- Field defaultStyle
--
-- @field [parent=#View3D] XMLFile#XMLFile defaultStyle

---
-- Field layoutMode
--
-- @field [parent=#View3D] LayoutMode#LayoutMode layoutMode

---
-- Field layoutSpacing
--
-- @field [parent=#View3D] #number layoutSpacing

---
-- Field layoutBorder
--
-- @field [parent=#View3D] IntRect#IntRect layoutBorder

---
-- Field numChildren (Read only)
--
-- @field [parent=#View3D] #number numChildren

---
-- Field parent
--
-- @field [parent=#View3D] UIElement#UIElement parent

---
-- Field root (Read only)
--
-- @field [parent=#View3D] UIElement#UIElement root

---
-- Field derivedColor (Read only)
--
-- @field [parent=#View3D] Color#Color derivedColor

---
-- Field combinedScreenRect (Read only)
--
-- @field [parent=#View3D] IntRect#IntRect combinedScreenRect

---
-- Field layoutMinSize (Read only)
--
-- @field [parent=#View3D] #number layoutMinSize

---
-- Field indent
--
-- @field [parent=#View3D] #number indent

---
-- Field indentSpacing
--
-- @field [parent=#View3D] #number indentSpacing

---
-- Field indentWidth (Read only)
--
-- @field [parent=#View3D] #number indentWidth

---
-- Field traversalMode
--
-- @field [parent=#View3D] TraversalMode#TraversalMode traversalMode

---
-- Field elementEventSender
--
-- @field [parent=#View3D] #boolean elementEventSender

---
-- Function SetTemporary
--
-- @function [parent=#View3D] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#View3D] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#View3D] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#View3D] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#View3D] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#View3D] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#View3D] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#View3D] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#View3D] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#View3D] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#View3D] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#View3D] #string category


return nil
