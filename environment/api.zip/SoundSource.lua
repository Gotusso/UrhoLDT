---
-- Module SoundSource
-- Module SoundSource extends Component
-- Generated on 2014-05-31
--
-- @module SoundSource

---
-- Function Play()
-- Play a sound.
--
-- @function [parent=#SoundSource] Play
-- @param self Self reference
-- @param Sound#Sound sound sound

---
-- Function Play()
-- Play a sound with specified frequency.
--
-- @function [parent=#SoundSource] Play
-- @param self Self reference
-- @param Sound#Sound sound sound
-- @param #number frequency frequency

---
-- Function Play()
-- Play a sound with specified frequency and gain.
--
-- @function [parent=#SoundSource] Play
-- @param self Self reference
-- @param Sound#Sound sound sound
-- @param #number frequency frequency
-- @param #number gain gain

---
-- Function Play()
-- Play a sound with specified frequency, gain and panning.
--
-- @function [parent=#SoundSource] Play
-- @param self Self reference
-- @param Sound#Sound sound sound
-- @param #number frequency frequency
-- @param #number gain gain
-- @param #number panning panning

---
-- Function Stop()
-- Stop playback.
--
-- @function [parent=#SoundSource] Stop
-- @param self Self reference

---
-- Function SetSoundType()
-- Set sound type, determines the master gain group.
--
-- @function [parent=#SoundSource] SetSoundType
-- @param self Self reference
-- @param SoundType#SoundType type type

---
-- Function SetFrequency()
-- Set frequency.
--
-- @function [parent=#SoundSource] SetFrequency
-- @param self Self reference
-- @param #number frequency frequency

---
-- Function SetGain()
-- Set gain. 0.0 is silence, 1.0 is full volume.
--
-- @function [parent=#SoundSource] SetGain
-- @param self Self reference
-- @param #number gain gain

---
-- Function SetAttenuation()
-- Set attenuation. 1.0 is unaltered. Used for distance attenuated playback.
--
-- @function [parent=#SoundSource] SetAttenuation
-- @param self Self reference
-- @param #number attenuation attenuation

---
-- Function SetPanning()
-- Set stereo panning. -1.0 is full left and 1.0 is full right.
--
-- @function [parent=#SoundSource] SetPanning
-- @param self Self reference
-- @param #number panning panning

---
-- Function SetAutoRemove()
-- Set whether sound source will be automatically removed from the scene node when playback stops.
--
-- @function [parent=#SoundSource] SetAutoRemove
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function GetSound()
-- Return sound.
--
-- @function [parent=#SoundSource] GetSound
-- @param self Self reference
-- @return Sound#Sound

---
-- Function GetSoundType()
-- Return sound type, determines the master gain group.
--
-- @function [parent=#SoundSource] GetSoundType
-- @param self Self reference
-- @return SoundType#SoundType

---
-- Function GetTimePosition()
-- Return playback time position.
--
-- @function [parent=#SoundSource] GetTimePosition
-- @param self Self reference
-- @return #number

---
-- Function GetFrequency()
-- Return frequency.
--
-- @function [parent=#SoundSource] GetFrequency
-- @param self Self reference
-- @return #number

---
-- Function GetGain()
-- Return gain.
--
-- @function [parent=#SoundSource] GetGain
-- @param self Self reference
-- @return #number

---
-- Function GetAttenuation()
-- Return attenuation.
--
-- @function [parent=#SoundSource] GetAttenuation
-- @param self Self reference
-- @return #number

---
-- Function GetPanning()
-- Return stereo panning.
--
-- @function [parent=#SoundSource] GetPanning
-- @param self Self reference
-- @return #number

---
-- Function GetAutoRemove()
-- Return autoremove mode.
--
-- @function [parent=#SoundSource] GetAutoRemove
-- @param self Self reference
-- @return #boolean

---
-- Function IsPlaying()
-- Return whether is playing.
--
-- @function [parent=#SoundSource] IsPlaying
-- @param self Self reference
-- @return #boolean

---
-- Field sound (Read only)
--
-- @field [parent=#SoundSource] Sound#Sound sound

---
-- Field soundType
--
-- @field [parent=#SoundSource] SoundType#SoundType soundType

---
-- Field timePosition (Read only)
--
-- @field [parent=#SoundSource] #number timePosition

---
-- Field frequency
--
-- @field [parent=#SoundSource] #number frequency

---
-- Field gain
--
-- @field [parent=#SoundSource] #number gain

---
-- Field attenuation
--
-- @field [parent=#SoundSource] #number attenuation

---
-- Field panning
--
-- @field [parent=#SoundSource] #number panning

---
-- Field autoRemove
--
-- @field [parent=#SoundSource] #boolean autoRemove

---
-- Field playing (Read only)
--
-- @field [parent=#SoundSource] #boolean playing


return nil
