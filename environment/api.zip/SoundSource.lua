---
-- Module SoundSource
-- Module SoundSource extends Component
-- Generated on 2014-03-13
--
-- @module SoundSource

---
-- Function Play
--
-- @function [parent=#SoundSource] Play
-- @param self Self reference
-- @param Sound#Sound sound sound

---
-- Function Play
--
-- @function [parent=#SoundSource] Play
-- @param self Self reference
-- @param Sound#Sound sound sound
-- @param #number frequency frequency

---
-- Function Play
--
-- @function [parent=#SoundSource] Play
-- @param self Self reference
-- @param Sound#Sound sound sound
-- @param #number frequency frequency
-- @param #number gain gain

---
-- Function Play
--
-- @function [parent=#SoundSource] Play
-- @param self Self reference
-- @param Sound#Sound sound sound
-- @param #number frequency frequency
-- @param #number gain gain
-- @param #number panning panning

---
-- Function Stop
--
-- @function [parent=#SoundSource] Stop
-- @param self Self reference

---
-- Function SetSoundType
--
-- @function [parent=#SoundSource] SetSoundType
-- @param self Self reference
-- @param SoundType#SoundType type type

---
-- Function SetFrequency
--
-- @function [parent=#SoundSource] SetFrequency
-- @param self Self reference
-- @param #number frequency frequency

---
-- Function SetGain
--
-- @function [parent=#SoundSource] SetGain
-- @param self Self reference
-- @param #number gain gain

---
-- Function SetAttenuation
--
-- @function [parent=#SoundSource] SetAttenuation
-- @param self Self reference
-- @param #number attenuation attenuation

---
-- Function SetPanning
--
-- @function [parent=#SoundSource] SetPanning
-- @param self Self reference
-- @param #number panning panning

---
-- Function SetAutoRemove
--
-- @function [parent=#SoundSource] SetAutoRemove
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function GetSound
--
-- @function [parent=#SoundSource] GetSound
-- @param self Self reference
-- @return Sound#Sound

---
-- Function GetSoundType
--
-- @function [parent=#SoundSource] GetSoundType
-- @param self Self reference
-- @return SoundType#SoundType

---
-- Function GetTimePosition
--
-- @function [parent=#SoundSource] GetTimePosition
-- @param self Self reference
-- @return #number

---
-- Function GetFrequency
--
-- @function [parent=#SoundSource] GetFrequency
-- @param self Self reference
-- @return #number

---
-- Function GetGain
--
-- @function [parent=#SoundSource] GetGain
-- @param self Self reference
-- @return #number

---
-- Function GetAttenuation
--
-- @function [parent=#SoundSource] GetAttenuation
-- @param self Self reference
-- @return #number

---
-- Function GetPanning
--
-- @function [parent=#SoundSource] GetPanning
-- @param self Self reference
-- @return #number

---
-- Function GetAutoRemove
--
-- @function [parent=#SoundSource] GetAutoRemove
-- @param self Self reference
-- @return #boolean

---
-- Function IsPlaying
--
-- @function [parent=#SoundSource] IsPlaying
-- @param self Self reference
-- @return #boolean

---
-- Function PlayLockless
--
-- @function [parent=#SoundSource] PlayLockless
-- @param self Self reference
-- @param Sound#Sound sound sound

---
-- Function StopLockless
--
-- @function [parent=#SoundSource] StopLockless
-- @param self Self reference

---
-- Field sound (Read only)
--
-- @field [parent=#SoundSource] Sound#Sound sound

---
-- Field soundType
--
-- @field [parent=#SoundSource] SoundType#SoundType soundType

---
-- Field timePosition (Read only)
--
-- @field [parent=#SoundSource] #number timePosition

---
-- Field frequency
--
-- @field [parent=#SoundSource] #number frequency

---
-- Field gain
--
-- @field [parent=#SoundSource] #number gain

---
-- Field attenuation
--
-- @field [parent=#SoundSource] #number attenuation

---
-- Field panning
--
-- @field [parent=#SoundSource] #number panning

---
-- Field autoRemove
--
-- @field [parent=#SoundSource] #boolean autoRemove

---
-- Field playing (Read only)
--
-- @field [parent=#SoundSource] #boolean playing

---
-- Function SetEnabled
--
-- @function [parent=#SoundSource] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Remove
--
-- @function [parent=#SoundSource] Remove
-- @param self Self reference

---
-- Function GetID
--
-- @function [parent=#SoundSource] GetID
-- @param self Self reference
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#SoundSource] GetNode
-- @param self Self reference
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#SoundSource] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#SoundSource] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#SoundSource] IsEnabledEffective
-- @param self Self reference
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#SoundSource] GetComponent
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#SoundSource] GetComponent
-- @param self Self reference
-- @param #string type type
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#SoundSource] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#SoundSource] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#SoundSource] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#SoundSource] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#SoundSource] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#SoundSource] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#SoundSource] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#SoundSource] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#SoundSource] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#SoundSource] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#SoundSource] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#SoundSource] #string category


return nil
