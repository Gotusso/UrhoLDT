---
-- Module SoundSource
-- extends Component
--
-- @module SoundSource

---
-- Function Play
--
-- @function [parent=#SoundSource] Play
-- @param Sound#Sound soundsound

---
-- Function Play
--
-- @function [parent=#SoundSource] Play
-- @param Sound#Sound soundsound
-- @param #number frequencyfrequency

---
-- Function Play
--
-- @function [parent=#SoundSource] Play
-- @param Sound#Sound soundsound
-- @param #number frequencyfrequency
-- @param #number gaingain

---
-- Function Play
--
-- @function [parent=#SoundSource] Play
-- @param Sound#Sound soundsound
-- @param #number frequencyfrequency
-- @param #number gaingain
-- @param #number panningpanning

---
-- Function Stop
--
-- @function [parent=#SoundSource] Stop

---
-- Function SetSoundType
--
-- @function [parent=#SoundSource] SetSoundType
-- @param SoundType#SoundType typetype

---
-- Function SetFrequency
--
-- @function [parent=#SoundSource] SetFrequency
-- @param #number frequencyfrequency

---
-- Function SetGain
--
-- @function [parent=#SoundSource] SetGain
-- @param #number gaingain

---
-- Function SetAttenuation
--
-- @function [parent=#SoundSource] SetAttenuation
-- @param #number attenuationattenuation

---
-- Function SetPanning
--
-- @function [parent=#SoundSource] SetPanning
-- @param #number panningpanning

---
-- Function SetAutoRemove
--
-- @function [parent=#SoundSource] SetAutoRemove
-- @param #boolean enableenable

---
-- Function GetSound
--
-- @function [parent=#SoundSource] GetSound
-- @return Sound#Sound

---
-- Function GetSoundType
--
-- @function [parent=#SoundSource] GetSoundType
-- @return SoundType#SoundType

---
-- Function GetTimePosition
--
-- @function [parent=#SoundSource] GetTimePosition
-- @return #number

---
-- Function GetFrequency
--
-- @function [parent=#SoundSource] GetFrequency
-- @return #number

---
-- Function GetGain
--
-- @function [parent=#SoundSource] GetGain
-- @return #number

---
-- Function GetAttenuation
--
-- @function [parent=#SoundSource] GetAttenuation
-- @return #number

---
-- Function GetPanning
--
-- @function [parent=#SoundSource] GetPanning
-- @return #number

---
-- Function GetAutoRemove
--
-- @function [parent=#SoundSource] GetAutoRemove
-- @return #boolean

---
-- Function IsPlaying
--
-- @function [parent=#SoundSource] IsPlaying
-- @return #boolean

---
-- Function PlayLockless
--
-- @function [parent=#SoundSource] PlayLockless
-- @param Sound#Sound soundsound

---
-- Function StopLockless
--
-- @function [parent=#SoundSource] StopLockless

---
-- Field sound (Read only)
--
-- @field [parent=#SoundSource] Sound#Sound sound

---
-- Field soundType
--
-- @field [parent=#SoundSource] SoundType#SoundType soundType

---
-- Field timePosition (Read only)
--
-- @field [parent=#SoundSource] #number timePosition

---
-- Field frequency
--
-- @field [parent=#SoundSource] #number frequency

---
-- Field gain
--
-- @field [parent=#SoundSource] #number gain

---
-- Field attenuation
--
-- @field [parent=#SoundSource] #number attenuation

---
-- Field panning
--
-- @field [parent=#SoundSource] #number panning

---
-- Field autoRemove
--
-- @field [parent=#SoundSource] #boolean autoRemove

---
-- Field playing (Read only)
--
-- @field [parent=#SoundSource] #boolean playing

---
-- Function SetEnabled
--
-- @function [parent=#SoundSource] SetEnabled
-- @param #boolean enableenable

---
-- Function Remove
--
-- @function [parent=#SoundSource] Remove

---
-- Function GetID
--
-- @function [parent=#SoundSource] GetID
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#SoundSource] GetNode
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#SoundSource] GetScene
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#SoundSource] IsEnabled
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#SoundSource] IsEnabledEffective
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#SoundSource] GetComponent
-- @param ShortStringHash#ShortStringHash typetype
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#SoundSource] GetComponent
-- @param #string typetype
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#SoundSource] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#SoundSource] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#SoundSource] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#SoundSource] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#SoundSource] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#SoundSource] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#SoundSource] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#SoundSource] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#SoundSource] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#SoundSource] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#SoundSource] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#SoundSource] #string category


return nil
