---
-- Module SoundSource
-- Extends Component
--
-- @module SoundSource

---
-- Function Play
--
-- @function [parent=#SoundSource] Play
-- @param Sound#Sound soundsound

---
-- Function Play
--
-- @function [parent=#SoundSource] Play
-- @param Sound#Sound soundsound
-- @param #number frequencyfrequency

---
-- Function Play
--
-- @function [parent=#SoundSource] Play
-- @param Sound#Sound soundsound
-- @param #number frequencyfrequency
-- @param #number gaingain

---
-- Function Play
--
-- @function [parent=#SoundSource] Play
-- @param Sound#Sound soundsound
-- @param #number frequencyfrequency
-- @param #number gaingain
-- @param #number panningpanning

---
-- Function Stop
--
-- @function [parent=#SoundSource] Stop

---
-- Function SetSoundType
--
-- @function [parent=#SoundSource] SetSoundType
-- @param SoundType#SoundType typetype

---
-- Function SetFrequency
--
-- @function [parent=#SoundSource] SetFrequency
-- @param #number frequencyfrequency

---
-- Function SetGain
--
-- @function [parent=#SoundSource] SetGain
-- @param #number gaingain

---
-- Function SetAttenuation
--
-- @function [parent=#SoundSource] SetAttenuation
-- @param #number attenuationattenuation

---
-- Function SetPanning
--
-- @function [parent=#SoundSource] SetPanning
-- @param #number panningpanning

---
-- Function SetAutoRemove
--
-- @function [parent=#SoundSource] SetAutoRemove
-- @param #boolean enableenable

---
-- Function GetSound
--
-- @function [parent=#SoundSource] GetSound
-- @return Sound#Sound

---
-- Function GetSoundType
--
-- @function [parent=#SoundSource] GetSoundType
-- @return SoundType#SoundType

---
-- Function GetTimePosition
--
-- @function [parent=#SoundSource] GetTimePosition
-- @return #number

---
-- Function GetFrequency
--
-- @function [parent=#SoundSource] GetFrequency
-- @return #number

---
-- Function GetGain
--
-- @function [parent=#SoundSource] GetGain
-- @return #number

---
-- Function GetAttenuation
--
-- @function [parent=#SoundSource] GetAttenuation
-- @return #number

---
-- Function GetPanning
--
-- @function [parent=#SoundSource] GetPanning
-- @return #number

---
-- Function GetAutoRemove
--
-- @function [parent=#SoundSource] GetAutoRemove
-- @return #boolean

---
-- Function IsPlaying
--
-- @function [parent=#SoundSource] IsPlaying
-- @return #boolean

---
-- Function PlayLockless
--
-- @function [parent=#SoundSource] PlayLockless
-- @param Sound#Sound soundsound

---
-- Function StopLockless
--
-- @function [parent=#SoundSource] StopLockless

---
-- Field sound (Read only)
--
-- @field [parent=#SoundSource] Sound#Sound sound

---
-- Field soundType
--
-- @field [parent=#SoundSource] SoundType#SoundType soundType

---
-- Field timePosition (Read only)
--
-- @field [parent=#SoundSource] #number timePosition

---
-- Field frequency
--
-- @field [parent=#SoundSource] #number frequency

---
-- Field gain
--
-- @field [parent=#SoundSource] #number gain

---
-- Field attenuation
--
-- @field [parent=#SoundSource] #number attenuation

---
-- Field panning
--
-- @field [parent=#SoundSource] #number panning

---
-- Field autoRemove
--
-- @field [parent=#SoundSource] #boolean autoRemove

---
-- Field playing (Read only)
--
-- @field [parent=#SoundSource] #boolean playing


return nil
