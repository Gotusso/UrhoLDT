---
-- Module Scene
-- Extends Node
--
-- @module Scene

---
-- Function Scene
--
-- @function [parent=#Scene] Scene

---
-- Function new
--
-- @function [parent=#Scene] new
-- @return Scene#Scene

---
-- Function delete
--
-- @function [parent=#Scene] delete

---
-- Function Load
--
-- @function [parent=#Scene] Load
-- @param File#File sourcesource
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#Scene] Save
-- @param File#File destdest
-- @return #boolean

---
-- Function Load
--
-- @function [parent=#Scene] Load
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#Scene] Save
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#Scene] LoadXML
-- @param File#File sourcesource
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#Scene] SaveXML
-- @param File#File destdest
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#Scene] LoadXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#Scene] SaveXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function Instantiate
--
-- @function [parent=#Scene] Instantiate
-- @param File#File sourcesource
-- @param Vector3#Vector3 positionposition
-- @param Quaternion#Quaternion rotationrotation
-- @param CreateMode#CreateMode modemode
-- @return Node#Node

---
-- Function Instantiate
--
-- @function [parent=#Scene] Instantiate
-- @param #string fileNamefileName
-- @param Vector3#Vector3 positionposition
-- @param Quaternion#Quaternion rotationrotation
-- @param CreateMode#CreateMode modemode
-- @return Node#Node

---
-- Function InstantiateXML
--
-- @function [parent=#Scene] InstantiateXML
-- @param File#File sourcesource
-- @param Vector3#Vector3 positionposition
-- @param Quaternion#Quaternion rotationrotation
-- @param CreateMode#CreateMode modemode
-- @return Node#Node

---
-- Function InstantiateXML
--
-- @function [parent=#Scene] InstantiateXML
-- @param #string fileNamefileName
-- @param Vector3#Vector3 positionposition
-- @param Quaternion#Quaternion rotationrotation
-- @param CreateMode#CreateMode modemode
-- @return Node#Node

---
-- Function LoadAsync
--
-- @function [parent=#Scene] LoadAsync
-- @param File#File filefile
-- @return #boolean

---
-- Function LoadAsyncXML
--
-- @function [parent=#Scene] LoadAsyncXML
-- @param File#File filefile
-- @return #boolean

---
-- Function StopAsyncLoading
--
-- @function [parent=#Scene] StopAsyncLoading

---
-- Function Clear
--
-- @function [parent=#Scene] Clear
-- @param #boolean clearReplicatedclearReplicated
-- @param #boolean clearLocalclearLocal

---
-- Function SetUpdateEnabled
--
-- @function [parent=#Scene] SetUpdateEnabled
-- @param #boolean enableenable

---
-- Function SetTimeScale
--
-- @function [parent=#Scene] SetTimeScale
-- @param #number scalescale

---
-- Function SetElapsedTime
--
-- @function [parent=#Scene] SetElapsedTime
-- @param #number timetime

---
-- Function SetSmoothingConstant
--
-- @function [parent=#Scene] SetSmoothingConstant
-- @param #number constantconstant

---
-- Function SetSnapThreshold
--
-- @function [parent=#Scene] SetSnapThreshold
-- @param #number thresholdthreshold

---
-- Function GetNode
--
-- @function [parent=#Scene] GetNode
-- @param #number idid
-- @return Node#Node

---
-- Function IsUpdateEnabled
--
-- @function [parent=#Scene] IsUpdateEnabled
-- @return #boolean

---
-- Function IsAsyncLoading
--
-- @function [parent=#Scene] IsAsyncLoading
-- @return #boolean

---
-- Function GetAsyncProgress
--
-- @function [parent=#Scene] GetAsyncProgress
-- @return #number

---
-- Function GetFileName
--
-- @function [parent=#Scene] GetFileName
-- @return const String#const String

---
-- Function GetChecksum
--
-- @function [parent=#Scene] GetChecksum
-- @return #number

---
-- Function GetTimeScale
--
-- @function [parent=#Scene] GetTimeScale
-- @return #number

---
-- Function GetElapsedTime
--
-- @function [parent=#Scene] GetElapsedTime
-- @return #number

---
-- Function GetSmoothingConstant
--
-- @function [parent=#Scene] GetSmoothingConstant
-- @return #number

---
-- Function GetSnapThreshold
--
-- @function [parent=#Scene] GetSnapThreshold
-- @return #number

---
-- Function GetVarName
--
-- @function [parent=#Scene] GetVarName
-- @param ShortStringHash#ShortStringHash hashhash
-- @return const String#const String

---
-- Function Update
--
-- @function [parent=#Scene] Update
-- @param #number timeSteptimeStep

---
-- Function BeginThreadedUpdate
--
-- @function [parent=#Scene] BeginThreadedUpdate

---
-- Function EndThreadedUpdate
--
-- @function [parent=#Scene] EndThreadedUpdate

---
-- Function DelayedMarkedDirty
--
-- @function [parent=#Scene] DelayedMarkedDirty
-- @param Component#Component componentcomponent

---
-- Function IsThreadedUpdate
--
-- @function [parent=#Scene] IsThreadedUpdate
-- @return #boolean

---
-- Function GetFreeNodeID
--
-- @function [parent=#Scene] GetFreeNodeID
-- @param CreateMode#CreateMode modemode
-- @return #number

---
-- Function GetFreeComponentID
--
-- @function [parent=#Scene] GetFreeComponentID
-- @param CreateMode#CreateMode modemode
-- @return #number

---
-- Function NodeAdded
--
-- @function [parent=#Scene] NodeAdded
-- @param Node#Node nodenode

---
-- Function NodeRemoved
--
-- @function [parent=#Scene] NodeRemoved
-- @param Node#Node nodenode

---
-- Function ComponentAdded
--
-- @function [parent=#Scene] ComponentAdded
-- @param Component#Component componentcomponent

---
-- Function ComponentRemoved
--
-- @function [parent=#Scene] ComponentRemoved
-- @param Component#Component componentcomponent

---
-- Function SetVarNamesAttr
--
-- @function [parent=#Scene] SetVarNamesAttr
-- @param #string valuevalue

---
-- Function GetVarNamesAttr
--
-- @function [parent=#Scene] GetVarNamesAttr
-- @return #string

---
-- Function PrepareNetworkUpdate
--
-- @function [parent=#Scene] PrepareNetworkUpdate

---
-- Function CleanupConnection
--
-- @function [parent=#Scene] CleanupConnection
-- @param Connection#Connection connectionconnection

---
-- Function MarkNetworkUpdate
--
-- @function [parent=#Scene] MarkNetworkUpdate
-- @param Node#Node nodenode

---
-- Function MarkNetworkUpdate
--
-- @function [parent=#Scene] MarkNetworkUpdate
-- @param Component#Component componentcomponent

---
-- Function MarkReplicationDirty
--
-- @function [parent=#Scene] MarkReplicationDirty
-- @param Node#Node nodenode

---
-- Field updateEnabled
--
-- @field [parent=#Scene] #boolean updateEnabled

---
-- Field asyncLoading (Read only)
--
-- @field [parent=#Scene] #boolean asyncLoading

---
-- Field asyncProgress (Read only)
--
-- @field [parent=#Scene] #number asyncProgress

---
-- Field fileName
--
-- @field [parent=#Scene] #string fileName

---
-- Field checksum (Read only)
--
-- @field [parent=#Scene] #number checksum

---
-- Field timeScale
--
-- @field [parent=#Scene] #number timeScale

---
-- Field elapsedTime
--
-- @field [parent=#Scene] #number elapsedTime

---
-- Field smoothingConstant
--
-- @field [parent=#Scene] #number smoothingConstant

---
-- Field snapThreshold
--
-- @field [parent=#Scene] #number snapThreshold

---
-- Field threadedUpdate (Read only)
--
-- @field [parent=#Scene] #boolean threadedUpdate

---
-- Field varNamesAttr
--
-- @field [parent=#Scene] #string varNamesAttr


return nil
