---
-- Module Scene
-- Module Scene extends Node
-- Generated on 2014-03-13
--
-- @module Scene

---
-- Function Scene
--
-- @function [parent=#Scene] Scene
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#Scene] new
-- @param self Self reference
-- @return Scene#Scene

---
-- Function delete
--
-- @function [parent=#Scene] delete
-- @param self Self reference

---
-- Function Load
--
-- @function [parent=#Scene] Load
-- @param self Self reference
-- @param File#File source source
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#Scene] Save
-- @param self Self reference
-- @param File#File dest dest
-- @return #boolean

---
-- Function Load
--
-- @function [parent=#Scene] Load
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#Scene] Save
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#Scene] LoadXML
-- @param self Self reference
-- @param File#File source source
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#Scene] SaveXML
-- @param self Self reference
-- @param File#File dest dest
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#Scene] LoadXML
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#Scene] SaveXML
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function Instantiate
--
-- @function [parent=#Scene] Instantiate
-- @param self Self reference
-- @param File#File source source
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation
-- @param CreateMode#CreateMode mode mode
-- @return Node#Node

---
-- Function Instantiate
--
-- @function [parent=#Scene] Instantiate
-- @param self Self reference
-- @param #string fileName fileName
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation
-- @param CreateMode#CreateMode mode mode
-- @return Node#Node

---
-- Function InstantiateXML
--
-- @function [parent=#Scene] InstantiateXML
-- @param self Self reference
-- @param File#File source source
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation
-- @param CreateMode#CreateMode mode mode
-- @return Node#Node

---
-- Function InstantiateXML
--
-- @function [parent=#Scene] InstantiateXML
-- @param self Self reference
-- @param #string fileName fileName
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation
-- @param CreateMode#CreateMode mode mode
-- @return Node#Node

---
-- Function LoadAsync
--
-- @function [parent=#Scene] LoadAsync
-- @param self Self reference
-- @param File#File file file
-- @return #boolean

---
-- Function LoadAsyncXML
--
-- @function [parent=#Scene] LoadAsyncXML
-- @param self Self reference
-- @param File#File file file
-- @return #boolean

---
-- Function StopAsyncLoading
--
-- @function [parent=#Scene] StopAsyncLoading
-- @param self Self reference

---
-- Function Clear
--
-- @function [parent=#Scene] Clear
-- @param self Self reference
-- @param #boolean clearReplicated clearReplicated
-- @param #boolean clearLocal clearLocal

---
-- Function SetUpdateEnabled
--
-- @function [parent=#Scene] SetUpdateEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetTimeScale
--
-- @function [parent=#Scene] SetTimeScale
-- @param self Self reference
-- @param #number scale scale

---
-- Function SetElapsedTime
--
-- @function [parent=#Scene] SetElapsedTime
-- @param self Self reference
-- @param #number time time

---
-- Function SetSmoothingConstant
--
-- @function [parent=#Scene] SetSmoothingConstant
-- @param self Self reference
-- @param #number constant constant

---
-- Function SetSnapThreshold
--
-- @function [parent=#Scene] SetSnapThreshold
-- @param self Self reference
-- @param #number threshold threshold

---
-- Function GetNode
--
-- @function [parent=#Scene] GetNode
-- @param self Self reference
-- @param #number id id
-- @return Node#Node

---
-- Function IsUpdateEnabled
--
-- @function [parent=#Scene] IsUpdateEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsAsyncLoading
--
-- @function [parent=#Scene] IsAsyncLoading
-- @param self Self reference
-- @return #boolean

---
-- Function GetAsyncProgress
--
-- @function [parent=#Scene] GetAsyncProgress
-- @param self Self reference
-- @return #number

---
-- Function GetFileName
--
-- @function [parent=#Scene] GetFileName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetChecksum
--
-- @function [parent=#Scene] GetChecksum
-- @param self Self reference
-- @return #number

---
-- Function GetTimeScale
--
-- @function [parent=#Scene] GetTimeScale
-- @param self Self reference
-- @return #number

---
-- Function GetElapsedTime
--
-- @function [parent=#Scene] GetElapsedTime
-- @param self Self reference
-- @return #number

---
-- Function GetSmoothingConstant
--
-- @function [parent=#Scene] GetSmoothingConstant
-- @param self Self reference
-- @return #number

---
-- Function GetSnapThreshold
--
-- @function [parent=#Scene] GetSnapThreshold
-- @param self Self reference
-- @return #number

---
-- Function GetVarName
--
-- @function [parent=#Scene] GetVarName
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash hash hash
-- @return const String#const String

---
-- Function Update
--
-- @function [parent=#Scene] Update
-- @param self Self reference
-- @param #number timeStep timeStep

---
-- Function BeginThreadedUpdate
--
-- @function [parent=#Scene] BeginThreadedUpdate
-- @param self Self reference

---
-- Function EndThreadedUpdate
--
-- @function [parent=#Scene] EndThreadedUpdate
-- @param self Self reference

---
-- Function DelayedMarkedDirty
--
-- @function [parent=#Scene] DelayedMarkedDirty
-- @param self Self reference
-- @param Component#Component component component

---
-- Function IsThreadedUpdate
--
-- @function [parent=#Scene] IsThreadedUpdate
-- @param self Self reference
-- @return #boolean

---
-- Function GetFreeNodeID
--
-- @function [parent=#Scene] GetFreeNodeID
-- @param self Self reference
-- @param CreateMode#CreateMode mode mode
-- @return #number

---
-- Function GetFreeComponentID
--
-- @function [parent=#Scene] GetFreeComponentID
-- @param self Self reference
-- @param CreateMode#CreateMode mode mode
-- @return #number

---
-- Function NodeAdded
--
-- @function [parent=#Scene] NodeAdded
-- @param self Self reference
-- @param Node#Node node node

---
-- Function NodeRemoved
--
-- @function [parent=#Scene] NodeRemoved
-- @param self Self reference
-- @param Node#Node node node

---
-- Function ComponentAdded
--
-- @function [parent=#Scene] ComponentAdded
-- @param self Self reference
-- @param Component#Component component component

---
-- Function ComponentRemoved
--
-- @function [parent=#Scene] ComponentRemoved
-- @param self Self reference
-- @param Component#Component component component

---
-- Function SetVarNamesAttr
--
-- @function [parent=#Scene] SetVarNamesAttr
-- @param self Self reference
-- @param #string value value

---
-- Function GetVarNamesAttr
--
-- @function [parent=#Scene] GetVarNamesAttr
-- @param self Self reference
-- @return #string

---
-- Function PrepareNetworkUpdate
--
-- @function [parent=#Scene] PrepareNetworkUpdate
-- @param self Self reference

---
-- Function CleanupConnection
--
-- @function [parent=#Scene] CleanupConnection
-- @param self Self reference
-- @param Connection#Connection connection connection

---
-- Function MarkNetworkUpdate
--
-- @function [parent=#Scene] MarkNetworkUpdate
-- @param self Self reference
-- @param Node#Node node node

---
-- Function MarkNetworkUpdate
--
-- @function [parent=#Scene] MarkNetworkUpdate
-- @param self Self reference
-- @param Component#Component component component

---
-- Function MarkReplicationDirty
--
-- @function [parent=#Scene] MarkReplicationDirty
-- @param self Self reference
-- @param Node#Node node node

---
-- Field updateEnabled
--
-- @field [parent=#Scene] #boolean updateEnabled

---
-- Field asyncLoading (Read only)
--
-- @field [parent=#Scene] #boolean asyncLoading

---
-- Field asyncProgress (Read only)
--
-- @field [parent=#Scene] #number asyncProgress

---
-- Field fileName
--
-- @field [parent=#Scene] #string fileName

---
-- Field checksum (Read only)
--
-- @field [parent=#Scene] #number checksum

---
-- Field timeScale
--
-- @field [parent=#Scene] #number timeScale

---
-- Field elapsedTime
--
-- @field [parent=#Scene] #number elapsedTime

---
-- Field smoothingConstant
--
-- @field [parent=#Scene] #number smoothingConstant

---
-- Field snapThreshold
--
-- @field [parent=#Scene] #number snapThreshold

---
-- Field threadedUpdate (Read only)
--
-- @field [parent=#Scene] #boolean threadedUpdate

---
-- Field varNamesAttr
--
-- @field [parent=#Scene] #string varNamesAttr

---
-- Function Node
--
-- @function [parent=#Scene] Node
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#Scene] new
-- @param self Self reference
-- @return Node#Node

---
-- Function delete
--
-- @function [parent=#Scene] delete
-- @param self Self reference

---
-- Function SaveXML
--
-- @function [parent=#Scene] SaveXML
-- @param self Self reference
-- @param File#File dest dest
-- @return #boolean

---
-- Function SetName
--
-- @function [parent=#Scene] SetName
-- @param self Self reference
-- @param #string name name

---
-- Function SetPosition
--
-- @function [parent=#Scene] SetPosition
-- @param self Self reference
-- @param Vector3#Vector3 position position

---
-- Function SetPositionXYZ
--
-- @function [parent=#Scene] SetPositionXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function SetRotation
--
-- @function [parent=#Scene] SetRotation
-- @param self Self reference
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetRotationXYZ
--
-- @function [parent=#Scene] SetRotationXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function SetDirection
--
-- @function [parent=#Scene] SetDirection
-- @param self Self reference
-- @param Vector3#Vector3 direction direction

---
-- Function SetDirectionXYZ
--
-- @function [parent=#Scene] SetDirectionXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function SetScale
--
-- @function [parent=#Scene] SetScale
-- @param self Self reference
-- @param #number scale scale

---
-- Function SetScale
--
-- @function [parent=#Scene] SetScale
-- @param self Self reference
-- @param Vector3#Vector3 scale scale

---
-- Function SetScaleXYZ
--
-- @function [parent=#Scene] SetScaleXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function SetTransform
--
-- @function [parent=#Scene] SetTransform
-- @param self Self reference
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetTransform
--
-- @function [parent=#Scene] SetTransform
-- @param self Self reference
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation
-- @param #number scale scale

---
-- Function SetTransform
--
-- @function [parent=#Scene] SetTransform
-- @param self Self reference
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation
-- @param Vector3#Vector3 scale scale

---
-- Function SetWorldPosition
--
-- @function [parent=#Scene] SetWorldPosition
-- @param self Self reference
-- @param Vector3#Vector3 position position

---
-- Function SetWorldPositionXYZ
--
-- @function [parent=#Scene] SetWorldPositionXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function SetWorldRotation
--
-- @function [parent=#Scene] SetWorldRotation
-- @param self Self reference
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetWorldRotationXYZ
--
-- @function [parent=#Scene] SetWorldRotationXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function SetWorldDirection
--
-- @function [parent=#Scene] SetWorldDirection
-- @param self Self reference
-- @param Vector3#Vector3 direction direction

---
-- Function SetWorldDirectionXYZ
--
-- @function [parent=#Scene] SetWorldDirectionXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function SetWorldScale
--
-- @function [parent=#Scene] SetWorldScale
-- @param self Self reference
-- @param #number scale scale

---
-- Function SetWorldScale
--
-- @function [parent=#Scene] SetWorldScale
-- @param self Self reference
-- @param Vector3#Vector3 scale scale

---
-- Function SetWorldScaleXYZ
--
-- @function [parent=#Scene] SetWorldScaleXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function SetWorldTransform
--
-- @function [parent=#Scene] SetWorldTransform
-- @param self Self reference
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetWorldTransform
--
-- @function [parent=#Scene] SetWorldTransform
-- @param self Self reference
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation
-- @param #number scale scale

---
-- Function SetWorldTransform
--
-- @function [parent=#Scene] SetWorldTransform
-- @param self Self reference
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation
-- @param Vector3#Vector3 scale scale

---
-- Function Translate
--
-- @function [parent=#Scene] Translate
-- @param self Self reference
-- @param Vector3#Vector3 delta delta

---
-- Function TranslateXYZ
--
-- @function [parent=#Scene] TranslateXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function TranslateRelative
--
-- @function [parent=#Scene] TranslateRelative
-- @param self Self reference
-- @param Vector3#Vector3 delta delta

---
-- Function TranslateRelativeXYZ
--
-- @function [parent=#Scene] TranslateRelativeXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function Rotate
--
-- @function [parent=#Scene] Rotate
-- @param self Self reference
-- @param Quaternion#Quaternion delta delta
-- @param #boolean fixedAxis fixedAxis

---
-- Function RotateXYZ
--
-- @function [parent=#Scene] RotateXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z
-- @param #boolean fixedAxis fixedAxis

---
-- Function Pitch
--
-- @function [parent=#Scene] Pitch
-- @param self Self reference
-- @param #number angle angle
-- @param #boolean fixedAxis fixedAxis

---
-- Function Yaw
--
-- @function [parent=#Scene] Yaw
-- @param self Self reference
-- @param #number angle angle
-- @param #boolean fixedAxis fixedAxis

---
-- Function Roll
--
-- @function [parent=#Scene] Roll
-- @param self Self reference
-- @param #number angle angle
-- @param #boolean fixedAxis fixedAxis

---
-- Function LookAt
--
-- @function [parent=#Scene] LookAt
-- @param self Self reference
-- @param Vector3#Vector3 target target

---
-- Function LookAt
--
-- @function [parent=#Scene] LookAt
-- @param self Self reference
-- @param Vector3#Vector3 target target
-- @param Vector3#Vector3 upAxis upAxis

---
-- Function LookAtXYZ
--
-- @function [parent=#Scene] LookAtXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z
-- @param #number upX upX
-- @param #number upY upY
-- @param #number upZ upZ

---
-- Function Scale
--
-- @function [parent=#Scene] Scale
-- @param self Self reference
-- @param #number scale scale

---
-- Function Scale
--
-- @function [parent=#Scene] Scale
-- @param self Self reference
-- @param Vector3#Vector3 scale scale

---
-- Function ScaleXYZ
--
-- @function [parent=#Scene] ScaleXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function SetEnabled
--
-- @function [parent=#Scene] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetEnabled
--
-- @function [parent=#Scene] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable
-- @param #boolean recursive recursive

---
-- Function SetOwner
--
-- @function [parent=#Scene] SetOwner
-- @param self Self reference
-- @param Connection#Connection owner owner

---
-- Function MarkDirty
--
-- @function [parent=#Scene] MarkDirty
-- @param self Self reference

---
-- Function CreateChild
--
-- @function [parent=#Scene] CreateChild
-- @param self Self reference
-- @param #string name name
-- @param CreateMode#CreateMode mode mode
-- @param #number id id
-- @return Node#Node

---
-- Function AddChild
--
-- @function [parent=#Scene] AddChild
-- @param self Self reference
-- @param Node#Node node node

---
-- Function RemoveChild
--
-- @function [parent=#Scene] RemoveChild
-- @param self Self reference
-- @param Node#Node node node

---
-- Function RemoveAllChildren
--
-- @function [parent=#Scene] RemoveAllChildren
-- @param self Self reference

---
-- Function RemoveChildren
--
-- @function [parent=#Scene] RemoveChildren
-- @param self Self reference
-- @param #boolean removeReplicated removeReplicated
-- @param #boolean removeLocal removeLocal
-- @param #boolean recursive recursive

---
-- Function RemoveComponent
--
-- @function [parent=#Scene] RemoveComponent
-- @param self Self reference
-- @param Component#Component component component

---
-- Function RemoveComponent
--
-- @function [parent=#Scene] RemoveComponent
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type

---
-- Function RemoveComponent
--
-- @function [parent=#Scene] RemoveComponent
-- @param self Self reference
-- @param #string type type

---
-- Function RemoveAllComponents
--
-- @function [parent=#Scene] RemoveAllComponents
-- @param self Self reference

---
-- Function RemoveComponents
--
-- @function [parent=#Scene] RemoveComponents
-- @param self Self reference
-- @param #boolean removeReplicated removeReplicated
-- @param #boolean removeLocal removeLocal

---
-- Function Clone
--
-- @function [parent=#Scene] Clone
-- @param self Self reference
-- @param CreateMode#CreateMode mode mode
-- @return Node#Node

---
-- Function Remove
--
-- @function [parent=#Scene] Remove
-- @param self Self reference

---
-- Function SetParent
--
-- @function [parent=#Scene] SetParent
-- @param self Self reference
-- @param Node#Node parent parent

---
-- Function SetVar
--
-- @function [parent=#Scene] SetVar
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash key key
-- @param Variant#Variant value value

---
-- Function AddListener
--
-- @function [parent=#Scene] AddListener
-- @param self Self reference
-- @param Component#Component component component

---
-- Function RemoveListener
--
-- @function [parent=#Scene] RemoveListener
-- @param self Self reference
-- @param Component#Component component component

---
-- Function CreateComponent
--
-- @function [parent=#Scene] CreateComponent
-- @param self Self reference
-- @param #string type type
-- @param CreateMode#CreateMode mode mode
-- @param #number id id
-- @return Component#Component

---
-- Function CreateScriptObject
--
-- @function [parent=#Scene] CreateScriptObject
-- @param self Self reference
-- @param #string scriptObjectType scriptObjectType
-- @return #number

---
-- Function CreateScriptObject
--
-- @function [parent=#Scene] CreateScriptObject
-- @param self Self reference
-- @param #string fileName fileName
-- @param #string scriptObjectType scriptObjectType
-- @return #number

---
-- Function GetScriptObject
--
-- @function [parent=#Scene] GetScriptObject
-- @param self Self reference
-- @return #number

---
-- Function GetScriptObject
--
-- @function [parent=#Scene] GetScriptObject
-- @param self Self reference
-- @param #string scriptObjectType scriptObjectType
-- @return #number

---
-- Function GetID
--
-- @function [parent=#Scene] GetID
-- @param self Self reference
-- @return #number

---
-- Function GetName
--
-- @function [parent=#Scene] GetName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetNameHash
--
-- @function [parent=#Scene] GetNameHash
-- @param self Self reference
-- @return StringHash#StringHash

---
-- Function GetParent
--
-- @function [parent=#Scene] GetParent
-- @param self Self reference
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#Scene] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#Scene] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function GetOwner
--
-- @function [parent=#Scene] GetOwner
-- @param self Self reference
-- @return Connection#Connection

---
-- Function GetPosition
--
-- @function [parent=#Scene] GetPosition
-- @param self Self reference
-- @return const Vector3#const Vector3

---
-- Function GetPositionXYZ
--
-- @function [parent=#Scene] GetPositionXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function GetRotation
--
-- @function [parent=#Scene] GetRotation
-- @param self Self reference
-- @return const Quaternion#const Quaternion

---
-- Function GetRotationXYZ
--
-- @function [parent=#Scene] GetRotationXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function GetRotationWXYZ
--
-- @function [parent=#Scene] GetRotationWXYZ
-- @param self Self reference
-- @param #number w w
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function GetDirection
--
-- @function [parent=#Scene] GetDirection
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetDirectionXYZ
--
-- @function [parent=#Scene] GetDirectionXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function GetUp
--
-- @function [parent=#Scene] GetUp
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetUpXYZ
--
-- @function [parent=#Scene] GetUpXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function GetRight
--
-- @function [parent=#Scene] GetRight
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetRightXYZ
--
-- @function [parent=#Scene] GetRightXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function GetScale
--
-- @function [parent=#Scene] GetScale
-- @param self Self reference
-- @return const Vector3#const Vector3

---
-- Function GetScaleXYZ
--
-- @function [parent=#Scene] GetScaleXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function GetTransform
--
-- @function [parent=#Scene] GetTransform
-- @param self Self reference
-- @return Matrix3x4#Matrix3x4

---
-- Function GetWorldPosition
--
-- @function [parent=#Scene] GetWorldPosition
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetWorldPositionXYZ
--
-- @function [parent=#Scene] GetWorldPositionXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function GetWorldRotation
--
-- @function [parent=#Scene] GetWorldRotation
-- @param self Self reference
-- @return Quaternion#Quaternion

---
-- Function GetWorldRotationXYZ
--
-- @function [parent=#Scene] GetWorldRotationXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function GetWorldRotationWXYZ
--
-- @function [parent=#Scene] GetWorldRotationWXYZ
-- @param self Self reference
-- @param #number w w
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function GetWorldDirection
--
-- @function [parent=#Scene] GetWorldDirection
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetWorldDirectionXYZ
--
-- @function [parent=#Scene] GetWorldDirectionXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function GetWorldUp
--
-- @function [parent=#Scene] GetWorldUp
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetWorldUpXYZ
--
-- @function [parent=#Scene] GetWorldUpXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function GetWorldRight
--
-- @function [parent=#Scene] GetWorldRight
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetWorldRightXYZ
--
-- @function [parent=#Scene] GetWorldRightXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function GetWorldScale
--
-- @function [parent=#Scene] GetWorldScale
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetWorldScaleXYZ
--
-- @function [parent=#Scene] GetWorldScaleXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function GetWorldTransform
--
-- @function [parent=#Scene] GetWorldTransform
-- @param self Self reference
-- @return const Matrix3x4#const Matrix3x4

---
-- Function LocalToWorld
--
-- @function [parent=#Scene] LocalToWorld
-- @param self Self reference
-- @param Vector3#Vector3 position position
-- @return Vector3#Vector3

---
-- Function LocalToWorld
--
-- @function [parent=#Scene] LocalToWorld
-- @param self Self reference
-- @param Vector4#Vector4 vector vector
-- @return Vector3#Vector3

---
-- Function WorldToLocal
--
-- @function [parent=#Scene] WorldToLocal
-- @param self Self reference
-- @param Vector3#Vector3 position position
-- @return Vector3#Vector3

---
-- Function WorldToLocal
--
-- @function [parent=#Scene] WorldToLocal
-- @param self Self reference
-- @param Vector4#Vector4 vector vector
-- @return Vector3#Vector3

---
-- Function IsDirty
--
-- @function [parent=#Scene] IsDirty
-- @param self Self reference
-- @return #boolean

---
-- Function GetNumChildren
--
-- @function [parent=#Scene] GetNumChildren
-- @param self Self reference
-- @param #boolean recursive recursive
-- @return #number

---
-- Function GetChild
--
-- @function [parent=#Scene] GetChild
-- @param self Self reference
-- @param #string name name
-- @param #boolean recursive recursive
-- @return Node#Node

---
-- Function GetChild
--
-- @function [parent=#Scene] GetChild
-- @param self Self reference
-- @param StringHash#StringHash nameHash nameHash
-- @param #boolean recursive recursive
-- @return Node#Node

---
-- Function GetChild
--
-- @function [parent=#Scene] GetChild
-- @param self Self reference
-- @param #number index index
-- @return Node#Node

---
-- Function GetNumComponents
--
-- @function [parent=#Scene] GetNumComponents
-- @param self Self reference
-- @return #number

---
-- Function GetNumNetworkComponents
--
-- @function [parent=#Scene] GetNumNetworkComponents
-- @param self Self reference
-- @return #number

---
-- Function HasComponent
--
-- @function [parent=#Scene] HasComponent
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return #boolean

---
-- Function HasComponent
--
-- @function [parent=#Scene] HasComponent
-- @param self Self reference
-- @param #string type type
-- @return #boolean

---
-- Function GetVar
--
-- @function [parent=#Scene] GetVar
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash key key
-- @return const Variant#const Variant

---
-- Function GetVars
--
-- @function [parent=#Scene] GetVars
-- @param self Self reference
-- @return const VariantMap#const VariantMap

---
-- Function GetComponent
--
-- @function [parent=#Scene] GetComponent
-- @param self Self reference
-- @param #string type type
-- @return Component#Component

---
-- Function SetID
--
-- @function [parent=#Scene] SetID
-- @param self Self reference
-- @param #number id id

---
-- Function SetScene
--
-- @function [parent=#Scene] SetScene
-- @param self Self reference
-- @param Scene#Scene scene scene

---
-- Function ResetScene
--
-- @function [parent=#Scene] ResetScene
-- @param self Self reference

---
-- Function Load
--
-- @function [parent=#Scene] Load
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @param SceneResolver#SceneResolver resolver resolver
-- @param #boolean loadChildren loadChildren
-- @param #boolean rewriteIDs rewriteIDs
-- @param CreateMode#CreateMode mode mode
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#Scene] LoadXML
-- @param self Self reference
-- @param XMLElement#XMLElement source source
-- @param SceneResolver#SceneResolver resolver resolver
-- @param #boolean loadChildren loadChildren
-- @param #boolean rewriteIDs rewriteIDs
-- @param CreateMode#CreateMode mode mode
-- @return #boolean

---
-- Function CreateChild
--
-- @function [parent=#Scene] CreateChild
-- @param self Self reference
-- @param #number id id
-- @param CreateMode#CreateMode mode mode
-- @return Node#Node

---
-- Function AddComponent
--
-- @function [parent=#Scene] AddComponent
-- @param self Self reference
-- @param Component#Component component component
-- @param #number id id
-- @param CreateMode#CreateMode mode mode

---
-- Field ID
--
-- @field [parent=#Scene] #number ID

---
-- Field name
--
-- @field [parent=#Scene] #string name

---
-- Field nameHash (Read only)
--
-- @field [parent=#Scene] StringHash#StringHash nameHash

---
-- Field parent
--
-- @field [parent=#Scene] Node#Node parent

---
-- Field scene
--
-- @field [parent=#Scene] Scene#Scene scene

---
-- Field enabled
--
-- @field [parent=#Scene] #boolean enabled

---
-- Field owner
--
-- @field [parent=#Scene] Connection#Connection owner

---
-- Field position
--
-- @field [parent=#Scene] Vector3#Vector3 position

---
-- Field rotation
--
-- @field [parent=#Scene] Quaternion#Quaternion rotation

---
-- Field direction
--
-- @field [parent=#Scene] Vector3#Vector3 direction

---
-- Field up (Read only)
--
-- @field [parent=#Scene] Vector3#Vector3 up

---
-- Field right (Read only)
--
-- @field [parent=#Scene] Vector3#Vector3 right

---
-- Field scale
--
-- @field [parent=#Scene] Vector3#Vector3 scale

---
-- Field transform (Read only)
--
-- @field [parent=#Scene] Matrix3x4#Matrix3x4 transform

---
-- Field worldPosition
--
-- @field [parent=#Scene] Vector3#Vector3 worldPosition

---
-- Field worldRotation
--
-- @field [parent=#Scene] Quaternion#Quaternion worldRotation

---
-- Field worldDirection
--
-- @field [parent=#Scene] Vector3#Vector3 worldDirection

---
-- Field worldUp (Read only)
--
-- @field [parent=#Scene] Vector3#Vector3 worldUp

---
-- Field worldRight (Read only)
--
-- @field [parent=#Scene] Vector3#Vector3 worldRight

---
-- Field worldScale
--
-- @field [parent=#Scene] Vector3#Vector3 worldScale

---
-- Field worldTransform (Read only)
--
-- @field [parent=#Scene] Matrix3x4#Matrix3x4 worldTransform

---
-- Field dirty (Read only)
--
-- @field [parent=#Scene] #boolean dirty

---
-- Field numComponents (Read only)
--
-- @field [parent=#Scene] #number numComponents

---
-- Field numNetworkComponents (Read only)
--
-- @field [parent=#Scene] #number numNetworkComponents

---
-- Function SetTemporary
--
-- @function [parent=#Scene] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#Scene] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Scene] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Scene] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Scene] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Scene] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Scene] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Scene] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#Scene] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Scene] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Scene] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Scene] #string category


return nil
