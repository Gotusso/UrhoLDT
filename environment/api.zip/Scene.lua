---
-- Module Scene
-- extends Node
--
-- @module Scene

---
-- Function Scene
--
-- @function [parent=#Scene] Scene

---
-- Function new
--
-- @function [parent=#Scene] new
-- @return Scene#Scene

---
-- Function delete
--
-- @function [parent=#Scene] delete

---
-- Function Load
--
-- @function [parent=#Scene] Load
-- @param File#File sourcesource
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#Scene] Save
-- @param File#File destdest
-- @return #boolean

---
-- Function Load
--
-- @function [parent=#Scene] Load
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#Scene] Save
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#Scene] LoadXML
-- @param File#File sourcesource
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#Scene] SaveXML
-- @param File#File destdest
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#Scene] LoadXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#Scene] SaveXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function Instantiate
--
-- @function [parent=#Scene] Instantiate
-- @param File#File sourcesource
-- @param Vector3#Vector3 positionposition
-- @param Quaternion#Quaternion rotationrotation
-- @param CreateMode#CreateMode modemode
-- @return Node#Node

---
-- Function Instantiate
--
-- @function [parent=#Scene] Instantiate
-- @param #string fileNamefileName
-- @param Vector3#Vector3 positionposition
-- @param Quaternion#Quaternion rotationrotation
-- @param CreateMode#CreateMode modemode
-- @return Node#Node

---
-- Function InstantiateXML
--
-- @function [parent=#Scene] InstantiateXML
-- @param File#File sourcesource
-- @param Vector3#Vector3 positionposition
-- @param Quaternion#Quaternion rotationrotation
-- @param CreateMode#CreateMode modemode
-- @return Node#Node

---
-- Function InstantiateXML
--
-- @function [parent=#Scene] InstantiateXML
-- @param #string fileNamefileName
-- @param Vector3#Vector3 positionposition
-- @param Quaternion#Quaternion rotationrotation
-- @param CreateMode#CreateMode modemode
-- @return Node#Node

---
-- Function LoadAsync
--
-- @function [parent=#Scene] LoadAsync
-- @param File#File filefile
-- @return #boolean

---
-- Function LoadAsyncXML
--
-- @function [parent=#Scene] LoadAsyncXML
-- @param File#File filefile
-- @return #boolean

---
-- Function StopAsyncLoading
--
-- @function [parent=#Scene] StopAsyncLoading

---
-- Function Clear
--
-- @function [parent=#Scene] Clear
-- @param #boolean clearReplicatedclearReplicated
-- @param #boolean clearLocalclearLocal

---
-- Function SetUpdateEnabled
--
-- @function [parent=#Scene] SetUpdateEnabled
-- @param #boolean enableenable

---
-- Function SetTimeScale
--
-- @function [parent=#Scene] SetTimeScale
-- @param #number scalescale

---
-- Function SetElapsedTime
--
-- @function [parent=#Scene] SetElapsedTime
-- @param #number timetime

---
-- Function SetSmoothingConstant
--
-- @function [parent=#Scene] SetSmoothingConstant
-- @param #number constantconstant

---
-- Function SetSnapThreshold
--
-- @function [parent=#Scene] SetSnapThreshold
-- @param #number thresholdthreshold

---
-- Function GetNode
--
-- @function [parent=#Scene] GetNode
-- @param #number idid
-- @return Node#Node

---
-- Function IsUpdateEnabled
--
-- @function [parent=#Scene] IsUpdateEnabled
-- @return #boolean

---
-- Function IsAsyncLoading
--
-- @function [parent=#Scene] IsAsyncLoading
-- @return #boolean

---
-- Function GetAsyncProgress
--
-- @function [parent=#Scene] GetAsyncProgress
-- @return #number

---
-- Function GetFileName
--
-- @function [parent=#Scene] GetFileName
-- @return const String#const String

---
-- Function GetChecksum
--
-- @function [parent=#Scene] GetChecksum
-- @return #number

---
-- Function GetTimeScale
--
-- @function [parent=#Scene] GetTimeScale
-- @return #number

---
-- Function GetElapsedTime
--
-- @function [parent=#Scene] GetElapsedTime
-- @return #number

---
-- Function GetSmoothingConstant
--
-- @function [parent=#Scene] GetSmoothingConstant
-- @return #number

---
-- Function GetSnapThreshold
--
-- @function [parent=#Scene] GetSnapThreshold
-- @return #number

---
-- Function GetVarName
--
-- @function [parent=#Scene] GetVarName
-- @param ShortStringHash#ShortStringHash hashhash
-- @return const String#const String

---
-- Function Update
--
-- @function [parent=#Scene] Update
-- @param #number timeSteptimeStep

---
-- Function BeginThreadedUpdate
--
-- @function [parent=#Scene] BeginThreadedUpdate

---
-- Function EndThreadedUpdate
--
-- @function [parent=#Scene] EndThreadedUpdate

---
-- Function DelayedMarkedDirty
--
-- @function [parent=#Scene] DelayedMarkedDirty
-- @param Component#Component componentcomponent

---
-- Function IsThreadedUpdate
--
-- @function [parent=#Scene] IsThreadedUpdate
-- @return #boolean

---
-- Function GetFreeNodeID
--
-- @function [parent=#Scene] GetFreeNodeID
-- @param CreateMode#CreateMode modemode
-- @return #number

---
-- Function GetFreeComponentID
--
-- @function [parent=#Scene] GetFreeComponentID
-- @param CreateMode#CreateMode modemode
-- @return #number

---
-- Function NodeAdded
--
-- @function [parent=#Scene] NodeAdded
-- @param Node#Node nodenode

---
-- Function NodeRemoved
--
-- @function [parent=#Scene] NodeRemoved
-- @param Node#Node nodenode

---
-- Function ComponentAdded
--
-- @function [parent=#Scene] ComponentAdded
-- @param Component#Component componentcomponent

---
-- Function ComponentRemoved
--
-- @function [parent=#Scene] ComponentRemoved
-- @param Component#Component componentcomponent

---
-- Function SetVarNamesAttr
--
-- @function [parent=#Scene] SetVarNamesAttr
-- @param #string valuevalue

---
-- Function GetVarNamesAttr
--
-- @function [parent=#Scene] GetVarNamesAttr
-- @return #string

---
-- Function PrepareNetworkUpdate
--
-- @function [parent=#Scene] PrepareNetworkUpdate

---
-- Function CleanupConnection
--
-- @function [parent=#Scene] CleanupConnection
-- @param Connection#Connection connectionconnection

---
-- Function MarkNetworkUpdate
--
-- @function [parent=#Scene] MarkNetworkUpdate
-- @param Node#Node nodenode

---
-- Function MarkNetworkUpdate
--
-- @function [parent=#Scene] MarkNetworkUpdate
-- @param Component#Component componentcomponent

---
-- Function MarkReplicationDirty
--
-- @function [parent=#Scene] MarkReplicationDirty
-- @param Node#Node nodenode

---
-- Field updateEnabled
--
-- @field [parent=#Scene] #boolean updateEnabled

---
-- Field asyncLoading (Read only)
--
-- @field [parent=#Scene] #boolean asyncLoading

---
-- Field asyncProgress (Read only)
--
-- @field [parent=#Scene] #number asyncProgress

---
-- Field fileName
--
-- @field [parent=#Scene] #string fileName

---
-- Field checksum (Read only)
--
-- @field [parent=#Scene] #number checksum

---
-- Field timeScale
--
-- @field [parent=#Scene] #number timeScale

---
-- Field elapsedTime
--
-- @field [parent=#Scene] #number elapsedTime

---
-- Field smoothingConstant
--
-- @field [parent=#Scene] #number smoothingConstant

---
-- Field snapThreshold
--
-- @field [parent=#Scene] #number snapThreshold

---
-- Field threadedUpdate (Read only)
--
-- @field [parent=#Scene] #boolean threadedUpdate

---
-- Field varNamesAttr
--
-- @field [parent=#Scene] #string varNamesAttr

---
-- Function Node
--
-- @function [parent=#Scene] Node

---
-- Function new
--
-- @function [parent=#Scene] new
-- @return Node#Node

---
-- Function delete
--
-- @function [parent=#Scene] delete

---
-- Function SaveXML
--
-- @function [parent=#Scene] SaveXML
-- @param File#File destdest
-- @return #boolean

---
-- Function SetName
--
-- @function [parent=#Scene] SetName
-- @param #string namename

---
-- Function SetPosition
--
-- @function [parent=#Scene] SetPosition
-- @param Vector3#Vector3 positionposition

---
-- Function SetPositionXYZ
--
-- @function [parent=#Scene] SetPositionXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function SetRotation
--
-- @function [parent=#Scene] SetRotation
-- @param Quaternion#Quaternion rotationrotation

---
-- Function SetRotationXYZ
--
-- @function [parent=#Scene] SetRotationXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function SetDirection
--
-- @function [parent=#Scene] SetDirection
-- @param Vector3#Vector3 directiondirection

---
-- Function SetDirectionXYZ
--
-- @function [parent=#Scene] SetDirectionXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function SetScale
--
-- @function [parent=#Scene] SetScale
-- @param #number scalescale

---
-- Function SetScale
--
-- @function [parent=#Scene] SetScale
-- @param Vector3#Vector3 scalescale

---
-- Function SetScaleXYZ
--
-- @function [parent=#Scene] SetScaleXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function SetTransform
--
-- @function [parent=#Scene] SetTransform
-- @param Vector3#Vector3 positionposition
-- @param Quaternion#Quaternion rotationrotation

---
-- Function SetTransform
--
-- @function [parent=#Scene] SetTransform
-- @param Vector3#Vector3 positionposition
-- @param Quaternion#Quaternion rotationrotation
-- @param #number scalescale

---
-- Function SetTransform
--
-- @function [parent=#Scene] SetTransform
-- @param Vector3#Vector3 positionposition
-- @param Quaternion#Quaternion rotationrotation
-- @param Vector3#Vector3 scalescale

---
-- Function SetWorldPosition
--
-- @function [parent=#Scene] SetWorldPosition
-- @param Vector3#Vector3 positionposition

---
-- Function SetWorldPositionXYZ
--
-- @function [parent=#Scene] SetWorldPositionXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function SetWorldRotation
--
-- @function [parent=#Scene] SetWorldRotation
-- @param Quaternion#Quaternion rotationrotation

---
-- Function SetWorldRotationXYZ
--
-- @function [parent=#Scene] SetWorldRotationXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function SetWorldDirection
--
-- @function [parent=#Scene] SetWorldDirection
-- @param Vector3#Vector3 directiondirection

---
-- Function SetWorldDirectionXYZ
--
-- @function [parent=#Scene] SetWorldDirectionXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function SetWorldScale
--
-- @function [parent=#Scene] SetWorldScale
-- @param #number scalescale

---
-- Function SetWorldScale
--
-- @function [parent=#Scene] SetWorldScale
-- @param Vector3#Vector3 scalescale

---
-- Function SetWorldScaleXYZ
--
-- @function [parent=#Scene] SetWorldScaleXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function SetWorldTransform
--
-- @function [parent=#Scene] SetWorldTransform
-- @param Vector3#Vector3 positionposition
-- @param Quaternion#Quaternion rotationrotation

---
-- Function SetWorldTransform
--
-- @function [parent=#Scene] SetWorldTransform
-- @param Vector3#Vector3 positionposition
-- @param Quaternion#Quaternion rotationrotation
-- @param #number scalescale

---
-- Function SetWorldTransform
--
-- @function [parent=#Scene] SetWorldTransform
-- @param Vector3#Vector3 positionposition
-- @param Quaternion#Quaternion rotationrotation
-- @param Vector3#Vector3 scalescale

---
-- Function Translate
--
-- @function [parent=#Scene] Translate
-- @param Vector3#Vector3 deltadelta

---
-- Function TranslateXYZ
--
-- @function [parent=#Scene] TranslateXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function TranslateRelative
--
-- @function [parent=#Scene] TranslateRelative
-- @param Vector3#Vector3 deltadelta

---
-- Function TranslateRelativeXYZ
--
-- @function [parent=#Scene] TranslateRelativeXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function Rotate
--
-- @function [parent=#Scene] Rotate
-- @param Quaternion#Quaternion deltadelta
-- @param #boolean fixedAxisfixedAxis

---
-- Function RotateXYZ
--
-- @function [parent=#Scene] RotateXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz
-- @param #boolean fixedAxisfixedAxis

---
-- Function Pitch
--
-- @function [parent=#Scene] Pitch
-- @param #number angleangle
-- @param #boolean fixedAxisfixedAxis

---
-- Function Yaw
--
-- @function [parent=#Scene] Yaw
-- @param #number angleangle
-- @param #boolean fixedAxisfixedAxis

---
-- Function Roll
--
-- @function [parent=#Scene] Roll
-- @param #number angleangle
-- @param #boolean fixedAxisfixedAxis

---
-- Function LookAt
--
-- @function [parent=#Scene] LookAt
-- @param Vector3#Vector3 targettarget

---
-- Function LookAt
--
-- @function [parent=#Scene] LookAt
-- @param Vector3#Vector3 targettarget
-- @param Vector3#Vector3 upAxisupAxis

---
-- Function LookAtXYZ
--
-- @function [parent=#Scene] LookAtXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz
-- @param #number upXupX
-- @param #number upYupY
-- @param #number upZupZ

---
-- Function Scale
--
-- @function [parent=#Scene] Scale
-- @param #number scalescale

---
-- Function Scale
--
-- @function [parent=#Scene] Scale
-- @param Vector3#Vector3 scalescale

---
-- Function ScaleXYZ
--
-- @function [parent=#Scene] ScaleXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function SetEnabled
--
-- @function [parent=#Scene] SetEnabled
-- @param #boolean enableenable

---
-- Function SetEnabled
--
-- @function [parent=#Scene] SetEnabled
-- @param #boolean enableenable
-- @param #boolean recursiverecursive

---
-- Function SetOwner
--
-- @function [parent=#Scene] SetOwner
-- @param Connection#Connection ownerowner

---
-- Function MarkDirty
--
-- @function [parent=#Scene] MarkDirty

---
-- Function CreateChild
--
-- @function [parent=#Scene] CreateChild
-- @param #string namename
-- @param CreateMode#CreateMode modemode
-- @param #number idid
-- @return Node#Node

---
-- Function AddChild
--
-- @function [parent=#Scene] AddChild
-- @param Node#Node nodenode

---
-- Function RemoveChild
--
-- @function [parent=#Scene] RemoveChild
-- @param Node#Node nodenode

---
-- Function RemoveAllChildren
--
-- @function [parent=#Scene] RemoveAllChildren

---
-- Function RemoveChildren
--
-- @function [parent=#Scene] RemoveChildren
-- @param #boolean removeReplicatedremoveReplicated
-- @param #boolean removeLocalremoveLocal
-- @param #boolean recursiverecursive

---
-- Function RemoveComponent
--
-- @function [parent=#Scene] RemoveComponent
-- @param Component#Component componentcomponent

---
-- Function RemoveComponent
--
-- @function [parent=#Scene] RemoveComponent
-- @param ShortStringHash#ShortStringHash typetype

---
-- Function RemoveComponent
--
-- @function [parent=#Scene] RemoveComponent
-- @param #string typetype

---
-- Function RemoveAllComponents
--
-- @function [parent=#Scene] RemoveAllComponents

---
-- Function RemoveComponents
--
-- @function [parent=#Scene] RemoveComponents
-- @param #boolean removeReplicatedremoveReplicated
-- @param #boolean removeLocalremoveLocal

---
-- Function Clone
--
-- @function [parent=#Scene] Clone
-- @param CreateMode#CreateMode modemode
-- @return Node#Node

---
-- Function Remove
--
-- @function [parent=#Scene] Remove

---
-- Function SetParent
--
-- @function [parent=#Scene] SetParent
-- @param Node#Node parentparent

---
-- Function SetVar
--
-- @function [parent=#Scene] SetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @param Variant#Variant valuevalue

---
-- Function AddListener
--
-- @function [parent=#Scene] AddListener
-- @param Component#Component componentcomponent

---
-- Function RemoveListener
--
-- @function [parent=#Scene] RemoveListener
-- @param Component#Component componentcomponent

---
-- Function CreateComponent
--
-- @function [parent=#Scene] CreateComponent
-- @param #string typetype
-- @param CreateMode#CreateMode modemode
-- @param #number idid
-- @return Component#Component

---
-- Function CreateScriptObject
--
-- @function [parent=#Scene] CreateScriptObject
-- @param #string scriptObjectTypescriptObjectType
-- @return #number

---
-- Function CreateScriptObject
--
-- @function [parent=#Scene] CreateScriptObject
-- @param #string fileNamefileName
-- @param #string scriptObjectTypescriptObjectType
-- @return #number

---
-- Function GetScriptObject
--
-- @function [parent=#Scene] GetScriptObject
-- @return #number

---
-- Function GetScriptObject
--
-- @function [parent=#Scene] GetScriptObject
-- @param #string scriptObjectTypescriptObjectType
-- @return #number

---
-- Function GetID
--
-- @function [parent=#Scene] GetID
-- @return #number

---
-- Function GetName
--
-- @function [parent=#Scene] GetName
-- @return const String#const String

---
-- Function GetNameHash
--
-- @function [parent=#Scene] GetNameHash
-- @return StringHash#StringHash

---
-- Function GetParent
--
-- @function [parent=#Scene] GetParent
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#Scene] GetScene
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#Scene] IsEnabled
-- @return #boolean

---
-- Function GetOwner
--
-- @function [parent=#Scene] GetOwner
-- @return Connection#Connection

---
-- Function GetPosition
--
-- @function [parent=#Scene] GetPosition
-- @return const Vector3#const Vector3

---
-- Function GetPositionXYZ
--
-- @function [parent=#Scene] GetPositionXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function GetRotation
--
-- @function [parent=#Scene] GetRotation
-- @return const Quaternion#const Quaternion

---
-- Function GetRotationXYZ
--
-- @function [parent=#Scene] GetRotationXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function GetRotationWXYZ
--
-- @function [parent=#Scene] GetRotationWXYZ
-- @param #number ww
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function GetDirection
--
-- @function [parent=#Scene] GetDirection
-- @return Vector3#Vector3

---
-- Function GetDirectionXYZ
--
-- @function [parent=#Scene] GetDirectionXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function GetUp
--
-- @function [parent=#Scene] GetUp
-- @return Vector3#Vector3

---
-- Function GetUpXYZ
--
-- @function [parent=#Scene] GetUpXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function GetRight
--
-- @function [parent=#Scene] GetRight
-- @return Vector3#Vector3

---
-- Function GetRightXYZ
--
-- @function [parent=#Scene] GetRightXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function GetScale
--
-- @function [parent=#Scene] GetScale
-- @return const Vector3#const Vector3

---
-- Function GetScaleXYZ
--
-- @function [parent=#Scene] GetScaleXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function GetTransform
--
-- @function [parent=#Scene] GetTransform
-- @return Matrix3x4#Matrix3x4

---
-- Function GetWorldPosition
--
-- @function [parent=#Scene] GetWorldPosition
-- @return Vector3#Vector3

---
-- Function GetWorldPositionXYZ
--
-- @function [parent=#Scene] GetWorldPositionXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function GetWorldRotation
--
-- @function [parent=#Scene] GetWorldRotation
-- @return Quaternion#Quaternion

---
-- Function GetWorldRotationXYZ
--
-- @function [parent=#Scene] GetWorldRotationXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function GetWorldRotationWXYZ
--
-- @function [parent=#Scene] GetWorldRotationWXYZ
-- @param #number ww
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function GetWorldDirection
--
-- @function [parent=#Scene] GetWorldDirection
-- @return Vector3#Vector3

---
-- Function GetWorldDirectionXYZ
--
-- @function [parent=#Scene] GetWorldDirectionXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function GetWorldUp
--
-- @function [parent=#Scene] GetWorldUp
-- @return Vector3#Vector3

---
-- Function GetWorldUpXYZ
--
-- @function [parent=#Scene] GetWorldUpXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function GetWorldRight
--
-- @function [parent=#Scene] GetWorldRight
-- @return Vector3#Vector3

---
-- Function GetWorldRightXYZ
--
-- @function [parent=#Scene] GetWorldRightXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function GetWorldScale
--
-- @function [parent=#Scene] GetWorldScale
-- @return Vector3#Vector3

---
-- Function GetWorldScaleXYZ
--
-- @function [parent=#Scene] GetWorldScaleXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function GetWorldTransform
--
-- @function [parent=#Scene] GetWorldTransform
-- @return const Matrix3x4#const Matrix3x4

---
-- Function LocalToWorld
--
-- @function [parent=#Scene] LocalToWorld
-- @param Vector3#Vector3 positionposition
-- @return Vector3#Vector3

---
-- Function LocalToWorld
--
-- @function [parent=#Scene] LocalToWorld
-- @param Vector4#Vector4 vectorvector
-- @return Vector3#Vector3

---
-- Function WorldToLocal
--
-- @function [parent=#Scene] WorldToLocal
-- @param Vector3#Vector3 positionposition
-- @return Vector3#Vector3

---
-- Function WorldToLocal
--
-- @function [parent=#Scene] WorldToLocal
-- @param Vector4#Vector4 vectorvector
-- @return Vector3#Vector3

---
-- Function IsDirty
--
-- @function [parent=#Scene] IsDirty
-- @return #boolean

---
-- Function GetNumChildren
--
-- @function [parent=#Scene] GetNumChildren
-- @param #boolean recursiverecursive
-- @return #number

---
-- Function GetChild
--
-- @function [parent=#Scene] GetChild
-- @param #string namename
-- @param #boolean recursiverecursive
-- @return Node#Node

---
-- Function GetChild
--
-- @function [parent=#Scene] GetChild
-- @param StringHash#StringHash nameHashnameHash
-- @param #boolean recursiverecursive
-- @return Node#Node

---
-- Function GetChild
--
-- @function [parent=#Scene] GetChild
-- @param #number indexindex
-- @return Node#Node

---
-- Function GetNumComponents
--
-- @function [parent=#Scene] GetNumComponents
-- @return #number

---
-- Function GetNumNetworkComponents
--
-- @function [parent=#Scene] GetNumNetworkComponents
-- @return #number

---
-- Function HasComponent
--
-- @function [parent=#Scene] HasComponent
-- @param ShortStringHash#ShortStringHash typetype
-- @return #boolean

---
-- Function HasComponent
--
-- @function [parent=#Scene] HasComponent
-- @param #string typetype
-- @return #boolean

---
-- Function GetVar
--
-- @function [parent=#Scene] GetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @return const Variant#const Variant

---
-- Function GetVars
--
-- @function [parent=#Scene] GetVars
-- @return const VariantMap#const VariantMap

---
-- Function GetComponent
--
-- @function [parent=#Scene] GetComponent
-- @param #string typetype
-- @return Component#Component

---
-- Function SetID
--
-- @function [parent=#Scene] SetID
-- @param #number idid

---
-- Function SetScene
--
-- @function [parent=#Scene] SetScene
-- @param Scene#Scene scenescene

---
-- Function ResetScene
--
-- @function [parent=#Scene] ResetScene

---
-- Function Load
--
-- @function [parent=#Scene] Load
-- @param Deserializer#Deserializer sourcesource
-- @param SceneResolver#SceneResolver resolverresolver
-- @param #boolean loadChildrenloadChildren
-- @param #boolean rewriteIDsrewriteIDs
-- @param CreateMode#CreateMode modemode
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#Scene] LoadXML
-- @param XMLElement#XMLElement sourcesource
-- @param SceneResolver#SceneResolver resolverresolver
-- @param #boolean loadChildrenloadChildren
-- @param #boolean rewriteIDsrewriteIDs
-- @param CreateMode#CreateMode modemode
-- @return #boolean

---
-- Function CreateChild
--
-- @function [parent=#Scene] CreateChild
-- @param #number idid
-- @param CreateMode#CreateMode modemode
-- @return Node#Node

---
-- Function AddComponent
--
-- @function [parent=#Scene] AddComponent
-- @param Component#Component componentcomponent
-- @param #number idid
-- @param CreateMode#CreateMode modemode

---
-- Field ID
--
-- @field [parent=#Scene] #number ID

---
-- Field name
--
-- @field [parent=#Scene] #string name

---
-- Field nameHash (Read only)
--
-- @field [parent=#Scene] StringHash#StringHash nameHash

---
-- Field parent
--
-- @field [parent=#Scene] Node#Node parent

---
-- Field scene
--
-- @field [parent=#Scene] Scene#Scene scene

---
-- Field enabled
--
-- @field [parent=#Scene] #boolean enabled

---
-- Field owner
--
-- @field [parent=#Scene] Connection#Connection owner

---
-- Field position
--
-- @field [parent=#Scene] Vector3#Vector3 position

---
-- Field rotation
--
-- @field [parent=#Scene] Quaternion#Quaternion rotation

---
-- Field direction
--
-- @field [parent=#Scene] Vector3#Vector3 direction

---
-- Field up (Read only)
--
-- @field [parent=#Scene] Vector3#Vector3 up

---
-- Field right (Read only)
--
-- @field [parent=#Scene] Vector3#Vector3 right

---
-- Field scale
--
-- @field [parent=#Scene] Vector3#Vector3 scale

---
-- Field transform (Read only)
--
-- @field [parent=#Scene] Matrix3x4#Matrix3x4 transform

---
-- Field worldPosition
--
-- @field [parent=#Scene] Vector3#Vector3 worldPosition

---
-- Field worldRotation
--
-- @field [parent=#Scene] Quaternion#Quaternion worldRotation

---
-- Field worldDirection
--
-- @field [parent=#Scene] Vector3#Vector3 worldDirection

---
-- Field worldUp (Read only)
--
-- @field [parent=#Scene] Vector3#Vector3 worldUp

---
-- Field worldRight (Read only)
--
-- @field [parent=#Scene] Vector3#Vector3 worldRight

---
-- Field worldScale
--
-- @field [parent=#Scene] Vector3#Vector3 worldScale

---
-- Field worldTransform (Read only)
--
-- @field [parent=#Scene] Matrix3x4#Matrix3x4 worldTransform

---
-- Field dirty (Read only)
--
-- @field [parent=#Scene] #boolean dirty

---
-- Field numComponents (Read only)
--
-- @field [parent=#Scene] #number numComponents

---
-- Field numNetworkComponents (Read only)
--
-- @field [parent=#Scene] #number numNetworkComponents

---
-- Function SetTemporary
--
-- @function [parent=#Scene] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#Scene] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Scene] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Scene] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Scene] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Scene] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Scene] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Scene] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#Scene] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Scene] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Scene] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Scene] #string category


return nil
