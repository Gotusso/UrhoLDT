---
-- Module Scene
-- Module Scene extends Node
-- Generated on 2014-05-31
--
-- @module Scene

---
-- Function Scene()
--
-- @function [parent=#Scene] Scene
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#Scene] new
-- @param self Self reference
-- @return Scene#Scene

---
-- Function delete()
--
-- @function [parent=#Scene] delete
-- @param self Self reference

---
-- Function Load()
--
-- @function [parent=#Scene] Load
-- @param self Self reference
-- @param File#File source source
-- @return #boolean

---
-- Function Save()
--
-- @function [parent=#Scene] Save
-- @param self Self reference
-- @param File#File dest dest
-- @return #boolean

---
-- Function Load()
--
-- @function [parent=#Scene] Load
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function Save()
--
-- @function [parent=#Scene] Save
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function LoadXML()
--
-- @function [parent=#Scene] LoadXML
-- @param self Self reference
-- @param File#File source source
-- @return #boolean

---
-- Function SaveXML()
--
-- @function [parent=#Scene] SaveXML
-- @param self Self reference
-- @param File#File dest dest
-- @return #boolean

---
-- Function LoadXML()
--
-- @function [parent=#Scene] LoadXML
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function SaveXML()
--
-- @function [parent=#Scene] SaveXML
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function Instantiate()
--
-- @function [parent=#Scene] Instantiate
-- @param self Self reference
-- @param File#File source source
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation
-- @param CreateMode#CreateMode mode mode
-- @return Node#Node

---
-- Function Instantiate()
--
-- @function [parent=#Scene] Instantiate
-- @param self Self reference
-- @param #string fileName fileName
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation
-- @param CreateMode#CreateMode mode mode
-- @return Node#Node

---
-- Function InstantiateXML()
--
-- @function [parent=#Scene] InstantiateXML
-- @param self Self reference
-- @param File#File source source
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation
-- @param CreateMode#CreateMode mode mode
-- @return Node#Node

---
-- Function InstantiateXML()
--
-- @function [parent=#Scene] InstantiateXML
-- @param self Self reference
-- @param #string fileName fileName
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation
-- @param CreateMode#CreateMode mode mode
-- @return Node#Node

---
-- Function LoadAsync()
-- Load from a binary file asynchronously. Return true if started successfully.
--
-- @function [parent=#Scene] LoadAsync
-- @param self Self reference
-- @param File#File file file
-- @return #boolean

---
-- Function LoadAsyncXML()
-- Load from an XML file asynchronously. Return true if started successfully.
--
-- @function [parent=#Scene] LoadAsyncXML
-- @param self Self reference
-- @param File#File file file
-- @return #boolean

---
-- Function LoadAsync()
--
-- @function [parent=#Scene] LoadAsync
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function LoadAsyncXML()
--
-- @function [parent=#Scene] LoadAsyncXML
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function StopAsyncLoading()
-- Stop asynchronous loading.
--
-- @function [parent=#Scene] StopAsyncLoading
-- @param self Self reference

---
-- Function Clear()
-- Clear scene completely of either replicated, local or all nodes and components.
--
-- @function [parent=#Scene] Clear
-- @param self Self reference
-- @param #boolean clearReplicated clearReplicated
-- @param #boolean clearLocal clearLocal

---
-- Function SetUpdateEnabled()
-- Enable or disable scene update.
--
-- @function [parent=#Scene] SetUpdateEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetTimeScale()
-- Set update time scale. 1.0 = real time (default.)
--
-- @function [parent=#Scene] SetTimeScale
-- @param self Self reference
-- @param #number scale scale

---
-- Function SetElapsedTime()
-- Set elapsed time in seconds. This can be used to prevent inaccuracy in the timer if the scene runs for a long time.
--
-- @function [parent=#Scene] SetElapsedTime
-- @param self Self reference
-- @param #number time time

---
-- Function SetSmoothingConstant()
-- Set network client motion smoothing constant.
--
-- @function [parent=#Scene] SetSmoothingConstant
-- @param self Self reference
-- @param #number constant constant

---
-- Function SetSnapThreshold()
-- Set network client motion smoothing snap threshold.
--
-- @function [parent=#Scene] SetSnapThreshold
-- @param self Self reference
-- @param #number threshold threshold

---
-- Function GetNode()
-- Return node from the whole scene by ID, or null if not found.
--
-- @function [parent=#Scene] GetNode
-- @param self Self reference
-- @param #number id id
-- @return Node#Node

---
-- Function IsUpdateEnabled()
-- Return whether updates are enabled.
--
-- @function [parent=#Scene] IsUpdateEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsAsyncLoading()
-- Return whether an asynchronous loading operation is in progress.
--
-- @function [parent=#Scene] IsAsyncLoading
-- @param self Self reference
-- @return #boolean

---
-- Function GetAsyncProgress()
-- Return asynchronous loading progress between 0.0 and 1.0, or 1.0 if not in progress.
--
-- @function [parent=#Scene] GetAsyncProgress
-- @param self Self reference
-- @return #number

---
-- Function GetFileName()
-- Return source file name.
--
-- @function [parent=#Scene] GetFileName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetChecksum()
-- Return source file checksum.
--
-- @function [parent=#Scene] GetChecksum
-- @param self Self reference
-- @return #number

---
-- Function GetTimeScale()
-- Return update time scale.
--
-- @function [parent=#Scene] GetTimeScale
-- @param self Self reference
-- @return #number

---
-- Function GetElapsedTime()
-- Return elapsed time in seconds.
--
-- @function [parent=#Scene] GetElapsedTime
-- @param self Self reference
-- @return #number

---
-- Function GetSmoothingConstant()
-- Return motion smoothing constant.
--
-- @function [parent=#Scene] GetSmoothingConstant
-- @param self Self reference
-- @return #number

---
-- Function GetSnapThreshold()
-- Return motion smoothing snap threshold.
--
-- @function [parent=#Scene] GetSnapThreshold
-- @param self Self reference
-- @return #number

---
-- Function GetVarName()
-- Return a node user variable name, or empty if not registered.
--
-- @function [parent=#Scene] GetVarName
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash hash hash
-- @return const String#const String

---
-- Function Update()
-- Update scene. Called by HandleUpdate.
--
-- @function [parent=#Scene] Update
-- @param self Self reference
-- @param #number timeStep timeStep

---
-- Function BeginThreadedUpdate()
-- Begin a threaded update. During threaded update components can choose to delay dirty processing.
--
-- @function [parent=#Scene] BeginThreadedUpdate
-- @param self Self reference

---
-- Function EndThreadedUpdate()
-- End a threaded update. Notify components that marked themselves for delayed dirty processing.
--
-- @function [parent=#Scene] EndThreadedUpdate
-- @param self Self reference

---
-- Function DelayedMarkedDirty()
-- Add a component to the delayed dirty notify queue. Is thread-safe.
--
-- @function [parent=#Scene] DelayedMarkedDirty
-- @param self Self reference
-- @param Component#Component component component

---
-- Function IsThreadedUpdate()
-- Return threaded update flag.
--
-- @function [parent=#Scene] IsThreadedUpdate
-- @param self Self reference
-- @return #boolean

---
-- Function GetFreeNodeID()
-- Get free node ID, either non-local or local.
--
-- @function [parent=#Scene] GetFreeNodeID
-- @param self Self reference
-- @param CreateMode#CreateMode mode mode
-- @return #number

---
-- Function GetFreeComponentID()
-- Get free component ID, either non-local or local.
--
-- @function [parent=#Scene] GetFreeComponentID
-- @param self Self reference
-- @param CreateMode#CreateMode mode mode
-- @return #number

---
-- Function NodeAdded()
-- Node added. Assign scene pointer and add to ID map.
--
-- @function [parent=#Scene] NodeAdded
-- @param self Self reference
-- @param Node#Node node node

---
-- Function NodeRemoved()
-- Node removed. Remove from ID map.
--
-- @function [parent=#Scene] NodeRemoved
-- @param self Self reference
-- @param Node#Node node node

---
-- Function ComponentAdded()
-- Component added. Add to ID map.
--
-- @function [parent=#Scene] ComponentAdded
-- @param self Self reference
-- @param Component#Component component component

---
-- Function ComponentRemoved()
-- Component removed. Remove from ID map.
--
-- @function [parent=#Scene] ComponentRemoved
-- @param self Self reference
-- @param Component#Component component component

---
-- Function SetVarNamesAttr()
-- Set node user variable reverse mappings.
--
-- @function [parent=#Scene] SetVarNamesAttr
-- @param self Self reference
-- @param #string value value

---
-- Function GetVarNamesAttr()
-- Return node user variable reverse mappings.
--
-- @function [parent=#Scene] GetVarNamesAttr
-- @param self Self reference
-- @return #string

---
-- Function PrepareNetworkUpdate()
-- Prepare network update by comparing attributes and marking replication states dirty as necessary.
--
-- @function [parent=#Scene] PrepareNetworkUpdate
-- @param self Self reference

---
-- Function CleanupConnection()
-- Clean up all references to a network connection that is about to be removed.
--
-- @function [parent=#Scene] CleanupConnection
-- @param self Self reference
-- @param Connection#Connection connection connection

---
-- Function MarkNetworkUpdate()
-- Mark a node for attribute check on the next network update.
--
-- @function [parent=#Scene] MarkNetworkUpdate
-- @param self Self reference
-- @param Node#Node node node

---
-- Function MarkNetworkUpdate()
-- Mark a comoponent for attribute check on the next network update.
--
-- @function [parent=#Scene] MarkNetworkUpdate
-- @param self Self reference
-- @param Component#Component component component

---
-- Function MarkReplicationDirty()
-- Mark a node dirty in scene replication states. The node does not need to have own replication state yet.
--
-- @function [parent=#Scene] MarkReplicationDirty
-- @param self Self reference
-- @param Node#Node node node

---
-- Field updateEnabled
--
-- @field [parent=#Scene] #boolean updateEnabled

---
-- Field asyncLoading (Read only)
--
-- @field [parent=#Scene] #boolean asyncLoading

---
-- Field asyncProgress (Read only)
--
-- @field [parent=#Scene] #number asyncProgress

---
-- Field fileName
--
-- @field [parent=#Scene] #string fileName

---
-- Field checksum (Read only)
--
-- @field [parent=#Scene] #number checksum

---
-- Field timeScale
--
-- @field [parent=#Scene] #number timeScale

---
-- Field elapsedTime
--
-- @field [parent=#Scene] #number elapsedTime

---
-- Field smoothingConstant
--
-- @field [parent=#Scene] #number smoothingConstant

---
-- Field snapThreshold
--
-- @field [parent=#Scene] #number snapThreshold

---
-- Field threadedUpdate (Read only)
--
-- @field [parent=#Scene] #boolean threadedUpdate

---
-- Field varNamesAttr
--
-- @field [parent=#Scene] #string varNamesAttr


return nil
