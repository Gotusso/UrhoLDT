---
-- Module VariantMap
-- Generated on 2014-05-31
--
-- @module VariantMap

---
-- Function VariantMap()
--
-- @function [parent=#VariantMap] VariantMap
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#VariantMap] new
-- @param self Self reference
-- @return VariantMap#VariantMap

---
-- Function delete()
--
-- @function [parent=#VariantMap] delete
-- @param self Self reference

---
-- Function SetInt()
--
-- @function [parent=#VariantMap] SetInt
-- @param self Self reference
-- @param #string key key
-- @param #number value value

---
-- Function SetUInt()
--
-- @function [parent=#VariantMap] SetUInt
-- @param self Self reference
-- @param #string key key
-- @param #number value value

---
-- Function SetStringHash()
--
-- @function [parent=#VariantMap] SetStringHash
-- @param self Self reference
-- @param #string key key
-- @param StringHash#StringHash value value

---
-- Function SetShortStringHash()
--
-- @function [parent=#VariantMap] SetShortStringHash
-- @param self Self reference
-- @param #string key key
-- @param ShortStringHash#ShortStringHash value value

---
-- Function SetBool()
--
-- @function [parent=#VariantMap] SetBool
-- @param self Self reference
-- @param #string key key
-- @param #boolean value value

---
-- Function SetFloat()
--
-- @function [parent=#VariantMap] SetFloat
-- @param self Self reference
-- @param #string key key
-- @param #number value value

---
-- Function SetVector2()
--
-- @function [parent=#VariantMap] SetVector2
-- @param self Self reference
-- @param #string key key
-- @param Vector2#Vector2 value value

---
-- Function SetVector3()
--
-- @function [parent=#VariantMap] SetVector3
-- @param self Self reference
-- @param #string key key
-- @param Vector3#Vector3 value value

---
-- Function SetVector4()
--
-- @function [parent=#VariantMap] SetVector4
-- @param self Self reference
-- @param #string key key
-- @param Vector4#Vector4 value value

---
-- Function SetQuaternion()
--
-- @function [parent=#VariantMap] SetQuaternion
-- @param self Self reference
-- @param #string key key
-- @param Quaternion#Quaternion value value

---
-- Function SetColor()
--
-- @function [parent=#VariantMap] SetColor
-- @param self Self reference
-- @param #string key key
-- @param Color#Color value value

---
-- Function SetString()
--
-- @function [parent=#VariantMap] SetString
-- @param self Self reference
-- @param #string key key
-- @param #string value value

---
-- Function SetBuffer()
--
-- @function [parent=#VariantMap] SetBuffer
-- @param self Self reference
-- @param #string key key
-- @param VectorBuffer#VectorBuffer value value

---
-- Function SetResourceRef()
--
-- @function [parent=#VariantMap] SetResourceRef
-- @param self Self reference
-- @param #string key key
-- @param ResourceRef#ResourceRef value value

---
-- Function SetResourceRefList()
--
-- @function [parent=#VariantMap] SetResourceRefList
-- @param self Self reference
-- @param #string key key
-- @param ResourceRefList#ResourceRefList value value

---
-- Function SetIntRect()
--
-- @function [parent=#VariantMap] SetIntRect
-- @param self Self reference
-- @param #string key key
-- @param IntRect#IntRect value value

---
-- Function SetIntVector2()
--
-- @function [parent=#VariantMap] SetIntVector2
-- @param self Self reference
-- @param #string key key
-- @param IntVector2#IntVector2 value value

---
-- Function SetPtr()
--
-- @function [parent=#VariantMap] SetPtr
-- @param self Self reference
-- @param #string key key
-- @param void*#void* value value

---
-- Function SetMatrix3()
--
-- @function [parent=#VariantMap] SetMatrix3
-- @param self Self reference
-- @param #string key key
-- @param Matrix3#Matrix3 value value

---
-- Function SetMatrix3x4()
--
-- @function [parent=#VariantMap] SetMatrix3x4
-- @param self Self reference
-- @param #string key key
-- @param Matrix3x4#Matrix3x4 value value

---
-- Function SetMatrix4()
--
-- @function [parent=#VariantMap] SetMatrix4
-- @param self Self reference
-- @param #string key key
-- @param Matrix4#Matrix4 value value

---
-- Function GetInt()
--
-- @function [parent=#VariantMap] GetInt
-- @param self Self reference
-- @param #string key key
-- @return #number

---
-- Function GetUInt()
--
-- @function [parent=#VariantMap] GetUInt
-- @param self Self reference
-- @param #string key key
-- @return #number

---
-- Function GetStringHash()
--
-- @function [parent=#VariantMap] GetStringHash
-- @param self Self reference
-- @param #string key key
-- @return StringHash#StringHash

---
-- Function GetShortStringHash()
--
-- @function [parent=#VariantMap] GetShortStringHash
-- @param self Self reference
-- @param #string key key
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBool()
--
-- @function [parent=#VariantMap] GetBool
-- @param self Self reference
-- @param #string key key
-- @return #boolean

---
-- Function GetFloat()
--
-- @function [parent=#VariantMap] GetFloat
-- @param self Self reference
-- @param #string key key
-- @return #number

---
-- Function GetVector2()
--
-- @function [parent=#VariantMap] GetVector2
-- @param self Self reference
-- @param #string key key
-- @return const Vector2#const Vector2

---
-- Function GetVector3()
--
-- @function [parent=#VariantMap] GetVector3
-- @param self Self reference
-- @param #string key key
-- @return const Vector3#const Vector3

---
-- Function GetVector4()
--
-- @function [parent=#VariantMap] GetVector4
-- @param self Self reference
-- @param #string key key
-- @return const Vector4#const Vector4

---
-- Function GetQuaternion()
--
-- @function [parent=#VariantMap] GetQuaternion
-- @param self Self reference
-- @param #string key key
-- @return const Quaternion#const Quaternion

---
-- Function GetColor()
--
-- @function [parent=#VariantMap] GetColor
-- @param self Self reference
-- @param #string key key
-- @return const Color#const Color

---
-- Function GetString()
--
-- @function [parent=#VariantMap] GetString
-- @param self Self reference
-- @param #string key key
-- @return const String#const String

---
-- Function GetBuffer()
--
-- @function [parent=#VariantMap] GetBuffer
-- @param self Self reference
-- @param #string key key
-- @return VectorBuffer#VectorBuffer

---
-- Function GetResourceRef()
--
-- @function [parent=#VariantMap] GetResourceRef
-- @param self Self reference
-- @param #string key key
-- @return const ResourceRef#const ResourceRef

---
-- Function GetResourceRefList()
--
-- @function [parent=#VariantMap] GetResourceRefList
-- @param self Self reference
-- @param #string key key
-- @return const ResourceRefList#const ResourceRefList

---
-- Function GetIntRect()
--
-- @function [parent=#VariantMap] GetIntRect
-- @param self Self reference
-- @param #string key key
-- @return const IntRect#const IntRect

---
-- Function GetIntVector2()
--
-- @function [parent=#VariantMap] GetIntVector2
-- @param self Self reference
-- @param #string key key
-- @return const IntVector2#const IntVector2

---
-- Function GetPtr()
--
-- @function [parent=#VariantMap] GetPtr
-- @param self Self reference
-- @param #string type type
-- @param #string key key
-- @return const void*#const void*

---
-- Function GetMatrix3()
--
-- @function [parent=#VariantMap] GetMatrix3
-- @param self Self reference
-- @param #string key key
-- @return const Matrix3#const Matrix3

---
-- Function GetMatrix3x4()
--
-- @function [parent=#VariantMap] GetMatrix3x4
-- @param self Self reference
-- @param #string key key
-- @return const Matrix3x4#const Matrix3x4

---
-- Function GetMatrix4()
--
-- @function [parent=#VariantMap] GetMatrix4
-- @param self Self reference
-- @param #string key key
-- @return const Matrix4#const Matrix4


return nil
