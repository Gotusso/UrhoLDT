---
-- Module VariantMap
--
-- @module VariantMap

---
-- Function VariantMap
--
-- @function [parent=#VariantMap] VariantMap

---
-- Function new
--
-- @function [parent=#VariantMap] new
-- @return VariantMap#VariantMap

---
-- Function delete
--
-- @function [parent=#VariantMap] delete

---
-- Function SetInt
--
-- @function [parent=#VariantMap] SetInt
-- @param #string keykey
-- @param #number valuevalue

---
-- Function SetUInt
--
-- @function [parent=#VariantMap] SetUInt
-- @param #string keykey
-- @param #number valuevalue

---
-- Function SetStringHash
--
-- @function [parent=#VariantMap] SetStringHash
-- @param #string keykey
-- @param StringHash#StringHash valuevalue

---
-- Function SetShortStringHash
--
-- @function [parent=#VariantMap] SetShortStringHash
-- @param #string keykey
-- @param ShortStringHash#ShortStringHash valuevalue

---
-- Function SetBool
--
-- @function [parent=#VariantMap] SetBool
-- @param #string keykey
-- @param #boolean valuevalue

---
-- Function SetFloat
--
-- @function [parent=#VariantMap] SetFloat
-- @param #string keykey
-- @param #number valuevalue

---
-- Function SetVector2
--
-- @function [parent=#VariantMap] SetVector2
-- @param #string keykey
-- @param Vector2#Vector2 valuevalue

---
-- Function SetVector3
--
-- @function [parent=#VariantMap] SetVector3
-- @param #string keykey
-- @param Vector3#Vector3 valuevalue

---
-- Function SetVector4
--
-- @function [parent=#VariantMap] SetVector4
-- @param #string keykey
-- @param Vector4#Vector4 valuevalue

---
-- Function SetQuaternion
--
-- @function [parent=#VariantMap] SetQuaternion
-- @param #string keykey
-- @param Quaternion#Quaternion valuevalue

---
-- Function SetColor
--
-- @function [parent=#VariantMap] SetColor
-- @param #string keykey
-- @param Color#Color valuevalue

---
-- Function SetString
--
-- @function [parent=#VariantMap] SetString
-- @param #string keykey
-- @param #string valuevalue

---
-- Function SetBuffer
--
-- @function [parent=#VariantMap] SetBuffer
-- @param #string keykey
-- @param VectorBuffer#VectorBuffer valuevalue

---
-- Function SetResourceRef
--
-- @function [parent=#VariantMap] SetResourceRef
-- @param #string keykey
-- @param ResourceRef#ResourceRef valuevalue

---
-- Function SetResourceRefList
--
-- @function [parent=#VariantMap] SetResourceRefList
-- @param #string keykey
-- @param ResourceRefList#ResourceRefList valuevalue

---
-- Function SetIntRect
--
-- @function [parent=#VariantMap] SetIntRect
-- @param #string keykey
-- @param IntRect#IntRect valuevalue

---
-- Function SetIntVector2
--
-- @function [parent=#VariantMap] SetIntVector2
-- @param #string keykey
-- @param IntVector2#IntVector2 valuevalue

---
-- Function SetPtr
--
-- @function [parent=#VariantMap] SetPtr
-- @param #string keykey
-- @param void*#void* valuevalue

---
-- Function GetInt
--
-- @function [parent=#VariantMap] GetInt
-- @param #string keykey
-- @return #number

---
-- Function GetUInt
--
-- @function [parent=#VariantMap] GetUInt
-- @param #string keykey
-- @return #number

---
-- Function GetStringHash
--
-- @function [parent=#VariantMap] GetStringHash
-- @param #string keykey
-- @return StringHash#StringHash

---
-- Function GetShortStringHash
--
-- @function [parent=#VariantMap] GetShortStringHash
-- @param #string keykey
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBool
--
-- @function [parent=#VariantMap] GetBool
-- @param #string keykey
-- @return #boolean

---
-- Function GetFloat
--
-- @function [parent=#VariantMap] GetFloat
-- @param #string keykey
-- @return #number

---
-- Function GetVector2
--
-- @function [parent=#VariantMap] GetVector2
-- @param #string keykey
-- @return const Vector2#const Vector2

---
-- Function GetVector3
--
-- @function [parent=#VariantMap] GetVector3
-- @param #string keykey
-- @return const Vector3#const Vector3

---
-- Function GetVector4
--
-- @function [parent=#VariantMap] GetVector4
-- @param #string keykey
-- @return const Vector4#const Vector4

---
-- Function GetQuaternion
--
-- @function [parent=#VariantMap] GetQuaternion
-- @param #string keykey
-- @return const Quaternion#const Quaternion

---
-- Function GetColor
--
-- @function [parent=#VariantMap] GetColor
-- @param #string keykey
-- @return const Color#const Color

---
-- Function GetString
--
-- @function [parent=#VariantMap] GetString
-- @param #string keykey
-- @return const String#const String

---
-- Function GetBuffer
--
-- @function [parent=#VariantMap] GetBuffer
-- @param #string keykey
-- @return VectorBuffer#VectorBuffer

---
-- Function GetResourceRef
--
-- @function [parent=#VariantMap] GetResourceRef
-- @param #string keykey
-- @return const ResourceRef#const ResourceRef

---
-- Function GetResourceRefList
--
-- @function [parent=#VariantMap] GetResourceRefList
-- @param #string keykey
-- @return const ResourceRefList#const ResourceRefList

---
-- Function GetIntRect
--
-- @function [parent=#VariantMap] GetIntRect
-- @param #string keykey
-- @return const IntRect#const IntRect

---
-- Function GetIntVector2
--
-- @function [parent=#VariantMap] GetIntVector2
-- @param #string keykey
-- @return const IntVector2#const IntVector2

---
-- Function GetPtr
--
-- @function [parent=#VariantMap] GetPtr
-- @param #string typetype
-- @param #string keykey
-- @return const void*#const void*


return nil
