---
-- Module Time
-- Extends Object
--
-- @module Time

---
-- Function GetFrameNumber
--
-- @function [parent=#Time] GetFrameNumber
-- @return #number

---
-- Function GetTimeStep
--
-- @function [parent=#Time] GetTimeStep
-- @return #number

---
-- Function GetTimerPeriod
--
-- @function [parent=#Time] GetTimerPeriod
-- @return #number

---
-- Function GetElapsedTime
--
-- @function [parent=#Time] GetElapsedTime
-- @return #number

---
-- Function GetSystemTime
--
-- @function [parent=#Time] GetSystemTime
-- @return #number

---
-- Function GetTimeStamp
--
-- @function [parent=#Time] GetTimeStamp
-- @return #string

---
-- Function Sleep
--
-- @function [parent=#Time] Sleep
-- @param #number mSecmSec

---
-- Field frameNumber (Read only)
--
-- @field [parent=#Time] #number frameNumber

---
-- Field timeStep (Read only)
--
-- @field [parent=#Time] #number timeStep

---
-- Field timerPeriod (Read only)
--
-- @field [parent=#Time] #number timerPeriod

---
-- Field elapsedTime (Read only)
--
-- @field [parent=#Time] #number elapsedTime


return nil
