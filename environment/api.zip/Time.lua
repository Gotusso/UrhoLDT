---
-- Module Time
-- Module Time extends Object
-- Generated on 2014-05-31
--
-- @module Time

---
-- Function GetFrameNumber()
-- Return frame number, starting from 1 once BeginFrame() is called for the first time.
--
-- @function [parent=#Time] GetFrameNumber
-- @param self Self reference
-- @return #number

---
-- Function GetTimeStep()
-- Return current frame timestep as seconds.
--
-- @function [parent=#Time] GetTimeStep
-- @param self Self reference
-- @return #number

---
-- Function GetTimerPeriod()
-- Return current low-resolution timer period in milliseconds.
--
-- @function [parent=#Time] GetTimerPeriod
-- @param self Self reference
-- @return #number

---
-- Function GetElapsedTime()
-- Return elapsed time from program start as seconds.
--
-- @function [parent=#Time] GetElapsedTime
-- @param self Self reference
-- @return #number

---
-- Function GetSystemTime()
-- Get system time as milliseconds.
--
-- @function [parent=#Time] GetSystemTime
-- @param self Self reference
-- @return #number

---
-- Function GetTimeStamp()
-- Get a date/time stamp as a string.
--
-- @function [parent=#Time] GetTimeStamp
-- @param self Self reference
-- @return #string

---
-- Function Sleep()
-- Sleep for a number of milliseconds.
--
-- @function [parent=#Time] Sleep
-- @param self Self reference
-- @param #number mSec mSec

---
-- Field frameNumber (Read only)
--
-- @field [parent=#Time] #number frameNumber

---
-- Field timeStep (Read only)
--
-- @field [parent=#Time] #number timeStep

---
-- Field timerPeriod (Read only)
--
-- @field [parent=#Time] #number timerPeriod

---
-- Field elapsedTime (Read only)
--
-- @field [parent=#Time] #number elapsedTime


return nil
