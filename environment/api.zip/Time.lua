---
-- Module Time
-- extends Object
--
-- @module Time

---
-- Function GetFrameNumber
--
-- @function [parent=#Time] GetFrameNumber
-- @return #number

---
-- Function GetTimeStep
--
-- @function [parent=#Time] GetTimeStep
-- @return #number

---
-- Function GetTimerPeriod
--
-- @function [parent=#Time] GetTimerPeriod
-- @return #number

---
-- Function GetElapsedTime
--
-- @function [parent=#Time] GetElapsedTime
-- @return #number

---
-- Function GetSystemTime
--
-- @function [parent=#Time] GetSystemTime
-- @return #number

---
-- Function GetTimeStamp
--
-- @function [parent=#Time] GetTimeStamp
-- @return #string

---
-- Function Sleep
--
-- @function [parent=#Time] Sleep
-- @param #number mSecmSec

---
-- Field frameNumber (Read only)
--
-- @field [parent=#Time] #number frameNumber

---
-- Field timeStep (Read only)
--
-- @field [parent=#Time] #number timeStep

---
-- Field timerPeriod (Read only)
--
-- @field [parent=#Time] #number timerPeriod

---
-- Field elapsedTime (Read only)
--
-- @field [parent=#Time] #number elapsedTime

---
-- Function GetType
--
-- @function [parent=#Time] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Time] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Time] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Time] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Time] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#Time] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Time] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Time] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Time] #string category


return nil
