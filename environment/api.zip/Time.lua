---
-- Module Time
-- Module Time extends Object
-- Generated on 2014-03-13
--
-- @module Time

---
-- Function GetFrameNumber
--
-- @function [parent=#Time] GetFrameNumber
-- @param self Self reference
-- @return #number

---
-- Function GetTimeStep
--
-- @function [parent=#Time] GetTimeStep
-- @param self Self reference
-- @return #number

---
-- Function GetTimerPeriod
--
-- @function [parent=#Time] GetTimerPeriod
-- @param self Self reference
-- @return #number

---
-- Function GetElapsedTime
--
-- @function [parent=#Time] GetElapsedTime
-- @param self Self reference
-- @return #number

---
-- Function GetSystemTime
--
-- @function [parent=#Time] GetSystemTime
-- @param self Self reference
-- @return #number

---
-- Function GetTimeStamp
--
-- @function [parent=#Time] GetTimeStamp
-- @param self Self reference
-- @return #string

---
-- Function Sleep
--
-- @function [parent=#Time] Sleep
-- @param self Self reference
-- @param #number mSec mSec

---
-- Field frameNumber (Read only)
--
-- @field [parent=#Time] #number frameNumber

---
-- Field timeStep (Read only)
--
-- @field [parent=#Time] #number timeStep

---
-- Field timerPeriod (Read only)
--
-- @field [parent=#Time] #number timerPeriod

---
-- Field elapsedTime (Read only)
--
-- @field [parent=#Time] #number elapsedTime

---
-- Function GetType
--
-- @function [parent=#Time] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Time] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Time] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Time] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Time] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#Time] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Time] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Time] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Time] #string category


return nil
