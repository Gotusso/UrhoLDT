---
-- Module CollisionBox2D
-- Module CollisionBox2D extends CollisionShape2D
-- Generated on 2014-05-31
--
-- @module CollisionBox2D

---
-- Function SetSize()
-- Set size.
--
-- @function [parent=#CollisionBox2D] SetSize
-- @param self Self reference
-- @param Vector2#Vector2 size size

---
-- Function SetSize()
-- Set size.
--
-- @function [parent=#CollisionBox2D] SetSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetCenter()
-- Set center.
--
-- @function [parent=#CollisionBox2D] SetCenter
-- @param self Self reference
-- @param Vector2#Vector2 center center

---
-- Function SetCenter()
-- Set center.
--
-- @function [parent=#CollisionBox2D] SetCenter
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function SetAngle()
-- Set angle.
--
-- @function [parent=#CollisionBox2D] SetAngle
-- @param self Self reference
-- @param #number angle angle

---
-- Function GetSize()
-- Return size.
--
-- @function [parent=#CollisionBox2D] GetSize
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Function GetCenter()
-- Return center.
--
-- @function [parent=#CollisionBox2D] GetCenter
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Function GetAngle()
-- Return angle.
--
-- @function [parent=#CollisionBox2D] GetAngle
-- @param self Self reference
-- @return #number

---
-- Field size
--
-- @field [parent=#CollisionBox2D] Vector2#Vector2 size

---
-- Field center
--
-- @field [parent=#CollisionBox2D] Vector2#Vector2 center

---
-- Field angle
--
-- @field [parent=#CollisionBox2D] #number angle


return nil
