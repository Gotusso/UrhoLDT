---
-- Module ConstraintPulley2D
-- Module ConstraintPulley2D extends Constraint2D
-- Generated on 2014-05-31
--
-- @module ConstraintPulley2D

---
-- Function SetOwnerBodyGroundAnchor()
-- Set other body ground anchor point.
--
-- @function [parent=#ConstraintPulley2D] SetOwnerBodyGroundAnchor
-- @param self Self reference
-- @param Vector2#Vector2 groundAnchor groundAnchor

---
-- Function SetOtherBodyGroundAnchor()
-- Set other body ground anchor point.
--
-- @function [parent=#ConstraintPulley2D] SetOtherBodyGroundAnchor
-- @param self Self reference
-- @param Vector2#Vector2 groundAnchor groundAnchor

---
-- Function SetOwnerBodyAnchor()
-- Set owner body anchor point.
--
-- @function [parent=#ConstraintPulley2D] SetOwnerBodyAnchor
-- @param self Self reference
-- @param Vector2#Vector2 anchor anchor

---
-- Function SetOtherBodyAnchor()
-- Set other body anchor point.
--
-- @function [parent=#ConstraintPulley2D] SetOtherBodyAnchor
-- @param self Self reference
-- @param Vector2#Vector2 anchor anchor

---
-- Function SetRatio()
-- Set ratio.
--
-- @function [parent=#ConstraintPulley2D] SetRatio
-- @param self Self reference
-- @param #number ratio ratio

---
-- Function GetOwnerBodyGroundAnchor()
-- Return owner body ground anchor.
--
-- @function [parent=#ConstraintPulley2D] GetOwnerBodyGroundAnchor
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Function GetOtherBodyGroundAnchor()
-- return other body ground anchor.
--
-- @function [parent=#ConstraintPulley2D] GetOtherBodyGroundAnchor
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Function GetOwnerBodyAnchor()
-- Return owner body anchor.
--
-- @function [parent=#ConstraintPulley2D] GetOwnerBodyAnchor
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Function GetOtherBodyAnchor()
-- Return other body anchor.
--
-- @function [parent=#ConstraintPulley2D] GetOtherBodyAnchor
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Function GetRatio()
-- Return ratio.
--
-- @function [parent=#ConstraintPulley2D] GetRatio
-- @param self Self reference
-- @return #number

---
-- Field ownerBodyGroundAnchor
--
-- @field [parent=#ConstraintPulley2D] Vector2#Vector2 ownerBodyGroundAnchor

---
-- Field otherBodyGroundAnchor
--
-- @field [parent=#ConstraintPulley2D] Vector2#Vector2 otherBodyGroundAnchor

---
-- Field ownerBodyAnchor
--
-- @field [parent=#ConstraintPulley2D] Vector2#Vector2 ownerBodyAnchor

---
-- Field otherBodyAnchor
--
-- @field [parent=#ConstraintPulley2D] Vector2#Vector2 otherBodyAnchor

---
-- Field ratio
--
-- @field [parent=#ConstraintPulley2D] #number ratio


return nil
