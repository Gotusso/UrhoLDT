---
-- Module ParticleEmitter
-- extends BillboardSet
--
-- @module ParticleEmitter

---
-- Function Load
--
-- @function [parent=#ParticleEmitter] Load
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#ParticleEmitter] Save
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetNumParticles
--
-- @function [parent=#ParticleEmitter] SetNumParticles
-- @param #number numnum

---
-- Function SetEmissionRate
--
-- @function [parent=#ParticleEmitter] SetEmissionRate
-- @param #number raterate

---
-- Function SetMinEmissionRate
--
-- @function [parent=#ParticleEmitter] SetMinEmissionRate
-- @param #number raterate

---
-- Function SetMaxEmissionRate
--
-- @function [parent=#ParticleEmitter] SetMaxEmissionRate
-- @param #number raterate

---
-- Function SetEmitterType
--
-- @function [parent=#ParticleEmitter] SetEmitterType
-- @param EmitterType#EmitterType typetype

---
-- Function SetEmitterSize
--
-- @function [parent=#ParticleEmitter] SetEmitterSize
-- @param Vector3#Vector3 sizesize

---
-- Function SetActiveTime
--
-- @function [parent=#ParticleEmitter] SetActiveTime
-- @param #number timetime

---
-- Function SetInactiveTime
--
-- @function [parent=#ParticleEmitter] SetInactiveTime
-- @param #number timetime

---
-- Function SetEmitting
--
-- @function [parent=#ParticleEmitter] SetEmitting
-- @param #boolean enableenable
-- @param #boolean resetPeriodresetPeriod

---
-- Function SetUpdateInvisible
--
-- @function [parent=#ParticleEmitter] SetUpdateInvisible
-- @param #boolean enableenable

---
-- Function SetTimeToLive
--
-- @function [parent=#ParticleEmitter] SetTimeToLive
-- @param #number timetime

---
-- Function SetMinTimeToLive
--
-- @function [parent=#ParticleEmitter] SetMinTimeToLive
-- @param #number timetime

---
-- Function SetMaxTimeToLive
--
-- @function [parent=#ParticleEmitter] SetMaxTimeToLive
-- @param #number timetime

---
-- Function SetParticleSize
--
-- @function [parent=#ParticleEmitter] SetParticleSize
-- @param Vector2#Vector2 sizesize

---
-- Function SetMinParticleSize
--
-- @function [parent=#ParticleEmitter] SetMinParticleSize
-- @param Vector2#Vector2 sizesize

---
-- Function SetMaxParticleSize
--
-- @function [parent=#ParticleEmitter] SetMaxParticleSize
-- @param Vector2#Vector2 sizesize

---
-- Function SetMinDirection
--
-- @function [parent=#ParticleEmitter] SetMinDirection
-- @param Vector3#Vector3 directiondirection

---
-- Function SetMaxDirection
--
-- @function [parent=#ParticleEmitter] SetMaxDirection
-- @param Vector3#Vector3 directiondirection

---
-- Function SetVelocity
--
-- @function [parent=#ParticleEmitter] SetVelocity
-- @param #number velocityvelocity

---
-- Function SetMinVelocity
--
-- @function [parent=#ParticleEmitter] SetMinVelocity
-- @param #number velocityvelocity

---
-- Function SetMaxVelocity
--
-- @function [parent=#ParticleEmitter] SetMaxVelocity
-- @param #number velocityvelocity

---
-- Function SetRotation
--
-- @function [parent=#ParticleEmitter] SetRotation
-- @param #number rotationrotation

---
-- Function SetMinRotation
--
-- @function [parent=#ParticleEmitter] SetMinRotation
-- @param #number rotationrotation

---
-- Function SetMaxRotation
--
-- @function [parent=#ParticleEmitter] SetMaxRotation
-- @param #number rotationrotation

---
-- Function SetRotationSpeed
--
-- @function [parent=#ParticleEmitter] SetRotationSpeed
-- @param #number speedspeed

---
-- Function SetMinRotationSpeed
--
-- @function [parent=#ParticleEmitter] SetMinRotationSpeed
-- @param #number speedspeed

---
-- Function SetMaxRotationSpeed
--
-- @function [parent=#ParticleEmitter] SetMaxRotationSpeed
-- @param #number speedspeed

---
-- Function SetConstantForce
--
-- @function [parent=#ParticleEmitter] SetConstantForce
-- @param Vector3#Vector3 forceforce

---
-- Function SetDampingForce
--
-- @function [parent=#ParticleEmitter] SetDampingForce
-- @param #number forceforce

---
-- Function SetSizeAdd
--
-- @function [parent=#ParticleEmitter] SetSizeAdd
-- @param #number sizeAddsizeAdd

---
-- Function SetSizeMul
--
-- @function [parent=#ParticleEmitter] SetSizeMul
-- @param #number sizeMulsizeMul

---
-- Function SetColor
--
-- @function [parent=#ParticleEmitter] SetColor
-- @param Color#Color colorcolor

---
-- Function SetNumColors
--
-- @function [parent=#ParticleEmitter] SetNumColors
-- @param #number numnum

---
-- Function SetNumTextureFrames
--
-- @function [parent=#ParticleEmitter] SetNumTextureFrames
-- @param #number numnum

---
-- Function GetNumParticles
--
-- @function [parent=#ParticleEmitter] GetNumParticles
-- @return #number

---
-- Function IsEmitting
--
-- @function [parent=#ParticleEmitter] IsEmitting
-- @return #boolean

---
-- Function GetUpdateInvisible
--
-- @function [parent=#ParticleEmitter] GetUpdateInvisible
-- @return #boolean

---
-- Function GetMinEmissionRate
--
-- @function [parent=#ParticleEmitter] GetMinEmissionRate
-- @return #number

---
-- Function GetMaxEmissionRate
--
-- @function [parent=#ParticleEmitter] GetMaxEmissionRate
-- @return #number

---
-- Function GetEmitterType
--
-- @function [parent=#ParticleEmitter] GetEmitterType
-- @return EmitterType#EmitterType

---
-- Function GetEmitterSize
--
-- @function [parent=#ParticleEmitter] GetEmitterSize
-- @return const Vector3#const Vector3

---
-- Function GetActiveTime
--
-- @function [parent=#ParticleEmitter] GetActiveTime
-- @return #number

---
-- Function GetInactiveTime
--
-- @function [parent=#ParticleEmitter] GetInactiveTime
-- @return #number

---
-- Function GetMinTimeToLive
--
-- @function [parent=#ParticleEmitter] GetMinTimeToLive
-- @return #number

---
-- Function GetMaxTimeToLive
--
-- @function [parent=#ParticleEmitter] GetMaxTimeToLive
-- @return #number

---
-- Function GetMinParticleSize
--
-- @function [parent=#ParticleEmitter] GetMinParticleSize
-- @return const Vector2#const Vector2

---
-- Function GetMaxParticleSize
--
-- @function [parent=#ParticleEmitter] GetMaxParticleSize
-- @return const Vector2#const Vector2

---
-- Function GetMinDirection
--
-- @function [parent=#ParticleEmitter] GetMinDirection
-- @return const Vector3#const Vector3

---
-- Function GetMaxDirection
--
-- @function [parent=#ParticleEmitter] GetMaxDirection
-- @return const Vector3#const Vector3

---
-- Function GetMinVelocity
--
-- @function [parent=#ParticleEmitter] GetMinVelocity
-- @return #number

---
-- Function GetMaxVelocity
--
-- @function [parent=#ParticleEmitter] GetMaxVelocity
-- @return #number

---
-- Function GetMinRotation
--
-- @function [parent=#ParticleEmitter] GetMinRotation
-- @return #number

---
-- Function GetMaxRotation
--
-- @function [parent=#ParticleEmitter] GetMaxRotation
-- @return #number

---
-- Function GetMinRotationSpeed
--
-- @function [parent=#ParticleEmitter] GetMinRotationSpeed
-- @return #number

---
-- Function GetMaxRotationSpeed
--
-- @function [parent=#ParticleEmitter] GetMaxRotationSpeed
-- @return #number

---
-- Function GetConstantForce
--
-- @function [parent=#ParticleEmitter] GetConstantForce
-- @return const Vector3#const Vector3

---
-- Function GetDampingForce
--
-- @function [parent=#ParticleEmitter] GetDampingForce
-- @return #number

---
-- Function GetSizeAdd
--
-- @function [parent=#ParticleEmitter] GetSizeAdd
-- @return #number

---
-- Function GetSizeMul
--
-- @function [parent=#ParticleEmitter] GetSizeMul
-- @return #number

---
-- Function GetNumColors
--
-- @function [parent=#ParticleEmitter] GetNumColors
-- @return #number

---
-- Function GetColor
--
-- @function [parent=#ParticleEmitter] GetColor
-- @param #number indexindex
-- @return ColorFrame#ColorFrame

---
-- Function GetNumTextureFrames
--
-- @function [parent=#ParticleEmitter] GetNumTextureFrames
-- @return #number

---
-- Function GetTextureFrame
--
-- @function [parent=#ParticleEmitter] GetTextureFrame
-- @param #number indexindex
-- @return TextureFrame#TextureFrame

---
-- Field numParticles
--
-- @field [parent=#ParticleEmitter] #number numParticles

---
-- Field emissionRate
--
-- @field [parent=#ParticleEmitter] #number emissionRate

---
-- Field emitting
--
-- @field [parent=#ParticleEmitter] #boolean emitting

---
-- Field updateInvisible
--
-- @field [parent=#ParticleEmitter] #boolean updateInvisible

---
-- Field minEmissionRate
--
-- @field [parent=#ParticleEmitter] #number minEmissionRate

---
-- Field maxEmissionRate
--
-- @field [parent=#ParticleEmitter] #number maxEmissionRate

---
-- Field emitterType
--
-- @field [parent=#ParticleEmitter] EmitterType#EmitterType emitterType

---
-- Field emitterSize
--
-- @field [parent=#ParticleEmitter] Vector3#Vector3 emitterSize

---
-- Field activeTime
--
-- @field [parent=#ParticleEmitter] #number activeTime

---
-- Field inactiveTime
--
-- @field [parent=#ParticleEmitter] #number inactiveTime

---
-- Field timeToLive
--
-- @field [parent=#ParticleEmitter] #number timeToLive

---
-- Field minTimeToLive
--
-- @field [parent=#ParticleEmitter] #number minTimeToLive

---
-- Field maxTimeToLive
--
-- @field [parent=#ParticleEmitter] #number maxTimeToLive

---
-- Field particleSize
--
-- @field [parent=#ParticleEmitter] Vector2#Vector2 particleSize

---
-- Field minParticleSize
--
-- @field [parent=#ParticleEmitter] Vector2#Vector2 minParticleSize

---
-- Field maxParticleSize
--
-- @field [parent=#ParticleEmitter] Vector2#Vector2 maxParticleSize

---
-- Field minDirection
--
-- @field [parent=#ParticleEmitter] Vector3#Vector3 minDirection

---
-- Field maxDirection
--
-- @field [parent=#ParticleEmitter] Vector3#Vector3 maxDirection

---
-- Field velocity
--
-- @field [parent=#ParticleEmitter] #number velocity

---
-- Field minVelocity
--
-- @field [parent=#ParticleEmitter] #number minVelocity

---
-- Field maxVelocity
--
-- @field [parent=#ParticleEmitter] #number maxVelocity

---
-- Field rotation
--
-- @field [parent=#ParticleEmitter] #number rotation

---
-- Field minRotation
--
-- @field [parent=#ParticleEmitter] #number minRotation

---
-- Field maxRotation
--
-- @field [parent=#ParticleEmitter] #number maxRotation

---
-- Field rotationSpeed
--
-- @field [parent=#ParticleEmitter] #number rotationSpeed

---
-- Field minRotationSpeed
--
-- @field [parent=#ParticleEmitter] #number minRotationSpeed

---
-- Field maxRotationSpeed
--
-- @field [parent=#ParticleEmitter] #number maxRotationSpeed

---
-- Field constantForce
--
-- @field [parent=#ParticleEmitter] Vector3#Vector3 constantForce

---
-- Field dampingForce
--
-- @field [parent=#ParticleEmitter] #number dampingForce

---
-- Field sizeAdd
--
-- @field [parent=#ParticleEmitter] #number sizeAdd

---
-- Field sizeMul
--
-- @field [parent=#ParticleEmitter] #number sizeMul

---
-- Field numColors
--
-- @field [parent=#ParticleEmitter] #number numColors

---
-- Field numTextureFrames
--
-- @field [parent=#ParticleEmitter] #number numTextureFrames

---
-- Function SetMaterial
--
-- @function [parent=#ParticleEmitter] SetMaterial
-- @param Material#Material materialmaterial

---
-- Function SetNumBillboards
--
-- @function [parent=#ParticleEmitter] SetNumBillboards
-- @param #number numnum

---
-- Function SetRelative
--
-- @function [parent=#ParticleEmitter] SetRelative
-- @param #boolean enableenable

---
-- Function SetScaled
--
-- @function [parent=#ParticleEmitter] SetScaled
-- @param #boolean enableenable

---
-- Function SetSorted
--
-- @function [parent=#ParticleEmitter] SetSorted
-- @param #boolean enableenable

---
-- Function SetFaceCamera
--
-- @function [parent=#ParticleEmitter] SetFaceCamera
-- @param #boolean enableenable

---
-- Function SetAnimationLodBias
--
-- @function [parent=#ParticleEmitter] SetAnimationLodBias
-- @param #number biasbias

---
-- Function Commit
--
-- @function [parent=#ParticleEmitter] Commit

---
-- Function GetMaterial
--
-- @function [parent=#ParticleEmitter] GetMaterial
-- @return Material#Material

---
-- Function GetNumBillboards
--
-- @function [parent=#ParticleEmitter] GetNumBillboards
-- @return #number

---
-- Function GetBillboard
--
-- @function [parent=#ParticleEmitter] GetBillboard
-- @param #number indexindex
-- @return Billboard#Billboard

---
-- Function IsRelative
--
-- @function [parent=#ParticleEmitter] IsRelative
-- @return #boolean

---
-- Function IsScaled
--
-- @function [parent=#ParticleEmitter] IsScaled
-- @return #boolean

---
-- Function IsSorted
--
-- @function [parent=#ParticleEmitter] IsSorted
-- @return #boolean

---
-- Function GetFaceCamera
--
-- @function [parent=#ParticleEmitter] GetFaceCamera
-- @return #boolean

---
-- Function GetAnimationLodBias
--
-- @function [parent=#ParticleEmitter] GetAnimationLodBias
-- @return #number

---
-- Field material
--
-- @field [parent=#ParticleEmitter] Material#Material material

---
-- Field numBillboards
--
-- @field [parent=#ParticleEmitter] #number numBillboards

---
-- Field relative
--
-- @field [parent=#ParticleEmitter] #boolean relative

---
-- Field scaled
--
-- @field [parent=#ParticleEmitter] #boolean scaled

---
-- Field sorted
--
-- @field [parent=#ParticleEmitter] #boolean sorted

---
-- Field faceCamera
--
-- @field [parent=#ParticleEmitter] #boolean faceCamera

---
-- Field animationLodBias
--
-- @field [parent=#ParticleEmitter] #number animationLodBias

---
-- Function SetDrawDistance
--
-- @function [parent=#ParticleEmitter] SetDrawDistance
-- @param #number distancedistance

---
-- Function SetShadowDistance
--
-- @function [parent=#ParticleEmitter] SetShadowDistance
-- @param #number distancedistance

---
-- Function SetLodBias
--
-- @function [parent=#ParticleEmitter] SetLodBias
-- @param #number biasbias

---
-- Function SetViewMask
--
-- @function [parent=#ParticleEmitter] SetViewMask
-- @param #number maskmask

---
-- Function SetLightMask
--
-- @function [parent=#ParticleEmitter] SetLightMask
-- @param #number maskmask

---
-- Function SetShadowMask
--
-- @function [parent=#ParticleEmitter] SetShadowMask
-- @param #number maskmask

---
-- Function SetZoneMask
--
-- @function [parent=#ParticleEmitter] SetZoneMask
-- @param #number maskmask

---
-- Function SetMaxLights
--
-- @function [parent=#ParticleEmitter] SetMaxLights
-- @param #number numnum

---
-- Function SetCastShadows
--
-- @function [parent=#ParticleEmitter] SetCastShadows
-- @param #boolean enableenable

---
-- Function SetOccluder
--
-- @function [parent=#ParticleEmitter] SetOccluder
-- @param #boolean enableenable

---
-- Function SetOccludee
--
-- @function [parent=#ParticleEmitter] SetOccludee
-- @param #boolean enableenable

---
-- Function MarkForUpdate
--
-- @function [parent=#ParticleEmitter] MarkForUpdate

---
-- Function GetBoundingBox
--
-- @function [parent=#ParticleEmitter] GetBoundingBox
-- @return const BoundingBox#const BoundingBox

---
-- Function GetWorldBoundingBox
--
-- @function [parent=#ParticleEmitter] GetWorldBoundingBox
-- @return const BoundingBox#const BoundingBox

---
-- Function GetDrawableFlags
--
-- @function [parent=#ParticleEmitter] GetDrawableFlags
-- @return #string

---
-- Function GetDrawDistance
--
-- @function [parent=#ParticleEmitter] GetDrawDistance
-- @return #number

---
-- Function GetShadowDistance
--
-- @function [parent=#ParticleEmitter] GetShadowDistance
-- @return #number

---
-- Function GetLodBias
--
-- @function [parent=#ParticleEmitter] GetLodBias
-- @return #number

---
-- Function GetViewMask
--
-- @function [parent=#ParticleEmitter] GetViewMask
-- @return #number

---
-- Function GetLightMask
--
-- @function [parent=#ParticleEmitter] GetLightMask
-- @return #number

---
-- Function GetShadowMask
--
-- @function [parent=#ParticleEmitter] GetShadowMask
-- @return #number

---
-- Function GetZoneMask
--
-- @function [parent=#ParticleEmitter] GetZoneMask
-- @return #number

---
-- Function GetMaxLights
--
-- @function [parent=#ParticleEmitter] GetMaxLights
-- @return #number

---
-- Function GetCastShadows
--
-- @function [parent=#ParticleEmitter] GetCastShadows
-- @return #boolean

---
-- Function IsOccluder
--
-- @function [parent=#ParticleEmitter] IsOccluder
-- @return #boolean

---
-- Function IsOccludee
--
-- @function [parent=#ParticleEmitter] IsOccludee
-- @return #boolean

---
-- Function SetZone
--
-- @function [parent=#ParticleEmitter] SetZone
-- @param Zone#Zone zonezone
-- @param #boolean temporarytemporary

---
-- Function SetSortValue
--
-- @function [parent=#ParticleEmitter] SetSortValue
-- @param #number valuevalue

---
-- Function SetMinMaxZ
--
-- @function [parent=#ParticleEmitter] SetMinMaxZ
-- @param #number minZminZ
-- @param #number maxZmaxZ

---
-- Function MarkInView
--
-- @function [parent=#ParticleEmitter] MarkInView
-- @param FrameInfo#FrameInfo frameframe
-- @param #boolean mainViewmainView

---
-- Function ClearLights
--
-- @function [parent=#ParticleEmitter] ClearLights

---
-- Function AddLight
--
-- @function [parent=#ParticleEmitter] AddLight
-- @param Light#Light lightlight

---
-- Function AddVertexLight
--
-- @function [parent=#ParticleEmitter] AddVertexLight
-- @param Light#Light lightlight

---
-- Function LimitLights
--
-- @function [parent=#ParticleEmitter] LimitLights

---
-- Function LimitVertexLights
--
-- @function [parent=#ParticleEmitter] LimitVertexLights

---
-- Function SetBasePass
--
-- @function [parent=#ParticleEmitter] SetBasePass
-- @param #number batchIndexbatchIndex

---
-- Function GetOctant
--
-- @function [parent=#ParticleEmitter] GetOctant
-- @return Octant#Octant

---
-- Function GetZone
--
-- @function [parent=#ParticleEmitter] GetZone
-- @return Zone#Zone

---
-- Function GetLastZone
--
-- @function [parent=#ParticleEmitter] GetLastZone
-- @return Zone#Zone

---
-- Function IsZoneDirty
--
-- @function [parent=#ParticleEmitter] IsZoneDirty
-- @return #boolean

---
-- Function GetDistance
--
-- @function [parent=#ParticleEmitter] GetDistance
-- @return #number

---
-- Function GetLodDistance
--
-- @function [parent=#ParticleEmitter] GetLodDistance
-- @return #number

---
-- Function GetSortValue
--
-- @function [parent=#ParticleEmitter] GetSortValue
-- @return #number

---
-- Function IsInView
--
-- @function [parent=#ParticleEmitter] IsInView
-- @param #number frameNumberframeNumber
-- @return #boolean

---
-- Function IsInView
--
-- @function [parent=#ParticleEmitter] IsInView
-- @param FrameInfo#FrameInfo frameframe
-- @param #boolean mainViewmainView
-- @return #boolean

---
-- Function HasBasePass
--
-- @function [parent=#ParticleEmitter] HasBasePass
-- @param #number batchIndexbatchIndex
-- @return #boolean

---
-- Function GetFirstLight
--
-- @function [parent=#ParticleEmitter] GetFirstLight
-- @return Light#Light

---
-- Function GetMinZ
--
-- @function [parent=#ParticleEmitter] GetMinZ
-- @return #number

---
-- Function GetMaxZ
--
-- @function [parent=#ParticleEmitter] GetMaxZ
-- @return #number

---
-- Field worldBoundingBox (Read only)
--
-- @field [parent=#ParticleEmitter] BoundingBox#BoundingBox worldBoundingBox

---
-- Field drawableFlags (Read only)
--
-- @field [parent=#ParticleEmitter] #string drawableFlags

---
-- Field drawDistance
--
-- @field [parent=#ParticleEmitter] #number drawDistance

---
-- Field shadowDistance
--
-- @field [parent=#ParticleEmitter] #number shadowDistance

---
-- Field lodBias
--
-- @field [parent=#ParticleEmitter] #number lodBias

---
-- Field viewMask
--
-- @field [parent=#ParticleEmitter] #number viewMask

---
-- Field lightMask
--
-- @field [parent=#ParticleEmitter] #number lightMask

---
-- Field shadowMask
--
-- @field [parent=#ParticleEmitter] #number shadowMask

---
-- Field zoneMask
--
-- @field [parent=#ParticleEmitter] #number zoneMask

---
-- Field maxLights
--
-- @field [parent=#ParticleEmitter] #number maxLights

---
-- Field castShadows
--
-- @field [parent=#ParticleEmitter] #boolean castShadows

---
-- Field occluder
--
-- @field [parent=#ParticleEmitter] #boolean occluder

---
-- Field occludee
--
-- @field [parent=#ParticleEmitter] #boolean occludee

---
-- Field octant (Read only)
--
-- @field [parent=#ParticleEmitter] Octant#Octant octant

---
-- Field zone
--
-- @field [parent=#ParticleEmitter] Zone#Zone zone

---
-- Field lastZone (Read only)
--
-- @field [parent=#ParticleEmitter] Zone#Zone lastZone

---
-- Field zoneDirty (Read only)
--
-- @field [parent=#ParticleEmitter] #boolean zoneDirty

---
-- Field distance (Read only)
--
-- @field [parent=#ParticleEmitter] #number distance

---
-- Field lodDistance (Read only)
--
-- @field [parent=#ParticleEmitter] #number lodDistance

---
-- Field sortValue
--
-- @field [parent=#ParticleEmitter] #number sortValue

---
-- Field firstLight (Read only)
--
-- @field [parent=#ParticleEmitter] Light#Light firstLight

---
-- Field minZ (Read only)
--
-- @field [parent=#ParticleEmitter] #number minZ

---
-- Field maxZ (Read only)
--
-- @field [parent=#ParticleEmitter] #number maxZ

---
-- Function SetEnabled
--
-- @function [parent=#ParticleEmitter] SetEnabled
-- @param #boolean enableenable

---
-- Function Remove
--
-- @function [parent=#ParticleEmitter] Remove

---
-- Function GetID
--
-- @function [parent=#ParticleEmitter] GetID
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#ParticleEmitter] GetNode
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#ParticleEmitter] GetScene
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#ParticleEmitter] IsEnabled
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#ParticleEmitter] IsEnabledEffective
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#ParticleEmitter] GetComponent
-- @param ShortStringHash#ShortStringHash typetype
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#ParticleEmitter] GetComponent
-- @param #string typetype
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#ParticleEmitter] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#ParticleEmitter] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#ParticleEmitter] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#ParticleEmitter] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#ParticleEmitter] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#ParticleEmitter] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#ParticleEmitter] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#ParticleEmitter] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#ParticleEmitter] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#ParticleEmitter] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#ParticleEmitter] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#ParticleEmitter] #string category


return nil
