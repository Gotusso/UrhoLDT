---
-- Module ParticleEmitter
-- Module ParticleEmitter extends BillboardSet
-- Generated on 2014-05-31
--
-- @module ParticleEmitter

---
-- Function Load()
-- Load emitter parameters from an XML file.
--
-- @function [parent=#ParticleEmitter] Load
-- @param self Self reference
-- @param XMLFile#XMLFile file file
-- @return #boolean

---
-- Function Save()
-- Save particle emitter parameters to an XML file. Return true if successful.
--
-- @function [parent=#ParticleEmitter] Save
-- @param self Self reference
-- @param XMLFile#XMLFile file file
-- @return #boolean

---
-- Function SetNumParticles()
-- Set maximum number of particles.
--
-- @function [parent=#ParticleEmitter] SetNumParticles
-- @param self Self reference
-- @param #number num num

---
-- Function SetEmissionRate()
-- Set emission rate (both minimum and maximum.)
--
-- @function [parent=#ParticleEmitter] SetEmissionRate
-- @param self Self reference
-- @param #number rate rate

---
-- Function SetMinEmissionRate()
-- Set minimum emission rate.
--
-- @function [parent=#ParticleEmitter] SetMinEmissionRate
-- @param self Self reference
-- @param #number rate rate

---
-- Function SetMaxEmissionRate()
-- Set maximum emission rate.
--
-- @function [parent=#ParticleEmitter] SetMaxEmissionRate
-- @param self Self reference
-- @param #number rate rate

---
-- Function SetEmitterType()
-- Set emitter type.
--
-- @function [parent=#ParticleEmitter] SetEmitterType
-- @param self Self reference
-- @param EmitterType#EmitterType type type

---
-- Function SetEmitterSize()
-- Set emitter size.
--
-- @function [parent=#ParticleEmitter] SetEmitterSize
-- @param self Self reference
-- @param Vector3#Vector3 size size

---
-- Function SetActiveTime()
-- Set emission active period length (0 = infinite.)
--
-- @function [parent=#ParticleEmitter] SetActiveTime
-- @param self Self reference
-- @param #number time time

---
-- Function SetInactiveTime()
-- Set emission inactive period length (0 = infinite.)
--
-- @function [parent=#ParticleEmitter] SetInactiveTime
-- @param self Self reference
-- @param #number time time

---
-- Function SetEmitting()
-- Set whether should be emitting and optionally reset emission period.
--
-- @function [parent=#ParticleEmitter] SetEmitting
-- @param self Self reference
-- @param #boolean enable enable
-- @param #boolean resetPeriod resetPeriod

---
-- Function SetUpdateInvisible()
-- Set whether to update when particles are not visible.
--
-- @function [parent=#ParticleEmitter] SetUpdateInvisible
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetTimeToLive()
-- Set particle time to live (both minimum and maximum.)
--
-- @function [parent=#ParticleEmitter] SetTimeToLive
-- @param self Self reference
-- @param #number time time

---
-- Function SetMinTimeToLive()
-- Set particle minimum time to live.
--
-- @function [parent=#ParticleEmitter] SetMinTimeToLive
-- @param self Self reference
-- @param #number time time

---
-- Function SetMaxTimeToLive()
-- Set particle maximum time to live.
--
-- @function [parent=#ParticleEmitter] SetMaxTimeToLive
-- @param self Self reference
-- @param #number time time

---
-- Function SetParticleSize()
-- Set particle size (both minimum and maximum.)
--
-- @function [parent=#ParticleEmitter] SetParticleSize
-- @param self Self reference
-- @param Vector2#Vector2 size size

---
-- Function SetMinParticleSize()
-- Set particle minimum size.
--
-- @function [parent=#ParticleEmitter] SetMinParticleSize
-- @param self Self reference
-- @param Vector2#Vector2 size size

---
-- Function SetMaxParticleSize()
-- Set particle maximum size.
--
-- @function [parent=#ParticleEmitter] SetMaxParticleSize
-- @param self Self reference
-- @param Vector2#Vector2 size size

---
-- Function SetMinDirection()
-- Set negative direction limit.
--
-- @function [parent=#ParticleEmitter] SetMinDirection
-- @param self Self reference
-- @param Vector3#Vector3 direction direction

---
-- Function SetMaxDirection()
-- Set positive direction limit.
--
-- @function [parent=#ParticleEmitter] SetMaxDirection
-- @param self Self reference
-- @param Vector3#Vector3 direction direction

---
-- Function SetVelocity()
-- Set particle velocity (both minimum and maximum.)
--
-- @function [parent=#ParticleEmitter] SetVelocity
-- @param self Self reference
-- @param #number velocity velocity

---
-- Function SetMinVelocity()
-- Set particle minimum velocity.
--
-- @function [parent=#ParticleEmitter] SetMinVelocity
-- @param self Self reference
-- @param #number velocity velocity

---
-- Function SetMaxVelocity()
-- Set particle maximum velocity.
--
-- @function [parent=#ParticleEmitter] SetMaxVelocity
-- @param self Self reference
-- @param #number velocity velocity

---
-- Function SetRotation()
-- Set particle rotation (both minimum and maximum.)
--
-- @function [parent=#ParticleEmitter] SetRotation
-- @param self Self reference
-- @param #number rotation rotation

---
-- Function SetMinRotation()
-- Set particle minimum rotation.
--
-- @function [parent=#ParticleEmitter] SetMinRotation
-- @param self Self reference
-- @param #number rotation rotation

---
-- Function SetMaxRotation()
-- Set particle maximum rotation.
--
-- @function [parent=#ParticleEmitter] SetMaxRotation
-- @param self Self reference
-- @param #number rotation rotation

---
-- Function SetRotationSpeed()
-- Set particle rotation speed (both minimum and maximum.)
--
-- @function [parent=#ParticleEmitter] SetRotationSpeed
-- @param self Self reference
-- @param #number speed speed

---
-- Function SetMinRotationSpeed()
-- Set particle minimum rotation speed.
--
-- @function [parent=#ParticleEmitter] SetMinRotationSpeed
-- @param self Self reference
-- @param #number speed speed

---
-- Function SetMaxRotationSpeed()
-- Set particle maximum rotation speed.
--
-- @function [parent=#ParticleEmitter] SetMaxRotationSpeed
-- @param self Self reference
-- @param #number speed speed

---
-- Function SetConstantForce()
-- Set constant force acting on particles.
--
-- @function [parent=#ParticleEmitter] SetConstantForce
-- @param self Self reference
-- @param Vector3#Vector3 force force

---
-- Function SetDampingForce()
-- Set particle velocity damping force.
--
-- @function [parent=#ParticleEmitter] SetDampingForce
-- @param self Self reference
-- @param #number force force

---
-- Function SetSizeAdd()
-- Set particle size additive modifier.
--
-- @function [parent=#ParticleEmitter] SetSizeAdd
-- @param self Self reference
-- @param #number sizeAdd sizeAdd

---
-- Function SetSizeMul()
-- Set particle size multiplicative modifier.
--
-- @function [parent=#ParticleEmitter] SetSizeMul
-- @param self Self reference
-- @param #number sizeMul sizeMul

---
-- Function SetColor()
-- Set color of particles.
--
-- @function [parent=#ParticleEmitter] SetColor
-- @param self Self reference
-- @param Color#Color color color

---
-- Function SetNumColors()
-- Set number of color animation frames.
--
-- @function [parent=#ParticleEmitter] SetNumColors
-- @param self Self reference
-- @param #number num num

---
-- Function SetNumTextureFrames()
-- Set number of texture animation frames.
--
-- @function [parent=#ParticleEmitter] SetNumTextureFrames
-- @param self Self reference
-- @param #number num num

---
-- Function GetNumParticles()
-- Return maximum number of particles.
--
-- @function [parent=#ParticleEmitter] GetNumParticles
-- @param self Self reference
-- @return #number

---
-- Function IsEmitting()
-- Return whether is currently emitting.
--
-- @function [parent=#ParticleEmitter] IsEmitting
-- @param self Self reference
-- @return #boolean

---
-- Function GetUpdateInvisible()
-- Return whether to update when particles are not visible.
--
-- @function [parent=#ParticleEmitter] GetUpdateInvisible
-- @param self Self reference
-- @return #boolean

---
-- Function GetMinEmissionRate()
-- Return minimum emission rate.
--
-- @function [parent=#ParticleEmitter] GetMinEmissionRate
-- @param self Self reference
-- @return #number

---
-- Function GetMaxEmissionRate()
-- Return maximum emission rate.
--
-- @function [parent=#ParticleEmitter] GetMaxEmissionRate
-- @param self Self reference
-- @return #number

---
-- Function GetEmitterType()
-- Return emitter type.
--
-- @function [parent=#ParticleEmitter] GetEmitterType
-- @param self Self reference
-- @return EmitterType#EmitterType

---
-- Function GetEmitterSize()
-- Return emitter size.
--
-- @function [parent=#ParticleEmitter] GetEmitterSize
-- @param self Self reference
-- @return const Vector3#const Vector3

---
-- Function GetActiveTime()
-- Return emission active period length (0 = infinite.)
--
-- @function [parent=#ParticleEmitter] GetActiveTime
-- @param self Self reference
-- @return #number

---
-- Function GetInactiveTime()
-- Return emission inactive period length (0 = infinite.)
--
-- @function [parent=#ParticleEmitter] GetInactiveTime
-- @param self Self reference
-- @return #number

---
-- Function GetMinTimeToLive()
-- Return particle minimum time to live.
--
-- @function [parent=#ParticleEmitter] GetMinTimeToLive
-- @param self Self reference
-- @return #number

---
-- Function GetMaxTimeToLive()
-- Return particle maximum time to live.
--
-- @function [parent=#ParticleEmitter] GetMaxTimeToLive
-- @param self Self reference
-- @return #number

---
-- Function GetMinParticleSize()
-- Return particle minimum size.
--
-- @function [parent=#ParticleEmitter] GetMinParticleSize
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Function GetMaxParticleSize()
-- Return particle maximum size.
--
-- @function [parent=#ParticleEmitter] GetMaxParticleSize
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Function GetMinDirection()
-- Return negative direction limit.
--
-- @function [parent=#ParticleEmitter] GetMinDirection
-- @param self Self reference
-- @return const Vector3#const Vector3

---
-- Function GetMaxDirection()
-- Return positive direction limit.
--
-- @function [parent=#ParticleEmitter] GetMaxDirection
-- @param self Self reference
-- @return const Vector3#const Vector3

---
-- Function GetMinVelocity()
-- Return particle minimum velocity.
--
-- @function [parent=#ParticleEmitter] GetMinVelocity
-- @param self Self reference
-- @return #number

---
-- Function GetMaxVelocity()
-- Return particle maximum velocity.
--
-- @function [parent=#ParticleEmitter] GetMaxVelocity
-- @param self Self reference
-- @return #number

---
-- Function GetMinRotation()
-- Return particle minimum rotation.
--
-- @function [parent=#ParticleEmitter] GetMinRotation
-- @param self Self reference
-- @return #number

---
-- Function GetMaxRotation()
-- Return particle maximum rotation.
--
-- @function [parent=#ParticleEmitter] GetMaxRotation
-- @param self Self reference
-- @return #number

---
-- Function GetMinRotationSpeed()
-- Return particle minimum rotation speed.
--
-- @function [parent=#ParticleEmitter] GetMinRotationSpeed
-- @param self Self reference
-- @return #number

---
-- Function GetMaxRotationSpeed()
-- Return particle maximum rotation speed.
--
-- @function [parent=#ParticleEmitter] GetMaxRotationSpeed
-- @param self Self reference
-- @return #number

---
-- Function GetConstantForce()
-- Return constant force acting on particles.
--
-- @function [parent=#ParticleEmitter] GetConstantForce
-- @param self Self reference
-- @return const Vector3#const Vector3

---
-- Function GetDampingForce()
-- Return particle velocity damping force.
--
-- @function [parent=#ParticleEmitter] GetDampingForce
-- @param self Self reference
-- @return #number

---
-- Function GetSizeAdd()
-- Return particle size additive modifier.
--
-- @function [parent=#ParticleEmitter] GetSizeAdd
-- @param self Self reference
-- @return #number

---
-- Function GetSizeMul()
-- Return particle size multiplicative modifier.
--
-- @function [parent=#ParticleEmitter] GetSizeMul
-- @param self Self reference
-- @return #number

---
-- Function GetNumColors()
-- Return number of color animation frames.
--
-- @function [parent=#ParticleEmitter] GetNumColors
-- @param self Self reference
-- @return #number

---
-- Function GetColor()
--
-- @function [parent=#ParticleEmitter] GetColor
-- @param self Self reference
-- @param #number index index
-- @return ColorFrame#ColorFrame

---
-- Function GetNumTextureFrames()
-- Return number of texture animation frames.
--
-- @function [parent=#ParticleEmitter] GetNumTextureFrames
-- @param self Self reference
-- @return #number

---
-- Function GetTextureFrame()
--
-- @function [parent=#ParticleEmitter] GetTextureFrame
-- @param self Self reference
-- @param #number index index
-- @return TextureFrame#TextureFrame

---
-- Field numParticles
--
-- @field [parent=#ParticleEmitter] #number numParticles

---
-- Field emissionRate
--
-- @field [parent=#ParticleEmitter] #number emissionRate

---
-- Field emitting
--
-- @field [parent=#ParticleEmitter] #boolean emitting

---
-- Field updateInvisible
--
-- @field [parent=#ParticleEmitter] #boolean updateInvisible

---
-- Field minEmissionRate
--
-- @field [parent=#ParticleEmitter] #number minEmissionRate

---
-- Field maxEmissionRate
--
-- @field [parent=#ParticleEmitter] #number maxEmissionRate

---
-- Field emitterType
--
-- @field [parent=#ParticleEmitter] EmitterType#EmitterType emitterType

---
-- Field emitterSize
--
-- @field [parent=#ParticleEmitter] Vector3#Vector3 emitterSize

---
-- Field activeTime
--
-- @field [parent=#ParticleEmitter] #number activeTime

---
-- Field inactiveTime
--
-- @field [parent=#ParticleEmitter] #number inactiveTime

---
-- Field timeToLive
--
-- @field [parent=#ParticleEmitter] #number timeToLive

---
-- Field minTimeToLive
--
-- @field [parent=#ParticleEmitter] #number minTimeToLive

---
-- Field maxTimeToLive
--
-- @field [parent=#ParticleEmitter] #number maxTimeToLive

---
-- Field particleSize
--
-- @field [parent=#ParticleEmitter] Vector2#Vector2 particleSize

---
-- Field minParticleSize
--
-- @field [parent=#ParticleEmitter] Vector2#Vector2 minParticleSize

---
-- Field maxParticleSize
--
-- @field [parent=#ParticleEmitter] Vector2#Vector2 maxParticleSize

---
-- Field minDirection
--
-- @field [parent=#ParticleEmitter] Vector3#Vector3 minDirection

---
-- Field maxDirection
--
-- @field [parent=#ParticleEmitter] Vector3#Vector3 maxDirection

---
-- Field velocity
--
-- @field [parent=#ParticleEmitter] #number velocity

---
-- Field minVelocity
--
-- @field [parent=#ParticleEmitter] #number minVelocity

---
-- Field maxVelocity
--
-- @field [parent=#ParticleEmitter] #number maxVelocity

---
-- Field rotation
--
-- @field [parent=#ParticleEmitter] #number rotation

---
-- Field minRotation
--
-- @field [parent=#ParticleEmitter] #number minRotation

---
-- Field maxRotation
--
-- @field [parent=#ParticleEmitter] #number maxRotation

---
-- Field rotationSpeed
--
-- @field [parent=#ParticleEmitter] #number rotationSpeed

---
-- Field minRotationSpeed
--
-- @field [parent=#ParticleEmitter] #number minRotationSpeed

---
-- Field maxRotationSpeed
--
-- @field [parent=#ParticleEmitter] #number maxRotationSpeed

---
-- Field constantForce
--
-- @field [parent=#ParticleEmitter] Vector3#Vector3 constantForce

---
-- Field dampingForce
--
-- @field [parent=#ParticleEmitter] #number dampingForce

---
-- Field sizeAdd
--
-- @field [parent=#ParticleEmitter] #number sizeAdd

---
-- Field sizeMul
--
-- @field [parent=#ParticleEmitter] #number sizeMul

---
-- Field numColors
--
-- @field [parent=#ParticleEmitter] #number numColors

---
-- Field numTextureFrames
--
-- @field [parent=#ParticleEmitter] #number numTextureFrames


return nil
