---
-- Module ParticleEmitter
-- Extends BillboardSet
--
-- @module ParticleEmitter

---
-- Function Load
--
-- @function [parent=#ParticleEmitter] Load
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#ParticleEmitter] Save
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetNumParticles
--
-- @function [parent=#ParticleEmitter] SetNumParticles
-- @param #number numnum

---
-- Function SetEmissionRate
--
-- @function [parent=#ParticleEmitter] SetEmissionRate
-- @param #number raterate

---
-- Function SetMinEmissionRate
--
-- @function [parent=#ParticleEmitter] SetMinEmissionRate
-- @param #number raterate

---
-- Function SetMaxEmissionRate
--
-- @function [parent=#ParticleEmitter] SetMaxEmissionRate
-- @param #number raterate

---
-- Function SetEmitterType
--
-- @function [parent=#ParticleEmitter] SetEmitterType
-- @param EmitterType#EmitterType typetype

---
-- Function SetEmitterSize
--
-- @function [parent=#ParticleEmitter] SetEmitterSize
-- @param Vector3#Vector3 sizesize

---
-- Function SetActiveTime
--
-- @function [parent=#ParticleEmitter] SetActiveTime
-- @param #number timetime

---
-- Function SetInactiveTime
--
-- @function [parent=#ParticleEmitter] SetInactiveTime
-- @param #number timetime

---
-- Function SetEmitting
--
-- @function [parent=#ParticleEmitter] SetEmitting
-- @param #boolean enableenable
-- @param #boolean resetPeriodresetPeriod

---
-- Function SetUpdateInvisible
--
-- @function [parent=#ParticleEmitter] SetUpdateInvisible
-- @param #boolean enableenable

---
-- Function SetTimeToLive
--
-- @function [parent=#ParticleEmitter] SetTimeToLive
-- @param #number timetime

---
-- Function SetMinTimeToLive
--
-- @function [parent=#ParticleEmitter] SetMinTimeToLive
-- @param #number timetime

---
-- Function SetMaxTimeToLive
--
-- @function [parent=#ParticleEmitter] SetMaxTimeToLive
-- @param #number timetime

---
-- Function SetParticleSize
--
-- @function [parent=#ParticleEmitter] SetParticleSize
-- @param Vector2#Vector2 sizesize

---
-- Function SetMinParticleSize
--
-- @function [parent=#ParticleEmitter] SetMinParticleSize
-- @param Vector2#Vector2 sizesize

---
-- Function SetMaxParticleSize
--
-- @function [parent=#ParticleEmitter] SetMaxParticleSize
-- @param Vector2#Vector2 sizesize

---
-- Function SetMinDirection
--
-- @function [parent=#ParticleEmitter] SetMinDirection
-- @param Vector3#Vector3 directiondirection

---
-- Function SetMaxDirection
--
-- @function [parent=#ParticleEmitter] SetMaxDirection
-- @param Vector3#Vector3 directiondirection

---
-- Function SetVelocity
--
-- @function [parent=#ParticleEmitter] SetVelocity
-- @param #number velocityvelocity

---
-- Function SetMinVelocity
--
-- @function [parent=#ParticleEmitter] SetMinVelocity
-- @param #number velocityvelocity

---
-- Function SetMaxVelocity
--
-- @function [parent=#ParticleEmitter] SetMaxVelocity
-- @param #number velocityvelocity

---
-- Function SetRotation
--
-- @function [parent=#ParticleEmitter] SetRotation
-- @param #number rotationrotation

---
-- Function SetMinRotation
--
-- @function [parent=#ParticleEmitter] SetMinRotation
-- @param #number rotationrotation

---
-- Function SetMaxRotation
--
-- @function [parent=#ParticleEmitter] SetMaxRotation
-- @param #number rotationrotation

---
-- Function SetRotationSpeed
--
-- @function [parent=#ParticleEmitter] SetRotationSpeed
-- @param #number speedspeed

---
-- Function SetMinRotationSpeed
--
-- @function [parent=#ParticleEmitter] SetMinRotationSpeed
-- @param #number speedspeed

---
-- Function SetMaxRotationSpeed
--
-- @function [parent=#ParticleEmitter] SetMaxRotationSpeed
-- @param #number speedspeed

---
-- Function SetConstantForce
--
-- @function [parent=#ParticleEmitter] SetConstantForce
-- @param Vector3#Vector3 forceforce

---
-- Function SetDampingForce
--
-- @function [parent=#ParticleEmitter] SetDampingForce
-- @param #number forceforce

---
-- Function SetSizeAdd
--
-- @function [parent=#ParticleEmitter] SetSizeAdd
-- @param #number sizeAddsizeAdd

---
-- Function SetSizeMul
--
-- @function [parent=#ParticleEmitter] SetSizeMul
-- @param #number sizeMulsizeMul

---
-- Function SetColor
--
-- @function [parent=#ParticleEmitter] SetColor
-- @param Color#Color colorcolor

---
-- Function SetNumColors
--
-- @function [parent=#ParticleEmitter] SetNumColors
-- @param #number numnum

---
-- Function SetNumTextureFrames
--
-- @function [parent=#ParticleEmitter] SetNumTextureFrames
-- @param #number numnum

---
-- Function GetNumParticles
--
-- @function [parent=#ParticleEmitter] GetNumParticles
-- @return #number

---
-- Function IsEmitting
--
-- @function [parent=#ParticleEmitter] IsEmitting
-- @return #boolean

---
-- Function GetUpdateInvisible
--
-- @function [parent=#ParticleEmitter] GetUpdateInvisible
-- @return #boolean

---
-- Function GetMinEmissionRate
--
-- @function [parent=#ParticleEmitter] GetMinEmissionRate
-- @return #number

---
-- Function GetMaxEmissionRate
--
-- @function [parent=#ParticleEmitter] GetMaxEmissionRate
-- @return #number

---
-- Function GetEmitterType
--
-- @function [parent=#ParticleEmitter] GetEmitterType
-- @return EmitterType#EmitterType

---
-- Function GetEmitterSize
--
-- @function [parent=#ParticleEmitter] GetEmitterSize
-- @return const Vector3#const Vector3

---
-- Function GetActiveTime
--
-- @function [parent=#ParticleEmitter] GetActiveTime
-- @return #number

---
-- Function GetInactiveTime
--
-- @function [parent=#ParticleEmitter] GetInactiveTime
-- @return #number

---
-- Function GetMinTimeToLive
--
-- @function [parent=#ParticleEmitter] GetMinTimeToLive
-- @return #number

---
-- Function GetMaxTimeToLive
--
-- @function [parent=#ParticleEmitter] GetMaxTimeToLive
-- @return #number

---
-- Function GetMinParticleSize
--
-- @function [parent=#ParticleEmitter] GetMinParticleSize
-- @return const Vector2#const Vector2

---
-- Function GetMaxParticleSize
--
-- @function [parent=#ParticleEmitter] GetMaxParticleSize
-- @return const Vector2#const Vector2

---
-- Function GetMinDirection
--
-- @function [parent=#ParticleEmitter] GetMinDirection
-- @return const Vector3#const Vector3

---
-- Function GetMaxDirection
--
-- @function [parent=#ParticleEmitter] GetMaxDirection
-- @return const Vector3#const Vector3

---
-- Function GetMinVelocity
--
-- @function [parent=#ParticleEmitter] GetMinVelocity
-- @return #number

---
-- Function GetMaxVelocity
--
-- @function [parent=#ParticleEmitter] GetMaxVelocity
-- @return #number

---
-- Function GetMinRotation
--
-- @function [parent=#ParticleEmitter] GetMinRotation
-- @return #number

---
-- Function GetMaxRotation
--
-- @function [parent=#ParticleEmitter] GetMaxRotation
-- @return #number

---
-- Function GetMinRotationSpeed
--
-- @function [parent=#ParticleEmitter] GetMinRotationSpeed
-- @return #number

---
-- Function GetMaxRotationSpeed
--
-- @function [parent=#ParticleEmitter] GetMaxRotationSpeed
-- @return #number

---
-- Function GetConstantForce
--
-- @function [parent=#ParticleEmitter] GetConstantForce
-- @return const Vector3#const Vector3

---
-- Function GetDampingForce
--
-- @function [parent=#ParticleEmitter] GetDampingForce
-- @return #number

---
-- Function GetSizeAdd
--
-- @function [parent=#ParticleEmitter] GetSizeAdd
-- @return #number

---
-- Function GetSizeMul
--
-- @function [parent=#ParticleEmitter] GetSizeMul
-- @return #number

---
-- Function GetNumColors
--
-- @function [parent=#ParticleEmitter] GetNumColors
-- @return #number

---
-- Function GetColor
--
-- @function [parent=#ParticleEmitter] GetColor
-- @param #number indexindex
-- @return ColorFrame#ColorFrame

---
-- Function GetNumTextureFrames
--
-- @function [parent=#ParticleEmitter] GetNumTextureFrames
-- @return #number

---
-- Function GetTextureFrame
--
-- @function [parent=#ParticleEmitter] GetTextureFrame
-- @param #number indexindex
-- @return TextureFrame#TextureFrame

---
-- Field numParticles
--
-- @field [parent=#ParticleEmitter] #number numParticles

---
-- Field emissionRate
--
-- @field [parent=#ParticleEmitter] #number emissionRate

---
-- Field emitting
--
-- @field [parent=#ParticleEmitter] #boolean emitting

---
-- Field updateInvisible
--
-- @field [parent=#ParticleEmitter] #boolean updateInvisible

---
-- Field minEmissionRate
--
-- @field [parent=#ParticleEmitter] #number minEmissionRate

---
-- Field maxEmissionRate
--
-- @field [parent=#ParticleEmitter] #number maxEmissionRate

---
-- Field emitterType
--
-- @field [parent=#ParticleEmitter] EmitterType#EmitterType emitterType

---
-- Field emitterSize
--
-- @field [parent=#ParticleEmitter] Vector3#Vector3 emitterSize

---
-- Field activeTime
--
-- @field [parent=#ParticleEmitter] #number activeTime

---
-- Field inactiveTime
--
-- @field [parent=#ParticleEmitter] #number inactiveTime

---
-- Field timeToLive
--
-- @field [parent=#ParticleEmitter] #number timeToLive

---
-- Field minTimeToLive
--
-- @field [parent=#ParticleEmitter] #number minTimeToLive

---
-- Field maxTimeToLive
--
-- @field [parent=#ParticleEmitter] #number maxTimeToLive

---
-- Field particleSize
--
-- @field [parent=#ParticleEmitter] Vector2#Vector2 particleSize

---
-- Field minParticleSize
--
-- @field [parent=#ParticleEmitter] Vector2#Vector2 minParticleSize

---
-- Field maxParticleSize
--
-- @field [parent=#ParticleEmitter] Vector2#Vector2 maxParticleSize

---
-- Field minDirection
--
-- @field [parent=#ParticleEmitter] Vector3#Vector3 minDirection

---
-- Field maxDirection
--
-- @field [parent=#ParticleEmitter] Vector3#Vector3 maxDirection

---
-- Field velocity
--
-- @field [parent=#ParticleEmitter] #number velocity

---
-- Field minVelocity
--
-- @field [parent=#ParticleEmitter] #number minVelocity

---
-- Field maxVelocity
--
-- @field [parent=#ParticleEmitter] #number maxVelocity

---
-- Field rotation
--
-- @field [parent=#ParticleEmitter] #number rotation

---
-- Field minRotation
--
-- @field [parent=#ParticleEmitter] #number minRotation

---
-- Field maxRotation
--
-- @field [parent=#ParticleEmitter] #number maxRotation

---
-- Field rotationSpeed
--
-- @field [parent=#ParticleEmitter] #number rotationSpeed

---
-- Field minRotationSpeed
--
-- @field [parent=#ParticleEmitter] #number minRotationSpeed

---
-- Field maxRotationSpeed
--
-- @field [parent=#ParticleEmitter] #number maxRotationSpeed

---
-- Field constantForce
--
-- @field [parent=#ParticleEmitter] Vector3#Vector3 constantForce

---
-- Field dampingForce
--
-- @field [parent=#ParticleEmitter] #number dampingForce

---
-- Field sizeAdd
--
-- @field [parent=#ParticleEmitter] #number sizeAdd

---
-- Field sizeMul
--
-- @field [parent=#ParticleEmitter] #number sizeMul

---
-- Field numColors
--
-- @field [parent=#ParticleEmitter] #number numColors

---
-- Field numTextureFrames
--
-- @field [parent=#ParticleEmitter] #number numTextureFrames


return nil
