---
-- Module ParticleEmitter
-- Module ParticleEmitter extends BillboardSet
-- Generated on 2014-03-13
--
-- @module ParticleEmitter

---
-- Function Load
--
-- @function [parent=#ParticleEmitter] Load
-- @param self Self reference
-- @param XMLFile#XMLFile file file
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#ParticleEmitter] Save
-- @param self Self reference
-- @param XMLFile#XMLFile file file
-- @return #boolean

---
-- Function SetNumParticles
--
-- @function [parent=#ParticleEmitter] SetNumParticles
-- @param self Self reference
-- @param #number num num

---
-- Function SetEmissionRate
--
-- @function [parent=#ParticleEmitter] SetEmissionRate
-- @param self Self reference
-- @param #number rate rate

---
-- Function SetMinEmissionRate
--
-- @function [parent=#ParticleEmitter] SetMinEmissionRate
-- @param self Self reference
-- @param #number rate rate

---
-- Function SetMaxEmissionRate
--
-- @function [parent=#ParticleEmitter] SetMaxEmissionRate
-- @param self Self reference
-- @param #number rate rate

---
-- Function SetEmitterType
--
-- @function [parent=#ParticleEmitter] SetEmitterType
-- @param self Self reference
-- @param EmitterType#EmitterType type type

---
-- Function SetEmitterSize
--
-- @function [parent=#ParticleEmitter] SetEmitterSize
-- @param self Self reference
-- @param Vector3#Vector3 size size

---
-- Function SetActiveTime
--
-- @function [parent=#ParticleEmitter] SetActiveTime
-- @param self Self reference
-- @param #number time time

---
-- Function SetInactiveTime
--
-- @function [parent=#ParticleEmitter] SetInactiveTime
-- @param self Self reference
-- @param #number time time

---
-- Function SetEmitting
--
-- @function [parent=#ParticleEmitter] SetEmitting
-- @param self Self reference
-- @param #boolean enable enable
-- @param #boolean resetPeriod resetPeriod

---
-- Function SetUpdateInvisible
--
-- @function [parent=#ParticleEmitter] SetUpdateInvisible
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetTimeToLive
--
-- @function [parent=#ParticleEmitter] SetTimeToLive
-- @param self Self reference
-- @param #number time time

---
-- Function SetMinTimeToLive
--
-- @function [parent=#ParticleEmitter] SetMinTimeToLive
-- @param self Self reference
-- @param #number time time

---
-- Function SetMaxTimeToLive
--
-- @function [parent=#ParticleEmitter] SetMaxTimeToLive
-- @param self Self reference
-- @param #number time time

---
-- Function SetParticleSize
--
-- @function [parent=#ParticleEmitter] SetParticleSize
-- @param self Self reference
-- @param Vector2#Vector2 size size

---
-- Function SetMinParticleSize
--
-- @function [parent=#ParticleEmitter] SetMinParticleSize
-- @param self Self reference
-- @param Vector2#Vector2 size size

---
-- Function SetMaxParticleSize
--
-- @function [parent=#ParticleEmitter] SetMaxParticleSize
-- @param self Self reference
-- @param Vector2#Vector2 size size

---
-- Function SetMinDirection
--
-- @function [parent=#ParticleEmitter] SetMinDirection
-- @param self Self reference
-- @param Vector3#Vector3 direction direction

---
-- Function SetMaxDirection
--
-- @function [parent=#ParticleEmitter] SetMaxDirection
-- @param self Self reference
-- @param Vector3#Vector3 direction direction

---
-- Function SetVelocity
--
-- @function [parent=#ParticleEmitter] SetVelocity
-- @param self Self reference
-- @param #number velocity velocity

---
-- Function SetMinVelocity
--
-- @function [parent=#ParticleEmitter] SetMinVelocity
-- @param self Self reference
-- @param #number velocity velocity

---
-- Function SetMaxVelocity
--
-- @function [parent=#ParticleEmitter] SetMaxVelocity
-- @param self Self reference
-- @param #number velocity velocity

---
-- Function SetRotation
--
-- @function [parent=#ParticleEmitter] SetRotation
-- @param self Self reference
-- @param #number rotation rotation

---
-- Function SetMinRotation
--
-- @function [parent=#ParticleEmitter] SetMinRotation
-- @param self Self reference
-- @param #number rotation rotation

---
-- Function SetMaxRotation
--
-- @function [parent=#ParticleEmitter] SetMaxRotation
-- @param self Self reference
-- @param #number rotation rotation

---
-- Function SetRotationSpeed
--
-- @function [parent=#ParticleEmitter] SetRotationSpeed
-- @param self Self reference
-- @param #number speed speed

---
-- Function SetMinRotationSpeed
--
-- @function [parent=#ParticleEmitter] SetMinRotationSpeed
-- @param self Self reference
-- @param #number speed speed

---
-- Function SetMaxRotationSpeed
--
-- @function [parent=#ParticleEmitter] SetMaxRotationSpeed
-- @param self Self reference
-- @param #number speed speed

---
-- Function SetConstantForce
--
-- @function [parent=#ParticleEmitter] SetConstantForce
-- @param self Self reference
-- @param Vector3#Vector3 force force

---
-- Function SetDampingForce
--
-- @function [parent=#ParticleEmitter] SetDampingForce
-- @param self Self reference
-- @param #number force force

---
-- Function SetSizeAdd
--
-- @function [parent=#ParticleEmitter] SetSizeAdd
-- @param self Self reference
-- @param #number sizeAdd sizeAdd

---
-- Function SetSizeMul
--
-- @function [parent=#ParticleEmitter] SetSizeMul
-- @param self Self reference
-- @param #number sizeMul sizeMul

---
-- Function SetColor
--
-- @function [parent=#ParticleEmitter] SetColor
-- @param self Self reference
-- @param Color#Color color color

---
-- Function SetNumColors
--
-- @function [parent=#ParticleEmitter] SetNumColors
-- @param self Self reference
-- @param #number num num

---
-- Function SetNumTextureFrames
--
-- @function [parent=#ParticleEmitter] SetNumTextureFrames
-- @param self Self reference
-- @param #number num num

---
-- Function GetNumParticles
--
-- @function [parent=#ParticleEmitter] GetNumParticles
-- @param self Self reference
-- @return #number

---
-- Function IsEmitting
--
-- @function [parent=#ParticleEmitter] IsEmitting
-- @param self Self reference
-- @return #boolean

---
-- Function GetUpdateInvisible
--
-- @function [parent=#ParticleEmitter] GetUpdateInvisible
-- @param self Self reference
-- @return #boolean

---
-- Function GetMinEmissionRate
--
-- @function [parent=#ParticleEmitter] GetMinEmissionRate
-- @param self Self reference
-- @return #number

---
-- Function GetMaxEmissionRate
--
-- @function [parent=#ParticleEmitter] GetMaxEmissionRate
-- @param self Self reference
-- @return #number

---
-- Function GetEmitterType
--
-- @function [parent=#ParticleEmitter] GetEmitterType
-- @param self Self reference
-- @return EmitterType#EmitterType

---
-- Function GetEmitterSize
--
-- @function [parent=#ParticleEmitter] GetEmitterSize
-- @param self Self reference
-- @return const Vector3#const Vector3

---
-- Function GetActiveTime
--
-- @function [parent=#ParticleEmitter] GetActiveTime
-- @param self Self reference
-- @return #number

---
-- Function GetInactiveTime
--
-- @function [parent=#ParticleEmitter] GetInactiveTime
-- @param self Self reference
-- @return #number

---
-- Function GetMinTimeToLive
--
-- @function [parent=#ParticleEmitter] GetMinTimeToLive
-- @param self Self reference
-- @return #number

---
-- Function GetMaxTimeToLive
--
-- @function [parent=#ParticleEmitter] GetMaxTimeToLive
-- @param self Self reference
-- @return #number

---
-- Function GetMinParticleSize
--
-- @function [parent=#ParticleEmitter] GetMinParticleSize
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Function GetMaxParticleSize
--
-- @function [parent=#ParticleEmitter] GetMaxParticleSize
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Function GetMinDirection
--
-- @function [parent=#ParticleEmitter] GetMinDirection
-- @param self Self reference
-- @return const Vector3#const Vector3

---
-- Function GetMaxDirection
--
-- @function [parent=#ParticleEmitter] GetMaxDirection
-- @param self Self reference
-- @return const Vector3#const Vector3

---
-- Function GetMinVelocity
--
-- @function [parent=#ParticleEmitter] GetMinVelocity
-- @param self Self reference
-- @return #number

---
-- Function GetMaxVelocity
--
-- @function [parent=#ParticleEmitter] GetMaxVelocity
-- @param self Self reference
-- @return #number

---
-- Function GetMinRotation
--
-- @function [parent=#ParticleEmitter] GetMinRotation
-- @param self Self reference
-- @return #number

---
-- Function GetMaxRotation
--
-- @function [parent=#ParticleEmitter] GetMaxRotation
-- @param self Self reference
-- @return #number

---
-- Function GetMinRotationSpeed
--
-- @function [parent=#ParticleEmitter] GetMinRotationSpeed
-- @param self Self reference
-- @return #number

---
-- Function GetMaxRotationSpeed
--
-- @function [parent=#ParticleEmitter] GetMaxRotationSpeed
-- @param self Self reference
-- @return #number

---
-- Function GetConstantForce
--
-- @function [parent=#ParticleEmitter] GetConstantForce
-- @param self Self reference
-- @return const Vector3#const Vector3

---
-- Function GetDampingForce
--
-- @function [parent=#ParticleEmitter] GetDampingForce
-- @param self Self reference
-- @return #number

---
-- Function GetSizeAdd
--
-- @function [parent=#ParticleEmitter] GetSizeAdd
-- @param self Self reference
-- @return #number

---
-- Function GetSizeMul
--
-- @function [parent=#ParticleEmitter] GetSizeMul
-- @param self Self reference
-- @return #number

---
-- Function GetNumColors
--
-- @function [parent=#ParticleEmitter] GetNumColors
-- @param self Self reference
-- @return #number

---
-- Function GetColor
--
-- @function [parent=#ParticleEmitter] GetColor
-- @param self Self reference
-- @param #number index index
-- @return ColorFrame#ColorFrame

---
-- Function GetNumTextureFrames
--
-- @function [parent=#ParticleEmitter] GetNumTextureFrames
-- @param self Self reference
-- @return #number

---
-- Function GetTextureFrame
--
-- @function [parent=#ParticleEmitter] GetTextureFrame
-- @param self Self reference
-- @param #number index index
-- @return TextureFrame#TextureFrame

---
-- Field numParticles
--
-- @field [parent=#ParticleEmitter] #number numParticles

---
-- Field emissionRate
--
-- @field [parent=#ParticleEmitter] #number emissionRate

---
-- Field emitting
--
-- @field [parent=#ParticleEmitter] #boolean emitting

---
-- Field updateInvisible
--
-- @field [parent=#ParticleEmitter] #boolean updateInvisible

---
-- Field minEmissionRate
--
-- @field [parent=#ParticleEmitter] #number minEmissionRate

---
-- Field maxEmissionRate
--
-- @field [parent=#ParticleEmitter] #number maxEmissionRate

---
-- Field emitterType
--
-- @field [parent=#ParticleEmitter] EmitterType#EmitterType emitterType

---
-- Field emitterSize
--
-- @field [parent=#ParticleEmitter] Vector3#Vector3 emitterSize

---
-- Field activeTime
--
-- @field [parent=#ParticleEmitter] #number activeTime

---
-- Field inactiveTime
--
-- @field [parent=#ParticleEmitter] #number inactiveTime

---
-- Field timeToLive
--
-- @field [parent=#ParticleEmitter] #number timeToLive

---
-- Field minTimeToLive
--
-- @field [parent=#ParticleEmitter] #number minTimeToLive

---
-- Field maxTimeToLive
--
-- @field [parent=#ParticleEmitter] #number maxTimeToLive

---
-- Field particleSize
--
-- @field [parent=#ParticleEmitter] Vector2#Vector2 particleSize

---
-- Field minParticleSize
--
-- @field [parent=#ParticleEmitter] Vector2#Vector2 minParticleSize

---
-- Field maxParticleSize
--
-- @field [parent=#ParticleEmitter] Vector2#Vector2 maxParticleSize

---
-- Field minDirection
--
-- @field [parent=#ParticleEmitter] Vector3#Vector3 minDirection

---
-- Field maxDirection
--
-- @field [parent=#ParticleEmitter] Vector3#Vector3 maxDirection

---
-- Field velocity
--
-- @field [parent=#ParticleEmitter] #number velocity

---
-- Field minVelocity
--
-- @field [parent=#ParticleEmitter] #number minVelocity

---
-- Field maxVelocity
--
-- @field [parent=#ParticleEmitter] #number maxVelocity

---
-- Field rotation
--
-- @field [parent=#ParticleEmitter] #number rotation

---
-- Field minRotation
--
-- @field [parent=#ParticleEmitter] #number minRotation

---
-- Field maxRotation
--
-- @field [parent=#ParticleEmitter] #number maxRotation

---
-- Field rotationSpeed
--
-- @field [parent=#ParticleEmitter] #number rotationSpeed

---
-- Field minRotationSpeed
--
-- @field [parent=#ParticleEmitter] #number minRotationSpeed

---
-- Field maxRotationSpeed
--
-- @field [parent=#ParticleEmitter] #number maxRotationSpeed

---
-- Field constantForce
--
-- @field [parent=#ParticleEmitter] Vector3#Vector3 constantForce

---
-- Field dampingForce
--
-- @field [parent=#ParticleEmitter] #number dampingForce

---
-- Field sizeAdd
--
-- @field [parent=#ParticleEmitter] #number sizeAdd

---
-- Field sizeMul
--
-- @field [parent=#ParticleEmitter] #number sizeMul

---
-- Field numColors
--
-- @field [parent=#ParticleEmitter] #number numColors

---
-- Field numTextureFrames
--
-- @field [parent=#ParticleEmitter] #number numTextureFrames

---
-- Function SetMaterial
--
-- @function [parent=#ParticleEmitter] SetMaterial
-- @param self Self reference
-- @param Material#Material material material

---
-- Function SetNumBillboards
--
-- @function [parent=#ParticleEmitter] SetNumBillboards
-- @param self Self reference
-- @param #number num num

---
-- Function SetRelative
--
-- @function [parent=#ParticleEmitter] SetRelative
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetScaled
--
-- @function [parent=#ParticleEmitter] SetScaled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetSorted
--
-- @function [parent=#ParticleEmitter] SetSorted
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetFaceCamera
--
-- @function [parent=#ParticleEmitter] SetFaceCamera
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetAnimationLodBias
--
-- @function [parent=#ParticleEmitter] SetAnimationLodBias
-- @param self Self reference
-- @param #number bias bias

---
-- Function Commit
--
-- @function [parent=#ParticleEmitter] Commit
-- @param self Self reference

---
-- Function GetMaterial
--
-- @function [parent=#ParticleEmitter] GetMaterial
-- @param self Self reference
-- @return Material#Material

---
-- Function GetNumBillboards
--
-- @function [parent=#ParticleEmitter] GetNumBillboards
-- @param self Self reference
-- @return #number

---
-- Function GetBillboard
--
-- @function [parent=#ParticleEmitter] GetBillboard
-- @param self Self reference
-- @param #number index index
-- @return Billboard#Billboard

---
-- Function IsRelative
--
-- @function [parent=#ParticleEmitter] IsRelative
-- @param self Self reference
-- @return #boolean

---
-- Function IsScaled
--
-- @function [parent=#ParticleEmitter] IsScaled
-- @param self Self reference
-- @return #boolean

---
-- Function IsSorted
--
-- @function [parent=#ParticleEmitter] IsSorted
-- @param self Self reference
-- @return #boolean

---
-- Function GetFaceCamera
--
-- @function [parent=#ParticleEmitter] GetFaceCamera
-- @param self Self reference
-- @return #boolean

---
-- Function GetAnimationLodBias
--
-- @function [parent=#ParticleEmitter] GetAnimationLodBias
-- @param self Self reference
-- @return #number

---
-- Field material
--
-- @field [parent=#ParticleEmitter] Material#Material material

---
-- Field numBillboards
--
-- @field [parent=#ParticleEmitter] #number numBillboards

---
-- Field relative
--
-- @field [parent=#ParticleEmitter] #boolean relative

---
-- Field scaled
--
-- @field [parent=#ParticleEmitter] #boolean scaled

---
-- Field sorted
--
-- @field [parent=#ParticleEmitter] #boolean sorted

---
-- Field faceCamera
--
-- @field [parent=#ParticleEmitter] #boolean faceCamera

---
-- Field animationLodBias
--
-- @field [parent=#ParticleEmitter] #number animationLodBias

---
-- Function SetDrawDistance
--
-- @function [parent=#ParticleEmitter] SetDrawDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetShadowDistance
--
-- @function [parent=#ParticleEmitter] SetShadowDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetLodBias
--
-- @function [parent=#ParticleEmitter] SetLodBias
-- @param self Self reference
-- @param #number bias bias

---
-- Function SetViewMask
--
-- @function [parent=#ParticleEmitter] SetViewMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetLightMask
--
-- @function [parent=#ParticleEmitter] SetLightMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetShadowMask
--
-- @function [parent=#ParticleEmitter] SetShadowMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetZoneMask
--
-- @function [parent=#ParticleEmitter] SetZoneMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetMaxLights
--
-- @function [parent=#ParticleEmitter] SetMaxLights
-- @param self Self reference
-- @param #number num num

---
-- Function SetCastShadows
--
-- @function [parent=#ParticleEmitter] SetCastShadows
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetOccluder
--
-- @function [parent=#ParticleEmitter] SetOccluder
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetOccludee
--
-- @function [parent=#ParticleEmitter] SetOccludee
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function MarkForUpdate
--
-- @function [parent=#ParticleEmitter] MarkForUpdate
-- @param self Self reference

---
-- Function GetBoundingBox
--
-- @function [parent=#ParticleEmitter] GetBoundingBox
-- @param self Self reference
-- @return const BoundingBox#const BoundingBox

---
-- Function GetWorldBoundingBox
--
-- @function [parent=#ParticleEmitter] GetWorldBoundingBox
-- @param self Self reference
-- @return const BoundingBox#const BoundingBox

---
-- Function GetDrawableFlags
--
-- @function [parent=#ParticleEmitter] GetDrawableFlags
-- @param self Self reference
-- @return #string

---
-- Function GetDrawDistance
--
-- @function [parent=#ParticleEmitter] GetDrawDistance
-- @param self Self reference
-- @return #number

---
-- Function GetShadowDistance
--
-- @function [parent=#ParticleEmitter] GetShadowDistance
-- @param self Self reference
-- @return #number

---
-- Function GetLodBias
--
-- @function [parent=#ParticleEmitter] GetLodBias
-- @param self Self reference
-- @return #number

---
-- Function GetViewMask
--
-- @function [parent=#ParticleEmitter] GetViewMask
-- @param self Self reference
-- @return #number

---
-- Function GetLightMask
--
-- @function [parent=#ParticleEmitter] GetLightMask
-- @param self Self reference
-- @return #number

---
-- Function GetShadowMask
--
-- @function [parent=#ParticleEmitter] GetShadowMask
-- @param self Self reference
-- @return #number

---
-- Function GetZoneMask
--
-- @function [parent=#ParticleEmitter] GetZoneMask
-- @param self Self reference
-- @return #number

---
-- Function GetMaxLights
--
-- @function [parent=#ParticleEmitter] GetMaxLights
-- @param self Self reference
-- @return #number

---
-- Function GetCastShadows
--
-- @function [parent=#ParticleEmitter] GetCastShadows
-- @param self Self reference
-- @return #boolean

---
-- Function IsOccluder
--
-- @function [parent=#ParticleEmitter] IsOccluder
-- @param self Self reference
-- @return #boolean

---
-- Function IsOccludee
--
-- @function [parent=#ParticleEmitter] IsOccludee
-- @param self Self reference
-- @return #boolean

---
-- Function SetZone
--
-- @function [parent=#ParticleEmitter] SetZone
-- @param self Self reference
-- @param Zone#Zone zone zone
-- @param #boolean temporary temporary

---
-- Function SetSortValue
--
-- @function [parent=#ParticleEmitter] SetSortValue
-- @param self Self reference
-- @param #number value value

---
-- Function SetMinMaxZ
--
-- @function [parent=#ParticleEmitter] SetMinMaxZ
-- @param self Self reference
-- @param #number minZ minZ
-- @param #number maxZ maxZ

---
-- Function MarkInView
--
-- @function [parent=#ParticleEmitter] MarkInView
-- @param self Self reference
-- @param FrameInfo#FrameInfo frame frame
-- @param #boolean mainView mainView

---
-- Function ClearLights
--
-- @function [parent=#ParticleEmitter] ClearLights
-- @param self Self reference

---
-- Function AddLight
--
-- @function [parent=#ParticleEmitter] AddLight
-- @param self Self reference
-- @param Light#Light light light

---
-- Function AddVertexLight
--
-- @function [parent=#ParticleEmitter] AddVertexLight
-- @param self Self reference
-- @param Light#Light light light

---
-- Function LimitLights
--
-- @function [parent=#ParticleEmitter] LimitLights
-- @param self Self reference

---
-- Function LimitVertexLights
--
-- @function [parent=#ParticleEmitter] LimitVertexLights
-- @param self Self reference

---
-- Function SetBasePass
--
-- @function [parent=#ParticleEmitter] SetBasePass
-- @param self Self reference
-- @param #number batchIndex batchIndex

---
-- Function GetOctant
--
-- @function [parent=#ParticleEmitter] GetOctant
-- @param self Self reference
-- @return Octant#Octant

---
-- Function GetZone
--
-- @function [parent=#ParticleEmitter] GetZone
-- @param self Self reference
-- @return Zone#Zone

---
-- Function GetLastZone
--
-- @function [parent=#ParticleEmitter] GetLastZone
-- @param self Self reference
-- @return Zone#Zone

---
-- Function IsZoneDirty
--
-- @function [parent=#ParticleEmitter] IsZoneDirty
-- @param self Self reference
-- @return #boolean

---
-- Function GetDistance
--
-- @function [parent=#ParticleEmitter] GetDistance
-- @param self Self reference
-- @return #number

---
-- Function GetLodDistance
--
-- @function [parent=#ParticleEmitter] GetLodDistance
-- @param self Self reference
-- @return #number

---
-- Function GetSortValue
--
-- @function [parent=#ParticleEmitter] GetSortValue
-- @param self Self reference
-- @return #number

---
-- Function IsInView
--
-- @function [parent=#ParticleEmitter] IsInView
-- @param self Self reference
-- @param #number frameNumber frameNumber
-- @return #boolean

---
-- Function IsInView
--
-- @function [parent=#ParticleEmitter] IsInView
-- @param self Self reference
-- @param FrameInfo#FrameInfo frame frame
-- @param #boolean mainView mainView
-- @return #boolean

---
-- Function HasBasePass
--
-- @function [parent=#ParticleEmitter] HasBasePass
-- @param self Self reference
-- @param #number batchIndex batchIndex
-- @return #boolean

---
-- Function GetFirstLight
--
-- @function [parent=#ParticleEmitter] GetFirstLight
-- @param self Self reference
-- @return Light#Light

---
-- Function GetMinZ
--
-- @function [parent=#ParticleEmitter] GetMinZ
-- @param self Self reference
-- @return #number

---
-- Function GetMaxZ
--
-- @function [parent=#ParticleEmitter] GetMaxZ
-- @param self Self reference
-- @return #number

---
-- Field worldBoundingBox (Read only)
--
-- @field [parent=#ParticleEmitter] BoundingBox#BoundingBox worldBoundingBox

---
-- Field drawableFlags (Read only)
--
-- @field [parent=#ParticleEmitter] #string drawableFlags

---
-- Field drawDistance
--
-- @field [parent=#ParticleEmitter] #number drawDistance

---
-- Field shadowDistance
--
-- @field [parent=#ParticleEmitter] #number shadowDistance

---
-- Field lodBias
--
-- @field [parent=#ParticleEmitter] #number lodBias

---
-- Field viewMask
--
-- @field [parent=#ParticleEmitter] #number viewMask

---
-- Field lightMask
--
-- @field [parent=#ParticleEmitter] #number lightMask

---
-- Field shadowMask
--
-- @field [parent=#ParticleEmitter] #number shadowMask

---
-- Field zoneMask
--
-- @field [parent=#ParticleEmitter] #number zoneMask

---
-- Field maxLights
--
-- @field [parent=#ParticleEmitter] #number maxLights

---
-- Field castShadows
--
-- @field [parent=#ParticleEmitter] #boolean castShadows

---
-- Field occluder
--
-- @field [parent=#ParticleEmitter] #boolean occluder

---
-- Field occludee
--
-- @field [parent=#ParticleEmitter] #boolean occludee

---
-- Field octant (Read only)
--
-- @field [parent=#ParticleEmitter] Octant#Octant octant

---
-- Field zone
--
-- @field [parent=#ParticleEmitter] Zone#Zone zone

---
-- Field lastZone (Read only)
--
-- @field [parent=#ParticleEmitter] Zone#Zone lastZone

---
-- Field zoneDirty (Read only)
--
-- @field [parent=#ParticleEmitter] #boolean zoneDirty

---
-- Field distance (Read only)
--
-- @field [parent=#ParticleEmitter] #number distance

---
-- Field lodDistance (Read only)
--
-- @field [parent=#ParticleEmitter] #number lodDistance

---
-- Field sortValue
--
-- @field [parent=#ParticleEmitter] #number sortValue

---
-- Field firstLight (Read only)
--
-- @field [parent=#ParticleEmitter] Light#Light firstLight

---
-- Field minZ (Read only)
--
-- @field [parent=#ParticleEmitter] #number minZ

---
-- Field maxZ (Read only)
--
-- @field [parent=#ParticleEmitter] #number maxZ

---
-- Function SetEnabled
--
-- @function [parent=#ParticleEmitter] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Remove
--
-- @function [parent=#ParticleEmitter] Remove
-- @param self Self reference

---
-- Function GetID
--
-- @function [parent=#ParticleEmitter] GetID
-- @param self Self reference
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#ParticleEmitter] GetNode
-- @param self Self reference
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#ParticleEmitter] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#ParticleEmitter] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#ParticleEmitter] IsEnabledEffective
-- @param self Self reference
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#ParticleEmitter] GetComponent
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#ParticleEmitter] GetComponent
-- @param self Self reference
-- @param #string type type
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#ParticleEmitter] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#ParticleEmitter] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#ParticleEmitter] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#ParticleEmitter] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#ParticleEmitter] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#ParticleEmitter] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#ParticleEmitter] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#ParticleEmitter] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#ParticleEmitter] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#ParticleEmitter] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#ParticleEmitter] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#ParticleEmitter] #string category


return nil
