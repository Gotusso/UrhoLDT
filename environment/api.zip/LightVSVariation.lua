---
-- Enumeration LightVSVariation
--
-- @module LightVSVariation

---
-- Enumeration value LVS_DIR
--
-- @field [parent=#LightVSVariation] #number LVS_DIR

---
-- Enumeration value LVS_SPOT
--
-- @field [parent=#LightVSVariation] #number LVS_SPOT

---
-- Enumeration value LVS_POINT
--
-- @field [parent=#LightVSVariation] #number LVS_POINT

---
-- Enumeration value LVS_SPEC
--
-- @field [parent=#LightVSVariation] #number LVS_SPEC

---
-- Enumeration value LVS_SPOTSPEC
--
-- @field [parent=#LightVSVariation] #number LVS_SPOTSPEC

---
-- Enumeration value LVS_POINTSPEC
--
-- @field [parent=#LightVSVariation] #number LVS_POINTSPEC

---
-- Enumeration value LVS_SHADOW
--
-- @field [parent=#LightVSVariation] #number LVS_SHADOW

---
-- Enumeration value LVS_SPOTSHADOW
--
-- @field [parent=#LightVSVariation] #number LVS_SPOTSHADOW

---
-- Enumeration value LVS_POINTSHADOW
--
-- @field [parent=#LightVSVariation] #number LVS_POINTSHADOW

---
-- Enumeration value LVS_DIRSPECSHADOW
--
-- @field [parent=#LightVSVariation] #number LVS_DIRSPECSHADOW

---
-- Enumeration value LVS_SPOTSPECSHADOW
--
-- @field [parent=#LightVSVariation] #number LVS_SPOTSPECSHADOW

---
-- Enumeration value LVS_POINTSPECSHADOW
--
-- @field [parent=#LightVSVariation] #number LVS_POINTSPECSHADOW

---
-- Enumeration value MAX_LIGHT_VS_VARIATIONS
--
-- @field [parent=#LightVSVariation] #number MAX_LIGHT_VS_VARIATIONS


return nil
