---
-- Enumeration SoundType
--
-- @module SoundType

---
-- Enumeration value SOUND_EFFECT
--
-- @field [parent=#SoundType] #number SOUND_EFFECT

---
-- Enumeration value SOUND_AMBIENT
--
-- @field [parent=#SoundType] #number SOUND_AMBIENT

---
-- Enumeration value SOUND_VOICE
--
-- @field [parent=#SoundType] #number SOUND_VOICE

---
-- Enumeration value SOUND_MUSIC
--
-- @field [parent=#SoundType] #number SOUND_MUSIC

---
-- Enumeration value SOUND_MASTER
--
-- @field [parent=#SoundType] #number SOUND_MASTER

---
-- Enumeration value MAX_SOUND_TYPES
--
-- @field [parent=#SoundType] #number MAX_SOUND_TYPES


return nil
