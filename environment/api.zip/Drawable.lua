---
-- Module Drawable
-- extends Component
--
-- @module Drawable

---
-- Function SetDrawDistance
--
-- @function [parent=#Drawable] SetDrawDistance
-- @param #number distancedistance

---
-- Function SetShadowDistance
--
-- @function [parent=#Drawable] SetShadowDistance
-- @param #number distancedistance

---
-- Function SetLodBias
--
-- @function [parent=#Drawable] SetLodBias
-- @param #number biasbias

---
-- Function SetViewMask
--
-- @function [parent=#Drawable] SetViewMask
-- @param #number maskmask

---
-- Function SetLightMask
--
-- @function [parent=#Drawable] SetLightMask
-- @param #number maskmask

---
-- Function SetShadowMask
--
-- @function [parent=#Drawable] SetShadowMask
-- @param #number maskmask

---
-- Function SetZoneMask
--
-- @function [parent=#Drawable] SetZoneMask
-- @param #number maskmask

---
-- Function SetMaxLights
--
-- @function [parent=#Drawable] SetMaxLights
-- @param #number numnum

---
-- Function SetCastShadows
--
-- @function [parent=#Drawable] SetCastShadows
-- @param #boolean enableenable

---
-- Function SetOccluder
--
-- @function [parent=#Drawable] SetOccluder
-- @param #boolean enableenable

---
-- Function SetOccludee
--
-- @function [parent=#Drawable] SetOccludee
-- @param #boolean enableenable

---
-- Function MarkForUpdate
--
-- @function [parent=#Drawable] MarkForUpdate

---
-- Function GetBoundingBox
--
-- @function [parent=#Drawable] GetBoundingBox
-- @return const BoundingBox#const BoundingBox

---
-- Function GetWorldBoundingBox
--
-- @function [parent=#Drawable] GetWorldBoundingBox
-- @return const BoundingBox#const BoundingBox

---
-- Function GetDrawableFlags
--
-- @function [parent=#Drawable] GetDrawableFlags
-- @return #string

---
-- Function GetDrawDistance
--
-- @function [parent=#Drawable] GetDrawDistance
-- @return #number

---
-- Function GetShadowDistance
--
-- @function [parent=#Drawable] GetShadowDistance
-- @return #number

---
-- Function GetLodBias
--
-- @function [parent=#Drawable] GetLodBias
-- @return #number

---
-- Function GetViewMask
--
-- @function [parent=#Drawable] GetViewMask
-- @return #number

---
-- Function GetLightMask
--
-- @function [parent=#Drawable] GetLightMask
-- @return #number

---
-- Function GetShadowMask
--
-- @function [parent=#Drawable] GetShadowMask
-- @return #number

---
-- Function GetZoneMask
--
-- @function [parent=#Drawable] GetZoneMask
-- @return #number

---
-- Function GetMaxLights
--
-- @function [parent=#Drawable] GetMaxLights
-- @return #number

---
-- Function GetCastShadows
--
-- @function [parent=#Drawable] GetCastShadows
-- @return #boolean

---
-- Function IsOccluder
--
-- @function [parent=#Drawable] IsOccluder
-- @return #boolean

---
-- Function IsOccludee
--
-- @function [parent=#Drawable] IsOccludee
-- @return #boolean

---
-- Function SetZone
--
-- @function [parent=#Drawable] SetZone
-- @param Zone#Zone zonezone
-- @param #boolean temporarytemporary

---
-- Function SetSortValue
--
-- @function [parent=#Drawable] SetSortValue
-- @param #number valuevalue

---
-- Function SetMinMaxZ
--
-- @function [parent=#Drawable] SetMinMaxZ
-- @param #number minZminZ
-- @param #number maxZmaxZ

---
-- Function MarkInView
--
-- @function [parent=#Drawable] MarkInView
-- @param FrameInfo#FrameInfo frameframe
-- @param #boolean mainViewmainView

---
-- Function ClearLights
--
-- @function [parent=#Drawable] ClearLights

---
-- Function AddLight
--
-- @function [parent=#Drawable] AddLight
-- @param Light#Light lightlight

---
-- Function AddVertexLight
--
-- @function [parent=#Drawable] AddVertexLight
-- @param Light#Light lightlight

---
-- Function LimitLights
--
-- @function [parent=#Drawable] LimitLights

---
-- Function LimitVertexLights
--
-- @function [parent=#Drawable] LimitVertexLights

---
-- Function SetBasePass
--
-- @function [parent=#Drawable] SetBasePass
-- @param #number batchIndexbatchIndex

---
-- Function GetOctant
--
-- @function [parent=#Drawable] GetOctant
-- @return Octant#Octant

---
-- Function GetZone
--
-- @function [parent=#Drawable] GetZone
-- @return Zone#Zone

---
-- Function GetLastZone
--
-- @function [parent=#Drawable] GetLastZone
-- @return Zone#Zone

---
-- Function IsZoneDirty
--
-- @function [parent=#Drawable] IsZoneDirty
-- @return #boolean

---
-- Function GetDistance
--
-- @function [parent=#Drawable] GetDistance
-- @return #number

---
-- Function GetLodDistance
--
-- @function [parent=#Drawable] GetLodDistance
-- @return #number

---
-- Function GetSortValue
--
-- @function [parent=#Drawable] GetSortValue
-- @return #number

---
-- Function IsInView
--
-- @function [parent=#Drawable] IsInView
-- @param #number frameNumberframeNumber
-- @return #boolean

---
-- Function IsInView
--
-- @function [parent=#Drawable] IsInView
-- @param FrameInfo#FrameInfo frameframe
-- @param #boolean mainViewmainView
-- @return #boolean

---
-- Function HasBasePass
--
-- @function [parent=#Drawable] HasBasePass
-- @param #number batchIndexbatchIndex
-- @return #boolean

---
-- Function GetFirstLight
--
-- @function [parent=#Drawable] GetFirstLight
-- @return Light#Light

---
-- Function GetMinZ
--
-- @function [parent=#Drawable] GetMinZ
-- @return #number

---
-- Function GetMaxZ
--
-- @function [parent=#Drawable] GetMaxZ
-- @return #number

---
-- Field worldBoundingBox (Read only)
--
-- @field [parent=#Drawable] BoundingBox#BoundingBox worldBoundingBox

---
-- Field drawableFlags (Read only)
--
-- @field [parent=#Drawable] #string drawableFlags

---
-- Field drawDistance
--
-- @field [parent=#Drawable] #number drawDistance

---
-- Field shadowDistance
--
-- @field [parent=#Drawable] #number shadowDistance

---
-- Field lodBias
--
-- @field [parent=#Drawable] #number lodBias

---
-- Field viewMask
--
-- @field [parent=#Drawable] #number viewMask

---
-- Field lightMask
--
-- @field [parent=#Drawable] #number lightMask

---
-- Field shadowMask
--
-- @field [parent=#Drawable] #number shadowMask

---
-- Field zoneMask
--
-- @field [parent=#Drawable] #number zoneMask

---
-- Field maxLights
--
-- @field [parent=#Drawable] #number maxLights

---
-- Field castShadows
--
-- @field [parent=#Drawable] #boolean castShadows

---
-- Field occluder
--
-- @field [parent=#Drawable] #boolean occluder

---
-- Field occludee
--
-- @field [parent=#Drawable] #boolean occludee

---
-- Field octant (Read only)
--
-- @field [parent=#Drawable] Octant#Octant octant

---
-- Field zone
--
-- @field [parent=#Drawable] Zone#Zone zone

---
-- Field lastZone (Read only)
--
-- @field [parent=#Drawable] Zone#Zone lastZone

---
-- Field zoneDirty (Read only)
--
-- @field [parent=#Drawable] #boolean zoneDirty

---
-- Field distance (Read only)
--
-- @field [parent=#Drawable] #number distance

---
-- Field lodDistance (Read only)
--
-- @field [parent=#Drawable] #number lodDistance

---
-- Field sortValue
--
-- @field [parent=#Drawable] #number sortValue

---
-- Field firstLight (Read only)
--
-- @field [parent=#Drawable] Light#Light firstLight

---
-- Field minZ (Read only)
--
-- @field [parent=#Drawable] #number minZ

---
-- Field maxZ (Read only)
--
-- @field [parent=#Drawable] #number maxZ

---
-- Function SetEnabled
--
-- @function [parent=#Drawable] SetEnabled
-- @param #boolean enableenable

---
-- Function Remove
--
-- @function [parent=#Drawable] Remove

---
-- Function GetID
--
-- @function [parent=#Drawable] GetID
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#Drawable] GetNode
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#Drawable] GetScene
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#Drawable] IsEnabled
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#Drawable] IsEnabledEffective
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#Drawable] GetComponent
-- @param ShortStringHash#ShortStringHash typetype
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#Drawable] GetComponent
-- @param #string typetype
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#Drawable] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#Drawable] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Drawable] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Drawable] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Drawable] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Drawable] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Drawable] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Drawable] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#Drawable] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Drawable] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Drawable] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Drawable] #string category


return nil
