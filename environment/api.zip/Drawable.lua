---
-- Module Drawable
-- Module Drawable extends Component
-- Generated on 2014-05-31
--
-- @module Drawable

---
-- Function SetDrawDistance()
-- Set draw distance.
--
-- @function [parent=#Drawable] SetDrawDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetShadowDistance()
-- Set shadow draw distance.
--
-- @function [parent=#Drawable] SetShadowDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetLodBias()
-- Set LOD bias.
--
-- @function [parent=#Drawable] SetLodBias
-- @param self Self reference
-- @param #number bias bias

---
-- Function SetViewMask()
-- Set view mask. Is and'ed with camera's view mask to see if the object should be rendered.
--
-- @function [parent=#Drawable] SetViewMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetLightMask()
-- Set light mask. Is and'ed with light's and zone's light mask to see if the object should be lit.
--
-- @function [parent=#Drawable] SetLightMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetShadowMask()
-- Set shadow mask. Is and'ed with light's light mask and zone's shadow mask to see if the object should be rendered to a shadow map.
--
-- @function [parent=#Drawable] SetShadowMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetZoneMask()
-- Set zone mask. Is and'ed with zone's zone mask to see if the object should belong to the zone.
--
-- @function [parent=#Drawable] SetZoneMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetMaxLights()
-- Set maximum number of per-pixel lights. Default 0 is unlimited.
--
-- @function [parent=#Drawable] SetMaxLights
-- @param self Self reference
-- @param #number num num

---
-- Function SetCastShadows()
-- Set shadowcaster flag.
--
-- @function [parent=#Drawable] SetCastShadows
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetOccluder()
-- Set occlusion flag.
--
-- @function [parent=#Drawable] SetOccluder
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetOccludee()
-- Set occludee flag.
--
-- @function [parent=#Drawable] SetOccludee
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function MarkForUpdate()
-- Mark for update and octree reinsertion. Update is automatically queued when the drawable's scene node moves or changes scale.
--
-- @function [parent=#Drawable] MarkForUpdate
-- @param self Self reference

---
-- Function GetBoundingBox()
-- Return local space bounding box. May not be applicable or properly updated on all drawables.
--
-- @function [parent=#Drawable] GetBoundingBox
-- @param self Self reference
-- @return const BoundingBox#const BoundingBox

---
-- Function GetWorldBoundingBox()
-- Return world-space bounding box.
--
-- @function [parent=#Drawable] GetWorldBoundingBox
-- @param self Self reference
-- @return const BoundingBox#const BoundingBox

---
-- Function GetDrawableFlags()
-- Return drawable flags.
--
-- @function [parent=#Drawable] GetDrawableFlags
-- @param self Self reference
-- @return #string

---
-- Function GetDrawDistance()
-- Return draw distance.
--
-- @function [parent=#Drawable] GetDrawDistance
-- @param self Self reference
-- @return #number

---
-- Function GetShadowDistance()
-- Return shadow draw distance.
--
-- @function [parent=#Drawable] GetShadowDistance
-- @param self Self reference
-- @return #number

---
-- Function GetLodBias()
-- Return LOD bias.
--
-- @function [parent=#Drawable] GetLodBias
-- @param self Self reference
-- @return #number

---
-- Function GetViewMask()
-- Return view mask.
--
-- @function [parent=#Drawable] GetViewMask
-- @param self Self reference
-- @return #number

---
-- Function GetLightMask()
-- Return light mask.
--
-- @function [parent=#Drawable] GetLightMask
-- @param self Self reference
-- @return #number

---
-- Function GetShadowMask()
-- Return shadow mask.
--
-- @function [parent=#Drawable] GetShadowMask
-- @param self Self reference
-- @return #number

---
-- Function GetZoneMask()
-- Return zone mask.
--
-- @function [parent=#Drawable] GetZoneMask
-- @param self Self reference
-- @return #number

---
-- Function GetMaxLights()
-- Return maximum number of per-pixel lights.
--
-- @function [parent=#Drawable] GetMaxLights
-- @param self Self reference
-- @return #number

---
-- Function GetCastShadows()
-- Return shadowcaster flag.
--
-- @function [parent=#Drawable] GetCastShadows
-- @param self Self reference
-- @return #boolean

---
-- Function IsOccluder()
-- Return occluder flag.
--
-- @function [parent=#Drawable] IsOccluder
-- @param self Self reference
-- @return #boolean

---
-- Function IsOccludee()
-- Return occludee flag.
--
-- @function [parent=#Drawable] IsOccludee
-- @param self Self reference
-- @return #boolean

---
-- Function IsInView()
-- Return whether is in view this frame from any viewport camera. Excludes shadow map cameras.
--
-- @function [parent=#Drawable] IsInView
-- @param self Self reference
-- @return #boolean

---
-- Function IsInView()
-- Return whether is in view of a specific camera this frame. Pass in a null camera to allow any camera, including shadow map cameras.
--
-- @function [parent=#Drawable] IsInView
-- @param self Self reference
-- @param Camera#Camera tolua_var_2 tolua_var_2
-- @return #boolean

---
-- Function GetZone()
-- Return current zone.
--
-- @function [parent=#Drawable] GetZone
-- @param self Self reference
-- @return Zone#Zone

---
-- Field worldBoundingBox (Read only)
--
-- @field [parent=#Drawable] BoundingBox#BoundingBox worldBoundingBox

---
-- Field drawableFlags (Read only)
--
-- @field [parent=#Drawable] #string drawableFlags

---
-- Field drawDistance
--
-- @field [parent=#Drawable] #number drawDistance

---
-- Field shadowDistance
--
-- @field [parent=#Drawable] #number shadowDistance

---
-- Field lodBias
--
-- @field [parent=#Drawable] #number lodBias

---
-- Field viewMask
--
-- @field [parent=#Drawable] #number viewMask

---
-- Field lightMask
--
-- @field [parent=#Drawable] #number lightMask

---
-- Field shadowMask
--
-- @field [parent=#Drawable] #number shadowMask

---
-- Field zoneMask
--
-- @field [parent=#Drawable] #number zoneMask

---
-- Field maxLights
--
-- @field [parent=#Drawable] #number maxLights

---
-- Field castShadows
--
-- @field [parent=#Drawable] #boolean castShadows

---
-- Field occluder
--
-- @field [parent=#Drawable] #boolean occluder

---
-- Field occludee
--
-- @field [parent=#Drawable] #boolean occludee

---
-- Field inView (Read only)
--
-- @field [parent=#Drawable] #boolean inView

---
-- Field zone (Read only)
--
-- @field [parent=#Drawable] Zone#Zone zone


return nil
