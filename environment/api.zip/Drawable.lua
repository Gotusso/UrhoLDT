---
-- Module Drawable
-- Module Drawable extends Component
-- Generated on 2014-03-13
--
-- @module Drawable

---
-- Function SetDrawDistance
--
-- @function [parent=#Drawable] SetDrawDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetShadowDistance
--
-- @function [parent=#Drawable] SetShadowDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetLodBias
--
-- @function [parent=#Drawable] SetLodBias
-- @param self Self reference
-- @param #number bias bias

---
-- Function SetViewMask
--
-- @function [parent=#Drawable] SetViewMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetLightMask
--
-- @function [parent=#Drawable] SetLightMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetShadowMask
--
-- @function [parent=#Drawable] SetShadowMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetZoneMask
--
-- @function [parent=#Drawable] SetZoneMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetMaxLights
--
-- @function [parent=#Drawable] SetMaxLights
-- @param self Self reference
-- @param #number num num

---
-- Function SetCastShadows
--
-- @function [parent=#Drawable] SetCastShadows
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetOccluder
--
-- @function [parent=#Drawable] SetOccluder
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetOccludee
--
-- @function [parent=#Drawable] SetOccludee
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function MarkForUpdate
--
-- @function [parent=#Drawable] MarkForUpdate
-- @param self Self reference

---
-- Function GetBoundingBox
--
-- @function [parent=#Drawable] GetBoundingBox
-- @param self Self reference
-- @return const BoundingBox#const BoundingBox

---
-- Function GetWorldBoundingBox
--
-- @function [parent=#Drawable] GetWorldBoundingBox
-- @param self Self reference
-- @return const BoundingBox#const BoundingBox

---
-- Function GetDrawableFlags
--
-- @function [parent=#Drawable] GetDrawableFlags
-- @param self Self reference
-- @return #string

---
-- Function GetDrawDistance
--
-- @function [parent=#Drawable] GetDrawDistance
-- @param self Self reference
-- @return #number

---
-- Function GetShadowDistance
--
-- @function [parent=#Drawable] GetShadowDistance
-- @param self Self reference
-- @return #number

---
-- Function GetLodBias
--
-- @function [parent=#Drawable] GetLodBias
-- @param self Self reference
-- @return #number

---
-- Function GetViewMask
--
-- @function [parent=#Drawable] GetViewMask
-- @param self Self reference
-- @return #number

---
-- Function GetLightMask
--
-- @function [parent=#Drawable] GetLightMask
-- @param self Self reference
-- @return #number

---
-- Function GetShadowMask
--
-- @function [parent=#Drawable] GetShadowMask
-- @param self Self reference
-- @return #number

---
-- Function GetZoneMask
--
-- @function [parent=#Drawable] GetZoneMask
-- @param self Self reference
-- @return #number

---
-- Function GetMaxLights
--
-- @function [parent=#Drawable] GetMaxLights
-- @param self Self reference
-- @return #number

---
-- Function GetCastShadows
--
-- @function [parent=#Drawable] GetCastShadows
-- @param self Self reference
-- @return #boolean

---
-- Function IsOccluder
--
-- @function [parent=#Drawable] IsOccluder
-- @param self Self reference
-- @return #boolean

---
-- Function IsOccludee
--
-- @function [parent=#Drawable] IsOccludee
-- @param self Self reference
-- @return #boolean

---
-- Function SetZone
--
-- @function [parent=#Drawable] SetZone
-- @param self Self reference
-- @param Zone#Zone zone zone
-- @param #boolean temporary temporary

---
-- Function SetSortValue
--
-- @function [parent=#Drawable] SetSortValue
-- @param self Self reference
-- @param #number value value

---
-- Function SetMinMaxZ
--
-- @function [parent=#Drawable] SetMinMaxZ
-- @param self Self reference
-- @param #number minZ minZ
-- @param #number maxZ maxZ

---
-- Function MarkInView
--
-- @function [parent=#Drawable] MarkInView
-- @param self Self reference
-- @param FrameInfo#FrameInfo frame frame
-- @param #boolean mainView mainView

---
-- Function ClearLights
--
-- @function [parent=#Drawable] ClearLights
-- @param self Self reference

---
-- Function AddLight
--
-- @function [parent=#Drawable] AddLight
-- @param self Self reference
-- @param Light#Light light light

---
-- Function AddVertexLight
--
-- @function [parent=#Drawable] AddVertexLight
-- @param self Self reference
-- @param Light#Light light light

---
-- Function LimitLights
--
-- @function [parent=#Drawable] LimitLights
-- @param self Self reference

---
-- Function LimitVertexLights
--
-- @function [parent=#Drawable] LimitVertexLights
-- @param self Self reference

---
-- Function SetBasePass
--
-- @function [parent=#Drawable] SetBasePass
-- @param self Self reference
-- @param #number batchIndex batchIndex

---
-- Function GetOctant
--
-- @function [parent=#Drawable] GetOctant
-- @param self Self reference
-- @return Octant#Octant

---
-- Function GetZone
--
-- @function [parent=#Drawable] GetZone
-- @param self Self reference
-- @return Zone#Zone

---
-- Function GetLastZone
--
-- @function [parent=#Drawable] GetLastZone
-- @param self Self reference
-- @return Zone#Zone

---
-- Function IsZoneDirty
--
-- @function [parent=#Drawable] IsZoneDirty
-- @param self Self reference
-- @return #boolean

---
-- Function GetDistance
--
-- @function [parent=#Drawable] GetDistance
-- @param self Self reference
-- @return #number

---
-- Function GetLodDistance
--
-- @function [parent=#Drawable] GetLodDistance
-- @param self Self reference
-- @return #number

---
-- Function GetSortValue
--
-- @function [parent=#Drawable] GetSortValue
-- @param self Self reference
-- @return #number

---
-- Function IsInView
--
-- @function [parent=#Drawable] IsInView
-- @param self Self reference
-- @param #number frameNumber frameNumber
-- @return #boolean

---
-- Function IsInView
--
-- @function [parent=#Drawable] IsInView
-- @param self Self reference
-- @param FrameInfo#FrameInfo frame frame
-- @param #boolean mainView mainView
-- @return #boolean

---
-- Function HasBasePass
--
-- @function [parent=#Drawable] HasBasePass
-- @param self Self reference
-- @param #number batchIndex batchIndex
-- @return #boolean

---
-- Function GetFirstLight
--
-- @function [parent=#Drawable] GetFirstLight
-- @param self Self reference
-- @return Light#Light

---
-- Function GetMinZ
--
-- @function [parent=#Drawable] GetMinZ
-- @param self Self reference
-- @return #number

---
-- Function GetMaxZ
--
-- @function [parent=#Drawable] GetMaxZ
-- @param self Self reference
-- @return #number

---
-- Field worldBoundingBox (Read only)
--
-- @field [parent=#Drawable] BoundingBox#BoundingBox worldBoundingBox

---
-- Field drawableFlags (Read only)
--
-- @field [parent=#Drawable] #string drawableFlags

---
-- Field drawDistance
--
-- @field [parent=#Drawable] #number drawDistance

---
-- Field shadowDistance
--
-- @field [parent=#Drawable] #number shadowDistance

---
-- Field lodBias
--
-- @field [parent=#Drawable] #number lodBias

---
-- Field viewMask
--
-- @field [parent=#Drawable] #number viewMask

---
-- Field lightMask
--
-- @field [parent=#Drawable] #number lightMask

---
-- Field shadowMask
--
-- @field [parent=#Drawable] #number shadowMask

---
-- Field zoneMask
--
-- @field [parent=#Drawable] #number zoneMask

---
-- Field maxLights
--
-- @field [parent=#Drawable] #number maxLights

---
-- Field castShadows
--
-- @field [parent=#Drawable] #boolean castShadows

---
-- Field occluder
--
-- @field [parent=#Drawable] #boolean occluder

---
-- Field occludee
--
-- @field [parent=#Drawable] #boolean occludee

---
-- Field octant (Read only)
--
-- @field [parent=#Drawable] Octant#Octant octant

---
-- Field zone
--
-- @field [parent=#Drawable] Zone#Zone zone

---
-- Field lastZone (Read only)
--
-- @field [parent=#Drawable] Zone#Zone lastZone

---
-- Field zoneDirty (Read only)
--
-- @field [parent=#Drawable] #boolean zoneDirty

---
-- Field distance (Read only)
--
-- @field [parent=#Drawable] #number distance

---
-- Field lodDistance (Read only)
--
-- @field [parent=#Drawable] #number lodDistance

---
-- Field sortValue
--
-- @field [parent=#Drawable] #number sortValue

---
-- Field firstLight (Read only)
--
-- @field [parent=#Drawable] Light#Light firstLight

---
-- Field minZ (Read only)
--
-- @field [parent=#Drawable] #number minZ

---
-- Field maxZ (Read only)
--
-- @field [parent=#Drawable] #number maxZ

---
-- Function SetEnabled
--
-- @function [parent=#Drawable] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Remove
--
-- @function [parent=#Drawable] Remove
-- @param self Self reference

---
-- Function GetID
--
-- @function [parent=#Drawable] GetID
-- @param self Self reference
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#Drawable] GetNode
-- @param self Self reference
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#Drawable] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#Drawable] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#Drawable] IsEnabledEffective
-- @param self Self reference
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#Drawable] GetComponent
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#Drawable] GetComponent
-- @param self Self reference
-- @param #string type type
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#Drawable] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#Drawable] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Drawable] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Drawable] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Drawable] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Drawable] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Drawable] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Drawable] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#Drawable] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Drawable] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Drawable] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Drawable] #string category


return nil
