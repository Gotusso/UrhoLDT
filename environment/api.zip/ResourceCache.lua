---
-- Module ResourceCache
--
-- @module ResourceCache

---
-- Function ReleaseAllResources
--
-- @function [parent=#ResourceCache] ReleaseAllResources
-- @param #boolean forceforce

---
-- Function ReloadResource
--
-- @function [parent=#ResourceCache] ReloadResource
-- @param Resource#Resource resourceresource
-- @return #boolean

---
-- Function SetMemoryBudget
--
-- @function [parent=#ResourceCache] SetMemoryBudget
-- @param ShortStringHash#ShortStringHash typetype
-- @param #number budgetbudget

---
-- Function SetMemoryBudget
--
-- @function [parent=#ResourceCache] SetMemoryBudget
-- @param #string typetype
-- @param #number budgetbudget

---
-- Function SetAutoReloadResources
--
-- @function [parent=#ResourceCache] SetAutoReloadResources
-- @param #boolean enableenable

---
-- Function SetSearchPackagesFirst
--
-- @function [parent=#ResourceCache] SetSearchPackagesFirst
-- @param #boolean valuevalue

---
-- Function GetFile
--
-- @function [parent=#ResourceCache] GetFile
-- @param #string namename
-- @return File#File

---
-- Function GetResource
--
-- @function [parent=#ResourceCache] GetResource
-- @param #string typetype
-- @param #string namename
-- @param #boolean SendEventOnFailureSendEventOnFailure
-- @return Resource#Resource

---
-- Function Exists
--
-- @function [parent=#ResourceCache] Exists
-- @param #string namename
-- @return #boolean

---
-- Function GetMemoryBudget
--
-- @function [parent=#ResourceCache] GetMemoryBudget
-- @param ShortStringHash#ShortStringHash typetype
-- @return #number

---
-- Function GetMemoryUse
--
-- @function [parent=#ResourceCache] GetMemoryUse
-- @param ShortStringHash#ShortStringHash typetype
-- @return #number

---
-- Function GetTotalMemoryUse
--
-- @function [parent=#ResourceCache] GetTotalMemoryUse
-- @return #number

---
-- Function GetResourceFileName
--
-- @function [parent=#ResourceCache] GetResourceFileName
-- @param #string namename
-- @return #string

---
-- Function GetAutoReloadResources
--
-- @function [parent=#ResourceCache] GetAutoReloadResources
-- @return #boolean

---
-- Function GetSearchPackagesFirst
--
-- @function [parent=#ResourceCache] GetSearchPackagesFirst
-- @return #boolean

---
-- Function GetPreferredResourceDir
--
-- @function [parent=#ResourceCache] GetPreferredResourceDir
-- @param #string pathpath
-- @return #string

---
-- Function SanitateResourceName
--
-- @function [parent=#ResourceCache] SanitateResourceName
-- @param #string namename
-- @return #string

---
-- Function SanitateResourceDirName
--
-- @function [parent=#ResourceCache] SanitateResourceDirName
-- @param #string namename
-- @return #string

---
-- Field totalMemoryUse (Read only)
--
-- @field [parent=#ResourceCache] #number totalMemoryUse

---
-- Field autoReloadResources (Read only)
--
-- @field [parent=#ResourceCache] #boolean autoReloadResources

---
-- Field searchPackagesFirst (Read only)
--
-- @field [parent=#ResourceCache] #boolean searchPackagesFirst


return nil
