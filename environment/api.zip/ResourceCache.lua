---
-- Module ResourceCache
-- Generated on 2014-03-13
--
-- @module ResourceCache

---
-- Function ReleaseAllResources
--
-- @function [parent=#ResourceCache] ReleaseAllResources
-- @param self Self reference
-- @param #boolean force force

---
-- Function ReloadResource
--
-- @function [parent=#ResourceCache] ReloadResource
-- @param self Self reference
-- @param Resource#Resource resource resource
-- @return #boolean

---
-- Function SetMemoryBudget
--
-- @function [parent=#ResourceCache] SetMemoryBudget
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @param #number budget budget

---
-- Function SetMemoryBudget
--
-- @function [parent=#ResourceCache] SetMemoryBudget
-- @param self Self reference
-- @param #string type type
-- @param #number budget budget

---
-- Function SetAutoReloadResources
--
-- @function [parent=#ResourceCache] SetAutoReloadResources
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetSearchPackagesFirst
--
-- @function [parent=#ResourceCache] SetSearchPackagesFirst
-- @param self Self reference
-- @param #boolean value value

---
-- Function GetFile
--
-- @function [parent=#ResourceCache] GetFile
-- @param self Self reference
-- @param #string name name
-- @return File#File

---
-- Function GetResource
--
-- @function [parent=#ResourceCache] GetResource
-- @param self Self reference
-- @param #string type type
-- @param #string name name
-- @param #boolean SendEventOnFailure SendEventOnFailure
-- @return Resource#Resource

---
-- Function Exists
--
-- @function [parent=#ResourceCache] Exists
-- @param self Self reference
-- @param #string name name
-- @return #boolean

---
-- Function GetMemoryBudget
--
-- @function [parent=#ResourceCache] GetMemoryBudget
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return #number

---
-- Function GetMemoryUse
--
-- @function [parent=#ResourceCache] GetMemoryUse
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return #number

---
-- Function GetTotalMemoryUse
--
-- @function [parent=#ResourceCache] GetTotalMemoryUse
-- @param self Self reference
-- @return #number

---
-- Function GetResourceFileName
--
-- @function [parent=#ResourceCache] GetResourceFileName
-- @param self Self reference
-- @param #string name name
-- @return #string

---
-- Function GetAutoReloadResources
--
-- @function [parent=#ResourceCache] GetAutoReloadResources
-- @param self Self reference
-- @return #boolean

---
-- Function GetSearchPackagesFirst
--
-- @function [parent=#ResourceCache] GetSearchPackagesFirst
-- @param self Self reference
-- @return #boolean

---
-- Function GetPreferredResourceDir
--
-- @function [parent=#ResourceCache] GetPreferredResourceDir
-- @param self Self reference
-- @param #string path path
-- @return #string

---
-- Function SanitateResourceName
--
-- @function [parent=#ResourceCache] SanitateResourceName
-- @param self Self reference
-- @param #string name name
-- @return #string

---
-- Function SanitateResourceDirName
--
-- @function [parent=#ResourceCache] SanitateResourceDirName
-- @param self Self reference
-- @param #string name name
-- @return #string

---
-- Field totalMemoryUse (Read only)
--
-- @field [parent=#ResourceCache] #number totalMemoryUse

---
-- Field autoReloadResources (Read only)
--
-- @field [parent=#ResourceCache] #boolean autoReloadResources

---
-- Field searchPackagesFirst (Read only)
--
-- @field [parent=#ResourceCache] #boolean searchPackagesFirst


return nil
