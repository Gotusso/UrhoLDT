---
-- Module ResourceCache
-- Generated on 2014-05-31
--
-- @module ResourceCache

---
-- Function ReleaseAllResources()
-- Release all resources. When called with the force flag false, releases all currently unused resources.
--
-- @function [parent=#ResourceCache] ReleaseAllResources
-- @param self Self reference
-- @param #boolean force force

---
-- Function ReloadResource()
-- Reload a resource. Return false and release it if fails.
--
-- @function [parent=#ResourceCache] ReloadResource
-- @param self Self reference
-- @param Resource#Resource resource resource
-- @return #boolean

---
-- Function SetMemoryBudget()
-- Set memory budget for a specific resource type, default 0 is unlimited.
--
-- @function [parent=#ResourceCache] SetMemoryBudget
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @param #number budget budget

---
-- Function SetMemoryBudget()
--
-- @function [parent=#ResourceCache] SetMemoryBudget
-- @param self Self reference
-- @param #string type type
-- @param #number budget budget

---
-- Function SetAutoReloadResources()
-- Enable or disable automatic reloading of resources as files are modified. Default false.
--
-- @function [parent=#ResourceCache] SetAutoReloadResources
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetReturnFailedResources()
-- Enable or disable returning resources that failed to load. Default false. This may be useful in editing to not lose resource ref attributes.
--
-- @function [parent=#ResourceCache] SetReturnFailedResources
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetSearchPackagesFirst()
-- Define whether when getting resources should check package files or directories first. True for packages, false for directories.
--
-- @function [parent=#ResourceCache] SetSearchPackagesFirst
-- @param self Self reference
-- @param #boolean value value

---
-- Function GetFile()
-- Open and return a file from the resource load paths or from inside a package file. If not found, use a fallback search with absolute path. Return null if fails.
--
-- @function [parent=#ResourceCache] GetFile
-- @param self Self reference
-- @param #string name name
-- @return File#File

---
-- Function GetResource()
--
-- @function [parent=#ResourceCache] GetResource
-- @param self Self reference
-- @param #string type type
-- @param #string name name
-- @param #boolean SendEventOnFailure SendEventOnFailure
-- @return Resource#Resource

---
-- Function Exists()
-- Return whether a file exists by name.
--
-- @function [parent=#ResourceCache] Exists
-- @param self Self reference
-- @param #string name name
-- @return #boolean

---
-- Function GetMemoryBudget()
-- Return memory budget for a resource type.
--
-- @function [parent=#ResourceCache] GetMemoryBudget
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return #number

---
-- Function GetMemoryUse()
-- Return total memory use for a resource type.
--
-- @function [parent=#ResourceCache] GetMemoryUse
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return #number

---
-- Function GetTotalMemoryUse()
-- Return total memory use for all resources.
--
-- @function [parent=#ResourceCache] GetTotalMemoryUse
-- @param self Self reference
-- @return #number

---
-- Function GetResourceFileName()
-- Return full absolute file name of resource if possible.
--
-- @function [parent=#ResourceCache] GetResourceFileName
-- @param self Self reference
-- @param #string name name
-- @return #string

---
-- Function GetAutoReloadResources()
-- Return whether automatic resource reloading is enabled.
--
-- @function [parent=#ResourceCache] GetAutoReloadResources
-- @param self Self reference
-- @return #boolean

---
-- Function GetReturnFailedResources()
-- Return whether resources that failed to load are returned.
--
-- @function [parent=#ResourceCache] GetReturnFailedResources
-- @param self Self reference
-- @return #boolean

---
-- Function GetSearchPackagesFirst()
-- Define whether when getting resources should check package files or directories first.
--
-- @function [parent=#ResourceCache] GetSearchPackagesFirst
-- @param self Self reference
-- @return #boolean

---
-- Function GetPreferredResourceDir()
-- Return either the path itself or its parent, based on which of them has recognized resource subdirectories.
--
-- @function [parent=#ResourceCache] GetPreferredResourceDir
-- @param self Self reference
-- @param #string path path
-- @return #string

---
-- Function SanitateResourceName()
-- Remove unsupported constructs from the resource name to prevent ambiguity, and normalize absolute filename to resource path relative if possible.
--
-- @function [parent=#ResourceCache] SanitateResourceName
-- @param self Self reference
-- @param #string name name
-- @return #string

---
-- Function SanitateResourceDirName()
-- Remove unnecessary constructs from a resource directory name and ensure it to be an absolute path.
--
-- @function [parent=#ResourceCache] SanitateResourceDirName
-- @param self Self reference
-- @param #string name name
-- @return #string

---
-- Field totalMemoryUse (Read only)
--
-- @field [parent=#ResourceCache] #number totalMemoryUse

---
-- Field autoReloadResources (Read only)
--
-- @field [parent=#ResourceCache] #boolean autoReloadResources

---
-- Field returnFailedResources (Read only)
--
-- @field [parent=#ResourceCache] #boolean returnFailedResources

---
-- Field searchPackagesFirst (Read only)
--
-- @field [parent=#ResourceCache] #boolean searchPackagesFirst


return nil
