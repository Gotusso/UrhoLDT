---
-- Enumeration HorizontalAlignment
--
-- @module HorizontalAlignment

---
-- Enumeration value HA_LEFT
--
-- @field [parent=#HorizontalAlignment] #number HA_LEFT

---
-- Enumeration value HA_CENTER
--
-- @field [parent=#HorizontalAlignment] #number HA_CENTER

---
-- Enumeration value HA_RIGHT
--
-- @field [parent=#HorizontalAlignment] #number HA_RIGHT


return nil
