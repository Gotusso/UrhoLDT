---
-- Module ConstraintWheel2D
-- Module ConstraintWheel2D extends Constraint2D
-- Generated on 2014-05-31
--
-- @module ConstraintWheel2D

---
-- Function SetAnchor()
-- Set anchor.
--
-- @function [parent=#ConstraintWheel2D] SetAnchor
-- @param self Self reference
-- @param Vector2#Vector2 anchor anchor

---
-- Function SetAxis()
-- Set axis.
--
-- @function [parent=#ConstraintWheel2D] SetAxis
-- @param self Self reference
-- @param Vector2#Vector2 axis axis

---
-- Function SetEnableMotor()
-- Set enable motor.
--
-- @function [parent=#ConstraintWheel2D] SetEnableMotor
-- @param self Self reference
-- @param #boolean enableMotor enableMotor

---
-- Function SetMaxMotorTorque()
-- Set max motor torque.
--
-- @function [parent=#ConstraintWheel2D] SetMaxMotorTorque
-- @param self Self reference
-- @param #number maxMotorTorque maxMotorTorque

---
-- Function SetMotorSpeed()
-- Set motor speed.
--
-- @function [parent=#ConstraintWheel2D] SetMotorSpeed
-- @param self Self reference
-- @param #number motorSpeed motorSpeed

---
-- Function SetFrequencyHz()
-- Set frequency Hz.
--
-- @function [parent=#ConstraintWheel2D] SetFrequencyHz
-- @param self Self reference
-- @param #number frequencyHz frequencyHz

---
-- Function SetDampingRatio()
-- Set damping ratio.
--
-- @function [parent=#ConstraintWheel2D] SetDampingRatio
-- @param self Self reference
-- @param #number dampingRatio dampingRatio

---
-- Function GetAnchor()
-- Return anchor.
--
-- @function [parent=#ConstraintWheel2D] GetAnchor
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Function GetAxis()
-- Return axis.
--
-- @function [parent=#ConstraintWheel2D] GetAxis
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Function GetEnableMotor()
-- Return enable motor.
--
-- @function [parent=#ConstraintWheel2D] GetEnableMotor
-- @param self Self reference
-- @return #boolean

---
-- Function GetMaxMotorTorque()
-- Return maxMotor torque.
--
-- @function [parent=#ConstraintWheel2D] GetMaxMotorTorque
-- @param self Self reference
-- @return #number

---
-- Function GetMotorSpeed()
-- Return motor speed.
--
-- @function [parent=#ConstraintWheel2D] GetMotorSpeed
-- @param self Self reference
-- @return #number

---
-- Function GetFrequencyHz()
-- Return frequency Hz.
--
-- @function [parent=#ConstraintWheel2D] GetFrequencyHz
-- @param self Self reference
-- @return #number

---
-- Function GetDampingRatio()
-- Return damping ratio.
--
-- @function [parent=#ConstraintWheel2D] GetDampingRatio
-- @param self Self reference
-- @return #number

---
-- Field anchor
--
-- @field [parent=#ConstraintWheel2D] Vector2#Vector2 anchor

---
-- Field axis
--
-- @field [parent=#ConstraintWheel2D] Vector2#Vector2 axis

---
-- Field enableMotor
--
-- @field [parent=#ConstraintWheel2D] #boolean enableMotor

---
-- Field maxMotorTorque
--
-- @field [parent=#ConstraintWheel2D] #number maxMotorTorque

---
-- Field motorSpeed
--
-- @field [parent=#ConstraintWheel2D] #number motorSpeed

---
-- Field frequencyHz
--
-- @field [parent=#ConstraintWheel2D] #number frequencyHz

---
-- Field dampingRatio
--
-- @field [parent=#ConstraintWheel2D] #number dampingRatio


return nil
