---
-- Module ConstraintDistance2D
-- Module ConstraintDistance2D extends Constraint2D
-- Generated on 2014-05-31
--
-- @module ConstraintDistance2D

---
-- Function SetOwnerBodyAnchor()
-- Set owner body anchor.
--
-- @function [parent=#ConstraintDistance2D] SetOwnerBodyAnchor
-- @param self Self reference
-- @param Vector2#Vector2 anchor anchor

---
-- Function SetOtherBodyAnchor()
-- Set other body anchor.
--
-- @function [parent=#ConstraintDistance2D] SetOtherBodyAnchor
-- @param self Self reference
-- @param Vector2#Vector2 anchor anchor

---
-- Function SetFrequencyHz()
-- Set frequency Hz.
--
-- @function [parent=#ConstraintDistance2D] SetFrequencyHz
-- @param self Self reference
-- @param #number frequencyHz frequencyHz

---
-- Function SetDampingRatio()
-- Set damping ratio.
--
-- @function [parent=#ConstraintDistance2D] SetDampingRatio
-- @param self Self reference
-- @param #number dampingRatio dampingRatio

---
-- Function GetOwnerBodyAnchor()
-- Return owner body anchor.
--
-- @function [parent=#ConstraintDistance2D] GetOwnerBodyAnchor
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Function GetOtherBodyAnchor()
-- Return other body anchor.
--
-- @function [parent=#ConstraintDistance2D] GetOtherBodyAnchor
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Function GetFrequencyHz()
-- Return frequency Hz.
--
-- @function [parent=#ConstraintDistance2D] GetFrequencyHz
-- @param self Self reference
-- @return #number

---
-- Function GetDampingRatio()
-- Return damping ratio.
--
-- @function [parent=#ConstraintDistance2D] GetDampingRatio
-- @param self Self reference
-- @return #number

---
-- Field ownerBodyAnchor
--
-- @field [parent=#ConstraintDistance2D] Vector2#Vector2 ownerBodyAnchor

---
-- Field otherBodyAnchor
--
-- @field [parent=#ConstraintDistance2D] Vector2#Vector2 otherBodyAnchor

---
-- Field frequencyHz
--
-- @field [parent=#ConstraintDistance2D] #number frequencyHz

---
-- Field dampingRatio
--
-- @field [parent=#ConstraintDistance2D] #number dampingRatio


return nil
