---
-- Module Spline
-- Extends Component
--
-- @module Spline

---
-- Function SetInterpolationMode
--
-- @function [parent=#Spline] SetInterpolationMode
-- @param InterpolationMode#InterpolationMode interpolationModeinterpolationMode

---
-- Function SetSpeed
--
-- @function [parent=#Spline] SetSpeed
-- @param #number speedspeed

---
-- Function SetPosition
--
-- @function [parent=#Spline] SetPosition
-- @param #number factorfactor

---
-- Function GetInterpolationMode
--
-- @function [parent=#Spline] GetInterpolationMode
-- @return InterpolationMode#InterpolationMode

---
-- Function GetSpeed
--
-- @function [parent=#Spline] GetSpeed
-- @return #number

---
-- Function GetPosition
--
-- @function [parent=#Spline] GetPosition
-- @return Vector3#Vector3

---
-- Function Push
--
-- @function [parent=#Spline] Push
-- @param Vector3#Vector3 controlPointcontrolPoint

---
-- Function Pop
--
-- @function [parent=#Spline] Pop

---
-- Function GetPoint
--
-- @function [parent=#Spline] GetPoint
-- @param #number factorfactor
-- @return Vector3#Vector3

---
-- Function Move
--
-- @function [parent=#Spline] Move
-- @param #number timeSteptimeStep

---
-- Function Reset
--
-- @function [parent=#Spline] Reset

---
-- Function IsFinished
--
-- @function [parent=#Spline] IsFinished
-- @return #boolean

---
-- Field interpolationMode
--
-- @field [parent=#Spline] InterpolationMode#InterpolationMode interpolationMode

---
-- Field speed
--
-- @field [parent=#Spline] #number speed


return nil
