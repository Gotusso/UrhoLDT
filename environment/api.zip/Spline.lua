---
-- Module Spline
-- extends Component
--
-- @module Spline

---
-- Function SetInterpolationMode
--
-- @function [parent=#Spline] SetInterpolationMode
-- @param InterpolationMode#InterpolationMode interpolationModeinterpolationMode

---
-- Function SetSpeed
--
-- @function [parent=#Spline] SetSpeed
-- @param #number speedspeed

---
-- Function SetPosition
--
-- @function [parent=#Spline] SetPosition
-- @param #number factorfactor

---
-- Function GetInterpolationMode
--
-- @function [parent=#Spline] GetInterpolationMode
-- @return InterpolationMode#InterpolationMode

---
-- Function GetSpeed
--
-- @function [parent=#Spline] GetSpeed
-- @return #number

---
-- Function GetPosition
--
-- @function [parent=#Spline] GetPosition
-- @return Vector3#Vector3

---
-- Function Push
--
-- @function [parent=#Spline] Push
-- @param Vector3#Vector3 controlPointcontrolPoint

---
-- Function Pop
--
-- @function [parent=#Spline] Pop

---
-- Function GetPoint
--
-- @function [parent=#Spline] GetPoint
-- @param #number factorfactor
-- @return Vector3#Vector3

---
-- Function Move
--
-- @function [parent=#Spline] Move
-- @param #number timeSteptimeStep

---
-- Function Reset
--
-- @function [parent=#Spline] Reset

---
-- Function IsFinished
--
-- @function [parent=#Spline] IsFinished
-- @return #boolean

---
-- Field interpolationMode
--
-- @field [parent=#Spline] InterpolationMode#InterpolationMode interpolationMode

---
-- Field speed
--
-- @field [parent=#Spline] #number speed

---
-- Function SetEnabled
--
-- @function [parent=#Spline] SetEnabled
-- @param #boolean enableenable

---
-- Function Remove
--
-- @function [parent=#Spline] Remove

---
-- Function GetID
--
-- @function [parent=#Spline] GetID
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#Spline] GetNode
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#Spline] GetScene
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#Spline] IsEnabled
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#Spline] IsEnabledEffective
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#Spline] GetComponent
-- @param ShortStringHash#ShortStringHash typetype
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#Spline] GetComponent
-- @param #string typetype
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#Spline] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#Spline] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Spline] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Spline] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Spline] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Spline] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Spline] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Spline] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#Spline] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Spline] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Spline] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Spline] #string category


return nil
