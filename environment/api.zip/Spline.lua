---
-- Module Spline
-- Module Spline extends Component
-- Generated on 2014-03-13
--
-- @module Spline

---
-- Function SetInterpolationMode
--
-- @function [parent=#Spline] SetInterpolationMode
-- @param self Self reference
-- @param InterpolationMode#InterpolationMode interpolationMode interpolationMode

---
-- Function SetSpeed
--
-- @function [parent=#Spline] SetSpeed
-- @param self Self reference
-- @param #number speed speed

---
-- Function SetPosition
--
-- @function [parent=#Spline] SetPosition
-- @param self Self reference
-- @param #number factor factor

---
-- Function GetInterpolationMode
--
-- @function [parent=#Spline] GetInterpolationMode
-- @param self Self reference
-- @return InterpolationMode#InterpolationMode

---
-- Function GetSpeed
--
-- @function [parent=#Spline] GetSpeed
-- @param self Self reference
-- @return #number

---
-- Function GetPosition
--
-- @function [parent=#Spline] GetPosition
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function Push
--
-- @function [parent=#Spline] Push
-- @param self Self reference
-- @param Vector3#Vector3 controlPoint controlPoint

---
-- Function Pop
--
-- @function [parent=#Spline] Pop
-- @param self Self reference

---
-- Function GetPoint
--
-- @function [parent=#Spline] GetPoint
-- @param self Self reference
-- @param #number factor factor
-- @return Vector3#Vector3

---
-- Function Move
--
-- @function [parent=#Spline] Move
-- @param self Self reference
-- @param #number timeStep timeStep

---
-- Function Reset
--
-- @function [parent=#Spline] Reset
-- @param self Self reference

---
-- Function IsFinished
--
-- @function [parent=#Spline] IsFinished
-- @param self Self reference
-- @return #boolean

---
-- Field interpolationMode
--
-- @field [parent=#Spline] InterpolationMode#InterpolationMode interpolationMode

---
-- Field speed
--
-- @field [parent=#Spline] #number speed

---
-- Function SetEnabled
--
-- @function [parent=#Spline] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Remove
--
-- @function [parent=#Spline] Remove
-- @param self Self reference

---
-- Function GetID
--
-- @function [parent=#Spline] GetID
-- @param self Self reference
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#Spline] GetNode
-- @param self Self reference
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#Spline] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#Spline] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#Spline] IsEnabledEffective
-- @param self Self reference
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#Spline] GetComponent
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#Spline] GetComponent
-- @param self Self reference
-- @param #string type type
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#Spline] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#Spline] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Spline] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Spline] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Spline] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Spline] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Spline] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Spline] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#Spline] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Spline] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Spline] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Spline] #string category


return nil
