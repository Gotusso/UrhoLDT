---
-- Module Spline
-- Generated on 2014-05-31
--
-- @module Spline

---
-- Function Spline()
-- Default constructor.
--
-- @function [parent=#Spline] Spline
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#Spline] new
-- @param self Self reference
-- @return Spline#Spline

---
-- Function Spline()
-- Constructor setting InterpolationMode.
--
-- @function [parent=#Spline] Spline
-- @param self Self reference
-- @param InterpolationMode#InterpolationMode mode mode

---
-- Function new()
--
-- @function [parent=#Spline] new
-- @param self Self reference
-- @param InterpolationMode#InterpolationMode mode mode
-- @return Spline#Spline

---
-- Function Spline()
-- Copy constructor.
--
-- @function [parent=#Spline] Spline
-- @param self Self reference
-- @param Spline#Spline rhs rhs

---
-- Function new()
--
-- @function [parent=#Spline] new
-- @param self Self reference
-- @param Spline#Spline rhs rhs
-- @return Spline#Spline

---
-- Function delete()
--
-- @function [parent=#Spline] delete
-- @param self Self reference

---
-- Function operator==()
--
-- @function [parent=#Spline] operator==
-- @param self Self reference
-- @param Spline#Spline rhs rhs
-- @return #boolean

---
-- Function GetPoint()
--
-- @function [parent=#Spline] GetPoint
-- @param self Self reference
-- @param #number f f
-- @return Variant#Variant

---
-- Function GetKnot()
--
-- @function [parent=#Spline] GetKnot
-- @param self Self reference
-- @param #number index index
-- @return Variant#Variant

---
-- Function SetKnot()
--
-- @function [parent=#Spline] SetKnot
-- @param self Self reference
-- @param Variant#Variant knot knot
-- @param #number tolua_var_1 tolua_var_1

---
-- Function AddKnot()
--
-- @function [parent=#Spline] AddKnot
-- @param self Self reference
-- @param Variant#Variant knot knot

---
-- Function AddKnot()
--
-- @function [parent=#Spline] AddKnot
-- @param self Self reference
-- @param Variant#Variant knot knot
-- @param #number index index

---
-- Function RemoveKnot()
--
-- @function [parent=#Spline] RemoveKnot
-- @param self Self reference

---
-- Function RemoveKnot()
--
-- @function [parent=#Spline] RemoveKnot
-- @param self Self reference
-- @param #number index index

---
-- Function Clear()
--
-- @function [parent=#Spline] Clear
-- @param self Self reference

---
-- Field interpolationMode
--
-- @field [parent=#Spline] InterpolationMode#InterpolationMode interpolationMode


return nil
