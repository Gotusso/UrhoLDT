---
-- Module AnimationControl
-- Generated on 2014-05-31
--
-- @module AnimationControl

---
-- Function AnimationControl()
--
-- @function [parent=#AnimationControl] AnimationControl
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#AnimationControl] new
-- @param self Self reference
-- @return AnimationControl#AnimationControl

---
-- Function delete()
--
-- @function [parent=#AnimationControl] delete
-- @param self Self reference

---
-- Field hash_
--
-- @field [parent=#AnimationControl] StringHash#StringHash hash_

---
-- Field speed_
--
-- @field [parent=#AnimationControl] #number speed_

---
-- Field targetWeight_
--
-- @field [parent=#AnimationControl] #number targetWeight_

---
-- Field fadeTime_
--
-- @field [parent=#AnimationControl] #number fadeTime_

---
-- Field autoFadeTime_
--
-- @field [parent=#AnimationControl] #number autoFadeTime_

---
-- Field setTimeTtl_
--
-- @field [parent=#AnimationControl] #number setTimeTtl_

---
-- Field setWeightTtl_
--
-- @field [parent=#AnimationControl] #number setWeightTtl_

---
-- Field setTime_
--
-- @field [parent=#AnimationControl] short#short setTime_

---
-- Field setWeight_
--
-- @field [parent=#AnimationControl] #string setWeight_

---
-- Field setTimeRev_
--
-- @field [parent=#AnimationControl] #string setTimeRev_

---
-- Field setWeightRev_
--
-- @field [parent=#AnimationControl] #string setWeightRev_


return nil
