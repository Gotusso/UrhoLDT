---
-- Module Text3D
-- Extends Drawable
--
-- @module Text3D

---
-- Function Text3D
--
-- @function [parent=#Text3D] Text3D

---
-- Function new
--
-- @function [parent=#Text3D] new
-- @return Text3D#Text3D

---
-- Function delete
--
-- @function [parent=#Text3D] delete

---
-- Function SetFont
--
-- @function [parent=#Text3D] SetFont
-- @param #string fontNamefontName
-- @param #number sizesize
-- @return #boolean

---
-- Function SetFont
--
-- @function [parent=#Text3D] SetFont
-- @param Font#Font fontfont
-- @param #number sizesize
-- @return #boolean

---
-- Function SetMaterial
--
-- @function [parent=#Text3D] SetMaterial
-- @param Material#Material materialmaterial

---
-- Function SetText
--
-- @function [parent=#Text3D] SetText
-- @param #string texttext

---
-- Function SetAlignment
--
-- @function [parent=#Text3D] SetAlignment
-- @param HorizontalAlignment#HorizontalAlignment hAlignhAlign
-- @param VerticalAlignment#VerticalAlignment vAlignvAlign

---
-- Function SetHorizontalAlignment
--
-- @function [parent=#Text3D] SetHorizontalAlignment
-- @param HorizontalAlignment#HorizontalAlignment alignalign

---
-- Function SetVerticalAlignment
--
-- @function [parent=#Text3D] SetVerticalAlignment
-- @param VerticalAlignment#VerticalAlignment alignalign

---
-- Function SetTextAlignment
--
-- @function [parent=#Text3D] SetTextAlignment
-- @param HorizontalAlignment#HorizontalAlignment alignalign

---
-- Function SetRowSpacing
--
-- @function [parent=#Text3D] SetRowSpacing
-- @param #number spacingspacing

---
-- Function SetWordwrap
--
-- @function [parent=#Text3D] SetWordwrap
-- @param #boolean enableenable

---
-- Function SetTextEffect
--
-- @function [parent=#Text3D] SetTextEffect
-- @param TextEffect#TextEffect textEffecttextEffect

---
-- Function SetEffectColor
--
-- @function [parent=#Text3D] SetEffectColor
-- @param Color#Color effectColoreffectColor

---
-- Function SetEffectDepthBias
--
-- @function [parent=#Text3D] SetEffectDepthBias
-- @param #number biasbias

---
-- Function SetWidth
--
-- @function [parent=#Text3D] SetWidth
-- @param #number widthwidth

---
-- Function SetColor
--
-- @function [parent=#Text3D] SetColor
-- @param Color#Color colorcolor

---
-- Function SetColor
--
-- @function [parent=#Text3D] SetColor
-- @param Corner#Corner cornercorner
-- @param Color#Color colorcolor

---
-- Function SetOpacity
--
-- @function [parent=#Text3D] SetOpacity
-- @param #number opacityopacity

---
-- Function SetFaceCamera
--
-- @function [parent=#Text3D] SetFaceCamera
-- @param #boolean enableenable

---
-- Function GetFont
--
-- @function [parent=#Text3D] GetFont
-- @return Font#Font

---
-- Function GetMaterial
--
-- @function [parent=#Text3D] GetMaterial
-- @return Material#Material

---
-- Function GetFontSize
--
-- @function [parent=#Text3D] GetFontSize
-- @return #number

---
-- Function GetText
--
-- @function [parent=#Text3D] GetText
-- @return const String#const String

---
-- Function GetTextAlignment
--
-- @function [parent=#Text3D] GetTextAlignment
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetHorizontalAlignment
--
-- @function [parent=#Text3D] GetHorizontalAlignment
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetVerticalAlignment
--
-- @function [parent=#Text3D] GetVerticalAlignment
-- @return VerticalAlignment#VerticalAlignment

---
-- Function GetRowSpacing
--
-- @function [parent=#Text3D] GetRowSpacing
-- @return #number

---
-- Function GetWordwrap
--
-- @function [parent=#Text3D] GetWordwrap
-- @return #boolean

---
-- Function GetTextEffect
--
-- @function [parent=#Text3D] GetTextEffect
-- @return TextEffect#TextEffect

---
-- Function GetEffectColor
--
-- @function [parent=#Text3D] GetEffectColor
-- @return const Color#const Color

---
-- Function GetEffectDepthBias
--
-- @function [parent=#Text3D] GetEffectDepthBias
-- @return #number

---
-- Function GetWidth
--
-- @function [parent=#Text3D] GetWidth
-- @return #number

---
-- Function GetRowHeight
--
-- @function [parent=#Text3D] GetRowHeight
-- @return #number

---
-- Function GetNumRows
--
-- @function [parent=#Text3D] GetNumRows
-- @return #number

---
-- Function GetNumChars
--
-- @function [parent=#Text3D] GetNumChars
-- @return #number

---
-- Function GetRowWidth
--
-- @function [parent=#Text3D] GetRowWidth
-- @param #number indexindex
-- @return #number

---
-- Function GetCharPosition
--
-- @function [parent=#Text3D] GetCharPosition
-- @param #number indexindex
-- @return IntVector2#IntVector2

---
-- Function GetCharSize
--
-- @function [parent=#Text3D] GetCharSize
-- @param #number indexindex
-- @return IntVector2#IntVector2

---
-- Function GetColor
--
-- @function [parent=#Text3D] GetColor
-- @param Corner#Corner cornercorner
-- @return const Color#const Color

---
-- Function GetOpacity
--
-- @function [parent=#Text3D] GetOpacity
-- @return #number

---
-- Function GetFaceCamera
--
-- @function [parent=#Text3D] GetFaceCamera
-- @return #boolean

---
-- Field font
--
-- @field [parent=#Text3D] Font#Font font

---
-- Field material
--
-- @field [parent=#Text3D] Material#Material material

---
-- Field fontSize (Read only)
--
-- @field [parent=#Text3D] #number fontSize

---
-- Field text
--
-- @field [parent=#Text3D] #string text

---
-- Field textAlignment
--
-- @field [parent=#Text3D] HorizontalAlignment#HorizontalAlignment textAlignment

---
-- Field horizontalAlignment
--
-- @field [parent=#Text3D] HorizontalAlignment#HorizontalAlignment horizontalAlignment

---
-- Field verticalAlignment
--
-- @field [parent=#Text3D] VerticalAlignment#VerticalAlignment verticalAlignment

---
-- Field rowSpacing
--
-- @field [parent=#Text3D] #number rowSpacing

---
-- Field wordwrap
--
-- @field [parent=#Text3D] #boolean wordwrap

---
-- Field textEffect
--
-- @field [parent=#Text3D] TextEffect#TextEffect textEffect

---
-- Field effectColor
--
-- @field [parent=#Text3D] Color#Color effectColor

---
-- Field effectDepthBias
--
-- @field [parent=#Text3D] #number effectDepthBias

---
-- Field width
--
-- @field [parent=#Text3D] #number width

---
-- Field color
--
-- @field [parent=#Text3D] Color#Color color

---
-- Field rowHeight (Read only)
--
-- @field [parent=#Text3D] #number rowHeight

---
-- Field numRows (Read only)
--
-- @field [parent=#Text3D] #number numRows

---
-- Field numChars (Read only)
--
-- @field [parent=#Text3D] #number numChars

---
-- Field opacity
--
-- @field [parent=#Text3D] #number opacity

---
-- Field faceCamera
--
-- @field [parent=#Text3D] #boolean faceCamera


return nil
