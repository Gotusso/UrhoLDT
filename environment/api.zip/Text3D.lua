---
-- Module Text3D
-- extends Drawable
--
-- @module Text3D

---
-- Function Text3D
--
-- @function [parent=#Text3D] Text3D

---
-- Function new
--
-- @function [parent=#Text3D] new
-- @return Text3D#Text3D

---
-- Function delete
--
-- @function [parent=#Text3D] delete

---
-- Function SetFont
--
-- @function [parent=#Text3D] SetFont
-- @param #string fontNamefontName
-- @param #number sizesize
-- @return #boolean

---
-- Function SetFont
--
-- @function [parent=#Text3D] SetFont
-- @param Font#Font fontfont
-- @param #number sizesize
-- @return #boolean

---
-- Function SetMaterial
--
-- @function [parent=#Text3D] SetMaterial
-- @param Material#Material materialmaterial

---
-- Function SetText
--
-- @function [parent=#Text3D] SetText
-- @param #string texttext

---
-- Function SetAlignment
--
-- @function [parent=#Text3D] SetAlignment
-- @param HorizontalAlignment#HorizontalAlignment hAlignhAlign
-- @param VerticalAlignment#VerticalAlignment vAlignvAlign

---
-- Function SetHorizontalAlignment
--
-- @function [parent=#Text3D] SetHorizontalAlignment
-- @param HorizontalAlignment#HorizontalAlignment alignalign

---
-- Function SetVerticalAlignment
--
-- @function [parent=#Text3D] SetVerticalAlignment
-- @param VerticalAlignment#VerticalAlignment alignalign

---
-- Function SetTextAlignment
--
-- @function [parent=#Text3D] SetTextAlignment
-- @param HorizontalAlignment#HorizontalAlignment alignalign

---
-- Function SetRowSpacing
--
-- @function [parent=#Text3D] SetRowSpacing
-- @param #number spacingspacing

---
-- Function SetWordwrap
--
-- @function [parent=#Text3D] SetWordwrap
-- @param #boolean enableenable

---
-- Function SetTextEffect
--
-- @function [parent=#Text3D] SetTextEffect
-- @param TextEffect#TextEffect textEffecttextEffect

---
-- Function SetEffectColor
--
-- @function [parent=#Text3D] SetEffectColor
-- @param Color#Color effectColoreffectColor

---
-- Function SetEffectDepthBias
--
-- @function [parent=#Text3D] SetEffectDepthBias
-- @param #number biasbias

---
-- Function SetWidth
--
-- @function [parent=#Text3D] SetWidth
-- @param #number widthwidth

---
-- Function SetColor
--
-- @function [parent=#Text3D] SetColor
-- @param Color#Color colorcolor

---
-- Function SetColor
--
-- @function [parent=#Text3D] SetColor
-- @param Corner#Corner cornercorner
-- @param Color#Color colorcolor

---
-- Function SetOpacity
--
-- @function [parent=#Text3D] SetOpacity
-- @param #number opacityopacity

---
-- Function SetFaceCamera
--
-- @function [parent=#Text3D] SetFaceCamera
-- @param #boolean enableenable

---
-- Function GetFont
--
-- @function [parent=#Text3D] GetFont
-- @return Font#Font

---
-- Function GetMaterial
--
-- @function [parent=#Text3D] GetMaterial
-- @return Material#Material

---
-- Function GetFontSize
--
-- @function [parent=#Text3D] GetFontSize
-- @return #number

---
-- Function GetText
--
-- @function [parent=#Text3D] GetText
-- @return const String#const String

---
-- Function GetTextAlignment
--
-- @function [parent=#Text3D] GetTextAlignment
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetHorizontalAlignment
--
-- @function [parent=#Text3D] GetHorizontalAlignment
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetVerticalAlignment
--
-- @function [parent=#Text3D] GetVerticalAlignment
-- @return VerticalAlignment#VerticalAlignment

---
-- Function GetRowSpacing
--
-- @function [parent=#Text3D] GetRowSpacing
-- @return #number

---
-- Function GetWordwrap
--
-- @function [parent=#Text3D] GetWordwrap
-- @return #boolean

---
-- Function GetTextEffect
--
-- @function [parent=#Text3D] GetTextEffect
-- @return TextEffect#TextEffect

---
-- Function GetEffectColor
--
-- @function [parent=#Text3D] GetEffectColor
-- @return const Color#const Color

---
-- Function GetEffectDepthBias
--
-- @function [parent=#Text3D] GetEffectDepthBias
-- @return #number

---
-- Function GetWidth
--
-- @function [parent=#Text3D] GetWidth
-- @return #number

---
-- Function GetRowHeight
--
-- @function [parent=#Text3D] GetRowHeight
-- @return #number

---
-- Function GetNumRows
--
-- @function [parent=#Text3D] GetNumRows
-- @return #number

---
-- Function GetNumChars
--
-- @function [parent=#Text3D] GetNumChars
-- @return #number

---
-- Function GetRowWidth
--
-- @function [parent=#Text3D] GetRowWidth
-- @param #number indexindex
-- @return #number

---
-- Function GetCharPosition
--
-- @function [parent=#Text3D] GetCharPosition
-- @param #number indexindex
-- @return IntVector2#IntVector2

---
-- Function GetCharSize
--
-- @function [parent=#Text3D] GetCharSize
-- @param #number indexindex
-- @return IntVector2#IntVector2

---
-- Function GetColor
--
-- @function [parent=#Text3D] GetColor
-- @param Corner#Corner cornercorner
-- @return const Color#const Color

---
-- Function GetOpacity
--
-- @function [parent=#Text3D] GetOpacity
-- @return #number

---
-- Function GetFaceCamera
--
-- @function [parent=#Text3D] GetFaceCamera
-- @return #boolean

---
-- Field font
--
-- @field [parent=#Text3D] Font#Font font

---
-- Field material
--
-- @field [parent=#Text3D] Material#Material material

---
-- Field fontSize (Read only)
--
-- @field [parent=#Text3D] #number fontSize

---
-- Field text
--
-- @field [parent=#Text3D] #string text

---
-- Field textAlignment
--
-- @field [parent=#Text3D] HorizontalAlignment#HorizontalAlignment textAlignment

---
-- Field horizontalAlignment
--
-- @field [parent=#Text3D] HorizontalAlignment#HorizontalAlignment horizontalAlignment

---
-- Field verticalAlignment
--
-- @field [parent=#Text3D] VerticalAlignment#VerticalAlignment verticalAlignment

---
-- Field rowSpacing
--
-- @field [parent=#Text3D] #number rowSpacing

---
-- Field wordwrap
--
-- @field [parent=#Text3D] #boolean wordwrap

---
-- Field textEffect
--
-- @field [parent=#Text3D] TextEffect#TextEffect textEffect

---
-- Field effectColor
--
-- @field [parent=#Text3D] Color#Color effectColor

---
-- Field effectDepthBias
--
-- @field [parent=#Text3D] #number effectDepthBias

---
-- Field width
--
-- @field [parent=#Text3D] #number width

---
-- Field color
--
-- @field [parent=#Text3D] Color#Color color

---
-- Field rowHeight (Read only)
--
-- @field [parent=#Text3D] #number rowHeight

---
-- Field numRows (Read only)
--
-- @field [parent=#Text3D] #number numRows

---
-- Field numChars (Read only)
--
-- @field [parent=#Text3D] #number numChars

---
-- Field opacity
--
-- @field [parent=#Text3D] #number opacity

---
-- Field faceCamera
--
-- @field [parent=#Text3D] #boolean faceCamera

---
-- Function SetDrawDistance
--
-- @function [parent=#Text3D] SetDrawDistance
-- @param #number distancedistance

---
-- Function SetShadowDistance
--
-- @function [parent=#Text3D] SetShadowDistance
-- @param #number distancedistance

---
-- Function SetLodBias
--
-- @function [parent=#Text3D] SetLodBias
-- @param #number biasbias

---
-- Function SetViewMask
--
-- @function [parent=#Text3D] SetViewMask
-- @param #number maskmask

---
-- Function SetLightMask
--
-- @function [parent=#Text3D] SetLightMask
-- @param #number maskmask

---
-- Function SetShadowMask
--
-- @function [parent=#Text3D] SetShadowMask
-- @param #number maskmask

---
-- Function SetZoneMask
--
-- @function [parent=#Text3D] SetZoneMask
-- @param #number maskmask

---
-- Function SetMaxLights
--
-- @function [parent=#Text3D] SetMaxLights
-- @param #number numnum

---
-- Function SetCastShadows
--
-- @function [parent=#Text3D] SetCastShadows
-- @param #boolean enableenable

---
-- Function SetOccluder
--
-- @function [parent=#Text3D] SetOccluder
-- @param #boolean enableenable

---
-- Function SetOccludee
--
-- @function [parent=#Text3D] SetOccludee
-- @param #boolean enableenable

---
-- Function MarkForUpdate
--
-- @function [parent=#Text3D] MarkForUpdate

---
-- Function GetBoundingBox
--
-- @function [parent=#Text3D] GetBoundingBox
-- @return const BoundingBox#const BoundingBox

---
-- Function GetWorldBoundingBox
--
-- @function [parent=#Text3D] GetWorldBoundingBox
-- @return const BoundingBox#const BoundingBox

---
-- Function GetDrawableFlags
--
-- @function [parent=#Text3D] GetDrawableFlags
-- @return #string

---
-- Function GetDrawDistance
--
-- @function [parent=#Text3D] GetDrawDistance
-- @return #number

---
-- Function GetShadowDistance
--
-- @function [parent=#Text3D] GetShadowDistance
-- @return #number

---
-- Function GetLodBias
--
-- @function [parent=#Text3D] GetLodBias
-- @return #number

---
-- Function GetViewMask
--
-- @function [parent=#Text3D] GetViewMask
-- @return #number

---
-- Function GetLightMask
--
-- @function [parent=#Text3D] GetLightMask
-- @return #number

---
-- Function GetShadowMask
--
-- @function [parent=#Text3D] GetShadowMask
-- @return #number

---
-- Function GetZoneMask
--
-- @function [parent=#Text3D] GetZoneMask
-- @return #number

---
-- Function GetMaxLights
--
-- @function [parent=#Text3D] GetMaxLights
-- @return #number

---
-- Function GetCastShadows
--
-- @function [parent=#Text3D] GetCastShadows
-- @return #boolean

---
-- Function IsOccluder
--
-- @function [parent=#Text3D] IsOccluder
-- @return #boolean

---
-- Function IsOccludee
--
-- @function [parent=#Text3D] IsOccludee
-- @return #boolean

---
-- Function SetZone
--
-- @function [parent=#Text3D] SetZone
-- @param Zone#Zone zonezone
-- @param #boolean temporarytemporary

---
-- Function SetSortValue
--
-- @function [parent=#Text3D] SetSortValue
-- @param #number valuevalue

---
-- Function SetMinMaxZ
--
-- @function [parent=#Text3D] SetMinMaxZ
-- @param #number minZminZ
-- @param #number maxZmaxZ

---
-- Function MarkInView
--
-- @function [parent=#Text3D] MarkInView
-- @param FrameInfo#FrameInfo frameframe
-- @param #boolean mainViewmainView

---
-- Function ClearLights
--
-- @function [parent=#Text3D] ClearLights

---
-- Function AddLight
--
-- @function [parent=#Text3D] AddLight
-- @param Light#Light lightlight

---
-- Function AddVertexLight
--
-- @function [parent=#Text3D] AddVertexLight
-- @param Light#Light lightlight

---
-- Function LimitLights
--
-- @function [parent=#Text3D] LimitLights

---
-- Function LimitVertexLights
--
-- @function [parent=#Text3D] LimitVertexLights

---
-- Function SetBasePass
--
-- @function [parent=#Text3D] SetBasePass
-- @param #number batchIndexbatchIndex

---
-- Function GetOctant
--
-- @function [parent=#Text3D] GetOctant
-- @return Octant#Octant

---
-- Function GetZone
--
-- @function [parent=#Text3D] GetZone
-- @return Zone#Zone

---
-- Function GetLastZone
--
-- @function [parent=#Text3D] GetLastZone
-- @return Zone#Zone

---
-- Function IsZoneDirty
--
-- @function [parent=#Text3D] IsZoneDirty
-- @return #boolean

---
-- Function GetDistance
--
-- @function [parent=#Text3D] GetDistance
-- @return #number

---
-- Function GetLodDistance
--
-- @function [parent=#Text3D] GetLodDistance
-- @return #number

---
-- Function GetSortValue
--
-- @function [parent=#Text3D] GetSortValue
-- @return #number

---
-- Function IsInView
--
-- @function [parent=#Text3D] IsInView
-- @param #number frameNumberframeNumber
-- @return #boolean

---
-- Function IsInView
--
-- @function [parent=#Text3D] IsInView
-- @param FrameInfo#FrameInfo frameframe
-- @param #boolean mainViewmainView
-- @return #boolean

---
-- Function HasBasePass
--
-- @function [parent=#Text3D] HasBasePass
-- @param #number batchIndexbatchIndex
-- @return #boolean

---
-- Function GetFirstLight
--
-- @function [parent=#Text3D] GetFirstLight
-- @return Light#Light

---
-- Function GetMinZ
--
-- @function [parent=#Text3D] GetMinZ
-- @return #number

---
-- Function GetMaxZ
--
-- @function [parent=#Text3D] GetMaxZ
-- @return #number

---
-- Field worldBoundingBox (Read only)
--
-- @field [parent=#Text3D] BoundingBox#BoundingBox worldBoundingBox

---
-- Field drawableFlags (Read only)
--
-- @field [parent=#Text3D] #string drawableFlags

---
-- Field drawDistance
--
-- @field [parent=#Text3D] #number drawDistance

---
-- Field shadowDistance
--
-- @field [parent=#Text3D] #number shadowDistance

---
-- Field lodBias
--
-- @field [parent=#Text3D] #number lodBias

---
-- Field viewMask
--
-- @field [parent=#Text3D] #number viewMask

---
-- Field lightMask
--
-- @field [parent=#Text3D] #number lightMask

---
-- Field shadowMask
--
-- @field [parent=#Text3D] #number shadowMask

---
-- Field zoneMask
--
-- @field [parent=#Text3D] #number zoneMask

---
-- Field maxLights
--
-- @field [parent=#Text3D] #number maxLights

---
-- Field castShadows
--
-- @field [parent=#Text3D] #boolean castShadows

---
-- Field occluder
--
-- @field [parent=#Text3D] #boolean occluder

---
-- Field occludee
--
-- @field [parent=#Text3D] #boolean occludee

---
-- Field octant (Read only)
--
-- @field [parent=#Text3D] Octant#Octant octant

---
-- Field zone
--
-- @field [parent=#Text3D] Zone#Zone zone

---
-- Field lastZone (Read only)
--
-- @field [parent=#Text3D] Zone#Zone lastZone

---
-- Field zoneDirty (Read only)
--
-- @field [parent=#Text3D] #boolean zoneDirty

---
-- Field distance (Read only)
--
-- @field [parent=#Text3D] #number distance

---
-- Field lodDistance (Read only)
--
-- @field [parent=#Text3D] #number lodDistance

---
-- Field sortValue
--
-- @field [parent=#Text3D] #number sortValue

---
-- Field firstLight (Read only)
--
-- @field [parent=#Text3D] Light#Light firstLight

---
-- Field minZ (Read only)
--
-- @field [parent=#Text3D] #number minZ

---
-- Field maxZ (Read only)
--
-- @field [parent=#Text3D] #number maxZ

---
-- Function SetEnabled
--
-- @function [parent=#Text3D] SetEnabled
-- @param #boolean enableenable

---
-- Function Remove
--
-- @function [parent=#Text3D] Remove

---
-- Function GetID
--
-- @function [parent=#Text3D] GetID
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#Text3D] GetNode
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#Text3D] GetScene
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#Text3D] IsEnabled
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#Text3D] IsEnabledEffective
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#Text3D] GetComponent
-- @param ShortStringHash#ShortStringHash typetype
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#Text3D] GetComponent
-- @param #string typetype
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#Text3D] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#Text3D] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Text3D] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Text3D] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Text3D] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Text3D] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Text3D] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Text3D] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#Text3D] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Text3D] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Text3D] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Text3D] #string category


return nil
