---
-- Module Text3D
-- Module Text3D extends Drawable
-- Generated on 2014-05-31
--
-- @module Text3D

---
-- Function Text3D()
--
-- @function [parent=#Text3D] Text3D
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#Text3D] new
-- @param self Self reference
-- @return Text3D#Text3D

---
-- Function delete()
--
-- @function [parent=#Text3D] delete
-- @param self Self reference

---
-- Function SetFont()
-- Set font and font size. Return true if successful.
--
-- @function [parent=#Text3D] SetFont
-- @param self Self reference
-- @param #string fontName fontName
-- @param #number size size
-- @return #boolean

---
-- Function SetFont()
-- Set font and font size. Return true if successful.
--
-- @function [parent=#Text3D] SetFont
-- @param self Self reference
-- @param Font#Font font font
-- @param #number size size
-- @return #boolean

---
-- Function SetMaterial()
-- Set material.
--
-- @function [parent=#Text3D] SetMaterial
-- @param self Self reference
-- @param Material#Material material material

---
-- Function SetText()
-- Set text. Text is assumed to be either ASCII or UTF8-encoded.
--
-- @function [parent=#Text3D] SetText
-- @param self Self reference
-- @param #string text text

---
-- Function SetAlignment()
-- Set horizontal and vertical alignment.
--
-- @function [parent=#Text3D] SetAlignment
-- @param self Self reference
-- @param HorizontalAlignment#HorizontalAlignment hAlign hAlign
-- @param VerticalAlignment#VerticalAlignment vAlign vAlign

---
-- Function SetHorizontalAlignment()
-- Set horizontal alignment.
--
-- @function [parent=#Text3D] SetHorizontalAlignment
-- @param self Self reference
-- @param HorizontalAlignment#HorizontalAlignment align align

---
-- Function SetVerticalAlignment()
-- Set vertical alignment.
--
-- @function [parent=#Text3D] SetVerticalAlignment
-- @param self Self reference
-- @param VerticalAlignment#VerticalAlignment align align

---
-- Function SetTextAlignment()
-- Set row alignment.
--
-- @function [parent=#Text3D] SetTextAlignment
-- @param self Self reference
-- @param HorizontalAlignment#HorizontalAlignment align align

---
-- Function SetRowSpacing()
-- Set row spacing, 1.0 for original font spacing.
--
-- @function [parent=#Text3D] SetRowSpacing
-- @param self Self reference
-- @param #number spacing spacing

---
-- Function SetWordwrap()
-- Set wordwrap. In wordwrap mode the text element will respect its current width. Otherwise it resizes itself freely.
--
-- @function [parent=#Text3D] SetWordwrap
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetTextEffect()
-- Set text effect.
--
-- @function [parent=#Text3D] SetTextEffect
-- @param self Self reference
-- @param TextEffect#TextEffect textEffect textEffect

---
-- Function SetEffectColor()
-- Set effect color.
--
-- @function [parent=#Text3D] SetEffectColor
-- @param self Self reference
-- @param Color#Color effectColor effectColor

---
-- Function SetEffectDepthBias()
-- Set effect Z bias.
--
-- @function [parent=#Text3D] SetEffectDepthBias
-- @param self Self reference
-- @param #number bias bias

---
-- Function SetWidth()
-- Set text width. Only has effect in word wrap mode.
--
-- @function [parent=#Text3D] SetWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetColor()
-- Set color on all corners.
--
-- @function [parent=#Text3D] SetColor
-- @param self Self reference
-- @param Color#Color color color

---
-- Function SetColor()
-- Set color on one corner.
--
-- @function [parent=#Text3D] SetColor
-- @param self Self reference
-- @param Corner#Corner corner corner
-- @param Color#Color color color

---
-- Function SetOpacity()
-- Set opacity.
--
-- @function [parent=#Text3D] SetOpacity
-- @param self Self reference
-- @param #number opacity opacity

---
-- Function SetFaceCameraMode()
-- Set how the text should rotate in relation to the camera. Default is to not rotate (FC_NONE.)
--
-- @function [parent=#Text3D] SetFaceCameraMode
-- @param self Self reference
-- @param FaceCameraMode#FaceCameraMode mode mode

---
-- Function GetFont()
-- Return font.
--
-- @function [parent=#Text3D] GetFont
-- @param self Self reference
-- @return Font#Font

---
-- Function GetMaterial()
-- Return material.
--
-- @function [parent=#Text3D] GetMaterial
-- @param self Self reference
-- @return Material#Material

---
-- Function GetFontSize()
-- Return font size.
--
-- @function [parent=#Text3D] GetFontSize
-- @param self Self reference
-- @return #number

---
-- Function GetText()
-- Return text.
--
-- @function [parent=#Text3D] GetText
-- @param self Self reference
-- @return const String#const String

---
-- Function GetTextAlignment()
-- Return row alignment.
--
-- @function [parent=#Text3D] GetTextAlignment
-- @param self Self reference
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetHorizontalAlignment()
-- Return horizontal alignment.
--
-- @function [parent=#Text3D] GetHorizontalAlignment
-- @param self Self reference
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetVerticalAlignment()
-- Return vertical alignment.
--
-- @function [parent=#Text3D] GetVerticalAlignment
-- @param self Self reference
-- @return VerticalAlignment#VerticalAlignment

---
-- Function GetRowSpacing()
-- Return row spacing.
--
-- @function [parent=#Text3D] GetRowSpacing
-- @param self Self reference
-- @return #number

---
-- Function GetWordwrap()
-- Return wordwrap mode.
--
-- @function [parent=#Text3D] GetWordwrap
-- @param self Self reference
-- @return #boolean

---
-- Function GetTextEffect()
-- Return text effect.
--
-- @function [parent=#Text3D] GetTextEffect
-- @param self Self reference
-- @return TextEffect#TextEffect

---
-- Function GetEffectColor()
-- Return effect color.
--
-- @function [parent=#Text3D] GetEffectColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetEffectDepthBias()
-- Return effect depth bias.
--
-- @function [parent=#Text3D] GetEffectDepthBias
-- @param self Self reference
-- @return #number

---
-- Function GetWidth()
-- Return text width.
--
-- @function [parent=#Text3D] GetWidth
-- @param self Self reference
-- @return #number

---
-- Function GetRowHeight()
-- Return row height.
--
-- @function [parent=#Text3D] GetRowHeight
-- @param self Self reference
-- @return #number

---
-- Function GetNumRows()
-- Return number of rows.
--
-- @function [parent=#Text3D] GetNumRows
-- @param self Self reference
-- @return #number

---
-- Function GetNumChars()
-- Return number of characters.
--
-- @function [parent=#Text3D] GetNumChars
-- @param self Self reference
-- @return #number

---
-- Function GetRowWidth()
-- Return width of row by index.
--
-- @function [parent=#Text3D] GetRowWidth
-- @param self Self reference
-- @param #number index index
-- @return #number

---
-- Function GetCharPosition()
-- Return position of character by index relative to the text element origin.
--
-- @function [parent=#Text3D] GetCharPosition
-- @param self Self reference
-- @param #number index index
-- @return IntVector2#IntVector2

---
-- Function GetCharSize()
-- Return size of character by index.
--
-- @function [parent=#Text3D] GetCharSize
-- @param self Self reference
-- @param #number index index
-- @return IntVector2#IntVector2

---
-- Function GetColor()
-- Return corner color.
--
-- @function [parent=#Text3D] GetColor
-- @param self Self reference
-- @param Corner#Corner corner corner
-- @return const Color#const Color

---
-- Function GetOpacity()
-- Return opacity.
--
-- @function [parent=#Text3D] GetOpacity
-- @param self Self reference
-- @return #number

---
-- Function GetFaceCameraMode()
-- Return how the text rotates in relation to the camera.
--
-- @function [parent=#Text3D] GetFaceCameraMode
-- @param self Self reference
-- @return FaceCameraMode#FaceCameraMode

---
-- Field font
--
-- @field [parent=#Text3D] Font#Font font

---
-- Field material
--
-- @field [parent=#Text3D] Material#Material material

---
-- Field fontSize (Read only)
--
-- @field [parent=#Text3D] #number fontSize

---
-- Field text
--
-- @field [parent=#Text3D] #string text

---
-- Field textAlignment
--
-- @field [parent=#Text3D] HorizontalAlignment#HorizontalAlignment textAlignment

---
-- Field horizontalAlignment
--
-- @field [parent=#Text3D] HorizontalAlignment#HorizontalAlignment horizontalAlignment

---
-- Field verticalAlignment
--
-- @field [parent=#Text3D] VerticalAlignment#VerticalAlignment verticalAlignment

---
-- Field rowSpacing
--
-- @field [parent=#Text3D] #number rowSpacing

---
-- Field wordwrap
--
-- @field [parent=#Text3D] #boolean wordwrap

---
-- Field textEffect
--
-- @field [parent=#Text3D] TextEffect#TextEffect textEffect

---
-- Field effectColor
--
-- @field [parent=#Text3D] Color#Color effectColor

---
-- Field effectDepthBias
--
-- @field [parent=#Text3D] #number effectDepthBias

---
-- Field width
--
-- @field [parent=#Text3D] #number width

---
-- Field color
--
-- @field [parent=#Text3D] Color#Color color

---
-- Field rowHeight (Read only)
--
-- @field [parent=#Text3D] #number rowHeight

---
-- Field numRows (Read only)
--
-- @field [parent=#Text3D] #number numRows

---
-- Field numChars (Read only)
--
-- @field [parent=#Text3D] #number numChars

---
-- Field opacity
--
-- @field [parent=#Text3D] #number opacity

---
-- Field faceCameraMode
--
-- @field [parent=#Text3D] FaceCameraMode#FaceCameraMode faceCameraMode


return nil
