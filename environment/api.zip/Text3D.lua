---
-- Module Text3D
-- Module Text3D extends Drawable
-- Generated on 2014-03-13
--
-- @module Text3D

---
-- Function Text3D
--
-- @function [parent=#Text3D] Text3D
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#Text3D] new
-- @param self Self reference
-- @return Text3D#Text3D

---
-- Function delete
--
-- @function [parent=#Text3D] delete
-- @param self Self reference

---
-- Function SetFont
--
-- @function [parent=#Text3D] SetFont
-- @param self Self reference
-- @param #string fontName fontName
-- @param #number size size
-- @return #boolean

---
-- Function SetFont
--
-- @function [parent=#Text3D] SetFont
-- @param self Self reference
-- @param Font#Font font font
-- @param #number size size
-- @return #boolean

---
-- Function SetMaterial
--
-- @function [parent=#Text3D] SetMaterial
-- @param self Self reference
-- @param Material#Material material material

---
-- Function SetText
--
-- @function [parent=#Text3D] SetText
-- @param self Self reference
-- @param #string text text

---
-- Function SetAlignment
--
-- @function [parent=#Text3D] SetAlignment
-- @param self Self reference
-- @param HorizontalAlignment#HorizontalAlignment hAlign hAlign
-- @param VerticalAlignment#VerticalAlignment vAlign vAlign

---
-- Function SetHorizontalAlignment
--
-- @function [parent=#Text3D] SetHorizontalAlignment
-- @param self Self reference
-- @param HorizontalAlignment#HorizontalAlignment align align

---
-- Function SetVerticalAlignment
--
-- @function [parent=#Text3D] SetVerticalAlignment
-- @param self Self reference
-- @param VerticalAlignment#VerticalAlignment align align

---
-- Function SetTextAlignment
--
-- @function [parent=#Text3D] SetTextAlignment
-- @param self Self reference
-- @param HorizontalAlignment#HorizontalAlignment align align

---
-- Function SetRowSpacing
--
-- @function [parent=#Text3D] SetRowSpacing
-- @param self Self reference
-- @param #number spacing spacing

---
-- Function SetWordwrap
--
-- @function [parent=#Text3D] SetWordwrap
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetTextEffect
--
-- @function [parent=#Text3D] SetTextEffect
-- @param self Self reference
-- @param TextEffect#TextEffect textEffect textEffect

---
-- Function SetEffectColor
--
-- @function [parent=#Text3D] SetEffectColor
-- @param self Self reference
-- @param Color#Color effectColor effectColor

---
-- Function SetEffectDepthBias
--
-- @function [parent=#Text3D] SetEffectDepthBias
-- @param self Self reference
-- @param #number bias bias

---
-- Function SetWidth
--
-- @function [parent=#Text3D] SetWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetColor
--
-- @function [parent=#Text3D] SetColor
-- @param self Self reference
-- @param Color#Color color color

---
-- Function SetColor
--
-- @function [parent=#Text3D] SetColor
-- @param self Self reference
-- @param Corner#Corner corner corner
-- @param Color#Color color color

---
-- Function SetOpacity
--
-- @function [parent=#Text3D] SetOpacity
-- @param self Self reference
-- @param #number opacity opacity

---
-- Function SetFaceCamera
--
-- @function [parent=#Text3D] SetFaceCamera
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function GetFont
--
-- @function [parent=#Text3D] GetFont
-- @param self Self reference
-- @return Font#Font

---
-- Function GetMaterial
--
-- @function [parent=#Text3D] GetMaterial
-- @param self Self reference
-- @return Material#Material

---
-- Function GetFontSize
--
-- @function [parent=#Text3D] GetFontSize
-- @param self Self reference
-- @return #number

---
-- Function GetText
--
-- @function [parent=#Text3D] GetText
-- @param self Self reference
-- @return const String#const String

---
-- Function GetTextAlignment
--
-- @function [parent=#Text3D] GetTextAlignment
-- @param self Self reference
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetHorizontalAlignment
--
-- @function [parent=#Text3D] GetHorizontalAlignment
-- @param self Self reference
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetVerticalAlignment
--
-- @function [parent=#Text3D] GetVerticalAlignment
-- @param self Self reference
-- @return VerticalAlignment#VerticalAlignment

---
-- Function GetRowSpacing
--
-- @function [parent=#Text3D] GetRowSpacing
-- @param self Self reference
-- @return #number

---
-- Function GetWordwrap
--
-- @function [parent=#Text3D] GetWordwrap
-- @param self Self reference
-- @return #boolean

---
-- Function GetTextEffect
--
-- @function [parent=#Text3D] GetTextEffect
-- @param self Self reference
-- @return TextEffect#TextEffect

---
-- Function GetEffectColor
--
-- @function [parent=#Text3D] GetEffectColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetEffectDepthBias
--
-- @function [parent=#Text3D] GetEffectDepthBias
-- @param self Self reference
-- @return #number

---
-- Function GetWidth
--
-- @function [parent=#Text3D] GetWidth
-- @param self Self reference
-- @return #number

---
-- Function GetRowHeight
--
-- @function [parent=#Text3D] GetRowHeight
-- @param self Self reference
-- @return #number

---
-- Function GetNumRows
--
-- @function [parent=#Text3D] GetNumRows
-- @param self Self reference
-- @return #number

---
-- Function GetNumChars
--
-- @function [parent=#Text3D] GetNumChars
-- @param self Self reference
-- @return #number

---
-- Function GetRowWidth
--
-- @function [parent=#Text3D] GetRowWidth
-- @param self Self reference
-- @param #number index index
-- @return #number

---
-- Function GetCharPosition
--
-- @function [parent=#Text3D] GetCharPosition
-- @param self Self reference
-- @param #number index index
-- @return IntVector2#IntVector2

---
-- Function GetCharSize
--
-- @function [parent=#Text3D] GetCharSize
-- @param self Self reference
-- @param #number index index
-- @return IntVector2#IntVector2

---
-- Function GetColor
--
-- @function [parent=#Text3D] GetColor
-- @param self Self reference
-- @param Corner#Corner corner corner
-- @return const Color#const Color

---
-- Function GetOpacity
--
-- @function [parent=#Text3D] GetOpacity
-- @param self Self reference
-- @return #number

---
-- Function GetFaceCamera
--
-- @function [parent=#Text3D] GetFaceCamera
-- @param self Self reference
-- @return #boolean

---
-- Field font
--
-- @field [parent=#Text3D] Font#Font font

---
-- Field material
--
-- @field [parent=#Text3D] Material#Material material

---
-- Field fontSize (Read only)
--
-- @field [parent=#Text3D] #number fontSize

---
-- Field text
--
-- @field [parent=#Text3D] #string text

---
-- Field textAlignment
--
-- @field [parent=#Text3D] HorizontalAlignment#HorizontalAlignment textAlignment

---
-- Field horizontalAlignment
--
-- @field [parent=#Text3D] HorizontalAlignment#HorizontalAlignment horizontalAlignment

---
-- Field verticalAlignment
--
-- @field [parent=#Text3D] VerticalAlignment#VerticalAlignment verticalAlignment

---
-- Field rowSpacing
--
-- @field [parent=#Text3D] #number rowSpacing

---
-- Field wordwrap
--
-- @field [parent=#Text3D] #boolean wordwrap

---
-- Field textEffect
--
-- @field [parent=#Text3D] TextEffect#TextEffect textEffect

---
-- Field effectColor
--
-- @field [parent=#Text3D] Color#Color effectColor

---
-- Field effectDepthBias
--
-- @field [parent=#Text3D] #number effectDepthBias

---
-- Field width
--
-- @field [parent=#Text3D] #number width

---
-- Field color
--
-- @field [parent=#Text3D] Color#Color color

---
-- Field rowHeight (Read only)
--
-- @field [parent=#Text3D] #number rowHeight

---
-- Field numRows (Read only)
--
-- @field [parent=#Text3D] #number numRows

---
-- Field numChars (Read only)
--
-- @field [parent=#Text3D] #number numChars

---
-- Field opacity
--
-- @field [parent=#Text3D] #number opacity

---
-- Field faceCamera
--
-- @field [parent=#Text3D] #boolean faceCamera

---
-- Function SetDrawDistance
--
-- @function [parent=#Text3D] SetDrawDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetShadowDistance
--
-- @function [parent=#Text3D] SetShadowDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetLodBias
--
-- @function [parent=#Text3D] SetLodBias
-- @param self Self reference
-- @param #number bias bias

---
-- Function SetViewMask
--
-- @function [parent=#Text3D] SetViewMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetLightMask
--
-- @function [parent=#Text3D] SetLightMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetShadowMask
--
-- @function [parent=#Text3D] SetShadowMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetZoneMask
--
-- @function [parent=#Text3D] SetZoneMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetMaxLights
--
-- @function [parent=#Text3D] SetMaxLights
-- @param self Self reference
-- @param #number num num

---
-- Function SetCastShadows
--
-- @function [parent=#Text3D] SetCastShadows
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetOccluder
--
-- @function [parent=#Text3D] SetOccluder
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetOccludee
--
-- @function [parent=#Text3D] SetOccludee
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function MarkForUpdate
--
-- @function [parent=#Text3D] MarkForUpdate
-- @param self Self reference

---
-- Function GetBoundingBox
--
-- @function [parent=#Text3D] GetBoundingBox
-- @param self Self reference
-- @return const BoundingBox#const BoundingBox

---
-- Function GetWorldBoundingBox
--
-- @function [parent=#Text3D] GetWorldBoundingBox
-- @param self Self reference
-- @return const BoundingBox#const BoundingBox

---
-- Function GetDrawableFlags
--
-- @function [parent=#Text3D] GetDrawableFlags
-- @param self Self reference
-- @return #string

---
-- Function GetDrawDistance
--
-- @function [parent=#Text3D] GetDrawDistance
-- @param self Self reference
-- @return #number

---
-- Function GetShadowDistance
--
-- @function [parent=#Text3D] GetShadowDistance
-- @param self Self reference
-- @return #number

---
-- Function GetLodBias
--
-- @function [parent=#Text3D] GetLodBias
-- @param self Self reference
-- @return #number

---
-- Function GetViewMask
--
-- @function [parent=#Text3D] GetViewMask
-- @param self Self reference
-- @return #number

---
-- Function GetLightMask
--
-- @function [parent=#Text3D] GetLightMask
-- @param self Self reference
-- @return #number

---
-- Function GetShadowMask
--
-- @function [parent=#Text3D] GetShadowMask
-- @param self Self reference
-- @return #number

---
-- Function GetZoneMask
--
-- @function [parent=#Text3D] GetZoneMask
-- @param self Self reference
-- @return #number

---
-- Function GetMaxLights
--
-- @function [parent=#Text3D] GetMaxLights
-- @param self Self reference
-- @return #number

---
-- Function GetCastShadows
--
-- @function [parent=#Text3D] GetCastShadows
-- @param self Self reference
-- @return #boolean

---
-- Function IsOccluder
--
-- @function [parent=#Text3D] IsOccluder
-- @param self Self reference
-- @return #boolean

---
-- Function IsOccludee
--
-- @function [parent=#Text3D] IsOccludee
-- @param self Self reference
-- @return #boolean

---
-- Function SetZone
--
-- @function [parent=#Text3D] SetZone
-- @param self Self reference
-- @param Zone#Zone zone zone
-- @param #boolean temporary temporary

---
-- Function SetSortValue
--
-- @function [parent=#Text3D] SetSortValue
-- @param self Self reference
-- @param #number value value

---
-- Function SetMinMaxZ
--
-- @function [parent=#Text3D] SetMinMaxZ
-- @param self Self reference
-- @param #number minZ minZ
-- @param #number maxZ maxZ

---
-- Function MarkInView
--
-- @function [parent=#Text3D] MarkInView
-- @param self Self reference
-- @param FrameInfo#FrameInfo frame frame
-- @param #boolean mainView mainView

---
-- Function ClearLights
--
-- @function [parent=#Text3D] ClearLights
-- @param self Self reference

---
-- Function AddLight
--
-- @function [parent=#Text3D] AddLight
-- @param self Self reference
-- @param Light#Light light light

---
-- Function AddVertexLight
--
-- @function [parent=#Text3D] AddVertexLight
-- @param self Self reference
-- @param Light#Light light light

---
-- Function LimitLights
--
-- @function [parent=#Text3D] LimitLights
-- @param self Self reference

---
-- Function LimitVertexLights
--
-- @function [parent=#Text3D] LimitVertexLights
-- @param self Self reference

---
-- Function SetBasePass
--
-- @function [parent=#Text3D] SetBasePass
-- @param self Self reference
-- @param #number batchIndex batchIndex

---
-- Function GetOctant
--
-- @function [parent=#Text3D] GetOctant
-- @param self Self reference
-- @return Octant#Octant

---
-- Function GetZone
--
-- @function [parent=#Text3D] GetZone
-- @param self Self reference
-- @return Zone#Zone

---
-- Function GetLastZone
--
-- @function [parent=#Text3D] GetLastZone
-- @param self Self reference
-- @return Zone#Zone

---
-- Function IsZoneDirty
--
-- @function [parent=#Text3D] IsZoneDirty
-- @param self Self reference
-- @return #boolean

---
-- Function GetDistance
--
-- @function [parent=#Text3D] GetDistance
-- @param self Self reference
-- @return #number

---
-- Function GetLodDistance
--
-- @function [parent=#Text3D] GetLodDistance
-- @param self Self reference
-- @return #number

---
-- Function GetSortValue
--
-- @function [parent=#Text3D] GetSortValue
-- @param self Self reference
-- @return #number

---
-- Function IsInView
--
-- @function [parent=#Text3D] IsInView
-- @param self Self reference
-- @param #number frameNumber frameNumber
-- @return #boolean

---
-- Function IsInView
--
-- @function [parent=#Text3D] IsInView
-- @param self Self reference
-- @param FrameInfo#FrameInfo frame frame
-- @param #boolean mainView mainView
-- @return #boolean

---
-- Function HasBasePass
--
-- @function [parent=#Text3D] HasBasePass
-- @param self Self reference
-- @param #number batchIndex batchIndex
-- @return #boolean

---
-- Function GetFirstLight
--
-- @function [parent=#Text3D] GetFirstLight
-- @param self Self reference
-- @return Light#Light

---
-- Function GetMinZ
--
-- @function [parent=#Text3D] GetMinZ
-- @param self Self reference
-- @return #number

---
-- Function GetMaxZ
--
-- @function [parent=#Text3D] GetMaxZ
-- @param self Self reference
-- @return #number

---
-- Field worldBoundingBox (Read only)
--
-- @field [parent=#Text3D] BoundingBox#BoundingBox worldBoundingBox

---
-- Field drawableFlags (Read only)
--
-- @field [parent=#Text3D] #string drawableFlags

---
-- Field drawDistance
--
-- @field [parent=#Text3D] #number drawDistance

---
-- Field shadowDistance
--
-- @field [parent=#Text3D] #number shadowDistance

---
-- Field lodBias
--
-- @field [parent=#Text3D] #number lodBias

---
-- Field viewMask
--
-- @field [parent=#Text3D] #number viewMask

---
-- Field lightMask
--
-- @field [parent=#Text3D] #number lightMask

---
-- Field shadowMask
--
-- @field [parent=#Text3D] #number shadowMask

---
-- Field zoneMask
--
-- @field [parent=#Text3D] #number zoneMask

---
-- Field maxLights
--
-- @field [parent=#Text3D] #number maxLights

---
-- Field castShadows
--
-- @field [parent=#Text3D] #boolean castShadows

---
-- Field occluder
--
-- @field [parent=#Text3D] #boolean occluder

---
-- Field occludee
--
-- @field [parent=#Text3D] #boolean occludee

---
-- Field octant (Read only)
--
-- @field [parent=#Text3D] Octant#Octant octant

---
-- Field zone
--
-- @field [parent=#Text3D] Zone#Zone zone

---
-- Field lastZone (Read only)
--
-- @field [parent=#Text3D] Zone#Zone lastZone

---
-- Field zoneDirty (Read only)
--
-- @field [parent=#Text3D] #boolean zoneDirty

---
-- Field distance (Read only)
--
-- @field [parent=#Text3D] #number distance

---
-- Field lodDistance (Read only)
--
-- @field [parent=#Text3D] #number lodDistance

---
-- Field sortValue
--
-- @field [parent=#Text3D] #number sortValue

---
-- Field firstLight (Read only)
--
-- @field [parent=#Text3D] Light#Light firstLight

---
-- Field minZ (Read only)
--
-- @field [parent=#Text3D] #number minZ

---
-- Field maxZ (Read only)
--
-- @field [parent=#Text3D] #number maxZ

---
-- Function SetEnabled
--
-- @function [parent=#Text3D] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Remove
--
-- @function [parent=#Text3D] Remove
-- @param self Self reference

---
-- Function GetID
--
-- @function [parent=#Text3D] GetID
-- @param self Self reference
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#Text3D] GetNode
-- @param self Self reference
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#Text3D] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#Text3D] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#Text3D] IsEnabledEffective
-- @param self Self reference
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#Text3D] GetComponent
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#Text3D] GetComponent
-- @param self Self reference
-- @param #string type type
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#Text3D] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#Text3D] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Text3D] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Text3D] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Text3D] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Text3D] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Text3D] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Text3D] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#Text3D] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Text3D] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Text3D] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Text3D] #string category


return nil
