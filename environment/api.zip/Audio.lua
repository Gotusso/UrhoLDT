---
-- Module Audio
-- Module Audio extends Object
-- Generated on 2014-05-31
--
-- @module Audio

---
-- Function SetMode()
-- Initialize sound output with specified buffer length and output mode.
--
-- @function [parent=#Audio] SetMode
-- @param self Self reference
-- @param #number bufferLengthMSec bufferLengthMSec
-- @param #number mixRate mixRate
-- @param #boolean stereo stereo
-- @param #boolean interpolation interpolation
-- @return #boolean

---
-- Function Play()
-- Restart sound output.
--
-- @function [parent=#Audio] Play
-- @param self Self reference
-- @return #boolean

---
-- Function Stop()
-- Suspend sound output.
--
-- @function [parent=#Audio] Stop
-- @param self Self reference

---
-- Function SetMasterGain()
-- Set master gain on a specific sound type such as sound effects, music or voice.
--
-- @function [parent=#Audio] SetMasterGain
-- @param self Self reference
-- @param SoundType#SoundType type type
-- @param #number gain gain

---
-- Function SetListener()
-- Set active sound listener for 3D sounds.
--
-- @function [parent=#Audio] SetListener
-- @param self Self reference
-- @param SoundListener#SoundListener listener listener

---
-- Function StopSound()
-- Stop any sound source playing a certain sound clip.
--
-- @function [parent=#Audio] StopSound
-- @param self Self reference
-- @param Sound#Sound sound sound

---
-- Function GetSampleSize()
-- Return byte size of one sample.
--
-- @function [parent=#Audio] GetSampleSize
-- @param self Self reference
-- @return #number

---
-- Function GetMixRate()
-- Return mixing rate.
--
-- @function [parent=#Audio] GetMixRate
-- @param self Self reference
-- @return #number

---
-- Function GetInterpolation()
-- Return whether output is interpolated.
--
-- @function [parent=#Audio] GetInterpolation
-- @param self Self reference
-- @return #boolean

---
-- Function IsStereo()
-- Return whether output is stereo.
--
-- @function [parent=#Audio] IsStereo
-- @param self Self reference
-- @return #boolean

---
-- Function IsPlaying()
-- Return whether audio is being output.
--
-- @function [parent=#Audio] IsPlaying
-- @param self Self reference
-- @return #boolean

---
-- Function IsInitialized()
-- Return whether an audio stream has been reserved.
--
-- @function [parent=#Audio] IsInitialized
-- @param self Self reference
-- @return #boolean

---
-- Function GetMasterGain()
-- Return master gain for a specific sound source type.
--
-- @function [parent=#Audio] GetMasterGain
-- @param self Self reference
-- @param SoundType#SoundType type type
-- @return #number

---
-- Function GetListener()
-- Return active sound listener.
--
-- @function [parent=#Audio] GetListener
-- @param self Self reference
-- @return SoundListener#SoundListener

---
-- Function GetSoundSources()
-- Return all sound sources.
--
-- @function [parent=#Audio] GetSoundSources
-- @param self Self reference
-- @return const PODVector<SoundSource*>#const PODVector<SoundSource*>

---
-- Function AddSoundSource()
-- Add a sound source to keep track of. Called by SoundSource.
--
-- @function [parent=#Audio] AddSoundSource
-- @param self Self reference
-- @param SoundSource#SoundSource soundSource soundSource

---
-- Function RemoveSoundSource()
-- Remove a sound source. Called by SoundSource.
--
-- @function [parent=#Audio] RemoveSoundSource
-- @param self Self reference
-- @param SoundSource#SoundSource soundSource soundSource

---
-- Function GetSoundSourceMasterGain()
-- Return sound type specific gain multiplied by master gain.
--
-- @function [parent=#Audio] GetSoundSourceMasterGain
-- @param self Self reference
-- @param SoundType#SoundType type type
-- @return #number

---
-- Function MixOutput()
--
-- @function [parent=#Audio] MixOutput
-- @param self Self reference
-- @param void*#void* dest dest
-- @param #number samples samples

---
-- Field sampleSize (Read only)
--
-- @field [parent=#Audio] #number sampleSize

---
-- Field mixRate (Read only)
--
-- @field [parent=#Audio] #number mixRate

---
-- Field interpolation (Read only)
--
-- @field [parent=#Audio] #boolean interpolation

---
-- Field stereo (Read only)
--
-- @field [parent=#Audio] #boolean stereo

---
-- Field playing (Read only)
--
-- @field [parent=#Audio] #boolean playing

---
-- Field initialized (Read only)
--
-- @field [parent=#Audio] #boolean initialized

---
-- Field listener
--
-- @field [parent=#Audio] SoundListener#SoundListener listener


return nil
