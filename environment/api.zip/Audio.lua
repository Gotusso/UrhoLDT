---
-- Module Audio
-- extends Object
--
-- @module Audio

---
-- Function SetMode
--
-- @function [parent=#Audio] SetMode
-- @param #number bufferLengthMSecbufferLengthMSec
-- @param #number mixRatemixRate
-- @param #boolean stereostereo
-- @param #boolean interpolationinterpolation
-- @return #boolean

---
-- Function Play
--
-- @function [parent=#Audio] Play
-- @return #boolean

---
-- Function Stop
--
-- @function [parent=#Audio] Stop

---
-- Function SetMasterGain
--
-- @function [parent=#Audio] SetMasterGain
-- @param SoundType#SoundType typetype
-- @param #number gaingain

---
-- Function SetListener
--
-- @function [parent=#Audio] SetListener
-- @param SoundListener#SoundListener listenerlistener

---
-- Function StopSound
--
-- @function [parent=#Audio] StopSound
-- @param Sound#Sound soundsound

---
-- Function GetSampleSize
--
-- @function [parent=#Audio] GetSampleSize
-- @return #number

---
-- Function GetMixRate
--
-- @function [parent=#Audio] GetMixRate
-- @return #number

---
-- Function GetInterpolation
--
-- @function [parent=#Audio] GetInterpolation
-- @return #boolean

---
-- Function IsStereo
--
-- @function [parent=#Audio] IsStereo
-- @return #boolean

---
-- Function IsPlaying
--
-- @function [parent=#Audio] IsPlaying
-- @return #boolean

---
-- Function IsInitialized
--
-- @function [parent=#Audio] IsInitialized
-- @return #boolean

---
-- Function GetMasterGain
--
-- @function [parent=#Audio] GetMasterGain
-- @param SoundType#SoundType typetype
-- @return #number

---
-- Function GetListener
--
-- @function [parent=#Audio] GetListener
-- @return SoundListener#SoundListener

---
-- Function GetSoundSources
--
-- @function [parent=#Audio] GetSoundSources
-- @return const PODVector<SoundSource*>#const PODVector<SoundSource*>

---
-- Function AddSoundSource
--
-- @function [parent=#Audio] AddSoundSource
-- @param SoundSource#SoundSource soundSourcesoundSource

---
-- Function RemoveSoundSource
--
-- @function [parent=#Audio] RemoveSoundSource
-- @param SoundSource#SoundSource soundSourcesoundSource

---
-- Function GetSoundSourceMasterGain
--
-- @function [parent=#Audio] GetSoundSourceMasterGain
-- @param SoundType#SoundType typetype
-- @return #number

---
-- Function MixOutput
--
-- @function [parent=#Audio] MixOutput
-- @param void*#void* destdest
-- @param #number samplessamples

---
-- Field sampleSize (Read only)
--
-- @field [parent=#Audio] #number sampleSize

---
-- Field mixRate (Read only)
--
-- @field [parent=#Audio] #number mixRate

---
-- Field interpolation (Read only)
--
-- @field [parent=#Audio] #boolean interpolation

---
-- Field stereo (Read only)
--
-- @field [parent=#Audio] #boolean stereo

---
-- Field playing (Read only)
--
-- @field [parent=#Audio] #boolean playing

---
-- Field initialized (Read only)
--
-- @field [parent=#Audio] #boolean initialized

---
-- Field listener
--
-- @field [parent=#Audio] SoundListener#SoundListener listener

---
-- Function GetType
--
-- @function [parent=#Audio] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Audio] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Audio] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Audio] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Audio] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#Audio] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Audio] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Audio] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Audio] #string category


return nil
