---
-- Module Audio
-- Module Audio extends Object
-- Generated on 2014-03-13
--
-- @module Audio

---
-- Function SetMode
--
-- @function [parent=#Audio] SetMode
-- @param self Self reference
-- @param #number bufferLengthMSec bufferLengthMSec
-- @param #number mixRate mixRate
-- @param #boolean stereo stereo
-- @param #boolean interpolation interpolation
-- @return #boolean

---
-- Function Play
--
-- @function [parent=#Audio] Play
-- @param self Self reference
-- @return #boolean

---
-- Function Stop
--
-- @function [parent=#Audio] Stop
-- @param self Self reference

---
-- Function SetMasterGain
--
-- @function [parent=#Audio] SetMasterGain
-- @param self Self reference
-- @param SoundType#SoundType type type
-- @param #number gain gain

---
-- Function SetListener
--
-- @function [parent=#Audio] SetListener
-- @param self Self reference
-- @param SoundListener#SoundListener listener listener

---
-- Function StopSound
--
-- @function [parent=#Audio] StopSound
-- @param self Self reference
-- @param Sound#Sound sound sound

---
-- Function GetSampleSize
--
-- @function [parent=#Audio] GetSampleSize
-- @param self Self reference
-- @return #number

---
-- Function GetMixRate
--
-- @function [parent=#Audio] GetMixRate
-- @param self Self reference
-- @return #number

---
-- Function GetInterpolation
--
-- @function [parent=#Audio] GetInterpolation
-- @param self Self reference
-- @return #boolean

---
-- Function IsStereo
--
-- @function [parent=#Audio] IsStereo
-- @param self Self reference
-- @return #boolean

---
-- Function IsPlaying
--
-- @function [parent=#Audio] IsPlaying
-- @param self Self reference
-- @return #boolean

---
-- Function IsInitialized
--
-- @function [parent=#Audio] IsInitialized
-- @param self Self reference
-- @return #boolean

---
-- Function GetMasterGain
--
-- @function [parent=#Audio] GetMasterGain
-- @param self Self reference
-- @param SoundType#SoundType type type
-- @return #number

---
-- Function GetListener
--
-- @function [parent=#Audio] GetListener
-- @param self Self reference
-- @return SoundListener#SoundListener

---
-- Function GetSoundSources
--
-- @function [parent=#Audio] GetSoundSources
-- @param self Self reference
-- @return const PODVector<SoundSource*>#const PODVector<SoundSource*>

---
-- Function AddSoundSource
--
-- @function [parent=#Audio] AddSoundSource
-- @param self Self reference
-- @param SoundSource#SoundSource soundSource soundSource

---
-- Function RemoveSoundSource
--
-- @function [parent=#Audio] RemoveSoundSource
-- @param self Self reference
-- @param SoundSource#SoundSource soundSource soundSource

---
-- Function GetSoundSourceMasterGain
--
-- @function [parent=#Audio] GetSoundSourceMasterGain
-- @param self Self reference
-- @param SoundType#SoundType type type
-- @return #number

---
-- Function MixOutput
--
-- @function [parent=#Audio] MixOutput
-- @param self Self reference
-- @param void*#void* dest dest
-- @param #number samples samples

---
-- Field sampleSize (Read only)
--
-- @field [parent=#Audio] #number sampleSize

---
-- Field mixRate (Read only)
--
-- @field [parent=#Audio] #number mixRate

---
-- Field interpolation (Read only)
--
-- @field [parent=#Audio] #boolean interpolation

---
-- Field stereo (Read only)
--
-- @field [parent=#Audio] #boolean stereo

---
-- Field playing (Read only)
--
-- @field [parent=#Audio] #boolean playing

---
-- Field initialized (Read only)
--
-- @field [parent=#Audio] #boolean initialized

---
-- Field listener
--
-- @field [parent=#Audio] SoundListener#SoundListener listener

---
-- Function GetType
--
-- @function [parent=#Audio] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Audio] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Audio] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Audio] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Audio] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#Audio] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Audio] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Audio] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Audio] #string category


return nil
