---
-- Module ObjectAnimation
-- Module ObjectAnimation extends Resource
-- Generated on 2014-05-31
--
-- @module ObjectAnimation

---
-- Function ObjectAnimation()
--
-- @function [parent=#ObjectAnimation] ObjectAnimation
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#ObjectAnimation] new
-- @param self Self reference
-- @return ObjectAnimation#ObjectAnimation

---
-- Function delete()
--
-- @function [parent=#ObjectAnimation] delete
-- @param self Self reference

---
-- Function AddAttributeAnimation()
-- Add attribute animation.
--
-- @function [parent=#ObjectAnimation] AddAttributeAnimation
-- @param self Self reference
-- @param #string name name
-- @param ValueAnimation#ValueAnimation attributeAnimation attributeAnimation
-- @param WrapMode#WrapMode wrapMode wrapMode
-- @param #number speed speed

---
-- Function RemoveAttributeAnimation()
-- Remove attribute animation.
--
-- @function [parent=#ObjectAnimation] RemoveAttributeAnimation
-- @param self Self reference
-- @param #string name name

---
-- Function RemoveAttributeAnimation()
-- Remove attribute animation.
--
-- @function [parent=#ObjectAnimation] RemoveAttributeAnimation
-- @param self Self reference
-- @param ValueAnimation#ValueAnimation attributeAnimation attributeAnimation

---
-- Function GetAttributeAnimation()
-- Return attribute animation by name.
--
-- @function [parent=#ObjectAnimation] GetAttributeAnimation
-- @param self Self reference
-- @param #string name name
-- @return ValueAnimation#ValueAnimation

---
-- Function GetAttributeAnimationWrapMode()
-- Return attribute animation wrap mode by name.
--
-- @function [parent=#ObjectAnimation] GetAttributeAnimationWrapMode
-- @param self Self reference
-- @param #string name name
-- @return WrapMode#WrapMode

---
-- Function GetAttributeAnimationSpeed()
-- Return attribute animation speed by name.
--
-- @function [parent=#ObjectAnimation] GetAttributeAnimationSpeed
-- @param self Self reference
-- @param #string name name
-- @return #number


return nil
