---
-- Module ConstraintFriction2D
-- Module ConstraintFriction2D extends Constraint2D
-- Generated on 2014-05-31
--
-- @module ConstraintFriction2D

---
-- Function SetAnchor()
-- Set anchor.
--
-- @function [parent=#ConstraintFriction2D] SetAnchor
-- @param self Self reference
-- @param Vector2#Vector2 anchor anchor

---
-- Function SetMaxForce()
-- Set max force.
--
-- @function [parent=#ConstraintFriction2D] SetMaxForce
-- @param self Self reference
-- @param #number maxForce maxForce

---
-- Function SetMaxTorque()
-- Set max torque.
--
-- @function [parent=#ConstraintFriction2D] SetMaxTorque
-- @param self Self reference
-- @param #number maxTorque maxTorque

---
-- Function GetAnchor()
-- Return anchor.
--
-- @function [parent=#ConstraintFriction2D] GetAnchor
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Function GetMaxForce()
-- Set max force.
--
-- @function [parent=#ConstraintFriction2D] GetMaxForce
-- @param self Self reference
-- @return #number

---
-- Function GetMaxTorque()
-- Set max torque.
--
-- @function [parent=#ConstraintFriction2D] GetMaxTorque
-- @param self Self reference
-- @return #number

---
-- Field anchor
--
-- @field [parent=#ConstraintFriction2D] Vector2#Vector2 anchor

---
-- Field maxForce
--
-- @field [parent=#ConstraintFriction2D] #number maxForce

---
-- Field maxTorque
--
-- @field [parent=#ConstraintFriction2D] #number maxTorque


return nil
