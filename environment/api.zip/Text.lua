---
-- Module Text
-- Extends UIElement
--
-- @module Text

---
-- Function Text
--
-- @function [parent=#Text] Text

---
-- Function new
--
-- @function [parent=#Text] new
-- @return Text#Text

---
-- Function delete
--
-- @function [parent=#Text] delete

---
-- Function SetFont
--
-- @function [parent=#Text] SetFont
-- @param #string fontNamefontName
-- @param #number sizesize
-- @return #boolean

---
-- Function SetFont
--
-- @function [parent=#Text] SetFont
-- @param Font#Font fontfont
-- @param #number sizesize
-- @return #boolean

---
-- Function SetText
--
-- @function [parent=#Text] SetText
-- @param #string texttext

---
-- Function SetTextAlignment
--
-- @function [parent=#Text] SetTextAlignment
-- @param HorizontalAlignment#HorizontalAlignment alignalign

---
-- Function SetRowSpacing
--
-- @function [parent=#Text] SetRowSpacing
-- @param #number spacingspacing

---
-- Function SetWordwrap
--
-- @function [parent=#Text] SetWordwrap
-- @param #boolean enableenable

---
-- Function SetSelection
--
-- @function [parent=#Text] SetSelection
-- @param #number startstart
-- @param #number lengthlength

---
-- Function ClearSelection
--
-- @function [parent=#Text] ClearSelection

---
-- Function SetSelectionColor
--
-- @function [parent=#Text] SetSelectionColor
-- @param Color#Color colorcolor

---
-- Function SetHoverColor
--
-- @function [parent=#Text] SetHoverColor
-- @param Color#Color colorcolor

---
-- Function SetTextEffect
--
-- @function [parent=#Text] SetTextEffect
-- @param TextEffect#TextEffect textEffecttextEffect

---
-- Function SetEffectColor
--
-- @function [parent=#Text] SetEffectColor
-- @param Color#Color effectColoreffectColor

---
-- Function GetFont
--
-- @function [parent=#Text] GetFont
-- @return Font#Font

---
-- Function GetFontSize
--
-- @function [parent=#Text] GetFontSize
-- @return #number

---
-- Function GetText
--
-- @function [parent=#Text] GetText
-- @return const String#const String

---
-- Function GetTextAlignment
--
-- @function [parent=#Text] GetTextAlignment
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetRowSpacing
--
-- @function [parent=#Text] GetRowSpacing
-- @return #number

---
-- Function GetWordwrap
--
-- @function [parent=#Text] GetWordwrap
-- @return #boolean

---
-- Function GetSelectionStart
--
-- @function [parent=#Text] GetSelectionStart
-- @return #number

---
-- Function GetSelectionLength
--
-- @function [parent=#Text] GetSelectionLength
-- @return #number

---
-- Function GetSelectionColor
--
-- @function [parent=#Text] GetSelectionColor
-- @return const Color#const Color

---
-- Function GetHoverColor
--
-- @function [parent=#Text] GetHoverColor
-- @return const Color#const Color

---
-- Function GetTextEffect
--
-- @function [parent=#Text] GetTextEffect
-- @return TextEffect#TextEffect

---
-- Function GetEffectColor
--
-- @function [parent=#Text] GetEffectColor
-- @return const Color#const Color

---
-- Function GetRowHeight
--
-- @function [parent=#Text] GetRowHeight
-- @return #number

---
-- Function GetNumRows
--
-- @function [parent=#Text] GetNumRows
-- @return #number

---
-- Function GetNumChars
--
-- @function [parent=#Text] GetNumChars
-- @return #number

---
-- Function GetRowWidth
--
-- @function [parent=#Text] GetRowWidth
-- @param #number indexindex
-- @return #number

---
-- Function GetCharPosition
--
-- @function [parent=#Text] GetCharPosition
-- @param #number indexindex
-- @return IntVector2#IntVector2

---
-- Function GetCharSize
--
-- @function [parent=#Text] GetCharSize
-- @param #number indexindex
-- @return IntVector2#IntVector2

---
-- Function SetEffectDepthBias
--
-- @function [parent=#Text] SetEffectDepthBias
-- @param #number biasbias

---
-- Function GetEffectDepthBias
--
-- @function [parent=#Text] GetEffectDepthBias
-- @return #number

---
-- Field font
--
-- @field [parent=#Text] Font#Font font

---
-- Field fontSize (Read only)
--
-- @field [parent=#Text] #number fontSize

---
-- Field text
--
-- @field [parent=#Text] #string text

---
-- Field textAlignment
--
-- @field [parent=#Text] HorizontalAlignment#HorizontalAlignment textAlignment

---
-- Field rowSpacing
--
-- @field [parent=#Text] #number rowSpacing

---
-- Field wordwrap
--
-- @field [parent=#Text] #boolean wordwrap

---
-- Field selectionStart (Read only)
--
-- @field [parent=#Text] #number selectionStart

---
-- Field selectionLength (Read only)
--
-- @field [parent=#Text] #number selectionLength

---
-- Field selectionColor
--
-- @field [parent=#Text] Color#Color selectionColor

---
-- Field hoverColor
--
-- @field [parent=#Text] Color#Color hoverColor

---
-- Field textEffect
--
-- @field [parent=#Text] TextEffect#TextEffect textEffect

---
-- Field effectColor
--
-- @field [parent=#Text] Color#Color effectColor

---
-- Field rowHeight (Read only)
--
-- @field [parent=#Text] #number rowHeight

---
-- Field numRows (Read only)
--
-- @field [parent=#Text] #number numRows

---
-- Field numChars (Read only)
--
-- @field [parent=#Text] #number numChars


return nil
