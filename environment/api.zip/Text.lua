---
-- Module Text
-- Module Text extends UIElement
-- Generated on 2014-05-31
--
-- @module Text

---
-- Function Text()
--
-- @function [parent=#Text] Text
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#Text] new
-- @param self Self reference
-- @return Text#Text

---
-- Function delete()
--
-- @function [parent=#Text] delete
-- @param self Self reference

---
-- Function SetFont()
-- Set font and font size.
--
-- @function [parent=#Text] SetFont
-- @param self Self reference
-- @param #string fontName fontName
-- @param #number size size
-- @return #boolean

---
-- Function SetFont()
-- Set font and font size.
--
-- @function [parent=#Text] SetFont
-- @param self Self reference
-- @param Font#Font font font
-- @param #number size size
-- @return #boolean

---
-- Function SetText()
-- Set text. Text is assumed to be either ASCII or UTF8-encoded.
--
-- @function [parent=#Text] SetText
-- @param self Self reference
-- @param #string text text

---
-- Function SetTextAlignment()
-- Set row alignment.
--
-- @function [parent=#Text] SetTextAlignment
-- @param self Self reference
-- @param HorizontalAlignment#HorizontalAlignment align align

---
-- Function SetRowSpacing()
-- Set row spacing, 1.0 for original font spacing.
--
-- @function [parent=#Text] SetRowSpacing
-- @param self Self reference
-- @param #number spacing spacing

---
-- Function SetWordwrap()
-- Set wordwrap. In wordwrap mode the text element will respect its current width. Otherwise it resizes itself freely.
--
-- @function [parent=#Text] SetWordwrap
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetSelection()
-- Set selection. When length is not provided, select until the text ends.
--
-- @function [parent=#Text] SetSelection
-- @param self Self reference
-- @param #number start start
-- @param #number length length

---
-- Function ClearSelection()
-- Clear selection.
--
-- @function [parent=#Text] ClearSelection
-- @param self Self reference

---
-- Function SetSelectionColor()
-- Set selection background color. Color with 0 alpha (default) disables.
--
-- @function [parent=#Text] SetSelectionColor
-- @param self Self reference
-- @param Color#Color color color

---
-- Function SetHoverColor()
-- Set hover background color. Color with 0 alpha (default) disables.
--
-- @function [parent=#Text] SetHoverColor
-- @param self Self reference
-- @param Color#Color color color

---
-- Function SetTextEffect()
-- Set text effect.
--
-- @function [parent=#Text] SetTextEffect
-- @param self Self reference
-- @param TextEffect#TextEffect textEffect textEffect

---
-- Function SetEffectColor()
-- Set effect color.
--
-- @function [parent=#Text] SetEffectColor
-- @param self Self reference
-- @param Color#Color effectColor effectColor

---
-- Function GetFont()
-- Return font.
--
-- @function [parent=#Text] GetFont
-- @param self Self reference
-- @return Font#Font

---
-- Function GetFontSize()
-- Return font size.
--
-- @function [parent=#Text] GetFontSize
-- @param self Self reference
-- @return #number

---
-- Function GetText()
-- Return text.
--
-- @function [parent=#Text] GetText
-- @param self Self reference
-- @return const String#const String

---
-- Function GetTextAlignment()
-- Return row alignment.
--
-- @function [parent=#Text] GetTextAlignment
-- @param self Self reference
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetRowSpacing()
-- Return row spacing.
--
-- @function [parent=#Text] GetRowSpacing
-- @param self Self reference
-- @return #number

---
-- Function GetWordwrap()
-- Return wordwrap mode.
--
-- @function [parent=#Text] GetWordwrap
-- @param self Self reference
-- @return #boolean

---
-- Function GetSelectionStart()
-- Return selection start.
--
-- @function [parent=#Text] GetSelectionStart
-- @param self Self reference
-- @return #number

---
-- Function GetSelectionLength()
-- Return selection length.
--
-- @function [parent=#Text] GetSelectionLength
-- @param self Self reference
-- @return #number

---
-- Function GetSelectionColor()
-- Return selection background color.
--
-- @function [parent=#Text] GetSelectionColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetHoverColor()
-- Return hover background color.
--
-- @function [parent=#Text] GetHoverColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetTextEffect()
-- Return text effect.
--
-- @function [parent=#Text] GetTextEffect
-- @param self Self reference
-- @return TextEffect#TextEffect

---
-- Function GetEffectColor()
-- Return effect color.
--
-- @function [parent=#Text] GetEffectColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetRowHeight()
-- Return row height.
--
-- @function [parent=#Text] GetRowHeight
-- @param self Self reference
-- @return #number

---
-- Function GetNumRows()
-- Return number of rows.
--
-- @function [parent=#Text] GetNumRows
-- @param self Self reference
-- @return #number

---
-- Function GetNumChars()
-- Return number of characters.
--
-- @function [parent=#Text] GetNumChars
-- @param self Self reference
-- @return #number

---
-- Function GetRowWidth()
-- Return width of row by index.
--
-- @function [parent=#Text] GetRowWidth
-- @param self Self reference
-- @param #number index index
-- @return #number

---
-- Function GetCharPosition()
-- Return position of character by index relative to the text element origin.
--
-- @function [parent=#Text] GetCharPosition
-- @param self Self reference
-- @param #number index index
-- @return IntVector2#IntVector2

---
-- Function GetCharSize()
-- Return size of character by index.
--
-- @function [parent=#Text] GetCharSize
-- @param self Self reference
-- @param #number index index
-- @return IntVector2#IntVector2

---
-- Function SetEffectDepthBias()
-- Set text effect Z bias. Zero by default, adjusted only in 3D mode.
--
-- @function [parent=#Text] SetEffectDepthBias
-- @param self Self reference
-- @param #number bias bias

---
-- Function GetEffectDepthBias()
-- Return effect Z bias.
--
-- @function [parent=#Text] GetEffectDepthBias
-- @param self Self reference
-- @return #number

---
-- Field font
--
-- @field [parent=#Text] Font#Font font

---
-- Field fontSize (Read only)
--
-- @field [parent=#Text] #number fontSize

---
-- Field text
--
-- @field [parent=#Text] #string text

---
-- Field textAlignment
--
-- @field [parent=#Text] HorizontalAlignment#HorizontalAlignment textAlignment

---
-- Field rowSpacing
--
-- @field [parent=#Text] #number rowSpacing

---
-- Field wordwrap
--
-- @field [parent=#Text] #boolean wordwrap

---
-- Field selectionStart (Read only)
--
-- @field [parent=#Text] #number selectionStart

---
-- Field selectionLength (Read only)
--
-- @field [parent=#Text] #number selectionLength

---
-- Field selectionColor
--
-- @field [parent=#Text] Color#Color selectionColor

---
-- Field hoverColor
--
-- @field [parent=#Text] Color#Color hoverColor

---
-- Field textEffect
--
-- @field [parent=#Text] TextEffect#TextEffect textEffect

---
-- Field effectColor
--
-- @field [parent=#Text] Color#Color effectColor

---
-- Field rowHeight (Read only)
--
-- @field [parent=#Text] #number rowHeight

---
-- Field numRows (Read only)
--
-- @field [parent=#Text] #number numRows

---
-- Field numChars (Read only)
--
-- @field [parent=#Text] #number numChars


return nil
