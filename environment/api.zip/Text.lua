---
-- Module Text
-- extends UIElement
--
-- @module Text

---
-- Function Text
--
-- @function [parent=#Text] Text

---
-- Function new
--
-- @function [parent=#Text] new
-- @return Text#Text

---
-- Function delete
--
-- @function [parent=#Text] delete

---
-- Function SetFont
--
-- @function [parent=#Text] SetFont
-- @param #string fontNamefontName
-- @param #number sizesize
-- @return #boolean

---
-- Function SetFont
--
-- @function [parent=#Text] SetFont
-- @param Font#Font fontfont
-- @param #number sizesize
-- @return #boolean

---
-- Function SetText
--
-- @function [parent=#Text] SetText
-- @param #string texttext

---
-- Function SetTextAlignment
--
-- @function [parent=#Text] SetTextAlignment
-- @param HorizontalAlignment#HorizontalAlignment alignalign

---
-- Function SetRowSpacing
--
-- @function [parent=#Text] SetRowSpacing
-- @param #number spacingspacing

---
-- Function SetWordwrap
--
-- @function [parent=#Text] SetWordwrap
-- @param #boolean enableenable

---
-- Function SetSelection
--
-- @function [parent=#Text] SetSelection
-- @param #number startstart
-- @param #number lengthlength

---
-- Function ClearSelection
--
-- @function [parent=#Text] ClearSelection

---
-- Function SetSelectionColor
--
-- @function [parent=#Text] SetSelectionColor
-- @param Color#Color colorcolor

---
-- Function SetHoverColor
--
-- @function [parent=#Text] SetHoverColor
-- @param Color#Color colorcolor

---
-- Function SetTextEffect
--
-- @function [parent=#Text] SetTextEffect
-- @param TextEffect#TextEffect textEffecttextEffect

---
-- Function SetEffectColor
--
-- @function [parent=#Text] SetEffectColor
-- @param Color#Color effectColoreffectColor

---
-- Function GetFont
--
-- @function [parent=#Text] GetFont
-- @return Font#Font

---
-- Function GetFontSize
--
-- @function [parent=#Text] GetFontSize
-- @return #number

---
-- Function GetText
--
-- @function [parent=#Text] GetText
-- @return const String#const String

---
-- Function GetTextAlignment
--
-- @function [parent=#Text] GetTextAlignment
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetRowSpacing
--
-- @function [parent=#Text] GetRowSpacing
-- @return #number

---
-- Function GetWordwrap
--
-- @function [parent=#Text] GetWordwrap
-- @return #boolean

---
-- Function GetSelectionStart
--
-- @function [parent=#Text] GetSelectionStart
-- @return #number

---
-- Function GetSelectionLength
--
-- @function [parent=#Text] GetSelectionLength
-- @return #number

---
-- Function GetSelectionColor
--
-- @function [parent=#Text] GetSelectionColor
-- @return const Color#const Color

---
-- Function GetHoverColor
--
-- @function [parent=#Text] GetHoverColor
-- @return const Color#const Color

---
-- Function GetTextEffect
--
-- @function [parent=#Text] GetTextEffect
-- @return TextEffect#TextEffect

---
-- Function GetEffectColor
--
-- @function [parent=#Text] GetEffectColor
-- @return const Color#const Color

---
-- Function GetRowHeight
--
-- @function [parent=#Text] GetRowHeight
-- @return #number

---
-- Function GetNumRows
--
-- @function [parent=#Text] GetNumRows
-- @return #number

---
-- Function GetNumChars
--
-- @function [parent=#Text] GetNumChars
-- @return #number

---
-- Function GetRowWidth
--
-- @function [parent=#Text] GetRowWidth
-- @param #number indexindex
-- @return #number

---
-- Function GetCharPosition
--
-- @function [parent=#Text] GetCharPosition
-- @param #number indexindex
-- @return IntVector2#IntVector2

---
-- Function GetCharSize
--
-- @function [parent=#Text] GetCharSize
-- @param #number indexindex
-- @return IntVector2#IntVector2

---
-- Function SetEffectDepthBias
--
-- @function [parent=#Text] SetEffectDepthBias
-- @param #number biasbias

---
-- Function GetEffectDepthBias
--
-- @function [parent=#Text] GetEffectDepthBias
-- @return #number

---
-- Field font
--
-- @field [parent=#Text] Font#Font font

---
-- Field fontSize (Read only)
--
-- @field [parent=#Text] #number fontSize

---
-- Field text
--
-- @field [parent=#Text] #string text

---
-- Field textAlignment
--
-- @field [parent=#Text] HorizontalAlignment#HorizontalAlignment textAlignment

---
-- Field rowSpacing
--
-- @field [parent=#Text] #number rowSpacing

---
-- Field wordwrap
--
-- @field [parent=#Text] #boolean wordwrap

---
-- Field selectionStart (Read only)
--
-- @field [parent=#Text] #number selectionStart

---
-- Field selectionLength (Read only)
--
-- @field [parent=#Text] #number selectionLength

---
-- Field selectionColor
--
-- @field [parent=#Text] Color#Color selectionColor

---
-- Field hoverColor
--
-- @field [parent=#Text] Color#Color hoverColor

---
-- Field textEffect
--
-- @field [parent=#Text] TextEffect#TextEffect textEffect

---
-- Field effectColor
--
-- @field [parent=#Text] Color#Color effectColor

---
-- Field rowHeight (Read only)
--
-- @field [parent=#Text] #number rowHeight

---
-- Field numRows (Read only)
--
-- @field [parent=#Text] #number numRows

---
-- Field numChars (Read only)
--
-- @field [parent=#Text] #number numChars

---
-- Function UIElement
--
-- @function [parent=#Text] UIElement

---
-- Function new
--
-- @function [parent=#Text] new
-- @return UIElement#UIElement

---
-- Function delete
--
-- @function [parent=#Text] delete

---
-- Function GetScreenPosition
--
-- @function [parent=#Text] GetScreenPosition
-- @return const IntVector2#const IntVector2

---
-- Function LoadXML
--
-- @function [parent=#Text] LoadXML
-- @param Deserializer#Deserializer sourcesource
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#Text] SaveXML
-- @param Serializer#Serializer destdest
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#Text] LoadXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#Text] SaveXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function FilterAttributes
--
-- @function [parent=#Text] FilterAttributes
-- @param XMLElement#XMLElement destdest
-- @return #boolean

---
-- Function SetName
--
-- @function [parent=#Text] SetName
-- @param #string namename

---
-- Function SetPosition
--
-- @function [parent=#Text] SetPosition
-- @param IntVector2#IntVector2 positionposition

---
-- Function SetPosition
--
-- @function [parent=#Text] SetPosition
-- @param #number xx
-- @param #number yy

---
-- Function SetSize
--
-- @function [parent=#Text] SetSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function SetSize
--
-- @function [parent=#Text] SetSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetWidth
--
-- @function [parent=#Text] SetWidth
-- @param #number widthwidth

---
-- Function SetHeight
--
-- @function [parent=#Text] SetHeight
-- @param #number heightheight

---
-- Function SetMinSize
--
-- @function [parent=#Text] SetMinSize
-- @param IntVector2#IntVector2 minSizeminSize

---
-- Function SetMinSize
--
-- @function [parent=#Text] SetMinSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetMinWidth
--
-- @function [parent=#Text] SetMinWidth
-- @param #number widthwidth

---
-- Function SetMinHeight
--
-- @function [parent=#Text] SetMinHeight
-- @param #number heightheight

---
-- Function SetMaxSize
--
-- @function [parent=#Text] SetMaxSize
-- @param IntVector2#IntVector2 maxSizemaxSize

---
-- Function SetMaxSize
--
-- @function [parent=#Text] SetMaxSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetMaxWidth
--
-- @function [parent=#Text] SetMaxWidth
-- @param #number widthwidth

---
-- Function SetMaxHeight
--
-- @function [parent=#Text] SetMaxHeight
-- @param #number heightheight

---
-- Function SetFixedSize
--
-- @function [parent=#Text] SetFixedSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function SetFixedSize
--
-- @function [parent=#Text] SetFixedSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetFixedWidth
--
-- @function [parent=#Text] SetFixedWidth
-- @param #number widthwidth

---
-- Function SetFixedHeight
--
-- @function [parent=#Text] SetFixedHeight
-- @param #number heightheight

---
-- Function SetAlignment
--
-- @function [parent=#Text] SetAlignment
-- @param HorizontalAlignment#HorizontalAlignment hAlignhAlign
-- @param VerticalAlignment#VerticalAlignment vAlignvAlign

---
-- Function SetHorizontalAlignment
--
-- @function [parent=#Text] SetHorizontalAlignment
-- @param HorizontalAlignment#HorizontalAlignment alignalign

---
-- Function SetVerticalAlignment
--
-- @function [parent=#Text] SetVerticalAlignment
-- @param VerticalAlignment#VerticalAlignment alignalign

---
-- Function SetClipBorder
--
-- @function [parent=#Text] SetClipBorder
-- @param IntRect#IntRect rectrect

---
-- Function SetColor
--
-- @function [parent=#Text] SetColor
-- @param Color#Color colorcolor

---
-- Function SetColor
--
-- @function [parent=#Text] SetColor
-- @param Corner#Corner cornercorner
-- @param Color#Color colorcolor

---
-- Function SetPriority
--
-- @function [parent=#Text] SetPriority
-- @param #number prioritypriority

---
-- Function SetOpacity
--
-- @function [parent=#Text] SetOpacity
-- @param #number opacityopacity

---
-- Function SetBringToFront
--
-- @function [parent=#Text] SetBringToFront
-- @param #boolean enableenable

---
-- Function SetBringToBack
--
-- @function [parent=#Text] SetBringToBack
-- @param #boolean enableenable

---
-- Function SetClipChildren
--
-- @function [parent=#Text] SetClipChildren
-- @param #boolean enableenable

---
-- Function SetSortChildren
--
-- @function [parent=#Text] SetSortChildren
-- @param #boolean enableenable

---
-- Function SetUseDerivedOpacity
--
-- @function [parent=#Text] SetUseDerivedOpacity
-- @param #boolean enableenable

---
-- Function SetEnabled
--
-- @function [parent=#Text] SetEnabled
-- @param #boolean enableenable

---
-- Function SetEditable
--
-- @function [parent=#Text] SetEditable
-- @param #boolean enableenable

---
-- Function SetFocus
--
-- @function [parent=#Text] SetFocus
-- @param #boolean enableenable

---
-- Function SetSelected
--
-- @function [parent=#Text] SetSelected
-- @param #boolean enableenable

---
-- Function SetVisible
--
-- @function [parent=#Text] SetVisible
-- @param #boolean enableenable

---
-- Function SetFocusMode
--
-- @function [parent=#Text] SetFocusMode
-- @param FocusMode#FocusMode modemode

---
-- Function SetDragDropMode
--
-- @function [parent=#Text] SetDragDropMode
-- @param #number modemode

---
-- Function SetStyle
--
-- @function [parent=#Text] SetStyle
-- @param #string styleNamestyleName
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetStyle
--
-- @function [parent=#Text] SetStyle
-- @param XMLElement#XMLElement elementelement
-- @return #boolean

---
-- Function SetStyleAuto
--
-- @function [parent=#Text] SetStyleAuto
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetDefaultStyle
--
-- @function [parent=#Text] SetDefaultStyle
-- @param XMLFile#XMLFile stylestyle

---
-- Function SetLayout
--
-- @function [parent=#Text] SetLayout
-- @param LayoutMode#LayoutMode modemode
-- @param #number spacingspacing

---
-- Function SetLayout
--
-- @function [parent=#Text] SetLayout
-- @param LayoutMode#LayoutMode modemode
-- @param #number spacingspacing
-- @param IntRect#IntRect borderborder

---
-- Function SetLayoutMode
--
-- @function [parent=#Text] SetLayoutMode
-- @param LayoutMode#LayoutMode modemode

---
-- Function SetLayoutSpacing
--
-- @function [parent=#Text] SetLayoutSpacing
-- @param #number spacingspacing

---
-- Function SetLayoutBorder
--
-- @function [parent=#Text] SetLayoutBorder
-- @param IntRect#IntRect borderborder

---
-- Function SetIndent
--
-- @function [parent=#Text] SetIndent
-- @param #number indentindent

---
-- Function SetIndentSpacing
--
-- @function [parent=#Text] SetIndentSpacing
-- @param #number indentSpacingindentSpacing

---
-- Function UpdateLayout
--
-- @function [parent=#Text] UpdateLayout

---
-- Function DisableLayoutUpdate
--
-- @function [parent=#Text] DisableLayoutUpdate

---
-- Function EnableLayoutUpdate
--
-- @function [parent=#Text] EnableLayoutUpdate

---
-- Function BringToFront
--
-- @function [parent=#Text] BringToFront

---
-- Function CreateChild
--
-- @function [parent=#Text] CreateChild
-- @param #string typetype
-- @param #string namename
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function AddChild
--
-- @function [parent=#Text] AddChild
-- @param UIElement#UIElement elementelement

---
-- Function InsertChild
--
-- @function [parent=#Text] InsertChild
-- @param #number indexindex
-- @param UIElement#UIElement elementelement

---
-- Function RemoveChild
--
-- @function [parent=#Text] RemoveChild
-- @param UIElement#UIElement elementelement
-- @param #number indexindex

---
-- Function RemoveChildAtIndex
--
-- @function [parent=#Text] RemoveChildAtIndex
-- @param #number indexindex

---
-- Function RemoveAllChildren
--
-- @function [parent=#Text] RemoveAllChildren

---
-- Function Remove
--
-- @function [parent=#Text] Remove

---
-- Function FindChild
--
-- @function [parent=#Text] FindChild
-- @param UIElement#UIElement elementelement
-- @return #number

---
-- Function SetParent
--
-- @function [parent=#Text] SetParent
-- @param UIElement#UIElement parentparent
-- @param #number indexindex

---
-- Function SetVar
--
-- @function [parent=#Text] SetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @param Variant#Variant valuevalue

---
-- Function SetInternal
--
-- @function [parent=#Text] SetInternal
-- @param #boolean enableenable

---
-- Function SetTraversalMode
--
-- @function [parent=#Text] SetTraversalMode
-- @param TraversalMode#TraversalMode traversalModetraversalMode

---
-- Function SetElementEventSender
--
-- @function [parent=#Text] SetElementEventSender
-- @param #boolean flagflag

---
-- Function GetName
--
-- @function [parent=#Text] GetName
-- @return const String#const String

---
-- Function GetPosition
--
-- @function [parent=#Text] GetPosition
-- @return const IntVector2#const IntVector2

---
-- Function GetSize
--
-- @function [parent=#Text] GetSize
-- @return const IntVector2#const IntVector2

---
-- Function GetWidth
--
-- @function [parent=#Text] GetWidth
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#Text] GetHeight
-- @return #number

---
-- Function GetMinSize
--
-- @function [parent=#Text] GetMinSize
-- @return const IntVector2#const IntVector2

---
-- Function GetMinWidth
--
-- @function [parent=#Text] GetMinWidth
-- @return #number

---
-- Function GetMinHeight
--
-- @function [parent=#Text] GetMinHeight
-- @return #number

---
-- Function GetMaxSize
--
-- @function [parent=#Text] GetMaxSize
-- @return const IntVector2#const IntVector2

---
-- Function GetMaxWidth
--
-- @function [parent=#Text] GetMaxWidth
-- @return #number

---
-- Function GetMaxHeight
--
-- @function [parent=#Text] GetMaxHeight
-- @return #number

---
-- Function IsFixedSize
--
-- @function [parent=#Text] IsFixedSize
-- @return #boolean

---
-- Function IsFixedWidth
--
-- @function [parent=#Text] IsFixedWidth
-- @return #boolean

---
-- Function IsFixedHeight
--
-- @function [parent=#Text] IsFixedHeight
-- @return #boolean

---
-- Function GetChildOffset
--
-- @function [parent=#Text] GetChildOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetHorizontalAlignment
--
-- @function [parent=#Text] GetHorizontalAlignment
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetVerticalAlignment
--
-- @function [parent=#Text] GetVerticalAlignment
-- @return VerticalAlignment#VerticalAlignment

---
-- Function GetClipBorder
--
-- @function [parent=#Text] GetClipBorder
-- @return const IntRect#const IntRect

---
-- Function GetColor
--
-- @function [parent=#Text] GetColor
-- @param Corner#Corner cornercorner
-- @return const Color#const Color

---
-- Function GetPriority
--
-- @function [parent=#Text] GetPriority
-- @return #number

---
-- Function GetOpacity
--
-- @function [parent=#Text] GetOpacity
-- @return #number

---
-- Function GetDerivedOpacity
--
-- @function [parent=#Text] GetDerivedOpacity
-- @return #number

---
-- Function GetBringToFront
--
-- @function [parent=#Text] GetBringToFront
-- @return #boolean

---
-- Function GetBringToBack
--
-- @function [parent=#Text] GetBringToBack
-- @return #boolean

---
-- Function GetClipChildren
--
-- @function [parent=#Text] GetClipChildren
-- @return #boolean

---
-- Function GetSortChildren
--
-- @function [parent=#Text] GetSortChildren
-- @return #boolean

---
-- Function GetUseDerivedOpacity
--
-- @function [parent=#Text] GetUseDerivedOpacity
-- @return #boolean

---
-- Function HasFocus
--
-- @function [parent=#Text] HasFocus
-- @return #boolean

---
-- Function IsEnabled
--
-- @function [parent=#Text] IsEnabled
-- @return #boolean

---
-- Function IsEditable
--
-- @function [parent=#Text] IsEditable
-- @return #boolean

---
-- Function IsSelected
--
-- @function [parent=#Text] IsSelected
-- @return #boolean

---
-- Function IsVisible
--
-- @function [parent=#Text] IsVisible
-- @return #boolean

---
-- Function IsHovering
--
-- @function [parent=#Text] IsHovering
-- @return #boolean

---
-- Function IsInternal
--
-- @function [parent=#Text] IsInternal
-- @return #boolean

---
-- Function HasColorGradient
--
-- @function [parent=#Text] HasColorGradient
-- @return #boolean

---
-- Function GetFocusMode
--
-- @function [parent=#Text] GetFocusMode
-- @return FocusMode#FocusMode

---
-- Function GetDragDropMode
--
-- @function [parent=#Text] GetDragDropMode
-- @return #number

---
-- Function GetAppliedStyle
--
-- @function [parent=#Text] GetAppliedStyle
-- @return const String#const String

---
-- Function GetDefaultStyle
--
-- @function [parent=#Text] GetDefaultStyle
-- @param #boolean recursiveUprecursiveUp
-- @return XMLFile#XMLFile

---
-- Function GetLayoutMode
--
-- @function [parent=#Text] GetLayoutMode
-- @return LayoutMode#LayoutMode

---
-- Function GetLayoutSpacing
--
-- @function [parent=#Text] GetLayoutSpacing
-- @return #number

---
-- Function GetLayoutBorder
--
-- @function [parent=#Text] GetLayoutBorder
-- @return const IntRect#const IntRect

---
-- Function GetNumChildren
--
-- @function [parent=#Text] GetNumChildren
-- @param #boolean recursiverecursive
-- @return #number

---
-- Function GetChild
--
-- @function [parent=#Text] GetChild
-- @param #string namename
-- @param #boolean recursiverecursive
-- @return UIElement#UIElement

---
-- Function GetChild
--
-- @function [parent=#Text] GetChild
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function GetParent
--
-- @function [parent=#Text] GetParent
-- @return UIElement#UIElement

---
-- Function GetRoot
--
-- @function [parent=#Text] GetRoot
-- @return UIElement#UIElement

---
-- Function GetDerivedColor
--
-- @function [parent=#Text] GetDerivedColor
-- @return const Color#const Color

---
-- Function GetVar
--
-- @function [parent=#Text] GetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @return const Variant#const Variant

---
-- Function GetVars
--
-- @function [parent=#Text] GetVars
-- @return const VariantMap#const VariantMap

---
-- Function ScreenToElement
--
-- @function [parent=#Text] ScreenToElement
-- @param IntVector2#IntVector2 screenPositionscreenPosition
-- @return IntVector2#IntVector2

---
-- Function ElementToScreen
--
-- @function [parent=#Text] ElementToScreen
-- @param IntVector2#IntVector2 positionposition
-- @return IntVector2#IntVector2

---
-- Function IsInside
--
-- @function [parent=#Text] IsInside
-- @param IntVector2#IntVector2 positionposition
-- @param #boolean isScreenisScreen
-- @return #boolean

---
-- Function IsInsideCombined
--
-- @function [parent=#Text] IsInsideCombined
-- @param IntVector2#IntVector2 positionposition
-- @param #boolean isScreenisScreen
-- @return #boolean

---
-- Function GetCombinedScreenRect
--
-- @function [parent=#Text] GetCombinedScreenRect
-- @return IntRect#IntRect

---
-- Function SortChildren
--
-- @function [parent=#Text] SortChildren

---
-- Function GetLayoutMinSize
--
-- @function [parent=#Text] GetLayoutMinSize
-- @return #number

---
-- Function GetIndent
--
-- @function [parent=#Text] GetIndent
-- @return #number

---
-- Function GetIndentSpacing
--
-- @function [parent=#Text] GetIndentSpacing
-- @return #number

---
-- Function GetIndentWidth
--
-- @function [parent=#Text] GetIndentWidth
-- @return #number

---
-- Function SetChildOffset
--
-- @function [parent=#Text] SetChildOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetHovering
--
-- @function [parent=#Text] SetHovering
-- @param #boolean enableenable

---
-- Function GetColor
--
-- @function [parent=#Text] GetColor
-- @return const Color#const Color

---
-- Function GetTraversalMode
--
-- @function [parent=#Text] GetTraversalMode
-- @return TraversalMode#TraversalMode

---
-- Function IsElementEventSender
--
-- @function [parent=#Text] IsElementEventSender
-- @return #boolean

---
-- Function GetElementEventSender
--
-- @function [parent=#Text] GetElementEventSender
-- @return UIElement#UIElement

---
-- Field screenPosition (Read only)
--
-- @field [parent=#Text] IntVector2#IntVector2 screenPosition

---
-- Field name
--
-- @field [parent=#Text] #string name

---
-- Field position
--
-- @field [parent=#Text] IntVector2#IntVector2 position

---
-- Field size
--
-- @field [parent=#Text] IntVector2#IntVector2 size

---
-- Field width
--
-- @field [parent=#Text] #number width

---
-- Field height
--
-- @field [parent=#Text] #number height

---
-- Field minSize
--
-- @field [parent=#Text] IntVector2#IntVector2 minSize

---
-- Field minWidth
--
-- @field [parent=#Text] #number minWidth

---
-- Field minHeight
--
-- @field [parent=#Text] #number minHeight

---
-- Field maxSize
--
-- @field [parent=#Text] IntVector2#IntVector2 maxSize

---
-- Field maxWidth
--
-- @field [parent=#Text] #number maxWidth

---
-- Field maxHeight
--
-- @field [parent=#Text] #number maxHeight

---
-- Field fixedSize (Read only)
--
-- @field [parent=#Text] #boolean fixedSize

---
-- Field fixedWidth (Read only)
--
-- @field [parent=#Text] #boolean fixedWidth

---
-- Field fixedHeight (Read only)
--
-- @field [parent=#Text] #boolean fixedHeight

---
-- Field childOffset
--
-- @field [parent=#Text] IntVector2#IntVector2 childOffset

---
-- Field horizontalAlignment
--
-- @field [parent=#Text] HorizontalAlignment#HorizontalAlignment horizontalAlignment

---
-- Field verticalAlignment
--
-- @field [parent=#Text] VerticalAlignment#VerticalAlignment verticalAlignment

---
-- Field clipBorder
--
-- @field [parent=#Text] IntRect#IntRect clipBorder

---
-- Field color
--
-- @field [parent=#Text] Color#Color color

---
-- Field priority
--
-- @field [parent=#Text] #number priority

---
-- Field opacity
--
-- @field [parent=#Text] #number opacity

---
-- Field derivedOpacity (Read only)
--
-- @field [parent=#Text] #number derivedOpacity

---
-- Field bringToFront
--
-- @field [parent=#Text] #boolean bringToFront

---
-- Field bringToBack
--
-- @field [parent=#Text] #boolean bringToBack

---
-- Field clipChildren
--
-- @field [parent=#Text] #boolean clipChildren

---
-- Field sortChildren
--
-- @field [parent=#Text] #boolean sortChildren

---
-- Field useDerivedOpacity
--
-- @field [parent=#Text] #boolean useDerivedOpacity

---
-- Field focus
--
-- @field [parent=#Text] #boolean focus

---
-- Field enabled
--
-- @field [parent=#Text] #boolean enabled

---
-- Field editable
--
-- @field [parent=#Text] #boolean editable

---
-- Field selected
--
-- @field [parent=#Text] #boolean selected

---
-- Field visible
--
-- @field [parent=#Text] #boolean visible

---
-- Field hovering
--
-- @field [parent=#Text] #boolean hovering

---
-- Field internal
--
-- @field [parent=#Text] #boolean internal

---
-- Field colorGradient (Read only)
--
-- @field [parent=#Text] #boolean colorGradient

---
-- Field focusMode
--
-- @field [parent=#Text] FocusMode#FocusMode focusMode

---
-- Field dragDropMode
--
-- @field [parent=#Text] #number dragDropMode

---
-- Field style
--
-- @field [parent=#Text] #string style

---
-- Field defaultStyle
--
-- @field [parent=#Text] XMLFile#XMLFile defaultStyle

---
-- Field layoutMode
--
-- @field [parent=#Text] LayoutMode#LayoutMode layoutMode

---
-- Field layoutSpacing
--
-- @field [parent=#Text] #number layoutSpacing

---
-- Field layoutBorder
--
-- @field [parent=#Text] IntRect#IntRect layoutBorder

---
-- Field numChildren (Read only)
--
-- @field [parent=#Text] #number numChildren

---
-- Field parent
--
-- @field [parent=#Text] UIElement#UIElement parent

---
-- Field root (Read only)
--
-- @field [parent=#Text] UIElement#UIElement root

---
-- Field derivedColor (Read only)
--
-- @field [parent=#Text] Color#Color derivedColor

---
-- Field combinedScreenRect (Read only)
--
-- @field [parent=#Text] IntRect#IntRect combinedScreenRect

---
-- Field layoutMinSize (Read only)
--
-- @field [parent=#Text] #number layoutMinSize

---
-- Field indent
--
-- @field [parent=#Text] #number indent

---
-- Field indentSpacing
--
-- @field [parent=#Text] #number indentSpacing

---
-- Field indentWidth (Read only)
--
-- @field [parent=#Text] #number indentWidth

---
-- Field traversalMode
--
-- @field [parent=#Text] TraversalMode#TraversalMode traversalMode

---
-- Field elementEventSender
--
-- @field [parent=#Text] #boolean elementEventSender

---
-- Function SetTemporary
--
-- @function [parent=#Text] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#Text] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Text] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Text] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Text] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Text] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Text] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Text] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#Text] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Text] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Text] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Text] #string category


return nil
