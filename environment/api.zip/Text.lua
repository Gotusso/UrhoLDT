---
-- Module Text
-- Module Text extends UIElement
-- Generated on 2014-03-13
--
-- @module Text

---
-- Function Text
--
-- @function [parent=#Text] Text
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#Text] new
-- @param self Self reference
-- @return Text#Text

---
-- Function delete
--
-- @function [parent=#Text] delete
-- @param self Self reference

---
-- Function SetFont
--
-- @function [parent=#Text] SetFont
-- @param self Self reference
-- @param #string fontName fontName
-- @param #number size size
-- @return #boolean

---
-- Function SetFont
--
-- @function [parent=#Text] SetFont
-- @param self Self reference
-- @param Font#Font font font
-- @param #number size size
-- @return #boolean

---
-- Function SetText
--
-- @function [parent=#Text] SetText
-- @param self Self reference
-- @param #string text text

---
-- Function SetTextAlignment
--
-- @function [parent=#Text] SetTextAlignment
-- @param self Self reference
-- @param HorizontalAlignment#HorizontalAlignment align align

---
-- Function SetRowSpacing
--
-- @function [parent=#Text] SetRowSpacing
-- @param self Self reference
-- @param #number spacing spacing

---
-- Function SetWordwrap
--
-- @function [parent=#Text] SetWordwrap
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetSelection
--
-- @function [parent=#Text] SetSelection
-- @param self Self reference
-- @param #number start start
-- @param #number length length

---
-- Function ClearSelection
--
-- @function [parent=#Text] ClearSelection
-- @param self Self reference

---
-- Function SetSelectionColor
--
-- @function [parent=#Text] SetSelectionColor
-- @param self Self reference
-- @param Color#Color color color

---
-- Function SetHoverColor
--
-- @function [parent=#Text] SetHoverColor
-- @param self Self reference
-- @param Color#Color color color

---
-- Function SetTextEffect
--
-- @function [parent=#Text] SetTextEffect
-- @param self Self reference
-- @param TextEffect#TextEffect textEffect textEffect

---
-- Function SetEffectColor
--
-- @function [parent=#Text] SetEffectColor
-- @param self Self reference
-- @param Color#Color effectColor effectColor

---
-- Function GetFont
--
-- @function [parent=#Text] GetFont
-- @param self Self reference
-- @return Font#Font

---
-- Function GetFontSize
--
-- @function [parent=#Text] GetFontSize
-- @param self Self reference
-- @return #number

---
-- Function GetText
--
-- @function [parent=#Text] GetText
-- @param self Self reference
-- @return const String#const String

---
-- Function GetTextAlignment
--
-- @function [parent=#Text] GetTextAlignment
-- @param self Self reference
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetRowSpacing
--
-- @function [parent=#Text] GetRowSpacing
-- @param self Self reference
-- @return #number

---
-- Function GetWordwrap
--
-- @function [parent=#Text] GetWordwrap
-- @param self Self reference
-- @return #boolean

---
-- Function GetSelectionStart
--
-- @function [parent=#Text] GetSelectionStart
-- @param self Self reference
-- @return #number

---
-- Function GetSelectionLength
--
-- @function [parent=#Text] GetSelectionLength
-- @param self Self reference
-- @return #number

---
-- Function GetSelectionColor
--
-- @function [parent=#Text] GetSelectionColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetHoverColor
--
-- @function [parent=#Text] GetHoverColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetTextEffect
--
-- @function [parent=#Text] GetTextEffect
-- @param self Self reference
-- @return TextEffect#TextEffect

---
-- Function GetEffectColor
--
-- @function [parent=#Text] GetEffectColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetRowHeight
--
-- @function [parent=#Text] GetRowHeight
-- @param self Self reference
-- @return #number

---
-- Function GetNumRows
--
-- @function [parent=#Text] GetNumRows
-- @param self Self reference
-- @return #number

---
-- Function GetNumChars
--
-- @function [parent=#Text] GetNumChars
-- @param self Self reference
-- @return #number

---
-- Function GetRowWidth
--
-- @function [parent=#Text] GetRowWidth
-- @param self Self reference
-- @param #number index index
-- @return #number

---
-- Function GetCharPosition
--
-- @function [parent=#Text] GetCharPosition
-- @param self Self reference
-- @param #number index index
-- @return IntVector2#IntVector2

---
-- Function GetCharSize
--
-- @function [parent=#Text] GetCharSize
-- @param self Self reference
-- @param #number index index
-- @return IntVector2#IntVector2

---
-- Function SetEffectDepthBias
--
-- @function [parent=#Text] SetEffectDepthBias
-- @param self Self reference
-- @param #number bias bias

---
-- Function GetEffectDepthBias
--
-- @function [parent=#Text] GetEffectDepthBias
-- @param self Self reference
-- @return #number

---
-- Field font
--
-- @field [parent=#Text] Font#Font font

---
-- Field fontSize (Read only)
--
-- @field [parent=#Text] #number fontSize

---
-- Field text
--
-- @field [parent=#Text] #string text

---
-- Field textAlignment
--
-- @field [parent=#Text] HorizontalAlignment#HorizontalAlignment textAlignment

---
-- Field rowSpacing
--
-- @field [parent=#Text] #number rowSpacing

---
-- Field wordwrap
--
-- @field [parent=#Text] #boolean wordwrap

---
-- Field selectionStart (Read only)
--
-- @field [parent=#Text] #number selectionStart

---
-- Field selectionLength (Read only)
--
-- @field [parent=#Text] #number selectionLength

---
-- Field selectionColor
--
-- @field [parent=#Text] Color#Color selectionColor

---
-- Field hoverColor
--
-- @field [parent=#Text] Color#Color hoverColor

---
-- Field textEffect
--
-- @field [parent=#Text] TextEffect#TextEffect textEffect

---
-- Field effectColor
--
-- @field [parent=#Text] Color#Color effectColor

---
-- Field rowHeight (Read only)
--
-- @field [parent=#Text] #number rowHeight

---
-- Field numRows (Read only)
--
-- @field [parent=#Text] #number numRows

---
-- Field numChars (Read only)
--
-- @field [parent=#Text] #number numChars

---
-- Function UIElement
--
-- @function [parent=#Text] UIElement
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#Text] new
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function delete
--
-- @function [parent=#Text] delete
-- @param self Self reference

---
-- Function GetScreenPosition
--
-- @function [parent=#Text] GetScreenPosition
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function LoadXML
--
-- @function [parent=#Text] LoadXML
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#Text] SaveXML
-- @param self Self reference
-- @param Serializer#Serializer dest dest
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#Text] LoadXML
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#Text] SaveXML
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function FilterAttributes
--
-- @function [parent=#Text] FilterAttributes
-- @param self Self reference
-- @param XMLElement#XMLElement dest dest
-- @return #boolean

---
-- Function SetName
--
-- @function [parent=#Text] SetName
-- @param self Self reference
-- @param #string name name

---
-- Function SetPosition
--
-- @function [parent=#Text] SetPosition
-- @param self Self reference
-- @param IntVector2#IntVector2 position position

---
-- Function SetPosition
--
-- @function [parent=#Text] SetPosition
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function SetSize
--
-- @function [parent=#Text] SetSize
-- @param self Self reference
-- @param IntVector2#IntVector2 size size

---
-- Function SetSize
--
-- @function [parent=#Text] SetSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetWidth
--
-- @function [parent=#Text] SetWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetHeight
--
-- @function [parent=#Text] SetHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetMinSize
--
-- @function [parent=#Text] SetMinSize
-- @param self Self reference
-- @param IntVector2#IntVector2 minSize minSize

---
-- Function SetMinSize
--
-- @function [parent=#Text] SetMinSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetMinWidth
--
-- @function [parent=#Text] SetMinWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetMinHeight
--
-- @function [parent=#Text] SetMinHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetMaxSize
--
-- @function [parent=#Text] SetMaxSize
-- @param self Self reference
-- @param IntVector2#IntVector2 maxSize maxSize

---
-- Function SetMaxSize
--
-- @function [parent=#Text] SetMaxSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetMaxWidth
--
-- @function [parent=#Text] SetMaxWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetMaxHeight
--
-- @function [parent=#Text] SetMaxHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetFixedSize
--
-- @function [parent=#Text] SetFixedSize
-- @param self Self reference
-- @param IntVector2#IntVector2 size size

---
-- Function SetFixedSize
--
-- @function [parent=#Text] SetFixedSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetFixedWidth
--
-- @function [parent=#Text] SetFixedWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetFixedHeight
--
-- @function [parent=#Text] SetFixedHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetAlignment
--
-- @function [parent=#Text] SetAlignment
-- @param self Self reference
-- @param HorizontalAlignment#HorizontalAlignment hAlign hAlign
-- @param VerticalAlignment#VerticalAlignment vAlign vAlign

---
-- Function SetHorizontalAlignment
--
-- @function [parent=#Text] SetHorizontalAlignment
-- @param self Self reference
-- @param HorizontalAlignment#HorizontalAlignment align align

---
-- Function SetVerticalAlignment
--
-- @function [parent=#Text] SetVerticalAlignment
-- @param self Self reference
-- @param VerticalAlignment#VerticalAlignment align align

---
-- Function SetClipBorder
--
-- @function [parent=#Text] SetClipBorder
-- @param self Self reference
-- @param IntRect#IntRect rect rect

---
-- Function SetColor
--
-- @function [parent=#Text] SetColor
-- @param self Self reference
-- @param Color#Color color color

---
-- Function SetColor
--
-- @function [parent=#Text] SetColor
-- @param self Self reference
-- @param Corner#Corner corner corner
-- @param Color#Color color color

---
-- Function SetPriority
--
-- @function [parent=#Text] SetPriority
-- @param self Self reference
-- @param #number priority priority

---
-- Function SetOpacity
--
-- @function [parent=#Text] SetOpacity
-- @param self Self reference
-- @param #number opacity opacity

---
-- Function SetBringToFront
--
-- @function [parent=#Text] SetBringToFront
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetBringToBack
--
-- @function [parent=#Text] SetBringToBack
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetClipChildren
--
-- @function [parent=#Text] SetClipChildren
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetSortChildren
--
-- @function [parent=#Text] SetSortChildren
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetUseDerivedOpacity
--
-- @function [parent=#Text] SetUseDerivedOpacity
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetEnabled
--
-- @function [parent=#Text] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetEditable
--
-- @function [parent=#Text] SetEditable
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetFocus
--
-- @function [parent=#Text] SetFocus
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetSelected
--
-- @function [parent=#Text] SetSelected
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetVisible
--
-- @function [parent=#Text] SetVisible
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetFocusMode
--
-- @function [parent=#Text] SetFocusMode
-- @param self Self reference
-- @param FocusMode#FocusMode mode mode

---
-- Function SetDragDropMode
--
-- @function [parent=#Text] SetDragDropMode
-- @param self Self reference
-- @param #number mode mode

---
-- Function SetStyle
--
-- @function [parent=#Text] SetStyle
-- @param self Self reference
-- @param #string styleName styleName
-- @param XMLFile#XMLFile file file
-- @return #boolean

---
-- Function SetStyle
--
-- @function [parent=#Text] SetStyle
-- @param self Self reference
-- @param XMLElement#XMLElement element element
-- @return #boolean

---
-- Function SetStyleAuto
--
-- @function [parent=#Text] SetStyleAuto
-- @param self Self reference
-- @param XMLFile#XMLFile file file
-- @return #boolean

---
-- Function SetDefaultStyle
--
-- @function [parent=#Text] SetDefaultStyle
-- @param self Self reference
-- @param XMLFile#XMLFile style style

---
-- Function SetLayout
--
-- @function [parent=#Text] SetLayout
-- @param self Self reference
-- @param LayoutMode#LayoutMode mode mode
-- @param #number spacing spacing

---
-- Function SetLayout
--
-- @function [parent=#Text] SetLayout
-- @param self Self reference
-- @param LayoutMode#LayoutMode mode mode
-- @param #number spacing spacing
-- @param IntRect#IntRect border border

---
-- Function SetLayoutMode
--
-- @function [parent=#Text] SetLayoutMode
-- @param self Self reference
-- @param LayoutMode#LayoutMode mode mode

---
-- Function SetLayoutSpacing
--
-- @function [parent=#Text] SetLayoutSpacing
-- @param self Self reference
-- @param #number spacing spacing

---
-- Function SetLayoutBorder
--
-- @function [parent=#Text] SetLayoutBorder
-- @param self Self reference
-- @param IntRect#IntRect border border

---
-- Function SetIndent
--
-- @function [parent=#Text] SetIndent
-- @param self Self reference
-- @param #number indent indent

---
-- Function SetIndentSpacing
--
-- @function [parent=#Text] SetIndentSpacing
-- @param self Self reference
-- @param #number indentSpacing indentSpacing

---
-- Function UpdateLayout
--
-- @function [parent=#Text] UpdateLayout
-- @param self Self reference

---
-- Function DisableLayoutUpdate
--
-- @function [parent=#Text] DisableLayoutUpdate
-- @param self Self reference

---
-- Function EnableLayoutUpdate
--
-- @function [parent=#Text] EnableLayoutUpdate
-- @param self Self reference

---
-- Function BringToFront
--
-- @function [parent=#Text] BringToFront
-- @param self Self reference

---
-- Function CreateChild
--
-- @function [parent=#Text] CreateChild
-- @param self Self reference
-- @param #string type type
-- @param #string name name
-- @param #number index index
-- @return UIElement#UIElement

---
-- Function AddChild
--
-- @function [parent=#Text] AddChild
-- @param self Self reference
-- @param UIElement#UIElement element element

---
-- Function InsertChild
--
-- @function [parent=#Text] InsertChild
-- @param self Self reference
-- @param #number index index
-- @param UIElement#UIElement element element

---
-- Function RemoveChild
--
-- @function [parent=#Text] RemoveChild
-- @param self Self reference
-- @param UIElement#UIElement element element
-- @param #number index index

---
-- Function RemoveChildAtIndex
--
-- @function [parent=#Text] RemoveChildAtIndex
-- @param self Self reference
-- @param #number index index

---
-- Function RemoveAllChildren
--
-- @function [parent=#Text] RemoveAllChildren
-- @param self Self reference

---
-- Function Remove
--
-- @function [parent=#Text] Remove
-- @param self Self reference

---
-- Function FindChild
--
-- @function [parent=#Text] FindChild
-- @param self Self reference
-- @param UIElement#UIElement element element
-- @return #number

---
-- Function SetParent
--
-- @function [parent=#Text] SetParent
-- @param self Self reference
-- @param UIElement#UIElement parent parent
-- @param #number index index

---
-- Function SetVar
--
-- @function [parent=#Text] SetVar
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash key key
-- @param Variant#Variant value value

---
-- Function SetInternal
--
-- @function [parent=#Text] SetInternal
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetTraversalMode
--
-- @function [parent=#Text] SetTraversalMode
-- @param self Self reference
-- @param TraversalMode#TraversalMode traversalMode traversalMode

---
-- Function SetElementEventSender
--
-- @function [parent=#Text] SetElementEventSender
-- @param self Self reference
-- @param #boolean flag flag

---
-- Function GetName
--
-- @function [parent=#Text] GetName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetPosition
--
-- @function [parent=#Text] GetPosition
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetSize
--
-- @function [parent=#Text] GetSize
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetWidth
--
-- @function [parent=#Text] GetWidth
-- @param self Self reference
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#Text] GetHeight
-- @param self Self reference
-- @return #number

---
-- Function GetMinSize
--
-- @function [parent=#Text] GetMinSize
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetMinWidth
--
-- @function [parent=#Text] GetMinWidth
-- @param self Self reference
-- @return #number

---
-- Function GetMinHeight
--
-- @function [parent=#Text] GetMinHeight
-- @param self Self reference
-- @return #number

---
-- Function GetMaxSize
--
-- @function [parent=#Text] GetMaxSize
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetMaxWidth
--
-- @function [parent=#Text] GetMaxWidth
-- @param self Self reference
-- @return #number

---
-- Function GetMaxHeight
--
-- @function [parent=#Text] GetMaxHeight
-- @param self Self reference
-- @return #number

---
-- Function IsFixedSize
--
-- @function [parent=#Text] IsFixedSize
-- @param self Self reference
-- @return #boolean

---
-- Function IsFixedWidth
--
-- @function [parent=#Text] IsFixedWidth
-- @param self Self reference
-- @return #boolean

---
-- Function IsFixedHeight
--
-- @function [parent=#Text] IsFixedHeight
-- @param self Self reference
-- @return #boolean

---
-- Function GetChildOffset
--
-- @function [parent=#Text] GetChildOffset
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetHorizontalAlignment
--
-- @function [parent=#Text] GetHorizontalAlignment
-- @param self Self reference
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetVerticalAlignment
--
-- @function [parent=#Text] GetVerticalAlignment
-- @param self Self reference
-- @return VerticalAlignment#VerticalAlignment

---
-- Function GetClipBorder
--
-- @function [parent=#Text] GetClipBorder
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetColor
--
-- @function [parent=#Text] GetColor
-- @param self Self reference
-- @param Corner#Corner corner corner
-- @return const Color#const Color

---
-- Function GetPriority
--
-- @function [parent=#Text] GetPriority
-- @param self Self reference
-- @return #number

---
-- Function GetOpacity
--
-- @function [parent=#Text] GetOpacity
-- @param self Self reference
-- @return #number

---
-- Function GetDerivedOpacity
--
-- @function [parent=#Text] GetDerivedOpacity
-- @param self Self reference
-- @return #number

---
-- Function GetBringToFront
--
-- @function [parent=#Text] GetBringToFront
-- @param self Self reference
-- @return #boolean

---
-- Function GetBringToBack
--
-- @function [parent=#Text] GetBringToBack
-- @param self Self reference
-- @return #boolean

---
-- Function GetClipChildren
--
-- @function [parent=#Text] GetClipChildren
-- @param self Self reference
-- @return #boolean

---
-- Function GetSortChildren
--
-- @function [parent=#Text] GetSortChildren
-- @param self Self reference
-- @return #boolean

---
-- Function GetUseDerivedOpacity
--
-- @function [parent=#Text] GetUseDerivedOpacity
-- @param self Self reference
-- @return #boolean

---
-- Function HasFocus
--
-- @function [parent=#Text] HasFocus
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabled
--
-- @function [parent=#Text] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEditable
--
-- @function [parent=#Text] IsEditable
-- @param self Self reference
-- @return #boolean

---
-- Function IsSelected
--
-- @function [parent=#Text] IsSelected
-- @param self Self reference
-- @return #boolean

---
-- Function IsVisible
--
-- @function [parent=#Text] IsVisible
-- @param self Self reference
-- @return #boolean

---
-- Function IsHovering
--
-- @function [parent=#Text] IsHovering
-- @param self Self reference
-- @return #boolean

---
-- Function IsInternal
--
-- @function [parent=#Text] IsInternal
-- @param self Self reference
-- @return #boolean

---
-- Function HasColorGradient
--
-- @function [parent=#Text] HasColorGradient
-- @param self Self reference
-- @return #boolean

---
-- Function GetFocusMode
--
-- @function [parent=#Text] GetFocusMode
-- @param self Self reference
-- @return FocusMode#FocusMode

---
-- Function GetDragDropMode
--
-- @function [parent=#Text] GetDragDropMode
-- @param self Self reference
-- @return #number

---
-- Function GetAppliedStyle
--
-- @function [parent=#Text] GetAppliedStyle
-- @param self Self reference
-- @return const String#const String

---
-- Function GetDefaultStyle
--
-- @function [parent=#Text] GetDefaultStyle
-- @param self Self reference
-- @param #boolean recursiveUp recursiveUp
-- @return XMLFile#XMLFile

---
-- Function GetLayoutMode
--
-- @function [parent=#Text] GetLayoutMode
-- @param self Self reference
-- @return LayoutMode#LayoutMode

---
-- Function GetLayoutSpacing
--
-- @function [parent=#Text] GetLayoutSpacing
-- @param self Self reference
-- @return #number

---
-- Function GetLayoutBorder
--
-- @function [parent=#Text] GetLayoutBorder
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetNumChildren
--
-- @function [parent=#Text] GetNumChildren
-- @param self Self reference
-- @param #boolean recursive recursive
-- @return #number

---
-- Function GetChild
--
-- @function [parent=#Text] GetChild
-- @param self Self reference
-- @param #string name name
-- @param #boolean recursive recursive
-- @return UIElement#UIElement

---
-- Function GetChild
--
-- @function [parent=#Text] GetChild
-- @param self Self reference
-- @param #number index index
-- @return UIElement#UIElement

---
-- Function GetParent
--
-- @function [parent=#Text] GetParent
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetRoot
--
-- @function [parent=#Text] GetRoot
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetDerivedColor
--
-- @function [parent=#Text] GetDerivedColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetVar
--
-- @function [parent=#Text] GetVar
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash key key
-- @return const Variant#const Variant

---
-- Function GetVars
--
-- @function [parent=#Text] GetVars
-- @param self Self reference
-- @return const VariantMap#const VariantMap

---
-- Function ScreenToElement
--
-- @function [parent=#Text] ScreenToElement
-- @param self Self reference
-- @param IntVector2#IntVector2 screenPosition screenPosition
-- @return IntVector2#IntVector2

---
-- Function ElementToScreen
--
-- @function [parent=#Text] ElementToScreen
-- @param self Self reference
-- @param IntVector2#IntVector2 position position
-- @return IntVector2#IntVector2

---
-- Function IsInside
--
-- @function [parent=#Text] IsInside
-- @param self Self reference
-- @param IntVector2#IntVector2 position position
-- @param #boolean isScreen isScreen
-- @return #boolean

---
-- Function IsInsideCombined
--
-- @function [parent=#Text] IsInsideCombined
-- @param self Self reference
-- @param IntVector2#IntVector2 position position
-- @param #boolean isScreen isScreen
-- @return #boolean

---
-- Function GetCombinedScreenRect
--
-- @function [parent=#Text] GetCombinedScreenRect
-- @param self Self reference
-- @return IntRect#IntRect

---
-- Function SortChildren
--
-- @function [parent=#Text] SortChildren
-- @param self Self reference

---
-- Function GetLayoutMinSize
--
-- @function [parent=#Text] GetLayoutMinSize
-- @param self Self reference
-- @return #number

---
-- Function GetIndent
--
-- @function [parent=#Text] GetIndent
-- @param self Self reference
-- @return #number

---
-- Function GetIndentSpacing
--
-- @function [parent=#Text] GetIndentSpacing
-- @param self Self reference
-- @return #number

---
-- Function GetIndentWidth
--
-- @function [parent=#Text] GetIndentWidth
-- @param self Self reference
-- @return #number

---
-- Function SetChildOffset
--
-- @function [parent=#Text] SetChildOffset
-- @param self Self reference
-- @param IntVector2#IntVector2 offset offset

---
-- Function SetHovering
--
-- @function [parent=#Text] SetHovering
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function GetColor
--
-- @function [parent=#Text] GetColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetTraversalMode
--
-- @function [parent=#Text] GetTraversalMode
-- @param self Self reference
-- @return TraversalMode#TraversalMode

---
-- Function IsElementEventSender
--
-- @function [parent=#Text] IsElementEventSender
-- @param self Self reference
-- @return #boolean

---
-- Function GetElementEventSender
--
-- @function [parent=#Text] GetElementEventSender
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Field screenPosition (Read only)
--
-- @field [parent=#Text] IntVector2#IntVector2 screenPosition

---
-- Field name
--
-- @field [parent=#Text] #string name

---
-- Field position
--
-- @field [parent=#Text] IntVector2#IntVector2 position

---
-- Field size
--
-- @field [parent=#Text] IntVector2#IntVector2 size

---
-- Field width
--
-- @field [parent=#Text] #number width

---
-- Field height
--
-- @field [parent=#Text] #number height

---
-- Field minSize
--
-- @field [parent=#Text] IntVector2#IntVector2 minSize

---
-- Field minWidth
--
-- @field [parent=#Text] #number minWidth

---
-- Field minHeight
--
-- @field [parent=#Text] #number minHeight

---
-- Field maxSize
--
-- @field [parent=#Text] IntVector2#IntVector2 maxSize

---
-- Field maxWidth
--
-- @field [parent=#Text] #number maxWidth

---
-- Field maxHeight
--
-- @field [parent=#Text] #number maxHeight

---
-- Field fixedSize (Read only)
--
-- @field [parent=#Text] #boolean fixedSize

---
-- Field fixedWidth (Read only)
--
-- @field [parent=#Text] #boolean fixedWidth

---
-- Field fixedHeight (Read only)
--
-- @field [parent=#Text] #boolean fixedHeight

---
-- Field childOffset
--
-- @field [parent=#Text] IntVector2#IntVector2 childOffset

---
-- Field horizontalAlignment
--
-- @field [parent=#Text] HorizontalAlignment#HorizontalAlignment horizontalAlignment

---
-- Field verticalAlignment
--
-- @field [parent=#Text] VerticalAlignment#VerticalAlignment verticalAlignment

---
-- Field clipBorder
--
-- @field [parent=#Text] IntRect#IntRect clipBorder

---
-- Field color
--
-- @field [parent=#Text] Color#Color color

---
-- Field priority
--
-- @field [parent=#Text] #number priority

---
-- Field opacity
--
-- @field [parent=#Text] #number opacity

---
-- Field derivedOpacity (Read only)
--
-- @field [parent=#Text] #number derivedOpacity

---
-- Field bringToFront
--
-- @field [parent=#Text] #boolean bringToFront

---
-- Field bringToBack
--
-- @field [parent=#Text] #boolean bringToBack

---
-- Field clipChildren
--
-- @field [parent=#Text] #boolean clipChildren

---
-- Field sortChildren
--
-- @field [parent=#Text] #boolean sortChildren

---
-- Field useDerivedOpacity
--
-- @field [parent=#Text] #boolean useDerivedOpacity

---
-- Field focus
--
-- @field [parent=#Text] #boolean focus

---
-- Field enabled
--
-- @field [parent=#Text] #boolean enabled

---
-- Field editable
--
-- @field [parent=#Text] #boolean editable

---
-- Field selected
--
-- @field [parent=#Text] #boolean selected

---
-- Field visible
--
-- @field [parent=#Text] #boolean visible

---
-- Field hovering
--
-- @field [parent=#Text] #boolean hovering

---
-- Field internal
--
-- @field [parent=#Text] #boolean internal

---
-- Field colorGradient (Read only)
--
-- @field [parent=#Text] #boolean colorGradient

---
-- Field focusMode
--
-- @field [parent=#Text] FocusMode#FocusMode focusMode

---
-- Field dragDropMode
--
-- @field [parent=#Text] #number dragDropMode

---
-- Field style
--
-- @field [parent=#Text] #string style

---
-- Field defaultStyle
--
-- @field [parent=#Text] XMLFile#XMLFile defaultStyle

---
-- Field layoutMode
--
-- @field [parent=#Text] LayoutMode#LayoutMode layoutMode

---
-- Field layoutSpacing
--
-- @field [parent=#Text] #number layoutSpacing

---
-- Field layoutBorder
--
-- @field [parent=#Text] IntRect#IntRect layoutBorder

---
-- Field numChildren (Read only)
--
-- @field [parent=#Text] #number numChildren

---
-- Field parent
--
-- @field [parent=#Text] UIElement#UIElement parent

---
-- Field root (Read only)
--
-- @field [parent=#Text] UIElement#UIElement root

---
-- Field derivedColor (Read only)
--
-- @field [parent=#Text] Color#Color derivedColor

---
-- Field combinedScreenRect (Read only)
--
-- @field [parent=#Text] IntRect#IntRect combinedScreenRect

---
-- Field layoutMinSize (Read only)
--
-- @field [parent=#Text] #number layoutMinSize

---
-- Field indent
--
-- @field [parent=#Text] #number indent

---
-- Field indentSpacing
--
-- @field [parent=#Text] #number indentSpacing

---
-- Field indentWidth (Read only)
--
-- @field [parent=#Text] #number indentWidth

---
-- Field traversalMode
--
-- @field [parent=#Text] TraversalMode#TraversalMode traversalMode

---
-- Field elementEventSender
--
-- @field [parent=#Text] #boolean elementEventSender

---
-- Function SetTemporary
--
-- @function [parent=#Text] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#Text] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Text] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Text] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Text] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Text] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Text] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Text] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#Text] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Text] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Text] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Text] #string category


return nil
