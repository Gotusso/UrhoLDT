---
-- Enumeration CollisionEventMode
--
-- @module CollisionEventMode

---
-- Enumeration value COLLISION_NEVER
--
-- @field [parent=#CollisionEventMode] #number COLLISION_NEVER

---
-- Enumeration value COLLISION_ACTIVE
--
-- @field [parent=#CollisionEventMode] #number COLLISION_ACTIVE

---
-- Enumeration value COLLISION_ALWAYS
--
-- @field [parent=#CollisionEventMode] #number COLLISION_ALWAYS


return nil
