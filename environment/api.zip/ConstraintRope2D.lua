---
-- Module ConstraintRope2D
-- Module ConstraintRope2D extends Constraint2D
-- Generated on 2014-05-31
--
-- @module ConstraintRope2D

---
-- Function SetOwnerBodyAnchor()
-- Set owner body anchor.
--
-- @function [parent=#ConstraintRope2D] SetOwnerBodyAnchor
-- @param self Self reference
-- @param Vector2#Vector2 anchor anchor

---
-- Function SetOtherBodyAnchor()
-- Set other body anchor.
--
-- @function [parent=#ConstraintRope2D] SetOtherBodyAnchor
-- @param self Self reference
-- @param Vector2#Vector2 anchor anchor

---
-- Function SetMaxLength()
-- Set max length.
--
-- @function [parent=#ConstraintRope2D] SetMaxLength
-- @param self Self reference
-- @param #number maxLength maxLength

---
-- Function GetOwnerBodyAnchor()
-- Return owner body anchor.
--
-- @function [parent=#ConstraintRope2D] GetOwnerBodyAnchor
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Function GetOtherBodyAnchor()
-- Return other body anchor.
--
-- @function [parent=#ConstraintRope2D] GetOtherBodyAnchor
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Function GetMaxLength()
-- Return max length.
--
-- @function [parent=#ConstraintRope2D] GetMaxLength
-- @param self Self reference
-- @return #number

---
-- Field ownerBodyAnchor
--
-- @field [parent=#ConstraintRope2D] Vector2#Vector2 ownerBodyAnchor

---
-- Field otherBodyAnchor
--
-- @field [parent=#ConstraintRope2D] Vector2#Vector2 otherBodyAnchor

---
-- Field maxLength
--
-- @field [parent=#ConstraintRope2D] #number maxLength


return nil
