---
-- Module Controls
--
-- @module Controls

---
-- Function Controls
--
-- @function [parent=#Controls] Controls

---
-- Function new
--
-- @function [parent=#Controls] new
-- @return Controls#Controls

---
-- Function delete
--
-- @function [parent=#Controls] delete

---
-- Function Reset
--
-- @function [parent=#Controls] Reset

---
-- Function Set
--
-- @function [parent=#Controls] Set
-- @param #number buttonsbuttons
-- @param #boolean downdown

---
-- Function IsDown
--
-- @function [parent=#Controls] IsDown
-- @param #number buttonbutton
-- @return #boolean

---
-- Function IsPressed
--
-- @function [parent=#Controls] IsPressed
-- @param #number buttonbutton
-- @param Controls#Controls previousControlspreviousControls
-- @return #boolean

---
-- Field buttons
--
-- @field [parent=#Controls] #number buttons

---
-- Field yaw
--
-- @field [parent=#Controls] #number yaw

---
-- Field pitch
--
-- @field [parent=#Controls] #number pitch

---
-- Field extraData
--
-- @field [parent=#Controls] VariantMap#VariantMap extraData


return nil
