---
-- Module Controls
-- Generated on 2014-05-31
--
-- @module Controls

---
-- Function Controls()
-- Construct.
--
-- @function [parent=#Controls] Controls
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#Controls] new
-- @param self Self reference
-- @return Controls#Controls

---
-- Function delete()
--
-- @function [parent=#Controls] delete
-- @param self Self reference

---
-- Function Reset()
-- Reset to initial state.
--
-- @function [parent=#Controls] Reset
-- @param self Self reference

---
-- Function Set()
-- Set or release buttons.
--
-- @function [parent=#Controls] Set
-- @param self Self reference
-- @param #number buttons buttons
-- @param #boolean down down

---
-- Function IsDown()
--
-- @function [parent=#Controls] IsDown
-- @param self Self reference
-- @param #number button button
-- @return #boolean

---
-- Function IsPressed()
--
-- @function [parent=#Controls] IsPressed
-- @param self Self reference
-- @param #number button button
-- @param Controls#Controls previousControls previousControls
-- @return #boolean

---
-- Field buttons
--
-- @field [parent=#Controls] #number buttons

---
-- Field yaw
--
-- @field [parent=#Controls] #number yaw

---
-- Field pitch
--
-- @field [parent=#Controls] #number pitch

---
-- Field extraData
--
-- @field [parent=#Controls] VariantMap#VariantMap extraData


return nil
