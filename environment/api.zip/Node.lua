---
-- Module Node
-- Module Node extends Serializable
-- Generated on 2014-03-13
--
-- @module Node

---
-- Function Node
--
-- @function [parent=#Node] Node
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#Node] new
-- @param self Self reference
-- @return Node#Node

---
-- Function delete
--
-- @function [parent=#Node] delete
-- @param self Self reference

---
-- Function SaveXML
--
-- @function [parent=#Node] SaveXML
-- @param self Self reference
-- @param File#File dest dest
-- @return #boolean

---
-- Function SetName
--
-- @function [parent=#Node] SetName
-- @param self Self reference
-- @param #string name name

---
-- Function SetPosition
--
-- @function [parent=#Node] SetPosition
-- @param self Self reference
-- @param Vector3#Vector3 position position

---
-- Function SetPositionXYZ
--
-- @function [parent=#Node] SetPositionXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function SetRotation
--
-- @function [parent=#Node] SetRotation
-- @param self Self reference
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetRotationXYZ
--
-- @function [parent=#Node] SetRotationXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function SetDirection
--
-- @function [parent=#Node] SetDirection
-- @param self Self reference
-- @param Vector3#Vector3 direction direction

---
-- Function SetDirectionXYZ
--
-- @function [parent=#Node] SetDirectionXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function SetScale
--
-- @function [parent=#Node] SetScale
-- @param self Self reference
-- @param #number scale scale

---
-- Function SetScale
--
-- @function [parent=#Node] SetScale
-- @param self Self reference
-- @param Vector3#Vector3 scale scale

---
-- Function SetScaleXYZ
--
-- @function [parent=#Node] SetScaleXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function SetTransform
--
-- @function [parent=#Node] SetTransform
-- @param self Self reference
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetTransform
--
-- @function [parent=#Node] SetTransform
-- @param self Self reference
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation
-- @param #number scale scale

---
-- Function SetTransform
--
-- @function [parent=#Node] SetTransform
-- @param self Self reference
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation
-- @param Vector3#Vector3 scale scale

---
-- Function SetWorldPosition
--
-- @function [parent=#Node] SetWorldPosition
-- @param self Self reference
-- @param Vector3#Vector3 position position

---
-- Function SetWorldPositionXYZ
--
-- @function [parent=#Node] SetWorldPositionXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function SetWorldRotation
--
-- @function [parent=#Node] SetWorldRotation
-- @param self Self reference
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetWorldRotationXYZ
--
-- @function [parent=#Node] SetWorldRotationXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function SetWorldDirection
--
-- @function [parent=#Node] SetWorldDirection
-- @param self Self reference
-- @param Vector3#Vector3 direction direction

---
-- Function SetWorldDirectionXYZ
--
-- @function [parent=#Node] SetWorldDirectionXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function SetWorldScale
--
-- @function [parent=#Node] SetWorldScale
-- @param self Self reference
-- @param #number scale scale

---
-- Function SetWorldScale
--
-- @function [parent=#Node] SetWorldScale
-- @param self Self reference
-- @param Vector3#Vector3 scale scale

---
-- Function SetWorldScaleXYZ
--
-- @function [parent=#Node] SetWorldScaleXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function SetWorldTransform
--
-- @function [parent=#Node] SetWorldTransform
-- @param self Self reference
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetWorldTransform
--
-- @function [parent=#Node] SetWorldTransform
-- @param self Self reference
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation
-- @param #number scale scale

---
-- Function SetWorldTransform
--
-- @function [parent=#Node] SetWorldTransform
-- @param self Self reference
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation
-- @param Vector3#Vector3 scale scale

---
-- Function Translate
--
-- @function [parent=#Node] Translate
-- @param self Self reference
-- @param Vector3#Vector3 delta delta

---
-- Function TranslateXYZ
--
-- @function [parent=#Node] TranslateXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function TranslateRelative
--
-- @function [parent=#Node] TranslateRelative
-- @param self Self reference
-- @param Vector3#Vector3 delta delta

---
-- Function TranslateRelativeXYZ
--
-- @function [parent=#Node] TranslateRelativeXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function Rotate
--
-- @function [parent=#Node] Rotate
-- @param self Self reference
-- @param Quaternion#Quaternion delta delta
-- @param #boolean fixedAxis fixedAxis

---
-- Function RotateXYZ
--
-- @function [parent=#Node] RotateXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z
-- @param #boolean fixedAxis fixedAxis

---
-- Function Pitch
--
-- @function [parent=#Node] Pitch
-- @param self Self reference
-- @param #number angle angle
-- @param #boolean fixedAxis fixedAxis

---
-- Function Yaw
--
-- @function [parent=#Node] Yaw
-- @param self Self reference
-- @param #number angle angle
-- @param #boolean fixedAxis fixedAxis

---
-- Function Roll
--
-- @function [parent=#Node] Roll
-- @param self Self reference
-- @param #number angle angle
-- @param #boolean fixedAxis fixedAxis

---
-- Function LookAt
--
-- @function [parent=#Node] LookAt
-- @param self Self reference
-- @param Vector3#Vector3 target target

---
-- Function LookAt
--
-- @function [parent=#Node] LookAt
-- @param self Self reference
-- @param Vector3#Vector3 target target
-- @param Vector3#Vector3 upAxis upAxis

---
-- Function LookAtXYZ
--
-- @function [parent=#Node] LookAtXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z
-- @param #number upX upX
-- @param #number upY upY
-- @param #number upZ upZ

---
-- Function Scale
--
-- @function [parent=#Node] Scale
-- @param self Self reference
-- @param #number scale scale

---
-- Function Scale
--
-- @function [parent=#Node] Scale
-- @param self Self reference
-- @param Vector3#Vector3 scale scale

---
-- Function ScaleXYZ
--
-- @function [parent=#Node] ScaleXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function SetEnabled
--
-- @function [parent=#Node] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetEnabled
--
-- @function [parent=#Node] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable
-- @param #boolean recursive recursive

---
-- Function SetOwner
--
-- @function [parent=#Node] SetOwner
-- @param self Self reference
-- @param Connection#Connection owner owner

---
-- Function MarkDirty
--
-- @function [parent=#Node] MarkDirty
-- @param self Self reference

---
-- Function CreateChild
--
-- @function [parent=#Node] CreateChild
-- @param self Self reference
-- @param #string name name
-- @param CreateMode#CreateMode mode mode
-- @param #number id id
-- @return Node#Node

---
-- Function AddChild
--
-- @function [parent=#Node] AddChild
-- @param self Self reference
-- @param Node#Node node node

---
-- Function RemoveChild
--
-- @function [parent=#Node] RemoveChild
-- @param self Self reference
-- @param Node#Node node node

---
-- Function RemoveAllChildren
--
-- @function [parent=#Node] RemoveAllChildren
-- @param self Self reference

---
-- Function RemoveChildren
--
-- @function [parent=#Node] RemoveChildren
-- @param self Self reference
-- @param #boolean removeReplicated removeReplicated
-- @param #boolean removeLocal removeLocal
-- @param #boolean recursive recursive

---
-- Function RemoveComponent
--
-- @function [parent=#Node] RemoveComponent
-- @param self Self reference
-- @param Component#Component component component

---
-- Function RemoveComponent
--
-- @function [parent=#Node] RemoveComponent
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type

---
-- Function RemoveComponent
--
-- @function [parent=#Node] RemoveComponent
-- @param self Self reference
-- @param #string type type

---
-- Function RemoveAllComponents
--
-- @function [parent=#Node] RemoveAllComponents
-- @param self Self reference

---
-- Function RemoveComponents
--
-- @function [parent=#Node] RemoveComponents
-- @param self Self reference
-- @param #boolean removeReplicated removeReplicated
-- @param #boolean removeLocal removeLocal

---
-- Function Clone
--
-- @function [parent=#Node] Clone
-- @param self Self reference
-- @param CreateMode#CreateMode mode mode
-- @return Node#Node

---
-- Function Remove
--
-- @function [parent=#Node] Remove
-- @param self Self reference

---
-- Function SetParent
--
-- @function [parent=#Node] SetParent
-- @param self Self reference
-- @param Node#Node parent parent

---
-- Function SetVar
--
-- @function [parent=#Node] SetVar
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash key key
-- @param Variant#Variant value value

---
-- Function AddListener
--
-- @function [parent=#Node] AddListener
-- @param self Self reference
-- @param Component#Component component component

---
-- Function RemoveListener
--
-- @function [parent=#Node] RemoveListener
-- @param self Self reference
-- @param Component#Component component component

---
-- Function CreateComponent
--
-- @function [parent=#Node] CreateComponent
-- @param self Self reference
-- @param #string type type
-- @param CreateMode#CreateMode mode mode
-- @param #number id id
-- @return Component#Component

---
-- Function CreateScriptObject
--
-- @function [parent=#Node] CreateScriptObject
-- @param self Self reference
-- @param #string scriptObjectType scriptObjectType
-- @return #number

---
-- Function CreateScriptObject
--
-- @function [parent=#Node] CreateScriptObject
-- @param self Self reference
-- @param #string fileName fileName
-- @param #string scriptObjectType scriptObjectType
-- @return #number

---
-- Function GetScriptObject
--
-- @function [parent=#Node] GetScriptObject
-- @param self Self reference
-- @return #number

---
-- Function GetScriptObject
--
-- @function [parent=#Node] GetScriptObject
-- @param self Self reference
-- @param #string scriptObjectType scriptObjectType
-- @return #number

---
-- Function GetID
--
-- @function [parent=#Node] GetID
-- @param self Self reference
-- @return #number

---
-- Function GetName
--
-- @function [parent=#Node] GetName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetNameHash
--
-- @function [parent=#Node] GetNameHash
-- @param self Self reference
-- @return StringHash#StringHash

---
-- Function GetParent
--
-- @function [parent=#Node] GetParent
-- @param self Self reference
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#Node] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#Node] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function GetOwner
--
-- @function [parent=#Node] GetOwner
-- @param self Self reference
-- @return Connection#Connection

---
-- Function GetPosition
--
-- @function [parent=#Node] GetPosition
-- @param self Self reference
-- @return const Vector3#const Vector3

---
-- Function GetPositionXYZ
--
-- @function [parent=#Node] GetPositionXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function GetRotation
--
-- @function [parent=#Node] GetRotation
-- @param self Self reference
-- @return const Quaternion#const Quaternion

---
-- Function GetRotationXYZ
--
-- @function [parent=#Node] GetRotationXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function GetRotationWXYZ
--
-- @function [parent=#Node] GetRotationWXYZ
-- @param self Self reference
-- @param #number w w
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function GetDirection
--
-- @function [parent=#Node] GetDirection
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetDirectionXYZ
--
-- @function [parent=#Node] GetDirectionXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function GetUp
--
-- @function [parent=#Node] GetUp
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetUpXYZ
--
-- @function [parent=#Node] GetUpXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function GetRight
--
-- @function [parent=#Node] GetRight
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetRightXYZ
--
-- @function [parent=#Node] GetRightXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function GetScale
--
-- @function [parent=#Node] GetScale
-- @param self Self reference
-- @return const Vector3#const Vector3

---
-- Function GetScaleXYZ
--
-- @function [parent=#Node] GetScaleXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function GetTransform
--
-- @function [parent=#Node] GetTransform
-- @param self Self reference
-- @return Matrix3x4#Matrix3x4

---
-- Function GetWorldPosition
--
-- @function [parent=#Node] GetWorldPosition
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetWorldPositionXYZ
--
-- @function [parent=#Node] GetWorldPositionXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function GetWorldRotation
--
-- @function [parent=#Node] GetWorldRotation
-- @param self Self reference
-- @return Quaternion#Quaternion

---
-- Function GetWorldRotationXYZ
--
-- @function [parent=#Node] GetWorldRotationXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function GetWorldRotationWXYZ
--
-- @function [parent=#Node] GetWorldRotationWXYZ
-- @param self Self reference
-- @param #number w w
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function GetWorldDirection
--
-- @function [parent=#Node] GetWorldDirection
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetWorldDirectionXYZ
--
-- @function [parent=#Node] GetWorldDirectionXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function GetWorldUp
--
-- @function [parent=#Node] GetWorldUp
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetWorldUpXYZ
--
-- @function [parent=#Node] GetWorldUpXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function GetWorldRight
--
-- @function [parent=#Node] GetWorldRight
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetWorldRightXYZ
--
-- @function [parent=#Node] GetWorldRightXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function GetWorldScale
--
-- @function [parent=#Node] GetWorldScale
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetWorldScaleXYZ
--
-- @function [parent=#Node] GetWorldScaleXYZ
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function GetWorldTransform
--
-- @function [parent=#Node] GetWorldTransform
-- @param self Self reference
-- @return const Matrix3x4#const Matrix3x4

---
-- Function LocalToWorld
--
-- @function [parent=#Node] LocalToWorld
-- @param self Self reference
-- @param Vector3#Vector3 position position
-- @return Vector3#Vector3

---
-- Function LocalToWorld
--
-- @function [parent=#Node] LocalToWorld
-- @param self Self reference
-- @param Vector4#Vector4 vector vector
-- @return Vector3#Vector3

---
-- Function WorldToLocal
--
-- @function [parent=#Node] WorldToLocal
-- @param self Self reference
-- @param Vector3#Vector3 position position
-- @return Vector3#Vector3

---
-- Function WorldToLocal
--
-- @function [parent=#Node] WorldToLocal
-- @param self Self reference
-- @param Vector4#Vector4 vector vector
-- @return Vector3#Vector3

---
-- Function IsDirty
--
-- @function [parent=#Node] IsDirty
-- @param self Self reference
-- @return #boolean

---
-- Function GetNumChildren
--
-- @function [parent=#Node] GetNumChildren
-- @param self Self reference
-- @param #boolean recursive recursive
-- @return #number

---
-- Function GetChild
--
-- @function [parent=#Node] GetChild
-- @param self Self reference
-- @param #string name name
-- @param #boolean recursive recursive
-- @return Node#Node

---
-- Function GetChild
--
-- @function [parent=#Node] GetChild
-- @param self Self reference
-- @param StringHash#StringHash nameHash nameHash
-- @param #boolean recursive recursive
-- @return Node#Node

---
-- Function GetChild
--
-- @function [parent=#Node] GetChild
-- @param self Self reference
-- @param #number index index
-- @return Node#Node

---
-- Function GetNumComponents
--
-- @function [parent=#Node] GetNumComponents
-- @param self Self reference
-- @return #number

---
-- Function GetNumNetworkComponents
--
-- @function [parent=#Node] GetNumNetworkComponents
-- @param self Self reference
-- @return #number

---
-- Function HasComponent
--
-- @function [parent=#Node] HasComponent
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return #boolean

---
-- Function HasComponent
--
-- @function [parent=#Node] HasComponent
-- @param self Self reference
-- @param #string type type
-- @return #boolean

---
-- Function GetVar
--
-- @function [parent=#Node] GetVar
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash key key
-- @return const Variant#const Variant

---
-- Function GetVars
--
-- @function [parent=#Node] GetVars
-- @param self Self reference
-- @return const VariantMap#const VariantMap

---
-- Function GetComponent
--
-- @function [parent=#Node] GetComponent
-- @param self Self reference
-- @param #string type type
-- @return Component#Component

---
-- Function SetID
--
-- @function [parent=#Node] SetID
-- @param self Self reference
-- @param #number id id

---
-- Function SetScene
--
-- @function [parent=#Node] SetScene
-- @param self Self reference
-- @param Scene#Scene scene scene

---
-- Function ResetScene
--
-- @function [parent=#Node] ResetScene
-- @param self Self reference

---
-- Function Load
--
-- @function [parent=#Node] Load
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @param SceneResolver#SceneResolver resolver resolver
-- @param #boolean loadChildren loadChildren
-- @param #boolean rewriteIDs rewriteIDs
-- @param CreateMode#CreateMode mode mode
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#Node] LoadXML
-- @param self Self reference
-- @param XMLElement#XMLElement source source
-- @param SceneResolver#SceneResolver resolver resolver
-- @param #boolean loadChildren loadChildren
-- @param #boolean rewriteIDs rewriteIDs
-- @param CreateMode#CreateMode mode mode
-- @return #boolean

---
-- Function CreateChild
--
-- @function [parent=#Node] CreateChild
-- @param self Self reference
-- @param #number id id
-- @param CreateMode#CreateMode mode mode
-- @return Node#Node

---
-- Function AddComponent
--
-- @function [parent=#Node] AddComponent
-- @param self Self reference
-- @param Component#Component component component
-- @param #number id id
-- @param CreateMode#CreateMode mode mode

---
-- Field ID
--
-- @field [parent=#Node] #number ID

---
-- Field name
--
-- @field [parent=#Node] #string name

---
-- Field nameHash (Read only)
--
-- @field [parent=#Node] StringHash#StringHash nameHash

---
-- Field parent
--
-- @field [parent=#Node] Node#Node parent

---
-- Field scene
--
-- @field [parent=#Node] Scene#Scene scene

---
-- Field enabled
--
-- @field [parent=#Node] #boolean enabled

---
-- Field owner
--
-- @field [parent=#Node] Connection#Connection owner

---
-- Field position
--
-- @field [parent=#Node] Vector3#Vector3 position

---
-- Field rotation
--
-- @field [parent=#Node] Quaternion#Quaternion rotation

---
-- Field direction
--
-- @field [parent=#Node] Vector3#Vector3 direction

---
-- Field up (Read only)
--
-- @field [parent=#Node] Vector3#Vector3 up

---
-- Field right (Read only)
--
-- @field [parent=#Node] Vector3#Vector3 right

---
-- Field scale
--
-- @field [parent=#Node] Vector3#Vector3 scale

---
-- Field transform (Read only)
--
-- @field [parent=#Node] Matrix3x4#Matrix3x4 transform

---
-- Field worldPosition
--
-- @field [parent=#Node] Vector3#Vector3 worldPosition

---
-- Field worldRotation
--
-- @field [parent=#Node] Quaternion#Quaternion worldRotation

---
-- Field worldDirection
--
-- @field [parent=#Node] Vector3#Vector3 worldDirection

---
-- Field worldUp (Read only)
--
-- @field [parent=#Node] Vector3#Vector3 worldUp

---
-- Field worldRight (Read only)
--
-- @field [parent=#Node] Vector3#Vector3 worldRight

---
-- Field worldScale
--
-- @field [parent=#Node] Vector3#Vector3 worldScale

---
-- Field worldTransform (Read only)
--
-- @field [parent=#Node] Matrix3x4#Matrix3x4 worldTransform

---
-- Field dirty (Read only)
--
-- @field [parent=#Node] #boolean dirty

---
-- Field numComponents (Read only)
--
-- @field [parent=#Node] #number numComponents

---
-- Field numNetworkComponents (Read only)
--
-- @field [parent=#Node] #number numNetworkComponents

---
-- Function SetTemporary
--
-- @function [parent=#Node] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#Node] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Node] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Node] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Node] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Node] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Node] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Node] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#Node] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Node] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Node] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Node] #string category


return nil
