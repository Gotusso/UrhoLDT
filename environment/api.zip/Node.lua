---
-- Module Node
-- Extends Serializable
--
-- @module Node

---
-- Function Node
--
-- @function [parent=#Node] Node

---
-- Function new
--
-- @function [parent=#Node] new
-- @return Node#Node

---
-- Function delete
--
-- @function [parent=#Node] delete

---
-- Function SaveXML
--
-- @function [parent=#Node] SaveXML
-- @param File#File destdest
-- @return #boolean

---
-- Function SetName
--
-- @function [parent=#Node] SetName
-- @param #string namename

---
-- Function SetPosition
--
-- @function [parent=#Node] SetPosition
-- @param Vector3#Vector3 positionposition

---
-- Function SetPositionXYZ
--
-- @function [parent=#Node] SetPositionXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function SetRotation
--
-- @function [parent=#Node] SetRotation
-- @param Quaternion#Quaternion rotationrotation

---
-- Function SetRotationXYZ
--
-- @function [parent=#Node] SetRotationXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function SetDirection
--
-- @function [parent=#Node] SetDirection
-- @param Vector3#Vector3 directiondirection

---
-- Function SetDirectionXYZ
--
-- @function [parent=#Node] SetDirectionXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function SetScale
--
-- @function [parent=#Node] SetScale
-- @param #number scalescale

---
-- Function SetScale
--
-- @function [parent=#Node] SetScale
-- @param Vector3#Vector3 scalescale

---
-- Function SetScaleXYZ
--
-- @function [parent=#Node] SetScaleXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function SetTransform
--
-- @function [parent=#Node] SetTransform
-- @param Vector3#Vector3 positionposition
-- @param Quaternion#Quaternion rotationrotation

---
-- Function SetTransform
--
-- @function [parent=#Node] SetTransform
-- @param Vector3#Vector3 positionposition
-- @param Quaternion#Quaternion rotationrotation
-- @param #number scalescale

---
-- Function SetTransform
--
-- @function [parent=#Node] SetTransform
-- @param Vector3#Vector3 positionposition
-- @param Quaternion#Quaternion rotationrotation
-- @param Vector3#Vector3 scalescale

---
-- Function SetWorldPosition
--
-- @function [parent=#Node] SetWorldPosition
-- @param Vector3#Vector3 positionposition

---
-- Function SetWorldPositionXYZ
--
-- @function [parent=#Node] SetWorldPositionXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function SetWorldRotation
--
-- @function [parent=#Node] SetWorldRotation
-- @param Quaternion#Quaternion rotationrotation

---
-- Function SetWorldRotationXYZ
--
-- @function [parent=#Node] SetWorldRotationXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function SetWorldDirection
--
-- @function [parent=#Node] SetWorldDirection
-- @param Vector3#Vector3 directiondirection

---
-- Function SetWorldDirectionXYZ
--
-- @function [parent=#Node] SetWorldDirectionXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function SetWorldScale
--
-- @function [parent=#Node] SetWorldScale
-- @param #number scalescale

---
-- Function SetWorldScale
--
-- @function [parent=#Node] SetWorldScale
-- @param Vector3#Vector3 scalescale

---
-- Function SetWorldScaleXYZ
--
-- @function [parent=#Node] SetWorldScaleXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function SetWorldTransform
--
-- @function [parent=#Node] SetWorldTransform
-- @param Vector3#Vector3 positionposition
-- @param Quaternion#Quaternion rotationrotation

---
-- Function SetWorldTransform
--
-- @function [parent=#Node] SetWorldTransform
-- @param Vector3#Vector3 positionposition
-- @param Quaternion#Quaternion rotationrotation
-- @param #number scalescale

---
-- Function SetWorldTransform
--
-- @function [parent=#Node] SetWorldTransform
-- @param Vector3#Vector3 positionposition
-- @param Quaternion#Quaternion rotationrotation
-- @param Vector3#Vector3 scalescale

---
-- Function Translate
--
-- @function [parent=#Node] Translate
-- @param Vector3#Vector3 deltadelta

---
-- Function TranslateXYZ
--
-- @function [parent=#Node] TranslateXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function TranslateRelative
--
-- @function [parent=#Node] TranslateRelative
-- @param Vector3#Vector3 deltadelta

---
-- Function TranslateRelativeXYZ
--
-- @function [parent=#Node] TranslateRelativeXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function Rotate
--
-- @function [parent=#Node] Rotate
-- @param Quaternion#Quaternion deltadelta
-- @param #boolean fixedAxisfixedAxis

---
-- Function RotateXYZ
--
-- @function [parent=#Node] RotateXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz
-- @param #boolean fixedAxisfixedAxis

---
-- Function Pitch
--
-- @function [parent=#Node] Pitch
-- @param #number angleangle
-- @param #boolean fixedAxisfixedAxis

---
-- Function Yaw
--
-- @function [parent=#Node] Yaw
-- @param #number angleangle
-- @param #boolean fixedAxisfixedAxis

---
-- Function Roll
--
-- @function [parent=#Node] Roll
-- @param #number angleangle
-- @param #boolean fixedAxisfixedAxis

---
-- Function LookAt
--
-- @function [parent=#Node] LookAt
-- @param Vector3#Vector3 targettarget

---
-- Function LookAt
--
-- @function [parent=#Node] LookAt
-- @param Vector3#Vector3 targettarget
-- @param Vector3#Vector3 upAxisupAxis

---
-- Function LookAtXYZ
--
-- @function [parent=#Node] LookAtXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz
-- @param #number upXupX
-- @param #number upYupY
-- @param #number upZupZ

---
-- Function Scale
--
-- @function [parent=#Node] Scale
-- @param #number scalescale

---
-- Function Scale
--
-- @function [parent=#Node] Scale
-- @param Vector3#Vector3 scalescale

---
-- Function ScaleXYZ
--
-- @function [parent=#Node] ScaleXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function SetEnabled
--
-- @function [parent=#Node] SetEnabled
-- @param #boolean enableenable

---
-- Function SetEnabled
--
-- @function [parent=#Node] SetEnabled
-- @param #boolean enableenable
-- @param #boolean recursiverecursive

---
-- Function SetOwner
--
-- @function [parent=#Node] SetOwner
-- @param Connection#Connection ownerowner

---
-- Function MarkDirty
--
-- @function [parent=#Node] MarkDirty

---
-- Function CreateChild
--
-- @function [parent=#Node] CreateChild
-- @param #string namename
-- @param CreateMode#CreateMode modemode
-- @param #number idid
-- @return Node#Node

---
-- Function AddChild
--
-- @function [parent=#Node] AddChild
-- @param Node#Node nodenode

---
-- Function RemoveChild
--
-- @function [parent=#Node] RemoveChild
-- @param Node#Node nodenode

---
-- Function RemoveAllChildren
--
-- @function [parent=#Node] RemoveAllChildren

---
-- Function RemoveChildren
--
-- @function [parent=#Node] RemoveChildren
-- @param #boolean removeReplicatedremoveReplicated
-- @param #boolean removeLocalremoveLocal
-- @param #boolean recursiverecursive

---
-- Function RemoveComponent
--
-- @function [parent=#Node] RemoveComponent
-- @param Component#Component componentcomponent

---
-- Function RemoveComponent
--
-- @function [parent=#Node] RemoveComponent
-- @param ShortStringHash#ShortStringHash typetype

---
-- Function RemoveComponent
--
-- @function [parent=#Node] RemoveComponent
-- @param #string typetype

---
-- Function RemoveAllComponents
--
-- @function [parent=#Node] RemoveAllComponents

---
-- Function RemoveComponents
--
-- @function [parent=#Node] RemoveComponents
-- @param #boolean removeReplicatedremoveReplicated
-- @param #boolean removeLocalremoveLocal

---
-- Function Clone
--
-- @function [parent=#Node] Clone
-- @param CreateMode#CreateMode modemode
-- @return Node#Node

---
-- Function Remove
--
-- @function [parent=#Node] Remove

---
-- Function SetParent
--
-- @function [parent=#Node] SetParent
-- @param Node#Node parentparent

---
-- Function SetVar
--
-- @function [parent=#Node] SetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @param Variant#Variant valuevalue

---
-- Function AddListener
--
-- @function [parent=#Node] AddListener
-- @param Component#Component componentcomponent

---
-- Function RemoveListener
--
-- @function [parent=#Node] RemoveListener
-- @param Component#Component componentcomponent

---
-- Function CreateComponent
--
-- @function [parent=#Node] CreateComponent
-- @param #string typetype
-- @param CreateMode#CreateMode modemode
-- @param #number idid
-- @return Component#Component

---
-- Function CreateScriptObject
--
-- @function [parent=#Node] CreateScriptObject
-- @param #string scriptObjectTypescriptObjectType
-- @return #number

---
-- Function CreateScriptObject
--
-- @function [parent=#Node] CreateScriptObject
-- @param #string fileNamefileName
-- @param #string scriptObjectTypescriptObjectType
-- @return #number

---
-- Function GetScriptObject
--
-- @function [parent=#Node] GetScriptObject
-- @return #number

---
-- Function GetScriptObject
--
-- @function [parent=#Node] GetScriptObject
-- @param #string scriptObjectTypescriptObjectType
-- @return #number

---
-- Function GetID
--
-- @function [parent=#Node] GetID
-- @return #number

---
-- Function GetName
--
-- @function [parent=#Node] GetName
-- @return const String#const String

---
-- Function GetNameHash
--
-- @function [parent=#Node] GetNameHash
-- @return StringHash#StringHash

---
-- Function GetParent
--
-- @function [parent=#Node] GetParent
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#Node] GetScene
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#Node] IsEnabled
-- @return #boolean

---
-- Function GetOwner
--
-- @function [parent=#Node] GetOwner
-- @return Connection#Connection

---
-- Function GetPosition
--
-- @function [parent=#Node] GetPosition
-- @return const Vector3#const Vector3

---
-- Function GetPositionXYZ
--
-- @function [parent=#Node] GetPositionXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function GetRotation
--
-- @function [parent=#Node] GetRotation
-- @return const Quaternion#const Quaternion

---
-- Function GetRotationXYZ
--
-- @function [parent=#Node] GetRotationXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function GetRotationWXYZ
--
-- @function [parent=#Node] GetRotationWXYZ
-- @param #number ww
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function GetDirection
--
-- @function [parent=#Node] GetDirection
-- @return Vector3#Vector3

---
-- Function GetDirectionXYZ
--
-- @function [parent=#Node] GetDirectionXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function GetUp
--
-- @function [parent=#Node] GetUp
-- @return Vector3#Vector3

---
-- Function GetUpXYZ
--
-- @function [parent=#Node] GetUpXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function GetRight
--
-- @function [parent=#Node] GetRight
-- @return Vector3#Vector3

---
-- Function GetRightXYZ
--
-- @function [parent=#Node] GetRightXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function GetScale
--
-- @function [parent=#Node] GetScale
-- @return const Vector3#const Vector3

---
-- Function GetScaleXYZ
--
-- @function [parent=#Node] GetScaleXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function GetTransform
--
-- @function [parent=#Node] GetTransform
-- @return Matrix3x4#Matrix3x4

---
-- Function GetWorldPosition
--
-- @function [parent=#Node] GetWorldPosition
-- @return Vector3#Vector3

---
-- Function GetWorldPositionXYZ
--
-- @function [parent=#Node] GetWorldPositionXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function GetWorldRotation
--
-- @function [parent=#Node] GetWorldRotation
-- @return Quaternion#Quaternion

---
-- Function GetWorldRotationXYZ
--
-- @function [parent=#Node] GetWorldRotationXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function GetWorldRotationWXYZ
--
-- @function [parent=#Node] GetWorldRotationWXYZ
-- @param #number ww
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function GetWorldDirection
--
-- @function [parent=#Node] GetWorldDirection
-- @return Vector3#Vector3

---
-- Function GetWorldDirectionXYZ
--
-- @function [parent=#Node] GetWorldDirectionXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function GetWorldUp
--
-- @function [parent=#Node] GetWorldUp
-- @return Vector3#Vector3

---
-- Function GetWorldUpXYZ
--
-- @function [parent=#Node] GetWorldUpXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function GetWorldRight
--
-- @function [parent=#Node] GetWorldRight
-- @return Vector3#Vector3

---
-- Function GetWorldRightXYZ
--
-- @function [parent=#Node] GetWorldRightXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function GetWorldScale
--
-- @function [parent=#Node] GetWorldScale
-- @return Vector3#Vector3

---
-- Function GetWorldScaleXYZ
--
-- @function [parent=#Node] GetWorldScaleXYZ
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function GetWorldTransform
--
-- @function [parent=#Node] GetWorldTransform
-- @return const Matrix3x4#const Matrix3x4

---
-- Function LocalToWorld
--
-- @function [parent=#Node] LocalToWorld
-- @param Vector3#Vector3 positionposition
-- @return Vector3#Vector3

---
-- Function LocalToWorld
--
-- @function [parent=#Node] LocalToWorld
-- @param Vector4#Vector4 vectorvector
-- @return Vector3#Vector3

---
-- Function WorldToLocal
--
-- @function [parent=#Node] WorldToLocal
-- @param Vector3#Vector3 positionposition
-- @return Vector3#Vector3

---
-- Function WorldToLocal
--
-- @function [parent=#Node] WorldToLocal
-- @param Vector4#Vector4 vectorvector
-- @return Vector3#Vector3

---
-- Function IsDirty
--
-- @function [parent=#Node] IsDirty
-- @return #boolean

---
-- Function GetNumChildren
--
-- @function [parent=#Node] GetNumChildren
-- @param #boolean recursiverecursive
-- @return #number

---
-- Function GetChild
--
-- @function [parent=#Node] GetChild
-- @param #string namename
-- @param #boolean recursiverecursive
-- @return Node#Node

---
-- Function GetChild
--
-- @function [parent=#Node] GetChild
-- @param StringHash#StringHash nameHashnameHash
-- @param #boolean recursiverecursive
-- @return Node#Node

---
-- Function GetChild
--
-- @function [parent=#Node] GetChild
-- @param #number indexindex
-- @return Node#Node

---
-- Function GetNumComponents
--
-- @function [parent=#Node] GetNumComponents
-- @return #number

---
-- Function GetNumNetworkComponents
--
-- @function [parent=#Node] GetNumNetworkComponents
-- @return #number

---
-- Function HasComponent
--
-- @function [parent=#Node] HasComponent
-- @param ShortStringHash#ShortStringHash typetype
-- @return #boolean

---
-- Function HasComponent
--
-- @function [parent=#Node] HasComponent
-- @param #string typetype
-- @return #boolean

---
-- Function GetVar
--
-- @function [parent=#Node] GetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @return const Variant#const Variant

---
-- Function GetVars
--
-- @function [parent=#Node] GetVars
-- @return const VariantMap#const VariantMap

---
-- Function GetComponent
--
-- @function [parent=#Node] GetComponent
-- @param #string typetype
-- @return Component#Component

---
-- Function SetID
--
-- @function [parent=#Node] SetID
-- @param #number idid

---
-- Function SetScene
--
-- @function [parent=#Node] SetScene
-- @param Scene#Scene scenescene

---
-- Function ResetScene
--
-- @function [parent=#Node] ResetScene

---
-- Function Load
--
-- @function [parent=#Node] Load
-- @param Deserializer#Deserializer sourcesource
-- @param SceneResolver#SceneResolver resolverresolver
-- @param #boolean loadChildrenloadChildren
-- @param #boolean rewriteIDsrewriteIDs
-- @param CreateMode#CreateMode modemode
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#Node] LoadXML
-- @param XMLElement#XMLElement sourcesource
-- @param SceneResolver#SceneResolver resolverresolver
-- @param #boolean loadChildrenloadChildren
-- @param #boolean rewriteIDsrewriteIDs
-- @param CreateMode#CreateMode modemode
-- @return #boolean

---
-- Function CreateChild
--
-- @function [parent=#Node] CreateChild
-- @param #number idid
-- @param CreateMode#CreateMode modemode
-- @return Node#Node

---
-- Function AddComponent
--
-- @function [parent=#Node] AddComponent
-- @param Component#Component componentcomponent
-- @param #number idid
-- @param CreateMode#CreateMode modemode

---
-- Field ID
--
-- @field [parent=#Node] #number ID

---
-- Field name
--
-- @field [parent=#Node] #string name

---
-- Field nameHash (Read only)
--
-- @field [parent=#Node] StringHash#StringHash nameHash

---
-- Field parent
--
-- @field [parent=#Node] Node#Node parent

---
-- Field scene
--
-- @field [parent=#Node] Scene#Scene scene

---
-- Field enabled
--
-- @field [parent=#Node] #boolean enabled

---
-- Field owner
--
-- @field [parent=#Node] Connection#Connection owner

---
-- Field position
--
-- @field [parent=#Node] Vector3#Vector3 position

---
-- Field rotation
--
-- @field [parent=#Node] Quaternion#Quaternion rotation

---
-- Field direction
--
-- @field [parent=#Node] Vector3#Vector3 direction

---
-- Field up (Read only)
--
-- @field [parent=#Node] Vector3#Vector3 up

---
-- Field right (Read only)
--
-- @field [parent=#Node] Vector3#Vector3 right

---
-- Field scale
--
-- @field [parent=#Node] Vector3#Vector3 scale

---
-- Field transform (Read only)
--
-- @field [parent=#Node] Matrix3x4#Matrix3x4 transform

---
-- Field worldPosition
--
-- @field [parent=#Node] Vector3#Vector3 worldPosition

---
-- Field worldRotation
--
-- @field [parent=#Node] Quaternion#Quaternion worldRotation

---
-- Field worldDirection
--
-- @field [parent=#Node] Vector3#Vector3 worldDirection

---
-- Field worldUp (Read only)
--
-- @field [parent=#Node] Vector3#Vector3 worldUp

---
-- Field worldRight (Read only)
--
-- @field [parent=#Node] Vector3#Vector3 worldRight

---
-- Field worldScale
--
-- @field [parent=#Node] Vector3#Vector3 worldScale

---
-- Field worldTransform (Read only)
--
-- @field [parent=#Node] Matrix3x4#Matrix3x4 worldTransform

---
-- Field dirty (Read only)
--
-- @field [parent=#Node] #boolean dirty

---
-- Field numComponents (Read only)
--
-- @field [parent=#Node] #number numComponents

---
-- Field numNetworkComponents (Read only)
--
-- @field [parent=#Node] #number numNetworkComponents


return nil
