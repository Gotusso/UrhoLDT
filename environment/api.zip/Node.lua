---
-- Module Node
-- Module Node extends Animatable
-- Generated on 2014-05-31
--
-- @module Node

---
-- Function Node()
--
-- @function [parent=#Node] Node
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#Node] new
-- @param self Self reference
-- @return Node#Node

---
-- Function delete()
--
-- @function [parent=#Node] delete
-- @param self Self reference

---
-- Function SaveXML()
--
-- @function [parent=#Node] SaveXML
-- @param self Self reference
-- @param File#File dest dest
-- @return #boolean

---
-- Function SetName()
-- Set name of the scene node. Names are not required to be unique.
--
-- @function [parent=#Node] SetName
-- @param self Self reference
-- @param #string name name

---
-- Function SetPosition()
-- Set position in parent space. If the scene node is on the root level (is child of the scene itself), this is same as world space.
--
-- @function [parent=#Node] SetPosition
-- @param self Self reference
-- @param Vector3#Vector3 position position

---
-- Function SetPosition()
--
-- @function [parent=#Node] SetPosition
-- @param self Self reference
-- @param Vector2#Vector2 position position

---
-- Function SetRotation()
-- Set rotation in parent space.
--
-- @function [parent=#Node] SetRotation
-- @param self Self reference
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetRotation()
--
-- @function [parent=#Node] SetRotation
-- @param self Self reference
-- @param #number rotation rotation

---
-- Function SetDirection()
-- Set forward direction in parent space. Positive Z axis equals identity rotation.
--
-- @function [parent=#Node] SetDirection
-- @param self Self reference
-- @param Vector3#Vector3 direction direction

---
-- Function SetScale()
-- Set uniform scale in parent space.
--
-- @function [parent=#Node] SetScale
-- @param self Self reference
-- @param #number scale scale

---
-- Function SetScale()
-- Set scale in parent space.
--
-- @function [parent=#Node] SetScale
-- @param self Self reference
-- @param Vector3#Vector3 scale scale

---
-- Function SetScale()
--
-- @function [parent=#Node] SetScale
-- @param self Self reference
-- @param Vector2#Vector2 scale scale

---
-- Function SetTransform()
-- Set both position and rotation in parent space as an atomic operation. This is faster than setting position and rotation separately.
--
-- @function [parent=#Node] SetTransform
-- @param self Self reference
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetTransform()
--
-- @function [parent=#Node] SetTransform
-- @param self Self reference
-- @param Vector2#Vector2 position position
-- @param #number rotation rotation

---
-- Function SetTransform()
-- Set both position, rotation and uniform scale in parent space as an atomic operation.
--
-- @function [parent=#Node] SetTransform
-- @param self Self reference
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation
-- @param #number scale scale

---
-- Function SetTransform()
--
-- @function [parent=#Node] SetTransform
-- @param self Self reference
-- @param Vector2#Vector2 position position
-- @param #number rotation rotation
-- @param #number scale scale

---
-- Function SetTransform()
-- Set both position, rotation and scale in parent space as an atomic operation.
--
-- @function [parent=#Node] SetTransform
-- @param self Self reference
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation
-- @param Vector3#Vector3 scale scale

---
-- Function SetTransform()
--
-- @function [parent=#Node] SetTransform
-- @param self Self reference
-- @param Vector2#Vector2 position position
-- @param #number rotation rotation
-- @param Vector2#Vector2 scale scale

---
-- Function SetWorldPosition()
-- Set position in world space.
--
-- @function [parent=#Node] SetWorldPosition
-- @param self Self reference
-- @param Vector3#Vector3 position position

---
-- Function SetWorldPosition()
--
-- @function [parent=#Node] SetWorldPosition
-- @param self Self reference
-- @param Vector2#Vector2 position position

---
-- Function SetWorldRotation()
-- Set rotation in world space.
--
-- @function [parent=#Node] SetWorldRotation
-- @param self Self reference
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetWorldRotation()
--
-- @function [parent=#Node] SetWorldRotation
-- @param self Self reference
-- @param #number rotation rotation

---
-- Function SetWorldDirection()
-- Set forward direction in world space.
--
-- @function [parent=#Node] SetWorldDirection
-- @param self Self reference
-- @param Vector3#Vector3 direction direction

---
-- Function SetWorldScale()
-- Set uniform scale in world space.
--
-- @function [parent=#Node] SetWorldScale
-- @param self Self reference
-- @param #number scale scale

---
-- Function SetWorldScale()
-- Set scale in world space.
--
-- @function [parent=#Node] SetWorldScale
-- @param self Self reference
-- @param Vector3#Vector3 scale scale

---
-- Function SetWorldScale()
--
-- @function [parent=#Node] SetWorldScale
-- @param self Self reference
-- @param Vector2#Vector2 scale scale

---
-- Function SetWorldTransform()
-- Set both position and rotation in world space as an atomic operation.
--
-- @function [parent=#Node] SetWorldTransform
-- @param self Self reference
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetWorldTransform()
--
-- @function [parent=#Node] SetWorldTransform
-- @param self Self reference
-- @param Vector2#Vector2 position position
-- @param #number rotation rotation

---
-- Function SetWorldTransform()
-- Set both position, rotation and uniform scale in world space as an atomic operation.
--
-- @function [parent=#Node] SetWorldTransform
-- @param self Self reference
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation
-- @param #number scale scale

---
-- Function SetWorldTransform()
--
-- @function [parent=#Node] SetWorldTransform
-- @param self Self reference
-- @param Vector2#Vector2 position position
-- @param #number rotation rotation
-- @param #number scale scale

---
-- Function SetWorldTransform()
-- Set both position, rotation and scale in world space as an atomic opration.
--
-- @function [parent=#Node] SetWorldTransform
-- @param self Self reference
-- @param Vector3#Vector3 position position
-- @param Quaternion#Quaternion rotation rotation
-- @param Vector3#Vector3 scale scale

---
-- Function SetWorldTransform()
--
-- @function [parent=#Node] SetWorldTransform
-- @param self Self reference
-- @param Vector2#Vector2 position position
-- @param #number rotation rotation
-- @param Vector3#Vector3 scale scale

---
-- Function Translate()
-- Move the scene node in the chosen transform space.
--
-- @function [parent=#Node] Translate
-- @param self Self reference
-- @param Vector3#Vector3 delta delta
-- @param TransformSpace#TransformSpace space space

---
-- Function Translate()
--
-- @function [parent=#Node] Translate
-- @param self Self reference
-- @param Vector2#Vector2 delta delta
-- @param TransformSpace#TransformSpace space space

---
-- Function Rotate()
-- Rotate the scene node in the chosen transform space.
--
-- @function [parent=#Node] Rotate
-- @param self Self reference
-- @param Quaternion#Quaternion delta delta
-- @param TransformSpace#TransformSpace space space

---
-- Function Rotate()
--
-- @function [parent=#Node] Rotate
-- @param self Self reference
-- @param #number delta delta
-- @param TransformSpace#TransformSpace space space

---
-- Function RotateAround()
-- Rotate around a point in the chosen transform space.
--
-- @function [parent=#Node] RotateAround
-- @param self Self reference
-- @param Vector3#Vector3 point point
-- @param Quaternion#Quaternion delta delta
-- @param TransformSpace#TransformSpace space space

---
-- Function RotateAround()
--
-- @function [parent=#Node] RotateAround
-- @param self Self reference
-- @param Vector2#Vector2 point point
-- @param #number delta delta
-- @param TransformSpace#TransformSpace space space

---
-- Function Pitch()
-- Rotate around the X axis.
--
-- @function [parent=#Node] Pitch
-- @param self Self reference
-- @param #number angle angle
-- @param TransformSpace#TransformSpace space space

---
-- Function Yaw()
-- Rotate around the Y axis.
--
-- @function [parent=#Node] Yaw
-- @param self Self reference
-- @param #number angle angle
-- @param TransformSpace#TransformSpace space space

---
-- Function Roll()
-- Rotate around the Z axis.
--
-- @function [parent=#Node] Roll
-- @param self Self reference
-- @param #number angle angle
-- @param TransformSpace#TransformSpace space space

---
-- Function LookAt()
-- Look at a target position in the chosen transform space. Note that the up vector is always specified in world space. Return true if successful, or false if resulted in an illegal rotation, in which case the current rotation remains.
--
-- @function [parent=#Node] LookAt
-- @param self Self reference
-- @param Vector3#Vector3 target target
-- @return #boolean

---
-- Function LookAt()
--
-- @function [parent=#Node] LookAt
-- @param self Self reference
-- @param Vector3#Vector3 target target
-- @param Vector3#Vector3 upAxis upAxis
-- @param TransformSpace#TransformSpace space space
-- @return #boolean

---
-- Function Scale()
-- Modify scale in parent space uniformly.
--
-- @function [parent=#Node] Scale
-- @param self Self reference
-- @param #number scale scale

---
-- Function Scale()
-- Modify scale in parent space.
--
-- @function [parent=#Node] Scale
-- @param self Self reference
-- @param Vector3#Vector3 scale scale

---
-- Function Scale()
--
-- @function [parent=#Node] Scale
-- @param self Self reference
-- @param Vector2#Vector2 scale scale

---
-- Function SetEnabled()
-- Set enabled/disabled state without recursion. Components in a disabled node become effectively disabled regardless of their own enable/disable state.
--
-- @function [parent=#Node] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetEnabled()
-- Set enabled/disabled state with optional recursion.
--
-- @function [parent=#Node] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable
-- @param #boolean recursive recursive

---
-- Function SetOwner()
-- Set owner connection for networking.
--
-- @function [parent=#Node] SetOwner
-- @param self Self reference
-- @param Connection#Connection owner owner

---
-- Function MarkDirty()
-- Mark node and child nodes to need world transform recalculation. Notify listener components.
--
-- @function [parent=#Node] MarkDirty
-- @param self Self reference

---
-- Function CreateChild()
-- Create a child scene node (with specified ID if provided).
--
-- @function [parent=#Node] CreateChild
-- @param self Self reference
-- @param #string name name
-- @param CreateMode#CreateMode mode mode
-- @param #number id id
-- @return Node#Node

---
-- Function AddChild()
-- Add a child scene node at a specific index. If index is not explicitly specified or is greater than current children size, append the new child at the end.
--
-- @function [parent=#Node] AddChild
-- @param self Self reference
-- @param Node#Node node node
-- @param #number index index

---
-- Function RemoveChild()
-- Remove a child scene node.
--
-- @function [parent=#Node] RemoveChild
-- @param self Self reference
-- @param Node#Node node node

---
-- Function RemoveAllChildren()
-- Remove all child scene nodes.
--
-- @function [parent=#Node] RemoveAllChildren
-- @param self Self reference

---
-- Function RemoveChildren()
-- Remove child scene nodes that match criteria.
--
-- @function [parent=#Node] RemoveChildren
-- @param self Self reference
-- @param #boolean removeReplicated removeReplicated
-- @param #boolean removeLocal removeLocal
-- @param #boolean recursive recursive

---
-- Function RemoveComponent()
-- Remove a component from this node.
--
-- @function [parent=#Node] RemoveComponent
-- @param self Self reference
-- @param Component#Component component component

---
-- Function RemoveComponent()
-- Remove the first component of specific type from this node.
--
-- @function [parent=#Node] RemoveComponent
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type

---
-- Function RemoveComponent()
--
-- @function [parent=#Node] RemoveComponent
-- @param self Self reference
-- @param #string type type

---
-- Function RemoveAllComponents()
-- Remove all components from this node.
--
-- @function [parent=#Node] RemoveAllComponents
-- @param self Self reference

---
-- Function RemoveComponents()
-- Remove components that match criteria.
--
-- @function [parent=#Node] RemoveComponents
-- @param self Self reference
-- @param #boolean removeReplicated removeReplicated
-- @param #boolean removeLocal removeLocal

---
-- Function Clone()
-- Clone scene node, components and child nodes. Return the clone.
--
-- @function [parent=#Node] Clone
-- @param self Self reference
-- @param CreateMode#CreateMode mode mode
-- @return Node#Node

---
-- Function Remove()
-- Remove from the parent node. If no other shared pointer references exist, causes immediate deletion.
--
-- @function [parent=#Node] Remove
-- @param self Self reference

---
-- Function SetParent()
-- Set parent scene node. Retains the world transform.
--
-- @function [parent=#Node] SetParent
-- @param self Self reference
-- @param Node#Node parent parent

---
-- Function SetVar()
-- Set a user variable.
--
-- @function [parent=#Node] SetVar
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash key key
-- @param Variant#Variant value value

---
-- Function AddListener()
-- Add listener component that is notified of node being dirtied. Can either be in the same node or another.
--
-- @function [parent=#Node] AddListener
-- @param self Self reference
-- @param Component#Component component component

---
-- Function RemoveListener()
-- Remove listener component.
--
-- @function [parent=#Node] RemoveListener
-- @param self Self reference
-- @param Component#Component component component

---
-- Function CreateComponent()
--
-- @function [parent=#Node] CreateComponent
-- @param self Self reference
-- @param #string type type
-- @param CreateMode#CreateMode mode mode
-- @param #number id id
-- @return Component#Component

---
-- Function CloneComponent()
-- Clone a component from another node using its create mode. Return the clone if successful or null on failure.
--
-- @function [parent=#Node] CloneComponent
-- @param self Self reference
-- @param Component#Component component component
-- @param #number id id
-- @return Component#Component

---
-- Function CloneComponent()
-- Clone a component from another node and specify the create mode. Return the clone if successful or null on failure.
--
-- @function [parent=#Node] CloneComponent
-- @param self Self reference
-- @param Component#Component component component
-- @param CreateMode#CreateMode mode mode
-- @param #number id id
-- @return Component#Component

---
-- Function CreateScriptObject()
--
-- @function [parent=#Node] CreateScriptObject
-- @param self Self reference
-- @param #string scriptObjectType scriptObjectType
-- @return #number

---
-- Function CreateScriptObject()
--
-- @function [parent=#Node] CreateScriptObject
-- @param self Self reference
-- @param #string fileName fileName
-- @param #string scriptObjectType scriptObjectType
-- @return #number

---
-- Function GetScriptObject()
--
-- @function [parent=#Node] GetScriptObject
-- @param self Self reference
-- @return #number

---
-- Function GetScriptObject()
--
-- @function [parent=#Node] GetScriptObject
-- @param self Self reference
-- @param #string scriptObjectType scriptObjectType
-- @return #number

---
-- Function GetID()
-- Return ID.
--
-- @function [parent=#Node] GetID
-- @param self Self reference
-- @return #number

---
-- Function GetName()
-- Return name.
--
-- @function [parent=#Node] GetName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetNameHash()
-- Return name hash.
--
-- @function [parent=#Node] GetNameHash
-- @param self Self reference
-- @return StringHash#StringHash

---
-- Function GetParent()
-- Return parent scene node.
--
-- @function [parent=#Node] GetParent
-- @param self Self reference
-- @return Node#Node

---
-- Function GetScene()
-- Return scene.
--
-- @function [parent=#Node] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function IsEnabled()
-- Return whether is enabled. Disables nodes effectively disable all their components.
--
-- @function [parent=#Node] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function GetOwner()
-- Return owner connection in networking.
--
-- @function [parent=#Node] GetOwner
-- @param self Self reference
-- @return Connection#Connection

---
-- Function GetPosition()
-- Return position in parent space.
--
-- @function [parent=#Node] GetPosition
-- @param self Self reference
-- @return const Vector3#const Vector3

---
-- Function GetRotation()
-- Return rotation in parent space.
--
-- @function [parent=#Node] GetRotation
-- @param self Self reference
-- @return const Quaternion#const Quaternion

---
-- Function GetDirection()
-- Return forward direction in parent space. Positive Z axis equals identity rotation.
--
-- @function [parent=#Node] GetDirection
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetUp()
-- Return up direction in parent space. Positive Y axis equals identity rotation.
--
-- @function [parent=#Node] GetUp
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetRight()
-- Return right direction in parent space. Positive X axis equals identity rotation.
--
-- @function [parent=#Node] GetRight
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetScale()
-- Return scale in parent space.
--
-- @function [parent=#Node] GetScale
-- @param self Self reference
-- @return const Vector3#const Vector3

---
-- Function GetTransform()
--
-- @function [parent=#Node] GetTransform
-- @param self Self reference
-- @return Matrix3x4#Matrix3x4

---
-- Function GetWorldPosition()
-- Return position in world space.
--
-- @function [parent=#Node] GetWorldPosition
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetWorldRotation()
--
-- @function [parent=#Node] GetWorldRotation
-- @param self Self reference
-- @return Quaternion#Quaternion

---
-- Function GetWorldDirection()
--
-- @function [parent=#Node] GetWorldDirection
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetWorldUp()
--
-- @function [parent=#Node] GetWorldUp
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetWorldRight()
--
-- @function [parent=#Node] GetWorldRight
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetWorldScale()
--
-- @function [parent=#Node] GetWorldScale
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetWorldTransform()
--
-- @function [parent=#Node] GetWorldTransform
-- @param self Self reference
-- @return const Matrix3x4#const Matrix3x4

---
-- Function LocalToWorld()
--
-- @function [parent=#Node] LocalToWorld
-- @param self Self reference
-- @param Vector3#Vector3 position position
-- @return Vector3#Vector3

---
-- Function LocalToWorld()
--
-- @function [parent=#Node] LocalToWorld
-- @param self Self reference
-- @param Vector4#Vector4 vector vector
-- @return Vector3#Vector3

---
-- Function LocalToWorld()
--
-- @function [parent=#Node] LocalToWorld
-- @param self Self reference
-- @param Vector2#Vector2 vector vector
-- @return Vector2#Vector2

---
-- Function WorldToLocal()
--
-- @function [parent=#Node] WorldToLocal
-- @param self Self reference
-- @param Vector3#Vector3 position position
-- @return Vector3#Vector3

---
-- Function WorldToLocal()
--
-- @function [parent=#Node] WorldToLocal
-- @param self Self reference
-- @param Vector4#Vector4 vector vector
-- @return Vector3#Vector3

---
-- Function WorldToLocal()
--
-- @function [parent=#Node] WorldToLocal
-- @param self Self reference
-- @param Vector2#Vector2 vector vector
-- @return Vector2#Vector2

---
-- Function IsDirty()
--
-- @function [parent=#Node] IsDirty
-- @param self Self reference
-- @return #boolean

---
-- Function GetNumChildren()
--
-- @function [parent=#Node] GetNumChildren
-- @param self Self reference
-- @param #boolean recursive recursive
-- @return #number

---
-- Function GetChild()
--
-- @function [parent=#Node] GetChild
-- @param self Self reference
-- @param #string name name
-- @param #boolean recursive recursive
-- @return Node#Node

---
-- Function GetChild()
--
-- @function [parent=#Node] GetChild
-- @param self Self reference
-- @param StringHash#StringHash nameHash nameHash
-- @param #boolean recursive recursive
-- @return Node#Node

---
-- Function GetChild()
--
-- @function [parent=#Node] GetChild
-- @param self Self reference
-- @param #number index index
-- @return Node#Node

---
-- Function GetNumComponents()
--
-- @function [parent=#Node] GetNumComponents
-- @param self Self reference
-- @return #number

---
-- Function GetNumNetworkComponents()
--
-- @function [parent=#Node] GetNumNetworkComponents
-- @param self Self reference
-- @return #number

---
-- Function HasComponent()
--
-- @function [parent=#Node] HasComponent
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return #boolean

---
-- Function HasComponent()
--
-- @function [parent=#Node] HasComponent
-- @param self Self reference
-- @param #string type type
-- @return #boolean

---
-- Function GetVar()
--
-- @function [parent=#Node] GetVar
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash key key
-- @return const Variant#const Variant

---
-- Function GetVars()
--
-- @function [parent=#Node] GetVars
-- @param self Self reference
-- @return const VariantMap#const VariantMap

---
-- Function GetComponent()
--
-- @function [parent=#Node] GetComponent
-- @param self Self reference
-- @param #string type type
-- @return Component#Component

---
-- Function SetID()
--
-- @function [parent=#Node] SetID
-- @param self Self reference
-- @param #number id id

---
-- Function SetScene()
--
-- @function [parent=#Node] SetScene
-- @param self Self reference
-- @param Scene#Scene scene scene

---
-- Function ResetScene()
--
-- @function [parent=#Node] ResetScene
-- @param self Self reference

---
-- Function Load()
--
-- @function [parent=#Node] Load
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @param SceneResolver#SceneResolver resolver resolver
-- @param #boolean loadChildren loadChildren
-- @param #boolean rewriteIDs rewriteIDs
-- @param CreateMode#CreateMode mode mode
-- @return #boolean

---
-- Function LoadXML()
--
-- @function [parent=#Node] LoadXML
-- @param self Self reference
-- @param XMLElement#XMLElement source source
-- @param SceneResolver#SceneResolver resolver resolver
-- @param #boolean loadChildren loadChildren
-- @param #boolean rewriteIDs rewriteIDs
-- @param CreateMode#CreateMode mode mode
-- @return #boolean

---
-- Function CreateChild()
--
-- @function [parent=#Node] CreateChild
-- @param self Self reference
-- @param #number id id
-- @param CreateMode#CreateMode mode mode
-- @return Node#Node

---
-- Function AddComponent()
--
-- @function [parent=#Node] AddComponent
-- @param self Self reference
-- @param Component#Component component component
-- @param #number id id
-- @param CreateMode#CreateMode mode mode

---
-- Field ID
--
-- @field [parent=#Node] #number ID

---
-- Field name
--
-- @field [parent=#Node] #string name

---
-- Field nameHash (Read only)
--
-- @field [parent=#Node] StringHash#StringHash nameHash

---
-- Field parent
--
-- @field [parent=#Node] Node#Node parent

---
-- Field scene
--
-- @field [parent=#Node] Scene#Scene scene

---
-- Field enabled
--
-- @field [parent=#Node] #boolean enabled

---
-- Field owner
--
-- @field [parent=#Node] Connection#Connection owner

---
-- Field position
--
-- @field [parent=#Node] Vector3#Vector3 position

---
-- Field rotation
--
-- @field [parent=#Node] Quaternion#Quaternion rotation

---
-- Field direction
--
-- @field [parent=#Node] Vector3#Vector3 direction

---
-- Field up (Read only)
--
-- @field [parent=#Node] Vector3#Vector3 up

---
-- Field right (Read only)
--
-- @field [parent=#Node] Vector3#Vector3 right

---
-- Field scale
--
-- @field [parent=#Node] Vector3#Vector3 scale

---
-- Field transform (Read only)
--
-- @field [parent=#Node] Matrix3x4#Matrix3x4 transform

---
-- Field worldPosition
--
-- @field [parent=#Node] Vector3#Vector3 worldPosition

---
-- Field worldRotation
--
-- @field [parent=#Node] Quaternion#Quaternion worldRotation

---
-- Field worldDirection
--
-- @field [parent=#Node] Vector3#Vector3 worldDirection

---
-- Field worldUp (Read only)
--
-- @field [parent=#Node] Vector3#Vector3 worldUp

---
-- Field worldRight (Read only)
--
-- @field [parent=#Node] Vector3#Vector3 worldRight

---
-- Field worldScale
--
-- @field [parent=#Node] Vector3#Vector3 worldScale

---
-- Field worldTransform (Read only)
--
-- @field [parent=#Node] Matrix3x4#Matrix3x4 worldTransform

---
-- Field dirty (Read only)
--
-- @field [parent=#Node] #boolean dirty

---
-- Field numComponents (Read only)
--
-- @field [parent=#Node] #number numComponents

---
-- Field numNetworkComponents (Read only)
--
-- @field [parent=#Node] #number numNetworkComponents


return nil
