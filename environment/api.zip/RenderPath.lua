---
-- Module RenderPath
--
-- @module RenderPath

---
-- Function Clone
--
-- @function [parent=#RenderPath] Clone
-- @return RenderPath#RenderPath

---
-- Function Load
--
-- @function [parent=#RenderPath] Load
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function Append
--
-- @function [parent=#RenderPath] Append
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetEnabled
--
-- @function [parent=#RenderPath] SetEnabled
-- @param #string tagtag
-- @param #boolean activeactive

---
-- Function ToggleEnabled
--
-- @function [parent=#RenderPath] ToggleEnabled
-- @param #string tagtag

---
-- Function SetRenderTarget
--
-- @function [parent=#RenderPath] SetRenderTarget
-- @param #number indexindex
-- @param RenderTargetInfo#RenderTargetInfo infoinfo

---
-- Function AddRenderTarget
--
-- @function [parent=#RenderPath] AddRenderTarget
-- @param RenderTargetInfo#RenderTargetInfo infoinfo

---
-- Function RemoveRenderTarget
--
-- @function [parent=#RenderPath] RemoveRenderTarget
-- @param #string namename

---
-- Function RemoveRenderTarget
--
-- @function [parent=#RenderPath] RemoveRenderTarget
-- @param #number indexindex

---
-- Function RemoveRenderTargets
--
-- @function [parent=#RenderPath] RemoveRenderTargets
-- @param #string tagtag

---
-- Function SetCommand
--
-- @function [parent=#RenderPath] SetCommand
-- @param #number indexindex
-- @param RenderPathCommand#RenderPathCommand commandcommand

---
-- Function AddCommand
--
-- @function [parent=#RenderPath] AddCommand
-- @param RenderPathCommand#RenderPathCommand commandcommand

---
-- Function InsertCommand
--
-- @function [parent=#RenderPath] InsertCommand
-- @param #number indexindex
-- @param RenderPathCommand#RenderPathCommand commandcommand

---
-- Function RemoveCommand
--
-- @function [parent=#RenderPath] RemoveCommand
-- @param #number indexindex

---
-- Function RemoveCommands
--
-- @function [parent=#RenderPath] RemoveCommands
-- @param #string tagtag

---
-- Function SetShaderParameter
--
-- @function [parent=#RenderPath] SetShaderParameter
-- @param #string namename
-- @param Variant#Variant valuevalue

---
-- Function GetNumRenderTargets
--
-- @function [parent=#RenderPath] GetNumRenderTargets
-- @return #number

---
-- Function GetNumCommands
--
-- @function [parent=#RenderPath] GetNumCommands
-- @return #number

---
-- Function GetShaderParameter
--
-- @function [parent=#RenderPath] GetShaderParameter
-- @param #string namename
-- @return const Variant#const Variant


return nil
