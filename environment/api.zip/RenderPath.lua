---
-- Module RenderPath
-- Generated on 2014-05-31
--
-- @module RenderPath

---
-- Function Clone()
-- Clone the rendering path.
--
-- @function [parent=#RenderPath] Clone
-- @param self Self reference
-- @return RenderPath#RenderPath

---
-- Function Load()
-- Clear existing data and load from an XML file. Return true if successful.
--
-- @function [parent=#RenderPath] Load
-- @param self Self reference
-- @param XMLFile#XMLFile file file
-- @return #boolean

---
-- Function Append()
-- Append data from an XML file. Return true if successful.
--
-- @function [parent=#RenderPath] Append
-- @param self Self reference
-- @param XMLFile#XMLFile file file
-- @return #boolean

---
-- Function SetEnabled()
-- Enable/disable commands and rendertargets by tag.
--
-- @function [parent=#RenderPath] SetEnabled
-- @param self Self reference
-- @param #string tag tag
-- @param #boolean active active

---
-- Function ToggleEnabled()
-- Toggle enabled state of commands and rendertargets by tag.
--
-- @function [parent=#RenderPath] ToggleEnabled
-- @param self Self reference
-- @param #string tag tag

---
-- Function SetRenderTarget()
-- Assign rendertarget at index.
--
-- @function [parent=#RenderPath] SetRenderTarget
-- @param self Self reference
-- @param #number index index
-- @param RenderTargetInfo#RenderTargetInfo info info

---
-- Function AddRenderTarget()
-- Add a rendertarget.
--
-- @function [parent=#RenderPath] AddRenderTarget
-- @param self Self reference
-- @param RenderTargetInfo#RenderTargetInfo info info

---
-- Function RemoveRenderTarget()
-- Remove a rendertarget by name.
--
-- @function [parent=#RenderPath] RemoveRenderTarget
-- @param self Self reference
-- @param #string name name

---
-- Function RemoveRenderTarget()
-- Remove a rendertarget by index.
--
-- @function [parent=#RenderPath] RemoveRenderTarget
-- @param self Self reference
-- @param #number index index

---
-- Function RemoveRenderTargets()
-- Remove rendertargets by tag name.
--
-- @function [parent=#RenderPath] RemoveRenderTargets
-- @param self Self reference
-- @param #string tag tag

---
-- Function SetCommand()
-- Assign command at index.
--
-- @function [parent=#RenderPath] SetCommand
-- @param self Self reference
-- @param #number index index
-- @param RenderPathCommand#RenderPathCommand command command

---
-- Function AddCommand()
-- Add a command to the end of the list.
--
-- @function [parent=#RenderPath] AddCommand
-- @param self Self reference
-- @param RenderPathCommand#RenderPathCommand command command

---
-- Function InsertCommand()
-- Insert a command at a position.
--
-- @function [parent=#RenderPath] InsertCommand
-- @param self Self reference
-- @param #number index index
-- @param RenderPathCommand#RenderPathCommand command command

---
-- Function RemoveCommand()
-- Remove a command by index.
--
-- @function [parent=#RenderPath] RemoveCommand
-- @param self Self reference
-- @param #number index index

---
-- Function RemoveCommands()
-- Remove commands by tag name.
--
-- @function [parent=#RenderPath] RemoveCommands
-- @param self Self reference
-- @param #string tag tag

---
-- Function SetShaderParameter()
-- Set a shader parameter in all commands that define it.
--
-- @function [parent=#RenderPath] SetShaderParameter
-- @param self Self reference
-- @param #string name name
-- @param Variant#Variant value value

---
-- Function GetNumRenderTargets()
-- Return number of rendertargets.
--
-- @function [parent=#RenderPath] GetNumRenderTargets
-- @param self Self reference
-- @return #number

---
-- Function GetNumCommands()
-- Return number of commands.
--
-- @function [parent=#RenderPath] GetNumCommands
-- @param self Self reference
-- @return #number

---
-- Function GetShaderParameter()
-- Return a shader parameter (first appearance in any command.)
--
-- @function [parent=#RenderPath] GetShaderParameter
-- @param self Self reference
-- @param #string name name
-- @return const Variant#const Variant


return nil
