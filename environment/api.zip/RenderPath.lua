---
-- Module RenderPath
-- Generated on 2014-03-13
--
-- @module RenderPath

---
-- Function Clone
--
-- @function [parent=#RenderPath] Clone
-- @param self Self reference
-- @return RenderPath#RenderPath

---
-- Function Load
--
-- @function [parent=#RenderPath] Load
-- @param self Self reference
-- @param XMLFile#XMLFile file file
-- @return #boolean

---
-- Function Append
--
-- @function [parent=#RenderPath] Append
-- @param self Self reference
-- @param XMLFile#XMLFile file file
-- @return #boolean

---
-- Function SetEnabled
--
-- @function [parent=#RenderPath] SetEnabled
-- @param self Self reference
-- @param #string tag tag
-- @param #boolean active active

---
-- Function ToggleEnabled
--
-- @function [parent=#RenderPath] ToggleEnabled
-- @param self Self reference
-- @param #string tag tag

---
-- Function SetRenderTarget
--
-- @function [parent=#RenderPath] SetRenderTarget
-- @param self Self reference
-- @param #number index index
-- @param RenderTargetInfo#RenderTargetInfo info info

---
-- Function AddRenderTarget
--
-- @function [parent=#RenderPath] AddRenderTarget
-- @param self Self reference
-- @param RenderTargetInfo#RenderTargetInfo info info

---
-- Function RemoveRenderTarget
--
-- @function [parent=#RenderPath] RemoveRenderTarget
-- @param self Self reference
-- @param #string name name

---
-- Function RemoveRenderTarget
--
-- @function [parent=#RenderPath] RemoveRenderTarget
-- @param self Self reference
-- @param #number index index

---
-- Function RemoveRenderTargets
--
-- @function [parent=#RenderPath] RemoveRenderTargets
-- @param self Self reference
-- @param #string tag tag

---
-- Function SetCommand
--
-- @function [parent=#RenderPath] SetCommand
-- @param self Self reference
-- @param #number index index
-- @param RenderPathCommand#RenderPathCommand command command

---
-- Function AddCommand
--
-- @function [parent=#RenderPath] AddCommand
-- @param self Self reference
-- @param RenderPathCommand#RenderPathCommand command command

---
-- Function InsertCommand
--
-- @function [parent=#RenderPath] InsertCommand
-- @param self Self reference
-- @param #number index index
-- @param RenderPathCommand#RenderPathCommand command command

---
-- Function RemoveCommand
--
-- @function [parent=#RenderPath] RemoveCommand
-- @param self Self reference
-- @param #number index index

---
-- Function RemoveCommands
--
-- @function [parent=#RenderPath] RemoveCommands
-- @param self Self reference
-- @param #string tag tag

---
-- Function SetShaderParameter
--
-- @function [parent=#RenderPath] SetShaderParameter
-- @param self Self reference
-- @param #string name name
-- @param Variant#Variant value value

---
-- Function GetNumRenderTargets
--
-- @function [parent=#RenderPath] GetNumRenderTargets
-- @param self Self reference
-- @return #number

---
-- Function GetNumCommands
--
-- @function [parent=#RenderPath] GetNumCommands
-- @param self Self reference
-- @return #number

---
-- Function GetShaderParameter
--
-- @function [parent=#RenderPath] GetShaderParameter
-- @param self Self reference
-- @param #string name name
-- @return const Variant#const Variant


return nil
