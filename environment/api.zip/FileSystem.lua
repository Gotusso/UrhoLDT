---
-- Module FileSystem
-- Module FileSystem extends Object
-- Generated on 2014-03-13
--
-- @module FileSystem

---
-- Function SetCurrentDir
--
-- @function [parent=#FileSystem] SetCurrentDir
-- @param self Self reference
-- @param #string pathName pathName
-- @return #boolean

---
-- Function CreateDir
--
-- @function [parent=#FileSystem] CreateDir
-- @param self Self reference
-- @param #string pathName pathName
-- @return #boolean

---
-- Function SystemCommand
--
-- @function [parent=#FileSystem] SystemCommand
-- @param self Self reference
-- @param #string commandLine commandLine
-- @return #number

---
-- Function SystemRun
--
-- @function [parent=#FileSystem] SystemRun
-- @param self Self reference
-- @param #string fileName fileName
-- @param Vector<String>#Vector<String> arguments arguments
-- @return #number

---
-- Function SystemOpen
--
-- @function [parent=#FileSystem] SystemOpen
-- @param self Self reference
-- @param #string fileName fileName
-- @param #string mode mode
-- @return #boolean

---
-- Function Copy
--
-- @function [parent=#FileSystem] Copy
-- @param self Self reference
-- @param #string srcFileName srcFileName
-- @param #string destFileName destFileName
-- @return #boolean

---
-- Function Rename
--
-- @function [parent=#FileSystem] Rename
-- @param self Self reference
-- @param #string srcFileName srcFileName
-- @param #string destFileName destFileName
-- @return #boolean

---
-- Function Delete
--
-- @function [parent=#FileSystem] Delete
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function RegisterPath
--
-- @function [parent=#FileSystem] RegisterPath
-- @param self Self reference
-- @param #string pathName pathName

---
-- Function GetCurrentDir
--
-- @function [parent=#FileSystem] GetCurrentDir
-- @param self Self reference
-- @return #string

---
-- Function HasRegisteredPaths
--
-- @function [parent=#FileSystem] HasRegisteredPaths
-- @param self Self reference
-- @return #boolean

---
-- Function CheckAccess
--
-- @function [parent=#FileSystem] CheckAccess
-- @param self Self reference
-- @param #string pathName pathName
-- @return #boolean

---
-- Function GetLastModifiedTime
--
-- @function [parent=#FileSystem] GetLastModifiedTime
-- @param self Self reference
-- @param #string fileName fileName
-- @return #number

---
-- Function FileExists
--
-- @function [parent=#FileSystem] FileExists
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function DirExists
--
-- @function [parent=#FileSystem] DirExists
-- @param self Self reference
-- @param #string pathName pathName
-- @return #boolean

---
-- Function ScanDir
--
-- @function [parent=#FileSystem] ScanDir
-- @param self Self reference
-- @param #string pathName pathName
-- @param #string filter filter
-- @param #number flags flags
-- @param #boolean recursive recursive
-- @return const Vector<String>#const Vector<String>

---
-- Function GetProgramDir
--
-- @function [parent=#FileSystem] GetProgramDir
-- @param self Self reference
-- @return #string

---
-- Function GetUserDocumentsDir
--
-- @function [parent=#FileSystem] GetUserDocumentsDir
-- @param self Self reference
-- @return #string

---
-- Function GetType
--
-- @function [parent=#FileSystem] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#FileSystem] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#FileSystem] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#FileSystem] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#FileSystem] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#FileSystem] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#FileSystem] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#FileSystem] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#FileSystem] #string category


return nil
