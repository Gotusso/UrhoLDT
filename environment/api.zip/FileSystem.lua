---
-- Module FileSystem
-- Module FileSystem extends Object
-- Generated on 2014-05-31
--
-- @module FileSystem

---
-- Function SetCurrentDir()
-- Set the current working directory.
--
-- @function [parent=#FileSystem] SetCurrentDir
-- @param self Self reference
-- @param #string pathName pathName
-- @return #boolean

---
-- Function CreateDir()
-- Create a directory.
--
-- @function [parent=#FileSystem] CreateDir
-- @param self Self reference
-- @param #string pathName pathName
-- @return #boolean

---
-- Function SetExecuteConsoleCommands()
-- Set whether to execute engine console commands as OS-specific system command.
--
-- @function [parent=#FileSystem] SetExecuteConsoleCommands
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SystemCommand()
-- Run a program using the command interpreter, block until it exits and return the exit code. Will fail if any allowed paths are defined.
--
-- @function [parent=#FileSystem] SystemCommand
-- @param self Self reference
-- @param #string commandLine commandLine
-- @param #boolean redirectStdOutToLog redirectStdOutToLog
-- @return #number

---
-- Function SystemRun()
--
-- @function [parent=#FileSystem] SystemRun
-- @param self Self reference
-- @param #string fileName fileName
-- @param Vector<String>#Vector<String> arguments arguments
-- @return #number

---
-- Function SystemCommandAsync()
-- Run a program using the command interpreter asynchronously. Return a request ID or M_MAX_UNSIGNED if failed. The exit code will be posted together with the request ID in an AsyncExecFinished event. Will fail if any allowed paths are defined.
--
-- @function [parent=#FileSystem] SystemCommandAsync
-- @param self Self reference
-- @param #string commandLine commandLine
-- @return #number

---
-- Function SystemRunAsync()
--
-- @function [parent=#FileSystem] SystemRunAsync
-- @param self Self reference
-- @param #string fileName fileName
-- @param Vector<String>#Vector<String> arguments arguments
-- @return #number

---
-- Function SystemOpen()
-- Open a file in an external program, with mode such as \"edit\" optionally specified. Will fail if any allowed paths are defined.
--
-- @function [parent=#FileSystem] SystemOpen
-- @param self Self reference
-- @param #string fileName fileName
-- @param #string mode mode
-- @return #boolean

---
-- Function Copy()
-- Copy a file. Return true if successful.
--
-- @function [parent=#FileSystem] Copy
-- @param self Self reference
-- @param #string srcFileName srcFileName
-- @param #string destFileName destFileName
-- @return #boolean

---
-- Function Rename()
-- Rename a file. Return true if successful.
--
-- @function [parent=#FileSystem] Rename
-- @param self Self reference
-- @param #string srcFileName srcFileName
-- @param #string destFileName destFileName
-- @return #boolean

---
-- Function Delete()
-- Delete a file. Return true if successful.
--
-- @function [parent=#FileSystem] Delete
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function RegisterPath()
-- Register a path as allowed to access. If no paths are registered, all are allowed. Registering allowed paths is considered securing the Urho3D execution environment: running programs and opening files externally through the system will fail afterward.
--
-- @function [parent=#FileSystem] RegisterPath
-- @param self Self reference
-- @param #string pathName pathName

---
-- Function GetCurrentDir()
-- Return the absolute current working directory.
--
-- @function [parent=#FileSystem] GetCurrentDir
-- @param self Self reference
-- @return #string

---
-- Function GetExecuteConsoleCommands()
-- Return whether is executing engine console commands as OS-specific system command.
--
-- @function [parent=#FileSystem] GetExecuteConsoleCommands
-- @param self Self reference
-- @return #boolean

---
-- Function HasRegisteredPaths()
-- Return whether paths have been registered.
--
-- @function [parent=#FileSystem] HasRegisteredPaths
-- @param self Self reference
-- @return #boolean

---
-- Function CheckAccess()
-- Check if a path is allowed to be accessed. If no paths are registered, all are allowed.
--
-- @function [parent=#FileSystem] CheckAccess
-- @param self Self reference
-- @param #string pathName pathName
-- @return #boolean

---
-- Function GetLastModifiedTime()
-- Returns the file's last modified time as seconds since 1.1.1970, or 0 if can not be accessed.
--
-- @function [parent=#FileSystem] GetLastModifiedTime
-- @param self Self reference
-- @param #string fileName fileName
-- @return #number

---
-- Function FileExists()
-- Check if a file exists.
--
-- @function [parent=#FileSystem] FileExists
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function DirExists()
-- Check if a directory exists.
--
-- @function [parent=#FileSystem] DirExists
-- @param self Self reference
-- @param #string pathName pathName
-- @return #boolean

---
-- Function ScanDir()
--
-- @function [parent=#FileSystem] ScanDir
-- @param self Self reference
-- @param #string pathName pathName
-- @param #string filter filter
-- @param #number flags flags
-- @param #boolean recursive recursive
-- @return const Vector<String>#const Vector<String>

---
-- Function GetProgramDir()
-- Return the program's directory. If it does not contain the Urho3D default CoreData and Data directories, and the current working directory does, return the working directory instead.
--
-- @function [parent=#FileSystem] GetProgramDir
-- @param self Self reference
-- @return #string

---
-- Function GetUserDocumentsDir()
-- Return the user documents directory.
--
-- @function [parent=#FileSystem] GetUserDocumentsDir
-- @param self Self reference
-- @return #string


return nil
