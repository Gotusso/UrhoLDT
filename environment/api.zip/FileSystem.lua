---
-- Module FileSystem
-- extends Object
--
-- @module FileSystem

---
-- Function SetCurrentDir
--
-- @function [parent=#FileSystem] SetCurrentDir
-- @param #string pathNamepathName
-- @return #boolean

---
-- Function CreateDir
--
-- @function [parent=#FileSystem] CreateDir
-- @param #string pathNamepathName
-- @return #boolean

---
-- Function SystemCommand
--
-- @function [parent=#FileSystem] SystemCommand
-- @param #string commandLinecommandLine
-- @return #number

---
-- Function SystemRun
--
-- @function [parent=#FileSystem] SystemRun
-- @param #string fileNamefileName
-- @param Vector<String>#Vector<String> argumentsarguments
-- @return #number

---
-- Function SystemOpen
--
-- @function [parent=#FileSystem] SystemOpen
-- @param #string fileNamefileName
-- @param #string modemode
-- @return #boolean

---
-- Function Copy
--
-- @function [parent=#FileSystem] Copy
-- @param #string srcFileNamesrcFileName
-- @param #string destFileNamedestFileName
-- @return #boolean

---
-- Function Rename
--
-- @function [parent=#FileSystem] Rename
-- @param #string srcFileNamesrcFileName
-- @param #string destFileNamedestFileName
-- @return #boolean

---
-- Function Delete
--
-- @function [parent=#FileSystem] Delete
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function RegisterPath
--
-- @function [parent=#FileSystem] RegisterPath
-- @param #string pathNamepathName

---
-- Function GetCurrentDir
--
-- @function [parent=#FileSystem] GetCurrentDir
-- @return #string

---
-- Function HasRegisteredPaths
--
-- @function [parent=#FileSystem] HasRegisteredPaths
-- @return #boolean

---
-- Function CheckAccess
--
-- @function [parent=#FileSystem] CheckAccess
-- @param #string pathNamepathName
-- @return #boolean

---
-- Function GetLastModifiedTime
--
-- @function [parent=#FileSystem] GetLastModifiedTime
-- @param #string fileNamefileName
-- @return #number

---
-- Function FileExists
--
-- @function [parent=#FileSystem] FileExists
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function DirExists
--
-- @function [parent=#FileSystem] DirExists
-- @param #string pathNamepathName
-- @return #boolean

---
-- Function ScanDir
--
-- @function [parent=#FileSystem] ScanDir
-- @param #string pathNamepathName
-- @param #string filterfilter
-- @param #number flagsflags
-- @param #boolean recursiverecursive
-- @return const Vector<String>#const Vector<String>

---
-- Function GetProgramDir
--
-- @function [parent=#FileSystem] GetProgramDir
-- @return #string

---
-- Function GetUserDocumentsDir
--
-- @function [parent=#FileSystem] GetUserDocumentsDir
-- @return #string

---
-- Function GetType
--
-- @function [parent=#FileSystem] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#FileSystem] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#FileSystem] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#FileSystem] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#FileSystem] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#FileSystem] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#FileSystem] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#FileSystem] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#FileSystem] #string category


return nil
