---
-- Module TouchState
-- Generated on 2014-05-31
--
-- @module TouchState

---
-- Function GetTouchedElement()
--
-- @function [parent=#TouchState] GetTouchedElement
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Field touchID
--
-- @field [parent=#TouchState] #number touchID

---
-- Field position
--
-- @field [parent=#TouchState] IntVector2#IntVector2 position

---
-- Field lastPosition
--
-- @field [parent=#TouchState] IntVector2#IntVector2 lastPosition

---
-- Field delta
--
-- @field [parent=#TouchState] IntVector2#IntVector2 delta

---
-- Field pressure
--
-- @field [parent=#TouchState] #number pressure

---
-- Field touchedElement (Read only)
--
-- @field [parent=#TouchState] UIElement#UIElement touchedElement


return nil
