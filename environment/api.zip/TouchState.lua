---
-- Module TouchState
-- Generated on 2014-03-13
--
-- @module TouchState

---
-- Field touchID
--
-- @field [parent=#TouchState] #number touchID

---
-- Field position
--
-- @field [parent=#TouchState] IntVector2#IntVector2 position

---
-- Field lastPosition
--
-- @field [parent=#TouchState] IntVector2#IntVector2 lastPosition

---
-- Field delta
--
-- @field [parent=#TouchState] IntVector2#IntVector2 delta

---
-- Field pressure
--
-- @field [parent=#TouchState] #number pressure


return nil
