---
-- Module FocusParameters
--
-- @module FocusParameters

---
-- Function FocusParameters
--
-- @function [parent=#FocusParameters] FocusParameters

---
-- Function new
--
-- @function [parent=#FocusParameters] new
-- @return FocusParameters#FocusParameters

---
-- Function FocusParameters
--
-- @function [parent=#FocusParameters] FocusParameters
-- @param #boolean focusfocus
-- @param #boolean nonUniformnonUniform
-- @param #boolean autoSizeautoSize
-- @param #number quantizequantize
-- @param #number minViewminView

---
-- Function new
--
-- @function [parent=#FocusParameters] new
-- @param #boolean focusfocus
-- @param #boolean nonUniformnonUniform
-- @param #boolean autoSizeautoSize
-- @param #number quantizequantize
-- @param #number minViewminView
-- @return FocusParameters#FocusParameters

---
-- Function delete
--
-- @function [parent=#FocusParameters] delete


return nil
