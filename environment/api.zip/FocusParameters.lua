---
-- Module FocusParameters
-- Generated on 2014-03-13
--
-- @module FocusParameters

---
-- Function FocusParameters
--
-- @function [parent=#FocusParameters] FocusParameters
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#FocusParameters] new
-- @param self Self reference
-- @return FocusParameters#FocusParameters

---
-- Function FocusParameters
--
-- @function [parent=#FocusParameters] FocusParameters
-- @param self Self reference
-- @param #boolean focus focus
-- @param #boolean nonUniform nonUniform
-- @param #boolean autoSize autoSize
-- @param #number quantize quantize
-- @param #number minView minView

---
-- Function new
--
-- @function [parent=#FocusParameters] new
-- @param self Self reference
-- @param #boolean focus focus
-- @param #boolean nonUniform nonUniform
-- @param #boolean autoSize autoSize
-- @param #number quantize quantize
-- @param #number minView minView
-- @return FocusParameters#FocusParameters

---
-- Function delete
--
-- @function [parent=#FocusParameters] delete
-- @param self Self reference


return nil
