---
-- Module Sphere
--
-- @module Sphere

---
-- Function Sphere
--
-- @function [parent=#Sphere] Sphere

---
-- Function new
--
-- @function [parent=#Sphere] new
-- @return Sphere#Sphere

---
-- Function Sphere
--
-- @function [parent=#Sphere] Sphere
-- @param Sphere#Sphere spheresphere

---
-- Function new
--
-- @function [parent=#Sphere] new
-- @param Sphere#Sphere spheresphere
-- @return Sphere#Sphere

---
-- Function Sphere
--
-- @function [parent=#Sphere] Sphere
-- @param Vector3#Vector3 centercenter
-- @param #number radiusradius

---
-- Function new
--
-- @function [parent=#Sphere] new
-- @param Vector3#Vector3 centercenter
-- @param #number radiusradius
-- @return Sphere#Sphere

---
-- Function Sphere
--
-- @function [parent=#Sphere] Sphere
-- @param BoundingBox#BoundingBox boxbox

---
-- Function new
--
-- @function [parent=#Sphere] new
-- @param BoundingBox#BoundingBox boxbox
-- @return Sphere#Sphere

---
-- Function Sphere
--
-- @function [parent=#Sphere] Sphere
-- @param Frustum#Frustum frustumfrustum

---
-- Function new
--
-- @function [parent=#Sphere] new
-- @param Frustum#Frustum frustumfrustum
-- @return Sphere#Sphere

---
-- Function Sphere
--
-- @function [parent=#Sphere] Sphere
-- @param Polyhedron#Polyhedron polypoly

---
-- Function new
--
-- @function [parent=#Sphere] new
-- @param Polyhedron#Polyhedron polypoly
-- @return Sphere#Sphere

---
-- Function delete
--
-- @function [parent=#Sphere] delete

---
-- Function operator==
--
-- @function [parent=#Sphere] operator==
-- @param Sphere#Sphere rhsrhs
-- @return #boolean

---
-- Function Define
--
-- @function [parent=#Sphere] Define
-- @param Sphere#Sphere spheresphere

---
-- Function Define
--
-- @function [parent=#Sphere] Define
-- @param Vector3#Vector3 centercenter
-- @param #number radiusradius

---
-- Function Define
--
-- @function [parent=#Sphere] Define
-- @param BoundingBox#BoundingBox boxbox

---
-- Function Define
--
-- @function [parent=#Sphere] Define
-- @param Frustum#Frustum frustumfrustum

---
-- Function Define
--
-- @function [parent=#Sphere] Define
-- @param Polyhedron#Polyhedron polypoly

---
-- Function Merge
--
-- @function [parent=#Sphere] Merge
-- @param Vector3#Vector3 pointpoint

---
-- Function Merge
--
-- @function [parent=#Sphere] Merge
-- @param BoundingBox#BoundingBox boxbox

---
-- Function Merge
--
-- @function [parent=#Sphere] Merge
-- @param Frustum#Frustum frustumfrustum

---
-- Function Merge
--
-- @function [parent=#Sphere] Merge
-- @param Polyhedron#Polyhedron polypoly

---
-- Function Merge
--
-- @function [parent=#Sphere] Merge
-- @param Sphere#Sphere spheresphere

---
-- Function Clear
--
-- @function [parent=#Sphere] Clear

---
-- Function IsInside
--
-- @function [parent=#Sphere] IsInside
-- @param Vector3#Vector3 pointpoint
-- @return Intersection#Intersection

---
-- Function IsInside
--
-- @function [parent=#Sphere] IsInside
-- @param Sphere#Sphere spheresphere
-- @return Intersection#Intersection

---
-- Function IsInsideFast
--
-- @function [parent=#Sphere] IsInsideFast
-- @param Sphere#Sphere spheresphere
-- @return Intersection#Intersection

---
-- Function IsInside
--
-- @function [parent=#Sphere] IsInside
-- @param BoundingBox#BoundingBox boxbox
-- @return Intersection#Intersection

---
-- Function IsInsideFast
--
-- @function [parent=#Sphere] IsInsideFast
-- @param BoundingBox#BoundingBox boxbox
-- @return Intersection#Intersection

---
-- Function Distance
--
-- @function [parent=#Sphere] Distance
-- @param Vector3#Vector3 pointpoint
-- @return #number

---
-- Field center
--
-- @field [parent=#Sphere] Vector3#Vector3 center

---
-- Field radius
--
-- @field [parent=#Sphere] #number radius

---
-- Field defined
--
-- @field [parent=#Sphere] #boolean defined


return nil
