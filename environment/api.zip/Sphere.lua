---
-- Module Sphere
-- Generated on 2014-03-13
--
-- @module Sphere

---
-- Function Sphere
--
-- @function [parent=#Sphere] Sphere
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#Sphere] new
-- @param self Self reference
-- @return Sphere#Sphere

---
-- Function Sphere
--
-- @function [parent=#Sphere] Sphere
-- @param self Self reference
-- @param Sphere#Sphere sphere sphere

---
-- Function new
--
-- @function [parent=#Sphere] new
-- @param self Self reference
-- @param Sphere#Sphere sphere sphere
-- @return Sphere#Sphere

---
-- Function Sphere
--
-- @function [parent=#Sphere] Sphere
-- @param self Self reference
-- @param Vector3#Vector3 center center
-- @param #number radius radius

---
-- Function new
--
-- @function [parent=#Sphere] new
-- @param self Self reference
-- @param Vector3#Vector3 center center
-- @param #number radius radius
-- @return Sphere#Sphere

---
-- Function Sphere
--
-- @function [parent=#Sphere] Sphere
-- @param self Self reference
-- @param BoundingBox#BoundingBox box box

---
-- Function new
--
-- @function [parent=#Sphere] new
-- @param self Self reference
-- @param BoundingBox#BoundingBox box box
-- @return Sphere#Sphere

---
-- Function Sphere
--
-- @function [parent=#Sphere] Sphere
-- @param self Self reference
-- @param Frustum#Frustum frustum frustum

---
-- Function new
--
-- @function [parent=#Sphere] new
-- @param self Self reference
-- @param Frustum#Frustum frustum frustum
-- @return Sphere#Sphere

---
-- Function Sphere
--
-- @function [parent=#Sphere] Sphere
-- @param self Self reference
-- @param Polyhedron#Polyhedron poly poly

---
-- Function new
--
-- @function [parent=#Sphere] new
-- @param self Self reference
-- @param Polyhedron#Polyhedron poly poly
-- @return Sphere#Sphere

---
-- Function delete
--
-- @function [parent=#Sphere] delete
-- @param self Self reference

---
-- Function operator==
--
-- @function [parent=#Sphere] operator==
-- @param self Self reference
-- @param Sphere#Sphere rhs rhs
-- @return #boolean

---
-- Function Define
--
-- @function [parent=#Sphere] Define
-- @param self Self reference
-- @param Sphere#Sphere sphere sphere

---
-- Function Define
--
-- @function [parent=#Sphere] Define
-- @param self Self reference
-- @param Vector3#Vector3 center center
-- @param #number radius radius

---
-- Function Define
--
-- @function [parent=#Sphere] Define
-- @param self Self reference
-- @param BoundingBox#BoundingBox box box

---
-- Function Define
--
-- @function [parent=#Sphere] Define
-- @param self Self reference
-- @param Frustum#Frustum frustum frustum

---
-- Function Define
--
-- @function [parent=#Sphere] Define
-- @param self Self reference
-- @param Polyhedron#Polyhedron poly poly

---
-- Function Merge
--
-- @function [parent=#Sphere] Merge
-- @param self Self reference
-- @param Vector3#Vector3 point point

---
-- Function Merge
--
-- @function [parent=#Sphere] Merge
-- @param self Self reference
-- @param BoundingBox#BoundingBox box box

---
-- Function Merge
--
-- @function [parent=#Sphere] Merge
-- @param self Self reference
-- @param Frustum#Frustum frustum frustum

---
-- Function Merge
--
-- @function [parent=#Sphere] Merge
-- @param self Self reference
-- @param Polyhedron#Polyhedron poly poly

---
-- Function Merge
--
-- @function [parent=#Sphere] Merge
-- @param self Self reference
-- @param Sphere#Sphere sphere sphere

---
-- Function Clear
--
-- @function [parent=#Sphere] Clear
-- @param self Self reference

---
-- Function IsInside
--
-- @function [parent=#Sphere] IsInside
-- @param self Self reference
-- @param Vector3#Vector3 point point
-- @return Intersection#Intersection

---
-- Function IsInside
--
-- @function [parent=#Sphere] IsInside
-- @param self Self reference
-- @param Sphere#Sphere sphere sphere
-- @return Intersection#Intersection

---
-- Function IsInsideFast
--
-- @function [parent=#Sphere] IsInsideFast
-- @param self Self reference
-- @param Sphere#Sphere sphere sphere
-- @return Intersection#Intersection

---
-- Function IsInside
--
-- @function [parent=#Sphere] IsInside
-- @param self Self reference
-- @param BoundingBox#BoundingBox box box
-- @return Intersection#Intersection

---
-- Function IsInsideFast
--
-- @function [parent=#Sphere] IsInsideFast
-- @param self Self reference
-- @param BoundingBox#BoundingBox box box
-- @return Intersection#Intersection

---
-- Function Distance
--
-- @function [parent=#Sphere] Distance
-- @param self Self reference
-- @param Vector3#Vector3 point point
-- @return #number

---
-- Field center
--
-- @field [parent=#Sphere] Vector3#Vector3 center

---
-- Field radius
--
-- @field [parent=#Sphere] #number radius

---
-- Field defined
--
-- @field [parent=#Sphere] #boolean defined


return nil
