---
-- Module Vector3
--
-- @module Vector3

---
-- Function Vector3
--
-- @function [parent=#Vector3] Vector3

---
-- Function new
--
-- @function [parent=#Vector3] new
-- @return Vector3#Vector3

---
-- Function Vector3
--
-- @function [parent=#Vector3] Vector3
-- @param Vector3#Vector3 vectorvector

---
-- Function new
--
-- @function [parent=#Vector3] new
-- @param Vector3#Vector3 vectorvector
-- @return Vector3#Vector3

---
-- Function Vector3
--
-- @function [parent=#Vector3] Vector3
-- @param Vector2#Vector2 vectorvector
-- @param #number zz

---
-- Function new
--
-- @function [parent=#Vector3] new
-- @param Vector2#Vector2 vectorvector
-- @param #number zz
-- @return Vector3#Vector3

---
-- Function Vector3
--
-- @function [parent=#Vector3] Vector3
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function new
--
-- @function [parent=#Vector3] new
-- @param #number xx
-- @param #number yy
-- @param #number zz
-- @return Vector3#Vector3

---
-- Function delete
--
-- @function [parent=#Vector3] delete

---
-- Function operator==
--
-- @function [parent=#Vector3] operator==
-- @param Vector3#Vector3 rhsrhs
-- @return #boolean

---
-- Function operator+
--
-- @function [parent=#Vector3] operator+
-- @param Vector3#Vector3 rhsrhs
-- @return Vector3#Vector3

---
-- Function operator-
--
-- @function [parent=#Vector3] operator-
-- @return Vector3#Vector3

---
-- Function operator-
--
-- @function [parent=#Vector3] operator-
-- @param Vector3#Vector3 rhsrhs
-- @return Vector3#Vector3

---
-- Function operator*
--
-- @function [parent=#Vector3] operator*
-- @param #number rhsrhs
-- @return Vector3#Vector3

---
-- Function operator*
--
-- @function [parent=#Vector3] operator*
-- @param Vector3#Vector3 rhsrhs
-- @return Vector3#Vector3

---
-- Function operator/
--
-- @function [parent=#Vector3] operator/
-- @param #number rhsrhs
-- @return Vector3#Vector3

---
-- Function operator/
--
-- @function [parent=#Vector3] operator/
-- @param Vector3#Vector3 rhsrhs
-- @return Vector3#Vector3

---
-- Function operator/
--
-- @function [parent=#Vector3] operator/
-- @param Vector3#Vector3 rhsrhs
-- @return Vector3#Vector3

---
-- Function Normalize
--
-- @function [parent=#Vector3] Normalize

---
-- Function Length
--
-- @function [parent=#Vector3] Length
-- @return #number

---
-- Function LengthSquared
--
-- @function [parent=#Vector3] LengthSquared
-- @return #number

---
-- Function DotProduct
--
-- @function [parent=#Vector3] DotProduct
-- @param Vector3#Vector3 rhsrhs
-- @return #number

---
-- Function AbsDotProduct
--
-- @function [parent=#Vector3] AbsDotProduct
-- @param Vector3#Vector3 rhsrhs
-- @return #number

---
-- Function CrossProduct
--
-- @function [parent=#Vector3] CrossProduct
-- @param Vector3#Vector3 rhsrhs
-- @return Vector3#Vector3

---
-- Function Abs
--
-- @function [parent=#Vector3] Abs
-- @return Vector3#Vector3

---
-- Function Lerp
--
-- @function [parent=#Vector3] Lerp
-- @param Vector3#Vector3 rhsrhs
-- @param #number tt
-- @return Vector3#Vector3

---
-- Function Equals
--
-- @function [parent=#Vector3] Equals
-- @param Vector3#Vector3 rhsrhs
-- @return #boolean

---
-- Function Angle
--
-- @function [parent=#Vector3] Angle
-- @param Vector3#Vector3 rhsrhs
-- @return #number

---
-- Function Normalized
--
-- @function [parent=#Vector3] Normalized
-- @return Vector3#Vector3

---
-- Function ToString
--
-- @function [parent=#Vector3] ToString
-- @return #string

---
-- Field x
--
-- @field [parent=#Vector3] #number x

---
-- Field y
--
-- @field [parent=#Vector3] #number y

---
-- Field z
--
-- @field [parent=#Vector3] #number z

---
-- Field ZERO
--
-- @field [parent=#Vector3] Vector3#Vector3 ZERO

---
-- Field LEFT
--
-- @field [parent=#Vector3] Vector3#Vector3 LEFT

---
-- Field RIGHT
--
-- @field [parent=#Vector3] Vector3#Vector3 RIGHT

---
-- Field UP
--
-- @field [parent=#Vector3] Vector3#Vector3 UP

---
-- Field DOWN
--
-- @field [parent=#Vector3] Vector3#Vector3 DOWN

---
-- Field FORWARD
--
-- @field [parent=#Vector3] Vector3#Vector3 FORWARD

---
-- Field BACK
--
-- @field [parent=#Vector3] Vector3#Vector3 BACK

---
-- Field ONE
--
-- @field [parent=#Vector3] Vector3#Vector3 ONE


return nil
