---
-- Module Vector3
-- Generated on 2014-03-13
--
-- @module Vector3

---
-- Function Vector3
--
-- @function [parent=#Vector3] Vector3
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#Vector3] new
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function Vector3
--
-- @function [parent=#Vector3] Vector3
-- @param self Self reference
-- @param Vector3#Vector3 vector vector

---
-- Function new
--
-- @function [parent=#Vector3] new
-- @param self Self reference
-- @param Vector3#Vector3 vector vector
-- @return Vector3#Vector3

---
-- Function Vector3
--
-- @function [parent=#Vector3] Vector3
-- @param self Self reference
-- @param Vector2#Vector2 vector vector
-- @param #number z z

---
-- Function new
--
-- @function [parent=#Vector3] new
-- @param self Self reference
-- @param Vector2#Vector2 vector vector
-- @param #number z z
-- @return Vector3#Vector3

---
-- Function Vector3
--
-- @function [parent=#Vector3] Vector3
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function new
--
-- @function [parent=#Vector3] new
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z
-- @return Vector3#Vector3

---
-- Function delete
--
-- @function [parent=#Vector3] delete
-- @param self Self reference

---
-- Function operator==
--
-- @function [parent=#Vector3] operator==
-- @param self Self reference
-- @param Vector3#Vector3 rhs rhs
-- @return #boolean

---
-- Function operator+
--
-- @function [parent=#Vector3] operator+
-- @param self Self reference
-- @param Vector3#Vector3 rhs rhs
-- @return Vector3#Vector3

---
-- Function operator-
--
-- @function [parent=#Vector3] operator-
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function operator-
--
-- @function [parent=#Vector3] operator-
-- @param self Self reference
-- @param Vector3#Vector3 rhs rhs
-- @return Vector3#Vector3

---
-- Function operator*
--
-- @function [parent=#Vector3] operator*
-- @param self Self reference
-- @param #number rhs rhs
-- @return Vector3#Vector3

---
-- Function operator*
--
-- @function [parent=#Vector3] operator*
-- @param self Self reference
-- @param Vector3#Vector3 rhs rhs
-- @return Vector3#Vector3

---
-- Function operator/
--
-- @function [parent=#Vector3] operator/
-- @param self Self reference
-- @param #number rhs rhs
-- @return Vector3#Vector3

---
-- Function operator/
--
-- @function [parent=#Vector3] operator/
-- @param self Self reference
-- @param Vector3#Vector3 rhs rhs
-- @return Vector3#Vector3

---
-- Function operator/
--
-- @function [parent=#Vector3] operator/
-- @param self Self reference
-- @param Vector3#Vector3 rhs rhs
-- @return Vector3#Vector3

---
-- Function Normalize
--
-- @function [parent=#Vector3] Normalize
-- @param self Self reference

---
-- Function Length
--
-- @function [parent=#Vector3] Length
-- @param self Self reference
-- @return #number

---
-- Function LengthSquared
--
-- @function [parent=#Vector3] LengthSquared
-- @param self Self reference
-- @return #number

---
-- Function DotProduct
--
-- @function [parent=#Vector3] DotProduct
-- @param self Self reference
-- @param Vector3#Vector3 rhs rhs
-- @return #number

---
-- Function AbsDotProduct
--
-- @function [parent=#Vector3] AbsDotProduct
-- @param self Self reference
-- @param Vector3#Vector3 rhs rhs
-- @return #number

---
-- Function CrossProduct
--
-- @function [parent=#Vector3] CrossProduct
-- @param self Self reference
-- @param Vector3#Vector3 rhs rhs
-- @return Vector3#Vector3

---
-- Function Abs
--
-- @function [parent=#Vector3] Abs
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function Lerp
--
-- @function [parent=#Vector3] Lerp
-- @param self Self reference
-- @param Vector3#Vector3 rhs rhs
-- @param #number t t
-- @return Vector3#Vector3

---
-- Function Equals
--
-- @function [parent=#Vector3] Equals
-- @param self Self reference
-- @param Vector3#Vector3 rhs rhs
-- @return #boolean

---
-- Function Angle
--
-- @function [parent=#Vector3] Angle
-- @param self Self reference
-- @param Vector3#Vector3 rhs rhs
-- @return #number

---
-- Function Normalized
--
-- @function [parent=#Vector3] Normalized
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function ToString
--
-- @function [parent=#Vector3] ToString
-- @param self Self reference
-- @return #string

---
-- Field x
--
-- @field [parent=#Vector3] #number x

---
-- Field y
--
-- @field [parent=#Vector3] #number y

---
-- Field z
--
-- @field [parent=#Vector3] #number z

---
-- Field ZERO
--
-- @field [parent=#Vector3] Vector3#Vector3 ZERO

---
-- Field LEFT
--
-- @field [parent=#Vector3] Vector3#Vector3 LEFT

---
-- Field RIGHT
--
-- @field [parent=#Vector3] Vector3#Vector3 RIGHT

---
-- Field UP
--
-- @field [parent=#Vector3] Vector3#Vector3 UP

---
-- Field DOWN
--
-- @field [parent=#Vector3] Vector3#Vector3 DOWN

---
-- Field FORWARD
--
-- @field [parent=#Vector3] Vector3#Vector3 FORWARD

---
-- Field BACK
--
-- @field [parent=#Vector3] Vector3#Vector3 BACK

---
-- Field ONE
--
-- @field [parent=#Vector3] Vector3#Vector3 ONE


return nil
