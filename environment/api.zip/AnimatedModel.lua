---
-- Module AnimatedModel
-- Module AnimatedModel extends StaticModel
-- Generated on 2014-03-13
--
-- @module AnimatedModel

---
-- Function SetModel
--
-- @function [parent=#AnimatedModel] SetModel
-- @param self Self reference
-- @param Model#Model model model

---
-- Function AddAnimationState
--
-- @function [parent=#AnimatedModel] AddAnimationState
-- @param self Self reference
-- @param Animation#Animation animation animation
-- @return AnimationState#AnimationState

---
-- Function RemoveAnimationState
--
-- @function [parent=#AnimatedModel] RemoveAnimationState
-- @param self Self reference
-- @param Animation#Animation animation animation

---
-- Function RemoveAnimationState
--
-- @function [parent=#AnimatedModel] RemoveAnimationState
-- @param self Self reference
-- @param #string animationName animationName

---
-- Function RemoveAnimationState
--
-- @function [parent=#AnimatedModel] RemoveAnimationState
-- @param self Self reference
-- @param StringHash#StringHash animationNameHash animationNameHash

---
-- Function RemoveAnimationState
--
-- @function [parent=#AnimatedModel] RemoveAnimationState
-- @param self Self reference
-- @param AnimationState#AnimationState state state

---
-- Function RemoveAnimationState
--
-- @function [parent=#AnimatedModel] RemoveAnimationState
-- @param self Self reference
-- @param #number index index

---
-- Function RemoveAllAnimationStates
--
-- @function [parent=#AnimatedModel] RemoveAllAnimationStates
-- @param self Self reference

---
-- Function SetAnimationLodBias
--
-- @function [parent=#AnimatedModel] SetAnimationLodBias
-- @param self Self reference
-- @param #number bias bias

---
-- Function SetUpdateInvisible
--
-- @function [parent=#AnimatedModel] SetUpdateInvisible
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetMorphWeight
--
-- @function [parent=#AnimatedModel] SetMorphWeight
-- @param self Self reference
-- @param #string name name
-- @param #number weight weight

---
-- Function SetMorphWeight
--
-- @function [parent=#AnimatedModel] SetMorphWeight
-- @param self Self reference
-- @param StringHash#StringHash nameHash nameHash
-- @param #number weight weight

---
-- Function SetMorphWeight
--
-- @function [parent=#AnimatedModel] SetMorphWeight
-- @param self Self reference
-- @param #number index index
-- @param #number weight weight

---
-- Function ResetMorphWeights
--
-- @function [parent=#AnimatedModel] ResetMorphWeights
-- @param self Self reference

---
-- Function GetSkeleton
--
-- @function [parent=#AnimatedModel] GetSkeleton
-- @param self Self reference
-- @return Skeleton#Skeleton

---
-- Function GetNumAnimationStates
--
-- @function [parent=#AnimatedModel] GetNumAnimationStates
-- @param self Self reference
-- @return #number

---
-- Function GetAnimationState
--
-- @function [parent=#AnimatedModel] GetAnimationState
-- @param self Self reference
-- @param Animation#Animation animation animation
-- @return AnimationState#AnimationState

---
-- Function GetAnimationState
--
-- @function [parent=#AnimatedModel] GetAnimationState
-- @param self Self reference
-- @param #string animationName animationName
-- @return AnimationState#AnimationState

---
-- Function GetAnimationState
--
-- @function [parent=#AnimatedModel] GetAnimationState
-- @param self Self reference
-- @param StringHash#StringHash animationNameHash animationNameHash
-- @return AnimationState#AnimationState

---
-- Function GetAnimationState
--
-- @function [parent=#AnimatedModel] GetAnimationState
-- @param self Self reference
-- @param #number index index
-- @return AnimationState#AnimationState

---
-- Function GetAnimationLodBias
--
-- @function [parent=#AnimatedModel] GetAnimationLodBias
-- @param self Self reference
-- @return #number

---
-- Function GetUpdateInvisible
--
-- @function [parent=#AnimatedModel] GetUpdateInvisible
-- @param self Self reference
-- @return #boolean

---
-- Function GetNumMorphs
--
-- @function [parent=#AnimatedModel] GetNumMorphs
-- @param self Self reference
-- @return #number

---
-- Function GetMorphWeight
--
-- @function [parent=#AnimatedModel] GetMorphWeight
-- @param self Self reference
-- @param #string name name
-- @return #number

---
-- Function GetMorphWeight
--
-- @function [parent=#AnimatedModel] GetMorphWeight
-- @param self Self reference
-- @param StringHash#StringHash nameHash nameHash
-- @return #number

---
-- Function GetMorphWeight
--
-- @function [parent=#AnimatedModel] GetMorphWeight
-- @param self Self reference
-- @param #number index index
-- @return #number

---
-- Function IsMaster
--
-- @function [parent=#AnimatedModel] IsMaster
-- @param self Self reference
-- @return #boolean

---
-- Field model
--
-- @field [parent=#AnimatedModel] Model#Model model

---
-- Field skeleton (Read only)
--
-- @field [parent=#AnimatedModel] Skeleton#Skeleton skeleton

---
-- Field numAnimationStates (Read only)
--
-- @field [parent=#AnimatedModel] #number numAnimationStates

---
-- Field animationLodBias
--
-- @field [parent=#AnimatedModel] #number animationLodBias

---
-- Field updateInvisible
--
-- @field [parent=#AnimatedModel] #boolean updateInvisible

---
-- Field numMorphs (Read only)
--
-- @field [parent=#AnimatedModel] #number numMorphs

---
-- Field master (Read only)
--
-- @field [parent=#AnimatedModel] #boolean master

---
-- Function SetModel
--
-- @function [parent=#AnimatedModel] SetModel
-- @param self Self reference
-- @param Model#Model model model

---
-- Function SetMaterial
--
-- @function [parent=#AnimatedModel] SetMaterial
-- @param self Self reference
-- @param Material#Material material material

---
-- Function SetMaterial
--
-- @function [parent=#AnimatedModel] SetMaterial
-- @param self Self reference
-- @param #number index index
-- @param Material#Material material material
-- @return #boolean

---
-- Function SetOcclusionLodLevel
--
-- @function [parent=#AnimatedModel] SetOcclusionLodLevel
-- @param self Self reference
-- @param #number level level

---
-- Function ApplyMaterialList
--
-- @function [parent=#AnimatedModel] ApplyMaterialList
-- @param self Self reference
-- @param #string fileName fileName

---
-- Function GetModel
--
-- @function [parent=#AnimatedModel] GetModel
-- @param self Self reference
-- @return Model#Model

---
-- Function GetNumGeometries
--
-- @function [parent=#AnimatedModel] GetNumGeometries
-- @param self Self reference
-- @return #number

---
-- Function GetMaterial
--
-- @function [parent=#AnimatedModel] GetMaterial
-- @param self Self reference
-- @param #number index index
-- @return Material#Material

---
-- Function GetOcclusionLodLevel
--
-- @function [parent=#AnimatedModel] GetOcclusionLodLevel
-- @param self Self reference
-- @return #number

---
-- Function IsInside
--
-- @function [parent=#AnimatedModel] IsInside
-- @param self Self reference
-- @param Vector3#Vector3 point point
-- @return #boolean

---
-- Function IsInsideLocal
--
-- @function [parent=#AnimatedModel] IsInsideLocal
-- @param self Self reference
-- @param Vector3#Vector3 point point
-- @return #boolean

---
-- Field model
--
-- @field [parent=#AnimatedModel] Model#Model model

---
-- Field material
--
-- @field [parent=#AnimatedModel] Material#Material material

---
-- Field boundingBox (Read only)
--
-- @field [parent=#AnimatedModel] BoundingBox#BoundingBox boundingBox

---
-- Field numGeometries (Read only)
--
-- @field [parent=#AnimatedModel] #number numGeometries

---
-- Field occlusionLodLevel
--
-- @field [parent=#AnimatedModel] #number occlusionLodLevel

---
-- Function SetDrawDistance
--
-- @function [parent=#AnimatedModel] SetDrawDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetShadowDistance
--
-- @function [parent=#AnimatedModel] SetShadowDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetLodBias
--
-- @function [parent=#AnimatedModel] SetLodBias
-- @param self Self reference
-- @param #number bias bias

---
-- Function SetViewMask
--
-- @function [parent=#AnimatedModel] SetViewMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetLightMask
--
-- @function [parent=#AnimatedModel] SetLightMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetShadowMask
--
-- @function [parent=#AnimatedModel] SetShadowMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetZoneMask
--
-- @function [parent=#AnimatedModel] SetZoneMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetMaxLights
--
-- @function [parent=#AnimatedModel] SetMaxLights
-- @param self Self reference
-- @param #number num num

---
-- Function SetCastShadows
--
-- @function [parent=#AnimatedModel] SetCastShadows
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetOccluder
--
-- @function [parent=#AnimatedModel] SetOccluder
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetOccludee
--
-- @function [parent=#AnimatedModel] SetOccludee
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function MarkForUpdate
--
-- @function [parent=#AnimatedModel] MarkForUpdate
-- @param self Self reference

---
-- Function GetBoundingBox
--
-- @function [parent=#AnimatedModel] GetBoundingBox
-- @param self Self reference
-- @return const BoundingBox#const BoundingBox

---
-- Function GetWorldBoundingBox
--
-- @function [parent=#AnimatedModel] GetWorldBoundingBox
-- @param self Self reference
-- @return const BoundingBox#const BoundingBox

---
-- Function GetDrawableFlags
--
-- @function [parent=#AnimatedModel] GetDrawableFlags
-- @param self Self reference
-- @return #string

---
-- Function GetDrawDistance
--
-- @function [parent=#AnimatedModel] GetDrawDistance
-- @param self Self reference
-- @return #number

---
-- Function GetShadowDistance
--
-- @function [parent=#AnimatedModel] GetShadowDistance
-- @param self Self reference
-- @return #number

---
-- Function GetLodBias
--
-- @function [parent=#AnimatedModel] GetLodBias
-- @param self Self reference
-- @return #number

---
-- Function GetViewMask
--
-- @function [parent=#AnimatedModel] GetViewMask
-- @param self Self reference
-- @return #number

---
-- Function GetLightMask
--
-- @function [parent=#AnimatedModel] GetLightMask
-- @param self Self reference
-- @return #number

---
-- Function GetShadowMask
--
-- @function [parent=#AnimatedModel] GetShadowMask
-- @param self Self reference
-- @return #number

---
-- Function GetZoneMask
--
-- @function [parent=#AnimatedModel] GetZoneMask
-- @param self Self reference
-- @return #number

---
-- Function GetMaxLights
--
-- @function [parent=#AnimatedModel] GetMaxLights
-- @param self Self reference
-- @return #number

---
-- Function GetCastShadows
--
-- @function [parent=#AnimatedModel] GetCastShadows
-- @param self Self reference
-- @return #boolean

---
-- Function IsOccluder
--
-- @function [parent=#AnimatedModel] IsOccluder
-- @param self Self reference
-- @return #boolean

---
-- Function IsOccludee
--
-- @function [parent=#AnimatedModel] IsOccludee
-- @param self Self reference
-- @return #boolean

---
-- Function SetZone
--
-- @function [parent=#AnimatedModel] SetZone
-- @param self Self reference
-- @param Zone#Zone zone zone
-- @param #boolean temporary temporary

---
-- Function SetSortValue
--
-- @function [parent=#AnimatedModel] SetSortValue
-- @param self Self reference
-- @param #number value value

---
-- Function SetMinMaxZ
--
-- @function [parent=#AnimatedModel] SetMinMaxZ
-- @param self Self reference
-- @param #number minZ minZ
-- @param #number maxZ maxZ

---
-- Function MarkInView
--
-- @function [parent=#AnimatedModel] MarkInView
-- @param self Self reference
-- @param FrameInfo#FrameInfo frame frame
-- @param #boolean mainView mainView

---
-- Function ClearLights
--
-- @function [parent=#AnimatedModel] ClearLights
-- @param self Self reference

---
-- Function AddLight
--
-- @function [parent=#AnimatedModel] AddLight
-- @param self Self reference
-- @param Light#Light light light

---
-- Function AddVertexLight
--
-- @function [parent=#AnimatedModel] AddVertexLight
-- @param self Self reference
-- @param Light#Light light light

---
-- Function LimitLights
--
-- @function [parent=#AnimatedModel] LimitLights
-- @param self Self reference

---
-- Function LimitVertexLights
--
-- @function [parent=#AnimatedModel] LimitVertexLights
-- @param self Self reference

---
-- Function SetBasePass
--
-- @function [parent=#AnimatedModel] SetBasePass
-- @param self Self reference
-- @param #number batchIndex batchIndex

---
-- Function GetOctant
--
-- @function [parent=#AnimatedModel] GetOctant
-- @param self Self reference
-- @return Octant#Octant

---
-- Function GetZone
--
-- @function [parent=#AnimatedModel] GetZone
-- @param self Self reference
-- @return Zone#Zone

---
-- Function GetLastZone
--
-- @function [parent=#AnimatedModel] GetLastZone
-- @param self Self reference
-- @return Zone#Zone

---
-- Function IsZoneDirty
--
-- @function [parent=#AnimatedModel] IsZoneDirty
-- @param self Self reference
-- @return #boolean

---
-- Function GetDistance
--
-- @function [parent=#AnimatedModel] GetDistance
-- @param self Self reference
-- @return #number

---
-- Function GetLodDistance
--
-- @function [parent=#AnimatedModel] GetLodDistance
-- @param self Self reference
-- @return #number

---
-- Function GetSortValue
--
-- @function [parent=#AnimatedModel] GetSortValue
-- @param self Self reference
-- @return #number

---
-- Function IsInView
--
-- @function [parent=#AnimatedModel] IsInView
-- @param self Self reference
-- @param #number frameNumber frameNumber
-- @return #boolean

---
-- Function IsInView
--
-- @function [parent=#AnimatedModel] IsInView
-- @param self Self reference
-- @param FrameInfo#FrameInfo frame frame
-- @param #boolean mainView mainView
-- @return #boolean

---
-- Function HasBasePass
--
-- @function [parent=#AnimatedModel] HasBasePass
-- @param self Self reference
-- @param #number batchIndex batchIndex
-- @return #boolean

---
-- Function GetFirstLight
--
-- @function [parent=#AnimatedModel] GetFirstLight
-- @param self Self reference
-- @return Light#Light

---
-- Function GetMinZ
--
-- @function [parent=#AnimatedModel] GetMinZ
-- @param self Self reference
-- @return #number

---
-- Function GetMaxZ
--
-- @function [parent=#AnimatedModel] GetMaxZ
-- @param self Self reference
-- @return #number

---
-- Field worldBoundingBox (Read only)
--
-- @field [parent=#AnimatedModel] BoundingBox#BoundingBox worldBoundingBox

---
-- Field drawableFlags (Read only)
--
-- @field [parent=#AnimatedModel] #string drawableFlags

---
-- Field drawDistance
--
-- @field [parent=#AnimatedModel] #number drawDistance

---
-- Field shadowDistance
--
-- @field [parent=#AnimatedModel] #number shadowDistance

---
-- Field lodBias
--
-- @field [parent=#AnimatedModel] #number lodBias

---
-- Field viewMask
--
-- @field [parent=#AnimatedModel] #number viewMask

---
-- Field lightMask
--
-- @field [parent=#AnimatedModel] #number lightMask

---
-- Field shadowMask
--
-- @field [parent=#AnimatedModel] #number shadowMask

---
-- Field zoneMask
--
-- @field [parent=#AnimatedModel] #number zoneMask

---
-- Field maxLights
--
-- @field [parent=#AnimatedModel] #number maxLights

---
-- Field castShadows
--
-- @field [parent=#AnimatedModel] #boolean castShadows

---
-- Field occluder
--
-- @field [parent=#AnimatedModel] #boolean occluder

---
-- Field occludee
--
-- @field [parent=#AnimatedModel] #boolean occludee

---
-- Field octant (Read only)
--
-- @field [parent=#AnimatedModel] Octant#Octant octant

---
-- Field zone
--
-- @field [parent=#AnimatedModel] Zone#Zone zone

---
-- Field lastZone (Read only)
--
-- @field [parent=#AnimatedModel] Zone#Zone lastZone

---
-- Field zoneDirty (Read only)
--
-- @field [parent=#AnimatedModel] #boolean zoneDirty

---
-- Field distance (Read only)
--
-- @field [parent=#AnimatedModel] #number distance

---
-- Field lodDistance (Read only)
--
-- @field [parent=#AnimatedModel] #number lodDistance

---
-- Field sortValue
--
-- @field [parent=#AnimatedModel] #number sortValue

---
-- Field firstLight (Read only)
--
-- @field [parent=#AnimatedModel] Light#Light firstLight

---
-- Field minZ (Read only)
--
-- @field [parent=#AnimatedModel] #number minZ

---
-- Field maxZ (Read only)
--
-- @field [parent=#AnimatedModel] #number maxZ

---
-- Function SetEnabled
--
-- @function [parent=#AnimatedModel] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Remove
--
-- @function [parent=#AnimatedModel] Remove
-- @param self Self reference

---
-- Function GetID
--
-- @function [parent=#AnimatedModel] GetID
-- @param self Self reference
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#AnimatedModel] GetNode
-- @param self Self reference
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#AnimatedModel] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#AnimatedModel] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#AnimatedModel] IsEnabledEffective
-- @param self Self reference
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#AnimatedModel] GetComponent
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#AnimatedModel] GetComponent
-- @param self Self reference
-- @param #string type type
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#AnimatedModel] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#AnimatedModel] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#AnimatedModel] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#AnimatedModel] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#AnimatedModel] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#AnimatedModel] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#AnimatedModel] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#AnimatedModel] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#AnimatedModel] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#AnimatedModel] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#AnimatedModel] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#AnimatedModel] #string category


return nil
