---
-- Module AnimatedModel
-- extends StaticModel
--
-- @module AnimatedModel

---
-- Function SetModel
--
-- @function [parent=#AnimatedModel] SetModel
-- @param Model#Model modelmodel

---
-- Function AddAnimationState
--
-- @function [parent=#AnimatedModel] AddAnimationState
-- @param Animation#Animation animationanimation
-- @return AnimationState#AnimationState

---
-- Function RemoveAnimationState
--
-- @function [parent=#AnimatedModel] RemoveAnimationState
-- @param Animation#Animation animationanimation

---
-- Function RemoveAnimationState
--
-- @function [parent=#AnimatedModel] RemoveAnimationState
-- @param #string animationNameanimationName

---
-- Function RemoveAnimationState
--
-- @function [parent=#AnimatedModel] RemoveAnimationState
-- @param StringHash#StringHash animationNameHashanimationNameHash

---
-- Function RemoveAnimationState
--
-- @function [parent=#AnimatedModel] RemoveAnimationState
-- @param AnimationState#AnimationState statestate

---
-- Function RemoveAnimationState
--
-- @function [parent=#AnimatedModel] RemoveAnimationState
-- @param #number indexindex

---
-- Function RemoveAllAnimationStates
--
-- @function [parent=#AnimatedModel] RemoveAllAnimationStates

---
-- Function SetAnimationLodBias
--
-- @function [parent=#AnimatedModel] SetAnimationLodBias
-- @param #number biasbias

---
-- Function SetUpdateInvisible
--
-- @function [parent=#AnimatedModel] SetUpdateInvisible
-- @param #boolean enableenable

---
-- Function SetMorphWeight
--
-- @function [parent=#AnimatedModel] SetMorphWeight
-- @param #string namename
-- @param #number weightweight

---
-- Function SetMorphWeight
--
-- @function [parent=#AnimatedModel] SetMorphWeight
-- @param StringHash#StringHash nameHashnameHash
-- @param #number weightweight

---
-- Function SetMorphWeight
--
-- @function [parent=#AnimatedModel] SetMorphWeight
-- @param #number indexindex
-- @param #number weightweight

---
-- Function ResetMorphWeights
--
-- @function [parent=#AnimatedModel] ResetMorphWeights

---
-- Function GetSkeleton
--
-- @function [parent=#AnimatedModel] GetSkeleton
-- @return Skeleton#Skeleton

---
-- Function GetNumAnimationStates
--
-- @function [parent=#AnimatedModel] GetNumAnimationStates
-- @return #number

---
-- Function GetAnimationState
--
-- @function [parent=#AnimatedModel] GetAnimationState
-- @param Animation#Animation animationanimation
-- @return AnimationState#AnimationState

---
-- Function GetAnimationState
--
-- @function [parent=#AnimatedModel] GetAnimationState
-- @param #string animationNameanimationName
-- @return AnimationState#AnimationState

---
-- Function GetAnimationState
--
-- @function [parent=#AnimatedModel] GetAnimationState
-- @param StringHash#StringHash animationNameHashanimationNameHash
-- @return AnimationState#AnimationState

---
-- Function GetAnimationState
--
-- @function [parent=#AnimatedModel] GetAnimationState
-- @param #number indexindex
-- @return AnimationState#AnimationState

---
-- Function GetAnimationLodBias
--
-- @function [parent=#AnimatedModel] GetAnimationLodBias
-- @return #number

---
-- Function GetUpdateInvisible
--
-- @function [parent=#AnimatedModel] GetUpdateInvisible
-- @return #boolean

---
-- Function GetNumMorphs
--
-- @function [parent=#AnimatedModel] GetNumMorphs
-- @return #number

---
-- Function GetMorphWeight
--
-- @function [parent=#AnimatedModel] GetMorphWeight
-- @param #string namename
-- @return #number

---
-- Function GetMorphWeight
--
-- @function [parent=#AnimatedModel] GetMorphWeight
-- @param StringHash#StringHash nameHashnameHash
-- @return #number

---
-- Function GetMorphWeight
--
-- @function [parent=#AnimatedModel] GetMorphWeight
-- @param #number indexindex
-- @return #number

---
-- Function IsMaster
--
-- @function [parent=#AnimatedModel] IsMaster
-- @return #boolean

---
-- Field model
--
-- @field [parent=#AnimatedModel] Model#Model model

---
-- Field skeleton (Read only)
--
-- @field [parent=#AnimatedModel] Skeleton#Skeleton skeleton

---
-- Field numAnimationStates (Read only)
--
-- @field [parent=#AnimatedModel] #number numAnimationStates

---
-- Field animationLodBias
--
-- @field [parent=#AnimatedModel] #number animationLodBias

---
-- Field updateInvisible
--
-- @field [parent=#AnimatedModel] #boolean updateInvisible

---
-- Field numMorphs (Read only)
--
-- @field [parent=#AnimatedModel] #number numMorphs

---
-- Field master (Read only)
--
-- @field [parent=#AnimatedModel] #boolean master

---
-- Function SetModel
--
-- @function [parent=#AnimatedModel] SetModel
-- @param Model#Model modelmodel

---
-- Function SetMaterial
--
-- @function [parent=#AnimatedModel] SetMaterial
-- @param Material#Material materialmaterial

---
-- Function SetMaterial
--
-- @function [parent=#AnimatedModel] SetMaterial
-- @param #number indexindex
-- @param Material#Material materialmaterial
-- @return #boolean

---
-- Function SetOcclusionLodLevel
--
-- @function [parent=#AnimatedModel] SetOcclusionLodLevel
-- @param #number levellevel

---
-- Function ApplyMaterialList
--
-- @function [parent=#AnimatedModel] ApplyMaterialList
-- @param #string fileNamefileName

---
-- Function GetModel
--
-- @function [parent=#AnimatedModel] GetModel
-- @return Model#Model

---
-- Function GetNumGeometries
--
-- @function [parent=#AnimatedModel] GetNumGeometries
-- @return #number

---
-- Function GetMaterial
--
-- @function [parent=#AnimatedModel] GetMaterial
-- @param #number indexindex
-- @return Material#Material

---
-- Function GetOcclusionLodLevel
--
-- @function [parent=#AnimatedModel] GetOcclusionLodLevel
-- @return #number

---
-- Function IsInside
--
-- @function [parent=#AnimatedModel] IsInside
-- @param Vector3#Vector3 pointpoint
-- @return #boolean

---
-- Function IsInsideLocal
--
-- @function [parent=#AnimatedModel] IsInsideLocal
-- @param Vector3#Vector3 pointpoint
-- @return #boolean

---
-- Field model
--
-- @field [parent=#AnimatedModel] Model#Model model

---
-- Field material
--
-- @field [parent=#AnimatedModel] Material#Material material

---
-- Field boundingBox (Read only)
--
-- @field [parent=#AnimatedModel] BoundingBox#BoundingBox boundingBox

---
-- Field numGeometries (Read only)
--
-- @field [parent=#AnimatedModel] #number numGeometries

---
-- Field occlusionLodLevel
--
-- @field [parent=#AnimatedModel] #number occlusionLodLevel

---
-- Function SetDrawDistance
--
-- @function [parent=#AnimatedModel] SetDrawDistance
-- @param #number distancedistance

---
-- Function SetShadowDistance
--
-- @function [parent=#AnimatedModel] SetShadowDistance
-- @param #number distancedistance

---
-- Function SetLodBias
--
-- @function [parent=#AnimatedModel] SetLodBias
-- @param #number biasbias

---
-- Function SetViewMask
--
-- @function [parent=#AnimatedModel] SetViewMask
-- @param #number maskmask

---
-- Function SetLightMask
--
-- @function [parent=#AnimatedModel] SetLightMask
-- @param #number maskmask

---
-- Function SetShadowMask
--
-- @function [parent=#AnimatedModel] SetShadowMask
-- @param #number maskmask

---
-- Function SetZoneMask
--
-- @function [parent=#AnimatedModel] SetZoneMask
-- @param #number maskmask

---
-- Function SetMaxLights
--
-- @function [parent=#AnimatedModel] SetMaxLights
-- @param #number numnum

---
-- Function SetCastShadows
--
-- @function [parent=#AnimatedModel] SetCastShadows
-- @param #boolean enableenable

---
-- Function SetOccluder
--
-- @function [parent=#AnimatedModel] SetOccluder
-- @param #boolean enableenable

---
-- Function SetOccludee
--
-- @function [parent=#AnimatedModel] SetOccludee
-- @param #boolean enableenable

---
-- Function MarkForUpdate
--
-- @function [parent=#AnimatedModel] MarkForUpdate

---
-- Function GetBoundingBox
--
-- @function [parent=#AnimatedModel] GetBoundingBox
-- @return const BoundingBox#const BoundingBox

---
-- Function GetWorldBoundingBox
--
-- @function [parent=#AnimatedModel] GetWorldBoundingBox
-- @return const BoundingBox#const BoundingBox

---
-- Function GetDrawableFlags
--
-- @function [parent=#AnimatedModel] GetDrawableFlags
-- @return #string

---
-- Function GetDrawDistance
--
-- @function [parent=#AnimatedModel] GetDrawDistance
-- @return #number

---
-- Function GetShadowDistance
--
-- @function [parent=#AnimatedModel] GetShadowDistance
-- @return #number

---
-- Function GetLodBias
--
-- @function [parent=#AnimatedModel] GetLodBias
-- @return #number

---
-- Function GetViewMask
--
-- @function [parent=#AnimatedModel] GetViewMask
-- @return #number

---
-- Function GetLightMask
--
-- @function [parent=#AnimatedModel] GetLightMask
-- @return #number

---
-- Function GetShadowMask
--
-- @function [parent=#AnimatedModel] GetShadowMask
-- @return #number

---
-- Function GetZoneMask
--
-- @function [parent=#AnimatedModel] GetZoneMask
-- @return #number

---
-- Function GetMaxLights
--
-- @function [parent=#AnimatedModel] GetMaxLights
-- @return #number

---
-- Function GetCastShadows
--
-- @function [parent=#AnimatedModel] GetCastShadows
-- @return #boolean

---
-- Function IsOccluder
--
-- @function [parent=#AnimatedModel] IsOccluder
-- @return #boolean

---
-- Function IsOccludee
--
-- @function [parent=#AnimatedModel] IsOccludee
-- @return #boolean

---
-- Function SetZone
--
-- @function [parent=#AnimatedModel] SetZone
-- @param Zone#Zone zonezone
-- @param #boolean temporarytemporary

---
-- Function SetSortValue
--
-- @function [parent=#AnimatedModel] SetSortValue
-- @param #number valuevalue

---
-- Function SetMinMaxZ
--
-- @function [parent=#AnimatedModel] SetMinMaxZ
-- @param #number minZminZ
-- @param #number maxZmaxZ

---
-- Function MarkInView
--
-- @function [parent=#AnimatedModel] MarkInView
-- @param FrameInfo#FrameInfo frameframe
-- @param #boolean mainViewmainView

---
-- Function ClearLights
--
-- @function [parent=#AnimatedModel] ClearLights

---
-- Function AddLight
--
-- @function [parent=#AnimatedModel] AddLight
-- @param Light#Light lightlight

---
-- Function AddVertexLight
--
-- @function [parent=#AnimatedModel] AddVertexLight
-- @param Light#Light lightlight

---
-- Function LimitLights
--
-- @function [parent=#AnimatedModel] LimitLights

---
-- Function LimitVertexLights
--
-- @function [parent=#AnimatedModel] LimitVertexLights

---
-- Function SetBasePass
--
-- @function [parent=#AnimatedModel] SetBasePass
-- @param #number batchIndexbatchIndex

---
-- Function GetOctant
--
-- @function [parent=#AnimatedModel] GetOctant
-- @return Octant#Octant

---
-- Function GetZone
--
-- @function [parent=#AnimatedModel] GetZone
-- @return Zone#Zone

---
-- Function GetLastZone
--
-- @function [parent=#AnimatedModel] GetLastZone
-- @return Zone#Zone

---
-- Function IsZoneDirty
--
-- @function [parent=#AnimatedModel] IsZoneDirty
-- @return #boolean

---
-- Function GetDistance
--
-- @function [parent=#AnimatedModel] GetDistance
-- @return #number

---
-- Function GetLodDistance
--
-- @function [parent=#AnimatedModel] GetLodDistance
-- @return #number

---
-- Function GetSortValue
--
-- @function [parent=#AnimatedModel] GetSortValue
-- @return #number

---
-- Function IsInView
--
-- @function [parent=#AnimatedModel] IsInView
-- @param #number frameNumberframeNumber
-- @return #boolean

---
-- Function IsInView
--
-- @function [parent=#AnimatedModel] IsInView
-- @param FrameInfo#FrameInfo frameframe
-- @param #boolean mainViewmainView
-- @return #boolean

---
-- Function HasBasePass
--
-- @function [parent=#AnimatedModel] HasBasePass
-- @param #number batchIndexbatchIndex
-- @return #boolean

---
-- Function GetFirstLight
--
-- @function [parent=#AnimatedModel] GetFirstLight
-- @return Light#Light

---
-- Function GetMinZ
--
-- @function [parent=#AnimatedModel] GetMinZ
-- @return #number

---
-- Function GetMaxZ
--
-- @function [parent=#AnimatedModel] GetMaxZ
-- @return #number

---
-- Field worldBoundingBox (Read only)
--
-- @field [parent=#AnimatedModel] BoundingBox#BoundingBox worldBoundingBox

---
-- Field drawableFlags (Read only)
--
-- @field [parent=#AnimatedModel] #string drawableFlags

---
-- Field drawDistance
--
-- @field [parent=#AnimatedModel] #number drawDistance

---
-- Field shadowDistance
--
-- @field [parent=#AnimatedModel] #number shadowDistance

---
-- Field lodBias
--
-- @field [parent=#AnimatedModel] #number lodBias

---
-- Field viewMask
--
-- @field [parent=#AnimatedModel] #number viewMask

---
-- Field lightMask
--
-- @field [parent=#AnimatedModel] #number lightMask

---
-- Field shadowMask
--
-- @field [parent=#AnimatedModel] #number shadowMask

---
-- Field zoneMask
--
-- @field [parent=#AnimatedModel] #number zoneMask

---
-- Field maxLights
--
-- @field [parent=#AnimatedModel] #number maxLights

---
-- Field castShadows
--
-- @field [parent=#AnimatedModel] #boolean castShadows

---
-- Field occluder
--
-- @field [parent=#AnimatedModel] #boolean occluder

---
-- Field occludee
--
-- @field [parent=#AnimatedModel] #boolean occludee

---
-- Field octant (Read only)
--
-- @field [parent=#AnimatedModel] Octant#Octant octant

---
-- Field zone
--
-- @field [parent=#AnimatedModel] Zone#Zone zone

---
-- Field lastZone (Read only)
--
-- @field [parent=#AnimatedModel] Zone#Zone lastZone

---
-- Field zoneDirty (Read only)
--
-- @field [parent=#AnimatedModel] #boolean zoneDirty

---
-- Field distance (Read only)
--
-- @field [parent=#AnimatedModel] #number distance

---
-- Field lodDistance (Read only)
--
-- @field [parent=#AnimatedModel] #number lodDistance

---
-- Field sortValue
--
-- @field [parent=#AnimatedModel] #number sortValue

---
-- Field firstLight (Read only)
--
-- @field [parent=#AnimatedModel] Light#Light firstLight

---
-- Field minZ (Read only)
--
-- @field [parent=#AnimatedModel] #number minZ

---
-- Field maxZ (Read only)
--
-- @field [parent=#AnimatedModel] #number maxZ

---
-- Function SetEnabled
--
-- @function [parent=#AnimatedModel] SetEnabled
-- @param #boolean enableenable

---
-- Function Remove
--
-- @function [parent=#AnimatedModel] Remove

---
-- Function GetID
--
-- @function [parent=#AnimatedModel] GetID
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#AnimatedModel] GetNode
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#AnimatedModel] GetScene
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#AnimatedModel] IsEnabled
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#AnimatedModel] IsEnabledEffective
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#AnimatedModel] GetComponent
-- @param ShortStringHash#ShortStringHash typetype
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#AnimatedModel] GetComponent
-- @param #string typetype
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#AnimatedModel] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#AnimatedModel] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#AnimatedModel] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#AnimatedModel] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#AnimatedModel] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#AnimatedModel] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#AnimatedModel] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#AnimatedModel] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#AnimatedModel] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#AnimatedModel] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#AnimatedModel] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#AnimatedModel] #string category


return nil
