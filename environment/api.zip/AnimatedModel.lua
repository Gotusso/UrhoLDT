---
-- Module AnimatedModel
-- Extends StaticModel
--
-- @module AnimatedModel

---
-- Function SetModel
--
-- @function [parent=#AnimatedModel] SetModel
-- @param Model#Model modelmodel

---
-- Function AddAnimationState
--
-- @function [parent=#AnimatedModel] AddAnimationState
-- @param Animation#Animation animationanimation
-- @return AnimationState#AnimationState

---
-- Function RemoveAnimationState
--
-- @function [parent=#AnimatedModel] RemoveAnimationState
-- @param Animation#Animation animationanimation

---
-- Function RemoveAnimationState
--
-- @function [parent=#AnimatedModel] RemoveAnimationState
-- @param #string animationNameanimationName

---
-- Function RemoveAnimationState
--
-- @function [parent=#AnimatedModel] RemoveAnimationState
-- @param StringHash#StringHash animationNameHashanimationNameHash

---
-- Function RemoveAnimationState
--
-- @function [parent=#AnimatedModel] RemoveAnimationState
-- @param AnimationState#AnimationState statestate

---
-- Function RemoveAnimationState
--
-- @function [parent=#AnimatedModel] RemoveAnimationState
-- @param #number indexindex

---
-- Function RemoveAllAnimationStates
--
-- @function [parent=#AnimatedModel] RemoveAllAnimationStates

---
-- Function SetAnimationLodBias
--
-- @function [parent=#AnimatedModel] SetAnimationLodBias
-- @param #number biasbias

---
-- Function SetUpdateInvisible
--
-- @function [parent=#AnimatedModel] SetUpdateInvisible
-- @param #boolean enableenable

---
-- Function SetMorphWeight
--
-- @function [parent=#AnimatedModel] SetMorphWeight
-- @param #string namename
-- @param #number weightweight

---
-- Function SetMorphWeight
--
-- @function [parent=#AnimatedModel] SetMorphWeight
-- @param StringHash#StringHash nameHashnameHash
-- @param #number weightweight

---
-- Function SetMorphWeight
--
-- @function [parent=#AnimatedModel] SetMorphWeight
-- @param #number indexindex
-- @param #number weightweight

---
-- Function ResetMorphWeights
--
-- @function [parent=#AnimatedModel] ResetMorphWeights

---
-- Function GetSkeleton
--
-- @function [parent=#AnimatedModel] GetSkeleton
-- @return Skeleton#Skeleton

---
-- Function GetNumAnimationStates
--
-- @function [parent=#AnimatedModel] GetNumAnimationStates
-- @return #number

---
-- Function GetAnimationState
--
-- @function [parent=#AnimatedModel] GetAnimationState
-- @param Animation#Animation animationanimation
-- @return AnimationState#AnimationState

---
-- Function GetAnimationState
--
-- @function [parent=#AnimatedModel] GetAnimationState
-- @param #string animationNameanimationName
-- @return AnimationState#AnimationState

---
-- Function GetAnimationState
--
-- @function [parent=#AnimatedModel] GetAnimationState
-- @param StringHash#StringHash animationNameHashanimationNameHash
-- @return AnimationState#AnimationState

---
-- Function GetAnimationState
--
-- @function [parent=#AnimatedModel] GetAnimationState
-- @param #number indexindex
-- @return AnimationState#AnimationState

---
-- Function GetAnimationLodBias
--
-- @function [parent=#AnimatedModel] GetAnimationLodBias
-- @return #number

---
-- Function GetUpdateInvisible
--
-- @function [parent=#AnimatedModel] GetUpdateInvisible
-- @return #boolean

---
-- Function GetNumMorphs
--
-- @function [parent=#AnimatedModel] GetNumMorphs
-- @return #number

---
-- Function GetMorphWeight
--
-- @function [parent=#AnimatedModel] GetMorphWeight
-- @param #string namename
-- @return #number

---
-- Function GetMorphWeight
--
-- @function [parent=#AnimatedModel] GetMorphWeight
-- @param StringHash#StringHash nameHashnameHash
-- @return #number

---
-- Function GetMorphWeight
--
-- @function [parent=#AnimatedModel] GetMorphWeight
-- @param #number indexindex
-- @return #number

---
-- Function IsMaster
--
-- @function [parent=#AnimatedModel] IsMaster
-- @return #boolean

---
-- Field model
--
-- @field [parent=#AnimatedModel] Model#Model model

---
-- Field skeleton (Read only)
--
-- @field [parent=#AnimatedModel] Skeleton#Skeleton skeleton

---
-- Field numAnimationStates (Read only)
--
-- @field [parent=#AnimatedModel] #number numAnimationStates

---
-- Field animationLodBias
--
-- @field [parent=#AnimatedModel] #number animationLodBias

---
-- Field updateInvisible
--
-- @field [parent=#AnimatedModel] #boolean updateInvisible

---
-- Field numMorphs (Read only)
--
-- @field [parent=#AnimatedModel] #number numMorphs

---
-- Field master (Read only)
--
-- @field [parent=#AnimatedModel] #boolean master


return nil
