---
-- Module AnimatedModel
-- Module AnimatedModel extends StaticModel
-- Generated on 2014-05-31
--
-- @module AnimatedModel

---
-- Function SetModel()
-- Set model.
--
-- @function [parent=#AnimatedModel] SetModel
-- @param self Self reference
-- @param Model#Model model model

---
-- Function AddAnimationState()
-- Add an animation.
--
-- @function [parent=#AnimatedModel] AddAnimationState
-- @param self Self reference
-- @param Animation#Animation animation animation
-- @return AnimationState#AnimationState

---
-- Function RemoveAnimationState()
-- Remove an animation by animation pointer.
--
-- @function [parent=#AnimatedModel] RemoveAnimationState
-- @param self Self reference
-- @param Animation#Animation animation animation

---
-- Function RemoveAnimationState()
-- Remove an animation by animation name.
--
-- @function [parent=#AnimatedModel] RemoveAnimationState
-- @param self Self reference
-- @param #string animationName animationName

---
-- Function RemoveAnimationState()
-- Remove an animation by animation name hash.
--
-- @function [parent=#AnimatedModel] RemoveAnimationState
-- @param self Self reference
-- @param StringHash#StringHash animationNameHash animationNameHash

---
-- Function RemoveAnimationState()
-- Remove an animation by AnimationState pointer.
--
-- @function [parent=#AnimatedModel] RemoveAnimationState
-- @param self Self reference
-- @param AnimationState#AnimationState state state

---
-- Function RemoveAnimationState()
-- Remove an animation by index.
--
-- @function [parent=#AnimatedModel] RemoveAnimationState
-- @param self Self reference
-- @param #number index index

---
-- Function RemoveAllAnimationStates()
-- Remove all animations.
--
-- @function [parent=#AnimatedModel] RemoveAllAnimationStates
-- @param self Self reference

---
-- Function SetAnimationLodBias()
-- Set animation LOD bias.
--
-- @function [parent=#AnimatedModel] SetAnimationLodBias
-- @param self Self reference
-- @param #number bias bias

---
-- Function SetUpdateInvisible()
-- Set whether to update animation and the bounding box when not visible. Recommended to enable for physically controlled models like ragdolls.
--
-- @function [parent=#AnimatedModel] SetUpdateInvisible
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetMorphWeight()
-- Set vertex morph weight by name.
--
-- @function [parent=#AnimatedModel] SetMorphWeight
-- @param self Self reference
-- @param #string name name
-- @param #number weight weight

---
-- Function SetMorphWeight()
-- Set vertex morph weight by name hash.
--
-- @function [parent=#AnimatedModel] SetMorphWeight
-- @param self Self reference
-- @param StringHash#StringHash nameHash nameHash
-- @param #number weight weight

---
-- Function SetMorphWeight()
-- Set vertex morph weight by index.
--
-- @function [parent=#AnimatedModel] SetMorphWeight
-- @param self Self reference
-- @param #number index index
-- @param #number weight weight

---
-- Function ResetMorphWeights()
-- Reset all vertex morphs to zero.
--
-- @function [parent=#AnimatedModel] ResetMorphWeights
-- @param self Self reference

---
-- Function GetSkeleton()
-- Return skeleton.
--
-- @function [parent=#AnimatedModel] GetSkeleton
-- @param self Self reference
-- @return Skeleton#Skeleton

---
-- Function GetNumAnimationStates()
-- Return number of animation states.
--
-- @function [parent=#AnimatedModel] GetNumAnimationStates
-- @param self Self reference
-- @return #number

---
-- Function GetAnimationState()
-- Return animation state by animation pointer.
--
-- @function [parent=#AnimatedModel] GetAnimationState
-- @param self Self reference
-- @param Animation#Animation animation animation
-- @return AnimationState#AnimationState

---
-- Function GetAnimationState()
-- Return animation state by animation name.
--
-- @function [parent=#AnimatedModel] GetAnimationState
-- @param self Self reference
-- @param #string animationName animationName
-- @return AnimationState#AnimationState

---
-- Function GetAnimationState()
-- Return animation state by animation name hash.
--
-- @function [parent=#AnimatedModel] GetAnimationState
-- @param self Self reference
-- @param StringHash#StringHash animationNameHash animationNameHash
-- @return AnimationState#AnimationState

---
-- Function GetAnimationState()
-- Return animation state by index.
--
-- @function [parent=#AnimatedModel] GetAnimationState
-- @param self Self reference
-- @param #number index index
-- @return AnimationState#AnimationState

---
-- Function GetAnimationLodBias()
-- Return animation LOD bias.
--
-- @function [parent=#AnimatedModel] GetAnimationLodBias
-- @param self Self reference
-- @return #number

---
-- Function GetUpdateInvisible()
-- Return whether to update animation when not visible.
--
-- @function [parent=#AnimatedModel] GetUpdateInvisible
-- @param self Self reference
-- @return #boolean

---
-- Function GetNumMorphs()
-- Return number of vertex morphs.
--
-- @function [parent=#AnimatedModel] GetNumMorphs
-- @param self Self reference
-- @return #number

---
-- Function GetMorphWeight()
-- Return vertex morph weight by name.
--
-- @function [parent=#AnimatedModel] GetMorphWeight
-- @param self Self reference
-- @param #string name name
-- @return #number

---
-- Function GetMorphWeight()
-- Return vertex morph weight by name hash.
--
-- @function [parent=#AnimatedModel] GetMorphWeight
-- @param self Self reference
-- @param StringHash#StringHash nameHash nameHash
-- @return #number

---
-- Function GetMorphWeight()
-- Return vertex morph weight by index.
--
-- @function [parent=#AnimatedModel] GetMorphWeight
-- @param self Self reference
-- @param #number index index
-- @return #number

---
-- Function IsMaster()
-- Return whether is the master (first) animated model.
--
-- @function [parent=#AnimatedModel] IsMaster
-- @param self Self reference
-- @return #boolean

---
-- Field model
--
-- @field [parent=#AnimatedModel] Model#Model model

---
-- Field skeleton (Read only)
--
-- @field [parent=#AnimatedModel] Skeleton#Skeleton skeleton

---
-- Field numAnimationStates (Read only)
--
-- @field [parent=#AnimatedModel] #number numAnimationStates

---
-- Field animationLodBias
--
-- @field [parent=#AnimatedModel] #number animationLodBias

---
-- Field updateInvisible
--
-- @field [parent=#AnimatedModel] #boolean updateInvisible

---
-- Field numMorphs (Read only)
--
-- @field [parent=#AnimatedModel] #number numMorphs

---
-- Field master (Read only)
--
-- @field [parent=#AnimatedModel] #boolean master


return nil
