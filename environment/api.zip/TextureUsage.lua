---
-- Enumeration TextureUsage
--
-- @module TextureUsage

---
-- Enumeration value TEXTURE_STATIC
--
-- @field [parent=#TextureUsage] #number TEXTURE_STATIC

---
-- Enumeration value TEXTURE_DYNAMIC
--
-- @field [parent=#TextureUsage] #number TEXTURE_DYNAMIC

---
-- Enumeration value TEXTURE_RENDERTARGET
--
-- @field [parent=#TextureUsage] #number TEXTURE_RENDERTARGET

---
-- Enumeration value TEXTURE_DEPTHSTENCIL
--
-- @field [parent=#TextureUsage] #number TEXTURE_DEPTHSTENCIL


return nil
