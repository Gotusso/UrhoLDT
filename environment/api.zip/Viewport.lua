---
-- Module Viewport
-- Generated on 2014-05-31
--
-- @module Viewport

---
-- Function Viewport()
--
-- @function [parent=#Viewport] Viewport
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#Viewport] new
-- @param self Self reference
-- @return Viewport#Viewport

---
-- Function Viewport()
--
-- @function [parent=#Viewport] Viewport
-- @param self Self reference
-- @param Scene#Scene scene scene
-- @param Camera#Camera camera camera
-- @param RenderPath#RenderPath renderPath renderPath

---
-- Function new()
--
-- @function [parent=#Viewport] new
-- @param self Self reference
-- @param Scene#Scene scene scene
-- @param Camera#Camera camera camera
-- @param RenderPath#RenderPath renderPath renderPath
-- @return Viewport#Viewport

---
-- Function Viewport()
--
-- @function [parent=#Viewport] Viewport
-- @param self Self reference
-- @param Scene#Scene scene scene
-- @param Camera#Camera camera camera
-- @param IntRect#IntRect rect rect
-- @param RenderPath#RenderPath renderPath renderPath

---
-- Function new()
--
-- @function [parent=#Viewport] new
-- @param self Self reference
-- @param Scene#Scene scene scene
-- @param Camera#Camera camera camera
-- @param IntRect#IntRect rect rect
-- @param RenderPath#RenderPath renderPath renderPath
-- @return Viewport#Viewport

---
-- Function delete()
--
-- @function [parent=#Viewport] delete
-- @param self Self reference

---
-- Function SetScene()
-- Set scene.
--
-- @function [parent=#Viewport] SetScene
-- @param self Self reference
-- @param Scene#Scene scene scene

---
-- Function SetCamera()
-- Set camera.
--
-- @function [parent=#Viewport] SetCamera
-- @param self Self reference
-- @param Camera#Camera camera camera

---
-- Function SetRect()
-- Set rectangle.
--
-- @function [parent=#Viewport] SetRect
-- @param self Self reference
-- @param IntRect#IntRect rect rect

---
-- Function SetRenderPath()
-- Set rendering path.
--
-- @function [parent=#Viewport] SetRenderPath
-- @param self Self reference
-- @param RenderPath#RenderPath path path

---
-- Function SetRenderPath()
-- Set rendering path from an XML file.
--
-- @function [parent=#Viewport] SetRenderPath
-- @param self Self reference
-- @param XMLFile#XMLFile file file

---
-- Function GetScene()
-- Return scene.
--
-- @function [parent=#Viewport] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function GetCamera()
-- Return camera.
--
-- @function [parent=#Viewport] GetCamera
-- @param self Self reference
-- @return Camera#Camera

---
-- Function GetRect()
-- Return rectangle.
--
-- @function [parent=#Viewport] GetRect
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetRenderPath()
-- Return rendering path.
--
-- @function [parent=#Viewport] GetRenderPath
-- @param self Self reference
-- @return RenderPath#RenderPath

---
-- Field scene
--
-- @field [parent=#Viewport] Scene#Scene scene

---
-- Field camera
--
-- @field [parent=#Viewport] Camera#Camera camera

---
-- Field rect
--
-- @field [parent=#Viewport] IntRect#IntRect rect

---
-- Field renderPath
--
-- @field [parent=#Viewport] RenderPath#RenderPath renderPath


return nil
