---
-- Module Viewport
--
-- @module Viewport

---
-- Function Viewport
--
-- @function [parent=#Viewport] Viewport

---
-- Function new
--
-- @function [parent=#Viewport] new
-- @return Viewport#Viewport

---
-- Function Viewport
--
-- @function [parent=#Viewport] Viewport
-- @param Scene#Scene scenescene
-- @param Camera#Camera cameracamera
-- @param RenderPath#RenderPath renderPathrenderPath

---
-- Function new
--
-- @function [parent=#Viewport] new
-- @param Scene#Scene scenescene
-- @param Camera#Camera cameracamera
-- @param RenderPath#RenderPath renderPathrenderPath
-- @return Viewport#Viewport

---
-- Function Viewport
--
-- @function [parent=#Viewport] Viewport
-- @param Scene#Scene scenescene
-- @param Camera#Camera cameracamera
-- @param IntRect#IntRect rectrect
-- @param RenderPath#RenderPath renderPathrenderPath

---
-- Function new
--
-- @function [parent=#Viewport] new
-- @param Scene#Scene scenescene
-- @param Camera#Camera cameracamera
-- @param IntRect#IntRect rectrect
-- @param RenderPath#RenderPath renderPathrenderPath
-- @return Viewport#Viewport

---
-- Function delete
--
-- @function [parent=#Viewport] delete

---
-- Function SetScene
--
-- @function [parent=#Viewport] SetScene
-- @param Scene#Scene scenescene

---
-- Function SetCamera
--
-- @function [parent=#Viewport] SetCamera
-- @param Camera#Camera cameracamera

---
-- Function SetRect
--
-- @function [parent=#Viewport] SetRect
-- @param IntRect#IntRect rectrect

---
-- Function SetRenderPath
--
-- @function [parent=#Viewport] SetRenderPath
-- @param RenderPath#RenderPath pathpath

---
-- Function SetRenderPath
--
-- @function [parent=#Viewport] SetRenderPath
-- @param XMLFile#XMLFile filefile

---
-- Function GetScene
--
-- @function [parent=#Viewport] GetScene
-- @return Scene#Scene

---
-- Function GetCamera
--
-- @function [parent=#Viewport] GetCamera
-- @return Camera#Camera

---
-- Function GetRect
--
-- @function [parent=#Viewport] GetRect
-- @return const IntRect#const IntRect

---
-- Function GetRenderPath
--
-- @function [parent=#Viewport] GetRenderPath
-- @return RenderPath#RenderPath

---
-- Field scene
--
-- @field [parent=#Viewport] Scene#Scene scene

---
-- Field camera
--
-- @field [parent=#Viewport] Camera#Camera camera

---
-- Field rect
--
-- @field [parent=#Viewport] IntRect#IntRect rect

---
-- Field renderPath
--
-- @field [parent=#Viewport] RenderPath#RenderPath renderPath


return nil
