---
-- Module ValueAnimation
-- Module ValueAnimation extends Resource
-- Generated on 2014-05-31
--
-- @module ValueAnimation

---
-- Function ValueAnimation()
--
-- @function [parent=#ValueAnimation] ValueAnimation
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#ValueAnimation] new
-- @param self Self reference
-- @return ValueAnimation#ValueAnimation

---
-- Function delete()
--
-- @function [parent=#ValueAnimation] delete
-- @param self Self reference

---
-- Function SetInterpolationMethod()
-- Set interpolation method.
--
-- @function [parent=#ValueAnimation] SetInterpolationMethod
-- @param self Self reference
-- @param InterpMethod#InterpMethod method method

---
-- Function SetSplineTension()
-- Set spline tension, should be between 0.0f and 1.0f, but this is not a must.
--
-- @function [parent=#ValueAnimation] SetSplineTension
-- @param self Self reference
-- @param #number tension tension

---
-- Function SetValueType()
-- Set value type.
--
-- @function [parent=#ValueAnimation] SetValueType
-- @param self Self reference
-- @param VariantType#VariantType valueType valueType

---
-- Function SetKeyFrame()
-- Set key frame.
--
-- @function [parent=#ValueAnimation] SetKeyFrame
-- @param self Self reference
-- @param #number time time
-- @param Variant#Variant value value
-- @return #boolean

---
-- Function SetEventFrame()
--
-- @function [parent=#ValueAnimation] SetEventFrame
-- @param self Self reference
-- @param #number time time
-- @param StringHash#StringHash eventType eventType

---
-- Function SetEventFrame()
--
-- @function [parent=#ValueAnimation] SetEventFrame
-- @param self Self reference
-- @param #number time time
-- @param StringHash#StringHash eventType eventType
-- @param VariantMap#VariantMap eventData eventData

---
-- Function GetInterpolationMethod()
-- Return interpolation method.
--
-- @function [parent=#ValueAnimation] GetInterpolationMethod
-- @param self Self reference
-- @return InterpMethod#InterpMethod

---
-- Function GetSplineTension()
-- Return spline tension.
--
-- @function [parent=#ValueAnimation] GetSplineTension
-- @param self Self reference
-- @return #number

---
-- Function GetValueType()
-- Return value type.
--
-- @function [parent=#ValueAnimation] GetValueType
-- @param self Self reference
-- @return VariantType#VariantType

---
-- Field interpolationMethod
--
-- @field [parent=#ValueAnimation] InterpMethod#InterpMethod interpolationMethod

---
-- Field splineTension
--
-- @field [parent=#ValueAnimation] #number splineTension

---
-- Field valueType
--
-- @field [parent=#ValueAnimation] VariantType#VariantType valueType


return nil
