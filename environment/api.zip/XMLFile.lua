---
-- Module XMLFile
-- extends Resource
--
-- @module XMLFile

---
-- Function XMLFile
--
-- @function [parent=#XMLFile] XMLFile

---
-- Function new
--
-- @function [parent=#XMLFile] new
-- @return XMLFile#XMLFile

---
-- Function delete
--
-- @function [parent=#XMLFile] delete

---
-- Function CreateRoot
--
-- @function [parent=#XMLFile] CreateRoot
-- @param #string namename
-- @return XMLElement#XMLElement

---
-- Function GetRoot
--
-- @function [parent=#XMLFile] GetRoot
-- @param #string namename
-- @return XMLElement#XMLElement

---
-- Function Patch
--
-- @function [parent=#XMLFile] Patch
-- @param XMLFile#XMLFile patchFilepatchFile

---
-- Function Patch
--
-- @function [parent=#XMLFile] Patch
-- @param XMLElement#XMLElement patchElementpatchElement

---
-- Function Load
--
-- @function [parent=#XMLFile] Load
-- @param Deserializer#Deserializer sourcesource
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#XMLFile] Save
-- @param Serializer#Serializer destdest
-- @return #boolean

---
-- Function Load
--
-- @function [parent=#XMLFile] Load
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#XMLFile] Save
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function GetName
--
-- @function [parent=#XMLFile] GetName
-- @return const String#const String

---
-- Function GetNameHash
--
-- @function [parent=#XMLFile] GetNameHash
-- @return StringHash#StringHash

---
-- Function GetMemoryUse
--
-- @function [parent=#XMLFile] GetMemoryUse
-- @return #number

---
-- Field name (Read only)
--
-- @field [parent=#XMLFile] #string name

---
-- Field nameHash (Read only)
--
-- @field [parent=#XMLFile] StringHash#StringHash nameHash

---
-- Field memoryUse (Read only)
--
-- @field [parent=#XMLFile] #number memoryUse


return nil
