---
-- Module XMLFile
-- Module XMLFile extends Resource
-- Generated on 2014-03-13
--
-- @module XMLFile

---
-- Function XMLFile
--
-- @function [parent=#XMLFile] XMLFile
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#XMLFile] new
-- @param self Self reference
-- @return XMLFile#XMLFile

---
-- Function delete
--
-- @function [parent=#XMLFile] delete
-- @param self Self reference

---
-- Function CreateRoot
--
-- @function [parent=#XMLFile] CreateRoot
-- @param self Self reference
-- @param #string name name
-- @return XMLElement#XMLElement

---
-- Function GetRoot
--
-- @function [parent=#XMLFile] GetRoot
-- @param self Self reference
-- @param #string name name
-- @return XMLElement#XMLElement

---
-- Function Patch
--
-- @function [parent=#XMLFile] Patch
-- @param self Self reference
-- @param XMLFile#XMLFile patchFile patchFile

---
-- Function Patch
--
-- @function [parent=#XMLFile] Patch
-- @param self Self reference
-- @param XMLElement#XMLElement patchElement patchElement

---
-- Function Load
--
-- @function [parent=#XMLFile] Load
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#XMLFile] Save
-- @param self Self reference
-- @param Serializer#Serializer dest dest
-- @return #boolean

---
-- Function Load
--
-- @function [parent=#XMLFile] Load
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#XMLFile] Save
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function GetName
--
-- @function [parent=#XMLFile] GetName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetNameHash
--
-- @function [parent=#XMLFile] GetNameHash
-- @param self Self reference
-- @return StringHash#StringHash

---
-- Function GetMemoryUse
--
-- @function [parent=#XMLFile] GetMemoryUse
-- @param self Self reference
-- @return #number

---
-- Field name (Read only)
--
-- @field [parent=#XMLFile] #string name

---
-- Field nameHash (Read only)
--
-- @field [parent=#XMLFile] StringHash#StringHash nameHash

---
-- Field memoryUse (Read only)
--
-- @field [parent=#XMLFile] #number memoryUse


return nil
