---
-- Module XMLFile
-- Module XMLFile extends Resource
-- Generated on 2014-05-31
--
-- @module XMLFile

---
-- Function XMLFile()
--
-- @function [parent=#XMLFile] XMLFile
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#XMLFile] new
-- @param self Self reference
-- @return XMLFile#XMLFile

---
-- Function delete()
--
-- @function [parent=#XMLFile] delete
-- @param self Self reference

---
-- Function FromString()
-- Deserialize from a string. Return true if successful.
--
-- @function [parent=#XMLFile] FromString
-- @param self Self reference
-- @param #string source source
-- @return #boolean

---
-- Function CreateRoot()
-- Clear the document and create a root element.
--
-- @function [parent=#XMLFile] CreateRoot
-- @param self Self reference
-- @param #string name name
-- @return XMLElement#XMLElement

---
-- Function GetRoot()
-- Return the root element, with optionally specified name. Return null element if not found.
--
-- @function [parent=#XMLFile] GetRoot
-- @param self Self reference
-- @param #string name name
-- @return XMLElement#XMLElement

---
-- Function Patch()
-- Patch the XMLFile with another XMLFile. Based on RFC 5261.
--
-- @function [parent=#XMLFile] Patch
-- @param self Self reference
-- @param XMLFile#XMLFile patchFile patchFile

---
-- Function Patch()
-- Patch the XMLFile with another XMLElement. Based on RFC 5261.
--
-- @function [parent=#XMLFile] Patch
-- @param self Self reference
-- @param XMLElement#XMLElement patchElement patchElement


return nil
