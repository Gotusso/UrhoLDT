---
-- Module XMLFile
-- Extends Resource
--
-- @module XMLFile

---
-- Function XMLFile
--
-- @function [parent=#XMLFile] XMLFile

---
-- Function new
--
-- @function [parent=#XMLFile] new
-- @return XMLFile#XMLFile

---
-- Function delete
--
-- @function [parent=#XMLFile] delete

---
-- Function CreateRoot
--
-- @function [parent=#XMLFile] CreateRoot
-- @param #string namename
-- @return XMLElement#XMLElement

---
-- Function GetRoot
--
-- @function [parent=#XMLFile] GetRoot
-- @param #string namename
-- @return XMLElement#XMLElement

---
-- Function Patch
--
-- @function [parent=#XMLFile] Patch
-- @param XMLFile#XMLFile patchFilepatchFile

---
-- Function Patch
--
-- @function [parent=#XMLFile] Patch
-- @param XMLElement#XMLElement patchElementpatchElement


return nil
