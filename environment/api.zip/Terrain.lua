---
-- Module Terrain
-- Module Terrain extends Component
-- Generated on 2014-05-31
--
-- @module Terrain

---
-- Function SetPatchSize()
-- Set patch quads per side. Must be a power of two.
--
-- @function [parent=#Terrain] SetPatchSize
-- @param self Self reference
-- @param #number size size

---
-- Function SetSpacing()
-- Set vertex (XZ) and height (Y) spacing.
--
-- @function [parent=#Terrain] SetSpacing
-- @param self Self reference
-- @param Vector3#Vector3 spacing spacing

---
-- Function SetSmoothing()
-- Set smoothing of heightmap.
--
-- @function [parent=#Terrain] SetSmoothing
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetHeightMap()
-- Set heightmap image. Dimensions should be a power of two + 1. Uses 8-bit grayscale, or optionally red as MSB and green as LSB for 16-bit accuracy. Return true if successful.
--
-- @function [parent=#Terrain] SetHeightMap
-- @param self Self reference
-- @param Image#Image image image
-- @return #boolean

---
-- Function SetMaterial()
-- Set material.
--
-- @function [parent=#Terrain] SetMaterial
-- @param self Self reference
-- @param Material#Material material material

---
-- Function SetDrawDistance()
-- Set draw distance for patches.
--
-- @function [parent=#Terrain] SetDrawDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetShadowDistance()
-- Set shadow draw distance for patches.
--
-- @function [parent=#Terrain] SetShadowDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetLodBias()
-- Set LOD bias for patches. Affects which terrain LOD to display.
--
-- @function [parent=#Terrain] SetLodBias
-- @param self Self reference
-- @param #number bias bias

---
-- Function SetViewMask()
-- Set view mask for patches. Is and'ed with camera's view mask to see if the object should be rendered.
--
-- @function [parent=#Terrain] SetViewMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetLightMask()
-- Set light mask for patches. Is and'ed with light's and zone's light mask to see if the object should be lit.
--
-- @function [parent=#Terrain] SetLightMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetShadowMask()
-- Set shadow mask for patches. Is and'ed with light's light mask and zone's shadow mask to see if the object should be rendered to a shadow map.
--
-- @function [parent=#Terrain] SetShadowMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetZoneMask()
-- Set zone mask for patches. Is and'ed with zone's zone mask to see if the object should belong to the zone.
--
-- @function [parent=#Terrain] SetZoneMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetMaxLights()
-- Set maximum number of per-pixel lights for patches. Default 0 is unlimited.
--
-- @function [parent=#Terrain] SetMaxLights
-- @param self Self reference
-- @param #number num num

---
-- Function SetCastShadows()
-- Set shadowcaster flag for patches.
--
-- @function [parent=#Terrain] SetCastShadows
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetOccluder()
-- Set occlusion flag for patches. Occlusion uses the coarsest LOD and may potentially be too aggressive, so use with caution.
--
-- @function [parent=#Terrain] SetOccluder
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetOccludee()
-- Set occludee flag for patches.
--
-- @function [parent=#Terrain] SetOccludee
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function GetPatchSize()
-- Return patch quads per side.
--
-- @function [parent=#Terrain] GetPatchSize
-- @param self Self reference
-- @return #number

---
-- Function GetSpacing()
-- Return vertex and height spacing.
--
-- @function [parent=#Terrain] GetSpacing
-- @param self Self reference
-- @return const Vector3#const Vector3

---
-- Function GetNumVertices()
-- Return heightmap size in vertices.
--
-- @function [parent=#Terrain] GetNumVertices
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetNumPatches()
-- Return heightmap size in patches.
--
-- @function [parent=#Terrain] GetNumPatches
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetSmoothing()
-- Return whether smoothing is in use.
--
-- @function [parent=#Terrain] GetSmoothing
-- @param self Self reference
-- @return #boolean

---
-- Function GetHeightMap()
-- Return heightmap image.
--
-- @function [parent=#Terrain] GetHeightMap
-- @param self Self reference
-- @return Image#Image

---
-- Function GetMaterial()
-- Return material.
--
-- @function [parent=#Terrain] GetMaterial
-- @param self Self reference
-- @return Material#Material

---
-- Function GetPatch()
-- Return patch by index.
--
-- @function [parent=#Terrain] GetPatch
-- @param self Self reference
-- @param #number index index
-- @return TerrainPatch#TerrainPatch

---
-- Function GetPatch()
-- Return patch by patch coordinates.
--
-- @function [parent=#Terrain] GetPatch
-- @param self Self reference
-- @param #number x x
-- @param #number z z
-- @return TerrainPatch#TerrainPatch

---
-- Function GetHeight()
-- Return height at world coordinates.
--
-- @function [parent=#Terrain] GetHeight
-- @param self Self reference
-- @param Vector3#Vector3 worldPosition worldPosition
-- @return #number

---
-- Function GetNormal()
-- Return normal at world coordinates.
--
-- @function [parent=#Terrain] GetNormal
-- @param self Self reference
-- @param Vector3#Vector3 worldPosition worldPosition
-- @return Vector3#Vector3

---
-- Function GetHeightData()
-- Return raw height data.
--
-- @function [parent=#Terrain] GetHeightData
-- @param self Self reference
-- @return SharedArrayPtr<float>#SharedArrayPtr<float>

---
-- Function GetDrawDistance()
-- Return draw distance.
--
-- @function [parent=#Terrain] GetDrawDistance
-- @param self Self reference
-- @return #number

---
-- Function GetShadowDistance()
-- Return shadow draw distance.
--
-- @function [parent=#Terrain] GetShadowDistance
-- @param self Self reference
-- @return #number

---
-- Function GetLodBias()
-- Return LOD bias.
--
-- @function [parent=#Terrain] GetLodBias
-- @param self Self reference
-- @return #number

---
-- Function GetViewMask()
-- Return view mask.
--
-- @function [parent=#Terrain] GetViewMask
-- @param self Self reference
-- @return #number

---
-- Function GetLightMask()
-- Return light mask.
--
-- @function [parent=#Terrain] GetLightMask
-- @param self Self reference
-- @return #number

---
-- Function GetShadowMask()
-- Return shadow mask.
--
-- @function [parent=#Terrain] GetShadowMask
-- @param self Self reference
-- @return #number

---
-- Function GetZoneMask()
-- Return zone mask.
--
-- @function [parent=#Terrain] GetZoneMask
-- @param self Self reference
-- @return #number

---
-- Function GetMaxLights()
-- Return maximum number of per-pixel lights.
--
-- @function [parent=#Terrain] GetMaxLights
-- @param self Self reference
-- @return #number

---
-- Function IsVisible()
-- Return visible flag.
--
-- @function [parent=#Terrain] IsVisible
-- @param self Self reference
-- @return #boolean

---
-- Function GetCastShadows()
-- Return shadowcaster flag.
--
-- @function [parent=#Terrain] GetCastShadows
-- @param self Self reference
-- @return #boolean

---
-- Function IsOccluder()
-- Return occluder flag.
--
-- @function [parent=#Terrain] IsOccluder
-- @param self Self reference
-- @return #boolean

---
-- Function IsOccludee()
-- Return occludee flag.
--
-- @function [parent=#Terrain] IsOccludee
-- @param self Self reference
-- @return #boolean

---
-- Field patchSize
--
-- @field [parent=#Terrain] #number patchSize

---
-- Field spacing
--
-- @field [parent=#Terrain] Vector3#Vector3 spacing

---
-- Field numVertices (Read only)
--
-- @field [parent=#Terrain] IntVector2#IntVector2 numVertices

---
-- Field numPatches (Read only)
--
-- @field [parent=#Terrain] IntVector2#IntVector2 numPatches

---
-- Field smoothing
--
-- @field [parent=#Terrain] #boolean smoothing

---
-- Field heightMap
--
-- @field [parent=#Terrain] Image#Image heightMap

---
-- Field material
--
-- @field [parent=#Terrain] Material#Material material

---
-- Field drawDistance
--
-- @field [parent=#Terrain] #number drawDistance

---
-- Field shadowDistance
--
-- @field [parent=#Terrain] #number shadowDistance

---
-- Field lodBias
--
-- @field [parent=#Terrain] #number lodBias

---
-- Field viewMask
--
-- @field [parent=#Terrain] #number viewMask

---
-- Field lightMask
--
-- @field [parent=#Terrain] #number lightMask

---
-- Field shadowMask
--
-- @field [parent=#Terrain] #number shadowMask

---
-- Field zoneMask
--
-- @field [parent=#Terrain] #number zoneMask

---
-- Field maxLights
--
-- @field [parent=#Terrain] #number maxLights

---
-- Field visible (Read only)
--
-- @field [parent=#Terrain] #boolean visible

---
-- Field castShadows
--
-- @field [parent=#Terrain] #boolean castShadows

---
-- Field occluder
--
-- @field [parent=#Terrain] #boolean occluder

---
-- Field occludee
--
-- @field [parent=#Terrain] #boolean occludee


return nil
