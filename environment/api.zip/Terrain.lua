---
-- Module Terrain
-- extends Component
--
-- @module Terrain

---
-- Function SetPatchSize
--
-- @function [parent=#Terrain] SetPatchSize
-- @param #number sizesize

---
-- Function SetSpacing
--
-- @function [parent=#Terrain] SetSpacing
-- @param Vector3#Vector3 spacingspacing

---
-- Function SetSmoothing
--
-- @function [parent=#Terrain] SetSmoothing
-- @param #boolean enableenable

---
-- Function SetHeightMap
--
-- @function [parent=#Terrain] SetHeightMap
-- @param Image#Image imageimage
-- @return #boolean

---
-- Function SetMaterial
--
-- @function [parent=#Terrain] SetMaterial
-- @param Material#Material materialmaterial

---
-- Function SetDrawDistance
--
-- @function [parent=#Terrain] SetDrawDistance
-- @param #number distancedistance

---
-- Function SetShadowDistance
--
-- @function [parent=#Terrain] SetShadowDistance
-- @param #number distancedistance

---
-- Function SetLodBias
--
-- @function [parent=#Terrain] SetLodBias
-- @param #number biasbias

---
-- Function SetViewMask
--
-- @function [parent=#Terrain] SetViewMask
-- @param #number maskmask

---
-- Function SetLightMask
--
-- @function [parent=#Terrain] SetLightMask
-- @param #number maskmask

---
-- Function SetShadowMask
--
-- @function [parent=#Terrain] SetShadowMask
-- @param #number maskmask

---
-- Function SetZoneMask
--
-- @function [parent=#Terrain] SetZoneMask
-- @param #number maskmask

---
-- Function SetMaxLights
--
-- @function [parent=#Terrain] SetMaxLights
-- @param #number numnum

---
-- Function SetCastShadows
--
-- @function [parent=#Terrain] SetCastShadows
-- @param #boolean enableenable

---
-- Function SetOccluder
--
-- @function [parent=#Terrain] SetOccluder
-- @param #boolean enableenable

---
-- Function SetOccludee
--
-- @function [parent=#Terrain] SetOccludee
-- @param #boolean enableenable

---
-- Function GetPatchSize
--
-- @function [parent=#Terrain] GetPatchSize
-- @return #number

---
-- Function GetSpacing
--
-- @function [parent=#Terrain] GetSpacing
-- @return const Vector3#const Vector3

---
-- Function GetNumVertices
--
-- @function [parent=#Terrain] GetNumVertices
-- @return const IntVector2#const IntVector2

---
-- Function GetNumPatches
--
-- @function [parent=#Terrain] GetNumPatches
-- @return const IntVector2#const IntVector2

---
-- Function GetSmoothing
--
-- @function [parent=#Terrain] GetSmoothing
-- @return #boolean

---
-- Function GetHeightMap
--
-- @function [parent=#Terrain] GetHeightMap
-- @return Image#Image

---
-- Function GetMaterial
--
-- @function [parent=#Terrain] GetMaterial
-- @return Material#Material

---
-- Function GetPatch
--
-- @function [parent=#Terrain] GetPatch
-- @param #number indexindex
-- @return TerrainPatch#TerrainPatch

---
-- Function GetPatch
--
-- @function [parent=#Terrain] GetPatch
-- @param #number xx
-- @param #number zz
-- @return TerrainPatch#TerrainPatch

---
-- Function GetHeight
--
-- @function [parent=#Terrain] GetHeight
-- @param Vector3#Vector3 worldPositionworldPosition
-- @return #number

---
-- Function GetNormal
--
-- @function [parent=#Terrain] GetNormal
-- @param Vector3#Vector3 worldPositionworldPosition
-- @return Vector3#Vector3

---
-- Function GetHeightData
--
-- @function [parent=#Terrain] GetHeightData
-- @return SharedArrayPtr<float>#SharedArrayPtr<float>

---
-- Function GetDrawDistance
--
-- @function [parent=#Terrain] GetDrawDistance
-- @return #number

---
-- Function GetShadowDistance
--
-- @function [parent=#Terrain] GetShadowDistance
-- @return #number

---
-- Function GetLodBias
--
-- @function [parent=#Terrain] GetLodBias
-- @return #number

---
-- Function GetViewMask
--
-- @function [parent=#Terrain] GetViewMask
-- @return #number

---
-- Function GetLightMask
--
-- @function [parent=#Terrain] GetLightMask
-- @return #number

---
-- Function GetShadowMask
--
-- @function [parent=#Terrain] GetShadowMask
-- @return #number

---
-- Function GetZoneMask
--
-- @function [parent=#Terrain] GetZoneMask
-- @return #number

---
-- Function GetMaxLights
--
-- @function [parent=#Terrain] GetMaxLights
-- @return #number

---
-- Function IsVisible
--
-- @function [parent=#Terrain] IsVisible
-- @return #boolean

---
-- Function GetCastShadows
--
-- @function [parent=#Terrain] GetCastShadows
-- @return #boolean

---
-- Function IsOccluder
--
-- @function [parent=#Terrain] IsOccluder
-- @return #boolean

---
-- Function IsOccludee
--
-- @function [parent=#Terrain] IsOccludee
-- @return #boolean

---
-- Field patchSize
--
-- @field [parent=#Terrain] #number patchSize

---
-- Field spacing
--
-- @field [parent=#Terrain] Vector3#Vector3 spacing

---
-- Field numVertices (Read only)
--
-- @field [parent=#Terrain] IntVector2#IntVector2 numVertices

---
-- Field numPatches (Read only)
--
-- @field [parent=#Terrain] IntVector2#IntVector2 numPatches

---
-- Field smoothing
--
-- @field [parent=#Terrain] #boolean smoothing

---
-- Field heightMap
--
-- @field [parent=#Terrain] Image#Image heightMap

---
-- Field material
--
-- @field [parent=#Terrain] Material#Material material

---
-- Field drawDistance
--
-- @field [parent=#Terrain] #number drawDistance

---
-- Field shadowDistance
--
-- @field [parent=#Terrain] #number shadowDistance

---
-- Field lodBias
--
-- @field [parent=#Terrain] #number lodBias

---
-- Field viewMask
--
-- @field [parent=#Terrain] #number viewMask

---
-- Field lightMask
--
-- @field [parent=#Terrain] #number lightMask

---
-- Field shadowMask
--
-- @field [parent=#Terrain] #number shadowMask

---
-- Field zoneMask
--
-- @field [parent=#Terrain] #number zoneMask

---
-- Field maxLights
--
-- @field [parent=#Terrain] #number maxLights

---
-- Field visible (Read only)
--
-- @field [parent=#Terrain] #boolean visible

---
-- Field castShadows
--
-- @field [parent=#Terrain] #boolean castShadows

---
-- Field occluder
--
-- @field [parent=#Terrain] #boolean occluder

---
-- Field occludee
--
-- @field [parent=#Terrain] #boolean occludee

---
-- Function SetEnabled
--
-- @function [parent=#Terrain] SetEnabled
-- @param #boolean enableenable

---
-- Function Remove
--
-- @function [parent=#Terrain] Remove

---
-- Function GetID
--
-- @function [parent=#Terrain] GetID
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#Terrain] GetNode
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#Terrain] GetScene
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#Terrain] IsEnabled
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#Terrain] IsEnabledEffective
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#Terrain] GetComponent
-- @param ShortStringHash#ShortStringHash typetype
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#Terrain] GetComponent
-- @param #string typetype
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#Terrain] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#Terrain] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Terrain] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Terrain] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Terrain] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Terrain] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Terrain] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Terrain] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#Terrain] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Terrain] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Terrain] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Terrain] #string category


return nil
