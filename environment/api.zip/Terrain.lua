---
-- Module Terrain
-- Module Terrain extends Component
-- Generated on 2014-03-13
--
-- @module Terrain

---
-- Function SetPatchSize
--
-- @function [parent=#Terrain] SetPatchSize
-- @param self Self reference
-- @param #number size size

---
-- Function SetSpacing
--
-- @function [parent=#Terrain] SetSpacing
-- @param self Self reference
-- @param Vector3#Vector3 spacing spacing

---
-- Function SetSmoothing
--
-- @function [parent=#Terrain] SetSmoothing
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetHeightMap
--
-- @function [parent=#Terrain] SetHeightMap
-- @param self Self reference
-- @param Image#Image image image
-- @return #boolean

---
-- Function SetMaterial
--
-- @function [parent=#Terrain] SetMaterial
-- @param self Self reference
-- @param Material#Material material material

---
-- Function SetDrawDistance
--
-- @function [parent=#Terrain] SetDrawDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetShadowDistance
--
-- @function [parent=#Terrain] SetShadowDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetLodBias
--
-- @function [parent=#Terrain] SetLodBias
-- @param self Self reference
-- @param #number bias bias

---
-- Function SetViewMask
--
-- @function [parent=#Terrain] SetViewMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetLightMask
--
-- @function [parent=#Terrain] SetLightMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetShadowMask
--
-- @function [parent=#Terrain] SetShadowMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetZoneMask
--
-- @function [parent=#Terrain] SetZoneMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetMaxLights
--
-- @function [parent=#Terrain] SetMaxLights
-- @param self Self reference
-- @param #number num num

---
-- Function SetCastShadows
--
-- @function [parent=#Terrain] SetCastShadows
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetOccluder
--
-- @function [parent=#Terrain] SetOccluder
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetOccludee
--
-- @function [parent=#Terrain] SetOccludee
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function GetPatchSize
--
-- @function [parent=#Terrain] GetPatchSize
-- @param self Self reference
-- @return #number

---
-- Function GetSpacing
--
-- @function [parent=#Terrain] GetSpacing
-- @param self Self reference
-- @return const Vector3#const Vector3

---
-- Function GetNumVertices
--
-- @function [parent=#Terrain] GetNumVertices
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetNumPatches
--
-- @function [parent=#Terrain] GetNumPatches
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetSmoothing
--
-- @function [parent=#Terrain] GetSmoothing
-- @param self Self reference
-- @return #boolean

---
-- Function GetHeightMap
--
-- @function [parent=#Terrain] GetHeightMap
-- @param self Self reference
-- @return Image#Image

---
-- Function GetMaterial
--
-- @function [parent=#Terrain] GetMaterial
-- @param self Self reference
-- @return Material#Material

---
-- Function GetPatch
--
-- @function [parent=#Terrain] GetPatch
-- @param self Self reference
-- @param #number index index
-- @return TerrainPatch#TerrainPatch

---
-- Function GetPatch
--
-- @function [parent=#Terrain] GetPatch
-- @param self Self reference
-- @param #number x x
-- @param #number z z
-- @return TerrainPatch#TerrainPatch

---
-- Function GetHeight
--
-- @function [parent=#Terrain] GetHeight
-- @param self Self reference
-- @param Vector3#Vector3 worldPosition worldPosition
-- @return #number

---
-- Function GetNormal
--
-- @function [parent=#Terrain] GetNormal
-- @param self Self reference
-- @param Vector3#Vector3 worldPosition worldPosition
-- @return Vector3#Vector3

---
-- Function GetHeightData
--
-- @function [parent=#Terrain] GetHeightData
-- @param self Self reference
-- @return SharedArrayPtr<float>#SharedArrayPtr<float>

---
-- Function GetDrawDistance
--
-- @function [parent=#Terrain] GetDrawDistance
-- @param self Self reference
-- @return #number

---
-- Function GetShadowDistance
--
-- @function [parent=#Terrain] GetShadowDistance
-- @param self Self reference
-- @return #number

---
-- Function GetLodBias
--
-- @function [parent=#Terrain] GetLodBias
-- @param self Self reference
-- @return #number

---
-- Function GetViewMask
--
-- @function [parent=#Terrain] GetViewMask
-- @param self Self reference
-- @return #number

---
-- Function GetLightMask
--
-- @function [parent=#Terrain] GetLightMask
-- @param self Self reference
-- @return #number

---
-- Function GetShadowMask
--
-- @function [parent=#Terrain] GetShadowMask
-- @param self Self reference
-- @return #number

---
-- Function GetZoneMask
--
-- @function [parent=#Terrain] GetZoneMask
-- @param self Self reference
-- @return #number

---
-- Function GetMaxLights
--
-- @function [parent=#Terrain] GetMaxLights
-- @param self Self reference
-- @return #number

---
-- Function IsVisible
--
-- @function [parent=#Terrain] IsVisible
-- @param self Self reference
-- @return #boolean

---
-- Function GetCastShadows
--
-- @function [parent=#Terrain] GetCastShadows
-- @param self Self reference
-- @return #boolean

---
-- Function IsOccluder
--
-- @function [parent=#Terrain] IsOccluder
-- @param self Self reference
-- @return #boolean

---
-- Function IsOccludee
--
-- @function [parent=#Terrain] IsOccludee
-- @param self Self reference
-- @return #boolean

---
-- Field patchSize
--
-- @field [parent=#Terrain] #number patchSize

---
-- Field spacing
--
-- @field [parent=#Terrain] Vector3#Vector3 spacing

---
-- Field numVertices (Read only)
--
-- @field [parent=#Terrain] IntVector2#IntVector2 numVertices

---
-- Field numPatches (Read only)
--
-- @field [parent=#Terrain] IntVector2#IntVector2 numPatches

---
-- Field smoothing
--
-- @field [parent=#Terrain] #boolean smoothing

---
-- Field heightMap
--
-- @field [parent=#Terrain] Image#Image heightMap

---
-- Field material
--
-- @field [parent=#Terrain] Material#Material material

---
-- Field drawDistance
--
-- @field [parent=#Terrain] #number drawDistance

---
-- Field shadowDistance
--
-- @field [parent=#Terrain] #number shadowDistance

---
-- Field lodBias
--
-- @field [parent=#Terrain] #number lodBias

---
-- Field viewMask
--
-- @field [parent=#Terrain] #number viewMask

---
-- Field lightMask
--
-- @field [parent=#Terrain] #number lightMask

---
-- Field shadowMask
--
-- @field [parent=#Terrain] #number shadowMask

---
-- Field zoneMask
--
-- @field [parent=#Terrain] #number zoneMask

---
-- Field maxLights
--
-- @field [parent=#Terrain] #number maxLights

---
-- Field visible (Read only)
--
-- @field [parent=#Terrain] #boolean visible

---
-- Field castShadows
--
-- @field [parent=#Terrain] #boolean castShadows

---
-- Field occluder
--
-- @field [parent=#Terrain] #boolean occluder

---
-- Field occludee
--
-- @field [parent=#Terrain] #boolean occludee

---
-- Function SetEnabled
--
-- @function [parent=#Terrain] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Remove
--
-- @function [parent=#Terrain] Remove
-- @param self Self reference

---
-- Function GetID
--
-- @function [parent=#Terrain] GetID
-- @param self Self reference
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#Terrain] GetNode
-- @param self Self reference
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#Terrain] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#Terrain] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#Terrain] IsEnabledEffective
-- @param self Self reference
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#Terrain] GetComponent
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#Terrain] GetComponent
-- @param self Self reference
-- @param #string type type
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#Terrain] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#Terrain] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Terrain] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Terrain] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Terrain] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Terrain] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Terrain] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Terrain] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#Terrain] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Terrain] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Terrain] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Terrain] #string category


return nil
