---
-- Module ConstraintWeld2D
-- Module ConstraintWeld2D extends Constraint2D
-- Generated on 2014-05-31
--
-- @module ConstraintWeld2D

---
-- Function SetAnchor()
-- Set anchor.
--
-- @function [parent=#ConstraintWeld2D] SetAnchor
-- @param self Self reference
-- @param Vector2#Vector2 anchor anchor

---
-- Function SetFrequencyHz()
-- Set frequency Hz.
--
-- @function [parent=#ConstraintWeld2D] SetFrequencyHz
-- @param self Self reference
-- @param #number frequencyHz frequencyHz

---
-- Function SetDampingRatio()
-- Set damping ratio.
--
-- @function [parent=#ConstraintWeld2D] SetDampingRatio
-- @param self Self reference
-- @param #number dampingRatio dampingRatio

---
-- Function GetAnchor()
-- Return anchor.
--
-- @function [parent=#ConstraintWeld2D] GetAnchor
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Function GetFrequencyHz()
-- Return frequency Hz.
--
-- @function [parent=#ConstraintWeld2D] GetFrequencyHz
-- @param self Self reference
-- @return #number

---
-- Function GetDampingRatio()
-- Return damping ratio.
--
-- @function [parent=#ConstraintWeld2D] GetDampingRatio
-- @param self Self reference
-- @return #number

---
-- Field anchor
--
-- @field [parent=#ConstraintWeld2D] Vector2#Vector2 anchor

---
-- Field frequencyHz
--
-- @field [parent=#ConstraintWeld2D] #number frequencyHz

---
-- Field dampingRatio
--
-- @field [parent=#ConstraintWeld2D] #number dampingRatio


return nil
