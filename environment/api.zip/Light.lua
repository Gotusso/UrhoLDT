---
-- Module Light
-- extends Drawable
--
-- @module Light

---
-- Function SetLightType
--
-- @function [parent=#Light] SetLightType
-- @param LightType#LightType typetype

---
-- Function SetPerVertex
--
-- @function [parent=#Light] SetPerVertex
-- @param #boolean enableenable

---
-- Function SetColor
--
-- @function [parent=#Light] SetColor
-- @param Color#Color colorcolor

---
-- Function SetSpecularIntensity
--
-- @function [parent=#Light] SetSpecularIntensity
-- @param #number intensityintensity

---
-- Function SetRange
--
-- @function [parent=#Light] SetRange
-- @param #number rangerange

---
-- Function SetFov
--
-- @function [parent=#Light] SetFov
-- @param #number fovfov

---
-- Function SetAspectRatio
--
-- @function [parent=#Light] SetAspectRatio
-- @param #number aspectRatioaspectRatio

---
-- Function SetFadeDistance
--
-- @function [parent=#Light] SetFadeDistance
-- @param #number distancedistance

---
-- Function SetShadowFadeDistance
--
-- @function [parent=#Light] SetShadowFadeDistance
-- @param #number distancedistance

---
-- Function SetShadowBias
--
-- @function [parent=#Light] SetShadowBias
-- @param BiasParameters#BiasParameters parametersparameters

---
-- Function SetShadowCascade
--
-- @function [parent=#Light] SetShadowCascade
-- @param CascadeParameters#CascadeParameters parametersparameters

---
-- Function SetShadowFocus
--
-- @function [parent=#Light] SetShadowFocus
-- @param FocusParameters#FocusParameters parametersparameters

---
-- Function SetShadowIntensity
--
-- @function [parent=#Light] SetShadowIntensity
-- @param #number intensityintensity

---
-- Function SetShadowResolution
--
-- @function [parent=#Light] SetShadowResolution
-- @param #number resolutionresolution

---
-- Function SetShadowNearFarRatio
--
-- @function [parent=#Light] SetShadowNearFarRatio
-- @param #number nearFarRationearFarRatio

---
-- Function SetRampTexture
--
-- @function [parent=#Light] SetRampTexture
-- @param Texture#Texture texturetexture

---
-- Function SetShapeTexture
--
-- @function [parent=#Light] SetShapeTexture
-- @param Texture#Texture texturetexture

---
-- Function GetLightType
--
-- @function [parent=#Light] GetLightType
-- @return LightType#LightType

---
-- Function GetPerVertex
--
-- @function [parent=#Light] GetPerVertex
-- @return #boolean

---
-- Function GetColor
--
-- @function [parent=#Light] GetColor
-- @return const Color#const Color

---
-- Function GetSpecularIntensity
--
-- @function [parent=#Light] GetSpecularIntensity
-- @return #number

---
-- Function GetRange
--
-- @function [parent=#Light] GetRange
-- @return #number

---
-- Function GetFov
--
-- @function [parent=#Light] GetFov
-- @return #number

---
-- Function GetAspectRatio
--
-- @function [parent=#Light] GetAspectRatio
-- @return #number

---
-- Function GetFadeDistance
--
-- @function [parent=#Light] GetFadeDistance
-- @return #number

---
-- Function GetShadowFadeDistance
--
-- @function [parent=#Light] GetShadowFadeDistance
-- @return #number

---
-- Function GetShadowBias
--
-- @function [parent=#Light] GetShadowBias
-- @return const BiasParameters#const BiasParameters

---
-- Function GetShadowCascade
--
-- @function [parent=#Light] GetShadowCascade
-- @return const CascadeParameters#const CascadeParameters

---
-- Function GetShadowFocus
--
-- @function [parent=#Light] GetShadowFocus
-- @return const FocusParameters#const FocusParameters

---
-- Function GetShadowIntensity
--
-- @function [parent=#Light] GetShadowIntensity
-- @return #number

---
-- Function GetShadowResolution
--
-- @function [parent=#Light] GetShadowResolution
-- @return #number

---
-- Function GetShadowNearFarRatio
--
-- @function [parent=#Light] GetShadowNearFarRatio
-- @return #number

---
-- Function GetRampTexture
--
-- @function [parent=#Light] GetRampTexture
-- @return Texture#Texture

---
-- Function GetShapeTexture
--
-- @function [parent=#Light] GetShapeTexture
-- @return Texture#Texture

---
-- Function GetFrustum
--
-- @function [parent=#Light] GetFrustum
-- @return Frustum#Frustum

---
-- Field lightType
--
-- @field [parent=#Light] LightType#LightType lightType

---
-- Field perVertex
--
-- @field [parent=#Light] #boolean perVertex

---
-- Field color
--
-- @field [parent=#Light] Color#Color color

---
-- Field specularIntensity
--
-- @field [parent=#Light] #number specularIntensity

---
-- Field range
--
-- @field [parent=#Light] #number range

---
-- Field fov
--
-- @field [parent=#Light] #number fov

---
-- Field aspectRatio
--
-- @field [parent=#Light] #number aspectRatio

---
-- Field fadeDistance
--
-- @field [parent=#Light] #number fadeDistance

---
-- Field shadowFadeDistance
--
-- @field [parent=#Light] #number shadowFadeDistance

---
-- Field shadowBias
--
-- @field [parent=#Light] BiasParameters#BiasParameters shadowBias

---
-- Field shadowCascade
--
-- @field [parent=#Light] CascadeParameters#CascadeParameters shadowCascade

---
-- Field shadowFocus
--
-- @field [parent=#Light] FocusParameters#FocusParameters shadowFocus

---
-- Field shadowIntensity
--
-- @field [parent=#Light] #number shadowIntensity

---
-- Field shadowResolution
--
-- @field [parent=#Light] #number shadowResolution

---
-- Field shadowNearFarRatio
--
-- @field [parent=#Light] #number shadowNearFarRatio

---
-- Field rampTexture
--
-- @field [parent=#Light] Texture#Texture rampTexture

---
-- Field shapeTexture
--
-- @field [parent=#Light] Texture#Texture shapeTexture

---
-- Field frustum (Read only)
--
-- @field [parent=#Light] Frustum#Frustum frustum

---
-- Function SetDrawDistance
--
-- @function [parent=#Light] SetDrawDistance
-- @param #number distancedistance

---
-- Function SetShadowDistance
--
-- @function [parent=#Light] SetShadowDistance
-- @param #number distancedistance

---
-- Function SetLodBias
--
-- @function [parent=#Light] SetLodBias
-- @param #number biasbias

---
-- Function SetViewMask
--
-- @function [parent=#Light] SetViewMask
-- @param #number maskmask

---
-- Function SetLightMask
--
-- @function [parent=#Light] SetLightMask
-- @param #number maskmask

---
-- Function SetShadowMask
--
-- @function [parent=#Light] SetShadowMask
-- @param #number maskmask

---
-- Function SetZoneMask
--
-- @function [parent=#Light] SetZoneMask
-- @param #number maskmask

---
-- Function SetMaxLights
--
-- @function [parent=#Light] SetMaxLights
-- @param #number numnum

---
-- Function SetCastShadows
--
-- @function [parent=#Light] SetCastShadows
-- @param #boolean enableenable

---
-- Function SetOccluder
--
-- @function [parent=#Light] SetOccluder
-- @param #boolean enableenable

---
-- Function SetOccludee
--
-- @function [parent=#Light] SetOccludee
-- @param #boolean enableenable

---
-- Function MarkForUpdate
--
-- @function [parent=#Light] MarkForUpdate

---
-- Function GetBoundingBox
--
-- @function [parent=#Light] GetBoundingBox
-- @return const BoundingBox#const BoundingBox

---
-- Function GetWorldBoundingBox
--
-- @function [parent=#Light] GetWorldBoundingBox
-- @return const BoundingBox#const BoundingBox

---
-- Function GetDrawableFlags
--
-- @function [parent=#Light] GetDrawableFlags
-- @return #string

---
-- Function GetDrawDistance
--
-- @function [parent=#Light] GetDrawDistance
-- @return #number

---
-- Function GetShadowDistance
--
-- @function [parent=#Light] GetShadowDistance
-- @return #number

---
-- Function GetLodBias
--
-- @function [parent=#Light] GetLodBias
-- @return #number

---
-- Function GetViewMask
--
-- @function [parent=#Light] GetViewMask
-- @return #number

---
-- Function GetLightMask
--
-- @function [parent=#Light] GetLightMask
-- @return #number

---
-- Function GetShadowMask
--
-- @function [parent=#Light] GetShadowMask
-- @return #number

---
-- Function GetZoneMask
--
-- @function [parent=#Light] GetZoneMask
-- @return #number

---
-- Function GetMaxLights
--
-- @function [parent=#Light] GetMaxLights
-- @return #number

---
-- Function GetCastShadows
--
-- @function [parent=#Light] GetCastShadows
-- @return #boolean

---
-- Function IsOccluder
--
-- @function [parent=#Light] IsOccluder
-- @return #boolean

---
-- Function IsOccludee
--
-- @function [parent=#Light] IsOccludee
-- @return #boolean

---
-- Function SetZone
--
-- @function [parent=#Light] SetZone
-- @param Zone#Zone zonezone
-- @param #boolean temporarytemporary

---
-- Function SetSortValue
--
-- @function [parent=#Light] SetSortValue
-- @param #number valuevalue

---
-- Function SetMinMaxZ
--
-- @function [parent=#Light] SetMinMaxZ
-- @param #number minZminZ
-- @param #number maxZmaxZ

---
-- Function MarkInView
--
-- @function [parent=#Light] MarkInView
-- @param FrameInfo#FrameInfo frameframe
-- @param #boolean mainViewmainView

---
-- Function ClearLights
--
-- @function [parent=#Light] ClearLights

---
-- Function AddLight
--
-- @function [parent=#Light] AddLight
-- @param Light#Light lightlight

---
-- Function AddVertexLight
--
-- @function [parent=#Light] AddVertexLight
-- @param Light#Light lightlight

---
-- Function LimitLights
--
-- @function [parent=#Light] LimitLights

---
-- Function LimitVertexLights
--
-- @function [parent=#Light] LimitVertexLights

---
-- Function SetBasePass
--
-- @function [parent=#Light] SetBasePass
-- @param #number batchIndexbatchIndex

---
-- Function GetOctant
--
-- @function [parent=#Light] GetOctant
-- @return Octant#Octant

---
-- Function GetZone
--
-- @function [parent=#Light] GetZone
-- @return Zone#Zone

---
-- Function GetLastZone
--
-- @function [parent=#Light] GetLastZone
-- @return Zone#Zone

---
-- Function IsZoneDirty
--
-- @function [parent=#Light] IsZoneDirty
-- @return #boolean

---
-- Function GetDistance
--
-- @function [parent=#Light] GetDistance
-- @return #number

---
-- Function GetLodDistance
--
-- @function [parent=#Light] GetLodDistance
-- @return #number

---
-- Function GetSortValue
--
-- @function [parent=#Light] GetSortValue
-- @return #number

---
-- Function IsInView
--
-- @function [parent=#Light] IsInView
-- @param #number frameNumberframeNumber
-- @return #boolean

---
-- Function IsInView
--
-- @function [parent=#Light] IsInView
-- @param FrameInfo#FrameInfo frameframe
-- @param #boolean mainViewmainView
-- @return #boolean

---
-- Function HasBasePass
--
-- @function [parent=#Light] HasBasePass
-- @param #number batchIndexbatchIndex
-- @return #boolean

---
-- Function GetFirstLight
--
-- @function [parent=#Light] GetFirstLight
-- @return Light#Light

---
-- Function GetMinZ
--
-- @function [parent=#Light] GetMinZ
-- @return #number

---
-- Function GetMaxZ
--
-- @function [parent=#Light] GetMaxZ
-- @return #number

---
-- Field worldBoundingBox (Read only)
--
-- @field [parent=#Light] BoundingBox#BoundingBox worldBoundingBox

---
-- Field drawableFlags (Read only)
--
-- @field [parent=#Light] #string drawableFlags

---
-- Field drawDistance
--
-- @field [parent=#Light] #number drawDistance

---
-- Field shadowDistance
--
-- @field [parent=#Light] #number shadowDistance

---
-- Field lodBias
--
-- @field [parent=#Light] #number lodBias

---
-- Field viewMask
--
-- @field [parent=#Light] #number viewMask

---
-- Field lightMask
--
-- @field [parent=#Light] #number lightMask

---
-- Field shadowMask
--
-- @field [parent=#Light] #number shadowMask

---
-- Field zoneMask
--
-- @field [parent=#Light] #number zoneMask

---
-- Field maxLights
--
-- @field [parent=#Light] #number maxLights

---
-- Field castShadows
--
-- @field [parent=#Light] #boolean castShadows

---
-- Field occluder
--
-- @field [parent=#Light] #boolean occluder

---
-- Field occludee
--
-- @field [parent=#Light] #boolean occludee

---
-- Field octant (Read only)
--
-- @field [parent=#Light] Octant#Octant octant

---
-- Field zone
--
-- @field [parent=#Light] Zone#Zone zone

---
-- Field lastZone (Read only)
--
-- @field [parent=#Light] Zone#Zone lastZone

---
-- Field zoneDirty (Read only)
--
-- @field [parent=#Light] #boolean zoneDirty

---
-- Field distance (Read only)
--
-- @field [parent=#Light] #number distance

---
-- Field lodDistance (Read only)
--
-- @field [parent=#Light] #number lodDistance

---
-- Field sortValue
--
-- @field [parent=#Light] #number sortValue

---
-- Field firstLight (Read only)
--
-- @field [parent=#Light] Light#Light firstLight

---
-- Field minZ (Read only)
--
-- @field [parent=#Light] #number minZ

---
-- Field maxZ (Read only)
--
-- @field [parent=#Light] #number maxZ

---
-- Function SetEnabled
--
-- @function [parent=#Light] SetEnabled
-- @param #boolean enableenable

---
-- Function Remove
--
-- @function [parent=#Light] Remove

---
-- Function GetID
--
-- @function [parent=#Light] GetID
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#Light] GetNode
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#Light] GetScene
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#Light] IsEnabled
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#Light] IsEnabledEffective
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#Light] GetComponent
-- @param ShortStringHash#ShortStringHash typetype
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#Light] GetComponent
-- @param #string typetype
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#Light] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#Light] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Light] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Light] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Light] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Light] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Light] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Light] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#Light] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Light] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Light] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Light] #string category


return nil
