---
-- Module Light
-- Module Light extends Drawable
-- Generated on 2014-03-13
--
-- @module Light

---
-- Function SetLightType
--
-- @function [parent=#Light] SetLightType
-- @param self Self reference
-- @param LightType#LightType type type

---
-- Function SetPerVertex
--
-- @function [parent=#Light] SetPerVertex
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetColor
--
-- @function [parent=#Light] SetColor
-- @param self Self reference
-- @param Color#Color color color

---
-- Function SetSpecularIntensity
--
-- @function [parent=#Light] SetSpecularIntensity
-- @param self Self reference
-- @param #number intensity intensity

---
-- Function SetRange
--
-- @function [parent=#Light] SetRange
-- @param self Self reference
-- @param #number range range

---
-- Function SetFov
--
-- @function [parent=#Light] SetFov
-- @param self Self reference
-- @param #number fov fov

---
-- Function SetAspectRatio
--
-- @function [parent=#Light] SetAspectRatio
-- @param self Self reference
-- @param #number aspectRatio aspectRatio

---
-- Function SetFadeDistance
--
-- @function [parent=#Light] SetFadeDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetShadowFadeDistance
--
-- @function [parent=#Light] SetShadowFadeDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetShadowBias
--
-- @function [parent=#Light] SetShadowBias
-- @param self Self reference
-- @param BiasParameters#BiasParameters parameters parameters

---
-- Function SetShadowCascade
--
-- @function [parent=#Light] SetShadowCascade
-- @param self Self reference
-- @param CascadeParameters#CascadeParameters parameters parameters

---
-- Function SetShadowFocus
--
-- @function [parent=#Light] SetShadowFocus
-- @param self Self reference
-- @param FocusParameters#FocusParameters parameters parameters

---
-- Function SetShadowIntensity
--
-- @function [parent=#Light] SetShadowIntensity
-- @param self Self reference
-- @param #number intensity intensity

---
-- Function SetShadowResolution
--
-- @function [parent=#Light] SetShadowResolution
-- @param self Self reference
-- @param #number resolution resolution

---
-- Function SetShadowNearFarRatio
--
-- @function [parent=#Light] SetShadowNearFarRatio
-- @param self Self reference
-- @param #number nearFarRatio nearFarRatio

---
-- Function SetRampTexture
--
-- @function [parent=#Light] SetRampTexture
-- @param self Self reference
-- @param Texture#Texture texture texture

---
-- Function SetShapeTexture
--
-- @function [parent=#Light] SetShapeTexture
-- @param self Self reference
-- @param Texture#Texture texture texture

---
-- Function GetLightType
--
-- @function [parent=#Light] GetLightType
-- @param self Self reference
-- @return LightType#LightType

---
-- Function GetPerVertex
--
-- @function [parent=#Light] GetPerVertex
-- @param self Self reference
-- @return #boolean

---
-- Function GetColor
--
-- @function [parent=#Light] GetColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetSpecularIntensity
--
-- @function [parent=#Light] GetSpecularIntensity
-- @param self Self reference
-- @return #number

---
-- Function GetRange
--
-- @function [parent=#Light] GetRange
-- @param self Self reference
-- @return #number

---
-- Function GetFov
--
-- @function [parent=#Light] GetFov
-- @param self Self reference
-- @return #number

---
-- Function GetAspectRatio
--
-- @function [parent=#Light] GetAspectRatio
-- @param self Self reference
-- @return #number

---
-- Function GetFadeDistance
--
-- @function [parent=#Light] GetFadeDistance
-- @param self Self reference
-- @return #number

---
-- Function GetShadowFadeDistance
--
-- @function [parent=#Light] GetShadowFadeDistance
-- @param self Self reference
-- @return #number

---
-- Function GetShadowBias
--
-- @function [parent=#Light] GetShadowBias
-- @param self Self reference
-- @return const BiasParameters#const BiasParameters

---
-- Function GetShadowCascade
--
-- @function [parent=#Light] GetShadowCascade
-- @param self Self reference
-- @return const CascadeParameters#const CascadeParameters

---
-- Function GetShadowFocus
--
-- @function [parent=#Light] GetShadowFocus
-- @param self Self reference
-- @return const FocusParameters#const FocusParameters

---
-- Function GetShadowIntensity
--
-- @function [parent=#Light] GetShadowIntensity
-- @param self Self reference
-- @return #number

---
-- Function GetShadowResolution
--
-- @function [parent=#Light] GetShadowResolution
-- @param self Self reference
-- @return #number

---
-- Function GetShadowNearFarRatio
--
-- @function [parent=#Light] GetShadowNearFarRatio
-- @param self Self reference
-- @return #number

---
-- Function GetRampTexture
--
-- @function [parent=#Light] GetRampTexture
-- @param self Self reference
-- @return Texture#Texture

---
-- Function GetShapeTexture
--
-- @function [parent=#Light] GetShapeTexture
-- @param self Self reference
-- @return Texture#Texture

---
-- Function GetFrustum
--
-- @function [parent=#Light] GetFrustum
-- @param self Self reference
-- @return Frustum#Frustum

---
-- Field lightType
--
-- @field [parent=#Light] LightType#LightType lightType

---
-- Field perVertex
--
-- @field [parent=#Light] #boolean perVertex

---
-- Field color
--
-- @field [parent=#Light] Color#Color color

---
-- Field specularIntensity
--
-- @field [parent=#Light] #number specularIntensity

---
-- Field range
--
-- @field [parent=#Light] #number range

---
-- Field fov
--
-- @field [parent=#Light] #number fov

---
-- Field aspectRatio
--
-- @field [parent=#Light] #number aspectRatio

---
-- Field fadeDistance
--
-- @field [parent=#Light] #number fadeDistance

---
-- Field shadowFadeDistance
--
-- @field [parent=#Light] #number shadowFadeDistance

---
-- Field shadowBias
--
-- @field [parent=#Light] BiasParameters#BiasParameters shadowBias

---
-- Field shadowCascade
--
-- @field [parent=#Light] CascadeParameters#CascadeParameters shadowCascade

---
-- Field shadowFocus
--
-- @field [parent=#Light] FocusParameters#FocusParameters shadowFocus

---
-- Field shadowIntensity
--
-- @field [parent=#Light] #number shadowIntensity

---
-- Field shadowResolution
--
-- @field [parent=#Light] #number shadowResolution

---
-- Field shadowNearFarRatio
--
-- @field [parent=#Light] #number shadowNearFarRatio

---
-- Field rampTexture
--
-- @field [parent=#Light] Texture#Texture rampTexture

---
-- Field shapeTexture
--
-- @field [parent=#Light] Texture#Texture shapeTexture

---
-- Field frustum (Read only)
--
-- @field [parent=#Light] Frustum#Frustum frustum

---
-- Function SetDrawDistance
--
-- @function [parent=#Light] SetDrawDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetShadowDistance
--
-- @function [parent=#Light] SetShadowDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetLodBias
--
-- @function [parent=#Light] SetLodBias
-- @param self Self reference
-- @param #number bias bias

---
-- Function SetViewMask
--
-- @function [parent=#Light] SetViewMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetLightMask
--
-- @function [parent=#Light] SetLightMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetShadowMask
--
-- @function [parent=#Light] SetShadowMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetZoneMask
--
-- @function [parent=#Light] SetZoneMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetMaxLights
--
-- @function [parent=#Light] SetMaxLights
-- @param self Self reference
-- @param #number num num

---
-- Function SetCastShadows
--
-- @function [parent=#Light] SetCastShadows
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetOccluder
--
-- @function [parent=#Light] SetOccluder
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetOccludee
--
-- @function [parent=#Light] SetOccludee
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function MarkForUpdate
--
-- @function [parent=#Light] MarkForUpdate
-- @param self Self reference

---
-- Function GetBoundingBox
--
-- @function [parent=#Light] GetBoundingBox
-- @param self Self reference
-- @return const BoundingBox#const BoundingBox

---
-- Function GetWorldBoundingBox
--
-- @function [parent=#Light] GetWorldBoundingBox
-- @param self Self reference
-- @return const BoundingBox#const BoundingBox

---
-- Function GetDrawableFlags
--
-- @function [parent=#Light] GetDrawableFlags
-- @param self Self reference
-- @return #string

---
-- Function GetDrawDistance
--
-- @function [parent=#Light] GetDrawDistance
-- @param self Self reference
-- @return #number

---
-- Function GetShadowDistance
--
-- @function [parent=#Light] GetShadowDistance
-- @param self Self reference
-- @return #number

---
-- Function GetLodBias
--
-- @function [parent=#Light] GetLodBias
-- @param self Self reference
-- @return #number

---
-- Function GetViewMask
--
-- @function [parent=#Light] GetViewMask
-- @param self Self reference
-- @return #number

---
-- Function GetLightMask
--
-- @function [parent=#Light] GetLightMask
-- @param self Self reference
-- @return #number

---
-- Function GetShadowMask
--
-- @function [parent=#Light] GetShadowMask
-- @param self Self reference
-- @return #number

---
-- Function GetZoneMask
--
-- @function [parent=#Light] GetZoneMask
-- @param self Self reference
-- @return #number

---
-- Function GetMaxLights
--
-- @function [parent=#Light] GetMaxLights
-- @param self Self reference
-- @return #number

---
-- Function GetCastShadows
--
-- @function [parent=#Light] GetCastShadows
-- @param self Self reference
-- @return #boolean

---
-- Function IsOccluder
--
-- @function [parent=#Light] IsOccluder
-- @param self Self reference
-- @return #boolean

---
-- Function IsOccludee
--
-- @function [parent=#Light] IsOccludee
-- @param self Self reference
-- @return #boolean

---
-- Function SetZone
--
-- @function [parent=#Light] SetZone
-- @param self Self reference
-- @param Zone#Zone zone zone
-- @param #boolean temporary temporary

---
-- Function SetSortValue
--
-- @function [parent=#Light] SetSortValue
-- @param self Self reference
-- @param #number value value

---
-- Function SetMinMaxZ
--
-- @function [parent=#Light] SetMinMaxZ
-- @param self Self reference
-- @param #number minZ minZ
-- @param #number maxZ maxZ

---
-- Function MarkInView
--
-- @function [parent=#Light] MarkInView
-- @param self Self reference
-- @param FrameInfo#FrameInfo frame frame
-- @param #boolean mainView mainView

---
-- Function ClearLights
--
-- @function [parent=#Light] ClearLights
-- @param self Self reference

---
-- Function AddLight
--
-- @function [parent=#Light] AddLight
-- @param self Self reference
-- @param Light#Light light light

---
-- Function AddVertexLight
--
-- @function [parent=#Light] AddVertexLight
-- @param self Self reference
-- @param Light#Light light light

---
-- Function LimitLights
--
-- @function [parent=#Light] LimitLights
-- @param self Self reference

---
-- Function LimitVertexLights
--
-- @function [parent=#Light] LimitVertexLights
-- @param self Self reference

---
-- Function SetBasePass
--
-- @function [parent=#Light] SetBasePass
-- @param self Self reference
-- @param #number batchIndex batchIndex

---
-- Function GetOctant
--
-- @function [parent=#Light] GetOctant
-- @param self Self reference
-- @return Octant#Octant

---
-- Function GetZone
--
-- @function [parent=#Light] GetZone
-- @param self Self reference
-- @return Zone#Zone

---
-- Function GetLastZone
--
-- @function [parent=#Light] GetLastZone
-- @param self Self reference
-- @return Zone#Zone

---
-- Function IsZoneDirty
--
-- @function [parent=#Light] IsZoneDirty
-- @param self Self reference
-- @return #boolean

---
-- Function GetDistance
--
-- @function [parent=#Light] GetDistance
-- @param self Self reference
-- @return #number

---
-- Function GetLodDistance
--
-- @function [parent=#Light] GetLodDistance
-- @param self Self reference
-- @return #number

---
-- Function GetSortValue
--
-- @function [parent=#Light] GetSortValue
-- @param self Self reference
-- @return #number

---
-- Function IsInView
--
-- @function [parent=#Light] IsInView
-- @param self Self reference
-- @param #number frameNumber frameNumber
-- @return #boolean

---
-- Function IsInView
--
-- @function [parent=#Light] IsInView
-- @param self Self reference
-- @param FrameInfo#FrameInfo frame frame
-- @param #boolean mainView mainView
-- @return #boolean

---
-- Function HasBasePass
--
-- @function [parent=#Light] HasBasePass
-- @param self Self reference
-- @param #number batchIndex batchIndex
-- @return #boolean

---
-- Function GetFirstLight
--
-- @function [parent=#Light] GetFirstLight
-- @param self Self reference
-- @return Light#Light

---
-- Function GetMinZ
--
-- @function [parent=#Light] GetMinZ
-- @param self Self reference
-- @return #number

---
-- Function GetMaxZ
--
-- @function [parent=#Light] GetMaxZ
-- @param self Self reference
-- @return #number

---
-- Field worldBoundingBox (Read only)
--
-- @field [parent=#Light] BoundingBox#BoundingBox worldBoundingBox

---
-- Field drawableFlags (Read only)
--
-- @field [parent=#Light] #string drawableFlags

---
-- Field drawDistance
--
-- @field [parent=#Light] #number drawDistance

---
-- Field shadowDistance
--
-- @field [parent=#Light] #number shadowDistance

---
-- Field lodBias
--
-- @field [parent=#Light] #number lodBias

---
-- Field viewMask
--
-- @field [parent=#Light] #number viewMask

---
-- Field lightMask
--
-- @field [parent=#Light] #number lightMask

---
-- Field shadowMask
--
-- @field [parent=#Light] #number shadowMask

---
-- Field zoneMask
--
-- @field [parent=#Light] #number zoneMask

---
-- Field maxLights
--
-- @field [parent=#Light] #number maxLights

---
-- Field castShadows
--
-- @field [parent=#Light] #boolean castShadows

---
-- Field occluder
--
-- @field [parent=#Light] #boolean occluder

---
-- Field occludee
--
-- @field [parent=#Light] #boolean occludee

---
-- Field octant (Read only)
--
-- @field [parent=#Light] Octant#Octant octant

---
-- Field zone
--
-- @field [parent=#Light] Zone#Zone zone

---
-- Field lastZone (Read only)
--
-- @field [parent=#Light] Zone#Zone lastZone

---
-- Field zoneDirty (Read only)
--
-- @field [parent=#Light] #boolean zoneDirty

---
-- Field distance (Read only)
--
-- @field [parent=#Light] #number distance

---
-- Field lodDistance (Read only)
--
-- @field [parent=#Light] #number lodDistance

---
-- Field sortValue
--
-- @field [parent=#Light] #number sortValue

---
-- Field firstLight (Read only)
--
-- @field [parent=#Light] Light#Light firstLight

---
-- Field minZ (Read only)
--
-- @field [parent=#Light] #number minZ

---
-- Field maxZ (Read only)
--
-- @field [parent=#Light] #number maxZ

---
-- Function SetEnabled
--
-- @function [parent=#Light] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Remove
--
-- @function [parent=#Light] Remove
-- @param self Self reference

---
-- Function GetID
--
-- @function [parent=#Light] GetID
-- @param self Self reference
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#Light] GetNode
-- @param self Self reference
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#Light] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#Light] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#Light] IsEnabledEffective
-- @param self Self reference
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#Light] GetComponent
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#Light] GetComponent
-- @param self Self reference
-- @param #string type type
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#Light] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#Light] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Light] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Light] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Light] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Light] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Light] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Light] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#Light] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Light] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Light] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Light] #string category


return nil
