---
-- Module Light
-- Module Light extends Drawable
-- Generated on 2014-05-31
--
-- @module Light

---
-- Function SetLightType()
-- Set light type.
--
-- @function [parent=#Light] SetLightType
-- @param self Self reference
-- @param LightType#LightType type type

---
-- Function SetPerVertex()
-- Set vertex lighting mode.
--
-- @function [parent=#Light] SetPerVertex
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetColor()
-- Set color.
--
-- @function [parent=#Light] SetColor
-- @param self Self reference
-- @param Color#Color color color

---
-- Function SetSpecularIntensity()
-- Set specular intensity. Zero disables specular calculations.
--
-- @function [parent=#Light] SetSpecularIntensity
-- @param self Self reference
-- @param #number intensity intensity

---
-- Function SetBrightness()
-- Set light brightness multiplier. Both the color and specular intensity are multiplied with this to get final values for rendering.
--
-- @function [parent=#Light] SetBrightness
-- @param self Self reference
-- @param #number brightness brightness

---
-- Function SetRange()
-- Set range.
--
-- @function [parent=#Light] SetRange
-- @param self Self reference
-- @param #number range range

---
-- Function SetFov()
-- Set spotlight field of view.
--
-- @function [parent=#Light] SetFov
-- @param self Self reference
-- @param #number fov fov

---
-- Function SetAspectRatio()
-- Set spotlight aspect ratio.
--
-- @function [parent=#Light] SetAspectRatio
-- @param self Self reference
-- @param #number aspectRatio aspectRatio

---
-- Function SetFadeDistance()
-- Set fade out start distance.
--
-- @function [parent=#Light] SetFadeDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetShadowFadeDistance()
-- Set shadow fade out start distance. Only has effect if shadow distance is also non-zero.
--
-- @function [parent=#Light] SetShadowFadeDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetShadowBias()
-- Set shadow depth bias parameters.
--
-- @function [parent=#Light] SetShadowBias
-- @param self Self reference
-- @param BiasParameters#BiasParameters parameters parameters

---
-- Function SetShadowCascade()
-- Set directional light cascaded shadow parameters.
--
-- @function [parent=#Light] SetShadowCascade
-- @param self Self reference
-- @param CascadeParameters#CascadeParameters parameters parameters

---
-- Function SetShadowFocus()
-- Set shadow map focusing parameters.
--
-- @function [parent=#Light] SetShadowFocus
-- @param self Self reference
-- @param FocusParameters#FocusParameters parameters parameters

---
-- Function SetShadowIntensity()
-- Set shadow intensity between 0.0 - 1.0. 0.0 (the default) gives fully dark shadows.
--
-- @function [parent=#Light] SetShadowIntensity
-- @param self Self reference
-- @param #number intensity intensity

---
-- Function SetShadowResolution()
-- Set shadow resolution between 0.25 - 1.0. Determines the shadow map to use.
--
-- @function [parent=#Light] SetShadowResolution
-- @param self Self reference
-- @param #number resolution resolution

---
-- Function SetShadowNearFarRatio()
-- Set shadow camera near/far clip distance ratio.
--
-- @function [parent=#Light] SetShadowNearFarRatio
-- @param self Self reference
-- @param #number nearFarRatio nearFarRatio

---
-- Function SetRampTexture()
-- Set range attenuation texture.
--
-- @function [parent=#Light] SetRampTexture
-- @param self Self reference
-- @param Texture#Texture texture texture

---
-- Function SetShapeTexture()
-- Set spotlight attenuation texture.
--
-- @function [parent=#Light] SetShapeTexture
-- @param self Self reference
-- @param Texture#Texture texture texture

---
-- Function GetLightType()
-- Return light type.
--
-- @function [parent=#Light] GetLightType
-- @param self Self reference
-- @return LightType#LightType

---
-- Function GetPerVertex()
-- Return vertex lighting mode.
--
-- @function [parent=#Light] GetPerVertex
-- @param self Self reference
-- @return #boolean

---
-- Function GetColor()
-- Return color.
--
-- @function [parent=#Light] GetColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetSpecularIntensity()
-- Return specular intensity.
--
-- @function [parent=#Light] GetSpecularIntensity
-- @param self Self reference
-- @return #number

---
-- Function GetBrightness()
-- Return brightness multiplier.
--
-- @function [parent=#Light] GetBrightness
-- @param self Self reference
-- @return #number

---
-- Function GetEffectiveColor()
-- Return whether light has negative (darkening) color.
--
-- @function [parent=#Light] GetEffectiveColor
-- @param self Self reference
-- @return Color#Color

---
-- Function GetEffectiveSpecularIntensity()
--
-- @function [parent=#Light] GetEffectiveSpecularIntensity
-- @param self Self reference
-- @return #number

---
-- Function GetRange()
-- Return range.
--
-- @function [parent=#Light] GetRange
-- @param self Self reference
-- @return #number

---
-- Function GetFov()
-- Return spotlight field of view.
--
-- @function [parent=#Light] GetFov
-- @param self Self reference
-- @return #number

---
-- Function GetAspectRatio()
-- Return spotlight aspect ratio.
--
-- @function [parent=#Light] GetAspectRatio
-- @param self Self reference
-- @return #number

---
-- Function GetFadeDistance()
-- Return fade start distance.
--
-- @function [parent=#Light] GetFadeDistance
-- @param self Self reference
-- @return #number

---
-- Function GetShadowFadeDistance()
-- Return shadow fade start distance.
--
-- @function [parent=#Light] GetShadowFadeDistance
-- @param self Self reference
-- @return #number

---
-- Function GetShadowBias()
-- Return shadow depth bias parameters.
--
-- @function [parent=#Light] GetShadowBias
-- @param self Self reference
-- @return const BiasParameters#const BiasParameters

---
-- Function GetShadowCascade()
-- Return directional light cascaded shadow parameters.
--
-- @function [parent=#Light] GetShadowCascade
-- @param self Self reference
-- @return const CascadeParameters#const CascadeParameters

---
-- Function GetShadowFocus()
-- Return shadow map focus parameters.
--
-- @function [parent=#Light] GetShadowFocus
-- @param self Self reference
-- @return const FocusParameters#const FocusParameters

---
-- Function GetShadowIntensity()
-- Return shadow intensity.
--
-- @function [parent=#Light] GetShadowIntensity
-- @param self Self reference
-- @return #number

---
-- Function GetShadowResolution()
-- Return shadow resolution.
--
-- @function [parent=#Light] GetShadowResolution
-- @param self Self reference
-- @return #number

---
-- Function GetShadowNearFarRatio()
-- Return shadow camera near/far clip distance ratio.
--
-- @function [parent=#Light] GetShadowNearFarRatio
-- @param self Self reference
-- @return #number

---
-- Function GetRampTexture()
-- Return range attenuation texture.
--
-- @function [parent=#Light] GetRampTexture
-- @param self Self reference
-- @return Texture#Texture

---
-- Function GetShapeTexture()
-- Return spotlight attenuation texture.
--
-- @function [parent=#Light] GetShapeTexture
-- @param self Self reference
-- @return Texture#Texture

---
-- Function GetFrustum()
-- Return spotlight frustum.
--
-- @function [parent=#Light] GetFrustum
-- @param self Self reference
-- @return Frustum#Frustum

---
-- Function GetNumShadowSplits()
-- Return number of shadow map cascade splits for a directional light, considering also graphics API limitations.
--
-- @function [parent=#Light] GetNumShadowSplits
-- @param self Self reference
-- @return #number

---
-- Function IsNegative()
--
-- @function [parent=#Light] IsNegative
-- @param self Self reference
-- @return #boolean

---
-- Field lightType
--
-- @field [parent=#Light] LightType#LightType lightType

---
-- Field perVertex
--
-- @field [parent=#Light] #boolean perVertex

---
-- Field color
--
-- @field [parent=#Light] Color#Color color

---
-- Field specularIntensity
--
-- @field [parent=#Light] #number specularIntensity

---
-- Field brightness
--
-- @field [parent=#Light] #number brightness

---
-- Field range
--
-- @field [parent=#Light] #number range

---
-- Field fov
--
-- @field [parent=#Light] #number fov

---
-- Field aspectRatio
--
-- @field [parent=#Light] #number aspectRatio

---
-- Field fadeDistance
--
-- @field [parent=#Light] #number fadeDistance

---
-- Field shadowFadeDistance
--
-- @field [parent=#Light] #number shadowFadeDistance

---
-- Field shadowBias
--
-- @field [parent=#Light] BiasParameters#BiasParameters shadowBias

---
-- Field shadowCascade
--
-- @field [parent=#Light] CascadeParameters#CascadeParameters shadowCascade

---
-- Field shadowFocus
--
-- @field [parent=#Light] FocusParameters#FocusParameters shadowFocus

---
-- Field shadowIntensity
--
-- @field [parent=#Light] #number shadowIntensity

---
-- Field shadowResolution
--
-- @field [parent=#Light] #number shadowResolution

---
-- Field shadowNearFarRatio
--
-- @field [parent=#Light] #number shadowNearFarRatio

---
-- Field rampTexture
--
-- @field [parent=#Light] Texture#Texture rampTexture

---
-- Field shapeTexture
--
-- @field [parent=#Light] Texture#Texture shapeTexture

---
-- Field frustum (Read only)
--
-- @field [parent=#Light] Frustum#Frustum frustum

---
-- Field numShadowSplits (Read only)
--
-- @field [parent=#Light] #number numShadowSplits

---
-- Field negative (Read only)
--
-- @field [parent=#Light] #boolean negative

---
-- Field effectiveColor (Read only)
--
-- @field [parent=#Light] Color#Color effectiveColor

---
-- Field effectiveSpecularIntensity (Read only)
--
-- @field [parent=#Light] #number effectiveSpecularIntensity


return nil
