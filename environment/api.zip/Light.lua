---
-- Module Light
-- Extends Drawable
--
-- @module Light

---
-- Function SetLightType
--
-- @function [parent=#Light] SetLightType
-- @param LightType#LightType typetype

---
-- Function SetPerVertex
--
-- @function [parent=#Light] SetPerVertex
-- @param #boolean enableenable

---
-- Function SetColor
--
-- @function [parent=#Light] SetColor
-- @param Color#Color colorcolor

---
-- Function SetSpecularIntensity
--
-- @function [parent=#Light] SetSpecularIntensity
-- @param #number intensityintensity

---
-- Function SetRange
--
-- @function [parent=#Light] SetRange
-- @param #number rangerange

---
-- Function SetFov
--
-- @function [parent=#Light] SetFov
-- @param #number fovfov

---
-- Function SetAspectRatio
--
-- @function [parent=#Light] SetAspectRatio
-- @param #number aspectRatioaspectRatio

---
-- Function SetFadeDistance
--
-- @function [parent=#Light] SetFadeDistance
-- @param #number distancedistance

---
-- Function SetShadowFadeDistance
--
-- @function [parent=#Light] SetShadowFadeDistance
-- @param #number distancedistance

---
-- Function SetShadowBias
--
-- @function [parent=#Light] SetShadowBias
-- @param BiasParameters#BiasParameters parametersparameters

---
-- Function SetShadowCascade
--
-- @function [parent=#Light] SetShadowCascade
-- @param CascadeParameters#CascadeParameters parametersparameters

---
-- Function SetShadowFocus
--
-- @function [parent=#Light] SetShadowFocus
-- @param FocusParameters#FocusParameters parametersparameters

---
-- Function SetShadowIntensity
--
-- @function [parent=#Light] SetShadowIntensity
-- @param #number intensityintensity

---
-- Function SetShadowResolution
--
-- @function [parent=#Light] SetShadowResolution
-- @param #number resolutionresolution

---
-- Function SetShadowNearFarRatio
--
-- @function [parent=#Light] SetShadowNearFarRatio
-- @param #number nearFarRationearFarRatio

---
-- Function SetRampTexture
--
-- @function [parent=#Light] SetRampTexture
-- @param Texture#Texture texturetexture

---
-- Function SetShapeTexture
--
-- @function [parent=#Light] SetShapeTexture
-- @param Texture#Texture texturetexture

---
-- Function GetLightType
--
-- @function [parent=#Light] GetLightType
-- @return LightType#LightType

---
-- Function GetPerVertex
--
-- @function [parent=#Light] GetPerVertex
-- @return #boolean

---
-- Function GetColor
--
-- @function [parent=#Light] GetColor
-- @return const Color#const Color

---
-- Function GetSpecularIntensity
--
-- @function [parent=#Light] GetSpecularIntensity
-- @return #number

---
-- Function GetRange
--
-- @function [parent=#Light] GetRange
-- @return #number

---
-- Function GetFov
--
-- @function [parent=#Light] GetFov
-- @return #number

---
-- Function GetAspectRatio
--
-- @function [parent=#Light] GetAspectRatio
-- @return #number

---
-- Function GetFadeDistance
--
-- @function [parent=#Light] GetFadeDistance
-- @return #number

---
-- Function GetShadowFadeDistance
--
-- @function [parent=#Light] GetShadowFadeDistance
-- @return #number

---
-- Function GetShadowBias
--
-- @function [parent=#Light] GetShadowBias
-- @return const BiasParameters#const BiasParameters

---
-- Function GetShadowCascade
--
-- @function [parent=#Light] GetShadowCascade
-- @return const CascadeParameters#const CascadeParameters

---
-- Function GetShadowFocus
--
-- @function [parent=#Light] GetShadowFocus
-- @return const FocusParameters#const FocusParameters

---
-- Function GetShadowIntensity
--
-- @function [parent=#Light] GetShadowIntensity
-- @return #number

---
-- Function GetShadowResolution
--
-- @function [parent=#Light] GetShadowResolution
-- @return #number

---
-- Function GetShadowNearFarRatio
--
-- @function [parent=#Light] GetShadowNearFarRatio
-- @return #number

---
-- Function GetRampTexture
--
-- @function [parent=#Light] GetRampTexture
-- @return Texture#Texture

---
-- Function GetShapeTexture
--
-- @function [parent=#Light] GetShapeTexture
-- @return Texture#Texture

---
-- Function GetFrustum
--
-- @function [parent=#Light] GetFrustum
-- @return Frustum#Frustum

---
-- Field lightType
--
-- @field [parent=#Light] LightType#LightType lightType

---
-- Field perVertex
--
-- @field [parent=#Light] #boolean perVertex

---
-- Field color
--
-- @field [parent=#Light] Color#Color color

---
-- Field specularIntensity
--
-- @field [parent=#Light] #number specularIntensity

---
-- Field range
--
-- @field [parent=#Light] #number range

---
-- Field fov
--
-- @field [parent=#Light] #number fov

---
-- Field aspectRatio
--
-- @field [parent=#Light] #number aspectRatio

---
-- Field fadeDistance
--
-- @field [parent=#Light] #number fadeDistance

---
-- Field shadowFadeDistance
--
-- @field [parent=#Light] #number shadowFadeDistance

---
-- Field shadowBias
--
-- @field [parent=#Light] BiasParameters#BiasParameters shadowBias

---
-- Field shadowCascade
--
-- @field [parent=#Light] CascadeParameters#CascadeParameters shadowCascade

---
-- Field shadowFocus
--
-- @field [parent=#Light] FocusParameters#FocusParameters shadowFocus

---
-- Field shadowIntensity
--
-- @field [parent=#Light] #number shadowIntensity

---
-- Field shadowResolution
--
-- @field [parent=#Light] #number shadowResolution

---
-- Field shadowNearFarRatio
--
-- @field [parent=#Light] #number shadowNearFarRatio

---
-- Field rampTexture
--
-- @field [parent=#Light] Texture#Texture rampTexture

---
-- Field shapeTexture
--
-- @field [parent=#Light] Texture#Texture shapeTexture

---
-- Field frustum (Read only)
--
-- @field [parent=#Light] Frustum#Frustum frustum


return nil
