---
-- Module Constraint2D
-- Module Constraint2D extends Component
-- Generated on 2014-05-31
--
-- @module Constraint2D

---
-- Function SetOtherBody()
-- Set other rigid body.
--
-- @function [parent=#Constraint2D] SetOtherBody
-- @param self Self reference
-- @param RigidBody2D#RigidBody2D body body

---
-- Function SetCollideConnected()
-- Set collide connected.
--
-- @function [parent=#Constraint2D] SetCollideConnected
-- @param self Self reference
-- @param #boolean collideConnected collideConnected

---
-- Function GetOwnerBody()
-- Return owner body.
--
-- @function [parent=#Constraint2D] GetOwnerBody
-- @param self Self reference
-- @return RigidBody2D#RigidBody2D

---
-- Function GetOtherBody()
-- Return other body.
--
-- @function [parent=#Constraint2D] GetOtherBody
-- @param self Self reference
-- @return RigidBody2D#RigidBody2D

---
-- Function GetCollideConnected()
-- Return collide connected.
--
-- @function [parent=#Constraint2D] GetCollideConnected
-- @param self Self reference
-- @return #boolean

---
-- Field ownerBody (Read only)
--
-- @field [parent=#Constraint2D] RigidBody2D#RigidBody2D ownerBody

---
-- Field otherBody
--
-- @field [parent=#Constraint2D] RigidBody2D#RigidBody2D otherBody

---
-- Field collideConnected
--
-- @field [parent=#Constraint2D] #boolean collideConnected


return nil
