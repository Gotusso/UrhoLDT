---
-- Module Matrix3
--
-- @module Matrix3

---
-- Function Matrix3
--
-- @function [parent=#Matrix3] Matrix3

---
-- Function new
--
-- @function [parent=#Matrix3] new
-- @return Matrix3#Matrix3

---
-- Function Matrix3
--
-- @function [parent=#Matrix3] Matrix3
-- @param Matrix3#Matrix3 matrixmatrix

---
-- Function new
--
-- @function [parent=#Matrix3] new
-- @param Matrix3#Matrix3 matrixmatrix
-- @return Matrix3#Matrix3

---
-- Function Matrix3
--
-- @function [parent=#Matrix3] Matrix3
-- @param #number v00v00
-- @param #number v01v01
-- @param #number v02v02
-- @param #number v10v10
-- @param #number v11v11
-- @param #number v12v12
-- @param #number v20v20
-- @param #number v21v21
-- @param #number v22v22

---
-- Function new
--
-- @function [parent=#Matrix3] new
-- @param #number v00v00
-- @param #number v01v01
-- @param #number v02v02
-- @param #number v10v10
-- @param #number v11v11
-- @param #number v12v12
-- @param #number v20v20
-- @param #number v21v21
-- @param #number v22v22
-- @return Matrix3#Matrix3

---
-- Function delete
--
-- @function [parent=#Matrix3] delete

---
-- Function operator==
--
-- @function [parent=#Matrix3] operator==
-- @param Matrix3#Matrix3 rhsrhs
-- @return #boolean

---
-- Function operator*
--
-- @function [parent=#Matrix3] operator*
-- @param Vector3#Vector3 rhsrhs
-- @return Vector3#Vector3

---
-- Function operator+
--
-- @function [parent=#Matrix3] operator+
-- @param Matrix3#Matrix3 rhsrhs
-- @return Matrix3#Matrix3

---
-- Function operator-
--
-- @function [parent=#Matrix3] operator-
-- @param Matrix3#Matrix3 rhsrhs
-- @return Matrix3#Matrix3

---
-- Function operator*
--
-- @function [parent=#Matrix3] operator*
-- @param #number rhsrhs
-- @return Matrix3#Matrix3

---
-- Function operator*
--
-- @function [parent=#Matrix3] operator*
-- @param Matrix3#Matrix3 rhsrhs
-- @return Matrix3#Matrix3

---
-- Function SetScale
--
-- @function [parent=#Matrix3] SetScale
-- @param Vector3#Vector3 scalescale

---
-- Function SetScale
--
-- @function [parent=#Matrix3] SetScale
-- @param #number scalescale

---
-- Function Scale
--
-- @function [parent=#Matrix3] Scale
-- @return Vector3#Vector3

---
-- Function Transpose
--
-- @function [parent=#Matrix3] Transpose
-- @return Matrix3#Matrix3

---
-- Function Scaled
--
-- @function [parent=#Matrix3] Scaled
-- @param Vector3#Vector3 scalescale
-- @return Matrix3#Matrix3

---
-- Function Equals
--
-- @function [parent=#Matrix3] Equals
-- @param Matrix3#Matrix3 rhsrhs
-- @return #boolean

---
-- Function Inverse
--
-- @function [parent=#Matrix3] Inverse
-- @return Matrix3#Matrix3

---
-- Field m00
--
-- @field [parent=#Matrix3] #number m00

---
-- Field m01
--
-- @field [parent=#Matrix3] #number m01

---
-- Field m02
--
-- @field [parent=#Matrix3] #number m02

---
-- Field m10
--
-- @field [parent=#Matrix3] #number m10

---
-- Field m11
--
-- @field [parent=#Matrix3] #number m11

---
-- Field m12
--
-- @field [parent=#Matrix3] #number m12

---
-- Field m20
--
-- @field [parent=#Matrix3] #number m20

---
-- Field m21
--
-- @field [parent=#Matrix3] #number m21

---
-- Field m22
--
-- @field [parent=#Matrix3] #number m22

---
-- Field ZERO
--
-- @field [parent=#Matrix3] Matrix3#Matrix3 ZERO

---
-- Field IDENTITY
--
-- @field [parent=#Matrix3] Matrix3#Matrix3 IDENTITY


return nil
