---
-- Module Matrix3
-- Generated on 2014-03-13
--
-- @module Matrix3

---
-- Function Matrix3
--
-- @function [parent=#Matrix3] Matrix3
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#Matrix3] new
-- @param self Self reference
-- @return Matrix3#Matrix3

---
-- Function Matrix3
--
-- @function [parent=#Matrix3] Matrix3
-- @param self Self reference
-- @param Matrix3#Matrix3 matrix matrix

---
-- Function new
--
-- @function [parent=#Matrix3] new
-- @param self Self reference
-- @param Matrix3#Matrix3 matrix matrix
-- @return Matrix3#Matrix3

---
-- Function Matrix3
--
-- @function [parent=#Matrix3] Matrix3
-- @param self Self reference
-- @param #number v00 v00
-- @param #number v01 v01
-- @param #number v02 v02
-- @param #number v10 v10
-- @param #number v11 v11
-- @param #number v12 v12
-- @param #number v20 v20
-- @param #number v21 v21
-- @param #number v22 v22

---
-- Function new
--
-- @function [parent=#Matrix3] new
-- @param self Self reference
-- @param #number v00 v00
-- @param #number v01 v01
-- @param #number v02 v02
-- @param #number v10 v10
-- @param #number v11 v11
-- @param #number v12 v12
-- @param #number v20 v20
-- @param #number v21 v21
-- @param #number v22 v22
-- @return Matrix3#Matrix3

---
-- Function delete
--
-- @function [parent=#Matrix3] delete
-- @param self Self reference

---
-- Function operator==
--
-- @function [parent=#Matrix3] operator==
-- @param self Self reference
-- @param Matrix3#Matrix3 rhs rhs
-- @return #boolean

---
-- Function operator*
--
-- @function [parent=#Matrix3] operator*
-- @param self Self reference
-- @param Vector3#Vector3 rhs rhs
-- @return Vector3#Vector3

---
-- Function operator+
--
-- @function [parent=#Matrix3] operator+
-- @param self Self reference
-- @param Matrix3#Matrix3 rhs rhs
-- @return Matrix3#Matrix3

---
-- Function operator-
--
-- @function [parent=#Matrix3] operator-
-- @param self Self reference
-- @param Matrix3#Matrix3 rhs rhs
-- @return Matrix3#Matrix3

---
-- Function operator*
--
-- @function [parent=#Matrix3] operator*
-- @param self Self reference
-- @param #number rhs rhs
-- @return Matrix3#Matrix3

---
-- Function operator*
--
-- @function [parent=#Matrix3] operator*
-- @param self Self reference
-- @param Matrix3#Matrix3 rhs rhs
-- @return Matrix3#Matrix3

---
-- Function SetScale
--
-- @function [parent=#Matrix3] SetScale
-- @param self Self reference
-- @param Vector3#Vector3 scale scale

---
-- Function SetScale
--
-- @function [parent=#Matrix3] SetScale
-- @param self Self reference
-- @param #number scale scale

---
-- Function Scale
--
-- @function [parent=#Matrix3] Scale
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function Transpose
--
-- @function [parent=#Matrix3] Transpose
-- @param self Self reference
-- @return Matrix3#Matrix3

---
-- Function Scaled
--
-- @function [parent=#Matrix3] Scaled
-- @param self Self reference
-- @param Vector3#Vector3 scale scale
-- @return Matrix3#Matrix3

---
-- Function Equals
--
-- @function [parent=#Matrix3] Equals
-- @param self Self reference
-- @param Matrix3#Matrix3 rhs rhs
-- @return #boolean

---
-- Function Inverse
--
-- @function [parent=#Matrix3] Inverse
-- @param self Self reference
-- @return Matrix3#Matrix3

---
-- Field m00
--
-- @field [parent=#Matrix3] #number m00

---
-- Field m01
--
-- @field [parent=#Matrix3] #number m01

---
-- Field m02
--
-- @field [parent=#Matrix3] #number m02

---
-- Field m10
--
-- @field [parent=#Matrix3] #number m10

---
-- Field m11
--
-- @field [parent=#Matrix3] #number m11

---
-- Field m12
--
-- @field [parent=#Matrix3] #number m12

---
-- Field m20
--
-- @field [parent=#Matrix3] #number m20

---
-- Field m21
--
-- @field [parent=#Matrix3] #number m21

---
-- Field m22
--
-- @field [parent=#Matrix3] #number m22

---
-- Field ZERO
--
-- @field [parent=#Matrix3] Matrix3#Matrix3 ZERO

---
-- Field IDENTITY
--
-- @field [parent=#Matrix3] Matrix3#Matrix3 IDENTITY


return nil
