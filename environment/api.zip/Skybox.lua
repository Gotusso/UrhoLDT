---
-- Module Skybox
-- Module Skybox extends StaticModel
-- Generated on 2014-03-13
--
-- @module Skybox

---
-- Function SetModel
--
-- @function [parent=#Skybox] SetModel
-- @param self Self reference
-- @param Model#Model model model

---
-- Function SetMaterial
--
-- @function [parent=#Skybox] SetMaterial
-- @param self Self reference
-- @param Material#Material material material

---
-- Function SetMaterial
--
-- @function [parent=#Skybox] SetMaterial
-- @param self Self reference
-- @param #number index index
-- @param Material#Material material material
-- @return #boolean

---
-- Function SetOcclusionLodLevel
--
-- @function [parent=#Skybox] SetOcclusionLodLevel
-- @param self Self reference
-- @param #number level level

---
-- Function ApplyMaterialList
--
-- @function [parent=#Skybox] ApplyMaterialList
-- @param self Self reference
-- @param #string fileName fileName

---
-- Function GetModel
--
-- @function [parent=#Skybox] GetModel
-- @param self Self reference
-- @return Model#Model

---
-- Function GetNumGeometries
--
-- @function [parent=#Skybox] GetNumGeometries
-- @param self Self reference
-- @return #number

---
-- Function GetMaterial
--
-- @function [parent=#Skybox] GetMaterial
-- @param self Self reference
-- @param #number index index
-- @return Material#Material

---
-- Function GetOcclusionLodLevel
--
-- @function [parent=#Skybox] GetOcclusionLodLevel
-- @param self Self reference
-- @return #number

---
-- Function IsInside
--
-- @function [parent=#Skybox] IsInside
-- @param self Self reference
-- @param Vector3#Vector3 point point
-- @return #boolean

---
-- Function IsInsideLocal
--
-- @function [parent=#Skybox] IsInsideLocal
-- @param self Self reference
-- @param Vector3#Vector3 point point
-- @return #boolean

---
-- Field model
--
-- @field [parent=#Skybox] Model#Model model

---
-- Field material
--
-- @field [parent=#Skybox] Material#Material material

---
-- Field boundingBox (Read only)
--
-- @field [parent=#Skybox] BoundingBox#BoundingBox boundingBox

---
-- Field numGeometries (Read only)
--
-- @field [parent=#Skybox] #number numGeometries

---
-- Field occlusionLodLevel
--
-- @field [parent=#Skybox] #number occlusionLodLevel

---
-- Function SetDrawDistance
--
-- @function [parent=#Skybox] SetDrawDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetShadowDistance
--
-- @function [parent=#Skybox] SetShadowDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetLodBias
--
-- @function [parent=#Skybox] SetLodBias
-- @param self Self reference
-- @param #number bias bias

---
-- Function SetViewMask
--
-- @function [parent=#Skybox] SetViewMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetLightMask
--
-- @function [parent=#Skybox] SetLightMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetShadowMask
--
-- @function [parent=#Skybox] SetShadowMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetZoneMask
--
-- @function [parent=#Skybox] SetZoneMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetMaxLights
--
-- @function [parent=#Skybox] SetMaxLights
-- @param self Self reference
-- @param #number num num

---
-- Function SetCastShadows
--
-- @function [parent=#Skybox] SetCastShadows
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetOccluder
--
-- @function [parent=#Skybox] SetOccluder
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetOccludee
--
-- @function [parent=#Skybox] SetOccludee
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function MarkForUpdate
--
-- @function [parent=#Skybox] MarkForUpdate
-- @param self Self reference

---
-- Function GetBoundingBox
--
-- @function [parent=#Skybox] GetBoundingBox
-- @param self Self reference
-- @return const BoundingBox#const BoundingBox

---
-- Function GetWorldBoundingBox
--
-- @function [parent=#Skybox] GetWorldBoundingBox
-- @param self Self reference
-- @return const BoundingBox#const BoundingBox

---
-- Function GetDrawableFlags
--
-- @function [parent=#Skybox] GetDrawableFlags
-- @param self Self reference
-- @return #string

---
-- Function GetDrawDistance
--
-- @function [parent=#Skybox] GetDrawDistance
-- @param self Self reference
-- @return #number

---
-- Function GetShadowDistance
--
-- @function [parent=#Skybox] GetShadowDistance
-- @param self Self reference
-- @return #number

---
-- Function GetLodBias
--
-- @function [parent=#Skybox] GetLodBias
-- @param self Self reference
-- @return #number

---
-- Function GetViewMask
--
-- @function [parent=#Skybox] GetViewMask
-- @param self Self reference
-- @return #number

---
-- Function GetLightMask
--
-- @function [parent=#Skybox] GetLightMask
-- @param self Self reference
-- @return #number

---
-- Function GetShadowMask
--
-- @function [parent=#Skybox] GetShadowMask
-- @param self Self reference
-- @return #number

---
-- Function GetZoneMask
--
-- @function [parent=#Skybox] GetZoneMask
-- @param self Self reference
-- @return #number

---
-- Function GetMaxLights
--
-- @function [parent=#Skybox] GetMaxLights
-- @param self Self reference
-- @return #number

---
-- Function GetCastShadows
--
-- @function [parent=#Skybox] GetCastShadows
-- @param self Self reference
-- @return #boolean

---
-- Function IsOccluder
--
-- @function [parent=#Skybox] IsOccluder
-- @param self Self reference
-- @return #boolean

---
-- Function IsOccludee
--
-- @function [parent=#Skybox] IsOccludee
-- @param self Self reference
-- @return #boolean

---
-- Function SetZone
--
-- @function [parent=#Skybox] SetZone
-- @param self Self reference
-- @param Zone#Zone zone zone
-- @param #boolean temporary temporary

---
-- Function SetSortValue
--
-- @function [parent=#Skybox] SetSortValue
-- @param self Self reference
-- @param #number value value

---
-- Function SetMinMaxZ
--
-- @function [parent=#Skybox] SetMinMaxZ
-- @param self Self reference
-- @param #number minZ minZ
-- @param #number maxZ maxZ

---
-- Function MarkInView
--
-- @function [parent=#Skybox] MarkInView
-- @param self Self reference
-- @param FrameInfo#FrameInfo frame frame
-- @param #boolean mainView mainView

---
-- Function ClearLights
--
-- @function [parent=#Skybox] ClearLights
-- @param self Self reference

---
-- Function AddLight
--
-- @function [parent=#Skybox] AddLight
-- @param self Self reference
-- @param Light#Light light light

---
-- Function AddVertexLight
--
-- @function [parent=#Skybox] AddVertexLight
-- @param self Self reference
-- @param Light#Light light light

---
-- Function LimitLights
--
-- @function [parent=#Skybox] LimitLights
-- @param self Self reference

---
-- Function LimitVertexLights
--
-- @function [parent=#Skybox] LimitVertexLights
-- @param self Self reference

---
-- Function SetBasePass
--
-- @function [parent=#Skybox] SetBasePass
-- @param self Self reference
-- @param #number batchIndex batchIndex

---
-- Function GetOctant
--
-- @function [parent=#Skybox] GetOctant
-- @param self Self reference
-- @return Octant#Octant

---
-- Function GetZone
--
-- @function [parent=#Skybox] GetZone
-- @param self Self reference
-- @return Zone#Zone

---
-- Function GetLastZone
--
-- @function [parent=#Skybox] GetLastZone
-- @param self Self reference
-- @return Zone#Zone

---
-- Function IsZoneDirty
--
-- @function [parent=#Skybox] IsZoneDirty
-- @param self Self reference
-- @return #boolean

---
-- Function GetDistance
--
-- @function [parent=#Skybox] GetDistance
-- @param self Self reference
-- @return #number

---
-- Function GetLodDistance
--
-- @function [parent=#Skybox] GetLodDistance
-- @param self Self reference
-- @return #number

---
-- Function GetSortValue
--
-- @function [parent=#Skybox] GetSortValue
-- @param self Self reference
-- @return #number

---
-- Function IsInView
--
-- @function [parent=#Skybox] IsInView
-- @param self Self reference
-- @param #number frameNumber frameNumber
-- @return #boolean

---
-- Function IsInView
--
-- @function [parent=#Skybox] IsInView
-- @param self Self reference
-- @param FrameInfo#FrameInfo frame frame
-- @param #boolean mainView mainView
-- @return #boolean

---
-- Function HasBasePass
--
-- @function [parent=#Skybox] HasBasePass
-- @param self Self reference
-- @param #number batchIndex batchIndex
-- @return #boolean

---
-- Function GetFirstLight
--
-- @function [parent=#Skybox] GetFirstLight
-- @param self Self reference
-- @return Light#Light

---
-- Function GetMinZ
--
-- @function [parent=#Skybox] GetMinZ
-- @param self Self reference
-- @return #number

---
-- Function GetMaxZ
--
-- @function [parent=#Skybox] GetMaxZ
-- @param self Self reference
-- @return #number

---
-- Field worldBoundingBox (Read only)
--
-- @field [parent=#Skybox] BoundingBox#BoundingBox worldBoundingBox

---
-- Field drawableFlags (Read only)
--
-- @field [parent=#Skybox] #string drawableFlags

---
-- Field drawDistance
--
-- @field [parent=#Skybox] #number drawDistance

---
-- Field shadowDistance
--
-- @field [parent=#Skybox] #number shadowDistance

---
-- Field lodBias
--
-- @field [parent=#Skybox] #number lodBias

---
-- Field viewMask
--
-- @field [parent=#Skybox] #number viewMask

---
-- Field lightMask
--
-- @field [parent=#Skybox] #number lightMask

---
-- Field shadowMask
--
-- @field [parent=#Skybox] #number shadowMask

---
-- Field zoneMask
--
-- @field [parent=#Skybox] #number zoneMask

---
-- Field maxLights
--
-- @field [parent=#Skybox] #number maxLights

---
-- Field castShadows
--
-- @field [parent=#Skybox] #boolean castShadows

---
-- Field occluder
--
-- @field [parent=#Skybox] #boolean occluder

---
-- Field occludee
--
-- @field [parent=#Skybox] #boolean occludee

---
-- Field octant (Read only)
--
-- @field [parent=#Skybox] Octant#Octant octant

---
-- Field zone
--
-- @field [parent=#Skybox] Zone#Zone zone

---
-- Field lastZone (Read only)
--
-- @field [parent=#Skybox] Zone#Zone lastZone

---
-- Field zoneDirty (Read only)
--
-- @field [parent=#Skybox] #boolean zoneDirty

---
-- Field distance (Read only)
--
-- @field [parent=#Skybox] #number distance

---
-- Field lodDistance (Read only)
--
-- @field [parent=#Skybox] #number lodDistance

---
-- Field sortValue
--
-- @field [parent=#Skybox] #number sortValue

---
-- Field firstLight (Read only)
--
-- @field [parent=#Skybox] Light#Light firstLight

---
-- Field minZ (Read only)
--
-- @field [parent=#Skybox] #number minZ

---
-- Field maxZ (Read only)
--
-- @field [parent=#Skybox] #number maxZ

---
-- Function SetEnabled
--
-- @function [parent=#Skybox] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Remove
--
-- @function [parent=#Skybox] Remove
-- @param self Self reference

---
-- Function GetID
--
-- @function [parent=#Skybox] GetID
-- @param self Self reference
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#Skybox] GetNode
-- @param self Self reference
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#Skybox] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#Skybox] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#Skybox] IsEnabledEffective
-- @param self Self reference
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#Skybox] GetComponent
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#Skybox] GetComponent
-- @param self Self reference
-- @param #string type type
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#Skybox] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#Skybox] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Skybox] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Skybox] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Skybox] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Skybox] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Skybox] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Skybox] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#Skybox] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Skybox] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Skybox] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Skybox] #string category


return nil
