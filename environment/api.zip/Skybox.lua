---
-- Module Skybox
-- extends StaticModel
--
-- @module Skybox

---
-- Function SetModel
--
-- @function [parent=#Skybox] SetModel
-- @param Model#Model modelmodel

---
-- Function SetMaterial
--
-- @function [parent=#Skybox] SetMaterial
-- @param Material#Material materialmaterial

---
-- Function SetMaterial
--
-- @function [parent=#Skybox] SetMaterial
-- @param #number indexindex
-- @param Material#Material materialmaterial
-- @return #boolean

---
-- Function SetOcclusionLodLevel
--
-- @function [parent=#Skybox] SetOcclusionLodLevel
-- @param #number levellevel

---
-- Function ApplyMaterialList
--
-- @function [parent=#Skybox] ApplyMaterialList
-- @param #string fileNamefileName

---
-- Function GetModel
--
-- @function [parent=#Skybox] GetModel
-- @return Model#Model

---
-- Function GetNumGeometries
--
-- @function [parent=#Skybox] GetNumGeometries
-- @return #number

---
-- Function GetMaterial
--
-- @function [parent=#Skybox] GetMaterial
-- @param #number indexindex
-- @return Material#Material

---
-- Function GetOcclusionLodLevel
--
-- @function [parent=#Skybox] GetOcclusionLodLevel
-- @return #number

---
-- Function IsInside
--
-- @function [parent=#Skybox] IsInside
-- @param Vector3#Vector3 pointpoint
-- @return #boolean

---
-- Function IsInsideLocal
--
-- @function [parent=#Skybox] IsInsideLocal
-- @param Vector3#Vector3 pointpoint
-- @return #boolean

---
-- Field model
--
-- @field [parent=#Skybox] Model#Model model

---
-- Field material
--
-- @field [parent=#Skybox] Material#Material material

---
-- Field boundingBox (Read only)
--
-- @field [parent=#Skybox] BoundingBox#BoundingBox boundingBox

---
-- Field numGeometries (Read only)
--
-- @field [parent=#Skybox] #number numGeometries

---
-- Field occlusionLodLevel
--
-- @field [parent=#Skybox] #number occlusionLodLevel

---
-- Function SetDrawDistance
--
-- @function [parent=#Skybox] SetDrawDistance
-- @param #number distancedistance

---
-- Function SetShadowDistance
--
-- @function [parent=#Skybox] SetShadowDistance
-- @param #number distancedistance

---
-- Function SetLodBias
--
-- @function [parent=#Skybox] SetLodBias
-- @param #number biasbias

---
-- Function SetViewMask
--
-- @function [parent=#Skybox] SetViewMask
-- @param #number maskmask

---
-- Function SetLightMask
--
-- @function [parent=#Skybox] SetLightMask
-- @param #number maskmask

---
-- Function SetShadowMask
--
-- @function [parent=#Skybox] SetShadowMask
-- @param #number maskmask

---
-- Function SetZoneMask
--
-- @function [parent=#Skybox] SetZoneMask
-- @param #number maskmask

---
-- Function SetMaxLights
--
-- @function [parent=#Skybox] SetMaxLights
-- @param #number numnum

---
-- Function SetCastShadows
--
-- @function [parent=#Skybox] SetCastShadows
-- @param #boolean enableenable

---
-- Function SetOccluder
--
-- @function [parent=#Skybox] SetOccluder
-- @param #boolean enableenable

---
-- Function SetOccludee
--
-- @function [parent=#Skybox] SetOccludee
-- @param #boolean enableenable

---
-- Function MarkForUpdate
--
-- @function [parent=#Skybox] MarkForUpdate

---
-- Function GetBoundingBox
--
-- @function [parent=#Skybox] GetBoundingBox
-- @return const BoundingBox#const BoundingBox

---
-- Function GetWorldBoundingBox
--
-- @function [parent=#Skybox] GetWorldBoundingBox
-- @return const BoundingBox#const BoundingBox

---
-- Function GetDrawableFlags
--
-- @function [parent=#Skybox] GetDrawableFlags
-- @return #string

---
-- Function GetDrawDistance
--
-- @function [parent=#Skybox] GetDrawDistance
-- @return #number

---
-- Function GetShadowDistance
--
-- @function [parent=#Skybox] GetShadowDistance
-- @return #number

---
-- Function GetLodBias
--
-- @function [parent=#Skybox] GetLodBias
-- @return #number

---
-- Function GetViewMask
--
-- @function [parent=#Skybox] GetViewMask
-- @return #number

---
-- Function GetLightMask
--
-- @function [parent=#Skybox] GetLightMask
-- @return #number

---
-- Function GetShadowMask
--
-- @function [parent=#Skybox] GetShadowMask
-- @return #number

---
-- Function GetZoneMask
--
-- @function [parent=#Skybox] GetZoneMask
-- @return #number

---
-- Function GetMaxLights
--
-- @function [parent=#Skybox] GetMaxLights
-- @return #number

---
-- Function GetCastShadows
--
-- @function [parent=#Skybox] GetCastShadows
-- @return #boolean

---
-- Function IsOccluder
--
-- @function [parent=#Skybox] IsOccluder
-- @return #boolean

---
-- Function IsOccludee
--
-- @function [parent=#Skybox] IsOccludee
-- @return #boolean

---
-- Function SetZone
--
-- @function [parent=#Skybox] SetZone
-- @param Zone#Zone zonezone
-- @param #boolean temporarytemporary

---
-- Function SetSortValue
--
-- @function [parent=#Skybox] SetSortValue
-- @param #number valuevalue

---
-- Function SetMinMaxZ
--
-- @function [parent=#Skybox] SetMinMaxZ
-- @param #number minZminZ
-- @param #number maxZmaxZ

---
-- Function MarkInView
--
-- @function [parent=#Skybox] MarkInView
-- @param FrameInfo#FrameInfo frameframe
-- @param #boolean mainViewmainView

---
-- Function ClearLights
--
-- @function [parent=#Skybox] ClearLights

---
-- Function AddLight
--
-- @function [parent=#Skybox] AddLight
-- @param Light#Light lightlight

---
-- Function AddVertexLight
--
-- @function [parent=#Skybox] AddVertexLight
-- @param Light#Light lightlight

---
-- Function LimitLights
--
-- @function [parent=#Skybox] LimitLights

---
-- Function LimitVertexLights
--
-- @function [parent=#Skybox] LimitVertexLights

---
-- Function SetBasePass
--
-- @function [parent=#Skybox] SetBasePass
-- @param #number batchIndexbatchIndex

---
-- Function GetOctant
--
-- @function [parent=#Skybox] GetOctant
-- @return Octant#Octant

---
-- Function GetZone
--
-- @function [parent=#Skybox] GetZone
-- @return Zone#Zone

---
-- Function GetLastZone
--
-- @function [parent=#Skybox] GetLastZone
-- @return Zone#Zone

---
-- Function IsZoneDirty
--
-- @function [parent=#Skybox] IsZoneDirty
-- @return #boolean

---
-- Function GetDistance
--
-- @function [parent=#Skybox] GetDistance
-- @return #number

---
-- Function GetLodDistance
--
-- @function [parent=#Skybox] GetLodDistance
-- @return #number

---
-- Function GetSortValue
--
-- @function [parent=#Skybox] GetSortValue
-- @return #number

---
-- Function IsInView
--
-- @function [parent=#Skybox] IsInView
-- @param #number frameNumberframeNumber
-- @return #boolean

---
-- Function IsInView
--
-- @function [parent=#Skybox] IsInView
-- @param FrameInfo#FrameInfo frameframe
-- @param #boolean mainViewmainView
-- @return #boolean

---
-- Function HasBasePass
--
-- @function [parent=#Skybox] HasBasePass
-- @param #number batchIndexbatchIndex
-- @return #boolean

---
-- Function GetFirstLight
--
-- @function [parent=#Skybox] GetFirstLight
-- @return Light#Light

---
-- Function GetMinZ
--
-- @function [parent=#Skybox] GetMinZ
-- @return #number

---
-- Function GetMaxZ
--
-- @function [parent=#Skybox] GetMaxZ
-- @return #number

---
-- Field worldBoundingBox (Read only)
--
-- @field [parent=#Skybox] BoundingBox#BoundingBox worldBoundingBox

---
-- Field drawableFlags (Read only)
--
-- @field [parent=#Skybox] #string drawableFlags

---
-- Field drawDistance
--
-- @field [parent=#Skybox] #number drawDistance

---
-- Field shadowDistance
--
-- @field [parent=#Skybox] #number shadowDistance

---
-- Field lodBias
--
-- @field [parent=#Skybox] #number lodBias

---
-- Field viewMask
--
-- @field [parent=#Skybox] #number viewMask

---
-- Field lightMask
--
-- @field [parent=#Skybox] #number lightMask

---
-- Field shadowMask
--
-- @field [parent=#Skybox] #number shadowMask

---
-- Field zoneMask
--
-- @field [parent=#Skybox] #number zoneMask

---
-- Field maxLights
--
-- @field [parent=#Skybox] #number maxLights

---
-- Field castShadows
--
-- @field [parent=#Skybox] #boolean castShadows

---
-- Field occluder
--
-- @field [parent=#Skybox] #boolean occluder

---
-- Field occludee
--
-- @field [parent=#Skybox] #boolean occludee

---
-- Field octant (Read only)
--
-- @field [parent=#Skybox] Octant#Octant octant

---
-- Field zone
--
-- @field [parent=#Skybox] Zone#Zone zone

---
-- Field lastZone (Read only)
--
-- @field [parent=#Skybox] Zone#Zone lastZone

---
-- Field zoneDirty (Read only)
--
-- @field [parent=#Skybox] #boolean zoneDirty

---
-- Field distance (Read only)
--
-- @field [parent=#Skybox] #number distance

---
-- Field lodDistance (Read only)
--
-- @field [parent=#Skybox] #number lodDistance

---
-- Field sortValue
--
-- @field [parent=#Skybox] #number sortValue

---
-- Field firstLight (Read only)
--
-- @field [parent=#Skybox] Light#Light firstLight

---
-- Field minZ (Read only)
--
-- @field [parent=#Skybox] #number minZ

---
-- Field maxZ (Read only)
--
-- @field [parent=#Skybox] #number maxZ

---
-- Function SetEnabled
--
-- @function [parent=#Skybox] SetEnabled
-- @param #boolean enableenable

---
-- Function Remove
--
-- @function [parent=#Skybox] Remove

---
-- Function GetID
--
-- @function [parent=#Skybox] GetID
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#Skybox] GetNode
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#Skybox] GetScene
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#Skybox] IsEnabled
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#Skybox] IsEnabledEffective
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#Skybox] GetComponent
-- @param ShortStringHash#ShortStringHash typetype
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#Skybox] GetComponent
-- @param #string typetype
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#Skybox] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#Skybox] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Skybox] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Skybox] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Skybox] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Skybox] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Skybox] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Skybox] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#Skybox] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Skybox] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Skybox] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Skybox] #string category


return nil
