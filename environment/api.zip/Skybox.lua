---
-- Module Skybox
-- Module Skybox extends StaticModel
-- Generated on 2014-05-31
--
-- @module Skybox


return nil
