---
-- Module Skybox
-- Extends StaticModel
--
-- @module Skybox


return nil
