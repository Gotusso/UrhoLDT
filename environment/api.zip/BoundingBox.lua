---
-- Module BoundingBox
-- Generated on 2014-05-31
--
-- @module BoundingBox

---
-- Function BoundingBox()
-- Construct with zero size.
--
-- @function [parent=#BoundingBox] BoundingBox
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#BoundingBox] new
-- @param self Self reference
-- @return BoundingBox#BoundingBox

---
-- Function BoundingBox()
--
-- @function [parent=#BoundingBox] BoundingBox
-- @param self Self reference
-- @param BoundingBox#BoundingBox box box

---
-- Function new()
--
-- @function [parent=#BoundingBox] new
-- @param self Self reference
-- @param BoundingBox#BoundingBox box box
-- @return BoundingBox#BoundingBox

---
-- Function BoundingBox()
--
-- @function [parent=#BoundingBox] BoundingBox
-- @param self Self reference
-- @param Rect#Rect rect rect

---
-- Function new()
--
-- @function [parent=#BoundingBox] new
-- @param self Self reference
-- @param Rect#Rect rect rect
-- @return BoundingBox#BoundingBox

---
-- Function BoundingBox()
--
-- @function [parent=#BoundingBox] BoundingBox
-- @param self Self reference
-- @param Vector3#Vector3 min min
-- @param Vector3#Vector3 max max

---
-- Function new()
--
-- @function [parent=#BoundingBox] new
-- @param self Self reference
-- @param Vector3#Vector3 min min
-- @param Vector3#Vector3 max max
-- @return BoundingBox#BoundingBox

---
-- Function BoundingBox()
--
-- @function [parent=#BoundingBox] BoundingBox
-- @param self Self reference
-- @param #number min min
-- @param #number max max

---
-- Function new()
--
-- @function [parent=#BoundingBox] new
-- @param self Self reference
-- @param #number min min
-- @param #number max max
-- @return BoundingBox#BoundingBox

---
-- Function BoundingBox()
--
-- @function [parent=#BoundingBox] BoundingBox
-- @param self Self reference
-- @param Frustum#Frustum frustum frustum

---
-- Function new()
--
-- @function [parent=#BoundingBox] new
-- @param self Self reference
-- @param Frustum#Frustum frustum frustum
-- @return BoundingBox#BoundingBox

---
-- Function BoundingBox()
--
-- @function [parent=#BoundingBox] BoundingBox
-- @param self Self reference
-- @param Polyhedron#Polyhedron poly poly

---
-- Function new()
--
-- @function [parent=#BoundingBox] new
-- @param self Self reference
-- @param Polyhedron#Polyhedron poly poly
-- @return BoundingBox#BoundingBox

---
-- Function BoundingBox()
--
-- @function [parent=#BoundingBox] BoundingBox
-- @param self Self reference
-- @param Sphere#Sphere sphere sphere

---
-- Function new()
--
-- @function [parent=#BoundingBox] new
-- @param self Self reference
-- @param Sphere#Sphere sphere sphere
-- @return BoundingBox#BoundingBox

---
-- Function delete()
--
-- @function [parent=#BoundingBox] delete
-- @param self Self reference

---
-- Function operator==()
--
-- @function [parent=#BoundingBox] operator==
-- @param self Self reference
-- @param BoundingBox#BoundingBox rhs rhs
-- @return #boolean

---
-- Function Define()
--
-- @function [parent=#BoundingBox] Define
-- @param self Self reference
-- @param BoundingBox#BoundingBox box box

---
-- Function Define()
--
-- @function [parent=#BoundingBox] Define
-- @param self Self reference
-- @param Rect#Rect rect rect

---
-- Function Define()
--
-- @function [parent=#BoundingBox] Define
-- @param self Self reference
-- @param Vector3#Vector3 min min
-- @param Vector3#Vector3 max max

---
-- Function Define()
--
-- @function [parent=#BoundingBox] Define
-- @param self Self reference
-- @param #number min min
-- @param #number max max

---
-- Function Define()
--
-- @function [parent=#BoundingBox] Define
-- @param self Self reference
-- @param Vector3#Vector3 point point

---
-- Function Define()
--
-- @function [parent=#BoundingBox] Define
-- @param self Self reference
-- @param Frustum#Frustum frustum frustum

---
-- Function Define()
--
-- @function [parent=#BoundingBox] Define
-- @param self Self reference
-- @param Polyhedron#Polyhedron poly poly

---
-- Function Define()
--
-- @function [parent=#BoundingBox] Define
-- @param self Self reference
-- @param Sphere#Sphere sphere sphere

---
-- Function Merge()
--
-- @function [parent=#BoundingBox] Merge
-- @param self Self reference
-- @param Vector3#Vector3 point point

---
-- Function Merge()
--
-- @function [parent=#BoundingBox] Merge
-- @param self Self reference
-- @param BoundingBox#BoundingBox box box

---
-- Function Merge()
--
-- @function [parent=#BoundingBox] Merge
-- @param self Self reference
-- @param Frustum#Frustum frustum frustum

---
-- Function Merge()
--
-- @function [parent=#BoundingBox] Merge
-- @param self Self reference
-- @param Polyhedron#Polyhedron poly poly

---
-- Function Merge()
--
-- @function [parent=#BoundingBox] Merge
-- @param self Self reference
-- @param Sphere#Sphere sphere sphere

---
-- Function Clip()
--
-- @function [parent=#BoundingBox] Clip
-- @param self Self reference
-- @param BoundingBox#BoundingBox box box

---
-- Function Transform()
--
-- @function [parent=#BoundingBox] Transform
-- @param self Self reference
-- @param Matrix3#Matrix3 transform transform

---
-- Function Transform()
--
-- @function [parent=#BoundingBox] Transform
-- @param self Self reference
-- @param Matrix3x4#Matrix3x4 transform transform

---
-- Function Clear()
--
-- @function [parent=#BoundingBox] Clear
-- @param self Self reference

---
-- Function Center()
--
-- @function [parent=#BoundingBox] Center
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function Size()
--
-- @function [parent=#BoundingBox] Size
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function HalfSize()
--
-- @function [parent=#BoundingBox] HalfSize
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function Transformed()
--
-- @function [parent=#BoundingBox] Transformed
-- @param self Self reference
-- @param Matrix3#Matrix3 transform transform
-- @return BoundingBox#BoundingBox

---
-- Function Transformed()
--
-- @function [parent=#BoundingBox] Transformed
-- @param self Self reference
-- @param Matrix3x4#Matrix3x4 transform transform
-- @return BoundingBox#BoundingBox

---
-- Function Projected()
--
-- @function [parent=#BoundingBox] Projected
-- @param self Self reference
-- @param Matrix4#Matrix4 projection projection
-- @return Rect#Rect

---
-- Function IsInside()
--
-- @function [parent=#BoundingBox] IsInside
-- @param self Self reference
-- @param Vector3#Vector3 point point
-- @return Intersection#Intersection

---
-- Function IsInside()
--
-- @function [parent=#BoundingBox] IsInside
-- @param self Self reference
-- @param BoundingBox#BoundingBox box box
-- @return Intersection#Intersection

---
-- Function IsInsideFast()
--
-- @function [parent=#BoundingBox] IsInsideFast
-- @param self Self reference
-- @param BoundingBox#BoundingBox box box
-- @return Intersection#Intersection

---
-- Function IsInside()
--
-- @function [parent=#BoundingBox] IsInside
-- @param self Self reference
-- @param Sphere#Sphere sphere sphere
-- @return Intersection#Intersection

---
-- Function IsInsideFast()
--
-- @function [parent=#BoundingBox] IsInsideFast
-- @param self Self reference
-- @param Sphere#Sphere sphere sphere
-- @return Intersection#Intersection

---
-- Function ToString()
--
-- @function [parent=#BoundingBox] ToString
-- @param self Self reference
-- @return #string

---
-- Field min
--
-- @field [parent=#BoundingBox] Vector3#Vector3 min

---
-- Field max
--
-- @field [parent=#BoundingBox] Vector3#Vector3 max

---
-- Field defined
--
-- @field [parent=#BoundingBox] #boolean defined

---
-- Field center (Read only)
--
-- @field [parent=#BoundingBox] Vector3#Vector3 center

---
-- Field size (Read only)
--
-- @field [parent=#BoundingBox] Vector3#Vector3 size

---
-- Field halfSize (Read only)
--
-- @field [parent=#BoundingBox] Vector3#Vector3 halfSize


return nil
