---
-- Module BoundingBox
--
-- @module BoundingBox

---
-- Function BoundingBox
--
-- @function [parent=#BoundingBox] BoundingBox

---
-- Function new
--
-- @function [parent=#BoundingBox] new
-- @return BoundingBox#BoundingBox

---
-- Function BoundingBox
--
-- @function [parent=#BoundingBox] BoundingBox
-- @param BoundingBox#BoundingBox boxbox

---
-- Function new
--
-- @function [parent=#BoundingBox] new
-- @param BoundingBox#BoundingBox boxbox
-- @return BoundingBox#BoundingBox

---
-- Function BoundingBox
--
-- @function [parent=#BoundingBox] BoundingBox
-- @param Rect#Rect rectrect

---
-- Function new
--
-- @function [parent=#BoundingBox] new
-- @param Rect#Rect rectrect
-- @return BoundingBox#BoundingBox

---
-- Function BoundingBox
--
-- @function [parent=#BoundingBox] BoundingBox
-- @param Vector3#Vector3 minmin
-- @param Vector3#Vector3 maxmax

---
-- Function new
--
-- @function [parent=#BoundingBox] new
-- @param Vector3#Vector3 minmin
-- @param Vector3#Vector3 maxmax
-- @return BoundingBox#BoundingBox

---
-- Function BoundingBox
--
-- @function [parent=#BoundingBox] BoundingBox
-- @param #number minmin
-- @param #number maxmax

---
-- Function new
--
-- @function [parent=#BoundingBox] new
-- @param #number minmin
-- @param #number maxmax
-- @return BoundingBox#BoundingBox

---
-- Function BoundingBox
--
-- @function [parent=#BoundingBox] BoundingBox
-- @param Frustum#Frustum frustumfrustum

---
-- Function new
--
-- @function [parent=#BoundingBox] new
-- @param Frustum#Frustum frustumfrustum
-- @return BoundingBox#BoundingBox

---
-- Function BoundingBox
--
-- @function [parent=#BoundingBox] BoundingBox
-- @param Polyhedron#Polyhedron polypoly

---
-- Function new
--
-- @function [parent=#BoundingBox] new
-- @param Polyhedron#Polyhedron polypoly
-- @return BoundingBox#BoundingBox

---
-- Function BoundingBox
--
-- @function [parent=#BoundingBox] BoundingBox
-- @param Sphere#Sphere spheresphere

---
-- Function new
--
-- @function [parent=#BoundingBox] new
-- @param Sphere#Sphere spheresphere
-- @return BoundingBox#BoundingBox

---
-- Function delete
--
-- @function [parent=#BoundingBox] delete

---
-- Function operator==
--
-- @function [parent=#BoundingBox] operator==
-- @param BoundingBox#BoundingBox rhsrhs
-- @return #boolean

---
-- Function Define
--
-- @function [parent=#BoundingBox] Define
-- @param BoundingBox#BoundingBox boxbox

---
-- Function Define
--
-- @function [parent=#BoundingBox] Define
-- @param Rect#Rect rectrect

---
-- Function Define
--
-- @function [parent=#BoundingBox] Define
-- @param Vector3#Vector3 minmin
-- @param Vector3#Vector3 maxmax

---
-- Function Define
--
-- @function [parent=#BoundingBox] Define
-- @param #number minmin
-- @param #number maxmax

---
-- Function Define
--
-- @function [parent=#BoundingBox] Define
-- @param Vector3#Vector3 pointpoint

---
-- Function Define
--
-- @function [parent=#BoundingBox] Define
-- @param Frustum#Frustum frustumfrustum

---
-- Function Define
--
-- @function [parent=#BoundingBox] Define
-- @param Polyhedron#Polyhedron polypoly

---
-- Function Define
--
-- @function [parent=#BoundingBox] Define
-- @param Sphere#Sphere spheresphere

---
-- Function Merge
--
-- @function [parent=#BoundingBox] Merge
-- @param Vector3#Vector3 pointpoint

---
-- Function Merge
--
-- @function [parent=#BoundingBox] Merge
-- @param BoundingBox#BoundingBox boxbox

---
-- Function Merge
--
-- @function [parent=#BoundingBox] Merge
-- @param Frustum#Frustum frustumfrustum

---
-- Function Merge
--
-- @function [parent=#BoundingBox] Merge
-- @param Polyhedron#Polyhedron polypoly

---
-- Function Merge
--
-- @function [parent=#BoundingBox] Merge
-- @param Sphere#Sphere spheresphere

---
-- Function Clip
--
-- @function [parent=#BoundingBox] Clip
-- @param BoundingBox#BoundingBox boxbox

---
-- Function Transform
--
-- @function [parent=#BoundingBox] Transform
-- @param Matrix3#Matrix3 transformtransform

---
-- Function Transform
--
-- @function [parent=#BoundingBox] Transform
-- @param Matrix3x4#Matrix3x4 transformtransform

---
-- Function Clear
--
-- @function [parent=#BoundingBox] Clear

---
-- Function Center
--
-- @function [parent=#BoundingBox] Center
-- @return Vector3#Vector3

---
-- Function Size
--
-- @function [parent=#BoundingBox] Size
-- @return Vector3#Vector3

---
-- Function HalfSize
--
-- @function [parent=#BoundingBox] HalfSize
-- @return Vector3#Vector3

---
-- Function Transformed
--
-- @function [parent=#BoundingBox] Transformed
-- @param Matrix3#Matrix3 transformtransform
-- @return BoundingBox#BoundingBox

---
-- Function Transformed
--
-- @function [parent=#BoundingBox] Transformed
-- @param Matrix3x4#Matrix3x4 transformtransform
-- @return BoundingBox#BoundingBox

---
-- Function Projected
--
-- @function [parent=#BoundingBox] Projected
-- @param Matrix4#Matrix4 projectionprojection
-- @return Rect#Rect

---
-- Function IsInside
--
-- @function [parent=#BoundingBox] IsInside
-- @param Vector3#Vector3 pointpoint
-- @return Intersection#Intersection

---
-- Function IsInside
--
-- @function [parent=#BoundingBox] IsInside
-- @param BoundingBox#BoundingBox boxbox
-- @return Intersection#Intersection

---
-- Function IsInsideFast
--
-- @function [parent=#BoundingBox] IsInsideFast
-- @param BoundingBox#BoundingBox boxbox
-- @return Intersection#Intersection

---
-- Function IsInside
--
-- @function [parent=#BoundingBox] IsInside
-- @param Sphere#Sphere spheresphere
-- @return Intersection#Intersection

---
-- Function IsInsideFast
--
-- @function [parent=#BoundingBox] IsInsideFast
-- @param Sphere#Sphere spheresphere
-- @return Intersection#Intersection

---
-- Function ToString
--
-- @function [parent=#BoundingBox] ToString
-- @return #string

---
-- Field min
--
-- @field [parent=#BoundingBox] Vector3#Vector3 min

---
-- Field max
--
-- @field [parent=#BoundingBox] Vector3#Vector3 max

---
-- Field defined
--
-- @field [parent=#BoundingBox] #boolean defined

---
-- Field center (Read only)
--
-- @field [parent=#BoundingBox] Vector3#Vector3 center

---
-- Field size (Read only)
--
-- @field [parent=#BoundingBox] Vector3#Vector3 size

---
-- Field halfSize (Read only)
--
-- @field [parent=#BoundingBox] Vector3#Vector3 halfSize


return nil
