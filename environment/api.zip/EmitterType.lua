---
-- Enumeration EmitterType
--
-- @module EmitterType

---
-- Enumeration value EMITTER_SPHERE
--
-- @field [parent=#EmitterType] #number EMITTER_SPHERE

---
-- Enumeration value EMITTER_BOX
--
-- @field [parent=#EmitterType] #number EMITTER_BOX


return nil
