---
-- Module Sprite
-- Module Sprite extends UIElement
-- Generated on 2014-03-13
--
-- @module Sprite

---
-- Function Sprite
--
-- @function [parent=#Sprite] Sprite
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#Sprite] new
-- @param self Self reference
-- @return Sprite#Sprite

---
-- Function delete
--
-- @function [parent=#Sprite] delete
-- @param self Self reference

---
-- Function SetPosition
--
-- @function [parent=#Sprite] SetPosition
-- @param self Self reference
-- @param Vector2#Vector2 position position

---
-- Function SetPosition
--
-- @function [parent=#Sprite] SetPosition
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function SetHotSpot
--
-- @function [parent=#Sprite] SetHotSpot
-- @param self Self reference
-- @param IntVector2#IntVector2 hotSpot hotSpot

---
-- Function SetHotSpot
--
-- @function [parent=#Sprite] SetHotSpot
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function SetScale
--
-- @function [parent=#Sprite] SetScale
-- @param self Self reference
-- @param Vector2#Vector2 scale scale

---
-- Function SetScale
--
-- @function [parent=#Sprite] SetScale
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function SetScale
--
-- @function [parent=#Sprite] SetScale
-- @param self Self reference
-- @param #number scale scale

---
-- Function SetRotation
--
-- @function [parent=#Sprite] SetRotation
-- @param self Self reference
-- @param #number angle angle

---
-- Function SetTexture
--
-- @function [parent=#Sprite] SetTexture
-- @param self Self reference
-- @param Texture#Texture texture texture

---
-- Function SetImageRect
--
-- @function [parent=#Sprite] SetImageRect
-- @param self Self reference
-- @param IntRect#IntRect rect rect

---
-- Function SetFullImageRect
--
-- @function [parent=#Sprite] SetFullImageRect
-- @param self Self reference

---
-- Function SetBlendMode
--
-- @function [parent=#Sprite] SetBlendMode
-- @param self Self reference
-- @param BlendMode#BlendMode mode mode

---
-- Function GetPosition
--
-- @function [parent=#Sprite] GetPosition
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Function GetHotSpot
--
-- @function [parent=#Sprite] GetHotSpot
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetScale
--
-- @function [parent=#Sprite] GetScale
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Function GetRotation
--
-- @function [parent=#Sprite] GetRotation
-- @param self Self reference
-- @return #number

---
-- Function GetTexture
--
-- @function [parent=#Sprite] GetTexture
-- @param self Self reference
-- @return Texture#Texture

---
-- Function GetImageRect
--
-- @function [parent=#Sprite] GetImageRect
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetBlendMode
--
-- @function [parent=#Sprite] GetBlendMode
-- @param self Self reference
-- @return BlendMode#BlendMode

---
-- Function GetTransform
--
-- @function [parent=#Sprite] GetTransform
-- @param self Self reference
-- @return const Matrix3x4#const Matrix3x4

---
-- Field position
--
-- @field [parent=#Sprite] Vector2#Vector2 position

---
-- Field hotSpot
--
-- @field [parent=#Sprite] IntVector2#IntVector2 hotSpot

---
-- Field scale
--
-- @field [parent=#Sprite] Vector2#Vector2 scale

---
-- Field rotation
--
-- @field [parent=#Sprite] #number rotation

---
-- Field texture
--
-- @field [parent=#Sprite] Texture#Texture texture

---
-- Field imageRect
--
-- @field [parent=#Sprite] IntRect#IntRect imageRect

---
-- Field blendMode
--
-- @field [parent=#Sprite] BlendMode#BlendMode blendMode

---
-- Field transform (Read only)
--
-- @field [parent=#Sprite] Matrix3x4#Matrix3x4 transform

---
-- Function UIElement
--
-- @function [parent=#Sprite] UIElement
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#Sprite] new
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function delete
--
-- @function [parent=#Sprite] delete
-- @param self Self reference

---
-- Function GetScreenPosition
--
-- @function [parent=#Sprite] GetScreenPosition
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function LoadXML
--
-- @function [parent=#Sprite] LoadXML
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#Sprite] SaveXML
-- @param self Self reference
-- @param Serializer#Serializer dest dest
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#Sprite] LoadXML
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#Sprite] SaveXML
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function FilterAttributes
--
-- @function [parent=#Sprite] FilterAttributes
-- @param self Self reference
-- @param XMLElement#XMLElement dest dest
-- @return #boolean

---
-- Function SetName
--
-- @function [parent=#Sprite] SetName
-- @param self Self reference
-- @param #string name name

---
-- Function SetPosition
--
-- @function [parent=#Sprite] SetPosition
-- @param self Self reference
-- @param IntVector2#IntVector2 position position

---
-- Function SetPosition
--
-- @function [parent=#Sprite] SetPosition
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function SetSize
--
-- @function [parent=#Sprite] SetSize
-- @param self Self reference
-- @param IntVector2#IntVector2 size size

---
-- Function SetSize
--
-- @function [parent=#Sprite] SetSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetWidth
--
-- @function [parent=#Sprite] SetWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetHeight
--
-- @function [parent=#Sprite] SetHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetMinSize
--
-- @function [parent=#Sprite] SetMinSize
-- @param self Self reference
-- @param IntVector2#IntVector2 minSize minSize

---
-- Function SetMinSize
--
-- @function [parent=#Sprite] SetMinSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetMinWidth
--
-- @function [parent=#Sprite] SetMinWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetMinHeight
--
-- @function [parent=#Sprite] SetMinHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetMaxSize
--
-- @function [parent=#Sprite] SetMaxSize
-- @param self Self reference
-- @param IntVector2#IntVector2 maxSize maxSize

---
-- Function SetMaxSize
--
-- @function [parent=#Sprite] SetMaxSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetMaxWidth
--
-- @function [parent=#Sprite] SetMaxWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetMaxHeight
--
-- @function [parent=#Sprite] SetMaxHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetFixedSize
--
-- @function [parent=#Sprite] SetFixedSize
-- @param self Self reference
-- @param IntVector2#IntVector2 size size

---
-- Function SetFixedSize
--
-- @function [parent=#Sprite] SetFixedSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetFixedWidth
--
-- @function [parent=#Sprite] SetFixedWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetFixedHeight
--
-- @function [parent=#Sprite] SetFixedHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetAlignment
--
-- @function [parent=#Sprite] SetAlignment
-- @param self Self reference
-- @param HorizontalAlignment#HorizontalAlignment hAlign hAlign
-- @param VerticalAlignment#VerticalAlignment vAlign vAlign

---
-- Function SetHorizontalAlignment
--
-- @function [parent=#Sprite] SetHorizontalAlignment
-- @param self Self reference
-- @param HorizontalAlignment#HorizontalAlignment align align

---
-- Function SetVerticalAlignment
--
-- @function [parent=#Sprite] SetVerticalAlignment
-- @param self Self reference
-- @param VerticalAlignment#VerticalAlignment align align

---
-- Function SetClipBorder
--
-- @function [parent=#Sprite] SetClipBorder
-- @param self Self reference
-- @param IntRect#IntRect rect rect

---
-- Function SetColor
--
-- @function [parent=#Sprite] SetColor
-- @param self Self reference
-- @param Color#Color color color

---
-- Function SetColor
--
-- @function [parent=#Sprite] SetColor
-- @param self Self reference
-- @param Corner#Corner corner corner
-- @param Color#Color color color

---
-- Function SetPriority
--
-- @function [parent=#Sprite] SetPriority
-- @param self Self reference
-- @param #number priority priority

---
-- Function SetOpacity
--
-- @function [parent=#Sprite] SetOpacity
-- @param self Self reference
-- @param #number opacity opacity

---
-- Function SetBringToFront
--
-- @function [parent=#Sprite] SetBringToFront
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetBringToBack
--
-- @function [parent=#Sprite] SetBringToBack
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetClipChildren
--
-- @function [parent=#Sprite] SetClipChildren
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetSortChildren
--
-- @function [parent=#Sprite] SetSortChildren
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetUseDerivedOpacity
--
-- @function [parent=#Sprite] SetUseDerivedOpacity
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetEnabled
--
-- @function [parent=#Sprite] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetEditable
--
-- @function [parent=#Sprite] SetEditable
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetFocus
--
-- @function [parent=#Sprite] SetFocus
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetSelected
--
-- @function [parent=#Sprite] SetSelected
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetVisible
--
-- @function [parent=#Sprite] SetVisible
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetFocusMode
--
-- @function [parent=#Sprite] SetFocusMode
-- @param self Self reference
-- @param FocusMode#FocusMode mode mode

---
-- Function SetDragDropMode
--
-- @function [parent=#Sprite] SetDragDropMode
-- @param self Self reference
-- @param #number mode mode

---
-- Function SetStyle
--
-- @function [parent=#Sprite] SetStyle
-- @param self Self reference
-- @param #string styleName styleName
-- @param XMLFile#XMLFile file file
-- @return #boolean

---
-- Function SetStyle
--
-- @function [parent=#Sprite] SetStyle
-- @param self Self reference
-- @param XMLElement#XMLElement element element
-- @return #boolean

---
-- Function SetStyleAuto
--
-- @function [parent=#Sprite] SetStyleAuto
-- @param self Self reference
-- @param XMLFile#XMLFile file file
-- @return #boolean

---
-- Function SetDefaultStyle
--
-- @function [parent=#Sprite] SetDefaultStyle
-- @param self Self reference
-- @param XMLFile#XMLFile style style

---
-- Function SetLayout
--
-- @function [parent=#Sprite] SetLayout
-- @param self Self reference
-- @param LayoutMode#LayoutMode mode mode
-- @param #number spacing spacing

---
-- Function SetLayout
--
-- @function [parent=#Sprite] SetLayout
-- @param self Self reference
-- @param LayoutMode#LayoutMode mode mode
-- @param #number spacing spacing
-- @param IntRect#IntRect border border

---
-- Function SetLayoutMode
--
-- @function [parent=#Sprite] SetLayoutMode
-- @param self Self reference
-- @param LayoutMode#LayoutMode mode mode

---
-- Function SetLayoutSpacing
--
-- @function [parent=#Sprite] SetLayoutSpacing
-- @param self Self reference
-- @param #number spacing spacing

---
-- Function SetLayoutBorder
--
-- @function [parent=#Sprite] SetLayoutBorder
-- @param self Self reference
-- @param IntRect#IntRect border border

---
-- Function SetIndent
--
-- @function [parent=#Sprite] SetIndent
-- @param self Self reference
-- @param #number indent indent

---
-- Function SetIndentSpacing
--
-- @function [parent=#Sprite] SetIndentSpacing
-- @param self Self reference
-- @param #number indentSpacing indentSpacing

---
-- Function UpdateLayout
--
-- @function [parent=#Sprite] UpdateLayout
-- @param self Self reference

---
-- Function DisableLayoutUpdate
--
-- @function [parent=#Sprite] DisableLayoutUpdate
-- @param self Self reference

---
-- Function EnableLayoutUpdate
--
-- @function [parent=#Sprite] EnableLayoutUpdate
-- @param self Self reference

---
-- Function BringToFront
--
-- @function [parent=#Sprite] BringToFront
-- @param self Self reference

---
-- Function CreateChild
--
-- @function [parent=#Sprite] CreateChild
-- @param self Self reference
-- @param #string type type
-- @param #string name name
-- @param #number index index
-- @return UIElement#UIElement

---
-- Function AddChild
--
-- @function [parent=#Sprite] AddChild
-- @param self Self reference
-- @param UIElement#UIElement element element

---
-- Function InsertChild
--
-- @function [parent=#Sprite] InsertChild
-- @param self Self reference
-- @param #number index index
-- @param UIElement#UIElement element element

---
-- Function RemoveChild
--
-- @function [parent=#Sprite] RemoveChild
-- @param self Self reference
-- @param UIElement#UIElement element element
-- @param #number index index

---
-- Function RemoveChildAtIndex
--
-- @function [parent=#Sprite] RemoveChildAtIndex
-- @param self Self reference
-- @param #number index index

---
-- Function RemoveAllChildren
--
-- @function [parent=#Sprite] RemoveAllChildren
-- @param self Self reference

---
-- Function Remove
--
-- @function [parent=#Sprite] Remove
-- @param self Self reference

---
-- Function FindChild
--
-- @function [parent=#Sprite] FindChild
-- @param self Self reference
-- @param UIElement#UIElement element element
-- @return #number

---
-- Function SetParent
--
-- @function [parent=#Sprite] SetParent
-- @param self Self reference
-- @param UIElement#UIElement parent parent
-- @param #number index index

---
-- Function SetVar
--
-- @function [parent=#Sprite] SetVar
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash key key
-- @param Variant#Variant value value

---
-- Function SetInternal
--
-- @function [parent=#Sprite] SetInternal
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetTraversalMode
--
-- @function [parent=#Sprite] SetTraversalMode
-- @param self Self reference
-- @param TraversalMode#TraversalMode traversalMode traversalMode

---
-- Function SetElementEventSender
--
-- @function [parent=#Sprite] SetElementEventSender
-- @param self Self reference
-- @param #boolean flag flag

---
-- Function GetName
--
-- @function [parent=#Sprite] GetName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetPosition
--
-- @function [parent=#Sprite] GetPosition
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetSize
--
-- @function [parent=#Sprite] GetSize
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetWidth
--
-- @function [parent=#Sprite] GetWidth
-- @param self Self reference
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#Sprite] GetHeight
-- @param self Self reference
-- @return #number

---
-- Function GetMinSize
--
-- @function [parent=#Sprite] GetMinSize
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetMinWidth
--
-- @function [parent=#Sprite] GetMinWidth
-- @param self Self reference
-- @return #number

---
-- Function GetMinHeight
--
-- @function [parent=#Sprite] GetMinHeight
-- @param self Self reference
-- @return #number

---
-- Function GetMaxSize
--
-- @function [parent=#Sprite] GetMaxSize
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetMaxWidth
--
-- @function [parent=#Sprite] GetMaxWidth
-- @param self Self reference
-- @return #number

---
-- Function GetMaxHeight
--
-- @function [parent=#Sprite] GetMaxHeight
-- @param self Self reference
-- @return #number

---
-- Function IsFixedSize
--
-- @function [parent=#Sprite] IsFixedSize
-- @param self Self reference
-- @return #boolean

---
-- Function IsFixedWidth
--
-- @function [parent=#Sprite] IsFixedWidth
-- @param self Self reference
-- @return #boolean

---
-- Function IsFixedHeight
--
-- @function [parent=#Sprite] IsFixedHeight
-- @param self Self reference
-- @return #boolean

---
-- Function GetChildOffset
--
-- @function [parent=#Sprite] GetChildOffset
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetHorizontalAlignment
--
-- @function [parent=#Sprite] GetHorizontalAlignment
-- @param self Self reference
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetVerticalAlignment
--
-- @function [parent=#Sprite] GetVerticalAlignment
-- @param self Self reference
-- @return VerticalAlignment#VerticalAlignment

---
-- Function GetClipBorder
--
-- @function [parent=#Sprite] GetClipBorder
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetColor
--
-- @function [parent=#Sprite] GetColor
-- @param self Self reference
-- @param Corner#Corner corner corner
-- @return const Color#const Color

---
-- Function GetPriority
--
-- @function [parent=#Sprite] GetPriority
-- @param self Self reference
-- @return #number

---
-- Function GetOpacity
--
-- @function [parent=#Sprite] GetOpacity
-- @param self Self reference
-- @return #number

---
-- Function GetDerivedOpacity
--
-- @function [parent=#Sprite] GetDerivedOpacity
-- @param self Self reference
-- @return #number

---
-- Function GetBringToFront
--
-- @function [parent=#Sprite] GetBringToFront
-- @param self Self reference
-- @return #boolean

---
-- Function GetBringToBack
--
-- @function [parent=#Sprite] GetBringToBack
-- @param self Self reference
-- @return #boolean

---
-- Function GetClipChildren
--
-- @function [parent=#Sprite] GetClipChildren
-- @param self Self reference
-- @return #boolean

---
-- Function GetSortChildren
--
-- @function [parent=#Sprite] GetSortChildren
-- @param self Self reference
-- @return #boolean

---
-- Function GetUseDerivedOpacity
--
-- @function [parent=#Sprite] GetUseDerivedOpacity
-- @param self Self reference
-- @return #boolean

---
-- Function HasFocus
--
-- @function [parent=#Sprite] HasFocus
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabled
--
-- @function [parent=#Sprite] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEditable
--
-- @function [parent=#Sprite] IsEditable
-- @param self Self reference
-- @return #boolean

---
-- Function IsSelected
--
-- @function [parent=#Sprite] IsSelected
-- @param self Self reference
-- @return #boolean

---
-- Function IsVisible
--
-- @function [parent=#Sprite] IsVisible
-- @param self Self reference
-- @return #boolean

---
-- Function IsHovering
--
-- @function [parent=#Sprite] IsHovering
-- @param self Self reference
-- @return #boolean

---
-- Function IsInternal
--
-- @function [parent=#Sprite] IsInternal
-- @param self Self reference
-- @return #boolean

---
-- Function HasColorGradient
--
-- @function [parent=#Sprite] HasColorGradient
-- @param self Self reference
-- @return #boolean

---
-- Function GetFocusMode
--
-- @function [parent=#Sprite] GetFocusMode
-- @param self Self reference
-- @return FocusMode#FocusMode

---
-- Function GetDragDropMode
--
-- @function [parent=#Sprite] GetDragDropMode
-- @param self Self reference
-- @return #number

---
-- Function GetAppliedStyle
--
-- @function [parent=#Sprite] GetAppliedStyle
-- @param self Self reference
-- @return const String#const String

---
-- Function GetDefaultStyle
--
-- @function [parent=#Sprite] GetDefaultStyle
-- @param self Self reference
-- @param #boolean recursiveUp recursiveUp
-- @return XMLFile#XMLFile

---
-- Function GetLayoutMode
--
-- @function [parent=#Sprite] GetLayoutMode
-- @param self Self reference
-- @return LayoutMode#LayoutMode

---
-- Function GetLayoutSpacing
--
-- @function [parent=#Sprite] GetLayoutSpacing
-- @param self Self reference
-- @return #number

---
-- Function GetLayoutBorder
--
-- @function [parent=#Sprite] GetLayoutBorder
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetNumChildren
--
-- @function [parent=#Sprite] GetNumChildren
-- @param self Self reference
-- @param #boolean recursive recursive
-- @return #number

---
-- Function GetChild
--
-- @function [parent=#Sprite] GetChild
-- @param self Self reference
-- @param #string name name
-- @param #boolean recursive recursive
-- @return UIElement#UIElement

---
-- Function GetChild
--
-- @function [parent=#Sprite] GetChild
-- @param self Self reference
-- @param #number index index
-- @return UIElement#UIElement

---
-- Function GetParent
--
-- @function [parent=#Sprite] GetParent
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetRoot
--
-- @function [parent=#Sprite] GetRoot
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetDerivedColor
--
-- @function [parent=#Sprite] GetDerivedColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetVar
--
-- @function [parent=#Sprite] GetVar
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash key key
-- @return const Variant#const Variant

---
-- Function GetVars
--
-- @function [parent=#Sprite] GetVars
-- @param self Self reference
-- @return const VariantMap#const VariantMap

---
-- Function ScreenToElement
--
-- @function [parent=#Sprite] ScreenToElement
-- @param self Self reference
-- @param IntVector2#IntVector2 screenPosition screenPosition
-- @return IntVector2#IntVector2

---
-- Function ElementToScreen
--
-- @function [parent=#Sprite] ElementToScreen
-- @param self Self reference
-- @param IntVector2#IntVector2 position position
-- @return IntVector2#IntVector2

---
-- Function IsInside
--
-- @function [parent=#Sprite] IsInside
-- @param self Self reference
-- @param IntVector2#IntVector2 position position
-- @param #boolean isScreen isScreen
-- @return #boolean

---
-- Function IsInsideCombined
--
-- @function [parent=#Sprite] IsInsideCombined
-- @param self Self reference
-- @param IntVector2#IntVector2 position position
-- @param #boolean isScreen isScreen
-- @return #boolean

---
-- Function GetCombinedScreenRect
--
-- @function [parent=#Sprite] GetCombinedScreenRect
-- @param self Self reference
-- @return IntRect#IntRect

---
-- Function SortChildren
--
-- @function [parent=#Sprite] SortChildren
-- @param self Self reference

---
-- Function GetLayoutMinSize
--
-- @function [parent=#Sprite] GetLayoutMinSize
-- @param self Self reference
-- @return #number

---
-- Function GetIndent
--
-- @function [parent=#Sprite] GetIndent
-- @param self Self reference
-- @return #number

---
-- Function GetIndentSpacing
--
-- @function [parent=#Sprite] GetIndentSpacing
-- @param self Self reference
-- @return #number

---
-- Function GetIndentWidth
--
-- @function [parent=#Sprite] GetIndentWidth
-- @param self Self reference
-- @return #number

---
-- Function SetChildOffset
--
-- @function [parent=#Sprite] SetChildOffset
-- @param self Self reference
-- @param IntVector2#IntVector2 offset offset

---
-- Function SetHovering
--
-- @function [parent=#Sprite] SetHovering
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function GetColor
--
-- @function [parent=#Sprite] GetColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetTraversalMode
--
-- @function [parent=#Sprite] GetTraversalMode
-- @param self Self reference
-- @return TraversalMode#TraversalMode

---
-- Function IsElementEventSender
--
-- @function [parent=#Sprite] IsElementEventSender
-- @param self Self reference
-- @return #boolean

---
-- Function GetElementEventSender
--
-- @function [parent=#Sprite] GetElementEventSender
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Field screenPosition (Read only)
--
-- @field [parent=#Sprite] IntVector2#IntVector2 screenPosition

---
-- Field name
--
-- @field [parent=#Sprite] #string name

---
-- Field position
--
-- @field [parent=#Sprite] IntVector2#IntVector2 position

---
-- Field size
--
-- @field [parent=#Sprite] IntVector2#IntVector2 size

---
-- Field width
--
-- @field [parent=#Sprite] #number width

---
-- Field height
--
-- @field [parent=#Sprite] #number height

---
-- Field minSize
--
-- @field [parent=#Sprite] IntVector2#IntVector2 minSize

---
-- Field minWidth
--
-- @field [parent=#Sprite] #number minWidth

---
-- Field minHeight
--
-- @field [parent=#Sprite] #number minHeight

---
-- Field maxSize
--
-- @field [parent=#Sprite] IntVector2#IntVector2 maxSize

---
-- Field maxWidth
--
-- @field [parent=#Sprite] #number maxWidth

---
-- Field maxHeight
--
-- @field [parent=#Sprite] #number maxHeight

---
-- Field fixedSize (Read only)
--
-- @field [parent=#Sprite] #boolean fixedSize

---
-- Field fixedWidth (Read only)
--
-- @field [parent=#Sprite] #boolean fixedWidth

---
-- Field fixedHeight (Read only)
--
-- @field [parent=#Sprite] #boolean fixedHeight

---
-- Field childOffset
--
-- @field [parent=#Sprite] IntVector2#IntVector2 childOffset

---
-- Field horizontalAlignment
--
-- @field [parent=#Sprite] HorizontalAlignment#HorizontalAlignment horizontalAlignment

---
-- Field verticalAlignment
--
-- @field [parent=#Sprite] VerticalAlignment#VerticalAlignment verticalAlignment

---
-- Field clipBorder
--
-- @field [parent=#Sprite] IntRect#IntRect clipBorder

---
-- Field color
--
-- @field [parent=#Sprite] Color#Color color

---
-- Field priority
--
-- @field [parent=#Sprite] #number priority

---
-- Field opacity
--
-- @field [parent=#Sprite] #number opacity

---
-- Field derivedOpacity (Read only)
--
-- @field [parent=#Sprite] #number derivedOpacity

---
-- Field bringToFront
--
-- @field [parent=#Sprite] #boolean bringToFront

---
-- Field bringToBack
--
-- @field [parent=#Sprite] #boolean bringToBack

---
-- Field clipChildren
--
-- @field [parent=#Sprite] #boolean clipChildren

---
-- Field sortChildren
--
-- @field [parent=#Sprite] #boolean sortChildren

---
-- Field useDerivedOpacity
--
-- @field [parent=#Sprite] #boolean useDerivedOpacity

---
-- Field focus
--
-- @field [parent=#Sprite] #boolean focus

---
-- Field enabled
--
-- @field [parent=#Sprite] #boolean enabled

---
-- Field editable
--
-- @field [parent=#Sprite] #boolean editable

---
-- Field selected
--
-- @field [parent=#Sprite] #boolean selected

---
-- Field visible
--
-- @field [parent=#Sprite] #boolean visible

---
-- Field hovering
--
-- @field [parent=#Sprite] #boolean hovering

---
-- Field internal
--
-- @field [parent=#Sprite] #boolean internal

---
-- Field colorGradient (Read only)
--
-- @field [parent=#Sprite] #boolean colorGradient

---
-- Field focusMode
--
-- @field [parent=#Sprite] FocusMode#FocusMode focusMode

---
-- Field dragDropMode
--
-- @field [parent=#Sprite] #number dragDropMode

---
-- Field style
--
-- @field [parent=#Sprite] #string style

---
-- Field defaultStyle
--
-- @field [parent=#Sprite] XMLFile#XMLFile defaultStyle

---
-- Field layoutMode
--
-- @field [parent=#Sprite] LayoutMode#LayoutMode layoutMode

---
-- Field layoutSpacing
--
-- @field [parent=#Sprite] #number layoutSpacing

---
-- Field layoutBorder
--
-- @field [parent=#Sprite] IntRect#IntRect layoutBorder

---
-- Field numChildren (Read only)
--
-- @field [parent=#Sprite] #number numChildren

---
-- Field parent
--
-- @field [parent=#Sprite] UIElement#UIElement parent

---
-- Field root (Read only)
--
-- @field [parent=#Sprite] UIElement#UIElement root

---
-- Field derivedColor (Read only)
--
-- @field [parent=#Sprite] Color#Color derivedColor

---
-- Field combinedScreenRect (Read only)
--
-- @field [parent=#Sprite] IntRect#IntRect combinedScreenRect

---
-- Field layoutMinSize (Read only)
--
-- @field [parent=#Sprite] #number layoutMinSize

---
-- Field indent
--
-- @field [parent=#Sprite] #number indent

---
-- Field indentSpacing
--
-- @field [parent=#Sprite] #number indentSpacing

---
-- Field indentWidth (Read only)
--
-- @field [parent=#Sprite] #number indentWidth

---
-- Field traversalMode
--
-- @field [parent=#Sprite] TraversalMode#TraversalMode traversalMode

---
-- Field elementEventSender
--
-- @field [parent=#Sprite] #boolean elementEventSender

---
-- Function SetTemporary
--
-- @function [parent=#Sprite] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#Sprite] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Sprite] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Sprite] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Sprite] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Sprite] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Sprite] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Sprite] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#Sprite] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Sprite] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Sprite] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Sprite] #string category


return nil
