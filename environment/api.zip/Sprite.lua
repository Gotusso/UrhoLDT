---
-- Module Sprite
-- Module Sprite extends UIElement
-- Generated on 2014-05-31
--
-- @module Sprite

---
-- Function Sprite()
--
-- @function [parent=#Sprite] Sprite
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#Sprite] new
-- @param self Self reference
-- @return Sprite#Sprite

---
-- Function delete()
--
-- @function [parent=#Sprite] delete
-- @param self Self reference

---
-- Function SetPosition()
-- Set floating point position.
--
-- @function [parent=#Sprite] SetPosition
-- @param self Self reference
-- @param Vector2#Vector2 position position

---
-- Function SetPosition()
-- Set floating point position.
--
-- @function [parent=#Sprite] SetPosition
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function SetHotSpot()
-- Set hotspot for positioning and rotation.
--
-- @function [parent=#Sprite] SetHotSpot
-- @param self Self reference
-- @param IntVector2#IntVector2 hotSpot hotSpot

---
-- Function SetHotSpot()
-- Set hotspot for positioning and rotation.
--
-- @function [parent=#Sprite] SetHotSpot
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function SetScale()
-- Set scale. Scale also affects child sprites.
--
-- @function [parent=#Sprite] SetScale
-- @param self Self reference
-- @param Vector2#Vector2 scale scale

---
-- Function SetScale()
-- Set scale. Scale also affects child sprites.
-- Set uniform scale. Scale also affects child sprites.
--
-- @function [parent=#Sprite] SetScale
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function SetScale()
--
-- @function [parent=#Sprite] SetScale
-- @param self Self reference
-- @param #number scale scale

---
-- Function SetRotation()
-- Set rotation angle.
--
-- @function [parent=#Sprite] SetRotation
-- @param self Self reference
-- @param #number angle angle

---
-- Function SetTexture()
-- Set texture.
--
-- @function [parent=#Sprite] SetTexture
-- @param self Self reference
-- @param Texture#Texture texture texture

---
-- Function SetImageRect()
-- Set part of texture to use as the image.
--
-- @function [parent=#Sprite] SetImageRect
-- @param self Self reference
-- @param IntRect#IntRect rect rect

---
-- Function SetFullImageRect()
-- Use whole texture as the image.
--
-- @function [parent=#Sprite] SetFullImageRect
-- @param self Self reference

---
-- Function SetBlendMode()
-- Set blend mode.
--
-- @function [parent=#Sprite] SetBlendMode
-- @param self Self reference
-- @param BlendMode#BlendMode mode mode

---
-- Function GetPosition()
-- Return floating point position.
--
-- @function [parent=#Sprite] GetPosition
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Function GetHotSpot()
-- Return hotspot.
--
-- @function [parent=#Sprite] GetHotSpot
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetScale()
-- Return scale.
--
-- @function [parent=#Sprite] GetScale
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Function GetRotation()
-- Return rotation angle.
--
-- @function [parent=#Sprite] GetRotation
-- @param self Self reference
-- @return #number

---
-- Function GetTexture()
-- Return texture.
--
-- @function [parent=#Sprite] GetTexture
-- @param self Self reference
-- @return Texture#Texture

---
-- Function GetImageRect()
-- Return image rectangle.
--
-- @function [parent=#Sprite] GetImageRect
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetBlendMode()
-- Return blend mode.
--
-- @function [parent=#Sprite] GetBlendMode
-- @param self Self reference
-- @return BlendMode#BlendMode

---
-- Function GetTransform()
-- Update and return rendering transform, also used to transform child sprites.
--
-- @function [parent=#Sprite] GetTransform
-- @param self Self reference
-- @return const Matrix3x4#const Matrix3x4

---
-- Field position
--
-- @field [parent=#Sprite] Vector2#Vector2 position

---
-- Field hotSpot
--
-- @field [parent=#Sprite] IntVector2#IntVector2 hotSpot

---
-- Field scale
--
-- @field [parent=#Sprite] Vector2#Vector2 scale

---
-- Field rotation
--
-- @field [parent=#Sprite] #number rotation

---
-- Field texture
--
-- @field [parent=#Sprite] Texture#Texture texture

---
-- Field imageRect
--
-- @field [parent=#Sprite] IntRect#IntRect imageRect

---
-- Field blendMode
--
-- @field [parent=#Sprite] BlendMode#BlendMode blendMode

---
-- Field transform (Read only)
--
-- @field [parent=#Sprite] Matrix3x4#Matrix3x4 transform


return nil
