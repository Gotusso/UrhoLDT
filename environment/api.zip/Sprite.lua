---
-- Module Sprite
-- extends UIElement
--
-- @module Sprite

---
-- Function Sprite
--
-- @function [parent=#Sprite] Sprite

---
-- Function new
--
-- @function [parent=#Sprite] new
-- @return Sprite#Sprite

---
-- Function delete
--
-- @function [parent=#Sprite] delete

---
-- Function SetPosition
--
-- @function [parent=#Sprite] SetPosition
-- @param Vector2#Vector2 positionposition

---
-- Function SetPosition
--
-- @function [parent=#Sprite] SetPosition
-- @param #number xx
-- @param #number yy

---
-- Function SetHotSpot
--
-- @function [parent=#Sprite] SetHotSpot
-- @param IntVector2#IntVector2 hotSpothotSpot

---
-- Function SetHotSpot
--
-- @function [parent=#Sprite] SetHotSpot
-- @param #number xx
-- @param #number yy

---
-- Function SetScale
--
-- @function [parent=#Sprite] SetScale
-- @param Vector2#Vector2 scalescale

---
-- Function SetScale
--
-- @function [parent=#Sprite] SetScale
-- @param #number xx
-- @param #number yy

---
-- Function SetScale
--
-- @function [parent=#Sprite] SetScale
-- @param #number scalescale

---
-- Function SetRotation
--
-- @function [parent=#Sprite] SetRotation
-- @param #number angleangle

---
-- Function SetTexture
--
-- @function [parent=#Sprite] SetTexture
-- @param Texture#Texture texturetexture

---
-- Function SetImageRect
--
-- @function [parent=#Sprite] SetImageRect
-- @param IntRect#IntRect rectrect

---
-- Function SetFullImageRect
--
-- @function [parent=#Sprite] SetFullImageRect

---
-- Function SetBlendMode
--
-- @function [parent=#Sprite] SetBlendMode
-- @param BlendMode#BlendMode modemode

---
-- Function GetPosition
--
-- @function [parent=#Sprite] GetPosition
-- @return const Vector2#const Vector2

---
-- Function GetHotSpot
--
-- @function [parent=#Sprite] GetHotSpot
-- @return const IntVector2#const IntVector2

---
-- Function GetScale
--
-- @function [parent=#Sprite] GetScale
-- @return const Vector2#const Vector2

---
-- Function GetRotation
--
-- @function [parent=#Sprite] GetRotation
-- @return #number

---
-- Function GetTexture
--
-- @function [parent=#Sprite] GetTexture
-- @return Texture#Texture

---
-- Function GetImageRect
--
-- @function [parent=#Sprite] GetImageRect
-- @return const IntRect#const IntRect

---
-- Function GetBlendMode
--
-- @function [parent=#Sprite] GetBlendMode
-- @return BlendMode#BlendMode

---
-- Function GetTransform
--
-- @function [parent=#Sprite] GetTransform
-- @return const Matrix3x4#const Matrix3x4

---
-- Field position
--
-- @field [parent=#Sprite] Vector2#Vector2 position

---
-- Field hotSpot
--
-- @field [parent=#Sprite] IntVector2#IntVector2 hotSpot

---
-- Field scale
--
-- @field [parent=#Sprite] Vector2#Vector2 scale

---
-- Field rotation
--
-- @field [parent=#Sprite] #number rotation

---
-- Field texture
--
-- @field [parent=#Sprite] Texture#Texture texture

---
-- Field imageRect
--
-- @field [parent=#Sprite] IntRect#IntRect imageRect

---
-- Field blendMode
--
-- @field [parent=#Sprite] BlendMode#BlendMode blendMode

---
-- Field transform (Read only)
--
-- @field [parent=#Sprite] Matrix3x4#Matrix3x4 transform

---
-- Function UIElement
--
-- @function [parent=#Sprite] UIElement

---
-- Function new
--
-- @function [parent=#Sprite] new
-- @return UIElement#UIElement

---
-- Function delete
--
-- @function [parent=#Sprite] delete

---
-- Function GetScreenPosition
--
-- @function [parent=#Sprite] GetScreenPosition
-- @return const IntVector2#const IntVector2

---
-- Function LoadXML
--
-- @function [parent=#Sprite] LoadXML
-- @param Deserializer#Deserializer sourcesource
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#Sprite] SaveXML
-- @param Serializer#Serializer destdest
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#Sprite] LoadXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#Sprite] SaveXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function FilterAttributes
--
-- @function [parent=#Sprite] FilterAttributes
-- @param XMLElement#XMLElement destdest
-- @return #boolean

---
-- Function SetName
--
-- @function [parent=#Sprite] SetName
-- @param #string namename

---
-- Function SetPosition
--
-- @function [parent=#Sprite] SetPosition
-- @param IntVector2#IntVector2 positionposition

---
-- Function SetPosition
--
-- @function [parent=#Sprite] SetPosition
-- @param #number xx
-- @param #number yy

---
-- Function SetSize
--
-- @function [parent=#Sprite] SetSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function SetSize
--
-- @function [parent=#Sprite] SetSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetWidth
--
-- @function [parent=#Sprite] SetWidth
-- @param #number widthwidth

---
-- Function SetHeight
--
-- @function [parent=#Sprite] SetHeight
-- @param #number heightheight

---
-- Function SetMinSize
--
-- @function [parent=#Sprite] SetMinSize
-- @param IntVector2#IntVector2 minSizeminSize

---
-- Function SetMinSize
--
-- @function [parent=#Sprite] SetMinSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetMinWidth
--
-- @function [parent=#Sprite] SetMinWidth
-- @param #number widthwidth

---
-- Function SetMinHeight
--
-- @function [parent=#Sprite] SetMinHeight
-- @param #number heightheight

---
-- Function SetMaxSize
--
-- @function [parent=#Sprite] SetMaxSize
-- @param IntVector2#IntVector2 maxSizemaxSize

---
-- Function SetMaxSize
--
-- @function [parent=#Sprite] SetMaxSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetMaxWidth
--
-- @function [parent=#Sprite] SetMaxWidth
-- @param #number widthwidth

---
-- Function SetMaxHeight
--
-- @function [parent=#Sprite] SetMaxHeight
-- @param #number heightheight

---
-- Function SetFixedSize
--
-- @function [parent=#Sprite] SetFixedSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function SetFixedSize
--
-- @function [parent=#Sprite] SetFixedSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetFixedWidth
--
-- @function [parent=#Sprite] SetFixedWidth
-- @param #number widthwidth

---
-- Function SetFixedHeight
--
-- @function [parent=#Sprite] SetFixedHeight
-- @param #number heightheight

---
-- Function SetAlignment
--
-- @function [parent=#Sprite] SetAlignment
-- @param HorizontalAlignment#HorizontalAlignment hAlignhAlign
-- @param VerticalAlignment#VerticalAlignment vAlignvAlign

---
-- Function SetHorizontalAlignment
--
-- @function [parent=#Sprite] SetHorizontalAlignment
-- @param HorizontalAlignment#HorizontalAlignment alignalign

---
-- Function SetVerticalAlignment
--
-- @function [parent=#Sprite] SetVerticalAlignment
-- @param VerticalAlignment#VerticalAlignment alignalign

---
-- Function SetClipBorder
--
-- @function [parent=#Sprite] SetClipBorder
-- @param IntRect#IntRect rectrect

---
-- Function SetColor
--
-- @function [parent=#Sprite] SetColor
-- @param Color#Color colorcolor

---
-- Function SetColor
--
-- @function [parent=#Sprite] SetColor
-- @param Corner#Corner cornercorner
-- @param Color#Color colorcolor

---
-- Function SetPriority
--
-- @function [parent=#Sprite] SetPriority
-- @param #number prioritypriority

---
-- Function SetOpacity
--
-- @function [parent=#Sprite] SetOpacity
-- @param #number opacityopacity

---
-- Function SetBringToFront
--
-- @function [parent=#Sprite] SetBringToFront
-- @param #boolean enableenable

---
-- Function SetBringToBack
--
-- @function [parent=#Sprite] SetBringToBack
-- @param #boolean enableenable

---
-- Function SetClipChildren
--
-- @function [parent=#Sprite] SetClipChildren
-- @param #boolean enableenable

---
-- Function SetSortChildren
--
-- @function [parent=#Sprite] SetSortChildren
-- @param #boolean enableenable

---
-- Function SetUseDerivedOpacity
--
-- @function [parent=#Sprite] SetUseDerivedOpacity
-- @param #boolean enableenable

---
-- Function SetEnabled
--
-- @function [parent=#Sprite] SetEnabled
-- @param #boolean enableenable

---
-- Function SetEditable
--
-- @function [parent=#Sprite] SetEditable
-- @param #boolean enableenable

---
-- Function SetFocus
--
-- @function [parent=#Sprite] SetFocus
-- @param #boolean enableenable

---
-- Function SetSelected
--
-- @function [parent=#Sprite] SetSelected
-- @param #boolean enableenable

---
-- Function SetVisible
--
-- @function [parent=#Sprite] SetVisible
-- @param #boolean enableenable

---
-- Function SetFocusMode
--
-- @function [parent=#Sprite] SetFocusMode
-- @param FocusMode#FocusMode modemode

---
-- Function SetDragDropMode
--
-- @function [parent=#Sprite] SetDragDropMode
-- @param #number modemode

---
-- Function SetStyle
--
-- @function [parent=#Sprite] SetStyle
-- @param #string styleNamestyleName
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetStyle
--
-- @function [parent=#Sprite] SetStyle
-- @param XMLElement#XMLElement elementelement
-- @return #boolean

---
-- Function SetStyleAuto
--
-- @function [parent=#Sprite] SetStyleAuto
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetDefaultStyle
--
-- @function [parent=#Sprite] SetDefaultStyle
-- @param XMLFile#XMLFile stylestyle

---
-- Function SetLayout
--
-- @function [parent=#Sprite] SetLayout
-- @param LayoutMode#LayoutMode modemode
-- @param #number spacingspacing

---
-- Function SetLayout
--
-- @function [parent=#Sprite] SetLayout
-- @param LayoutMode#LayoutMode modemode
-- @param #number spacingspacing
-- @param IntRect#IntRect borderborder

---
-- Function SetLayoutMode
--
-- @function [parent=#Sprite] SetLayoutMode
-- @param LayoutMode#LayoutMode modemode

---
-- Function SetLayoutSpacing
--
-- @function [parent=#Sprite] SetLayoutSpacing
-- @param #number spacingspacing

---
-- Function SetLayoutBorder
--
-- @function [parent=#Sprite] SetLayoutBorder
-- @param IntRect#IntRect borderborder

---
-- Function SetIndent
--
-- @function [parent=#Sprite] SetIndent
-- @param #number indentindent

---
-- Function SetIndentSpacing
--
-- @function [parent=#Sprite] SetIndentSpacing
-- @param #number indentSpacingindentSpacing

---
-- Function UpdateLayout
--
-- @function [parent=#Sprite] UpdateLayout

---
-- Function DisableLayoutUpdate
--
-- @function [parent=#Sprite] DisableLayoutUpdate

---
-- Function EnableLayoutUpdate
--
-- @function [parent=#Sprite] EnableLayoutUpdate

---
-- Function BringToFront
--
-- @function [parent=#Sprite] BringToFront

---
-- Function CreateChild
--
-- @function [parent=#Sprite] CreateChild
-- @param #string typetype
-- @param #string namename
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function AddChild
--
-- @function [parent=#Sprite] AddChild
-- @param UIElement#UIElement elementelement

---
-- Function InsertChild
--
-- @function [parent=#Sprite] InsertChild
-- @param #number indexindex
-- @param UIElement#UIElement elementelement

---
-- Function RemoveChild
--
-- @function [parent=#Sprite] RemoveChild
-- @param UIElement#UIElement elementelement
-- @param #number indexindex

---
-- Function RemoveChildAtIndex
--
-- @function [parent=#Sprite] RemoveChildAtIndex
-- @param #number indexindex

---
-- Function RemoveAllChildren
--
-- @function [parent=#Sprite] RemoveAllChildren

---
-- Function Remove
--
-- @function [parent=#Sprite] Remove

---
-- Function FindChild
--
-- @function [parent=#Sprite] FindChild
-- @param UIElement#UIElement elementelement
-- @return #number

---
-- Function SetParent
--
-- @function [parent=#Sprite] SetParent
-- @param UIElement#UIElement parentparent
-- @param #number indexindex

---
-- Function SetVar
--
-- @function [parent=#Sprite] SetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @param Variant#Variant valuevalue

---
-- Function SetInternal
--
-- @function [parent=#Sprite] SetInternal
-- @param #boolean enableenable

---
-- Function SetTraversalMode
--
-- @function [parent=#Sprite] SetTraversalMode
-- @param TraversalMode#TraversalMode traversalModetraversalMode

---
-- Function SetElementEventSender
--
-- @function [parent=#Sprite] SetElementEventSender
-- @param #boolean flagflag

---
-- Function GetName
--
-- @function [parent=#Sprite] GetName
-- @return const String#const String

---
-- Function GetPosition
--
-- @function [parent=#Sprite] GetPosition
-- @return const IntVector2#const IntVector2

---
-- Function GetSize
--
-- @function [parent=#Sprite] GetSize
-- @return const IntVector2#const IntVector2

---
-- Function GetWidth
--
-- @function [parent=#Sprite] GetWidth
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#Sprite] GetHeight
-- @return #number

---
-- Function GetMinSize
--
-- @function [parent=#Sprite] GetMinSize
-- @return const IntVector2#const IntVector2

---
-- Function GetMinWidth
--
-- @function [parent=#Sprite] GetMinWidth
-- @return #number

---
-- Function GetMinHeight
--
-- @function [parent=#Sprite] GetMinHeight
-- @return #number

---
-- Function GetMaxSize
--
-- @function [parent=#Sprite] GetMaxSize
-- @return const IntVector2#const IntVector2

---
-- Function GetMaxWidth
--
-- @function [parent=#Sprite] GetMaxWidth
-- @return #number

---
-- Function GetMaxHeight
--
-- @function [parent=#Sprite] GetMaxHeight
-- @return #number

---
-- Function IsFixedSize
--
-- @function [parent=#Sprite] IsFixedSize
-- @return #boolean

---
-- Function IsFixedWidth
--
-- @function [parent=#Sprite] IsFixedWidth
-- @return #boolean

---
-- Function IsFixedHeight
--
-- @function [parent=#Sprite] IsFixedHeight
-- @return #boolean

---
-- Function GetChildOffset
--
-- @function [parent=#Sprite] GetChildOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetHorizontalAlignment
--
-- @function [parent=#Sprite] GetHorizontalAlignment
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetVerticalAlignment
--
-- @function [parent=#Sprite] GetVerticalAlignment
-- @return VerticalAlignment#VerticalAlignment

---
-- Function GetClipBorder
--
-- @function [parent=#Sprite] GetClipBorder
-- @return const IntRect#const IntRect

---
-- Function GetColor
--
-- @function [parent=#Sprite] GetColor
-- @param Corner#Corner cornercorner
-- @return const Color#const Color

---
-- Function GetPriority
--
-- @function [parent=#Sprite] GetPriority
-- @return #number

---
-- Function GetOpacity
--
-- @function [parent=#Sprite] GetOpacity
-- @return #number

---
-- Function GetDerivedOpacity
--
-- @function [parent=#Sprite] GetDerivedOpacity
-- @return #number

---
-- Function GetBringToFront
--
-- @function [parent=#Sprite] GetBringToFront
-- @return #boolean

---
-- Function GetBringToBack
--
-- @function [parent=#Sprite] GetBringToBack
-- @return #boolean

---
-- Function GetClipChildren
--
-- @function [parent=#Sprite] GetClipChildren
-- @return #boolean

---
-- Function GetSortChildren
--
-- @function [parent=#Sprite] GetSortChildren
-- @return #boolean

---
-- Function GetUseDerivedOpacity
--
-- @function [parent=#Sprite] GetUseDerivedOpacity
-- @return #boolean

---
-- Function HasFocus
--
-- @function [parent=#Sprite] HasFocus
-- @return #boolean

---
-- Function IsEnabled
--
-- @function [parent=#Sprite] IsEnabled
-- @return #boolean

---
-- Function IsEditable
--
-- @function [parent=#Sprite] IsEditable
-- @return #boolean

---
-- Function IsSelected
--
-- @function [parent=#Sprite] IsSelected
-- @return #boolean

---
-- Function IsVisible
--
-- @function [parent=#Sprite] IsVisible
-- @return #boolean

---
-- Function IsHovering
--
-- @function [parent=#Sprite] IsHovering
-- @return #boolean

---
-- Function IsInternal
--
-- @function [parent=#Sprite] IsInternal
-- @return #boolean

---
-- Function HasColorGradient
--
-- @function [parent=#Sprite] HasColorGradient
-- @return #boolean

---
-- Function GetFocusMode
--
-- @function [parent=#Sprite] GetFocusMode
-- @return FocusMode#FocusMode

---
-- Function GetDragDropMode
--
-- @function [parent=#Sprite] GetDragDropMode
-- @return #number

---
-- Function GetAppliedStyle
--
-- @function [parent=#Sprite] GetAppliedStyle
-- @return const String#const String

---
-- Function GetDefaultStyle
--
-- @function [parent=#Sprite] GetDefaultStyle
-- @param #boolean recursiveUprecursiveUp
-- @return XMLFile#XMLFile

---
-- Function GetLayoutMode
--
-- @function [parent=#Sprite] GetLayoutMode
-- @return LayoutMode#LayoutMode

---
-- Function GetLayoutSpacing
--
-- @function [parent=#Sprite] GetLayoutSpacing
-- @return #number

---
-- Function GetLayoutBorder
--
-- @function [parent=#Sprite] GetLayoutBorder
-- @return const IntRect#const IntRect

---
-- Function GetNumChildren
--
-- @function [parent=#Sprite] GetNumChildren
-- @param #boolean recursiverecursive
-- @return #number

---
-- Function GetChild
--
-- @function [parent=#Sprite] GetChild
-- @param #string namename
-- @param #boolean recursiverecursive
-- @return UIElement#UIElement

---
-- Function GetChild
--
-- @function [parent=#Sprite] GetChild
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function GetParent
--
-- @function [parent=#Sprite] GetParent
-- @return UIElement#UIElement

---
-- Function GetRoot
--
-- @function [parent=#Sprite] GetRoot
-- @return UIElement#UIElement

---
-- Function GetDerivedColor
--
-- @function [parent=#Sprite] GetDerivedColor
-- @return const Color#const Color

---
-- Function GetVar
--
-- @function [parent=#Sprite] GetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @return const Variant#const Variant

---
-- Function GetVars
--
-- @function [parent=#Sprite] GetVars
-- @return const VariantMap#const VariantMap

---
-- Function ScreenToElement
--
-- @function [parent=#Sprite] ScreenToElement
-- @param IntVector2#IntVector2 screenPositionscreenPosition
-- @return IntVector2#IntVector2

---
-- Function ElementToScreen
--
-- @function [parent=#Sprite] ElementToScreen
-- @param IntVector2#IntVector2 positionposition
-- @return IntVector2#IntVector2

---
-- Function IsInside
--
-- @function [parent=#Sprite] IsInside
-- @param IntVector2#IntVector2 positionposition
-- @param #boolean isScreenisScreen
-- @return #boolean

---
-- Function IsInsideCombined
--
-- @function [parent=#Sprite] IsInsideCombined
-- @param IntVector2#IntVector2 positionposition
-- @param #boolean isScreenisScreen
-- @return #boolean

---
-- Function GetCombinedScreenRect
--
-- @function [parent=#Sprite] GetCombinedScreenRect
-- @return IntRect#IntRect

---
-- Function SortChildren
--
-- @function [parent=#Sprite] SortChildren

---
-- Function GetLayoutMinSize
--
-- @function [parent=#Sprite] GetLayoutMinSize
-- @return #number

---
-- Function GetIndent
--
-- @function [parent=#Sprite] GetIndent
-- @return #number

---
-- Function GetIndentSpacing
--
-- @function [parent=#Sprite] GetIndentSpacing
-- @return #number

---
-- Function GetIndentWidth
--
-- @function [parent=#Sprite] GetIndentWidth
-- @return #number

---
-- Function SetChildOffset
--
-- @function [parent=#Sprite] SetChildOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetHovering
--
-- @function [parent=#Sprite] SetHovering
-- @param #boolean enableenable

---
-- Function GetColor
--
-- @function [parent=#Sprite] GetColor
-- @return const Color#const Color

---
-- Function GetTraversalMode
--
-- @function [parent=#Sprite] GetTraversalMode
-- @return TraversalMode#TraversalMode

---
-- Function IsElementEventSender
--
-- @function [parent=#Sprite] IsElementEventSender
-- @return #boolean

---
-- Function GetElementEventSender
--
-- @function [parent=#Sprite] GetElementEventSender
-- @return UIElement#UIElement

---
-- Field screenPosition (Read only)
--
-- @field [parent=#Sprite] IntVector2#IntVector2 screenPosition

---
-- Field name
--
-- @field [parent=#Sprite] #string name

---
-- Field position
--
-- @field [parent=#Sprite] IntVector2#IntVector2 position

---
-- Field size
--
-- @field [parent=#Sprite] IntVector2#IntVector2 size

---
-- Field width
--
-- @field [parent=#Sprite] #number width

---
-- Field height
--
-- @field [parent=#Sprite] #number height

---
-- Field minSize
--
-- @field [parent=#Sprite] IntVector2#IntVector2 minSize

---
-- Field minWidth
--
-- @field [parent=#Sprite] #number minWidth

---
-- Field minHeight
--
-- @field [parent=#Sprite] #number minHeight

---
-- Field maxSize
--
-- @field [parent=#Sprite] IntVector2#IntVector2 maxSize

---
-- Field maxWidth
--
-- @field [parent=#Sprite] #number maxWidth

---
-- Field maxHeight
--
-- @field [parent=#Sprite] #number maxHeight

---
-- Field fixedSize (Read only)
--
-- @field [parent=#Sprite] #boolean fixedSize

---
-- Field fixedWidth (Read only)
--
-- @field [parent=#Sprite] #boolean fixedWidth

---
-- Field fixedHeight (Read only)
--
-- @field [parent=#Sprite] #boolean fixedHeight

---
-- Field childOffset
--
-- @field [parent=#Sprite] IntVector2#IntVector2 childOffset

---
-- Field horizontalAlignment
--
-- @field [parent=#Sprite] HorizontalAlignment#HorizontalAlignment horizontalAlignment

---
-- Field verticalAlignment
--
-- @field [parent=#Sprite] VerticalAlignment#VerticalAlignment verticalAlignment

---
-- Field clipBorder
--
-- @field [parent=#Sprite] IntRect#IntRect clipBorder

---
-- Field color
--
-- @field [parent=#Sprite] Color#Color color

---
-- Field priority
--
-- @field [parent=#Sprite] #number priority

---
-- Field opacity
--
-- @field [parent=#Sprite] #number opacity

---
-- Field derivedOpacity (Read only)
--
-- @field [parent=#Sprite] #number derivedOpacity

---
-- Field bringToFront
--
-- @field [parent=#Sprite] #boolean bringToFront

---
-- Field bringToBack
--
-- @field [parent=#Sprite] #boolean bringToBack

---
-- Field clipChildren
--
-- @field [parent=#Sprite] #boolean clipChildren

---
-- Field sortChildren
--
-- @field [parent=#Sprite] #boolean sortChildren

---
-- Field useDerivedOpacity
--
-- @field [parent=#Sprite] #boolean useDerivedOpacity

---
-- Field focus
--
-- @field [parent=#Sprite] #boolean focus

---
-- Field enabled
--
-- @field [parent=#Sprite] #boolean enabled

---
-- Field editable
--
-- @field [parent=#Sprite] #boolean editable

---
-- Field selected
--
-- @field [parent=#Sprite] #boolean selected

---
-- Field visible
--
-- @field [parent=#Sprite] #boolean visible

---
-- Field hovering
--
-- @field [parent=#Sprite] #boolean hovering

---
-- Field internal
--
-- @field [parent=#Sprite] #boolean internal

---
-- Field colorGradient (Read only)
--
-- @field [parent=#Sprite] #boolean colorGradient

---
-- Field focusMode
--
-- @field [parent=#Sprite] FocusMode#FocusMode focusMode

---
-- Field dragDropMode
--
-- @field [parent=#Sprite] #number dragDropMode

---
-- Field style
--
-- @field [parent=#Sprite] #string style

---
-- Field defaultStyle
--
-- @field [parent=#Sprite] XMLFile#XMLFile defaultStyle

---
-- Field layoutMode
--
-- @field [parent=#Sprite] LayoutMode#LayoutMode layoutMode

---
-- Field layoutSpacing
--
-- @field [parent=#Sprite] #number layoutSpacing

---
-- Field layoutBorder
--
-- @field [parent=#Sprite] IntRect#IntRect layoutBorder

---
-- Field numChildren (Read only)
--
-- @field [parent=#Sprite] #number numChildren

---
-- Field parent
--
-- @field [parent=#Sprite] UIElement#UIElement parent

---
-- Field root (Read only)
--
-- @field [parent=#Sprite] UIElement#UIElement root

---
-- Field derivedColor (Read only)
--
-- @field [parent=#Sprite] Color#Color derivedColor

---
-- Field combinedScreenRect (Read only)
--
-- @field [parent=#Sprite] IntRect#IntRect combinedScreenRect

---
-- Field layoutMinSize (Read only)
--
-- @field [parent=#Sprite] #number layoutMinSize

---
-- Field indent
--
-- @field [parent=#Sprite] #number indent

---
-- Field indentSpacing
--
-- @field [parent=#Sprite] #number indentSpacing

---
-- Field indentWidth (Read only)
--
-- @field [parent=#Sprite] #number indentWidth

---
-- Field traversalMode
--
-- @field [parent=#Sprite] TraversalMode#TraversalMode traversalMode

---
-- Field elementEventSender
--
-- @field [parent=#Sprite] #boolean elementEventSender

---
-- Function SetTemporary
--
-- @function [parent=#Sprite] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#Sprite] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Sprite] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Sprite] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Sprite] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Sprite] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Sprite] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Sprite] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#Sprite] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Sprite] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Sprite] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Sprite] #string category


return nil
