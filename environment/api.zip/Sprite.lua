---
-- Module Sprite
-- Extends UIElement
--
-- @module Sprite

---
-- Function Sprite
--
-- @function [parent=#Sprite] Sprite

---
-- Function new
--
-- @function [parent=#Sprite] new
-- @return Sprite#Sprite

---
-- Function delete
--
-- @function [parent=#Sprite] delete

---
-- Function SetPosition
--
-- @function [parent=#Sprite] SetPosition
-- @param Vector2#Vector2 positionposition

---
-- Function SetPosition
--
-- @function [parent=#Sprite] SetPosition
-- @param #number xx
-- @param #number yy

---
-- Function SetHotSpot
--
-- @function [parent=#Sprite] SetHotSpot
-- @param IntVector2#IntVector2 hotSpothotSpot

---
-- Function SetHotSpot
--
-- @function [parent=#Sprite] SetHotSpot
-- @param #number xx
-- @param #number yy

---
-- Function SetScale
--
-- @function [parent=#Sprite] SetScale
-- @param Vector2#Vector2 scalescale

---
-- Function SetScale
--
-- @function [parent=#Sprite] SetScale
-- @param #number xx
-- @param #number yy

---
-- Function SetScale
--
-- @function [parent=#Sprite] SetScale
-- @param #number scalescale

---
-- Function SetRotation
--
-- @function [parent=#Sprite] SetRotation
-- @param #number angleangle

---
-- Function SetTexture
--
-- @function [parent=#Sprite] SetTexture
-- @param Texture#Texture texturetexture

---
-- Function SetImageRect
--
-- @function [parent=#Sprite] SetImageRect
-- @param IntRect#IntRect rectrect

---
-- Function SetFullImageRect
--
-- @function [parent=#Sprite] SetFullImageRect

---
-- Function SetBlendMode
--
-- @function [parent=#Sprite] SetBlendMode
-- @param BlendMode#BlendMode modemode

---
-- Function GetPosition
--
-- @function [parent=#Sprite] GetPosition
-- @return const Vector2#const Vector2

---
-- Function GetHotSpot
--
-- @function [parent=#Sprite] GetHotSpot
-- @return const IntVector2#const IntVector2

---
-- Function GetScale
--
-- @function [parent=#Sprite] GetScale
-- @return const Vector2#const Vector2

---
-- Function GetRotation
--
-- @function [parent=#Sprite] GetRotation
-- @return #number

---
-- Function GetTexture
--
-- @function [parent=#Sprite] GetTexture
-- @return Texture#Texture

---
-- Function GetImageRect
--
-- @function [parent=#Sprite] GetImageRect
-- @return const IntRect#const IntRect

---
-- Function GetBlendMode
--
-- @function [parent=#Sprite] GetBlendMode
-- @return BlendMode#BlendMode

---
-- Function GetTransform
--
-- @function [parent=#Sprite] GetTransform
-- @return const Matrix3x4#const Matrix3x4

---
-- Field position
--
-- @field [parent=#Sprite] Vector2#Vector2 position

---
-- Field hotSpot
--
-- @field [parent=#Sprite] IntVector2#IntVector2 hotSpot

---
-- Field scale
--
-- @field [parent=#Sprite] Vector2#Vector2 scale

---
-- Field rotation
--
-- @field [parent=#Sprite] #number rotation

---
-- Field texture
--
-- @field [parent=#Sprite] Texture#Texture texture

---
-- Field imageRect
--
-- @field [parent=#Sprite] IntRect#IntRect imageRect

---
-- Field blendMode
--
-- @field [parent=#Sprite] BlendMode#BlendMode blendMode

---
-- Field transform (Read only)
--
-- @field [parent=#Sprite] Matrix3x4#Matrix3x4 transform


return nil
