---
-- Module Material
-- Extends Resource
--
-- @module Material

---
-- Function Material
--
-- @function [parent=#Material] Material

---
-- Function new
--
-- @function [parent=#Material] new
-- @return Material#Material

---
-- Function delete
--
-- @function [parent=#Material] delete

---
-- Function SetNumTechniques
--
-- @function [parent=#Material] SetNumTechniques
-- @param #number numnum

---
-- Function SetTechnique
--
-- @function [parent=#Material] SetTechnique
-- @param #number indexindex
-- @param Technique#Technique techtech
-- @param #number qualityLevelqualityLevel
-- @param #number lodDistancelodDistance

---
-- Function SetShaderParameter
--
-- @function [parent=#Material] SetShaderParameter
-- @param #string namename
-- @param Variant#Variant valuevalue

---
-- Function SetTexture
--
-- @function [parent=#Material] SetTexture
-- @param TextureUnit#TextureUnit unitunit
-- @param Texture#Texture texturetexture

---
-- Function SetUVTransform
--
-- @function [parent=#Material] SetUVTransform
-- @param Vector2#Vector2 offsetoffset
-- @param #number rotationrotation
-- @param Vector2#Vector2 repeatrepeat

---
-- Function SetUVTransform
--
-- @function [parent=#Material] SetUVTransform
-- @param Vector2#Vector2 offsetoffset
-- @param #number rotationrotation
-- @param #number repeatrepeat

---
-- Function SetCullMode
--
-- @function [parent=#Material] SetCullMode
-- @param CullMode#CullMode modemode

---
-- Function SetShadowCullMode
--
-- @function [parent=#Material] SetShadowCullMode
-- @param CullMode#CullMode modemode

---
-- Function SetDepthBias
--
-- @function [parent=#Material] SetDepthBias
-- @param BiasParameters#BiasParameters parametersparameters

---
-- Function RemoveShaderParameter
--
-- @function [parent=#Material] RemoveShaderParameter
-- @param #string namename

---
-- Function ReleaseShaders
--
-- @function [parent=#Material] ReleaseShaders

---
-- Function Clone
--
-- @function [parent=#Material] Clone
-- @param #string cloneNamecloneName
-- @return Material#Material

---
-- Function SortTechniques
--
-- @function [parent=#Material] SortTechniques

---
-- Function MarkForAuxView
--
-- @function [parent=#Material] MarkForAuxView
-- @param #number frameNumberframeNumber

---
-- Function GetNumTechniques
--
-- @function [parent=#Material] GetNumTechniques
-- @return #number

---
-- Function GetTechnique
--
-- @function [parent=#Material] GetTechnique
-- @param #number indexindex
-- @return Technique#Technique

---
-- Function GetPass
--
-- @function [parent=#Material] GetPass
-- @param #number indexindex
-- @param StringHash#StringHash passTypepassType
-- @return Pass#Pass

---
-- Function GetPass
--
-- @function [parent=#Material] GetPass
-- @param #number indexindex
-- @param #string passTypepassType
-- @return Pass#Pass

---
-- Function GetTexture
--
-- @function [parent=#Material] GetTexture
-- @param TextureUnit#TextureUnit unitunit
-- @return Texture#Texture

---
-- Function GetCullMode
--
-- @function [parent=#Material] GetCullMode
-- @return CullMode#CullMode

---
-- Function GetShadowCullMode
--
-- @function [parent=#Material] GetShadowCullMode
-- @return CullMode#CullMode

---
-- Function GetDepthBias
--
-- @function [parent=#Material] GetDepthBias
-- @return const BiasParameters#const BiasParameters

---
-- Function GetAuxViewFrameNumber
--
-- @function [parent=#Material] GetAuxViewFrameNumber
-- @return #number

---
-- Function GetOcclusion
--
-- @function [parent=#Material] GetOcclusion
-- @return #boolean

---
-- Function GetSpecular
--
-- @function [parent=#Material] GetSpecular
-- @return #boolean

---
-- Field cullMode (Read only)
--
-- @field [parent=#Material] CullMode#CullMode cullMode

---
-- Field shadowCullMode (Read only)
--
-- @field [parent=#Material] CullMode#CullMode shadowCullMode

---
-- Field auxViewFrameNumber (Read only)
--
-- @field [parent=#Material] #number auxViewFrameNumber

---
-- Field occlusion (Read only)
--
-- @field [parent=#Material] #boolean occlusion

---
-- Field specular (Read only)
--
-- @field [parent=#Material] #boolean specular


return nil
