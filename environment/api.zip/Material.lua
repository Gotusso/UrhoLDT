---
-- Module Material
-- Module Material extends Resource
-- Generated on 2014-05-31
--
-- @module Material

---
-- Function Material()
--
-- @function [parent=#Material] Material
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#Material] new
-- @param self Self reference
-- @return Material#Material

---
-- Function delete()
--
-- @function [parent=#Material] delete
-- @param self Self reference

---
-- Function SetNumTechniques()
-- Set number of techniques.
--
-- @function [parent=#Material] SetNumTechniques
-- @param self Self reference
-- @param #number num num

---
-- Function SetTechnique()
-- Set technique.
--
-- @function [parent=#Material] SetTechnique
-- @param self Self reference
-- @param #number index index
-- @param Technique#Technique tech tech
-- @param #number qualityLevel qualityLevel
-- @param #number lodDistance lodDistance

---
-- Function SetShaderParameter()
-- Set shader parameter.
--
-- @function [parent=#Material] SetShaderParameter
-- @param self Self reference
-- @param #string name name
-- @param Variant#Variant value value

---
-- Function SetShaderParameterAnimation()
-- Set shader paramter animation.
--
-- @function [parent=#Material] SetShaderParameterAnimation
-- @param self Self reference
-- @param #string name name
-- @param ValueAnimation#ValueAnimation animation animation
-- @param WrapMode#WrapMode wrapMode wrapMode
-- @param #number speed speed

---
-- Function SetShaderParameterAnimationWrapMode()
-- Set shader paramter animation.
--
-- @function [parent=#Material] SetShaderParameterAnimationWrapMode
-- @param self Self reference
-- @param #string name name
-- @param WrapMode#WrapMode wrapMode wrapMode

---
-- Function SetShaderParameterAnimationSpeed()
-- Set shader paramter animation.
--
-- @function [parent=#Material] SetShaderParameterAnimationSpeed
-- @param self Self reference
-- @param #string name name
-- @param #number speed speed

---
-- Function SetTexture()
-- Set texture.
--
-- @function [parent=#Material] SetTexture
-- @param self Self reference
-- @param TextureUnit#TextureUnit unit unit
-- @param Texture#Texture texture texture

---
-- Function SetUVTransform()
-- Set texture coordinate transform.
--
-- @function [parent=#Material] SetUVTransform
-- @param self Self reference
-- @param Vector2#Vector2 offset offset
-- @param #number rotation rotation
-- @param Vector2#Vector2 repeat repeat

---
-- Function SetUVTransform()
-- Set texture coordinate transform.
--
-- @function [parent=#Material] SetUVTransform
-- @param self Self reference
-- @param Vector2#Vector2 offset offset
-- @param #number rotation rotation
-- @param #number repeat repeat

---
-- Function SetCullMode()
-- Set culling mode.
--
-- @function [parent=#Material] SetCullMode
-- @param self Self reference
-- @param CullMode#CullMode mode mode

---
-- Function SetShadowCullMode()
-- Set culling mode for shadows.
--
-- @function [parent=#Material] SetShadowCullMode
-- @param self Self reference
-- @param CullMode#CullMode mode mode

---
-- Function SetDepthBias()
-- Set depth bias.
--
-- @function [parent=#Material] SetDepthBias
-- @param self Self reference
-- @param BiasParameters#BiasParameters parameters parameters

---
-- Function RemoveShaderParameter()
-- Remove shader parameter.
--
-- @function [parent=#Material] RemoveShaderParameter
-- @param self Self reference
-- @param #string name name

---
-- Function ReleaseShaders()
-- Reset all shader pointers.
--
-- @function [parent=#Material] ReleaseShaders
-- @param self Self reference

---
-- Function Clone()
-- Clone material.
--
-- @function [parent=#Material] Clone
-- @param self Self reference
-- @param #string cloneName cloneName
-- @return Material#Material

---
-- Function SortTechniques()
-- Ensure that material techniques are listed in correct order.
--
-- @function [parent=#Material] SortTechniques
-- @param self Self reference

---
-- Function MarkForAuxView()
-- Mark material for auxiliary view rendering.
--
-- @function [parent=#Material] MarkForAuxView
-- @param self Self reference
-- @param #number frameNumber frameNumber

---
-- Function GetNumTechniques()
-- Return number of techniques.
--
-- @function [parent=#Material] GetNumTechniques
-- @param self Self reference
-- @return #number

---
-- Function GetTechnique()
-- Return technique by index.
--
-- @function [parent=#Material] GetTechnique
-- @param self Self reference
-- @param #number index index
-- @return Technique#Technique

---
-- Function GetPass()
-- Return pass by technique index and pass type.
--
-- @function [parent=#Material] GetPass
-- @param self Self reference
-- @param #number index index
-- @param StringHash#StringHash passType passType
-- @return Pass#Pass

---
-- Function GetPass()
--
-- @function [parent=#Material] GetPass
-- @param self Self reference
-- @param #number index index
-- @param #string passType passType
-- @return Pass#Pass

---
-- Function GetTexture()
-- Return texture by unit.
--
-- @function [parent=#Material] GetTexture
-- @param self Self reference
-- @param TextureUnit#TextureUnit unit unit
-- @return Texture#Texture

---
-- Function GetShaderParameterAnimation()
-- Return shader parameter animation.
--
-- @function [parent=#Material] GetShaderParameterAnimation
-- @param self Self reference
-- @param #string name name
-- @return ValueAnimation#ValueAnimation

---
-- Function GetShaderParameterAnimationWrapMode()
-- Return shader parameter animation wrap mode.
--
-- @function [parent=#Material] GetShaderParameterAnimationWrapMode
-- @param self Self reference
-- @param #string name name
-- @return WrapMode#WrapMode

---
-- Function GetShaderParameterAnimationSpeed()
-- Return shader parameter animation speed.
--
-- @function [parent=#Material] GetShaderParameterAnimationSpeed
-- @param self Self reference
-- @param #string name name
-- @return #number

---
-- Function GetCullMode()
-- Return normal culling mode.
--
-- @function [parent=#Material] GetCullMode
-- @param self Self reference
-- @return CullMode#CullMode

---
-- Function GetShadowCullMode()
-- Return culling mode for shadows.
--
-- @function [parent=#Material] GetShadowCullMode
-- @param self Self reference
-- @return CullMode#CullMode

---
-- Function GetDepthBias()
-- Return depth bias.
--
-- @function [parent=#Material] GetDepthBias
-- @param self Self reference
-- @return const BiasParameters#const BiasParameters

---
-- Function GetAuxViewFrameNumber()
-- Return last auxiliary view rendered frame number.
--
-- @function [parent=#Material] GetAuxViewFrameNumber
-- @param self Self reference
-- @return #number

---
-- Function GetOcclusion()
-- Return whether should render occlusion.
--
-- @function [parent=#Material] GetOcclusion
-- @param self Self reference
-- @return #boolean

---
-- Function GetSpecular()
-- Return whether should render specular.
--
-- @function [parent=#Material] GetSpecular
-- @param self Self reference
-- @return #boolean

---
-- Field cullMode (Read only)
--
-- @field [parent=#Material] CullMode#CullMode cullMode

---
-- Field shadowCullMode (Read only)
--
-- @field [parent=#Material] CullMode#CullMode shadowCullMode

---
-- Field auxViewFrameNumber (Read only)
--
-- @field [parent=#Material] #number auxViewFrameNumber

---
-- Field occlusion (Read only)
--
-- @field [parent=#Material] #boolean occlusion

---
-- Field specular (Read only)
--
-- @field [parent=#Material] #boolean specular


return nil
