---
-- Module Material
-- Module Material extends Resource
-- Generated on 2014-03-13
--
-- @module Material

---
-- Function Material
--
-- @function [parent=#Material] Material
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#Material] new
-- @param self Self reference
-- @return Material#Material

---
-- Function delete
--
-- @function [parent=#Material] delete
-- @param self Self reference

---
-- Function SetNumTechniques
--
-- @function [parent=#Material] SetNumTechniques
-- @param self Self reference
-- @param #number num num

---
-- Function SetTechnique
--
-- @function [parent=#Material] SetTechnique
-- @param self Self reference
-- @param #number index index
-- @param Technique#Technique tech tech
-- @param #number qualityLevel qualityLevel
-- @param #number lodDistance lodDistance

---
-- Function SetShaderParameter
--
-- @function [parent=#Material] SetShaderParameter
-- @param self Self reference
-- @param #string name name
-- @param Variant#Variant value value

---
-- Function SetTexture
--
-- @function [parent=#Material] SetTexture
-- @param self Self reference
-- @param TextureUnit#TextureUnit unit unit
-- @param Texture#Texture texture texture

---
-- Function SetUVTransform
--
-- @function [parent=#Material] SetUVTransform
-- @param self Self reference
-- @param Vector2#Vector2 offset offset
-- @param #number rotation rotation
-- @param Vector2#Vector2 repeat repeat

---
-- Function SetUVTransform
--
-- @function [parent=#Material] SetUVTransform
-- @param self Self reference
-- @param Vector2#Vector2 offset offset
-- @param #number rotation rotation
-- @param #number repeat repeat

---
-- Function SetCullMode
--
-- @function [parent=#Material] SetCullMode
-- @param self Self reference
-- @param CullMode#CullMode mode mode

---
-- Function SetShadowCullMode
--
-- @function [parent=#Material] SetShadowCullMode
-- @param self Self reference
-- @param CullMode#CullMode mode mode

---
-- Function SetDepthBias
--
-- @function [parent=#Material] SetDepthBias
-- @param self Self reference
-- @param BiasParameters#BiasParameters parameters parameters

---
-- Function RemoveShaderParameter
--
-- @function [parent=#Material] RemoveShaderParameter
-- @param self Self reference
-- @param #string name name

---
-- Function ReleaseShaders
--
-- @function [parent=#Material] ReleaseShaders
-- @param self Self reference

---
-- Function Clone
--
-- @function [parent=#Material] Clone
-- @param self Self reference
-- @param #string cloneName cloneName
-- @return Material#Material

---
-- Function SortTechniques
--
-- @function [parent=#Material] SortTechniques
-- @param self Self reference

---
-- Function MarkForAuxView
--
-- @function [parent=#Material] MarkForAuxView
-- @param self Self reference
-- @param #number frameNumber frameNumber

---
-- Function GetNumTechniques
--
-- @function [parent=#Material] GetNumTechniques
-- @param self Self reference
-- @return #number

---
-- Function GetTechnique
--
-- @function [parent=#Material] GetTechnique
-- @param self Self reference
-- @param #number index index
-- @return Technique#Technique

---
-- Function GetPass
--
-- @function [parent=#Material] GetPass
-- @param self Self reference
-- @param #number index index
-- @param StringHash#StringHash passType passType
-- @return Pass#Pass

---
-- Function GetPass
--
-- @function [parent=#Material] GetPass
-- @param self Self reference
-- @param #number index index
-- @param #string passType passType
-- @return Pass#Pass

---
-- Function GetTexture
--
-- @function [parent=#Material] GetTexture
-- @param self Self reference
-- @param TextureUnit#TextureUnit unit unit
-- @return Texture#Texture

---
-- Function GetCullMode
--
-- @function [parent=#Material] GetCullMode
-- @param self Self reference
-- @return CullMode#CullMode

---
-- Function GetShadowCullMode
--
-- @function [parent=#Material] GetShadowCullMode
-- @param self Self reference
-- @return CullMode#CullMode

---
-- Function GetDepthBias
--
-- @function [parent=#Material] GetDepthBias
-- @param self Self reference
-- @return const BiasParameters#const BiasParameters

---
-- Function GetAuxViewFrameNumber
--
-- @function [parent=#Material] GetAuxViewFrameNumber
-- @param self Self reference
-- @return #number

---
-- Function GetOcclusion
--
-- @function [parent=#Material] GetOcclusion
-- @param self Self reference
-- @return #boolean

---
-- Function GetSpecular
--
-- @function [parent=#Material] GetSpecular
-- @param self Self reference
-- @return #boolean

---
-- Field cullMode (Read only)
--
-- @field [parent=#Material] CullMode#CullMode cullMode

---
-- Field shadowCullMode (Read only)
--
-- @field [parent=#Material] CullMode#CullMode shadowCullMode

---
-- Field auxViewFrameNumber (Read only)
--
-- @field [parent=#Material] #number auxViewFrameNumber

---
-- Field occlusion (Read only)
--
-- @field [parent=#Material] #boolean occlusion

---
-- Field specular (Read only)
--
-- @field [parent=#Material] #boolean specular

---
-- Function Load
--
-- @function [parent=#Material] Load
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#Material] Save
-- @param self Self reference
-- @param Serializer#Serializer dest dest
-- @return #boolean

---
-- Function Load
--
-- @function [parent=#Material] Load
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#Material] Save
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function GetName
--
-- @function [parent=#Material] GetName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetNameHash
--
-- @function [parent=#Material] GetNameHash
-- @param self Self reference
-- @return StringHash#StringHash

---
-- Function GetMemoryUse
--
-- @function [parent=#Material] GetMemoryUse
-- @param self Self reference
-- @return #number

---
-- Field name (Read only)
--
-- @field [parent=#Material] #string name

---
-- Field nameHash (Read only)
--
-- @field [parent=#Material] StringHash#StringHash nameHash

---
-- Field memoryUse (Read only)
--
-- @field [parent=#Material] #number memoryUse


return nil
