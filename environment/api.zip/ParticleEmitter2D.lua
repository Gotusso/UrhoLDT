---
-- Module ParticleEmitter2D
-- Module ParticleEmitter2D extends Drawable2D
-- Generated on 2014-05-31
--
-- @module ParticleEmitter2D

---
-- Function SetEffect()
-- Set particle effect.
--
-- @function [parent=#ParticleEmitter2D] SetEffect
-- @param self Self reference
-- @param ParticleEffect2D#ParticleEffect2D effect effect

---
-- Function GetEffect()
-- Return particle effect.
--
-- @function [parent=#ParticleEmitter2D] GetEffect
-- @param self Self reference
-- @return ParticleEffect2D#ParticleEffect2D

---
-- Field effect
--
-- @field [parent=#ParticleEmitter2D] ParticleEffect2D#ParticleEffect2D effect


return nil
