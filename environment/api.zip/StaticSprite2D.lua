---
-- Module StaticSprite2D
-- Module StaticSprite2D extends Drawable2D
-- Generated on 2014-05-31
--
-- @module StaticSprite2D

---
-- Function SetFlip()
-- Set flip.
--
-- @function [parent=#StaticSprite2D] SetFlip
-- @param self Self reference
-- @param #boolean flipX flipX
-- @param #boolean flipY flipY

---
-- Function SetFlipX()
-- Set flip X.
--
-- @function [parent=#StaticSprite2D] SetFlipX
-- @param self Self reference
-- @param #boolean flipX flipX

---
-- Function SetFlipY()
-- Set flip Y.
--
-- @function [parent=#StaticSprite2D] SetFlipY
-- @param self Self reference
-- @param #boolean flipY flipY

---
-- Function SetColor()
-- Set color.
--
-- @function [parent=#StaticSprite2D] SetColor
-- @param self Self reference
-- @param Color#Color color color

---
-- Function GetFlipX()
-- Return flip X.
--
-- @function [parent=#StaticSprite2D] GetFlipX
-- @param self Self reference
-- @return #boolean

---
-- Function GetFlipY()
-- Return flip Y.
--
-- @function [parent=#StaticSprite2D] GetFlipY
-- @param self Self reference
-- @return #boolean

---
-- Function GetColor()
-- Return color.
--
-- @function [parent=#StaticSprite2D] GetColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Field flipX
--
-- @field [parent=#StaticSprite2D] #boolean flipX

---
-- Field flipY
--
-- @field [parent=#StaticSprite2D] #boolean flipY

---
-- Field color
--
-- @field [parent=#StaticSprite2D] Color#Color color


return nil
