---
-- Module Animatable
-- Module Animatable extends Serializable
-- Generated on 2014-05-31
--
-- @module Animatable

---
-- Function SetAnimationEnabled()
-- Set animation enabled.
--
-- @function [parent=#Animatable] SetAnimationEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetObjectAnimation()
-- Set object animation.
--
-- @function [parent=#Animatable] SetObjectAnimation
-- @param self Self reference
-- @param ObjectAnimation#ObjectAnimation objectAnimation objectAnimation

---
-- Function SetAttributeAnimation()
-- Set attribute animation.
--
-- @function [parent=#Animatable] SetAttributeAnimation
-- @param self Self reference
-- @param #string name name
-- @param ValueAnimation#ValueAnimation attributeAnimation attributeAnimation
-- @param WrapMode#WrapMode wrapMode wrapMode
-- @param #number speed speed

---
-- Function SetAttributeAnimationWrapMode()
-- Set attribute animation wrap mode.
--
-- @function [parent=#Animatable] SetAttributeAnimationWrapMode
-- @param self Self reference
-- @param #string name name
-- @param WrapMode#WrapMode wrapMode wrapMode

---
-- Function SetAttributeAnimationSpeed()
-- Set attribute animation speed.
--
-- @function [parent=#Animatable] SetAttributeAnimationSpeed
-- @param self Self reference
-- @param #string name name
-- @param #number speed speed

---
-- Function GetAnimationEnabled()
-- Return animation enabled.
--
-- @function [parent=#Animatable] GetAnimationEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function GetObjectAnimation()
-- Return object animation.
--
-- @function [parent=#Animatable] GetObjectAnimation
-- @param self Self reference
-- @return ObjectAnimation#ObjectAnimation

---
-- Function GetAttributeAnimation()
-- Return attribute animation.
--
-- @function [parent=#Animatable] GetAttributeAnimation
-- @param self Self reference
-- @param #string name name
-- @return ValueAnimation#ValueAnimation

---
-- Function GetAttributeAnimationWrapMode()
-- Return attribute animation wrap mode.
--
-- @function [parent=#Animatable] GetAttributeAnimationWrapMode
-- @param self Self reference
-- @param #string name name
-- @return WrapMode#WrapMode

---
-- Function GetAttributeAnimationSpeed()
-- Return attribute animation speed.
--
-- @function [parent=#Animatable] GetAttributeAnimationSpeed
-- @param self Self reference
-- @param #string name name
-- @return #number

---
-- Field animationEnabled
--
-- @field [parent=#Animatable] #boolean animationEnabled

---
-- Field objectAnimation
--
-- @field [parent=#Animatable] ObjectAnimation#ObjectAnimation objectAnimation


return nil
