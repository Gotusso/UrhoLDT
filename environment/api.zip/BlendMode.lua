---
-- Enumeration BlendMode
--
-- @module BlendMode

---
-- Enumeration value BLEND_REPLACE
--
-- @field [parent=#BlendMode] #number BLEND_REPLACE

---
-- Enumeration value BLEND_ADD
--
-- @field [parent=#BlendMode] #number BLEND_ADD

---
-- Enumeration value BLEND_MULTIPLY
--
-- @field [parent=#BlendMode] #number BLEND_MULTIPLY

---
-- Enumeration value BLEND_ALPHA
--
-- @field [parent=#BlendMode] #number BLEND_ALPHA

---
-- Enumeration value BLEND_ADDALPHA
--
-- @field [parent=#BlendMode] #number BLEND_ADDALPHA

---
-- Enumeration value BLEND_PREMULALPHA
--
-- @field [parent=#BlendMode] #number BLEND_PREMULALPHA

---
-- Enumeration value BLEND_INVDESTALPHA
--
-- @field [parent=#BlendMode] #number BLEND_INVDESTALPHA

---
-- Enumeration value MAX_BLENDMODES
--
-- @field [parent=#BlendMode] #number MAX_BLENDMODES


return nil
