---
-- Module Serializer
--
-- @module Serializer

---
-- Function Write
--
-- @function [parent=#Serializer] Write
-- @param VectorBuffer#VectorBuffer bufferbuffer
-- @return #number

---
-- Function WriteInt
--
-- @function [parent=#Serializer] WriteInt
-- @param #number valuevalue
-- @return #boolean

---
-- Function WriteShort
--
-- @function [parent=#Serializer] WriteShort
-- @param short#short valuevalue
-- @return #boolean

---
-- Function WriteByte
--
-- @function [parent=#Serializer] WriteByte
-- @param #string valuevalue
-- @return #boolean

---
-- Function WriteUInt
--
-- @function [parent=#Serializer] WriteUInt
-- @param #number valuevalue
-- @return #boolean

---
-- Function WriteUShort
--
-- @function [parent=#Serializer] WriteUShort
-- @param short#short valuevalue
-- @return #boolean

---
-- Function WriteUByte
--
-- @function [parent=#Serializer] WriteUByte
-- @param #string valuevalue
-- @return #boolean

---
-- Function WriteBool
--
-- @function [parent=#Serializer] WriteBool
-- @param #boolean valuevalue
-- @return #boolean

---
-- Function WriteFloat
--
-- @function [parent=#Serializer] WriteFloat
-- @param #number valuevalue
-- @return #boolean

---
-- Function WriteIntRect
--
-- @function [parent=#Serializer] WriteIntRect
-- @param IntRect#IntRect valuevalue
-- @return #boolean

---
-- Function WriteIntVector2
--
-- @function [parent=#Serializer] WriteIntVector2
-- @param IntVector2#IntVector2 valuevalue
-- @return #boolean

---
-- Function WriteRect
--
-- @function [parent=#Serializer] WriteRect
-- @param Rect#Rect valuevalue
-- @return #boolean

---
-- Function WriteVector2
--
-- @function [parent=#Serializer] WriteVector2
-- @param Vector2#Vector2 valuevalue
-- @return #boolean

---
-- Function WriteVector3
--
-- @function [parent=#Serializer] WriteVector3
-- @param Vector3#Vector3 valuevalue
-- @return #boolean

---
-- Function WritePackedVector3
--
-- @function [parent=#Serializer] WritePackedVector3
-- @param Vector3#Vector3 valuevalue
-- @param #number maxAbsCoordmaxAbsCoord
-- @return #boolean

---
-- Function WriteVector4
--
-- @function [parent=#Serializer] WriteVector4
-- @param Vector4#Vector4 valuevalue
-- @return #boolean

---
-- Function WriteQuaternion
--
-- @function [parent=#Serializer] WriteQuaternion
-- @param Quaternion#Quaternion valuevalue
-- @return #boolean

---
-- Function WritePackedQuaternion
--
-- @function [parent=#Serializer] WritePackedQuaternion
-- @param Quaternion#Quaternion valuevalue
-- @return #boolean

---
-- Function WriteColor
--
-- @function [parent=#Serializer] WriteColor
-- @param Color#Color valuevalue
-- @return #boolean

---
-- Function WriteBoundingBox
--
-- @function [parent=#Serializer] WriteBoundingBox
-- @param BoundingBox#BoundingBox valuevalue
-- @return #boolean

---
-- Function WriteString
--
-- @function [parent=#Serializer] WriteString
-- @param #string valuevalue
-- @return #boolean

---
-- Function WriteFileID
--
-- @function [parent=#Serializer] WriteFileID
-- @param #string valuevalue
-- @return #boolean

---
-- Function WriteStringHash
--
-- @function [parent=#Serializer] WriteStringHash
-- @param StringHash#StringHash valuevalue
-- @return #boolean

---
-- Function WriteShortStringHash
--
-- @function [parent=#Serializer] WriteShortStringHash
-- @param ShortStringHash#ShortStringHash valuevalue
-- @return #boolean

---
-- Function WriteBuffer
--
-- @function [parent=#Serializer] WriteBuffer
-- @param VectorBuffer#VectorBuffer bufferbuffer
-- @return #boolean

---
-- Function WriteResourceRef
--
-- @function [parent=#Serializer] WriteResourceRef
-- @param ResourceRef#ResourceRef valuevalue
-- @return #boolean

---
-- Function WriteResourceRefList
--
-- @function [parent=#Serializer] WriteResourceRefList
-- @param ResourceRefList#ResourceRefList valuevalue
-- @return #boolean

---
-- Function WriteVariant
--
-- @function [parent=#Serializer] WriteVariant
-- @param Variant#Variant valuevalue
-- @return #boolean

---
-- Function WriteVariantData
--
-- @function [parent=#Serializer] WriteVariantData
-- @param Variant#Variant valuevalue
-- @return #boolean

---
-- Function WriteVariantVector
--
-- @function [parent=#Serializer] WriteVariantVector
-- @param VariantVector#VariantVector valuevalue
-- @return #boolean

---
-- Function WriteVariantMap
--
-- @function [parent=#Serializer] WriteVariantMap
-- @param VariantMap#VariantMap valuevalue
-- @return #boolean

---
-- Function WriteVLE
--
-- @function [parent=#Serializer] WriteVLE
-- @param #number valuevalue
-- @return #boolean

---
-- Function WriteNetID
--
-- @function [parent=#Serializer] WriteNetID
-- @param #number valuevalue
-- @return #boolean

---
-- Function WriteLine
--
-- @function [parent=#Serializer] WriteLine
-- @param #string valuevalue
-- @return #boolean


return nil
