---
-- Module Serializer
-- Generated on 2014-03-13
--
-- @module Serializer

---
-- Function Write
--
-- @function [parent=#Serializer] Write
-- @param self Self reference
-- @param VectorBuffer#VectorBuffer buffer buffer
-- @return #number

---
-- Function WriteInt
--
-- @function [parent=#Serializer] WriteInt
-- @param self Self reference
-- @param #number value value
-- @return #boolean

---
-- Function WriteShort
--
-- @function [parent=#Serializer] WriteShort
-- @param self Self reference
-- @param short#short value value
-- @return #boolean

---
-- Function WriteByte
--
-- @function [parent=#Serializer] WriteByte
-- @param self Self reference
-- @param #string value value
-- @return #boolean

---
-- Function WriteUInt
--
-- @function [parent=#Serializer] WriteUInt
-- @param self Self reference
-- @param #number value value
-- @return #boolean

---
-- Function WriteUShort
--
-- @function [parent=#Serializer] WriteUShort
-- @param self Self reference
-- @param short#short value value
-- @return #boolean

---
-- Function WriteUByte
--
-- @function [parent=#Serializer] WriteUByte
-- @param self Self reference
-- @param #string value value
-- @return #boolean

---
-- Function WriteBool
--
-- @function [parent=#Serializer] WriteBool
-- @param self Self reference
-- @param #boolean value value
-- @return #boolean

---
-- Function WriteFloat
--
-- @function [parent=#Serializer] WriteFloat
-- @param self Self reference
-- @param #number value value
-- @return #boolean

---
-- Function WriteIntRect
--
-- @function [parent=#Serializer] WriteIntRect
-- @param self Self reference
-- @param IntRect#IntRect value value
-- @return #boolean

---
-- Function WriteIntVector2
--
-- @function [parent=#Serializer] WriteIntVector2
-- @param self Self reference
-- @param IntVector2#IntVector2 value value
-- @return #boolean

---
-- Function WriteRect
--
-- @function [parent=#Serializer] WriteRect
-- @param self Self reference
-- @param Rect#Rect value value
-- @return #boolean

---
-- Function WriteVector2
--
-- @function [parent=#Serializer] WriteVector2
-- @param self Self reference
-- @param Vector2#Vector2 value value
-- @return #boolean

---
-- Function WriteVector3
--
-- @function [parent=#Serializer] WriteVector3
-- @param self Self reference
-- @param Vector3#Vector3 value value
-- @return #boolean

---
-- Function WritePackedVector3
--
-- @function [parent=#Serializer] WritePackedVector3
-- @param self Self reference
-- @param Vector3#Vector3 value value
-- @param #number maxAbsCoord maxAbsCoord
-- @return #boolean

---
-- Function WriteVector4
--
-- @function [parent=#Serializer] WriteVector4
-- @param self Self reference
-- @param Vector4#Vector4 value value
-- @return #boolean

---
-- Function WriteQuaternion
--
-- @function [parent=#Serializer] WriteQuaternion
-- @param self Self reference
-- @param Quaternion#Quaternion value value
-- @return #boolean

---
-- Function WritePackedQuaternion
--
-- @function [parent=#Serializer] WritePackedQuaternion
-- @param self Self reference
-- @param Quaternion#Quaternion value value
-- @return #boolean

---
-- Function WriteColor
--
-- @function [parent=#Serializer] WriteColor
-- @param self Self reference
-- @param Color#Color value value
-- @return #boolean

---
-- Function WriteBoundingBox
--
-- @function [parent=#Serializer] WriteBoundingBox
-- @param self Self reference
-- @param BoundingBox#BoundingBox value value
-- @return #boolean

---
-- Function WriteString
--
-- @function [parent=#Serializer] WriteString
-- @param self Self reference
-- @param #string value value
-- @return #boolean

---
-- Function WriteFileID
--
-- @function [parent=#Serializer] WriteFileID
-- @param self Self reference
-- @param #string value value
-- @return #boolean

---
-- Function WriteStringHash
--
-- @function [parent=#Serializer] WriteStringHash
-- @param self Self reference
-- @param StringHash#StringHash value value
-- @return #boolean

---
-- Function WriteShortStringHash
--
-- @function [parent=#Serializer] WriteShortStringHash
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash value value
-- @return #boolean

---
-- Function WriteBuffer
--
-- @function [parent=#Serializer] WriteBuffer
-- @param self Self reference
-- @param VectorBuffer#VectorBuffer buffer buffer
-- @return #boolean

---
-- Function WriteResourceRef
--
-- @function [parent=#Serializer] WriteResourceRef
-- @param self Self reference
-- @param ResourceRef#ResourceRef value value
-- @return #boolean

---
-- Function WriteResourceRefList
--
-- @function [parent=#Serializer] WriteResourceRefList
-- @param self Self reference
-- @param ResourceRefList#ResourceRefList value value
-- @return #boolean

---
-- Function WriteVariant
--
-- @function [parent=#Serializer] WriteVariant
-- @param self Self reference
-- @param Variant#Variant value value
-- @return #boolean

---
-- Function WriteVariantData
--
-- @function [parent=#Serializer] WriteVariantData
-- @param self Self reference
-- @param Variant#Variant value value
-- @return #boolean

---
-- Function WriteVariantVector
--
-- @function [parent=#Serializer] WriteVariantVector
-- @param self Self reference
-- @param VariantVector#VariantVector value value
-- @return #boolean

---
-- Function WriteVariantMap
--
-- @function [parent=#Serializer] WriteVariantMap
-- @param self Self reference
-- @param VariantMap#VariantMap value value
-- @return #boolean

---
-- Function WriteVLE
--
-- @function [parent=#Serializer] WriteVLE
-- @param self Self reference
-- @param #number value value
-- @return #boolean

---
-- Function WriteNetID
--
-- @function [parent=#Serializer] WriteNetID
-- @param self Self reference
-- @param #number value value
-- @return #boolean

---
-- Function WriteLine
--
-- @function [parent=#Serializer] WriteLine
-- @param self Self reference
-- @param #string value value
-- @return #boolean


return nil
