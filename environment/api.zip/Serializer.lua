---
-- Module Serializer
-- Generated on 2014-05-31
--
-- @module Serializer

---
-- Function Write()
--
-- @function [parent=#Serializer] Write
-- @param self Self reference
-- @param VectorBuffer#VectorBuffer buffer buffer
-- @return #number

---
-- Function WriteInt()
-- Write a 32-bit integer.
--
-- @function [parent=#Serializer] WriteInt
-- @param self Self reference
-- @param #number value value
-- @return #boolean

---
-- Function WriteShort()
-- Write a 16-bit integer.
--
-- @function [parent=#Serializer] WriteShort
-- @param self Self reference
-- @param short#short value value
-- @return #boolean

---
-- Function WriteByte()
--
-- @function [parent=#Serializer] WriteByte
-- @param self Self reference
-- @param #string value value
-- @return #boolean

---
-- Function WriteUInt()
-- Write a 32-bit unsigned integer.
--
-- @function [parent=#Serializer] WriteUInt
-- @param self Self reference
-- @param #number value value
-- @return #boolean

---
-- Function WriteUShort()
--
-- @function [parent=#Serializer] WriteUShort
-- @param self Self reference
-- @param short#short value value
-- @return #boolean

---
-- Function WriteUByte()
--
-- @function [parent=#Serializer] WriteUByte
-- @param self Self reference
-- @param #string value value
-- @return #boolean

---
-- Function WriteBool()
-- Write a bool.
--
-- @function [parent=#Serializer] WriteBool
-- @param self Self reference
-- @param #boolean value value
-- @return #boolean

---
-- Function WriteFloat()
-- Write a float.
--
-- @function [parent=#Serializer] WriteFloat
-- @param self Self reference
-- @param #number value value
-- @return #boolean

---
-- Function WriteIntRect()
-- Write an IntRect.
--
-- @function [parent=#Serializer] WriteIntRect
-- @param self Self reference
-- @param IntRect#IntRect value value
-- @return #boolean

---
-- Function WriteIntVector2()
-- Write an IntVector2.
--
-- @function [parent=#Serializer] WriteIntVector2
-- @param self Self reference
-- @param IntVector2#IntVector2 value value
-- @return #boolean

---
-- Function WriteRect()
-- Write a Rect.
--
-- @function [parent=#Serializer] WriteRect
-- @param self Self reference
-- @param Rect#Rect value value
-- @return #boolean

---
-- Function WriteVector2()
-- Write a Vector2.
--
-- @function [parent=#Serializer] WriteVector2
-- @param self Self reference
-- @param Vector2#Vector2 value value
-- @return #boolean

---
-- Function WriteVector3()
-- Write a Vector3.
--
-- @function [parent=#Serializer] WriteVector3
-- @param self Self reference
-- @param Vector3#Vector3 value value
-- @return #boolean

---
-- Function WritePackedVector3()
-- Write a Vector3 packed into 3 x 16 bits with the specified maximum absolute range.
--
-- @function [parent=#Serializer] WritePackedVector3
-- @param self Self reference
-- @param Vector3#Vector3 value value
-- @param #number maxAbsCoord maxAbsCoord
-- @return #boolean

---
-- Function WriteVector4()
-- Write a Vector4.
--
-- @function [parent=#Serializer] WriteVector4
-- @param self Self reference
-- @param Vector4#Vector4 value value
-- @return #boolean

---
-- Function WriteQuaternion()
-- Write a quaternion.
--
-- @function [parent=#Serializer] WriteQuaternion
-- @param self Self reference
-- @param Quaternion#Quaternion value value
-- @return #boolean

---
-- Function WritePackedQuaternion()
-- Write a quaternion with each component packed in 16 bits.
--
-- @function [parent=#Serializer] WritePackedQuaternion
-- @param self Self reference
-- @param Quaternion#Quaternion value value
-- @return #boolean

---
-- Function WriteMatrix3()
-- Write a Matrix3.
--
-- @function [parent=#Serializer] WriteMatrix3
-- @param self Self reference
-- @param Matrix3#Matrix3 value value
-- @return #boolean

---
-- Function WriteMatrix3x4()
-- Write a Matrix3x4.
--
-- @function [parent=#Serializer] WriteMatrix3x4
-- @param self Self reference
-- @param Matrix3x4#Matrix3x4 value value
-- @return #boolean

---
-- Function WriteMatrix4()
-- Write a Matrix4.
--
-- @function [parent=#Serializer] WriteMatrix4
-- @param self Self reference
-- @param Matrix4#Matrix4 value value
-- @return #boolean

---
-- Function WriteColor()
-- Write a color.
--
-- @function [parent=#Serializer] WriteColor
-- @param self Self reference
-- @param Color#Color value value
-- @return #boolean

---
-- Function WriteBoundingBox()
-- Write a bounding box.
--
-- @function [parent=#Serializer] WriteBoundingBox
-- @param self Self reference
-- @param BoundingBox#BoundingBox value value
-- @return #boolean

---
-- Function WriteString()
-- Write a null-terminated string.
--
-- @function [parent=#Serializer] WriteString
-- @param self Self reference
-- @param #string value value
-- @return #boolean

---
-- Function WriteFileID()
-- Write a four-letter file ID. If the string is not long enough, spaces will be appended.
--
-- @function [parent=#Serializer] WriteFileID
-- @param self Self reference
-- @param #string value value
-- @return #boolean

---
-- Function WriteStringHash()
-- Write a 32-bit StringHash.
--
-- @function [parent=#Serializer] WriteStringHash
-- @param self Self reference
-- @param StringHash#StringHash value value
-- @return #boolean

---
-- Function WriteShortStringHash()
-- Write a 16-bit ShortStringHash.
--
-- @function [parent=#Serializer] WriteShortStringHash
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash value value
-- @return #boolean

---
-- Function WriteBuffer()
--
-- @function [parent=#Serializer] WriteBuffer
-- @param self Self reference
-- @param VectorBuffer#VectorBuffer buffer buffer
-- @return #boolean

---
-- Function WriteResourceRef()
-- Write a resource reference.
--
-- @function [parent=#Serializer] WriteResourceRef
-- @param self Self reference
-- @param ResourceRef#ResourceRef value value
-- @return #boolean

---
-- Function WriteResourceRefList()
-- Write a resource reference list.
--
-- @function [parent=#Serializer] WriteResourceRefList
-- @param self Self reference
-- @param ResourceRefList#ResourceRefList value value
-- @return #boolean

---
-- Function WriteVariant()
-- Write a variant.
--
-- @function [parent=#Serializer] WriteVariant
-- @param self Self reference
-- @param Variant#Variant value value
-- @return #boolean

---
-- Function WriteVariantData()
-- Write a variant without the type information.
--
-- @function [parent=#Serializer] WriteVariantData
-- @param self Self reference
-- @param Variant#Variant value value
-- @return #boolean

---
-- Function WriteVariantVector()
-- Write a variant vector.
--
-- @function [parent=#Serializer] WriteVariantVector
-- @param self Self reference
-- @param VariantVector#VariantVector value value
-- @return #boolean

---
-- Function WriteVariantMap()
-- Write a variant map.
--
-- @function [parent=#Serializer] WriteVariantMap
-- @param self Self reference
-- @param VariantMap#VariantMap value value
-- @return #boolean

---
-- Function WriteVLE()
-- Write a variable-length encoded unsigned integer, which can use 29 bits maximum.
--
-- @function [parent=#Serializer] WriteVLE
-- @param self Self reference
-- @param #number value value
-- @return #boolean

---
-- Function WriteNetID()
-- Write a 24-bit network object ID.
--
-- @function [parent=#Serializer] WriteNetID
-- @param self Self reference
-- @param #number value value
-- @return #boolean

---
-- Function WriteLine()
-- Write a text line. Char codes 13 & 10 will be automatically appended.
--
-- @function [parent=#Serializer] WriteLine
-- @param self Self reference
-- @param #string value value
-- @return #boolean


return nil
