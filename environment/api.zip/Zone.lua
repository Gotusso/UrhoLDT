---
-- Module Zone
-- extends Drawable
--
-- @module Zone

---
-- Function SetBoundingBox
--
-- @function [parent=#Zone] SetBoundingBox
-- @param BoundingBox#BoundingBox boxbox

---
-- Function SetAmbientColor
--
-- @function [parent=#Zone] SetAmbientColor
-- @param Color#Color colorcolor

---
-- Function SetFogColor
--
-- @function [parent=#Zone] SetFogColor
-- @param Color#Color colorcolor

---
-- Function SetFogStart
--
-- @function [parent=#Zone] SetFogStart
-- @param #number startstart

---
-- Function SetFogEnd
--
-- @function [parent=#Zone] SetFogEnd
-- @param #number endend

---
-- Function SetFogHeight
--
-- @function [parent=#Zone] SetFogHeight
-- @param #number heightheight

---
-- Function SetFogHeightScale
--
-- @function [parent=#Zone] SetFogHeightScale
-- @param #number scalescale

---
-- Function SetPriority
--
-- @function [parent=#Zone] SetPriority
-- @param #number prioritypriority

---
-- Function SetHeightFog
--
-- @function [parent=#Zone] SetHeightFog
-- @param #boolean enableenable

---
-- Function SetOverride
--
-- @function [parent=#Zone] SetOverride
-- @param #boolean enableenable

---
-- Function SetAmbientGradient
--
-- @function [parent=#Zone] SetAmbientGradient
-- @param #boolean enableenable

---
-- Function GetInverseWorldTransform
--
-- @function [parent=#Zone] GetInverseWorldTransform
-- @return const Matrix3x4#const Matrix3x4

---
-- Function GetAmbientColor
--
-- @function [parent=#Zone] GetAmbientColor
-- @return const Color#const Color

---
-- Function GetAmbientStartColor
--
-- @function [parent=#Zone] GetAmbientStartColor
-- @return const Color#const Color

---
-- Function GetAmbientEndColor
--
-- @function [parent=#Zone] GetAmbientEndColor
-- @return const Color#const Color

---
-- Function GetFogColor
--
-- @function [parent=#Zone] GetFogColor
-- @return const Color#const Color

---
-- Function GetFogStart
--
-- @function [parent=#Zone] GetFogStart
-- @return #number

---
-- Function GetFogEnd
--
-- @function [parent=#Zone] GetFogEnd
-- @return #number

---
-- Function GetFogHeight
--
-- @function [parent=#Zone] GetFogHeight
-- @return #number

---
-- Function GetFogHeightScale
--
-- @function [parent=#Zone] GetFogHeightScale
-- @return #number

---
-- Function GetPriority
--
-- @function [parent=#Zone] GetPriority
-- @return #number

---
-- Function GetHeightFog
--
-- @function [parent=#Zone] GetHeightFog
-- @return #boolean

---
-- Function GetOverride
--
-- @function [parent=#Zone] GetOverride
-- @return #boolean

---
-- Function GetAmbientGradient
--
-- @function [parent=#Zone] GetAmbientGradient
-- @return #boolean

---
-- Function IsInside
--
-- @function [parent=#Zone] IsInside
-- @param Vector3#Vector3 pointpoint
-- @return #boolean

---
-- Field boundingBox
--
-- @field [parent=#Zone] BoundingBox#BoundingBox boundingBox

---
-- Field inverseWorldTransform (Read only)
--
-- @field [parent=#Zone] Matrix3x4#Matrix3x4 inverseWorldTransform

---
-- Field ambientColor
--
-- @field [parent=#Zone] Color#Color ambientColor

---
-- Field ambientStartColor (Read only)
--
-- @field [parent=#Zone] Color#Color ambientStartColor

---
-- Field ambientEndColor (Read only)
--
-- @field [parent=#Zone] Color#Color ambientEndColor

---
-- Field fogColor
--
-- @field [parent=#Zone] Color#Color fogColor

---
-- Field fogStart
--
-- @field [parent=#Zone] #number fogStart

---
-- Field fogEnd
--
-- @field [parent=#Zone] #number fogEnd

---
-- Field fogHeight
--
-- @field [parent=#Zone] #number fogHeight

---
-- Field fogHeightScale
--
-- @field [parent=#Zone] #number fogHeightScale

---
-- Field priority
--
-- @field [parent=#Zone] #number priority

---
-- Field heightFog
--
-- @field [parent=#Zone] #boolean heightFog

---
-- Field override
--
-- @field [parent=#Zone] #boolean override

---
-- Field ambientGradient
--
-- @field [parent=#Zone] #boolean ambientGradient

---
-- Function SetDrawDistance
--
-- @function [parent=#Zone] SetDrawDistance
-- @param #number distancedistance

---
-- Function SetShadowDistance
--
-- @function [parent=#Zone] SetShadowDistance
-- @param #number distancedistance

---
-- Function SetLodBias
--
-- @function [parent=#Zone] SetLodBias
-- @param #number biasbias

---
-- Function SetViewMask
--
-- @function [parent=#Zone] SetViewMask
-- @param #number maskmask

---
-- Function SetLightMask
--
-- @function [parent=#Zone] SetLightMask
-- @param #number maskmask

---
-- Function SetShadowMask
--
-- @function [parent=#Zone] SetShadowMask
-- @param #number maskmask

---
-- Function SetZoneMask
--
-- @function [parent=#Zone] SetZoneMask
-- @param #number maskmask

---
-- Function SetMaxLights
--
-- @function [parent=#Zone] SetMaxLights
-- @param #number numnum

---
-- Function SetCastShadows
--
-- @function [parent=#Zone] SetCastShadows
-- @param #boolean enableenable

---
-- Function SetOccluder
--
-- @function [parent=#Zone] SetOccluder
-- @param #boolean enableenable

---
-- Function SetOccludee
--
-- @function [parent=#Zone] SetOccludee
-- @param #boolean enableenable

---
-- Function MarkForUpdate
--
-- @function [parent=#Zone] MarkForUpdate

---
-- Function GetBoundingBox
--
-- @function [parent=#Zone] GetBoundingBox
-- @return const BoundingBox#const BoundingBox

---
-- Function GetWorldBoundingBox
--
-- @function [parent=#Zone] GetWorldBoundingBox
-- @return const BoundingBox#const BoundingBox

---
-- Function GetDrawableFlags
--
-- @function [parent=#Zone] GetDrawableFlags
-- @return #string

---
-- Function GetDrawDistance
--
-- @function [parent=#Zone] GetDrawDistance
-- @return #number

---
-- Function GetShadowDistance
--
-- @function [parent=#Zone] GetShadowDistance
-- @return #number

---
-- Function GetLodBias
--
-- @function [parent=#Zone] GetLodBias
-- @return #number

---
-- Function GetViewMask
--
-- @function [parent=#Zone] GetViewMask
-- @return #number

---
-- Function GetLightMask
--
-- @function [parent=#Zone] GetLightMask
-- @return #number

---
-- Function GetShadowMask
--
-- @function [parent=#Zone] GetShadowMask
-- @return #number

---
-- Function GetZoneMask
--
-- @function [parent=#Zone] GetZoneMask
-- @return #number

---
-- Function GetMaxLights
--
-- @function [parent=#Zone] GetMaxLights
-- @return #number

---
-- Function GetCastShadows
--
-- @function [parent=#Zone] GetCastShadows
-- @return #boolean

---
-- Function IsOccluder
--
-- @function [parent=#Zone] IsOccluder
-- @return #boolean

---
-- Function IsOccludee
--
-- @function [parent=#Zone] IsOccludee
-- @return #boolean

---
-- Function SetZone
--
-- @function [parent=#Zone] SetZone
-- @param Zone#Zone zonezone
-- @param #boolean temporarytemporary

---
-- Function SetSortValue
--
-- @function [parent=#Zone] SetSortValue
-- @param #number valuevalue

---
-- Function SetMinMaxZ
--
-- @function [parent=#Zone] SetMinMaxZ
-- @param #number minZminZ
-- @param #number maxZmaxZ

---
-- Function MarkInView
--
-- @function [parent=#Zone] MarkInView
-- @param FrameInfo#FrameInfo frameframe
-- @param #boolean mainViewmainView

---
-- Function ClearLights
--
-- @function [parent=#Zone] ClearLights

---
-- Function AddLight
--
-- @function [parent=#Zone] AddLight
-- @param Light#Light lightlight

---
-- Function AddVertexLight
--
-- @function [parent=#Zone] AddVertexLight
-- @param Light#Light lightlight

---
-- Function LimitLights
--
-- @function [parent=#Zone] LimitLights

---
-- Function LimitVertexLights
--
-- @function [parent=#Zone] LimitVertexLights

---
-- Function SetBasePass
--
-- @function [parent=#Zone] SetBasePass
-- @param #number batchIndexbatchIndex

---
-- Function GetOctant
--
-- @function [parent=#Zone] GetOctant
-- @return Octant#Octant

---
-- Function GetZone
--
-- @function [parent=#Zone] GetZone
-- @return Zone#Zone

---
-- Function GetLastZone
--
-- @function [parent=#Zone] GetLastZone
-- @return Zone#Zone

---
-- Function IsZoneDirty
--
-- @function [parent=#Zone] IsZoneDirty
-- @return #boolean

---
-- Function GetDistance
--
-- @function [parent=#Zone] GetDistance
-- @return #number

---
-- Function GetLodDistance
--
-- @function [parent=#Zone] GetLodDistance
-- @return #number

---
-- Function GetSortValue
--
-- @function [parent=#Zone] GetSortValue
-- @return #number

---
-- Function IsInView
--
-- @function [parent=#Zone] IsInView
-- @param #number frameNumberframeNumber
-- @return #boolean

---
-- Function IsInView
--
-- @function [parent=#Zone] IsInView
-- @param FrameInfo#FrameInfo frameframe
-- @param #boolean mainViewmainView
-- @return #boolean

---
-- Function HasBasePass
--
-- @function [parent=#Zone] HasBasePass
-- @param #number batchIndexbatchIndex
-- @return #boolean

---
-- Function GetFirstLight
--
-- @function [parent=#Zone] GetFirstLight
-- @return Light#Light

---
-- Function GetMinZ
--
-- @function [parent=#Zone] GetMinZ
-- @return #number

---
-- Function GetMaxZ
--
-- @function [parent=#Zone] GetMaxZ
-- @return #number

---
-- Field worldBoundingBox (Read only)
--
-- @field [parent=#Zone] BoundingBox#BoundingBox worldBoundingBox

---
-- Field drawableFlags (Read only)
--
-- @field [parent=#Zone] #string drawableFlags

---
-- Field drawDistance
--
-- @field [parent=#Zone] #number drawDistance

---
-- Field shadowDistance
--
-- @field [parent=#Zone] #number shadowDistance

---
-- Field lodBias
--
-- @field [parent=#Zone] #number lodBias

---
-- Field viewMask
--
-- @field [parent=#Zone] #number viewMask

---
-- Field lightMask
--
-- @field [parent=#Zone] #number lightMask

---
-- Field shadowMask
--
-- @field [parent=#Zone] #number shadowMask

---
-- Field zoneMask
--
-- @field [parent=#Zone] #number zoneMask

---
-- Field maxLights
--
-- @field [parent=#Zone] #number maxLights

---
-- Field castShadows
--
-- @field [parent=#Zone] #boolean castShadows

---
-- Field occluder
--
-- @field [parent=#Zone] #boolean occluder

---
-- Field occludee
--
-- @field [parent=#Zone] #boolean occludee

---
-- Field octant (Read only)
--
-- @field [parent=#Zone] Octant#Octant octant

---
-- Field zone
--
-- @field [parent=#Zone] Zone#Zone zone

---
-- Field lastZone (Read only)
--
-- @field [parent=#Zone] Zone#Zone lastZone

---
-- Field zoneDirty (Read only)
--
-- @field [parent=#Zone] #boolean zoneDirty

---
-- Field distance (Read only)
--
-- @field [parent=#Zone] #number distance

---
-- Field lodDistance (Read only)
--
-- @field [parent=#Zone] #number lodDistance

---
-- Field sortValue
--
-- @field [parent=#Zone] #number sortValue

---
-- Field firstLight (Read only)
--
-- @field [parent=#Zone] Light#Light firstLight

---
-- Field minZ (Read only)
--
-- @field [parent=#Zone] #number minZ

---
-- Field maxZ (Read only)
--
-- @field [parent=#Zone] #number maxZ

---
-- Function SetEnabled
--
-- @function [parent=#Zone] SetEnabled
-- @param #boolean enableenable

---
-- Function Remove
--
-- @function [parent=#Zone] Remove

---
-- Function GetID
--
-- @function [parent=#Zone] GetID
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#Zone] GetNode
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#Zone] GetScene
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#Zone] IsEnabled
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#Zone] IsEnabledEffective
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#Zone] GetComponent
-- @param ShortStringHash#ShortStringHash typetype
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#Zone] GetComponent
-- @param #string typetype
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#Zone] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#Zone] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Zone] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Zone] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Zone] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Zone] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Zone] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Zone] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#Zone] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Zone] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Zone] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Zone] #string category


return nil
