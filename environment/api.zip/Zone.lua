---
-- Module Zone
-- Module Zone extends Drawable
-- Generated on 2014-05-31
--
-- @module Zone

---
-- Function SetBoundingBox()
-- Set local-space bounding box. Will be used as an oriented bounding box to test whether objects or the camera are inside.
--
-- @function [parent=#Zone] SetBoundingBox
-- @param self Self reference
-- @param BoundingBox#BoundingBox box box

---
-- Function SetAmbientColor()
-- Set ambient color
--
-- @function [parent=#Zone] SetAmbientColor
-- @param self Self reference
-- @param Color#Color color color

---
-- Function SetFogColor()
-- Set fog color.
--
-- @function [parent=#Zone] SetFogColor
-- @param self Self reference
-- @param Color#Color color color

---
-- Function SetFogStart()
-- Set fog start distance.
--
-- @function [parent=#Zone] SetFogStart
-- @param self Self reference
-- @param #number start start

---
-- Function SetFogEnd()
-- Set fog end distance.
--
-- @function [parent=#Zone] SetFogEnd
-- @param self Self reference
-- @param #number end end

---
-- Function SetFogHeight()
-- Set fog height distance relative to the scene node's world position. Effective only in height fog mode.
--
-- @function [parent=#Zone] SetFogHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetFogHeightScale()
-- Set fog height scale. Effective only in height fog mode.
--
-- @function [parent=#Zone] SetFogHeightScale
-- @param self Self reference
-- @param #number scale scale

---
-- Function SetPriority()
-- Set zone priority. If an object or camera is inside several zones, the one with highest priority is used.
--
-- @function [parent=#Zone] SetPriority
-- @param self Self reference
-- @param #number priority priority

---
-- Function SetHeightFog()
-- Set height fog mode.
--
-- @function [parent=#Zone] SetHeightFog
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetOverride()
-- Set override mode. If camera is inside an override zone, it will also be used for all drawables.
--
-- @function [parent=#Zone] SetOverride
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetAmbientGradient()
-- Set ambient gradient mode. In gradient mode ambient color is interpolated from neighbor zones.
--
-- @function [parent=#Zone] SetAmbientGradient
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function GetInverseWorldTransform()
-- Return inverse world transform.
--
-- @function [parent=#Zone] GetInverseWorldTransform
-- @param self Self reference
-- @return const Matrix3x4#const Matrix3x4

---
-- Function GetAmbientColor()
-- Return zone's own ambient color, disregarding gradient mode.
--
-- @function [parent=#Zone] GetAmbientColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetAmbientStartColor()
-- Return ambient start color. Not safe to call from worker threads due to possible octree query.
--
-- @function [parent=#Zone] GetAmbientStartColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetAmbientEndColor()
-- Return ambient end color. Not safe to call from worker threads due to possible octree query.
--
-- @function [parent=#Zone] GetAmbientEndColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetFogColor()
-- Return fog color.
--
-- @function [parent=#Zone] GetFogColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetFogStart()
-- Return fog start distance.
--
-- @function [parent=#Zone] GetFogStart
-- @param self Self reference
-- @return #number

---
-- Function GetFogEnd()
-- Return fog end distance.
--
-- @function [parent=#Zone] GetFogEnd
-- @param self Self reference
-- @return #number

---
-- Function GetFogHeight()
-- Return fog height distance relative to the scene node's world position.
--
-- @function [parent=#Zone] GetFogHeight
-- @param self Self reference
-- @return #number

---
-- Function GetFogHeightScale()
-- Return fog height scale.
--
-- @function [parent=#Zone] GetFogHeightScale
-- @param self Self reference
-- @return #number

---
-- Function GetPriority()
-- Return zone priority.
--
-- @function [parent=#Zone] GetPriority
-- @param self Self reference
-- @return #number

---
-- Function GetHeightFog()
-- Return whether height fog mode is enabled.
--
-- @function [parent=#Zone] GetHeightFog
-- @param self Self reference
-- @return #boolean

---
-- Function GetOverride()
-- Return whether override mode is enabled.
--
-- @function [parent=#Zone] GetOverride
-- @param self Self reference
-- @return #boolean

---
-- Function GetAmbientGradient()
-- Return whether ambient gradient mode is enabled.
--
-- @function [parent=#Zone] GetAmbientGradient
-- @param self Self reference
-- @return #boolean

---
-- Function IsInside()
-- Check whether a point is inside.
--
-- @function [parent=#Zone] IsInside
-- @param self Self reference
-- @param Vector3#Vector3 point point
-- @return #boolean

---
-- Field boundingBox
--
-- @field [parent=#Zone] BoundingBox#BoundingBox boundingBox

---
-- Field inverseWorldTransform (Read only)
--
-- @field [parent=#Zone] Matrix3x4#Matrix3x4 inverseWorldTransform

---
-- Field ambientColor
--
-- @field [parent=#Zone] Color#Color ambientColor

---
-- Field ambientStartColor (Read only)
--
-- @field [parent=#Zone] Color#Color ambientStartColor

---
-- Field ambientEndColor (Read only)
--
-- @field [parent=#Zone] Color#Color ambientEndColor

---
-- Field fogColor
--
-- @field [parent=#Zone] Color#Color fogColor

---
-- Field fogStart
--
-- @field [parent=#Zone] #number fogStart

---
-- Field fogEnd
--
-- @field [parent=#Zone] #number fogEnd

---
-- Field fogHeight
--
-- @field [parent=#Zone] #number fogHeight

---
-- Field fogHeightScale
--
-- @field [parent=#Zone] #number fogHeightScale

---
-- Field priority
--
-- @field [parent=#Zone] #number priority

---
-- Field heightFog
--
-- @field [parent=#Zone] #boolean heightFog

---
-- Field override
--
-- @field [parent=#Zone] #boolean override

---
-- Field ambientGradient
--
-- @field [parent=#Zone] #boolean ambientGradient


return nil
