---
-- Module Zone
-- Extends Drawable
--
-- @module Zone

---
-- Function SetBoundingBox
--
-- @function [parent=#Zone] SetBoundingBox
-- @param BoundingBox#BoundingBox boxbox

---
-- Function SetAmbientColor
--
-- @function [parent=#Zone] SetAmbientColor
-- @param Color#Color colorcolor

---
-- Function SetFogColor
--
-- @function [parent=#Zone] SetFogColor
-- @param Color#Color colorcolor

---
-- Function SetFogStart
--
-- @function [parent=#Zone] SetFogStart
-- @param #number startstart

---
-- Function SetFogEnd
--
-- @function [parent=#Zone] SetFogEnd
-- @param #number endend

---
-- Function SetFogHeight
--
-- @function [parent=#Zone] SetFogHeight
-- @param #number heightheight

---
-- Function SetFogHeightScale
--
-- @function [parent=#Zone] SetFogHeightScale
-- @param #number scalescale

---
-- Function SetPriority
--
-- @function [parent=#Zone] SetPriority
-- @param #number prioritypriority

---
-- Function SetHeightFog
--
-- @function [parent=#Zone] SetHeightFog
-- @param #boolean enableenable

---
-- Function SetOverride
--
-- @function [parent=#Zone] SetOverride
-- @param #boolean enableenable

---
-- Function SetAmbientGradient
--
-- @function [parent=#Zone] SetAmbientGradient
-- @param #boolean enableenable

---
-- Function GetInverseWorldTransform
--
-- @function [parent=#Zone] GetInverseWorldTransform
-- @return const Matrix3x4#const Matrix3x4

---
-- Function GetAmbientColor
--
-- @function [parent=#Zone] GetAmbientColor
-- @return const Color#const Color

---
-- Function GetAmbientStartColor
--
-- @function [parent=#Zone] GetAmbientStartColor
-- @return const Color#const Color

---
-- Function GetAmbientEndColor
--
-- @function [parent=#Zone] GetAmbientEndColor
-- @return const Color#const Color

---
-- Function GetFogColor
--
-- @function [parent=#Zone] GetFogColor
-- @return const Color#const Color

---
-- Function GetFogStart
--
-- @function [parent=#Zone] GetFogStart
-- @return #number

---
-- Function GetFogEnd
--
-- @function [parent=#Zone] GetFogEnd
-- @return #number

---
-- Function GetFogHeight
--
-- @function [parent=#Zone] GetFogHeight
-- @return #number

---
-- Function GetFogHeightScale
--
-- @function [parent=#Zone] GetFogHeightScale
-- @return #number

---
-- Function GetPriority
--
-- @function [parent=#Zone] GetPriority
-- @return #number

---
-- Function GetHeightFog
--
-- @function [parent=#Zone] GetHeightFog
-- @return #boolean

---
-- Function GetOverride
--
-- @function [parent=#Zone] GetOverride
-- @return #boolean

---
-- Function GetAmbientGradient
--
-- @function [parent=#Zone] GetAmbientGradient
-- @return #boolean

---
-- Function IsInside
--
-- @function [parent=#Zone] IsInside
-- @param Vector3#Vector3 pointpoint
-- @return #boolean

---
-- Field boundingBox
--
-- @field [parent=#Zone] BoundingBox#BoundingBox boundingBox

---
-- Field inverseWorldTransform (Read only)
--
-- @field [parent=#Zone] Matrix3x4#Matrix3x4 inverseWorldTransform

---
-- Field ambientColor
--
-- @field [parent=#Zone] Color#Color ambientColor

---
-- Field ambientStartColor (Read only)
--
-- @field [parent=#Zone] Color#Color ambientStartColor

---
-- Field ambientEndColor (Read only)
--
-- @field [parent=#Zone] Color#Color ambientEndColor

---
-- Field fogColor
--
-- @field [parent=#Zone] Color#Color fogColor

---
-- Field fogStart
--
-- @field [parent=#Zone] #number fogStart

---
-- Field fogEnd
--
-- @field [parent=#Zone] #number fogEnd

---
-- Field fogHeight
--
-- @field [parent=#Zone] #number fogHeight

---
-- Field fogHeightScale
--
-- @field [parent=#Zone] #number fogHeightScale

---
-- Field priority
--
-- @field [parent=#Zone] #number priority

---
-- Field heightFog
--
-- @field [parent=#Zone] #boolean heightFog

---
-- Field override
--
-- @field [parent=#Zone] #boolean override

---
-- Field ambientGradient
--
-- @field [parent=#Zone] #boolean ambientGradient


return nil
