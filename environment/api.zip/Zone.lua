---
-- Module Zone
-- Module Zone extends Drawable
-- Generated on 2014-03-13
--
-- @module Zone

---
-- Function SetBoundingBox
--
-- @function [parent=#Zone] SetBoundingBox
-- @param self Self reference
-- @param BoundingBox#BoundingBox box box

---
-- Function SetAmbientColor
--
-- @function [parent=#Zone] SetAmbientColor
-- @param self Self reference
-- @param Color#Color color color

---
-- Function SetFogColor
--
-- @function [parent=#Zone] SetFogColor
-- @param self Self reference
-- @param Color#Color color color

---
-- Function SetFogStart
--
-- @function [parent=#Zone] SetFogStart
-- @param self Self reference
-- @param #number start start

---
-- Function SetFogEnd
--
-- @function [parent=#Zone] SetFogEnd
-- @param self Self reference
-- @param #number end end

---
-- Function SetFogHeight
--
-- @function [parent=#Zone] SetFogHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetFogHeightScale
--
-- @function [parent=#Zone] SetFogHeightScale
-- @param self Self reference
-- @param #number scale scale

---
-- Function SetPriority
--
-- @function [parent=#Zone] SetPriority
-- @param self Self reference
-- @param #number priority priority

---
-- Function SetHeightFog
--
-- @function [parent=#Zone] SetHeightFog
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetOverride
--
-- @function [parent=#Zone] SetOverride
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetAmbientGradient
--
-- @function [parent=#Zone] SetAmbientGradient
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function GetInverseWorldTransform
--
-- @function [parent=#Zone] GetInverseWorldTransform
-- @param self Self reference
-- @return const Matrix3x4#const Matrix3x4

---
-- Function GetAmbientColor
--
-- @function [parent=#Zone] GetAmbientColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetAmbientStartColor
--
-- @function [parent=#Zone] GetAmbientStartColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetAmbientEndColor
--
-- @function [parent=#Zone] GetAmbientEndColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetFogColor
--
-- @function [parent=#Zone] GetFogColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetFogStart
--
-- @function [parent=#Zone] GetFogStart
-- @param self Self reference
-- @return #number

---
-- Function GetFogEnd
--
-- @function [parent=#Zone] GetFogEnd
-- @param self Self reference
-- @return #number

---
-- Function GetFogHeight
--
-- @function [parent=#Zone] GetFogHeight
-- @param self Self reference
-- @return #number

---
-- Function GetFogHeightScale
--
-- @function [parent=#Zone] GetFogHeightScale
-- @param self Self reference
-- @return #number

---
-- Function GetPriority
--
-- @function [parent=#Zone] GetPriority
-- @param self Self reference
-- @return #number

---
-- Function GetHeightFog
--
-- @function [parent=#Zone] GetHeightFog
-- @param self Self reference
-- @return #boolean

---
-- Function GetOverride
--
-- @function [parent=#Zone] GetOverride
-- @param self Self reference
-- @return #boolean

---
-- Function GetAmbientGradient
--
-- @function [parent=#Zone] GetAmbientGradient
-- @param self Self reference
-- @return #boolean

---
-- Function IsInside
--
-- @function [parent=#Zone] IsInside
-- @param self Self reference
-- @param Vector3#Vector3 point point
-- @return #boolean

---
-- Field boundingBox
--
-- @field [parent=#Zone] BoundingBox#BoundingBox boundingBox

---
-- Field inverseWorldTransform (Read only)
--
-- @field [parent=#Zone] Matrix3x4#Matrix3x4 inverseWorldTransform

---
-- Field ambientColor
--
-- @field [parent=#Zone] Color#Color ambientColor

---
-- Field ambientStartColor (Read only)
--
-- @field [parent=#Zone] Color#Color ambientStartColor

---
-- Field ambientEndColor (Read only)
--
-- @field [parent=#Zone] Color#Color ambientEndColor

---
-- Field fogColor
--
-- @field [parent=#Zone] Color#Color fogColor

---
-- Field fogStart
--
-- @field [parent=#Zone] #number fogStart

---
-- Field fogEnd
--
-- @field [parent=#Zone] #number fogEnd

---
-- Field fogHeight
--
-- @field [parent=#Zone] #number fogHeight

---
-- Field fogHeightScale
--
-- @field [parent=#Zone] #number fogHeightScale

---
-- Field priority
--
-- @field [parent=#Zone] #number priority

---
-- Field heightFog
--
-- @field [parent=#Zone] #boolean heightFog

---
-- Field override
--
-- @field [parent=#Zone] #boolean override

---
-- Field ambientGradient
--
-- @field [parent=#Zone] #boolean ambientGradient

---
-- Function SetDrawDistance
--
-- @function [parent=#Zone] SetDrawDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetShadowDistance
--
-- @function [parent=#Zone] SetShadowDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetLodBias
--
-- @function [parent=#Zone] SetLodBias
-- @param self Self reference
-- @param #number bias bias

---
-- Function SetViewMask
--
-- @function [parent=#Zone] SetViewMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetLightMask
--
-- @function [parent=#Zone] SetLightMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetShadowMask
--
-- @function [parent=#Zone] SetShadowMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetZoneMask
--
-- @function [parent=#Zone] SetZoneMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetMaxLights
--
-- @function [parent=#Zone] SetMaxLights
-- @param self Self reference
-- @param #number num num

---
-- Function SetCastShadows
--
-- @function [parent=#Zone] SetCastShadows
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetOccluder
--
-- @function [parent=#Zone] SetOccluder
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetOccludee
--
-- @function [parent=#Zone] SetOccludee
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function MarkForUpdate
--
-- @function [parent=#Zone] MarkForUpdate
-- @param self Self reference

---
-- Function GetBoundingBox
--
-- @function [parent=#Zone] GetBoundingBox
-- @param self Self reference
-- @return const BoundingBox#const BoundingBox

---
-- Function GetWorldBoundingBox
--
-- @function [parent=#Zone] GetWorldBoundingBox
-- @param self Self reference
-- @return const BoundingBox#const BoundingBox

---
-- Function GetDrawableFlags
--
-- @function [parent=#Zone] GetDrawableFlags
-- @param self Self reference
-- @return #string

---
-- Function GetDrawDistance
--
-- @function [parent=#Zone] GetDrawDistance
-- @param self Self reference
-- @return #number

---
-- Function GetShadowDistance
--
-- @function [parent=#Zone] GetShadowDistance
-- @param self Self reference
-- @return #number

---
-- Function GetLodBias
--
-- @function [parent=#Zone] GetLodBias
-- @param self Self reference
-- @return #number

---
-- Function GetViewMask
--
-- @function [parent=#Zone] GetViewMask
-- @param self Self reference
-- @return #number

---
-- Function GetLightMask
--
-- @function [parent=#Zone] GetLightMask
-- @param self Self reference
-- @return #number

---
-- Function GetShadowMask
--
-- @function [parent=#Zone] GetShadowMask
-- @param self Self reference
-- @return #number

---
-- Function GetZoneMask
--
-- @function [parent=#Zone] GetZoneMask
-- @param self Self reference
-- @return #number

---
-- Function GetMaxLights
--
-- @function [parent=#Zone] GetMaxLights
-- @param self Self reference
-- @return #number

---
-- Function GetCastShadows
--
-- @function [parent=#Zone] GetCastShadows
-- @param self Self reference
-- @return #boolean

---
-- Function IsOccluder
--
-- @function [parent=#Zone] IsOccluder
-- @param self Self reference
-- @return #boolean

---
-- Function IsOccludee
--
-- @function [parent=#Zone] IsOccludee
-- @param self Self reference
-- @return #boolean

---
-- Function SetZone
--
-- @function [parent=#Zone] SetZone
-- @param self Self reference
-- @param Zone#Zone zone zone
-- @param #boolean temporary temporary

---
-- Function SetSortValue
--
-- @function [parent=#Zone] SetSortValue
-- @param self Self reference
-- @param #number value value

---
-- Function SetMinMaxZ
--
-- @function [parent=#Zone] SetMinMaxZ
-- @param self Self reference
-- @param #number minZ minZ
-- @param #number maxZ maxZ

---
-- Function MarkInView
--
-- @function [parent=#Zone] MarkInView
-- @param self Self reference
-- @param FrameInfo#FrameInfo frame frame
-- @param #boolean mainView mainView

---
-- Function ClearLights
--
-- @function [parent=#Zone] ClearLights
-- @param self Self reference

---
-- Function AddLight
--
-- @function [parent=#Zone] AddLight
-- @param self Self reference
-- @param Light#Light light light

---
-- Function AddVertexLight
--
-- @function [parent=#Zone] AddVertexLight
-- @param self Self reference
-- @param Light#Light light light

---
-- Function LimitLights
--
-- @function [parent=#Zone] LimitLights
-- @param self Self reference

---
-- Function LimitVertexLights
--
-- @function [parent=#Zone] LimitVertexLights
-- @param self Self reference

---
-- Function SetBasePass
--
-- @function [parent=#Zone] SetBasePass
-- @param self Self reference
-- @param #number batchIndex batchIndex

---
-- Function GetOctant
--
-- @function [parent=#Zone] GetOctant
-- @param self Self reference
-- @return Octant#Octant

---
-- Function GetZone
--
-- @function [parent=#Zone] GetZone
-- @param self Self reference
-- @return Zone#Zone

---
-- Function GetLastZone
--
-- @function [parent=#Zone] GetLastZone
-- @param self Self reference
-- @return Zone#Zone

---
-- Function IsZoneDirty
--
-- @function [parent=#Zone] IsZoneDirty
-- @param self Self reference
-- @return #boolean

---
-- Function GetDistance
--
-- @function [parent=#Zone] GetDistance
-- @param self Self reference
-- @return #number

---
-- Function GetLodDistance
--
-- @function [parent=#Zone] GetLodDistance
-- @param self Self reference
-- @return #number

---
-- Function GetSortValue
--
-- @function [parent=#Zone] GetSortValue
-- @param self Self reference
-- @return #number

---
-- Function IsInView
--
-- @function [parent=#Zone] IsInView
-- @param self Self reference
-- @param #number frameNumber frameNumber
-- @return #boolean

---
-- Function IsInView
--
-- @function [parent=#Zone] IsInView
-- @param self Self reference
-- @param FrameInfo#FrameInfo frame frame
-- @param #boolean mainView mainView
-- @return #boolean

---
-- Function HasBasePass
--
-- @function [parent=#Zone] HasBasePass
-- @param self Self reference
-- @param #number batchIndex batchIndex
-- @return #boolean

---
-- Function GetFirstLight
--
-- @function [parent=#Zone] GetFirstLight
-- @param self Self reference
-- @return Light#Light

---
-- Function GetMinZ
--
-- @function [parent=#Zone] GetMinZ
-- @param self Self reference
-- @return #number

---
-- Function GetMaxZ
--
-- @function [parent=#Zone] GetMaxZ
-- @param self Self reference
-- @return #number

---
-- Field worldBoundingBox (Read only)
--
-- @field [parent=#Zone] BoundingBox#BoundingBox worldBoundingBox

---
-- Field drawableFlags (Read only)
--
-- @field [parent=#Zone] #string drawableFlags

---
-- Field drawDistance
--
-- @field [parent=#Zone] #number drawDistance

---
-- Field shadowDistance
--
-- @field [parent=#Zone] #number shadowDistance

---
-- Field lodBias
--
-- @field [parent=#Zone] #number lodBias

---
-- Field viewMask
--
-- @field [parent=#Zone] #number viewMask

---
-- Field lightMask
--
-- @field [parent=#Zone] #number lightMask

---
-- Field shadowMask
--
-- @field [parent=#Zone] #number shadowMask

---
-- Field zoneMask
--
-- @field [parent=#Zone] #number zoneMask

---
-- Field maxLights
--
-- @field [parent=#Zone] #number maxLights

---
-- Field castShadows
--
-- @field [parent=#Zone] #boolean castShadows

---
-- Field occluder
--
-- @field [parent=#Zone] #boolean occluder

---
-- Field occludee
--
-- @field [parent=#Zone] #boolean occludee

---
-- Field octant (Read only)
--
-- @field [parent=#Zone] Octant#Octant octant

---
-- Field zone
--
-- @field [parent=#Zone] Zone#Zone zone

---
-- Field lastZone (Read only)
--
-- @field [parent=#Zone] Zone#Zone lastZone

---
-- Field zoneDirty (Read only)
--
-- @field [parent=#Zone] #boolean zoneDirty

---
-- Field distance (Read only)
--
-- @field [parent=#Zone] #number distance

---
-- Field lodDistance (Read only)
--
-- @field [parent=#Zone] #number lodDistance

---
-- Field sortValue
--
-- @field [parent=#Zone] #number sortValue

---
-- Field firstLight (Read only)
--
-- @field [parent=#Zone] Light#Light firstLight

---
-- Field minZ (Read only)
--
-- @field [parent=#Zone] #number minZ

---
-- Field maxZ (Read only)
--
-- @field [parent=#Zone] #number maxZ

---
-- Function SetEnabled
--
-- @function [parent=#Zone] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Remove
--
-- @function [parent=#Zone] Remove
-- @param self Self reference

---
-- Function GetID
--
-- @function [parent=#Zone] GetID
-- @param self Self reference
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#Zone] GetNode
-- @param self Self reference
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#Zone] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#Zone] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#Zone] IsEnabledEffective
-- @param self Self reference
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#Zone] GetComponent
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#Zone] GetComponent
-- @param self Self reference
-- @param #string type type
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#Zone] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#Zone] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Zone] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Zone] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Zone] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Zone] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Zone] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Zone] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#Zone] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Zone] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Zone] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Zone] #string category


return nil
