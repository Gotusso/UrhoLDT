---
-- Module StringHash
--
-- @module StringHash

---
-- Function StringHash
--
-- @function [parent=#StringHash] StringHash

---
-- Function new
--
-- @function [parent=#StringHash] new
-- @return StringHash#StringHash

---
-- Function StringHash
--
-- @function [parent=#StringHash] StringHash
-- @param StringHash#StringHash rhsrhs

---
-- Function new
--
-- @function [parent=#StringHash] new
-- @param StringHash#StringHash rhsrhs
-- @return StringHash#StringHash

---
-- Function StringHash
--
-- @function [parent=#StringHash] StringHash
-- @param #number valuevalue

---
-- Function new
--
-- @function [parent=#StringHash] new
-- @param #number valuevalue
-- @return StringHash#StringHash

---
-- Function StringHash
--
-- @function [parent=#StringHash] StringHash
-- @param #string strstr

---
-- Function new
--
-- @function [parent=#StringHash] new
-- @param #string strstr
-- @return StringHash#StringHash

---
-- Function delete
--
-- @function [parent=#StringHash] delete

---
-- Function operator+
--
-- @function [parent=#StringHash] operator+
-- @param StringHash#StringHash rhsrhs
-- @return StringHash#StringHash

---
-- Function operator==
--
-- @function [parent=#StringHash] operator==
-- @param StringHash#StringHash rhsrhs
-- @return #boolean

---
-- Function operator<
--
-- @function [parent=#StringHash] operator<
-- @param StringHash#StringHash rhsrhs
-- @return #boolean

---
-- Function operatorbool
--
-- @function [parent=#StringHash] operatorbool
-- @return #boolean

---
-- Function Value
--
-- @function [parent=#StringHash] Value
-- @return #number

---
-- Function ToString
--
-- @function [parent=#StringHash] ToString
-- @return #string

---
-- Function ToHash
--
-- @function [parent=#StringHash] ToHash
-- @return #number

---
-- Function Calculate
--
-- @function [parent=#StringHash] Calculate
-- @param char*#char* strstr
-- @return #number

---
-- Field ZERO
--
-- @field [parent=#StringHash] StringHash#StringHash ZERO

---
-- Field value (Read only)
--
-- @field [parent=#StringHash] #number value


return nil
