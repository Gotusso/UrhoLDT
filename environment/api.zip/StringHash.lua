---
-- Module StringHash
-- Generated on 2014-05-31
--
-- @module StringHash

---
-- Function StringHash()
-- Construct with zero value.
--
-- @function [parent=#StringHash] StringHash
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#StringHash] new
-- @param self Self reference
-- @return StringHash#StringHash

---
-- Function StringHash()
--
-- @function [parent=#StringHash] StringHash
-- @param self Self reference
-- @param StringHash#StringHash rhs rhs

---
-- Function new()
--
-- @function [parent=#StringHash] new
-- @param self Self reference
-- @param StringHash#StringHash rhs rhs
-- @return StringHash#StringHash

---
-- Function StringHash()
--
-- @function [parent=#StringHash] StringHash
-- @param self Self reference
-- @param #number value value

---
-- Function new()
--
-- @function [parent=#StringHash] new
-- @param self Self reference
-- @param #number value value
-- @return StringHash#StringHash

---
-- Function StringHash()
--
-- @function [parent=#StringHash] StringHash
-- @param self Self reference
-- @param #string str str

---
-- Function new()
--
-- @function [parent=#StringHash] new
-- @param self Self reference
-- @param #string str str
-- @return StringHash#StringHash

---
-- Function delete()
--
-- @function [parent=#StringHash] delete
-- @param self Self reference

---
-- Function operator+()
--
-- @function [parent=#StringHash] operator+
-- @param self Self reference
-- @param StringHash#StringHash rhs rhs
-- @return StringHash#StringHash

---
-- Function operator==()
--
-- @function [parent=#StringHash] operator==
-- @param self Self reference
-- @param StringHash#StringHash rhs rhs
-- @return #boolean

---
-- Function operator<()
--
-- @function [parent=#StringHash] operator<
-- @param self Self reference
-- @param StringHash#StringHash rhs rhs
-- @return #boolean

---
-- Function operatorbool()
--
-- @function [parent=#StringHash] operatorbool
-- @param self Self reference
-- @return #boolean

---
-- Function Value()
--
-- @function [parent=#StringHash] Value
-- @param self Self reference
-- @return #number

---
-- Function ToString()
--
-- @function [parent=#StringHash] ToString
-- @param self Self reference
-- @return #string

---
-- Function ToHash()
--
-- @function [parent=#StringHash] ToHash
-- @param self Self reference
-- @return #number

---
-- Function Calculate()
--
-- @function [parent=#StringHash] Calculate
-- @param self Self reference
-- @param char*#char* str str
-- @return #number

---
-- Field ZERO
--
-- @field [parent=#StringHash] StringHash#StringHash ZERO

---
-- Field value (Read only)
--
-- @field [parent=#StringHash] #number value


return nil
