---
-- Enumeration ShapeType
--
-- @module ShapeType

---
-- Enumeration value SHAPE_BOX
--
-- @field [parent=#ShapeType] #number SHAPE_BOX

---
-- Enumeration value SHAPE_SPHERE
--
-- @field [parent=#ShapeType] #number SHAPE_SPHERE

---
-- Enumeration value SHAPE_STATICPLANE
--
-- @field [parent=#ShapeType] #number SHAPE_STATICPLANE

---
-- Enumeration value SHAPE_CYLINDER
--
-- @field [parent=#ShapeType] #number SHAPE_CYLINDER

---
-- Enumeration value SHAPE_CAPSULE
--
-- @field [parent=#ShapeType] #number SHAPE_CAPSULE

---
-- Enumeration value SHAPE_CONE
--
-- @field [parent=#ShapeType] #number SHAPE_CONE

---
-- Enumeration value SHAPE_TRIANGLEMESH
--
-- @field [parent=#ShapeType] #number SHAPE_TRIANGLEMESH

---
-- Enumeration value SHAPE_CONVEXHULL
--
-- @field [parent=#ShapeType] #number SHAPE_CONVEXHULL

---
-- Enumeration value SHAPE_TERRAIN
--
-- @field [parent=#ShapeType] #number SHAPE_TERRAIN


return nil
