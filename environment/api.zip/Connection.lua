---
-- Module Connection
-- Extends Object
--
-- @module Connection

---
-- Function SendMessage
--
-- @function [parent=#Connection] SendMessage
-- @param #number msgIDmsgID
-- @param #boolean reliablereliable
-- @param #boolean inOrderinOrder
-- @param VectorBuffer#VectorBuffer msgmsg
-- @param #number contentIDcontentID

---
-- Function SendRemoteEvent
--
-- @function [parent=#Connection] SendRemoteEvent
-- @param StringHash#StringHash eventTypeeventType
-- @param #boolean inOrderinOrder

---
-- Function SendRemoteEvent
--
-- @function [parent=#Connection] SendRemoteEvent
-- @param StringHash#StringHash eventTypeeventType
-- @param #boolean inOrderinOrder
-- @param VariantMap#VariantMap eventDataeventData

---
-- Function SendRemoteEvent
--
-- @function [parent=#Connection] SendRemoteEvent
-- @param #string eventTypeeventType
-- @param #boolean inOrderinOrder

---
-- Function SendRemoteEvent
--
-- @function [parent=#Connection] SendRemoteEvent
-- @param #string eventTypeeventType
-- @param #boolean inOrderinOrder
-- @param VariantMap#VariantMap eventDataeventData

---
-- Function SendRemoteEvent
--
-- @function [parent=#Connection] SendRemoteEvent
-- @param Node#Node nodenode
-- @param StringHash#StringHash eventTypeeventType
-- @param #boolean inOrderinOrder

---
-- Function SendRemoteEvent
--
-- @function [parent=#Connection] SendRemoteEvent
-- @param Node#Node nodenode
-- @param StringHash#StringHash eventTypeeventType
-- @param #boolean inOrderinOrder
-- @param VariantMap#VariantMap eventDataeventData

---
-- Function SendRemoteEvent
--
-- @function [parent=#Connection] SendRemoteEvent
-- @param Node#Node nodenode
-- @param #string eventTypeeventType
-- @param #boolean inOrderinOrder

---
-- Function SendRemoteEvent
--
-- @function [parent=#Connection] SendRemoteEvent
-- @param Node#Node nodenode
-- @param #string eventTypeeventType
-- @param #boolean inOrderinOrder
-- @param VariantMap#VariantMap eventDataeventData

---
-- Function SetScene
--
-- @function [parent=#Connection] SetScene
-- @param Scene#Scene newScenenewScene

---
-- Function SetIdentity
--
-- @function [parent=#Connection] SetIdentity
-- @param VariantMap#VariantMap identityidentity

---
-- Function SetControls
--
-- @function [parent=#Connection] SetControls
-- @param Controls#Controls newControlsnewControls

---
-- Function SetPosition
--
-- @function [parent=#Connection] SetPosition
-- @param Vector3#Vector3 positionposition

---
-- Function SetConnectPending
--
-- @function [parent=#Connection] SetConnectPending
-- @param #boolean connectPendingconnectPending

---
-- Function SetLogStatistics
--
-- @function [parent=#Connection] SetLogStatistics
-- @param #boolean enableenable

---
-- Function Disconnect
--
-- @function [parent=#Connection] Disconnect
-- @param #number waitMSecwaitMSec

---
-- Function SendServerUpdate
--
-- @function [parent=#Connection] SendServerUpdate

---
-- Function SendClientUpdate
--
-- @function [parent=#Connection] SendClientUpdate

---
-- Function SendRemoteEvents
--
-- @function [parent=#Connection] SendRemoteEvents

---
-- Function SendPackages
--
-- @function [parent=#Connection] SendPackages

---
-- Function ProcessPendingLatestData
--
-- @function [parent=#Connection] ProcessPendingLatestData

---
-- Function ProcessMessage
--
-- @function [parent=#Connection] ProcessMessage
-- @param #number msgIDmsgID
-- @param MemoryBuffer#MemoryBuffer msgmsg
-- @return #boolean

---
-- Function GetIdentity
--
-- @function [parent=#Connection] GetIdentity
-- @return const VariantMap#const VariantMap

---
-- Function GetScene
--
-- @function [parent=#Connection] GetScene
-- @return Scene#Scene

---
-- Function GetControls
--
-- @function [parent=#Connection] GetControls
-- @return const Controls#const Controls

---
-- Function GetPosition
--
-- @function [parent=#Connection] GetPosition
-- @return const Vector3#const Vector3

---
-- Function IsClient
--
-- @function [parent=#Connection] IsClient
-- @return #boolean

---
-- Function IsConnected
--
-- @function [parent=#Connection] IsConnected
-- @return #boolean

---
-- Function IsConnectPending
--
-- @function [parent=#Connection] IsConnectPending
-- @return #boolean

---
-- Function IsSceneLoaded
--
-- @function [parent=#Connection] IsSceneLoaded
-- @return #boolean

---
-- Function GetLogStatistics
--
-- @function [parent=#Connection] GetLogStatistics
-- @return #boolean

---
-- Function GetAddress
--
-- @function [parent=#Connection] GetAddress
-- @return #string

---
-- Function GetPort
--
-- @function [parent=#Connection] GetPort
-- @return short#short

---
-- Function ToString
--
-- @function [parent=#Connection] ToString
-- @return #string

---
-- Function GetNumDownloads
--
-- @function [parent=#Connection] GetNumDownloads
-- @return #number

---
-- Function GetDownloadName
--
-- @function [parent=#Connection] GetDownloadName
-- @return const String#const String

---
-- Function GetDownloadProgress
--
-- @function [parent=#Connection] GetDownloadProgress
-- @return #number

---
-- Field identity
--
-- @field [parent=#Connection] VariantMap#VariantMap identity

---
-- Field scene
--
-- @field [parent=#Connection] Scene#Scene scene

---
-- Field controls
--
-- @field [parent=#Connection] Controls#Controls controls

---
-- Field position
--
-- @field [parent=#Connection] Vector3#Vector3 position

---
-- Field client (Read only)
--
-- @field [parent=#Connection] #boolean client

---
-- Field connected (Read only)
--
-- @field [parent=#Connection] #boolean connected

---
-- Field connectPending
--
-- @field [parent=#Connection] #boolean connectPending

---
-- Field sceneLoaded (Read only)
--
-- @field [parent=#Connection] #boolean sceneLoaded

---
-- Field logStatistics
--
-- @field [parent=#Connection] #boolean logStatistics

---
-- Field address (Read only)
--
-- @field [parent=#Connection] #string address

---
-- Field port (Read only)
--
-- @field [parent=#Connection] short#short port

---
-- Field numDownloads (Read only)
--
-- @field [parent=#Connection] #number numDownloads

---
-- Field downloadName (Read only)
--
-- @field [parent=#Connection] #string downloadName

---
-- Field downloadProgress (Read only)
--
-- @field [parent=#Connection] #number downloadProgress


return nil
