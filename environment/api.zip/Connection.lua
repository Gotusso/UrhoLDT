---
-- Module Connection
-- Module Connection extends Object
-- Generated on 2014-03-13
--
-- @module Connection

---
-- Function SendMessage
--
-- @function [parent=#Connection] SendMessage
-- @param self Self reference
-- @param #number msgID msgID
-- @param #boolean reliable reliable
-- @param #boolean inOrder inOrder
-- @param VectorBuffer#VectorBuffer msg msg
-- @param #number contentID contentID

---
-- Function SendRemoteEvent
--
-- @function [parent=#Connection] SendRemoteEvent
-- @param self Self reference
-- @param StringHash#StringHash eventType eventType
-- @param #boolean inOrder inOrder

---
-- Function SendRemoteEvent
--
-- @function [parent=#Connection] SendRemoteEvent
-- @param self Self reference
-- @param StringHash#StringHash eventType eventType
-- @param #boolean inOrder inOrder
-- @param VariantMap#VariantMap eventData eventData

---
-- Function SendRemoteEvent
--
-- @function [parent=#Connection] SendRemoteEvent
-- @param self Self reference
-- @param #string eventType eventType
-- @param #boolean inOrder inOrder

---
-- Function SendRemoteEvent
--
-- @function [parent=#Connection] SendRemoteEvent
-- @param self Self reference
-- @param #string eventType eventType
-- @param #boolean inOrder inOrder
-- @param VariantMap#VariantMap eventData eventData

---
-- Function SendRemoteEvent
--
-- @function [parent=#Connection] SendRemoteEvent
-- @param self Self reference
-- @param Node#Node node node
-- @param StringHash#StringHash eventType eventType
-- @param #boolean inOrder inOrder

---
-- Function SendRemoteEvent
--
-- @function [parent=#Connection] SendRemoteEvent
-- @param self Self reference
-- @param Node#Node node node
-- @param StringHash#StringHash eventType eventType
-- @param #boolean inOrder inOrder
-- @param VariantMap#VariantMap eventData eventData

---
-- Function SendRemoteEvent
--
-- @function [parent=#Connection] SendRemoteEvent
-- @param self Self reference
-- @param Node#Node node node
-- @param #string eventType eventType
-- @param #boolean inOrder inOrder

---
-- Function SendRemoteEvent
--
-- @function [parent=#Connection] SendRemoteEvent
-- @param self Self reference
-- @param Node#Node node node
-- @param #string eventType eventType
-- @param #boolean inOrder inOrder
-- @param VariantMap#VariantMap eventData eventData

---
-- Function SetScene
--
-- @function [parent=#Connection] SetScene
-- @param self Self reference
-- @param Scene#Scene newScene newScene

---
-- Function SetIdentity
--
-- @function [parent=#Connection] SetIdentity
-- @param self Self reference
-- @param VariantMap#VariantMap identity identity

---
-- Function SetControls
--
-- @function [parent=#Connection] SetControls
-- @param self Self reference
-- @param Controls#Controls newControls newControls

---
-- Function SetPosition
--
-- @function [parent=#Connection] SetPosition
-- @param self Self reference
-- @param Vector3#Vector3 position position

---
-- Function SetConnectPending
--
-- @function [parent=#Connection] SetConnectPending
-- @param self Self reference
-- @param #boolean connectPending connectPending

---
-- Function SetLogStatistics
--
-- @function [parent=#Connection] SetLogStatistics
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Disconnect
--
-- @function [parent=#Connection] Disconnect
-- @param self Self reference
-- @param #number waitMSec waitMSec

---
-- Function SendServerUpdate
--
-- @function [parent=#Connection] SendServerUpdate
-- @param self Self reference

---
-- Function SendClientUpdate
--
-- @function [parent=#Connection] SendClientUpdate
-- @param self Self reference

---
-- Function SendRemoteEvents
--
-- @function [parent=#Connection] SendRemoteEvents
-- @param self Self reference

---
-- Function SendPackages
--
-- @function [parent=#Connection] SendPackages
-- @param self Self reference

---
-- Function ProcessPendingLatestData
--
-- @function [parent=#Connection] ProcessPendingLatestData
-- @param self Self reference

---
-- Function ProcessMessage
--
-- @function [parent=#Connection] ProcessMessage
-- @param self Self reference
-- @param #number msgID msgID
-- @param MemoryBuffer#MemoryBuffer msg msg
-- @return #boolean

---
-- Function GetIdentity
--
-- @function [parent=#Connection] GetIdentity
-- @param self Self reference
-- @return const VariantMap#const VariantMap

---
-- Function GetScene
--
-- @function [parent=#Connection] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function GetControls
--
-- @function [parent=#Connection] GetControls
-- @param self Self reference
-- @return const Controls#const Controls

---
-- Function GetPosition
--
-- @function [parent=#Connection] GetPosition
-- @param self Self reference
-- @return const Vector3#const Vector3

---
-- Function IsClient
--
-- @function [parent=#Connection] IsClient
-- @param self Self reference
-- @return #boolean

---
-- Function IsConnected
--
-- @function [parent=#Connection] IsConnected
-- @param self Self reference
-- @return #boolean

---
-- Function IsConnectPending
--
-- @function [parent=#Connection] IsConnectPending
-- @param self Self reference
-- @return #boolean

---
-- Function IsSceneLoaded
--
-- @function [parent=#Connection] IsSceneLoaded
-- @param self Self reference
-- @return #boolean

---
-- Function GetLogStatistics
--
-- @function [parent=#Connection] GetLogStatistics
-- @param self Self reference
-- @return #boolean

---
-- Function GetAddress
--
-- @function [parent=#Connection] GetAddress
-- @param self Self reference
-- @return #string

---
-- Function GetPort
--
-- @function [parent=#Connection] GetPort
-- @param self Self reference
-- @return short#short

---
-- Function ToString
--
-- @function [parent=#Connection] ToString
-- @param self Self reference
-- @return #string

---
-- Function GetNumDownloads
--
-- @function [parent=#Connection] GetNumDownloads
-- @param self Self reference
-- @return #number

---
-- Function GetDownloadName
--
-- @function [parent=#Connection] GetDownloadName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetDownloadProgress
--
-- @function [parent=#Connection] GetDownloadProgress
-- @param self Self reference
-- @return #number

---
-- Field identity
--
-- @field [parent=#Connection] VariantMap#VariantMap identity

---
-- Field scene
--
-- @field [parent=#Connection] Scene#Scene scene

---
-- Field controls
--
-- @field [parent=#Connection] Controls#Controls controls

---
-- Field position
--
-- @field [parent=#Connection] Vector3#Vector3 position

---
-- Field client (Read only)
--
-- @field [parent=#Connection] #boolean client

---
-- Field connected (Read only)
--
-- @field [parent=#Connection] #boolean connected

---
-- Field connectPending
--
-- @field [parent=#Connection] #boolean connectPending

---
-- Field sceneLoaded (Read only)
--
-- @field [parent=#Connection] #boolean sceneLoaded

---
-- Field logStatistics
--
-- @field [parent=#Connection] #boolean logStatistics

---
-- Field address (Read only)
--
-- @field [parent=#Connection] #string address

---
-- Field port (Read only)
--
-- @field [parent=#Connection] short#short port

---
-- Field numDownloads (Read only)
--
-- @field [parent=#Connection] #number numDownloads

---
-- Field downloadName (Read only)
--
-- @field [parent=#Connection] #string downloadName

---
-- Field downloadProgress (Read only)
--
-- @field [parent=#Connection] #number downloadProgress

---
-- Function GetType
--
-- @function [parent=#Connection] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Connection] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Connection] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Connection] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Connection] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#Connection] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Connection] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Connection] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Connection] #string category


return nil
