---
-- Module Connection
-- Module Connection extends Object
-- Generated on 2014-05-31
--
-- @module Connection

---
-- Function SendMessage()
-- Send a message.
--
-- @function [parent=#Connection] SendMessage
-- @param self Self reference
-- @param #number msgID msgID
-- @param #boolean reliable reliable
-- @param #boolean inOrder inOrder
-- @param VectorBuffer#VectorBuffer msg msg
-- @param #number contentID contentID

---
-- Function SendRemoteEvent()
-- Send a remote event.
--
-- @function [parent=#Connection] SendRemoteEvent
-- @param self Self reference
-- @param StringHash#StringHash eventType eventType
-- @param #boolean inOrder inOrder

---
-- Function SendRemoteEvent()
--
-- @function [parent=#Connection] SendRemoteEvent
-- @param self Self reference
-- @param StringHash#StringHash eventType eventType
-- @param #boolean inOrder inOrder
-- @param VariantMap#VariantMap eventData eventData

---
-- Function SendRemoteEvent()
--
-- @function [parent=#Connection] SendRemoteEvent
-- @param self Self reference
-- @param #string eventType eventType
-- @param #boolean inOrder inOrder

---
-- Function SendRemoteEvent()
--
-- @function [parent=#Connection] SendRemoteEvent
-- @param self Self reference
-- @param #string eventType eventType
-- @param #boolean inOrder inOrder
-- @param VariantMap#VariantMap eventData eventData

---
-- Function SendRemoteEvent()
-- Send a remote event with the specified node as sender.
--
-- @function [parent=#Connection] SendRemoteEvent
-- @param self Self reference
-- @param Node#Node node node
-- @param StringHash#StringHash eventType eventType
-- @param #boolean inOrder inOrder

---
-- Function SendRemoteEvent()
--
-- @function [parent=#Connection] SendRemoteEvent
-- @param self Self reference
-- @param Node#Node node node
-- @param StringHash#StringHash eventType eventType
-- @param #boolean inOrder inOrder
-- @param VariantMap#VariantMap eventData eventData

---
-- Function SendRemoteEvent()
--
-- @function [parent=#Connection] SendRemoteEvent
-- @param self Self reference
-- @param Node#Node node node
-- @param #string eventType eventType
-- @param #boolean inOrder inOrder

---
-- Function SendRemoteEvent()
--
-- @function [parent=#Connection] SendRemoteEvent
-- @param self Self reference
-- @param Node#Node node node
-- @param #string eventType eventType
-- @param #boolean inOrder inOrder
-- @param VariantMap#VariantMap eventData eventData

---
-- Function SetScene()
-- Assign scene. On the server, this will cause the client to load it.
--
-- @function [parent=#Connection] SetScene
-- @param self Self reference
-- @param Scene#Scene newScene newScene

---
-- Function SetIdentity()
-- Assign identity. Called by Network.
--
-- @function [parent=#Connection] SetIdentity
-- @param self Self reference
-- @param VariantMap#VariantMap identity identity

---
-- Function SetControls()
-- Set new controls.
--
-- @function [parent=#Connection] SetControls
-- @param self Self reference
-- @param Controls#Controls newControls newControls

---
-- Function SetPosition()
-- Set the observer position for interest management.
--
-- @function [parent=#Connection] SetPosition
-- @param self Self reference
-- @param Vector3#Vector3 position position

---
-- Function SetConnectPending()
-- Set the connection pending status. Called by Network.
--
-- @function [parent=#Connection] SetConnectPending
-- @param self Self reference
-- @param #boolean connectPending connectPending

---
-- Function SetLogStatistics()
-- Set whether to log data in/out statistics.
--
-- @function [parent=#Connection] SetLogStatistics
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Disconnect()
-- Disconnect. If wait time is non-zero, will block while waiting for disconnect to finish.
--
-- @function [parent=#Connection] Disconnect
-- @param self Self reference
-- @param #number waitMSec waitMSec

---
-- Function SendServerUpdate()
-- Send scene update messages. Called by Network.
--
-- @function [parent=#Connection] SendServerUpdate
-- @param self Self reference

---
-- Function SendClientUpdate()
-- Send latest controls from the client. Called by Network.
--
-- @function [parent=#Connection] SendClientUpdate
-- @param self Self reference

---
-- Function SendRemoteEvents()
-- Send queued remote events. Called by Network.
--
-- @function [parent=#Connection] SendRemoteEvents
-- @param self Self reference

---
-- Function SendPackages()
-- Send package files to client. Called by network.
--
-- @function [parent=#Connection] SendPackages
-- @param self Self reference

---
-- Function ProcessPendingLatestData()
-- Process pending latest data for nodes and components.
--
-- @function [parent=#Connection] ProcessPendingLatestData
-- @param self Self reference

---
-- Function ProcessMessage()
-- Process a message from the server or client. Called by Network.
--
-- @function [parent=#Connection] ProcessMessage
-- @param self Self reference
-- @param #number msgID msgID
-- @param MemoryBuffer#MemoryBuffer msg msg
-- @return #boolean

---
-- Function GetIdentity()
-- Return client identity.
--
-- @function [parent=#Connection] GetIdentity
-- @param self Self reference
-- @return const VariantMap#const VariantMap

---
-- Function GetScene()
-- Return the scene used by this connection.
--
-- @function [parent=#Connection] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function GetControls()
-- Return the client controls of this connection.
--
-- @function [parent=#Connection] GetControls
-- @param self Self reference
-- @return const Controls#const Controls

---
-- Function GetPosition()
-- Return the observer position for interest management.
--
-- @function [parent=#Connection] GetPosition
-- @param self Self reference
-- @return const Vector3#const Vector3

---
-- Function IsClient()
-- Return whether is a client connection.
--
-- @function [parent=#Connection] IsClient
-- @param self Self reference
-- @return #boolean

---
-- Function IsConnected()
-- Return whether is fully connected.
--
-- @function [parent=#Connection] IsConnected
-- @param self Self reference
-- @return #boolean

---
-- Function IsConnectPending()
-- Return whether connection is pending.
--
-- @function [parent=#Connection] IsConnectPending
-- @param self Self reference
-- @return #boolean

---
-- Function IsSceneLoaded()
-- Return whether the scene is loaded and ready to receive server updates.
--
-- @function [parent=#Connection] IsSceneLoaded
-- @param self Self reference
-- @return #boolean

---
-- Function GetLogStatistics()
-- Return whether to log data in/out statistics.
--
-- @function [parent=#Connection] GetLogStatistics
-- @param self Self reference
-- @return #boolean

---
-- Function GetAddress()
-- Return remote address.
--
-- @function [parent=#Connection] GetAddress
-- @param self Self reference
-- @return #string

---
-- Function GetPort()
-- Return remote port.
--
-- @function [parent=#Connection] GetPort
-- @param self Self reference
-- @return short#short

---
-- Function ToString()
-- Return an address:port string.
--
-- @function [parent=#Connection] ToString
-- @param self Self reference
-- @return #string

---
-- Function GetNumDownloads()
-- Return number of package downloads remaining.
--
-- @function [parent=#Connection] GetNumDownloads
-- @param self Self reference
-- @return #number

---
-- Function GetDownloadName()
-- Return name of current package download, or empty if no downloads.
--
-- @function [parent=#Connection] GetDownloadName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetDownloadProgress()
-- Return progress of current package download, or 1.0 if no downloads.
--
-- @function [parent=#Connection] GetDownloadProgress
-- @param self Self reference
-- @return #number

---
-- Field identity
--
-- @field [parent=#Connection] VariantMap#VariantMap identity

---
-- Field scene
--
-- @field [parent=#Connection] Scene#Scene scene

---
-- Field controls
--
-- @field [parent=#Connection] Controls#Controls controls

---
-- Field position
--
-- @field [parent=#Connection] Vector3#Vector3 position

---
-- Field client (Read only)
--
-- @field [parent=#Connection] #boolean client

---
-- Field connected (Read only)
--
-- @field [parent=#Connection] #boolean connected

---
-- Field connectPending
--
-- @field [parent=#Connection] #boolean connectPending

---
-- Field sceneLoaded (Read only)
--
-- @field [parent=#Connection] #boolean sceneLoaded

---
-- Field logStatistics
--
-- @field [parent=#Connection] #boolean logStatistics

---
-- Field address (Read only)
--
-- @field [parent=#Connection] #string address

---
-- Field port (Read only)
--
-- @field [parent=#Connection] short#short port

---
-- Field numDownloads (Read only)
--
-- @field [parent=#Connection] #number numDownloads

---
-- Field downloadName (Read only)
--
-- @field [parent=#Connection] #string downloadName

---
-- Field downloadProgress (Read only)
--
-- @field [parent=#Connection] #number downloadProgress


return nil
