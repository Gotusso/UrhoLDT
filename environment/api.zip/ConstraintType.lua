---
-- Enumeration ConstraintType
--
-- @module ConstraintType

---
-- Enumeration value CONSTRAINT_POINT
--
-- @field [parent=#ConstraintType] #number CONSTRAINT_POINT

---
-- Enumeration value CONSTRAINT_HINGE
--
-- @field [parent=#ConstraintType] #number CONSTRAINT_HINGE

---
-- Enumeration value CONSTRAINT_SLIDER
--
-- @field [parent=#ConstraintType] #number CONSTRAINT_SLIDER

---
-- Enumeration value CONSTRAINT_CONETWIST
--
-- @field [parent=#ConstraintType] #number CONSTRAINT_CONETWIST


return nil
