---
-- Module RenderSurface
--
-- @module RenderSurface

---
-- Function RenderSurface
--
-- @function [parent=#RenderSurface] RenderSurface
-- @param Texture#Texture parentTextureparentTexture

---
-- Function new
--
-- @function [parent=#RenderSurface] new
-- @param Texture#Texture parentTextureparentTexture
-- @return RenderSurface#RenderSurface

---
-- Function delete
--
-- @function [parent=#RenderSurface] delete

---
-- Function SetNumViewports
--
-- @function [parent=#RenderSurface] SetNumViewports
-- @param #number numnum

---
-- Function SetViewport
--
-- @function [parent=#RenderSurface] SetViewport
-- @param #number indexindex
-- @param Viewport#Viewport viewportviewport

---
-- Function SetUpdateMode
--
-- @function [parent=#RenderSurface] SetUpdateMode
-- @param RenderSurfaceUpdateMode#RenderSurfaceUpdateMode modemode

---
-- Function SetLinkedRenderTarget
--
-- @function [parent=#RenderSurface] SetLinkedRenderTarget
-- @param RenderSurface#RenderSurface renderTargetrenderTarget

---
-- Function SetLinkedDepthStencil
--
-- @function [parent=#RenderSurface] SetLinkedDepthStencil
-- @param RenderSurface#RenderSurface depthStencildepthStencil

---
-- Function QueueUpdate
--
-- @function [parent=#RenderSurface] QueueUpdate

---
-- Function Release
--
-- @function [parent=#RenderSurface] Release

---
-- Function GetParentTexture
--
-- @function [parent=#RenderSurface] GetParentTexture
-- @return Texture#Texture

---
-- Function GetWidth
--
-- @function [parent=#RenderSurface] GetWidth
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#RenderSurface] GetHeight
-- @return #number

---
-- Function GetUsage
--
-- @function [parent=#RenderSurface] GetUsage
-- @return TextureUsage#TextureUsage

---
-- Function GetNumViewports
--
-- @function [parent=#RenderSurface] GetNumViewports
-- @return #number

---
-- Function GetViewport
--
-- @function [parent=#RenderSurface] GetViewport
-- @param #number indexindex
-- @return Viewport#Viewport

---
-- Function GetUpdateMode
--
-- @function [parent=#RenderSurface] GetUpdateMode
-- @return RenderSurfaceUpdateMode#RenderSurfaceUpdateMode

---
-- Function GetLinkedRenderTarget
--
-- @function [parent=#RenderSurface] GetLinkedRenderTarget
-- @return RenderSurface#RenderSurface

---
-- Function GetLinkedDepthStencil
--
-- @function [parent=#RenderSurface] GetLinkedDepthStencil
-- @return RenderSurface#RenderSurface

---
-- Field parentTexture (Read only)
--
-- @field [parent=#RenderSurface] Texture#Texture parentTexture

---
-- Field width (Read only)
--
-- @field [parent=#RenderSurface] #number width

---
-- Field height (Read only)
--
-- @field [parent=#RenderSurface] #number height

---
-- Field usage (Read only)
--
-- @field [parent=#RenderSurface] TextureUsage#TextureUsage usage

---
-- Field numViewports
--
-- @field [parent=#RenderSurface] #number numViewports

---
-- Field updateMode
--
-- @field [parent=#RenderSurface] RenderSurfaceUpdateMode#RenderSurfaceUpdateMode updateMode

---
-- Field linkedRenderTarget
--
-- @field [parent=#RenderSurface] RenderSurface#RenderSurface linkedRenderTarget

---
-- Field linkedDepthStencil
--
-- @field [parent=#RenderSurface] RenderSurface#RenderSurface linkedDepthStencil


return nil
