---
-- Module RenderSurface
-- Generated on 2014-03-13
--
-- @module RenderSurface

---
-- Function RenderSurface
--
-- @function [parent=#RenderSurface] RenderSurface
-- @param self Self reference
-- @param Texture#Texture parentTexture parentTexture

---
-- Function new
--
-- @function [parent=#RenderSurface] new
-- @param self Self reference
-- @param Texture#Texture parentTexture parentTexture
-- @return RenderSurface#RenderSurface

---
-- Function delete
--
-- @function [parent=#RenderSurface] delete
-- @param self Self reference

---
-- Function SetNumViewports
--
-- @function [parent=#RenderSurface] SetNumViewports
-- @param self Self reference
-- @param #number num num

---
-- Function SetViewport
--
-- @function [parent=#RenderSurface] SetViewport
-- @param self Self reference
-- @param #number index index
-- @param Viewport#Viewport viewport viewport

---
-- Function SetUpdateMode
--
-- @function [parent=#RenderSurface] SetUpdateMode
-- @param self Self reference
-- @param RenderSurfaceUpdateMode#RenderSurfaceUpdateMode mode mode

---
-- Function SetLinkedRenderTarget
--
-- @function [parent=#RenderSurface] SetLinkedRenderTarget
-- @param self Self reference
-- @param RenderSurface#RenderSurface renderTarget renderTarget

---
-- Function SetLinkedDepthStencil
--
-- @function [parent=#RenderSurface] SetLinkedDepthStencil
-- @param self Self reference
-- @param RenderSurface#RenderSurface depthStencil depthStencil

---
-- Function QueueUpdate
--
-- @function [parent=#RenderSurface] QueueUpdate
-- @param self Self reference

---
-- Function Release
--
-- @function [parent=#RenderSurface] Release
-- @param self Self reference

---
-- Function GetParentTexture
--
-- @function [parent=#RenderSurface] GetParentTexture
-- @param self Self reference
-- @return Texture#Texture

---
-- Function GetWidth
--
-- @function [parent=#RenderSurface] GetWidth
-- @param self Self reference
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#RenderSurface] GetHeight
-- @param self Self reference
-- @return #number

---
-- Function GetUsage
--
-- @function [parent=#RenderSurface] GetUsage
-- @param self Self reference
-- @return TextureUsage#TextureUsage

---
-- Function GetNumViewports
--
-- @function [parent=#RenderSurface] GetNumViewports
-- @param self Self reference
-- @return #number

---
-- Function GetViewport
--
-- @function [parent=#RenderSurface] GetViewport
-- @param self Self reference
-- @param #number index index
-- @return Viewport#Viewport

---
-- Function GetUpdateMode
--
-- @function [parent=#RenderSurface] GetUpdateMode
-- @param self Self reference
-- @return RenderSurfaceUpdateMode#RenderSurfaceUpdateMode

---
-- Function GetLinkedRenderTarget
--
-- @function [parent=#RenderSurface] GetLinkedRenderTarget
-- @param self Self reference
-- @return RenderSurface#RenderSurface

---
-- Function GetLinkedDepthStencil
--
-- @function [parent=#RenderSurface] GetLinkedDepthStencil
-- @param self Self reference
-- @return RenderSurface#RenderSurface

---
-- Field parentTexture (Read only)
--
-- @field [parent=#RenderSurface] Texture#Texture parentTexture

---
-- Field width (Read only)
--
-- @field [parent=#RenderSurface] #number width

---
-- Field height (Read only)
--
-- @field [parent=#RenderSurface] #number height

---
-- Field usage (Read only)
--
-- @field [parent=#RenderSurface] TextureUsage#TextureUsage usage

---
-- Field numViewports
--
-- @field [parent=#RenderSurface] #number numViewports

---
-- Field updateMode
--
-- @field [parent=#RenderSurface] RenderSurfaceUpdateMode#RenderSurfaceUpdateMode updateMode

---
-- Field linkedRenderTarget
--
-- @field [parent=#RenderSurface] RenderSurface#RenderSurface linkedRenderTarget

---
-- Field linkedDepthStencil
--
-- @field [parent=#RenderSurface] RenderSurface#RenderSurface linkedDepthStencil


return nil
