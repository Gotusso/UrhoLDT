---
-- Module ListView
-- extends ScrollView
--
-- @module ListView

---
-- Function ListView
--
-- @function [parent=#ListView] ListView

---
-- Function new
--
-- @function [parent=#ListView] new
-- @return ListView#ListView

---
-- Function delete
--
-- @function [parent=#ListView] delete

---
-- Function AddItem
--
-- @function [parent=#ListView] AddItem
-- @param UIElement#UIElement itemitem

---
-- Function InsertItem
--
-- @function [parent=#ListView] InsertItem
-- @param #number indexindex
-- @param UIElement#UIElement itemitem
-- @param UIElement#UIElement parentItemparentItem

---
-- Function RemoveItem
--
-- @function [parent=#ListView] RemoveItem
-- @param UIElement#UIElement itemitem
-- @param #number indexindex

---
-- Function RemoveItem
--
-- @function [parent=#ListView] RemoveItem
-- @param #number indexindex

---
-- Function RemoveAllItems
--
-- @function [parent=#ListView] RemoveAllItems

---
-- Function SetSelection
--
-- @function [parent=#ListView] SetSelection
-- @param #number indexindex

---
-- Function SetSelections
--
-- @function [parent=#ListView] SetSelections
-- @param PODVector<unsigned>#PODVector<unsigned> indicesindices

---
-- Function AddSelection
--
-- @function [parent=#ListView] AddSelection
-- @param #number indexindex

---
-- Function RemoveSelection
--
-- @function [parent=#ListView] RemoveSelection
-- @param #number indexindex

---
-- Function ToggleSelection
--
-- @function [parent=#ListView] ToggleSelection
-- @param #number indexindex

---
-- Function ChangeSelection
--
-- @function [parent=#ListView] ChangeSelection
-- @param #number deltadelta
-- @param #boolean additiveadditive

---
-- Function ClearSelection
--
-- @function [parent=#ListView] ClearSelection

---
-- Function SetHighlightMode
--
-- @function [parent=#ListView] SetHighlightMode
-- @param HighlightMode#HighlightMode modemode

---
-- Function SetMultiselect
--
-- @function [parent=#ListView] SetMultiselect
-- @param #boolean enableenable

---
-- Function SetHierarchyMode
--
-- @function [parent=#ListView] SetHierarchyMode
-- @param #boolean enableenable

---
-- Function SetBaseIndent
--
-- @function [parent=#ListView] SetBaseIndent
-- @param #number baseIndentbaseIndent

---
-- Function SetClearSelectionOnDefocus
--
-- @function [parent=#ListView] SetClearSelectionOnDefocus
-- @param #boolean enableenable

---
-- Function Expand
--
-- @function [parent=#ListView] Expand
-- @param #number indexindex
-- @param #boolean enableenable
-- @param #boolean recursiverecursive

---
-- Function ToggleExpand
--
-- @function [parent=#ListView] ToggleExpand
-- @param #number indexindex
-- @param #boolean recursiverecursive

---
-- Function GetNumItems
--
-- @function [parent=#ListView] GetNumItems
-- @return #number

---
-- Function GetItem
--
-- @function [parent=#ListView] GetItem
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function GetItems
--
-- @function [parent=#ListView] GetItems
-- @return const PODVector<UIElement*>#const PODVector<UIElement*>

---
-- Function FindItem
--
-- @function [parent=#ListView] FindItem
-- @param UIElement#UIElement itemitem
-- @return #number

---
-- Function GetSelection
--
-- @function [parent=#ListView] GetSelection
-- @return #number

---
-- Function GetSelections
--
-- @function [parent=#ListView] GetSelections
-- @return const PODVector<unsigned>#const PODVector<unsigned>

---
-- Function GetSelectedItem
--
-- @function [parent=#ListView] GetSelectedItem
-- @return UIElement#UIElement

---
-- Function GetSelectedItems
--
-- @function [parent=#ListView] GetSelectedItems
-- @return const PODVector<UIElement*>#const PODVector<UIElement*>

---
-- Function IsSelected
--
-- @function [parent=#ListView] IsSelected
-- @param #number indexindex
-- @return #boolean

---
-- Function IsExpanded
--
-- @function [parent=#ListView] IsExpanded
-- @param #number indexindex
-- @return #boolean

---
-- Function GetHighlightMode
--
-- @function [parent=#ListView] GetHighlightMode
-- @return HighlightMode#HighlightMode

---
-- Function GetMultiselect
--
-- @function [parent=#ListView] GetMultiselect
-- @return #boolean

---
-- Function GetClearSelectionOnDefocus
--
-- @function [parent=#ListView] GetClearSelectionOnDefocus
-- @return #boolean

---
-- Function GetHierarchyMode
--
-- @function [parent=#ListView] GetHierarchyMode
-- @return #boolean

---
-- Function GetBaseIndent
--
-- @function [parent=#ListView] GetBaseIndent
-- @return #number

---
-- Field numItems (Read only)
--
-- @field [parent=#ListView] #number numItems

---
-- Field selection
--
-- @field [parent=#ListView] #number selection

---
-- Field selectedItem (Read only)
--
-- @field [parent=#ListView] UIElement#UIElement selectedItem

---
-- Field highlightMode
--
-- @field [parent=#ListView] HighlightMode#HighlightMode highlightMode

---
-- Field multiselect
--
-- @field [parent=#ListView] #boolean multiselect

---
-- Field clearSelectionOnDefocus
--
-- @field [parent=#ListView] #boolean clearSelectionOnDefocus

---
-- Field hierarchyMode
--
-- @field [parent=#ListView] #boolean hierarchyMode

---
-- Field baseIndent
--
-- @field [parent=#ListView] #number baseIndent

---
-- Function ScrollView
--
-- @function [parent=#ListView] ScrollView

---
-- Function new
--
-- @function [parent=#ListView] new
-- @return ScrollView#ScrollView

---
-- Function delete
--
-- @function [parent=#ListView] delete

---
-- Function SetContentElement
--
-- @function [parent=#ListView] SetContentElement
-- @param UIElement#UIElement elementelement

---
-- Function SetViewPosition
--
-- @function [parent=#ListView] SetViewPosition
-- @param IntVector2#IntVector2 positionposition

---
-- Function SetViewPosition
--
-- @function [parent=#ListView] SetViewPosition
-- @param #number xx
-- @param #number yy

---
-- Function SetScrollBarsVisible
--
-- @function [parent=#ListView] SetScrollBarsVisible
-- @param #boolean horizontalhorizontal
-- @param #boolean verticalvertical

---
-- Function SetScrollBarsAutoVisible
--
-- @function [parent=#ListView] SetScrollBarsAutoVisible
-- @param #boolean enableenable

---
-- Function SetScrollStep
--
-- @function [parent=#ListView] SetScrollStep
-- @param #number stepstep

---
-- Function SetPageStep
--
-- @function [parent=#ListView] SetPageStep
-- @param #number stepstep

---
-- Function GetViewPosition
--
-- @function [parent=#ListView] GetViewPosition
-- @return const IntVector2#const IntVector2

---
-- Function GetContentElement
--
-- @function [parent=#ListView] GetContentElement
-- @return UIElement#UIElement

---
-- Function GetHorizontalScrollBar
--
-- @function [parent=#ListView] GetHorizontalScrollBar
-- @return ScrollBar#ScrollBar

---
-- Function GetVerticalScrollBar
--
-- @function [parent=#ListView] GetVerticalScrollBar
-- @return ScrollBar#ScrollBar

---
-- Function GetScrollPanel
--
-- @function [parent=#ListView] GetScrollPanel
-- @return BorderImage#BorderImage

---
-- Function GetScrollBarsAutoVisible
--
-- @function [parent=#ListView] GetScrollBarsAutoVisible
-- @return #boolean

---
-- Function GetScrollStep
--
-- @function [parent=#ListView] GetScrollStep
-- @return #number

---
-- Function GetPageStep
--
-- @function [parent=#ListView] GetPageStep
-- @return #number

---
-- Field viewPosition
--
-- @field [parent=#ListView] IntVector2#IntVector2 viewPosition

---
-- Field contentElement
--
-- @field [parent=#ListView] UIElement#UIElement contentElement

---
-- Field horizontalScrollBar (Read only)
--
-- @field [parent=#ListView] ScrollBar#ScrollBar horizontalScrollBar

---
-- Field verticalScrollBar (Read only)
--
-- @field [parent=#ListView] ScrollBar#ScrollBar verticalScrollBar

---
-- Field scrollPanel (Read only)
--
-- @field [parent=#ListView] BorderImage#BorderImage scrollPanel

---
-- Field scrollBarsAutoVisible
--
-- @field [parent=#ListView] #boolean scrollBarsAutoVisible

---
-- Field scrollStep
--
-- @field [parent=#ListView] #number scrollStep

---
-- Field pageStep
--
-- @field [parent=#ListView] #number pageStep

---
-- Function UIElement
--
-- @function [parent=#ListView] UIElement

---
-- Function new
--
-- @function [parent=#ListView] new
-- @return UIElement#UIElement

---
-- Function delete
--
-- @function [parent=#ListView] delete

---
-- Function GetScreenPosition
--
-- @function [parent=#ListView] GetScreenPosition
-- @return const IntVector2#const IntVector2

---
-- Function LoadXML
--
-- @function [parent=#ListView] LoadXML
-- @param Deserializer#Deserializer sourcesource
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#ListView] SaveXML
-- @param Serializer#Serializer destdest
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#ListView] LoadXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#ListView] SaveXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function FilterAttributes
--
-- @function [parent=#ListView] FilterAttributes
-- @param XMLElement#XMLElement destdest
-- @return #boolean

---
-- Function SetName
--
-- @function [parent=#ListView] SetName
-- @param #string namename

---
-- Function SetPosition
--
-- @function [parent=#ListView] SetPosition
-- @param IntVector2#IntVector2 positionposition

---
-- Function SetPosition
--
-- @function [parent=#ListView] SetPosition
-- @param #number xx
-- @param #number yy

---
-- Function SetSize
--
-- @function [parent=#ListView] SetSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function SetSize
--
-- @function [parent=#ListView] SetSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetWidth
--
-- @function [parent=#ListView] SetWidth
-- @param #number widthwidth

---
-- Function SetHeight
--
-- @function [parent=#ListView] SetHeight
-- @param #number heightheight

---
-- Function SetMinSize
--
-- @function [parent=#ListView] SetMinSize
-- @param IntVector2#IntVector2 minSizeminSize

---
-- Function SetMinSize
--
-- @function [parent=#ListView] SetMinSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetMinWidth
--
-- @function [parent=#ListView] SetMinWidth
-- @param #number widthwidth

---
-- Function SetMinHeight
--
-- @function [parent=#ListView] SetMinHeight
-- @param #number heightheight

---
-- Function SetMaxSize
--
-- @function [parent=#ListView] SetMaxSize
-- @param IntVector2#IntVector2 maxSizemaxSize

---
-- Function SetMaxSize
--
-- @function [parent=#ListView] SetMaxSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetMaxWidth
--
-- @function [parent=#ListView] SetMaxWidth
-- @param #number widthwidth

---
-- Function SetMaxHeight
--
-- @function [parent=#ListView] SetMaxHeight
-- @param #number heightheight

---
-- Function SetFixedSize
--
-- @function [parent=#ListView] SetFixedSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function SetFixedSize
--
-- @function [parent=#ListView] SetFixedSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetFixedWidth
--
-- @function [parent=#ListView] SetFixedWidth
-- @param #number widthwidth

---
-- Function SetFixedHeight
--
-- @function [parent=#ListView] SetFixedHeight
-- @param #number heightheight

---
-- Function SetAlignment
--
-- @function [parent=#ListView] SetAlignment
-- @param HorizontalAlignment#HorizontalAlignment hAlignhAlign
-- @param VerticalAlignment#VerticalAlignment vAlignvAlign

---
-- Function SetHorizontalAlignment
--
-- @function [parent=#ListView] SetHorizontalAlignment
-- @param HorizontalAlignment#HorizontalAlignment alignalign

---
-- Function SetVerticalAlignment
--
-- @function [parent=#ListView] SetVerticalAlignment
-- @param VerticalAlignment#VerticalAlignment alignalign

---
-- Function SetClipBorder
--
-- @function [parent=#ListView] SetClipBorder
-- @param IntRect#IntRect rectrect

---
-- Function SetColor
--
-- @function [parent=#ListView] SetColor
-- @param Color#Color colorcolor

---
-- Function SetColor
--
-- @function [parent=#ListView] SetColor
-- @param Corner#Corner cornercorner
-- @param Color#Color colorcolor

---
-- Function SetPriority
--
-- @function [parent=#ListView] SetPriority
-- @param #number prioritypriority

---
-- Function SetOpacity
--
-- @function [parent=#ListView] SetOpacity
-- @param #number opacityopacity

---
-- Function SetBringToFront
--
-- @function [parent=#ListView] SetBringToFront
-- @param #boolean enableenable

---
-- Function SetBringToBack
--
-- @function [parent=#ListView] SetBringToBack
-- @param #boolean enableenable

---
-- Function SetClipChildren
--
-- @function [parent=#ListView] SetClipChildren
-- @param #boolean enableenable

---
-- Function SetSortChildren
--
-- @function [parent=#ListView] SetSortChildren
-- @param #boolean enableenable

---
-- Function SetUseDerivedOpacity
--
-- @function [parent=#ListView] SetUseDerivedOpacity
-- @param #boolean enableenable

---
-- Function SetEnabled
--
-- @function [parent=#ListView] SetEnabled
-- @param #boolean enableenable

---
-- Function SetEditable
--
-- @function [parent=#ListView] SetEditable
-- @param #boolean enableenable

---
-- Function SetFocus
--
-- @function [parent=#ListView] SetFocus
-- @param #boolean enableenable

---
-- Function SetSelected
--
-- @function [parent=#ListView] SetSelected
-- @param #boolean enableenable

---
-- Function SetVisible
--
-- @function [parent=#ListView] SetVisible
-- @param #boolean enableenable

---
-- Function SetFocusMode
--
-- @function [parent=#ListView] SetFocusMode
-- @param FocusMode#FocusMode modemode

---
-- Function SetDragDropMode
--
-- @function [parent=#ListView] SetDragDropMode
-- @param #number modemode

---
-- Function SetStyle
--
-- @function [parent=#ListView] SetStyle
-- @param #string styleNamestyleName
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetStyle
--
-- @function [parent=#ListView] SetStyle
-- @param XMLElement#XMLElement elementelement
-- @return #boolean

---
-- Function SetStyleAuto
--
-- @function [parent=#ListView] SetStyleAuto
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetDefaultStyle
--
-- @function [parent=#ListView] SetDefaultStyle
-- @param XMLFile#XMLFile stylestyle

---
-- Function SetLayout
--
-- @function [parent=#ListView] SetLayout
-- @param LayoutMode#LayoutMode modemode
-- @param #number spacingspacing

---
-- Function SetLayout
--
-- @function [parent=#ListView] SetLayout
-- @param LayoutMode#LayoutMode modemode
-- @param #number spacingspacing
-- @param IntRect#IntRect borderborder

---
-- Function SetLayoutMode
--
-- @function [parent=#ListView] SetLayoutMode
-- @param LayoutMode#LayoutMode modemode

---
-- Function SetLayoutSpacing
--
-- @function [parent=#ListView] SetLayoutSpacing
-- @param #number spacingspacing

---
-- Function SetLayoutBorder
--
-- @function [parent=#ListView] SetLayoutBorder
-- @param IntRect#IntRect borderborder

---
-- Function SetIndent
--
-- @function [parent=#ListView] SetIndent
-- @param #number indentindent

---
-- Function SetIndentSpacing
--
-- @function [parent=#ListView] SetIndentSpacing
-- @param #number indentSpacingindentSpacing

---
-- Function UpdateLayout
--
-- @function [parent=#ListView] UpdateLayout

---
-- Function DisableLayoutUpdate
--
-- @function [parent=#ListView] DisableLayoutUpdate

---
-- Function EnableLayoutUpdate
--
-- @function [parent=#ListView] EnableLayoutUpdate

---
-- Function BringToFront
--
-- @function [parent=#ListView] BringToFront

---
-- Function CreateChild
--
-- @function [parent=#ListView] CreateChild
-- @param #string typetype
-- @param #string namename
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function AddChild
--
-- @function [parent=#ListView] AddChild
-- @param UIElement#UIElement elementelement

---
-- Function InsertChild
--
-- @function [parent=#ListView] InsertChild
-- @param #number indexindex
-- @param UIElement#UIElement elementelement

---
-- Function RemoveChild
--
-- @function [parent=#ListView] RemoveChild
-- @param UIElement#UIElement elementelement
-- @param #number indexindex

---
-- Function RemoveChildAtIndex
--
-- @function [parent=#ListView] RemoveChildAtIndex
-- @param #number indexindex

---
-- Function RemoveAllChildren
--
-- @function [parent=#ListView] RemoveAllChildren

---
-- Function Remove
--
-- @function [parent=#ListView] Remove

---
-- Function FindChild
--
-- @function [parent=#ListView] FindChild
-- @param UIElement#UIElement elementelement
-- @return #number

---
-- Function SetParent
--
-- @function [parent=#ListView] SetParent
-- @param UIElement#UIElement parentparent
-- @param #number indexindex

---
-- Function SetVar
--
-- @function [parent=#ListView] SetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @param Variant#Variant valuevalue

---
-- Function SetInternal
--
-- @function [parent=#ListView] SetInternal
-- @param #boolean enableenable

---
-- Function SetTraversalMode
--
-- @function [parent=#ListView] SetTraversalMode
-- @param TraversalMode#TraversalMode traversalModetraversalMode

---
-- Function SetElementEventSender
--
-- @function [parent=#ListView] SetElementEventSender
-- @param #boolean flagflag

---
-- Function GetName
--
-- @function [parent=#ListView] GetName
-- @return const String#const String

---
-- Function GetPosition
--
-- @function [parent=#ListView] GetPosition
-- @return const IntVector2#const IntVector2

---
-- Function GetSize
--
-- @function [parent=#ListView] GetSize
-- @return const IntVector2#const IntVector2

---
-- Function GetWidth
--
-- @function [parent=#ListView] GetWidth
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#ListView] GetHeight
-- @return #number

---
-- Function GetMinSize
--
-- @function [parent=#ListView] GetMinSize
-- @return const IntVector2#const IntVector2

---
-- Function GetMinWidth
--
-- @function [parent=#ListView] GetMinWidth
-- @return #number

---
-- Function GetMinHeight
--
-- @function [parent=#ListView] GetMinHeight
-- @return #number

---
-- Function GetMaxSize
--
-- @function [parent=#ListView] GetMaxSize
-- @return const IntVector2#const IntVector2

---
-- Function GetMaxWidth
--
-- @function [parent=#ListView] GetMaxWidth
-- @return #number

---
-- Function GetMaxHeight
--
-- @function [parent=#ListView] GetMaxHeight
-- @return #number

---
-- Function IsFixedSize
--
-- @function [parent=#ListView] IsFixedSize
-- @return #boolean

---
-- Function IsFixedWidth
--
-- @function [parent=#ListView] IsFixedWidth
-- @return #boolean

---
-- Function IsFixedHeight
--
-- @function [parent=#ListView] IsFixedHeight
-- @return #boolean

---
-- Function GetChildOffset
--
-- @function [parent=#ListView] GetChildOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetHorizontalAlignment
--
-- @function [parent=#ListView] GetHorizontalAlignment
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetVerticalAlignment
--
-- @function [parent=#ListView] GetVerticalAlignment
-- @return VerticalAlignment#VerticalAlignment

---
-- Function GetClipBorder
--
-- @function [parent=#ListView] GetClipBorder
-- @return const IntRect#const IntRect

---
-- Function GetColor
--
-- @function [parent=#ListView] GetColor
-- @param Corner#Corner cornercorner
-- @return const Color#const Color

---
-- Function GetPriority
--
-- @function [parent=#ListView] GetPriority
-- @return #number

---
-- Function GetOpacity
--
-- @function [parent=#ListView] GetOpacity
-- @return #number

---
-- Function GetDerivedOpacity
--
-- @function [parent=#ListView] GetDerivedOpacity
-- @return #number

---
-- Function GetBringToFront
--
-- @function [parent=#ListView] GetBringToFront
-- @return #boolean

---
-- Function GetBringToBack
--
-- @function [parent=#ListView] GetBringToBack
-- @return #boolean

---
-- Function GetClipChildren
--
-- @function [parent=#ListView] GetClipChildren
-- @return #boolean

---
-- Function GetSortChildren
--
-- @function [parent=#ListView] GetSortChildren
-- @return #boolean

---
-- Function GetUseDerivedOpacity
--
-- @function [parent=#ListView] GetUseDerivedOpacity
-- @return #boolean

---
-- Function HasFocus
--
-- @function [parent=#ListView] HasFocus
-- @return #boolean

---
-- Function IsEnabled
--
-- @function [parent=#ListView] IsEnabled
-- @return #boolean

---
-- Function IsEditable
--
-- @function [parent=#ListView] IsEditable
-- @return #boolean

---
-- Function IsSelected
--
-- @function [parent=#ListView] IsSelected
-- @return #boolean

---
-- Function IsVisible
--
-- @function [parent=#ListView] IsVisible
-- @return #boolean

---
-- Function IsHovering
--
-- @function [parent=#ListView] IsHovering
-- @return #boolean

---
-- Function IsInternal
--
-- @function [parent=#ListView] IsInternal
-- @return #boolean

---
-- Function HasColorGradient
--
-- @function [parent=#ListView] HasColorGradient
-- @return #boolean

---
-- Function GetFocusMode
--
-- @function [parent=#ListView] GetFocusMode
-- @return FocusMode#FocusMode

---
-- Function GetDragDropMode
--
-- @function [parent=#ListView] GetDragDropMode
-- @return #number

---
-- Function GetAppliedStyle
--
-- @function [parent=#ListView] GetAppliedStyle
-- @return const String#const String

---
-- Function GetDefaultStyle
--
-- @function [parent=#ListView] GetDefaultStyle
-- @param #boolean recursiveUprecursiveUp
-- @return XMLFile#XMLFile

---
-- Function GetLayoutMode
--
-- @function [parent=#ListView] GetLayoutMode
-- @return LayoutMode#LayoutMode

---
-- Function GetLayoutSpacing
--
-- @function [parent=#ListView] GetLayoutSpacing
-- @return #number

---
-- Function GetLayoutBorder
--
-- @function [parent=#ListView] GetLayoutBorder
-- @return const IntRect#const IntRect

---
-- Function GetNumChildren
--
-- @function [parent=#ListView] GetNumChildren
-- @param #boolean recursiverecursive
-- @return #number

---
-- Function GetChild
--
-- @function [parent=#ListView] GetChild
-- @param #string namename
-- @param #boolean recursiverecursive
-- @return UIElement#UIElement

---
-- Function GetChild
--
-- @function [parent=#ListView] GetChild
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function GetParent
--
-- @function [parent=#ListView] GetParent
-- @return UIElement#UIElement

---
-- Function GetRoot
--
-- @function [parent=#ListView] GetRoot
-- @return UIElement#UIElement

---
-- Function GetDerivedColor
--
-- @function [parent=#ListView] GetDerivedColor
-- @return const Color#const Color

---
-- Function GetVar
--
-- @function [parent=#ListView] GetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @return const Variant#const Variant

---
-- Function GetVars
--
-- @function [parent=#ListView] GetVars
-- @return const VariantMap#const VariantMap

---
-- Function ScreenToElement
--
-- @function [parent=#ListView] ScreenToElement
-- @param IntVector2#IntVector2 screenPositionscreenPosition
-- @return IntVector2#IntVector2

---
-- Function ElementToScreen
--
-- @function [parent=#ListView] ElementToScreen
-- @param IntVector2#IntVector2 positionposition
-- @return IntVector2#IntVector2

---
-- Function IsInside
--
-- @function [parent=#ListView] IsInside
-- @param IntVector2#IntVector2 positionposition
-- @param #boolean isScreenisScreen
-- @return #boolean

---
-- Function IsInsideCombined
--
-- @function [parent=#ListView] IsInsideCombined
-- @param IntVector2#IntVector2 positionposition
-- @param #boolean isScreenisScreen
-- @return #boolean

---
-- Function GetCombinedScreenRect
--
-- @function [parent=#ListView] GetCombinedScreenRect
-- @return IntRect#IntRect

---
-- Function SortChildren
--
-- @function [parent=#ListView] SortChildren

---
-- Function GetLayoutMinSize
--
-- @function [parent=#ListView] GetLayoutMinSize
-- @return #number

---
-- Function GetIndent
--
-- @function [parent=#ListView] GetIndent
-- @return #number

---
-- Function GetIndentSpacing
--
-- @function [parent=#ListView] GetIndentSpacing
-- @return #number

---
-- Function GetIndentWidth
--
-- @function [parent=#ListView] GetIndentWidth
-- @return #number

---
-- Function SetChildOffset
--
-- @function [parent=#ListView] SetChildOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetHovering
--
-- @function [parent=#ListView] SetHovering
-- @param #boolean enableenable

---
-- Function GetColor
--
-- @function [parent=#ListView] GetColor
-- @return const Color#const Color

---
-- Function GetTraversalMode
--
-- @function [parent=#ListView] GetTraversalMode
-- @return TraversalMode#TraversalMode

---
-- Function IsElementEventSender
--
-- @function [parent=#ListView] IsElementEventSender
-- @return #boolean

---
-- Function GetElementEventSender
--
-- @function [parent=#ListView] GetElementEventSender
-- @return UIElement#UIElement

---
-- Field screenPosition (Read only)
--
-- @field [parent=#ListView] IntVector2#IntVector2 screenPosition

---
-- Field name
--
-- @field [parent=#ListView] #string name

---
-- Field position
--
-- @field [parent=#ListView] IntVector2#IntVector2 position

---
-- Field size
--
-- @field [parent=#ListView] IntVector2#IntVector2 size

---
-- Field width
--
-- @field [parent=#ListView] #number width

---
-- Field height
--
-- @field [parent=#ListView] #number height

---
-- Field minSize
--
-- @field [parent=#ListView] IntVector2#IntVector2 minSize

---
-- Field minWidth
--
-- @field [parent=#ListView] #number minWidth

---
-- Field minHeight
--
-- @field [parent=#ListView] #number minHeight

---
-- Field maxSize
--
-- @field [parent=#ListView] IntVector2#IntVector2 maxSize

---
-- Field maxWidth
--
-- @field [parent=#ListView] #number maxWidth

---
-- Field maxHeight
--
-- @field [parent=#ListView] #number maxHeight

---
-- Field fixedSize (Read only)
--
-- @field [parent=#ListView] #boolean fixedSize

---
-- Field fixedWidth (Read only)
--
-- @field [parent=#ListView] #boolean fixedWidth

---
-- Field fixedHeight (Read only)
--
-- @field [parent=#ListView] #boolean fixedHeight

---
-- Field childOffset
--
-- @field [parent=#ListView] IntVector2#IntVector2 childOffset

---
-- Field horizontalAlignment
--
-- @field [parent=#ListView] HorizontalAlignment#HorizontalAlignment horizontalAlignment

---
-- Field verticalAlignment
--
-- @field [parent=#ListView] VerticalAlignment#VerticalAlignment verticalAlignment

---
-- Field clipBorder
--
-- @field [parent=#ListView] IntRect#IntRect clipBorder

---
-- Field color
--
-- @field [parent=#ListView] Color#Color color

---
-- Field priority
--
-- @field [parent=#ListView] #number priority

---
-- Field opacity
--
-- @field [parent=#ListView] #number opacity

---
-- Field derivedOpacity (Read only)
--
-- @field [parent=#ListView] #number derivedOpacity

---
-- Field bringToFront
--
-- @field [parent=#ListView] #boolean bringToFront

---
-- Field bringToBack
--
-- @field [parent=#ListView] #boolean bringToBack

---
-- Field clipChildren
--
-- @field [parent=#ListView] #boolean clipChildren

---
-- Field sortChildren
--
-- @field [parent=#ListView] #boolean sortChildren

---
-- Field useDerivedOpacity
--
-- @field [parent=#ListView] #boolean useDerivedOpacity

---
-- Field focus
--
-- @field [parent=#ListView] #boolean focus

---
-- Field enabled
--
-- @field [parent=#ListView] #boolean enabled

---
-- Field editable
--
-- @field [parent=#ListView] #boolean editable

---
-- Field selected
--
-- @field [parent=#ListView] #boolean selected

---
-- Field visible
--
-- @field [parent=#ListView] #boolean visible

---
-- Field hovering
--
-- @field [parent=#ListView] #boolean hovering

---
-- Field internal
--
-- @field [parent=#ListView] #boolean internal

---
-- Field colorGradient (Read only)
--
-- @field [parent=#ListView] #boolean colorGradient

---
-- Field focusMode
--
-- @field [parent=#ListView] FocusMode#FocusMode focusMode

---
-- Field dragDropMode
--
-- @field [parent=#ListView] #number dragDropMode

---
-- Field style
--
-- @field [parent=#ListView] #string style

---
-- Field defaultStyle
--
-- @field [parent=#ListView] XMLFile#XMLFile defaultStyle

---
-- Field layoutMode
--
-- @field [parent=#ListView] LayoutMode#LayoutMode layoutMode

---
-- Field layoutSpacing
--
-- @field [parent=#ListView] #number layoutSpacing

---
-- Field layoutBorder
--
-- @field [parent=#ListView] IntRect#IntRect layoutBorder

---
-- Field numChildren (Read only)
--
-- @field [parent=#ListView] #number numChildren

---
-- Field parent
--
-- @field [parent=#ListView] UIElement#UIElement parent

---
-- Field root (Read only)
--
-- @field [parent=#ListView] UIElement#UIElement root

---
-- Field derivedColor (Read only)
--
-- @field [parent=#ListView] Color#Color derivedColor

---
-- Field combinedScreenRect (Read only)
--
-- @field [parent=#ListView] IntRect#IntRect combinedScreenRect

---
-- Field layoutMinSize (Read only)
--
-- @field [parent=#ListView] #number layoutMinSize

---
-- Field indent
--
-- @field [parent=#ListView] #number indent

---
-- Field indentSpacing
--
-- @field [parent=#ListView] #number indentSpacing

---
-- Field indentWidth (Read only)
--
-- @field [parent=#ListView] #number indentWidth

---
-- Field traversalMode
--
-- @field [parent=#ListView] TraversalMode#TraversalMode traversalMode

---
-- Field elementEventSender
--
-- @field [parent=#ListView] #boolean elementEventSender

---
-- Function SetTemporary
--
-- @function [parent=#ListView] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#ListView] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#ListView] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#ListView] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#ListView] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#ListView] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#ListView] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#ListView] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#ListView] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#ListView] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#ListView] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#ListView] #string category


return nil
