---
-- Module ListView
-- Module ListView extends ScrollView
-- Generated on 2014-05-31
--
-- @module ListView

---
-- Function ListView()
--
-- @function [parent=#ListView] ListView
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#ListView] new
-- @param self Self reference
-- @return ListView#ListView

---
-- Function delete()
--
-- @function [parent=#ListView] delete
-- @param self Self reference

---
-- Function AddItem()
-- Add item to the end of the list.
--
-- @function [parent=#ListView] AddItem
-- @param self Self reference
-- @param UIElement#UIElement item item

---
-- Function InsertItem()
-- And if the index is lesser than the index of the parent item itself then the new item is inserted before the first child item.
--
-- @function [parent=#ListView] InsertItem
-- @param self Self reference
-- @param #number index index
-- @param UIElement#UIElement item item
-- @param UIElement#UIElement parentItem parentItem

---
-- Function RemoveItem()
-- Remove specific item, starting search at the specified index if provided. In hierarchy mode will also remove any children.
--
-- @function [parent=#ListView] RemoveItem
-- @param self Self reference
-- @param UIElement#UIElement item item
-- @param #number index index

---
-- Function RemoveItem()
-- Remove item at index. In hierarchy mode will also remove any children.
--
-- @function [parent=#ListView] RemoveItem
-- @param self Self reference
-- @param #number index index

---
-- Function RemoveAllItems()
-- Remove all items.
--
-- @function [parent=#ListView] RemoveAllItems
-- @param self Self reference

---
-- Function SetSelection()
-- Set selection.
--
-- @function [parent=#ListView] SetSelection
-- @param self Self reference
-- @param #number index index

---
-- Function SetSelections()
--
-- @function [parent=#ListView] SetSelections
-- @param self Self reference
-- @param PODVector<unsigned>#PODVector<unsigned> indices indices

---
-- Function AddSelection()
-- Add item to the selection, multiselect mode only.
--
-- @function [parent=#ListView] AddSelection
-- @param self Self reference
-- @param #number index index

---
-- Function RemoveSelection()
-- Remove item from the selection.
--
-- @function [parent=#ListView] RemoveSelection
-- @param self Self reference
-- @param #number index index

---
-- Function ToggleSelection()
-- Toggle selection of an item.
--
-- @function [parent=#ListView] ToggleSelection
-- @param self Self reference
-- @param #number index index

---
-- Function ChangeSelection()
-- Move selection by a delta and clamp at list ends. If additive (multiselect only), will add to the existing selection.
--
-- @function [parent=#ListView] ChangeSelection
-- @param self Self reference
-- @param #number delta delta
-- @param #boolean additive additive

---
-- Function ClearSelection()
-- Clear selection.
--
-- @function [parent=#ListView] ClearSelection
-- @param self Self reference

---
-- Function SetHighlightMode()
-- Set selected items' highlight mode.
--
-- @function [parent=#ListView] SetHighlightMode
-- @param self Self reference
-- @param HighlightMode#HighlightMode mode mode

---
-- Function SetMultiselect()
-- Enable multiselect.
--
-- @function [parent=#ListView] SetMultiselect
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetHierarchyMode()
-- All items in the list will be lost during mode change.
--
-- @function [parent=#ListView] SetHierarchyMode
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetBaseIndent()
-- Set base indent, i.e. the indent level of the ultimate parent item.
--
-- @function [parent=#ListView] SetBaseIndent
-- @param self Self reference
-- @param #number baseIndent baseIndent

---
-- Function SetClearSelectionOnDefocus()
-- Enable clearing of selection on defocus.
--
-- @function [parent=#ListView] SetClearSelectionOnDefocus
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetSelectOnClickEnd()
-- Enable reacting to click end instead of click start for item selection. Default false.
--
-- @function [parent=#ListView] SetSelectOnClickEnd
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Expand()
-- Expand item at index. Only has effect in hierarchy mode.
--
-- @function [parent=#ListView] Expand
-- @param self Self reference
-- @param #number index index
-- @param #boolean enable enable
-- @param #boolean recursive recursive

---
-- Function ToggleExpand()
-- Toggle item's expanded flag at index. Only has effect in hierarchy mode.
--
-- @function [parent=#ListView] ToggleExpand
-- @param self Self reference
-- @param #number index index
-- @param #boolean recursive recursive

---
-- Function GetNumItems()
-- Return number of items.
--
-- @function [parent=#ListView] GetNumItems
-- @param self Self reference
-- @return #number

---
-- Function GetItem()
-- Return item at index.
--
-- @function [parent=#ListView] GetItem
-- @param self Self reference
-- @param #number index index
-- @return UIElement#UIElement

---
-- Function GetItems()
-- Return all items.
--
-- @function [parent=#ListView] GetItems
-- @param self Self reference
-- @return const PODVector<UIElement*>#const PODVector<UIElement*>

---
-- Function FindItem()
-- Return index of item, or M_MAX_UNSIGNED If not found.
--
-- @function [parent=#ListView] FindItem
-- @param self Self reference
-- @param UIElement#UIElement item item
-- @return #number

---
-- Function GetSelection()
-- Return first selected index, or M_MAX_UNSIGNED if none selected.
--
-- @function [parent=#ListView] GetSelection
-- @param self Self reference
-- @return #number

---
-- Function GetSelections()
-- Return all selected indices.
--
-- @function [parent=#ListView] GetSelections
-- @param self Self reference
-- @return const PODVector<unsigned>#const PODVector<unsigned>

---
-- Function CopySelectedItemsToClipboard()
-- Copy selected items to system clipboard. Currently only applicable to Text items.
--
-- @function [parent=#ListView] CopySelectedItemsToClipboard
-- @param self Self reference

---
-- Function GetSelectedItem()
-- Return first selected item, or null if none selected.
--
-- @function [parent=#ListView] GetSelectedItem
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetSelectedItems()
-- Return all selected items.
--
-- @function [parent=#ListView] GetSelectedItems
-- @param self Self reference
-- @return const PODVector<UIElement*>#const PODVector<UIElement*>

---
-- Function IsSelected()
-- Return whether an item at index is seleccted.
--
-- @function [parent=#ListView] IsSelected
-- @param self Self reference
-- @param #number index index
-- @return #boolean

---
-- Function IsExpanded()
-- Return whether an item at index has its children expanded (in hierachy mode only).
--
-- @function [parent=#ListView] IsExpanded
-- @param self Self reference
-- @param #number index index
-- @return #boolean

---
-- Function GetHighlightMode()
-- Return highlight mode.
--
-- @function [parent=#ListView] GetHighlightMode
-- @param self Self reference
-- @return HighlightMode#HighlightMode

---
-- Function GetMultiselect()
-- Return whether multiselect enabled.
--
-- @function [parent=#ListView] GetMultiselect
-- @param self Self reference
-- @return #boolean

---
-- Function GetClearSelectionOnDefocus()
-- Return whether selection is cleared on defocus.
--
-- @function [parent=#ListView] GetClearSelectionOnDefocus
-- @param self Self reference
-- @return #boolean

---
-- Function GetSelectOnClickEnd()
-- Return whether reacts to click end instead of click start for item selection.
--
-- @function [parent=#ListView] GetSelectOnClickEnd
-- @param self Self reference
-- @return #boolean

---
-- Function GetHierarchyMode()
-- Return whether hierarchy mode enabled.
--
-- @function [parent=#ListView] GetHierarchyMode
-- @param self Self reference
-- @return #boolean

---
-- Function GetBaseIndent()
-- Return base indent.
--
-- @function [parent=#ListView] GetBaseIndent
-- @param self Self reference
-- @return #number

---
-- Field numItems (Read only)
--
-- @field [parent=#ListView] #number numItems

---
-- Field selection
--
-- @field [parent=#ListView] #number selection

---
-- Field selectedItem (Read only)
--
-- @field [parent=#ListView] UIElement#UIElement selectedItem

---
-- Field highlightMode
--
-- @field [parent=#ListView] HighlightMode#HighlightMode highlightMode

---
-- Field multiselect
--
-- @field [parent=#ListView] #boolean multiselect

---
-- Field clearSelectionOnDefocus
--
-- @field [parent=#ListView] #boolean clearSelectionOnDefocus

---
-- Field selectOnClickEnd
--
-- @field [parent=#ListView] #boolean selectOnClickEnd

---
-- Field hierarchyMode
--
-- @field [parent=#ListView] #boolean hierarchyMode

---
-- Field baseIndent
--
-- @field [parent=#ListView] #number baseIndent


return nil
