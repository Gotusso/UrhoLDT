---
-- Module ListView
-- Module ListView extends ScrollView
-- Generated on 2014-03-13
--
-- @module ListView

---
-- Function ListView
--
-- @function [parent=#ListView] ListView
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#ListView] new
-- @param self Self reference
-- @return ListView#ListView

---
-- Function delete
--
-- @function [parent=#ListView] delete
-- @param self Self reference

---
-- Function AddItem
--
-- @function [parent=#ListView] AddItem
-- @param self Self reference
-- @param UIElement#UIElement item item

---
-- Function InsertItem
--
-- @function [parent=#ListView] InsertItem
-- @param self Self reference
-- @param #number index index
-- @param UIElement#UIElement item item
-- @param UIElement#UIElement parentItem parentItem

---
-- Function RemoveItem
--
-- @function [parent=#ListView] RemoveItem
-- @param self Self reference
-- @param UIElement#UIElement item item
-- @param #number index index

---
-- Function RemoveItem
--
-- @function [parent=#ListView] RemoveItem
-- @param self Self reference
-- @param #number index index

---
-- Function RemoveAllItems
--
-- @function [parent=#ListView] RemoveAllItems
-- @param self Self reference

---
-- Function SetSelection
--
-- @function [parent=#ListView] SetSelection
-- @param self Self reference
-- @param #number index index

---
-- Function SetSelections
--
-- @function [parent=#ListView] SetSelections
-- @param self Self reference
-- @param PODVector<unsigned>#PODVector<unsigned> indices indices

---
-- Function AddSelection
--
-- @function [parent=#ListView] AddSelection
-- @param self Self reference
-- @param #number index index

---
-- Function RemoveSelection
--
-- @function [parent=#ListView] RemoveSelection
-- @param self Self reference
-- @param #number index index

---
-- Function ToggleSelection
--
-- @function [parent=#ListView] ToggleSelection
-- @param self Self reference
-- @param #number index index

---
-- Function ChangeSelection
--
-- @function [parent=#ListView] ChangeSelection
-- @param self Self reference
-- @param #number delta delta
-- @param #boolean additive additive

---
-- Function ClearSelection
--
-- @function [parent=#ListView] ClearSelection
-- @param self Self reference

---
-- Function SetHighlightMode
--
-- @function [parent=#ListView] SetHighlightMode
-- @param self Self reference
-- @param HighlightMode#HighlightMode mode mode

---
-- Function SetMultiselect
--
-- @function [parent=#ListView] SetMultiselect
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetHierarchyMode
--
-- @function [parent=#ListView] SetHierarchyMode
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetBaseIndent
--
-- @function [parent=#ListView] SetBaseIndent
-- @param self Self reference
-- @param #number baseIndent baseIndent

---
-- Function SetClearSelectionOnDefocus
--
-- @function [parent=#ListView] SetClearSelectionOnDefocus
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Expand
--
-- @function [parent=#ListView] Expand
-- @param self Self reference
-- @param #number index index
-- @param #boolean enable enable
-- @param #boolean recursive recursive

---
-- Function ToggleExpand
--
-- @function [parent=#ListView] ToggleExpand
-- @param self Self reference
-- @param #number index index
-- @param #boolean recursive recursive

---
-- Function GetNumItems
--
-- @function [parent=#ListView] GetNumItems
-- @param self Self reference
-- @return #number

---
-- Function GetItem
--
-- @function [parent=#ListView] GetItem
-- @param self Self reference
-- @param #number index index
-- @return UIElement#UIElement

---
-- Function GetItems
--
-- @function [parent=#ListView] GetItems
-- @param self Self reference
-- @return const PODVector<UIElement*>#const PODVector<UIElement*>

---
-- Function FindItem
--
-- @function [parent=#ListView] FindItem
-- @param self Self reference
-- @param UIElement#UIElement item item
-- @return #number

---
-- Function GetSelection
--
-- @function [parent=#ListView] GetSelection
-- @param self Self reference
-- @return #number

---
-- Function GetSelections
--
-- @function [parent=#ListView] GetSelections
-- @param self Self reference
-- @return const PODVector<unsigned>#const PODVector<unsigned>

---
-- Function GetSelectedItem
--
-- @function [parent=#ListView] GetSelectedItem
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetSelectedItems
--
-- @function [parent=#ListView] GetSelectedItems
-- @param self Self reference
-- @return const PODVector<UIElement*>#const PODVector<UIElement*>

---
-- Function IsSelected
--
-- @function [parent=#ListView] IsSelected
-- @param self Self reference
-- @param #number index index
-- @return #boolean

---
-- Function IsExpanded
--
-- @function [parent=#ListView] IsExpanded
-- @param self Self reference
-- @param #number index index
-- @return #boolean

---
-- Function GetHighlightMode
--
-- @function [parent=#ListView] GetHighlightMode
-- @param self Self reference
-- @return HighlightMode#HighlightMode

---
-- Function GetMultiselect
--
-- @function [parent=#ListView] GetMultiselect
-- @param self Self reference
-- @return #boolean

---
-- Function GetClearSelectionOnDefocus
--
-- @function [parent=#ListView] GetClearSelectionOnDefocus
-- @param self Self reference
-- @return #boolean

---
-- Function GetHierarchyMode
--
-- @function [parent=#ListView] GetHierarchyMode
-- @param self Self reference
-- @return #boolean

---
-- Function GetBaseIndent
--
-- @function [parent=#ListView] GetBaseIndent
-- @param self Self reference
-- @return #number

---
-- Field numItems (Read only)
--
-- @field [parent=#ListView] #number numItems

---
-- Field selection
--
-- @field [parent=#ListView] #number selection

---
-- Field selectedItem (Read only)
--
-- @field [parent=#ListView] UIElement#UIElement selectedItem

---
-- Field highlightMode
--
-- @field [parent=#ListView] HighlightMode#HighlightMode highlightMode

---
-- Field multiselect
--
-- @field [parent=#ListView] #boolean multiselect

---
-- Field clearSelectionOnDefocus
--
-- @field [parent=#ListView] #boolean clearSelectionOnDefocus

---
-- Field hierarchyMode
--
-- @field [parent=#ListView] #boolean hierarchyMode

---
-- Field baseIndent
--
-- @field [parent=#ListView] #number baseIndent

---
-- Function ScrollView
--
-- @function [parent=#ListView] ScrollView
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#ListView] new
-- @param self Self reference
-- @return ScrollView#ScrollView

---
-- Function delete
--
-- @function [parent=#ListView] delete
-- @param self Self reference

---
-- Function SetContentElement
--
-- @function [parent=#ListView] SetContentElement
-- @param self Self reference
-- @param UIElement#UIElement element element

---
-- Function SetViewPosition
--
-- @function [parent=#ListView] SetViewPosition
-- @param self Self reference
-- @param IntVector2#IntVector2 position position

---
-- Function SetViewPosition
--
-- @function [parent=#ListView] SetViewPosition
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function SetScrollBarsVisible
--
-- @function [parent=#ListView] SetScrollBarsVisible
-- @param self Self reference
-- @param #boolean horizontal horizontal
-- @param #boolean vertical vertical

---
-- Function SetScrollBarsAutoVisible
--
-- @function [parent=#ListView] SetScrollBarsAutoVisible
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetScrollStep
--
-- @function [parent=#ListView] SetScrollStep
-- @param self Self reference
-- @param #number step step

---
-- Function SetPageStep
--
-- @function [parent=#ListView] SetPageStep
-- @param self Self reference
-- @param #number step step

---
-- Function GetViewPosition
--
-- @function [parent=#ListView] GetViewPosition
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetContentElement
--
-- @function [parent=#ListView] GetContentElement
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetHorizontalScrollBar
--
-- @function [parent=#ListView] GetHorizontalScrollBar
-- @param self Self reference
-- @return ScrollBar#ScrollBar

---
-- Function GetVerticalScrollBar
--
-- @function [parent=#ListView] GetVerticalScrollBar
-- @param self Self reference
-- @return ScrollBar#ScrollBar

---
-- Function GetScrollPanel
--
-- @function [parent=#ListView] GetScrollPanel
-- @param self Self reference
-- @return BorderImage#BorderImage

---
-- Function GetScrollBarsAutoVisible
--
-- @function [parent=#ListView] GetScrollBarsAutoVisible
-- @param self Self reference
-- @return #boolean

---
-- Function GetScrollStep
--
-- @function [parent=#ListView] GetScrollStep
-- @param self Self reference
-- @return #number

---
-- Function GetPageStep
--
-- @function [parent=#ListView] GetPageStep
-- @param self Self reference
-- @return #number

---
-- Field viewPosition
--
-- @field [parent=#ListView] IntVector2#IntVector2 viewPosition

---
-- Field contentElement
--
-- @field [parent=#ListView] UIElement#UIElement contentElement

---
-- Field horizontalScrollBar (Read only)
--
-- @field [parent=#ListView] ScrollBar#ScrollBar horizontalScrollBar

---
-- Field verticalScrollBar (Read only)
--
-- @field [parent=#ListView] ScrollBar#ScrollBar verticalScrollBar

---
-- Field scrollPanel (Read only)
--
-- @field [parent=#ListView] BorderImage#BorderImage scrollPanel

---
-- Field scrollBarsAutoVisible
--
-- @field [parent=#ListView] #boolean scrollBarsAutoVisible

---
-- Field scrollStep
--
-- @field [parent=#ListView] #number scrollStep

---
-- Field pageStep
--
-- @field [parent=#ListView] #number pageStep

---
-- Function UIElement
--
-- @function [parent=#ListView] UIElement
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#ListView] new
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function delete
--
-- @function [parent=#ListView] delete
-- @param self Self reference

---
-- Function GetScreenPosition
--
-- @function [parent=#ListView] GetScreenPosition
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function LoadXML
--
-- @function [parent=#ListView] LoadXML
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#ListView] SaveXML
-- @param self Self reference
-- @param Serializer#Serializer dest dest
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#ListView] LoadXML
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#ListView] SaveXML
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function FilterAttributes
--
-- @function [parent=#ListView] FilterAttributes
-- @param self Self reference
-- @param XMLElement#XMLElement dest dest
-- @return #boolean

---
-- Function SetName
--
-- @function [parent=#ListView] SetName
-- @param self Self reference
-- @param #string name name

---
-- Function SetPosition
--
-- @function [parent=#ListView] SetPosition
-- @param self Self reference
-- @param IntVector2#IntVector2 position position

---
-- Function SetPosition
--
-- @function [parent=#ListView] SetPosition
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function SetSize
--
-- @function [parent=#ListView] SetSize
-- @param self Self reference
-- @param IntVector2#IntVector2 size size

---
-- Function SetSize
--
-- @function [parent=#ListView] SetSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetWidth
--
-- @function [parent=#ListView] SetWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetHeight
--
-- @function [parent=#ListView] SetHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetMinSize
--
-- @function [parent=#ListView] SetMinSize
-- @param self Self reference
-- @param IntVector2#IntVector2 minSize minSize

---
-- Function SetMinSize
--
-- @function [parent=#ListView] SetMinSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetMinWidth
--
-- @function [parent=#ListView] SetMinWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetMinHeight
--
-- @function [parent=#ListView] SetMinHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetMaxSize
--
-- @function [parent=#ListView] SetMaxSize
-- @param self Self reference
-- @param IntVector2#IntVector2 maxSize maxSize

---
-- Function SetMaxSize
--
-- @function [parent=#ListView] SetMaxSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetMaxWidth
--
-- @function [parent=#ListView] SetMaxWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetMaxHeight
--
-- @function [parent=#ListView] SetMaxHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetFixedSize
--
-- @function [parent=#ListView] SetFixedSize
-- @param self Self reference
-- @param IntVector2#IntVector2 size size

---
-- Function SetFixedSize
--
-- @function [parent=#ListView] SetFixedSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetFixedWidth
--
-- @function [parent=#ListView] SetFixedWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetFixedHeight
--
-- @function [parent=#ListView] SetFixedHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetAlignment
--
-- @function [parent=#ListView] SetAlignment
-- @param self Self reference
-- @param HorizontalAlignment#HorizontalAlignment hAlign hAlign
-- @param VerticalAlignment#VerticalAlignment vAlign vAlign

---
-- Function SetHorizontalAlignment
--
-- @function [parent=#ListView] SetHorizontalAlignment
-- @param self Self reference
-- @param HorizontalAlignment#HorizontalAlignment align align

---
-- Function SetVerticalAlignment
--
-- @function [parent=#ListView] SetVerticalAlignment
-- @param self Self reference
-- @param VerticalAlignment#VerticalAlignment align align

---
-- Function SetClipBorder
--
-- @function [parent=#ListView] SetClipBorder
-- @param self Self reference
-- @param IntRect#IntRect rect rect

---
-- Function SetColor
--
-- @function [parent=#ListView] SetColor
-- @param self Self reference
-- @param Color#Color color color

---
-- Function SetColor
--
-- @function [parent=#ListView] SetColor
-- @param self Self reference
-- @param Corner#Corner corner corner
-- @param Color#Color color color

---
-- Function SetPriority
--
-- @function [parent=#ListView] SetPriority
-- @param self Self reference
-- @param #number priority priority

---
-- Function SetOpacity
--
-- @function [parent=#ListView] SetOpacity
-- @param self Self reference
-- @param #number opacity opacity

---
-- Function SetBringToFront
--
-- @function [parent=#ListView] SetBringToFront
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetBringToBack
--
-- @function [parent=#ListView] SetBringToBack
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetClipChildren
--
-- @function [parent=#ListView] SetClipChildren
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetSortChildren
--
-- @function [parent=#ListView] SetSortChildren
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetUseDerivedOpacity
--
-- @function [parent=#ListView] SetUseDerivedOpacity
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetEnabled
--
-- @function [parent=#ListView] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetEditable
--
-- @function [parent=#ListView] SetEditable
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetFocus
--
-- @function [parent=#ListView] SetFocus
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetSelected
--
-- @function [parent=#ListView] SetSelected
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetVisible
--
-- @function [parent=#ListView] SetVisible
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetFocusMode
--
-- @function [parent=#ListView] SetFocusMode
-- @param self Self reference
-- @param FocusMode#FocusMode mode mode

---
-- Function SetDragDropMode
--
-- @function [parent=#ListView] SetDragDropMode
-- @param self Self reference
-- @param #number mode mode

---
-- Function SetStyle
--
-- @function [parent=#ListView] SetStyle
-- @param self Self reference
-- @param #string styleName styleName
-- @param XMLFile#XMLFile file file
-- @return #boolean

---
-- Function SetStyle
--
-- @function [parent=#ListView] SetStyle
-- @param self Self reference
-- @param XMLElement#XMLElement element element
-- @return #boolean

---
-- Function SetStyleAuto
--
-- @function [parent=#ListView] SetStyleAuto
-- @param self Self reference
-- @param XMLFile#XMLFile file file
-- @return #boolean

---
-- Function SetDefaultStyle
--
-- @function [parent=#ListView] SetDefaultStyle
-- @param self Self reference
-- @param XMLFile#XMLFile style style

---
-- Function SetLayout
--
-- @function [parent=#ListView] SetLayout
-- @param self Self reference
-- @param LayoutMode#LayoutMode mode mode
-- @param #number spacing spacing

---
-- Function SetLayout
--
-- @function [parent=#ListView] SetLayout
-- @param self Self reference
-- @param LayoutMode#LayoutMode mode mode
-- @param #number spacing spacing
-- @param IntRect#IntRect border border

---
-- Function SetLayoutMode
--
-- @function [parent=#ListView] SetLayoutMode
-- @param self Self reference
-- @param LayoutMode#LayoutMode mode mode

---
-- Function SetLayoutSpacing
--
-- @function [parent=#ListView] SetLayoutSpacing
-- @param self Self reference
-- @param #number spacing spacing

---
-- Function SetLayoutBorder
--
-- @function [parent=#ListView] SetLayoutBorder
-- @param self Self reference
-- @param IntRect#IntRect border border

---
-- Function SetIndent
--
-- @function [parent=#ListView] SetIndent
-- @param self Self reference
-- @param #number indent indent

---
-- Function SetIndentSpacing
--
-- @function [parent=#ListView] SetIndentSpacing
-- @param self Self reference
-- @param #number indentSpacing indentSpacing

---
-- Function UpdateLayout
--
-- @function [parent=#ListView] UpdateLayout
-- @param self Self reference

---
-- Function DisableLayoutUpdate
--
-- @function [parent=#ListView] DisableLayoutUpdate
-- @param self Self reference

---
-- Function EnableLayoutUpdate
--
-- @function [parent=#ListView] EnableLayoutUpdate
-- @param self Self reference

---
-- Function BringToFront
--
-- @function [parent=#ListView] BringToFront
-- @param self Self reference

---
-- Function CreateChild
--
-- @function [parent=#ListView] CreateChild
-- @param self Self reference
-- @param #string type type
-- @param #string name name
-- @param #number index index
-- @return UIElement#UIElement

---
-- Function AddChild
--
-- @function [parent=#ListView] AddChild
-- @param self Self reference
-- @param UIElement#UIElement element element

---
-- Function InsertChild
--
-- @function [parent=#ListView] InsertChild
-- @param self Self reference
-- @param #number index index
-- @param UIElement#UIElement element element

---
-- Function RemoveChild
--
-- @function [parent=#ListView] RemoveChild
-- @param self Self reference
-- @param UIElement#UIElement element element
-- @param #number index index

---
-- Function RemoveChildAtIndex
--
-- @function [parent=#ListView] RemoveChildAtIndex
-- @param self Self reference
-- @param #number index index

---
-- Function RemoveAllChildren
--
-- @function [parent=#ListView] RemoveAllChildren
-- @param self Self reference

---
-- Function Remove
--
-- @function [parent=#ListView] Remove
-- @param self Self reference

---
-- Function FindChild
--
-- @function [parent=#ListView] FindChild
-- @param self Self reference
-- @param UIElement#UIElement element element
-- @return #number

---
-- Function SetParent
--
-- @function [parent=#ListView] SetParent
-- @param self Self reference
-- @param UIElement#UIElement parent parent
-- @param #number index index

---
-- Function SetVar
--
-- @function [parent=#ListView] SetVar
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash key key
-- @param Variant#Variant value value

---
-- Function SetInternal
--
-- @function [parent=#ListView] SetInternal
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetTraversalMode
--
-- @function [parent=#ListView] SetTraversalMode
-- @param self Self reference
-- @param TraversalMode#TraversalMode traversalMode traversalMode

---
-- Function SetElementEventSender
--
-- @function [parent=#ListView] SetElementEventSender
-- @param self Self reference
-- @param #boolean flag flag

---
-- Function GetName
--
-- @function [parent=#ListView] GetName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetPosition
--
-- @function [parent=#ListView] GetPosition
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetSize
--
-- @function [parent=#ListView] GetSize
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetWidth
--
-- @function [parent=#ListView] GetWidth
-- @param self Self reference
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#ListView] GetHeight
-- @param self Self reference
-- @return #number

---
-- Function GetMinSize
--
-- @function [parent=#ListView] GetMinSize
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetMinWidth
--
-- @function [parent=#ListView] GetMinWidth
-- @param self Self reference
-- @return #number

---
-- Function GetMinHeight
--
-- @function [parent=#ListView] GetMinHeight
-- @param self Self reference
-- @return #number

---
-- Function GetMaxSize
--
-- @function [parent=#ListView] GetMaxSize
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetMaxWidth
--
-- @function [parent=#ListView] GetMaxWidth
-- @param self Self reference
-- @return #number

---
-- Function GetMaxHeight
--
-- @function [parent=#ListView] GetMaxHeight
-- @param self Self reference
-- @return #number

---
-- Function IsFixedSize
--
-- @function [parent=#ListView] IsFixedSize
-- @param self Self reference
-- @return #boolean

---
-- Function IsFixedWidth
--
-- @function [parent=#ListView] IsFixedWidth
-- @param self Self reference
-- @return #boolean

---
-- Function IsFixedHeight
--
-- @function [parent=#ListView] IsFixedHeight
-- @param self Self reference
-- @return #boolean

---
-- Function GetChildOffset
--
-- @function [parent=#ListView] GetChildOffset
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetHorizontalAlignment
--
-- @function [parent=#ListView] GetHorizontalAlignment
-- @param self Self reference
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetVerticalAlignment
--
-- @function [parent=#ListView] GetVerticalAlignment
-- @param self Self reference
-- @return VerticalAlignment#VerticalAlignment

---
-- Function GetClipBorder
--
-- @function [parent=#ListView] GetClipBorder
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetColor
--
-- @function [parent=#ListView] GetColor
-- @param self Self reference
-- @param Corner#Corner corner corner
-- @return const Color#const Color

---
-- Function GetPriority
--
-- @function [parent=#ListView] GetPriority
-- @param self Self reference
-- @return #number

---
-- Function GetOpacity
--
-- @function [parent=#ListView] GetOpacity
-- @param self Self reference
-- @return #number

---
-- Function GetDerivedOpacity
--
-- @function [parent=#ListView] GetDerivedOpacity
-- @param self Self reference
-- @return #number

---
-- Function GetBringToFront
--
-- @function [parent=#ListView] GetBringToFront
-- @param self Self reference
-- @return #boolean

---
-- Function GetBringToBack
--
-- @function [parent=#ListView] GetBringToBack
-- @param self Self reference
-- @return #boolean

---
-- Function GetClipChildren
--
-- @function [parent=#ListView] GetClipChildren
-- @param self Self reference
-- @return #boolean

---
-- Function GetSortChildren
--
-- @function [parent=#ListView] GetSortChildren
-- @param self Self reference
-- @return #boolean

---
-- Function GetUseDerivedOpacity
--
-- @function [parent=#ListView] GetUseDerivedOpacity
-- @param self Self reference
-- @return #boolean

---
-- Function HasFocus
--
-- @function [parent=#ListView] HasFocus
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabled
--
-- @function [parent=#ListView] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEditable
--
-- @function [parent=#ListView] IsEditable
-- @param self Self reference
-- @return #boolean

---
-- Function IsSelected
--
-- @function [parent=#ListView] IsSelected
-- @param self Self reference
-- @return #boolean

---
-- Function IsVisible
--
-- @function [parent=#ListView] IsVisible
-- @param self Self reference
-- @return #boolean

---
-- Function IsHovering
--
-- @function [parent=#ListView] IsHovering
-- @param self Self reference
-- @return #boolean

---
-- Function IsInternal
--
-- @function [parent=#ListView] IsInternal
-- @param self Self reference
-- @return #boolean

---
-- Function HasColorGradient
--
-- @function [parent=#ListView] HasColorGradient
-- @param self Self reference
-- @return #boolean

---
-- Function GetFocusMode
--
-- @function [parent=#ListView] GetFocusMode
-- @param self Self reference
-- @return FocusMode#FocusMode

---
-- Function GetDragDropMode
--
-- @function [parent=#ListView] GetDragDropMode
-- @param self Self reference
-- @return #number

---
-- Function GetAppliedStyle
--
-- @function [parent=#ListView] GetAppliedStyle
-- @param self Self reference
-- @return const String#const String

---
-- Function GetDefaultStyle
--
-- @function [parent=#ListView] GetDefaultStyle
-- @param self Self reference
-- @param #boolean recursiveUp recursiveUp
-- @return XMLFile#XMLFile

---
-- Function GetLayoutMode
--
-- @function [parent=#ListView] GetLayoutMode
-- @param self Self reference
-- @return LayoutMode#LayoutMode

---
-- Function GetLayoutSpacing
--
-- @function [parent=#ListView] GetLayoutSpacing
-- @param self Self reference
-- @return #number

---
-- Function GetLayoutBorder
--
-- @function [parent=#ListView] GetLayoutBorder
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetNumChildren
--
-- @function [parent=#ListView] GetNumChildren
-- @param self Self reference
-- @param #boolean recursive recursive
-- @return #number

---
-- Function GetChild
--
-- @function [parent=#ListView] GetChild
-- @param self Self reference
-- @param #string name name
-- @param #boolean recursive recursive
-- @return UIElement#UIElement

---
-- Function GetChild
--
-- @function [parent=#ListView] GetChild
-- @param self Self reference
-- @param #number index index
-- @return UIElement#UIElement

---
-- Function GetParent
--
-- @function [parent=#ListView] GetParent
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetRoot
--
-- @function [parent=#ListView] GetRoot
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetDerivedColor
--
-- @function [parent=#ListView] GetDerivedColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetVar
--
-- @function [parent=#ListView] GetVar
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash key key
-- @return const Variant#const Variant

---
-- Function GetVars
--
-- @function [parent=#ListView] GetVars
-- @param self Self reference
-- @return const VariantMap#const VariantMap

---
-- Function ScreenToElement
--
-- @function [parent=#ListView] ScreenToElement
-- @param self Self reference
-- @param IntVector2#IntVector2 screenPosition screenPosition
-- @return IntVector2#IntVector2

---
-- Function ElementToScreen
--
-- @function [parent=#ListView] ElementToScreen
-- @param self Self reference
-- @param IntVector2#IntVector2 position position
-- @return IntVector2#IntVector2

---
-- Function IsInside
--
-- @function [parent=#ListView] IsInside
-- @param self Self reference
-- @param IntVector2#IntVector2 position position
-- @param #boolean isScreen isScreen
-- @return #boolean

---
-- Function IsInsideCombined
--
-- @function [parent=#ListView] IsInsideCombined
-- @param self Self reference
-- @param IntVector2#IntVector2 position position
-- @param #boolean isScreen isScreen
-- @return #boolean

---
-- Function GetCombinedScreenRect
--
-- @function [parent=#ListView] GetCombinedScreenRect
-- @param self Self reference
-- @return IntRect#IntRect

---
-- Function SortChildren
--
-- @function [parent=#ListView] SortChildren
-- @param self Self reference

---
-- Function GetLayoutMinSize
--
-- @function [parent=#ListView] GetLayoutMinSize
-- @param self Self reference
-- @return #number

---
-- Function GetIndent
--
-- @function [parent=#ListView] GetIndent
-- @param self Self reference
-- @return #number

---
-- Function GetIndentSpacing
--
-- @function [parent=#ListView] GetIndentSpacing
-- @param self Self reference
-- @return #number

---
-- Function GetIndentWidth
--
-- @function [parent=#ListView] GetIndentWidth
-- @param self Self reference
-- @return #number

---
-- Function SetChildOffset
--
-- @function [parent=#ListView] SetChildOffset
-- @param self Self reference
-- @param IntVector2#IntVector2 offset offset

---
-- Function SetHovering
--
-- @function [parent=#ListView] SetHovering
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function GetColor
--
-- @function [parent=#ListView] GetColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetTraversalMode
--
-- @function [parent=#ListView] GetTraversalMode
-- @param self Self reference
-- @return TraversalMode#TraversalMode

---
-- Function IsElementEventSender
--
-- @function [parent=#ListView] IsElementEventSender
-- @param self Self reference
-- @return #boolean

---
-- Function GetElementEventSender
--
-- @function [parent=#ListView] GetElementEventSender
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Field screenPosition (Read only)
--
-- @field [parent=#ListView] IntVector2#IntVector2 screenPosition

---
-- Field name
--
-- @field [parent=#ListView] #string name

---
-- Field position
--
-- @field [parent=#ListView] IntVector2#IntVector2 position

---
-- Field size
--
-- @field [parent=#ListView] IntVector2#IntVector2 size

---
-- Field width
--
-- @field [parent=#ListView] #number width

---
-- Field height
--
-- @field [parent=#ListView] #number height

---
-- Field minSize
--
-- @field [parent=#ListView] IntVector2#IntVector2 minSize

---
-- Field minWidth
--
-- @field [parent=#ListView] #number minWidth

---
-- Field minHeight
--
-- @field [parent=#ListView] #number minHeight

---
-- Field maxSize
--
-- @field [parent=#ListView] IntVector2#IntVector2 maxSize

---
-- Field maxWidth
--
-- @field [parent=#ListView] #number maxWidth

---
-- Field maxHeight
--
-- @field [parent=#ListView] #number maxHeight

---
-- Field fixedSize (Read only)
--
-- @field [parent=#ListView] #boolean fixedSize

---
-- Field fixedWidth (Read only)
--
-- @field [parent=#ListView] #boolean fixedWidth

---
-- Field fixedHeight (Read only)
--
-- @field [parent=#ListView] #boolean fixedHeight

---
-- Field childOffset
--
-- @field [parent=#ListView] IntVector2#IntVector2 childOffset

---
-- Field horizontalAlignment
--
-- @field [parent=#ListView] HorizontalAlignment#HorizontalAlignment horizontalAlignment

---
-- Field verticalAlignment
--
-- @field [parent=#ListView] VerticalAlignment#VerticalAlignment verticalAlignment

---
-- Field clipBorder
--
-- @field [parent=#ListView] IntRect#IntRect clipBorder

---
-- Field color
--
-- @field [parent=#ListView] Color#Color color

---
-- Field priority
--
-- @field [parent=#ListView] #number priority

---
-- Field opacity
--
-- @field [parent=#ListView] #number opacity

---
-- Field derivedOpacity (Read only)
--
-- @field [parent=#ListView] #number derivedOpacity

---
-- Field bringToFront
--
-- @field [parent=#ListView] #boolean bringToFront

---
-- Field bringToBack
--
-- @field [parent=#ListView] #boolean bringToBack

---
-- Field clipChildren
--
-- @field [parent=#ListView] #boolean clipChildren

---
-- Field sortChildren
--
-- @field [parent=#ListView] #boolean sortChildren

---
-- Field useDerivedOpacity
--
-- @field [parent=#ListView] #boolean useDerivedOpacity

---
-- Field focus
--
-- @field [parent=#ListView] #boolean focus

---
-- Field enabled
--
-- @field [parent=#ListView] #boolean enabled

---
-- Field editable
--
-- @field [parent=#ListView] #boolean editable

---
-- Field selected
--
-- @field [parent=#ListView] #boolean selected

---
-- Field visible
--
-- @field [parent=#ListView] #boolean visible

---
-- Field hovering
--
-- @field [parent=#ListView] #boolean hovering

---
-- Field internal
--
-- @field [parent=#ListView] #boolean internal

---
-- Field colorGradient (Read only)
--
-- @field [parent=#ListView] #boolean colorGradient

---
-- Field focusMode
--
-- @field [parent=#ListView] FocusMode#FocusMode focusMode

---
-- Field dragDropMode
--
-- @field [parent=#ListView] #number dragDropMode

---
-- Field style
--
-- @field [parent=#ListView] #string style

---
-- Field defaultStyle
--
-- @field [parent=#ListView] XMLFile#XMLFile defaultStyle

---
-- Field layoutMode
--
-- @field [parent=#ListView] LayoutMode#LayoutMode layoutMode

---
-- Field layoutSpacing
--
-- @field [parent=#ListView] #number layoutSpacing

---
-- Field layoutBorder
--
-- @field [parent=#ListView] IntRect#IntRect layoutBorder

---
-- Field numChildren (Read only)
--
-- @field [parent=#ListView] #number numChildren

---
-- Field parent
--
-- @field [parent=#ListView] UIElement#UIElement parent

---
-- Field root (Read only)
--
-- @field [parent=#ListView] UIElement#UIElement root

---
-- Field derivedColor (Read only)
--
-- @field [parent=#ListView] Color#Color derivedColor

---
-- Field combinedScreenRect (Read only)
--
-- @field [parent=#ListView] IntRect#IntRect combinedScreenRect

---
-- Field layoutMinSize (Read only)
--
-- @field [parent=#ListView] #number layoutMinSize

---
-- Field indent
--
-- @field [parent=#ListView] #number indent

---
-- Field indentSpacing
--
-- @field [parent=#ListView] #number indentSpacing

---
-- Field indentWidth (Read only)
--
-- @field [parent=#ListView] #number indentWidth

---
-- Field traversalMode
--
-- @field [parent=#ListView] TraversalMode#TraversalMode traversalMode

---
-- Field elementEventSender
--
-- @field [parent=#ListView] #boolean elementEventSender

---
-- Function SetTemporary
--
-- @function [parent=#ListView] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#ListView] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#ListView] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#ListView] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#ListView] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#ListView] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#ListView] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#ListView] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#ListView] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#ListView] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#ListView] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#ListView] #string category


return nil
