---
-- Module ListView
-- Extends ScrollView
--
-- @module ListView

---
-- Function ListView
--
-- @function [parent=#ListView] ListView

---
-- Function new
--
-- @function [parent=#ListView] new
-- @return ListView#ListView

---
-- Function delete
--
-- @function [parent=#ListView] delete

---
-- Function AddItem
--
-- @function [parent=#ListView] AddItem
-- @param UIElement#UIElement itemitem

---
-- Function InsertItem
--
-- @function [parent=#ListView] InsertItem
-- @param #number indexindex
-- @param UIElement#UIElement itemitem
-- @param UIElement#UIElement parentItemparentItem

---
-- Function RemoveItem
--
-- @function [parent=#ListView] RemoveItem
-- @param UIElement#UIElement itemitem
-- @param #number indexindex

---
-- Function RemoveItem
--
-- @function [parent=#ListView] RemoveItem
-- @param #number indexindex

---
-- Function RemoveAllItems
--
-- @function [parent=#ListView] RemoveAllItems

---
-- Function SetSelection
--
-- @function [parent=#ListView] SetSelection
-- @param #number indexindex

---
-- Function SetSelections
--
-- @function [parent=#ListView] SetSelections
-- @param PODVector<unsigned>#PODVector<unsigned> indicesindices

---
-- Function AddSelection
--
-- @function [parent=#ListView] AddSelection
-- @param #number indexindex

---
-- Function RemoveSelection
--
-- @function [parent=#ListView] RemoveSelection
-- @param #number indexindex

---
-- Function ToggleSelection
--
-- @function [parent=#ListView] ToggleSelection
-- @param #number indexindex

---
-- Function ChangeSelection
--
-- @function [parent=#ListView] ChangeSelection
-- @param #number deltadelta
-- @param #boolean additiveadditive

---
-- Function ClearSelection
--
-- @function [parent=#ListView] ClearSelection

---
-- Function SetHighlightMode
--
-- @function [parent=#ListView] SetHighlightMode
-- @param HighlightMode#HighlightMode modemode

---
-- Function SetMultiselect
--
-- @function [parent=#ListView] SetMultiselect
-- @param #boolean enableenable

---
-- Function SetHierarchyMode
--
-- @function [parent=#ListView] SetHierarchyMode
-- @param #boolean enableenable

---
-- Function SetBaseIndent
--
-- @function [parent=#ListView] SetBaseIndent
-- @param #number baseIndentbaseIndent

---
-- Function SetClearSelectionOnDefocus
--
-- @function [parent=#ListView] SetClearSelectionOnDefocus
-- @param #boolean enableenable

---
-- Function Expand
--
-- @function [parent=#ListView] Expand
-- @param #number indexindex
-- @param #boolean enableenable
-- @param #boolean recursiverecursive

---
-- Function ToggleExpand
--
-- @function [parent=#ListView] ToggleExpand
-- @param #number indexindex
-- @param #boolean recursiverecursive

---
-- Function GetNumItems
--
-- @function [parent=#ListView] GetNumItems
-- @return #number

---
-- Function GetItem
--
-- @function [parent=#ListView] GetItem
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function GetItems
--
-- @function [parent=#ListView] GetItems
-- @return const PODVector<UIElement*>#const PODVector<UIElement*>

---
-- Function FindItem
--
-- @function [parent=#ListView] FindItem
-- @param UIElement#UIElement itemitem
-- @return #number

---
-- Function GetSelection
--
-- @function [parent=#ListView] GetSelection
-- @return #number

---
-- Function GetSelections
--
-- @function [parent=#ListView] GetSelections
-- @return const PODVector<unsigned>#const PODVector<unsigned>

---
-- Function GetSelectedItem
--
-- @function [parent=#ListView] GetSelectedItem
-- @return UIElement#UIElement

---
-- Function GetSelectedItems
--
-- @function [parent=#ListView] GetSelectedItems
-- @return const PODVector<UIElement*>#const PODVector<UIElement*>

---
-- Function IsSelected
--
-- @function [parent=#ListView] IsSelected
-- @param #number indexindex
-- @return #boolean

---
-- Function IsExpanded
--
-- @function [parent=#ListView] IsExpanded
-- @param #number indexindex
-- @return #boolean

---
-- Function GetHighlightMode
--
-- @function [parent=#ListView] GetHighlightMode
-- @return HighlightMode#HighlightMode

---
-- Function GetMultiselect
--
-- @function [parent=#ListView] GetMultiselect
-- @return #boolean

---
-- Function GetClearSelectionOnDefocus
--
-- @function [parent=#ListView] GetClearSelectionOnDefocus
-- @return #boolean

---
-- Function GetHierarchyMode
--
-- @function [parent=#ListView] GetHierarchyMode
-- @return #boolean

---
-- Function GetBaseIndent
--
-- @function [parent=#ListView] GetBaseIndent
-- @return #number

---
-- Field numItems (Read only)
--
-- @field [parent=#ListView] #number numItems

---
-- Field selection
--
-- @field [parent=#ListView] #number selection

---
-- Field selectedItem (Read only)
--
-- @field [parent=#ListView] UIElement#UIElement selectedItem

---
-- Field highlightMode
--
-- @field [parent=#ListView] HighlightMode#HighlightMode highlightMode

---
-- Field multiselect
--
-- @field [parent=#ListView] #boolean multiselect

---
-- Field clearSelectionOnDefocus
--
-- @field [parent=#ListView] #boolean clearSelectionOnDefocus

---
-- Field hierarchyMode
--
-- @field [parent=#ListView] #boolean hierarchyMode

---
-- Field baseIndent
--
-- @field [parent=#ListView] #number baseIndent


return nil
