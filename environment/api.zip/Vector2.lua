---
-- Module Vector2
-- Generated on 2014-05-31
--
-- @module Vector2

---
-- Function Vector2()
-- Construct a zero vector.
--
-- @function [parent=#Vector2] Vector2
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#Vector2] new
-- @param self Self reference
-- @return Vector2#Vector2

---
-- Function Vector2()
--
-- @function [parent=#Vector2] Vector2
-- @param self Self reference
-- @param Vector2#Vector2 vector vector

---
-- Function new()
--
-- @function [parent=#Vector2] new
-- @param self Self reference
-- @param Vector2#Vector2 vector vector
-- @return Vector2#Vector2

---
-- Function Vector2()
--
-- @function [parent=#Vector2] Vector2
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function new()
--
-- @function [parent=#Vector2] new
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @return Vector2#Vector2

---
-- Function delete()
--
-- @function [parent=#Vector2] delete
-- @param self Self reference

---
-- Function operator==()
--
-- @function [parent=#Vector2] operator==
-- @param self Self reference
-- @param Vector2#Vector2 rhs rhs
-- @return #boolean

---
-- Function operator+()
--
-- @function [parent=#Vector2] operator+
-- @param self Self reference
-- @param Vector2#Vector2 rhs rhs
-- @return Vector2#Vector2

---
-- Function operator-()
--
-- @function [parent=#Vector2] operator-
-- @param self Self reference
-- @return Vector2#Vector2

---
-- Function operator-()
--
-- @function [parent=#Vector2] operator-
-- @param self Self reference
-- @param Vector2#Vector2 rhs rhs
-- @return Vector2#Vector2

---
-- Function operator*()
--
-- @function [parent=#Vector2] operator*
-- @param self Self reference
-- @param #number rhs rhs
-- @return Vector2#Vector2

---
-- Function operator*()
--
-- @function [parent=#Vector2] operator*
-- @param self Self reference
-- @param Vector2#Vector2 rhs rhs
-- @return Vector2#Vector2

---
-- Function operator/()
--
-- @function [parent=#Vector2] operator/
-- @param self Self reference
-- @param #number rhs rhs
-- @return Vector2#Vector2

---
-- Function operator/()
--
-- @function [parent=#Vector2] operator/
-- @param self Self reference
-- @param Vector2#Vector2 rhs rhs
-- @return Vector2#Vector2

---
-- Function operator/()
--
-- @function [parent=#Vector2] operator/
-- @param self Self reference
-- @param Vector2#Vector2 rhs rhs
-- @return Vector2#Vector2

---
-- Function Normalize()
--
-- @function [parent=#Vector2] Normalize
-- @param self Self reference

---
-- Function Length()
--
-- @function [parent=#Vector2] Length
-- @param self Self reference
-- @return #number

---
-- Function LengthSquared()
--
-- @function [parent=#Vector2] LengthSquared
-- @param self Self reference
-- @return #number

---
-- Function DotProduct()
--
-- @function [parent=#Vector2] DotProduct
-- @param self Self reference
-- @param Vector2#Vector2 rhs rhs
-- @return #number

---
-- Function AbsDotProduct()
--
-- @function [parent=#Vector2] AbsDotProduct
-- @param self Self reference
-- @param Vector2#Vector2 rhs rhs
-- @return #number

---
-- Function Abs()
--
-- @function [parent=#Vector2] Abs
-- @param self Self reference
-- @return Vector2#Vector2

---
-- Function Lerp()
--
-- @function [parent=#Vector2] Lerp
-- @param self Self reference
-- @param Vector2#Vector2 rhs rhs
-- @param #number t t
-- @return Vector2#Vector2

---
-- Function Equals()
--
-- @function [parent=#Vector2] Equals
-- @param self Self reference
-- @param Vector2#Vector2 rhs rhs
-- @return #boolean

---
-- Function IsNaN()
--
-- @function [parent=#Vector2] IsNaN
-- @param self Self reference
-- @return #boolean

---
-- Function Normalized()
--
-- @function [parent=#Vector2] Normalized
-- @param self Self reference
-- @return Vector2#Vector2

---
-- Function ToString()
--
-- @function [parent=#Vector2] ToString
-- @param self Self reference
-- @return #string

---
-- Field x
--
-- @field [parent=#Vector2] #number x

---
-- Field y
--
-- @field [parent=#Vector2] #number y

---
-- Field ZERO
--
-- @field [parent=#Vector2] Vector2#Vector2 ZERO

---
-- Field LEFT
--
-- @field [parent=#Vector2] Vector2#Vector2 LEFT

---
-- Field RIGHT
--
-- @field [parent=#Vector2] Vector2#Vector2 RIGHT

---
-- Field UP
--
-- @field [parent=#Vector2] Vector2#Vector2 UP

---
-- Field DOWN
--
-- @field [parent=#Vector2] Vector2#Vector2 DOWN

---
-- Field ONE
--
-- @field [parent=#Vector2] Vector2#Vector2 ONE


return nil
