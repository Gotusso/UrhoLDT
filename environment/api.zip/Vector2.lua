---
-- Module Vector2
--
-- @module Vector2

---
-- Function Vector2
--
-- @function [parent=#Vector2] Vector2

---
-- Function new
--
-- @function [parent=#Vector2] new
-- @return Vector2#Vector2

---
-- Function Vector2
--
-- @function [parent=#Vector2] Vector2
-- @param Vector2#Vector2 vectorvector

---
-- Function new
--
-- @function [parent=#Vector2] new
-- @param Vector2#Vector2 vectorvector
-- @return Vector2#Vector2

---
-- Function Vector2
--
-- @function [parent=#Vector2] Vector2
-- @param #number xx
-- @param #number yy

---
-- Function new
--
-- @function [parent=#Vector2] new
-- @param #number xx
-- @param #number yy
-- @return Vector2#Vector2

---
-- Function delete
--
-- @function [parent=#Vector2] delete

---
-- Function operator==
--
-- @function [parent=#Vector2] operator==
-- @param Vector2#Vector2 rhsrhs
-- @return #boolean

---
-- Function operator+
--
-- @function [parent=#Vector2] operator+
-- @param Vector2#Vector2 rhsrhs
-- @return Vector2#Vector2

---
-- Function operator-
--
-- @function [parent=#Vector2] operator-
-- @return Vector2#Vector2

---
-- Function operator-
--
-- @function [parent=#Vector2] operator-
-- @param Vector2#Vector2 rhsrhs
-- @return Vector2#Vector2

---
-- Function operator*
--
-- @function [parent=#Vector2] operator*
-- @param #number rhsrhs
-- @return Vector2#Vector2

---
-- Function operator*
--
-- @function [parent=#Vector2] operator*
-- @param Vector2#Vector2 rhsrhs
-- @return Vector2#Vector2

---
-- Function operator/
--
-- @function [parent=#Vector2] operator/
-- @param #number rhsrhs
-- @return Vector2#Vector2

---
-- Function operator/
--
-- @function [parent=#Vector2] operator/
-- @param Vector2#Vector2 rhsrhs
-- @return Vector2#Vector2

---
-- Function operator/
--
-- @function [parent=#Vector2] operator/
-- @param Vector2#Vector2 rhsrhs
-- @return Vector2#Vector2

---
-- Function Normalize
--
-- @function [parent=#Vector2] Normalize

---
-- Function Length
--
-- @function [parent=#Vector2] Length
-- @return #number

---
-- Function LengthSquared
--
-- @function [parent=#Vector2] LengthSquared
-- @return #number

---
-- Function DotProduct
--
-- @function [parent=#Vector2] DotProduct
-- @param Vector2#Vector2 rhsrhs
-- @return #number

---
-- Function AbsDotProduct
--
-- @function [parent=#Vector2] AbsDotProduct
-- @param Vector2#Vector2 rhsrhs
-- @return #number

---
-- Function Abs
--
-- @function [parent=#Vector2] Abs
-- @return Vector2#Vector2

---
-- Function Lerp
--
-- @function [parent=#Vector2] Lerp
-- @param Vector2#Vector2 rhsrhs
-- @param #number tt
-- @return Vector2#Vector2

---
-- Function Equals
--
-- @function [parent=#Vector2] Equals
-- @param Vector2#Vector2 rhsrhs
-- @return #boolean

---
-- Function Normalized
--
-- @function [parent=#Vector2] Normalized
-- @return Vector2#Vector2

---
-- Function ToString
--
-- @function [parent=#Vector2] ToString
-- @return #string

---
-- Field x
--
-- @field [parent=#Vector2] #number x

---
-- Field y
--
-- @field [parent=#Vector2] #number y

---
-- Field ZERO
--
-- @field [parent=#Vector2] Vector2#Vector2 ZERO

---
-- Field LEFT
--
-- @field [parent=#Vector2] Vector2#Vector2 LEFT

---
-- Field RIGHT
--
-- @field [parent=#Vector2] Vector2#Vector2 RIGHT

---
-- Field UP
--
-- @field [parent=#Vector2] Vector2#Vector2 UP

---
-- Field DOWN
--
-- @field [parent=#Vector2] Vector2#Vector2 DOWN

---
-- Field ONE
--
-- @field [parent=#Vector2] Vector2#Vector2 ONE


return nil
