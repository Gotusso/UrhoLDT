---
-- Module BorderImage
-- extends UIElement
--
-- @module BorderImage

---
-- Function BorderImage
--
-- @function [parent=#BorderImage] BorderImage

---
-- Function new
--
-- @function [parent=#BorderImage] new
-- @return BorderImage#BorderImage

---
-- Function delete
--
-- @function [parent=#BorderImage] delete

---
-- Function SetTexture
--
-- @function [parent=#BorderImage] SetTexture
-- @param Texture#Texture texturetexture

---
-- Function SetImageRect
--
-- @function [parent=#BorderImage] SetImageRect
-- @param IntRect#IntRect rectrect

---
-- Function SetFullImageRect
--
-- @function [parent=#BorderImage] SetFullImageRect

---
-- Function SetBorder
--
-- @function [parent=#BorderImage] SetBorder
-- @param IntRect#IntRect rectrect

---
-- Function SetHoverOffset
--
-- @function [parent=#BorderImage] SetHoverOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetHoverOffset
--
-- @function [parent=#BorderImage] SetHoverOffset
-- @param #number xx
-- @param #number yy

---
-- Function SetBlendMode
--
-- @function [parent=#BorderImage] SetBlendMode
-- @param BlendMode#BlendMode modemode

---
-- Function SetTiled
--
-- @function [parent=#BorderImage] SetTiled
-- @param #boolean enableenable

---
-- Function GetTexture
--
-- @function [parent=#BorderImage] GetTexture
-- @return Texture#Texture

---
-- Function GetImageRect
--
-- @function [parent=#BorderImage] GetImageRect
-- @return const IntRect#const IntRect

---
-- Function GetBorder
--
-- @function [parent=#BorderImage] GetBorder
-- @return const IntRect#const IntRect

---
-- Function GetHoverOffset
--
-- @function [parent=#BorderImage] GetHoverOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetBlendMode
--
-- @function [parent=#BorderImage] GetBlendMode
-- @return BlendMode#BlendMode

---
-- Function IsTiled
--
-- @function [parent=#BorderImage] IsTiled
-- @return #boolean

---
-- Field texture
--
-- @field [parent=#BorderImage] Texture#Texture texture

---
-- Field imageRect
--
-- @field [parent=#BorderImage] IntRect#IntRect imageRect

---
-- Field border
--
-- @field [parent=#BorderImage] IntRect#IntRect border

---
-- Field hoverOffset
--
-- @field [parent=#BorderImage] IntVector2#IntVector2 hoverOffset

---
-- Field blendMode
--
-- @field [parent=#BorderImage] BlendMode#BlendMode blendMode

---
-- Field tiled
--
-- @field [parent=#BorderImage] #boolean tiled

---
-- Function UIElement
--
-- @function [parent=#BorderImage] UIElement

---
-- Function new
--
-- @function [parent=#BorderImage] new
-- @return UIElement#UIElement

---
-- Function delete
--
-- @function [parent=#BorderImage] delete

---
-- Function GetScreenPosition
--
-- @function [parent=#BorderImage] GetScreenPosition
-- @return const IntVector2#const IntVector2

---
-- Function LoadXML
--
-- @function [parent=#BorderImage] LoadXML
-- @param Deserializer#Deserializer sourcesource
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#BorderImage] SaveXML
-- @param Serializer#Serializer destdest
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#BorderImage] LoadXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#BorderImage] SaveXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function FilterAttributes
--
-- @function [parent=#BorderImage] FilterAttributes
-- @param XMLElement#XMLElement destdest
-- @return #boolean

---
-- Function SetName
--
-- @function [parent=#BorderImage] SetName
-- @param #string namename

---
-- Function SetPosition
--
-- @function [parent=#BorderImage] SetPosition
-- @param IntVector2#IntVector2 positionposition

---
-- Function SetPosition
--
-- @function [parent=#BorderImage] SetPosition
-- @param #number xx
-- @param #number yy

---
-- Function SetSize
--
-- @function [parent=#BorderImage] SetSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function SetSize
--
-- @function [parent=#BorderImage] SetSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetWidth
--
-- @function [parent=#BorderImage] SetWidth
-- @param #number widthwidth

---
-- Function SetHeight
--
-- @function [parent=#BorderImage] SetHeight
-- @param #number heightheight

---
-- Function SetMinSize
--
-- @function [parent=#BorderImage] SetMinSize
-- @param IntVector2#IntVector2 minSizeminSize

---
-- Function SetMinSize
--
-- @function [parent=#BorderImage] SetMinSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetMinWidth
--
-- @function [parent=#BorderImage] SetMinWidth
-- @param #number widthwidth

---
-- Function SetMinHeight
--
-- @function [parent=#BorderImage] SetMinHeight
-- @param #number heightheight

---
-- Function SetMaxSize
--
-- @function [parent=#BorderImage] SetMaxSize
-- @param IntVector2#IntVector2 maxSizemaxSize

---
-- Function SetMaxSize
--
-- @function [parent=#BorderImage] SetMaxSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetMaxWidth
--
-- @function [parent=#BorderImage] SetMaxWidth
-- @param #number widthwidth

---
-- Function SetMaxHeight
--
-- @function [parent=#BorderImage] SetMaxHeight
-- @param #number heightheight

---
-- Function SetFixedSize
--
-- @function [parent=#BorderImage] SetFixedSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function SetFixedSize
--
-- @function [parent=#BorderImage] SetFixedSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetFixedWidth
--
-- @function [parent=#BorderImage] SetFixedWidth
-- @param #number widthwidth

---
-- Function SetFixedHeight
--
-- @function [parent=#BorderImage] SetFixedHeight
-- @param #number heightheight

---
-- Function SetAlignment
--
-- @function [parent=#BorderImage] SetAlignment
-- @param HorizontalAlignment#HorizontalAlignment hAlignhAlign
-- @param VerticalAlignment#VerticalAlignment vAlignvAlign

---
-- Function SetHorizontalAlignment
--
-- @function [parent=#BorderImage] SetHorizontalAlignment
-- @param HorizontalAlignment#HorizontalAlignment alignalign

---
-- Function SetVerticalAlignment
--
-- @function [parent=#BorderImage] SetVerticalAlignment
-- @param VerticalAlignment#VerticalAlignment alignalign

---
-- Function SetClipBorder
--
-- @function [parent=#BorderImage] SetClipBorder
-- @param IntRect#IntRect rectrect

---
-- Function SetColor
--
-- @function [parent=#BorderImage] SetColor
-- @param Color#Color colorcolor

---
-- Function SetColor
--
-- @function [parent=#BorderImage] SetColor
-- @param Corner#Corner cornercorner
-- @param Color#Color colorcolor

---
-- Function SetPriority
--
-- @function [parent=#BorderImage] SetPriority
-- @param #number prioritypriority

---
-- Function SetOpacity
--
-- @function [parent=#BorderImage] SetOpacity
-- @param #number opacityopacity

---
-- Function SetBringToFront
--
-- @function [parent=#BorderImage] SetBringToFront
-- @param #boolean enableenable

---
-- Function SetBringToBack
--
-- @function [parent=#BorderImage] SetBringToBack
-- @param #boolean enableenable

---
-- Function SetClipChildren
--
-- @function [parent=#BorderImage] SetClipChildren
-- @param #boolean enableenable

---
-- Function SetSortChildren
--
-- @function [parent=#BorderImage] SetSortChildren
-- @param #boolean enableenable

---
-- Function SetUseDerivedOpacity
--
-- @function [parent=#BorderImage] SetUseDerivedOpacity
-- @param #boolean enableenable

---
-- Function SetEnabled
--
-- @function [parent=#BorderImage] SetEnabled
-- @param #boolean enableenable

---
-- Function SetEditable
--
-- @function [parent=#BorderImage] SetEditable
-- @param #boolean enableenable

---
-- Function SetFocus
--
-- @function [parent=#BorderImage] SetFocus
-- @param #boolean enableenable

---
-- Function SetSelected
--
-- @function [parent=#BorderImage] SetSelected
-- @param #boolean enableenable

---
-- Function SetVisible
--
-- @function [parent=#BorderImage] SetVisible
-- @param #boolean enableenable

---
-- Function SetFocusMode
--
-- @function [parent=#BorderImage] SetFocusMode
-- @param FocusMode#FocusMode modemode

---
-- Function SetDragDropMode
--
-- @function [parent=#BorderImage] SetDragDropMode
-- @param #number modemode

---
-- Function SetStyle
--
-- @function [parent=#BorderImage] SetStyle
-- @param #string styleNamestyleName
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetStyle
--
-- @function [parent=#BorderImage] SetStyle
-- @param XMLElement#XMLElement elementelement
-- @return #boolean

---
-- Function SetStyleAuto
--
-- @function [parent=#BorderImage] SetStyleAuto
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetDefaultStyle
--
-- @function [parent=#BorderImage] SetDefaultStyle
-- @param XMLFile#XMLFile stylestyle

---
-- Function SetLayout
--
-- @function [parent=#BorderImage] SetLayout
-- @param LayoutMode#LayoutMode modemode
-- @param #number spacingspacing

---
-- Function SetLayout
--
-- @function [parent=#BorderImage] SetLayout
-- @param LayoutMode#LayoutMode modemode
-- @param #number spacingspacing
-- @param IntRect#IntRect borderborder

---
-- Function SetLayoutMode
--
-- @function [parent=#BorderImage] SetLayoutMode
-- @param LayoutMode#LayoutMode modemode

---
-- Function SetLayoutSpacing
--
-- @function [parent=#BorderImage] SetLayoutSpacing
-- @param #number spacingspacing

---
-- Function SetLayoutBorder
--
-- @function [parent=#BorderImage] SetLayoutBorder
-- @param IntRect#IntRect borderborder

---
-- Function SetIndent
--
-- @function [parent=#BorderImage] SetIndent
-- @param #number indentindent

---
-- Function SetIndentSpacing
--
-- @function [parent=#BorderImage] SetIndentSpacing
-- @param #number indentSpacingindentSpacing

---
-- Function UpdateLayout
--
-- @function [parent=#BorderImage] UpdateLayout

---
-- Function DisableLayoutUpdate
--
-- @function [parent=#BorderImage] DisableLayoutUpdate

---
-- Function EnableLayoutUpdate
--
-- @function [parent=#BorderImage] EnableLayoutUpdate

---
-- Function BringToFront
--
-- @function [parent=#BorderImage] BringToFront

---
-- Function CreateChild
--
-- @function [parent=#BorderImage] CreateChild
-- @param #string typetype
-- @param #string namename
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function AddChild
--
-- @function [parent=#BorderImage] AddChild
-- @param UIElement#UIElement elementelement

---
-- Function InsertChild
--
-- @function [parent=#BorderImage] InsertChild
-- @param #number indexindex
-- @param UIElement#UIElement elementelement

---
-- Function RemoveChild
--
-- @function [parent=#BorderImage] RemoveChild
-- @param UIElement#UIElement elementelement
-- @param #number indexindex

---
-- Function RemoveChildAtIndex
--
-- @function [parent=#BorderImage] RemoveChildAtIndex
-- @param #number indexindex

---
-- Function RemoveAllChildren
--
-- @function [parent=#BorderImage] RemoveAllChildren

---
-- Function Remove
--
-- @function [parent=#BorderImage] Remove

---
-- Function FindChild
--
-- @function [parent=#BorderImage] FindChild
-- @param UIElement#UIElement elementelement
-- @return #number

---
-- Function SetParent
--
-- @function [parent=#BorderImage] SetParent
-- @param UIElement#UIElement parentparent
-- @param #number indexindex

---
-- Function SetVar
--
-- @function [parent=#BorderImage] SetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @param Variant#Variant valuevalue

---
-- Function SetInternal
--
-- @function [parent=#BorderImage] SetInternal
-- @param #boolean enableenable

---
-- Function SetTraversalMode
--
-- @function [parent=#BorderImage] SetTraversalMode
-- @param TraversalMode#TraversalMode traversalModetraversalMode

---
-- Function SetElementEventSender
--
-- @function [parent=#BorderImage] SetElementEventSender
-- @param #boolean flagflag

---
-- Function GetName
--
-- @function [parent=#BorderImage] GetName
-- @return const String#const String

---
-- Function GetPosition
--
-- @function [parent=#BorderImage] GetPosition
-- @return const IntVector2#const IntVector2

---
-- Function GetSize
--
-- @function [parent=#BorderImage] GetSize
-- @return const IntVector2#const IntVector2

---
-- Function GetWidth
--
-- @function [parent=#BorderImage] GetWidth
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#BorderImage] GetHeight
-- @return #number

---
-- Function GetMinSize
--
-- @function [parent=#BorderImage] GetMinSize
-- @return const IntVector2#const IntVector2

---
-- Function GetMinWidth
--
-- @function [parent=#BorderImage] GetMinWidth
-- @return #number

---
-- Function GetMinHeight
--
-- @function [parent=#BorderImage] GetMinHeight
-- @return #number

---
-- Function GetMaxSize
--
-- @function [parent=#BorderImage] GetMaxSize
-- @return const IntVector2#const IntVector2

---
-- Function GetMaxWidth
--
-- @function [parent=#BorderImage] GetMaxWidth
-- @return #number

---
-- Function GetMaxHeight
--
-- @function [parent=#BorderImage] GetMaxHeight
-- @return #number

---
-- Function IsFixedSize
--
-- @function [parent=#BorderImage] IsFixedSize
-- @return #boolean

---
-- Function IsFixedWidth
--
-- @function [parent=#BorderImage] IsFixedWidth
-- @return #boolean

---
-- Function IsFixedHeight
--
-- @function [parent=#BorderImage] IsFixedHeight
-- @return #boolean

---
-- Function GetChildOffset
--
-- @function [parent=#BorderImage] GetChildOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetHorizontalAlignment
--
-- @function [parent=#BorderImage] GetHorizontalAlignment
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetVerticalAlignment
--
-- @function [parent=#BorderImage] GetVerticalAlignment
-- @return VerticalAlignment#VerticalAlignment

---
-- Function GetClipBorder
--
-- @function [parent=#BorderImage] GetClipBorder
-- @return const IntRect#const IntRect

---
-- Function GetColor
--
-- @function [parent=#BorderImage] GetColor
-- @param Corner#Corner cornercorner
-- @return const Color#const Color

---
-- Function GetPriority
--
-- @function [parent=#BorderImage] GetPriority
-- @return #number

---
-- Function GetOpacity
--
-- @function [parent=#BorderImage] GetOpacity
-- @return #number

---
-- Function GetDerivedOpacity
--
-- @function [parent=#BorderImage] GetDerivedOpacity
-- @return #number

---
-- Function GetBringToFront
--
-- @function [parent=#BorderImage] GetBringToFront
-- @return #boolean

---
-- Function GetBringToBack
--
-- @function [parent=#BorderImage] GetBringToBack
-- @return #boolean

---
-- Function GetClipChildren
--
-- @function [parent=#BorderImage] GetClipChildren
-- @return #boolean

---
-- Function GetSortChildren
--
-- @function [parent=#BorderImage] GetSortChildren
-- @return #boolean

---
-- Function GetUseDerivedOpacity
--
-- @function [parent=#BorderImage] GetUseDerivedOpacity
-- @return #boolean

---
-- Function HasFocus
--
-- @function [parent=#BorderImage] HasFocus
-- @return #boolean

---
-- Function IsEnabled
--
-- @function [parent=#BorderImage] IsEnabled
-- @return #boolean

---
-- Function IsEditable
--
-- @function [parent=#BorderImage] IsEditable
-- @return #boolean

---
-- Function IsSelected
--
-- @function [parent=#BorderImage] IsSelected
-- @return #boolean

---
-- Function IsVisible
--
-- @function [parent=#BorderImage] IsVisible
-- @return #boolean

---
-- Function IsHovering
--
-- @function [parent=#BorderImage] IsHovering
-- @return #boolean

---
-- Function IsInternal
--
-- @function [parent=#BorderImage] IsInternal
-- @return #boolean

---
-- Function HasColorGradient
--
-- @function [parent=#BorderImage] HasColorGradient
-- @return #boolean

---
-- Function GetFocusMode
--
-- @function [parent=#BorderImage] GetFocusMode
-- @return FocusMode#FocusMode

---
-- Function GetDragDropMode
--
-- @function [parent=#BorderImage] GetDragDropMode
-- @return #number

---
-- Function GetAppliedStyle
--
-- @function [parent=#BorderImage] GetAppliedStyle
-- @return const String#const String

---
-- Function GetDefaultStyle
--
-- @function [parent=#BorderImage] GetDefaultStyle
-- @param #boolean recursiveUprecursiveUp
-- @return XMLFile#XMLFile

---
-- Function GetLayoutMode
--
-- @function [parent=#BorderImage] GetLayoutMode
-- @return LayoutMode#LayoutMode

---
-- Function GetLayoutSpacing
--
-- @function [parent=#BorderImage] GetLayoutSpacing
-- @return #number

---
-- Function GetLayoutBorder
--
-- @function [parent=#BorderImage] GetLayoutBorder
-- @return const IntRect#const IntRect

---
-- Function GetNumChildren
--
-- @function [parent=#BorderImage] GetNumChildren
-- @param #boolean recursiverecursive
-- @return #number

---
-- Function GetChild
--
-- @function [parent=#BorderImage] GetChild
-- @param #string namename
-- @param #boolean recursiverecursive
-- @return UIElement#UIElement

---
-- Function GetChild
--
-- @function [parent=#BorderImage] GetChild
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function GetParent
--
-- @function [parent=#BorderImage] GetParent
-- @return UIElement#UIElement

---
-- Function GetRoot
--
-- @function [parent=#BorderImage] GetRoot
-- @return UIElement#UIElement

---
-- Function GetDerivedColor
--
-- @function [parent=#BorderImage] GetDerivedColor
-- @return const Color#const Color

---
-- Function GetVar
--
-- @function [parent=#BorderImage] GetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @return const Variant#const Variant

---
-- Function GetVars
--
-- @function [parent=#BorderImage] GetVars
-- @return const VariantMap#const VariantMap

---
-- Function ScreenToElement
--
-- @function [parent=#BorderImage] ScreenToElement
-- @param IntVector2#IntVector2 screenPositionscreenPosition
-- @return IntVector2#IntVector2

---
-- Function ElementToScreen
--
-- @function [parent=#BorderImage] ElementToScreen
-- @param IntVector2#IntVector2 positionposition
-- @return IntVector2#IntVector2

---
-- Function IsInside
--
-- @function [parent=#BorderImage] IsInside
-- @param IntVector2#IntVector2 positionposition
-- @param #boolean isScreenisScreen
-- @return #boolean

---
-- Function IsInsideCombined
--
-- @function [parent=#BorderImage] IsInsideCombined
-- @param IntVector2#IntVector2 positionposition
-- @param #boolean isScreenisScreen
-- @return #boolean

---
-- Function GetCombinedScreenRect
--
-- @function [parent=#BorderImage] GetCombinedScreenRect
-- @return IntRect#IntRect

---
-- Function SortChildren
--
-- @function [parent=#BorderImage] SortChildren

---
-- Function GetLayoutMinSize
--
-- @function [parent=#BorderImage] GetLayoutMinSize
-- @return #number

---
-- Function GetIndent
--
-- @function [parent=#BorderImage] GetIndent
-- @return #number

---
-- Function GetIndentSpacing
--
-- @function [parent=#BorderImage] GetIndentSpacing
-- @return #number

---
-- Function GetIndentWidth
--
-- @function [parent=#BorderImage] GetIndentWidth
-- @return #number

---
-- Function SetChildOffset
--
-- @function [parent=#BorderImage] SetChildOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetHovering
--
-- @function [parent=#BorderImage] SetHovering
-- @param #boolean enableenable

---
-- Function GetColor
--
-- @function [parent=#BorderImage] GetColor
-- @return const Color#const Color

---
-- Function GetTraversalMode
--
-- @function [parent=#BorderImage] GetTraversalMode
-- @return TraversalMode#TraversalMode

---
-- Function IsElementEventSender
--
-- @function [parent=#BorderImage] IsElementEventSender
-- @return #boolean

---
-- Function GetElementEventSender
--
-- @function [parent=#BorderImage] GetElementEventSender
-- @return UIElement#UIElement

---
-- Field screenPosition (Read only)
--
-- @field [parent=#BorderImage] IntVector2#IntVector2 screenPosition

---
-- Field name
--
-- @field [parent=#BorderImage] #string name

---
-- Field position
--
-- @field [parent=#BorderImage] IntVector2#IntVector2 position

---
-- Field size
--
-- @field [parent=#BorderImage] IntVector2#IntVector2 size

---
-- Field width
--
-- @field [parent=#BorderImage] #number width

---
-- Field height
--
-- @field [parent=#BorderImage] #number height

---
-- Field minSize
--
-- @field [parent=#BorderImage] IntVector2#IntVector2 minSize

---
-- Field minWidth
--
-- @field [parent=#BorderImage] #number minWidth

---
-- Field minHeight
--
-- @field [parent=#BorderImage] #number minHeight

---
-- Field maxSize
--
-- @field [parent=#BorderImage] IntVector2#IntVector2 maxSize

---
-- Field maxWidth
--
-- @field [parent=#BorderImage] #number maxWidth

---
-- Field maxHeight
--
-- @field [parent=#BorderImage] #number maxHeight

---
-- Field fixedSize (Read only)
--
-- @field [parent=#BorderImage] #boolean fixedSize

---
-- Field fixedWidth (Read only)
--
-- @field [parent=#BorderImage] #boolean fixedWidth

---
-- Field fixedHeight (Read only)
--
-- @field [parent=#BorderImage] #boolean fixedHeight

---
-- Field childOffset
--
-- @field [parent=#BorderImage] IntVector2#IntVector2 childOffset

---
-- Field horizontalAlignment
--
-- @field [parent=#BorderImage] HorizontalAlignment#HorizontalAlignment horizontalAlignment

---
-- Field verticalAlignment
--
-- @field [parent=#BorderImage] VerticalAlignment#VerticalAlignment verticalAlignment

---
-- Field clipBorder
--
-- @field [parent=#BorderImage] IntRect#IntRect clipBorder

---
-- Field color
--
-- @field [parent=#BorderImage] Color#Color color

---
-- Field priority
--
-- @field [parent=#BorderImage] #number priority

---
-- Field opacity
--
-- @field [parent=#BorderImage] #number opacity

---
-- Field derivedOpacity (Read only)
--
-- @field [parent=#BorderImage] #number derivedOpacity

---
-- Field bringToFront
--
-- @field [parent=#BorderImage] #boolean bringToFront

---
-- Field bringToBack
--
-- @field [parent=#BorderImage] #boolean bringToBack

---
-- Field clipChildren
--
-- @field [parent=#BorderImage] #boolean clipChildren

---
-- Field sortChildren
--
-- @field [parent=#BorderImage] #boolean sortChildren

---
-- Field useDerivedOpacity
--
-- @field [parent=#BorderImage] #boolean useDerivedOpacity

---
-- Field focus
--
-- @field [parent=#BorderImage] #boolean focus

---
-- Field enabled
--
-- @field [parent=#BorderImage] #boolean enabled

---
-- Field editable
--
-- @field [parent=#BorderImage] #boolean editable

---
-- Field selected
--
-- @field [parent=#BorderImage] #boolean selected

---
-- Field visible
--
-- @field [parent=#BorderImage] #boolean visible

---
-- Field hovering
--
-- @field [parent=#BorderImage] #boolean hovering

---
-- Field internal
--
-- @field [parent=#BorderImage] #boolean internal

---
-- Field colorGradient (Read only)
--
-- @field [parent=#BorderImage] #boolean colorGradient

---
-- Field focusMode
--
-- @field [parent=#BorderImage] FocusMode#FocusMode focusMode

---
-- Field dragDropMode
--
-- @field [parent=#BorderImage] #number dragDropMode

---
-- Field style
--
-- @field [parent=#BorderImage] #string style

---
-- Field defaultStyle
--
-- @field [parent=#BorderImage] XMLFile#XMLFile defaultStyle

---
-- Field layoutMode
--
-- @field [parent=#BorderImage] LayoutMode#LayoutMode layoutMode

---
-- Field layoutSpacing
--
-- @field [parent=#BorderImage] #number layoutSpacing

---
-- Field layoutBorder
--
-- @field [parent=#BorderImage] IntRect#IntRect layoutBorder

---
-- Field numChildren (Read only)
--
-- @field [parent=#BorderImage] #number numChildren

---
-- Field parent
--
-- @field [parent=#BorderImage] UIElement#UIElement parent

---
-- Field root (Read only)
--
-- @field [parent=#BorderImage] UIElement#UIElement root

---
-- Field derivedColor (Read only)
--
-- @field [parent=#BorderImage] Color#Color derivedColor

---
-- Field combinedScreenRect (Read only)
--
-- @field [parent=#BorderImage] IntRect#IntRect combinedScreenRect

---
-- Field layoutMinSize (Read only)
--
-- @field [parent=#BorderImage] #number layoutMinSize

---
-- Field indent
--
-- @field [parent=#BorderImage] #number indent

---
-- Field indentSpacing
--
-- @field [parent=#BorderImage] #number indentSpacing

---
-- Field indentWidth (Read only)
--
-- @field [parent=#BorderImage] #number indentWidth

---
-- Field traversalMode
--
-- @field [parent=#BorderImage] TraversalMode#TraversalMode traversalMode

---
-- Field elementEventSender
--
-- @field [parent=#BorderImage] #boolean elementEventSender

---
-- Function SetTemporary
--
-- @function [parent=#BorderImage] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#BorderImage] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#BorderImage] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#BorderImage] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#BorderImage] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#BorderImage] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#BorderImage] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#BorderImage] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#BorderImage] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#BorderImage] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#BorderImage] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#BorderImage] #string category


return nil
