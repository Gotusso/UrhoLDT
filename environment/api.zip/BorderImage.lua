---
-- Module BorderImage
-- Module BorderImage extends UIElement
-- Generated on 2014-05-31
--
-- @module BorderImage

---
-- Function BorderImage()
--
-- @function [parent=#BorderImage] BorderImage
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#BorderImage] new
-- @param self Self reference
-- @return BorderImage#BorderImage

---
-- Function delete()
--
-- @function [parent=#BorderImage] delete
-- @param self Self reference

---
-- Function SetTexture()
-- Set texture.
--
-- @function [parent=#BorderImage] SetTexture
-- @param self Self reference
-- @param Texture#Texture texture texture

---
-- Function SetImageRect()
-- Set part of texture to use as the image.
--
-- @function [parent=#BorderImage] SetImageRect
-- @param self Self reference
-- @param IntRect#IntRect rect rect

---
-- Function SetFullImageRect()
-- Use whole texture as the image.
--
-- @function [parent=#BorderImage] SetFullImageRect
-- @param self Self reference

---
-- Function SetBorder()
-- Set border dimensions on the screen.
--
-- @function [parent=#BorderImage] SetBorder
-- @param self Self reference
-- @param IntRect#IntRect rect rect

---
-- Function SetImageBorder()
-- Set border dimensions on the image. If zero (default) uses the screen dimensions, resulting in pixel-perfect borders.
--
-- @function [parent=#BorderImage] SetImageBorder
-- @param self Self reference
-- @param IntRect#IntRect rect rect

---
-- Function SetHoverOffset()
-- Set offset to image rectangle used on hover.
--
-- @function [parent=#BorderImage] SetHoverOffset
-- @param self Self reference
-- @param IntVector2#IntVector2 offset offset

---
-- Function SetHoverOffset()
-- Set offset to image rectangle used on hover.
--
-- @function [parent=#BorderImage] SetHoverOffset
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function SetBlendMode()
-- Set blend mode.
--
-- @function [parent=#BorderImage] SetBlendMode
-- @param self Self reference
-- @param BlendMode#BlendMode mode mode

---
-- Function SetTiled()
-- Set tiled mode.
--
-- @function [parent=#BorderImage] SetTiled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function GetTexture()
-- Return texture.
--
-- @function [parent=#BorderImage] GetTexture
-- @param self Self reference
-- @return Texture#Texture

---
-- Function GetImageRect()
-- Return image rectangle.
--
-- @function [parent=#BorderImage] GetImageRect
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetBorder()
-- Return border screen dimensions.
--
-- @function [parent=#BorderImage] GetBorder
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetImageBorder()
-- Return border image dimensions. Zero rect uses border screen dimensions.
--
-- @function [parent=#BorderImage] GetImageBorder
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetHoverOffset()
-- Return offset to image rectangle used on hover.
--
-- @function [parent=#BorderImage] GetHoverOffset
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetBlendMode()
-- Return blend mode.
--
-- @function [parent=#BorderImage] GetBlendMode
-- @param self Self reference
-- @return BlendMode#BlendMode

---
-- Function IsTiled()
-- Return whether is tiled.
--
-- @function [parent=#BorderImage] IsTiled
-- @param self Self reference
-- @return #boolean

---
-- Field texture
--
-- @field [parent=#BorderImage] Texture#Texture texture

---
-- Field imageRect
--
-- @field [parent=#BorderImage] IntRect#IntRect imageRect

---
-- Field border
--
-- @field [parent=#BorderImage] IntRect#IntRect border

---
-- Field imageBorder
--
-- @field [parent=#BorderImage] IntRect#IntRect imageBorder

---
-- Field hoverOffset
--
-- @field [parent=#BorderImage] IntVector2#IntVector2 hoverOffset

---
-- Field blendMode
--
-- @field [parent=#BorderImage] BlendMode#BlendMode blendMode

---
-- Field tiled
--
-- @field [parent=#BorderImage] #boolean tiled


return nil
