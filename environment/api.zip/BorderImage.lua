---
-- Module BorderImage
-- Extends UIElement
--
-- @module BorderImage

---
-- Function BorderImage
--
-- @function [parent=#BorderImage] BorderImage

---
-- Function new
--
-- @function [parent=#BorderImage] new
-- @return BorderImage#BorderImage

---
-- Function delete
--
-- @function [parent=#BorderImage] delete

---
-- Function SetTexture
--
-- @function [parent=#BorderImage] SetTexture
-- @param Texture#Texture texturetexture

---
-- Function SetImageRect
--
-- @function [parent=#BorderImage] SetImageRect
-- @param IntRect#IntRect rectrect

---
-- Function SetFullImageRect
--
-- @function [parent=#BorderImage] SetFullImageRect

---
-- Function SetBorder
--
-- @function [parent=#BorderImage] SetBorder
-- @param IntRect#IntRect rectrect

---
-- Function SetHoverOffset
--
-- @function [parent=#BorderImage] SetHoverOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetHoverOffset
--
-- @function [parent=#BorderImage] SetHoverOffset
-- @param #number xx
-- @param #number yy

---
-- Function SetBlendMode
--
-- @function [parent=#BorderImage] SetBlendMode
-- @param BlendMode#BlendMode modemode

---
-- Function SetTiled
--
-- @function [parent=#BorderImage] SetTiled
-- @param #boolean enableenable

---
-- Function GetTexture
--
-- @function [parent=#BorderImage] GetTexture
-- @return Texture#Texture

---
-- Function GetImageRect
--
-- @function [parent=#BorderImage] GetImageRect
-- @return const IntRect#const IntRect

---
-- Function GetBorder
--
-- @function [parent=#BorderImage] GetBorder
-- @return const IntRect#const IntRect

---
-- Function GetHoverOffset
--
-- @function [parent=#BorderImage] GetHoverOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetBlendMode
--
-- @function [parent=#BorderImage] GetBlendMode
-- @return BlendMode#BlendMode

---
-- Function IsTiled
--
-- @function [parent=#BorderImage] IsTiled
-- @return #boolean

---
-- Field texture
--
-- @field [parent=#BorderImage] Texture#Texture texture

---
-- Field imageRect
--
-- @field [parent=#BorderImage] IntRect#IntRect imageRect

---
-- Field border
--
-- @field [parent=#BorderImage] IntRect#IntRect border

---
-- Field hoverOffset
--
-- @field [parent=#BorderImage] IntVector2#IntVector2 hoverOffset

---
-- Field blendMode
--
-- @field [parent=#BorderImage] BlendMode#BlendMode blendMode

---
-- Field tiled
--
-- @field [parent=#BorderImage] #boolean tiled


return nil
