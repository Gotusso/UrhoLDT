---
-- Module PhysicsWorld
-- Extends Component
--
-- @module PhysicsWorld

---
-- Function Update
--
-- @function [parent=#PhysicsWorld] Update
-- @param #number timeSteptimeStep

---
-- Function UpdateCollisions
--
-- @function [parent=#PhysicsWorld] UpdateCollisions

---
-- Function SetFps
--
-- @function [parent=#PhysicsWorld] SetFps
-- @param #number fpsfps

---
-- Function SetGravity
--
-- @function [parent=#PhysicsWorld] SetGravity
-- @param Vector3#Vector3 gravitygravity

---
-- Function SetNumIterations
--
-- @function [parent=#PhysicsWorld] SetNumIterations
-- @param #number numnum

---
-- Function SetInterpolation
--
-- @function [parent=#PhysicsWorld] SetInterpolation
-- @param #boolean enableenable

---
-- Function SetInternalEdge
--
-- @function [parent=#PhysicsWorld] SetInternalEdge
-- @param #boolean enableenable

---
-- Function SetSplitImpulse
--
-- @function [parent=#PhysicsWorld] SetSplitImpulse
-- @param #boolean enableenable

---
-- Function SetMaxNetworkAngularVelocity
--
-- @function [parent=#PhysicsWorld] SetMaxNetworkAngularVelocity
-- @param #number velocityvelocity

---
-- Function Raycast
--
-- @function [parent=#PhysicsWorld] Raycast
-- @param Ray#Ray rayray
-- @param #number maxDistancemaxDistance
-- @param #number collisionMaskcollisionMask
-- @return const PODVector<PhysicsRaycastResult>#const PODVector<PhysicsRaycastResult>

---
-- Function RaycastSingle
--
-- @function [parent=#PhysicsWorld] RaycastSingle
-- @param Ray#Ray rayray
-- @param #number maxDistancemaxDistance
-- @param #number collisionMaskcollisionMask
-- @return PhysicsRaycastResult#PhysicsRaycastResult

---
-- Function SphereCast
--
-- @function [parent=#PhysicsWorld] SphereCast
-- @param Ray#Ray rayray
-- @param #number radiusradius
-- @param #number maxDistancemaxDistance
-- @param #number collisionMaskcollisionMask
-- @return PhysicsRaycastResult#PhysicsRaycastResult

---
-- Function DrawDebugGeometry
--
-- @function [parent=#PhysicsWorld] DrawDebugGeometry
-- @param #boolean depthTestdepthTest

---
-- Function RemoveCachedGeometry
--
-- @function [parent=#PhysicsWorld] RemoveCachedGeometry
-- @param Model#Model modelmodel

---
-- Function GetGravity
--
-- @function [parent=#PhysicsWorld] GetGravity
-- @return Vector3#Vector3

---
-- Function GetNumIterations
--
-- @function [parent=#PhysicsWorld] GetNumIterations
-- @return #number

---
-- Function GetInterpolation
--
-- @function [parent=#PhysicsWorld] GetInterpolation
-- @return #boolean

---
-- Function GetInternalEdge
--
-- @function [parent=#PhysicsWorld] GetInternalEdge
-- @return #boolean

---
-- Function GetSplitImpulse
--
-- @function [parent=#PhysicsWorld] GetSplitImpulse
-- @return #boolean

---
-- Function GetFps
--
-- @function [parent=#PhysicsWorld] GetFps
-- @return #number

---
-- Function GetMaxNetworkAngularVelocity
--
-- @function [parent=#PhysicsWorld] GetMaxNetworkAngularVelocity
-- @return #number

---
-- Field gravity
--
-- @field [parent=#PhysicsWorld] Vector3#Vector3 gravity

---
-- Field numIterations
--
-- @field [parent=#PhysicsWorld] #number numIterations

---
-- Field interpolation
--
-- @field [parent=#PhysicsWorld] #boolean interpolation

---
-- Field internalEdge
--
-- @field [parent=#PhysicsWorld] #boolean internalEdge

---
-- Field splitImpulse
--
-- @field [parent=#PhysicsWorld] #boolean splitImpulse

---
-- Field fps
--
-- @field [parent=#PhysicsWorld] #number fps

---
-- Field maxNetworkAngularVelocity
--
-- @field [parent=#PhysicsWorld] #number maxNetworkAngularVelocity

---
-- Field applyingTransforms
--
-- @field [parent=#PhysicsWorld] #boolean applyingTransforms


return nil
