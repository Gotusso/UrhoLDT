---
-- Module PhysicsWorld
-- Module PhysicsWorld extends Component
-- Generated on 2014-03-13
--
-- @module PhysicsWorld

---
-- Function Update
--
-- @function [parent=#PhysicsWorld] Update
-- @param self Self reference
-- @param #number timeStep timeStep

---
-- Function UpdateCollisions
--
-- @function [parent=#PhysicsWorld] UpdateCollisions
-- @param self Self reference

---
-- Function SetFps
--
-- @function [parent=#PhysicsWorld] SetFps
-- @param self Self reference
-- @param #number fps fps

---
-- Function SetGravity
--
-- @function [parent=#PhysicsWorld] SetGravity
-- @param self Self reference
-- @param Vector3#Vector3 gravity gravity

---
-- Function SetNumIterations
--
-- @function [parent=#PhysicsWorld] SetNumIterations
-- @param self Self reference
-- @param #number num num

---
-- Function SetInterpolation
--
-- @function [parent=#PhysicsWorld] SetInterpolation
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetInternalEdge
--
-- @function [parent=#PhysicsWorld] SetInternalEdge
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetSplitImpulse
--
-- @function [parent=#PhysicsWorld] SetSplitImpulse
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetMaxNetworkAngularVelocity
--
-- @function [parent=#PhysicsWorld] SetMaxNetworkAngularVelocity
-- @param self Self reference
-- @param #number velocity velocity

---
-- Function Raycast
--
-- @function [parent=#PhysicsWorld] Raycast
-- @param self Self reference
-- @param Ray#Ray ray ray
-- @param #number maxDistance maxDistance
-- @param #number collisionMask collisionMask
-- @return const PODVector<PhysicsRaycastResult>#const PODVector<PhysicsRaycastResult>

---
-- Function RaycastSingle
--
-- @function [parent=#PhysicsWorld] RaycastSingle
-- @param self Self reference
-- @param Ray#Ray ray ray
-- @param #number maxDistance maxDistance
-- @param #number collisionMask collisionMask
-- @return PhysicsRaycastResult#PhysicsRaycastResult

---
-- Function SphereCast
--
-- @function [parent=#PhysicsWorld] SphereCast
-- @param self Self reference
-- @param Ray#Ray ray ray
-- @param #number radius radius
-- @param #number maxDistance maxDistance
-- @param #number collisionMask collisionMask
-- @return PhysicsRaycastResult#PhysicsRaycastResult

---
-- Function DrawDebugGeometry
--
-- @function [parent=#PhysicsWorld] DrawDebugGeometry
-- @param self Self reference
-- @param #boolean depthTest depthTest

---
-- Function RemoveCachedGeometry
--
-- @function [parent=#PhysicsWorld] RemoveCachedGeometry
-- @param self Self reference
-- @param Model#Model model model

---
-- Function GetGravity
--
-- @function [parent=#PhysicsWorld] GetGravity
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetNumIterations
--
-- @function [parent=#PhysicsWorld] GetNumIterations
-- @param self Self reference
-- @return #number

---
-- Function GetInterpolation
--
-- @function [parent=#PhysicsWorld] GetInterpolation
-- @param self Self reference
-- @return #boolean

---
-- Function GetInternalEdge
--
-- @function [parent=#PhysicsWorld] GetInternalEdge
-- @param self Self reference
-- @return #boolean

---
-- Function GetSplitImpulse
--
-- @function [parent=#PhysicsWorld] GetSplitImpulse
-- @param self Self reference
-- @return #boolean

---
-- Function GetFps
--
-- @function [parent=#PhysicsWorld] GetFps
-- @param self Self reference
-- @return #number

---
-- Function GetMaxNetworkAngularVelocity
--
-- @function [parent=#PhysicsWorld] GetMaxNetworkAngularVelocity
-- @param self Self reference
-- @return #number

---
-- Field gravity
--
-- @field [parent=#PhysicsWorld] Vector3#Vector3 gravity

---
-- Field numIterations
--
-- @field [parent=#PhysicsWorld] #number numIterations

---
-- Field interpolation
--
-- @field [parent=#PhysicsWorld] #boolean interpolation

---
-- Field internalEdge
--
-- @field [parent=#PhysicsWorld] #boolean internalEdge

---
-- Field splitImpulse
--
-- @field [parent=#PhysicsWorld] #boolean splitImpulse

---
-- Field fps
--
-- @field [parent=#PhysicsWorld] #number fps

---
-- Field maxNetworkAngularVelocity
--
-- @field [parent=#PhysicsWorld] #number maxNetworkAngularVelocity

---
-- Field applyingTransforms
--
-- @field [parent=#PhysicsWorld] #boolean applyingTransforms

---
-- Function SetEnabled
--
-- @function [parent=#PhysicsWorld] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Remove
--
-- @function [parent=#PhysicsWorld] Remove
-- @param self Self reference

---
-- Function GetID
--
-- @function [parent=#PhysicsWorld] GetID
-- @param self Self reference
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#PhysicsWorld] GetNode
-- @param self Self reference
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#PhysicsWorld] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#PhysicsWorld] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#PhysicsWorld] IsEnabledEffective
-- @param self Self reference
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#PhysicsWorld] GetComponent
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#PhysicsWorld] GetComponent
-- @param self Self reference
-- @param #string type type
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#PhysicsWorld] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#PhysicsWorld] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#PhysicsWorld] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#PhysicsWorld] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#PhysicsWorld] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#PhysicsWorld] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#PhysicsWorld] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#PhysicsWorld] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#PhysicsWorld] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#PhysicsWorld] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#PhysicsWorld] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#PhysicsWorld] #string category


return nil
