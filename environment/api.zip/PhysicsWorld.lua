---
-- Module PhysicsWorld
-- extends Component
--
-- @module PhysicsWorld

---
-- Function Update
--
-- @function [parent=#PhysicsWorld] Update
-- @param #number timeSteptimeStep

---
-- Function UpdateCollisions
--
-- @function [parent=#PhysicsWorld] UpdateCollisions

---
-- Function SetFps
--
-- @function [parent=#PhysicsWorld] SetFps
-- @param #number fpsfps

---
-- Function SetGravity
--
-- @function [parent=#PhysicsWorld] SetGravity
-- @param Vector3#Vector3 gravitygravity

---
-- Function SetNumIterations
--
-- @function [parent=#PhysicsWorld] SetNumIterations
-- @param #number numnum

---
-- Function SetInterpolation
--
-- @function [parent=#PhysicsWorld] SetInterpolation
-- @param #boolean enableenable

---
-- Function SetInternalEdge
--
-- @function [parent=#PhysicsWorld] SetInternalEdge
-- @param #boolean enableenable

---
-- Function SetSplitImpulse
--
-- @function [parent=#PhysicsWorld] SetSplitImpulse
-- @param #boolean enableenable

---
-- Function SetMaxNetworkAngularVelocity
--
-- @function [parent=#PhysicsWorld] SetMaxNetworkAngularVelocity
-- @param #number velocityvelocity

---
-- Function Raycast
--
-- @function [parent=#PhysicsWorld] Raycast
-- @param Ray#Ray rayray
-- @param #number maxDistancemaxDistance
-- @param #number collisionMaskcollisionMask
-- @return const PODVector<PhysicsRaycastResult>#const PODVector<PhysicsRaycastResult>

---
-- Function RaycastSingle
--
-- @function [parent=#PhysicsWorld] RaycastSingle
-- @param Ray#Ray rayray
-- @param #number maxDistancemaxDistance
-- @param #number collisionMaskcollisionMask
-- @return PhysicsRaycastResult#PhysicsRaycastResult

---
-- Function SphereCast
--
-- @function [parent=#PhysicsWorld] SphereCast
-- @param Ray#Ray rayray
-- @param #number radiusradius
-- @param #number maxDistancemaxDistance
-- @param #number collisionMaskcollisionMask
-- @return PhysicsRaycastResult#PhysicsRaycastResult

---
-- Function DrawDebugGeometry
--
-- @function [parent=#PhysicsWorld] DrawDebugGeometry
-- @param #boolean depthTestdepthTest

---
-- Function RemoveCachedGeometry
--
-- @function [parent=#PhysicsWorld] RemoveCachedGeometry
-- @param Model#Model modelmodel

---
-- Function GetGravity
--
-- @function [parent=#PhysicsWorld] GetGravity
-- @return Vector3#Vector3

---
-- Function GetNumIterations
--
-- @function [parent=#PhysicsWorld] GetNumIterations
-- @return #number

---
-- Function GetInterpolation
--
-- @function [parent=#PhysicsWorld] GetInterpolation
-- @return #boolean

---
-- Function GetInternalEdge
--
-- @function [parent=#PhysicsWorld] GetInternalEdge
-- @return #boolean

---
-- Function GetSplitImpulse
--
-- @function [parent=#PhysicsWorld] GetSplitImpulse
-- @return #boolean

---
-- Function GetFps
--
-- @function [parent=#PhysicsWorld] GetFps
-- @return #number

---
-- Function GetMaxNetworkAngularVelocity
--
-- @function [parent=#PhysicsWorld] GetMaxNetworkAngularVelocity
-- @return #number

---
-- Field gravity
--
-- @field [parent=#PhysicsWorld] Vector3#Vector3 gravity

---
-- Field numIterations
--
-- @field [parent=#PhysicsWorld] #number numIterations

---
-- Field interpolation
--
-- @field [parent=#PhysicsWorld] #boolean interpolation

---
-- Field internalEdge
--
-- @field [parent=#PhysicsWorld] #boolean internalEdge

---
-- Field splitImpulse
--
-- @field [parent=#PhysicsWorld] #boolean splitImpulse

---
-- Field fps
--
-- @field [parent=#PhysicsWorld] #number fps

---
-- Field maxNetworkAngularVelocity
--
-- @field [parent=#PhysicsWorld] #number maxNetworkAngularVelocity

---
-- Field applyingTransforms
--
-- @field [parent=#PhysicsWorld] #boolean applyingTransforms

---
-- Function SetEnabled
--
-- @function [parent=#PhysicsWorld] SetEnabled
-- @param #boolean enableenable

---
-- Function Remove
--
-- @function [parent=#PhysicsWorld] Remove

---
-- Function GetID
--
-- @function [parent=#PhysicsWorld] GetID
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#PhysicsWorld] GetNode
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#PhysicsWorld] GetScene
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#PhysicsWorld] IsEnabled
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#PhysicsWorld] IsEnabledEffective
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#PhysicsWorld] GetComponent
-- @param ShortStringHash#ShortStringHash typetype
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#PhysicsWorld] GetComponent
-- @param #string typetype
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#PhysicsWorld] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#PhysicsWorld] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#PhysicsWorld] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#PhysicsWorld] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#PhysicsWorld] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#PhysicsWorld] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#PhysicsWorld] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#PhysicsWorld] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#PhysicsWorld] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#PhysicsWorld] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#PhysicsWorld] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#PhysicsWorld] #string category


return nil
