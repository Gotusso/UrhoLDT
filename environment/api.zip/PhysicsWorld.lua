---
-- Module PhysicsWorld
-- Module PhysicsWorld extends Component
-- Generated on 2014-05-31
--
-- @module PhysicsWorld

---
-- Function Update()
-- Step the simulation forward.
--
-- @function [parent=#PhysicsWorld] Update
-- @param self Self reference
-- @param #number timeStep timeStep

---
-- Function UpdateCollisions()
-- Refresh collisions only without updating dynamics.
--
-- @function [parent=#PhysicsWorld] UpdateCollisions
-- @param self Self reference

---
-- Function SetFps()
-- Set simulation steps per second.
--
-- @function [parent=#PhysicsWorld] SetFps
-- @param self Self reference
-- @param #number fps fps

---
-- Function SetGravity()
-- Set gravity.
--
-- @function [parent=#PhysicsWorld] SetGravity
-- @param self Self reference
-- @param Vector3#Vector3 gravity gravity

---
-- Function SetNumIterations()
-- Set number of constraint solver iterations.
--
-- @function [parent=#PhysicsWorld] SetNumIterations
-- @param self Self reference
-- @param #number num num

---
-- Function SetInterpolation()
-- Set whether to interpolate between simulation steps.
--
-- @function [parent=#PhysicsWorld] SetInterpolation
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetInternalEdge()
-- Set whether to use Bullet's internal edge utility for trimesh collisions. Disabled by default.
--
-- @function [parent=#PhysicsWorld] SetInternalEdge
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetSplitImpulse()
-- Set split impulse collision mode. This is more accurate, but slower. Disabled by default.
--
-- @function [parent=#PhysicsWorld] SetSplitImpulse
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetMaxNetworkAngularVelocity()
-- Set maximum angular velocity for network replication.
--
-- @function [parent=#PhysicsWorld] SetMaxNetworkAngularVelocity
-- @param self Self reference
-- @param #number velocity velocity

---
-- Function Raycast()
--
-- @function [parent=#PhysicsWorld] Raycast
-- @param self Self reference
-- @param Ray#Ray ray ray
-- @param #number maxDistance maxDistance
-- @param #number collisionMask collisionMask
-- @return const PODVector<PhysicsRaycastResult>#const PODVector<PhysicsRaycastResult>

---
-- Function RaycastSingle()
--
-- @function [parent=#PhysicsWorld] RaycastSingle
-- @param self Self reference
-- @param Ray#Ray ray ray
-- @param #number maxDistance maxDistance
-- @param #number collisionMask collisionMask
-- @return PhysicsRaycastResult#PhysicsRaycastResult

---
-- Function SphereCast()
--
-- @function [parent=#PhysicsWorld] SphereCast
-- @param self Self reference
-- @param Ray#Ray ray ray
-- @param #number radius radius
-- @param #number maxDistance maxDistance
-- @param #number collisionMask collisionMask
-- @return PhysicsRaycastResult#PhysicsRaycastResult

---
-- Function GetRigidBodies()
--
-- @function [parent=#PhysicsWorld] GetRigidBodies
-- @param self Self reference
-- @param Sphere#Sphere sphere sphere
-- @param #number collisionMask collisionMask
-- @return const PODVector<RigidBody*>#const PODVector<RigidBody*>

---
-- Function GetRigidBodies()
--
-- @function [parent=#PhysicsWorld] GetRigidBodies
-- @param self Self reference
-- @param BoundingBox#BoundingBox box box
-- @param #number collisionMask collisionMask
-- @return const PODVector<RigidBody*>#const PODVector<RigidBody*>

---
-- Function GetRigidBodies()
--
-- @function [parent=#PhysicsWorld] GetRigidBodies
-- @param self Self reference
-- @param RigidBody#RigidBody body body
-- @return const PODVector<RigidBody*>#const PODVector<RigidBody*>

---
-- Function DrawDebugGeometry()
-- Add debug geometry to the debug renderer.
--
-- @function [parent=#PhysicsWorld] DrawDebugGeometry
-- @param self Self reference
-- @param #boolean depthTest depthTest

---
-- Function RemoveCachedGeometry()
-- Invalidate cached collision geometry for a model.
--
-- @function [parent=#PhysicsWorld] RemoveCachedGeometry
-- @param self Self reference
-- @param Model#Model model model

---
-- Function GetGravity()
-- Return gravity.
--
-- @function [parent=#PhysicsWorld] GetGravity
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetNumIterations()
-- Return number of constraint solver iterations.
--
-- @function [parent=#PhysicsWorld] GetNumIterations
-- @param self Self reference
-- @return #number

---
-- Function GetInterpolation()
-- Return whether interpolation between simulation steps is enabled.
--
-- @function [parent=#PhysicsWorld] GetInterpolation
-- @param self Self reference
-- @return #boolean

---
-- Function GetInternalEdge()
-- Return whether Bullet's internal edge utility for trimesh collisions is enabled.
--
-- @function [parent=#PhysicsWorld] GetInternalEdge
-- @param self Self reference
-- @return #boolean

---
-- Function GetSplitImpulse()
-- Return whether split impulse collision mode is enabled.
--
-- @function [parent=#PhysicsWorld] GetSplitImpulse
-- @param self Self reference
-- @return #boolean

---
-- Function GetFps()
-- Return simulation steps per second.
--
-- @function [parent=#PhysicsWorld] GetFps
-- @param self Self reference
-- @return #number

---
-- Function GetMaxNetworkAngularVelocity()
-- Return maximum angular velocity for network replication.
--
-- @function [parent=#PhysicsWorld] GetMaxNetworkAngularVelocity
-- @param self Self reference
-- @return #number

---
-- Field gravity
--
-- @field [parent=#PhysicsWorld] Vector3#Vector3 gravity

---
-- Field numIterations
--
-- @field [parent=#PhysicsWorld] #number numIterations

---
-- Field interpolation
--
-- @field [parent=#PhysicsWorld] #boolean interpolation

---
-- Field internalEdge
--
-- @field [parent=#PhysicsWorld] #boolean internalEdge

---
-- Field splitImpulse
--
-- @field [parent=#PhysicsWorld] #boolean splitImpulse

---
-- Field fps
--
-- @field [parent=#PhysicsWorld] #number fps

---
-- Field maxNetworkAngularVelocity
--
-- @field [parent=#PhysicsWorld] #number maxNetworkAngularVelocity

---
-- Field applyingTransforms
--
-- @field [parent=#PhysicsWorld] #boolean applyingTransforms


return nil
