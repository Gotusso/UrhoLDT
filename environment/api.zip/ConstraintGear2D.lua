---
-- Module ConstraintGear2D
-- Module ConstraintGear2D extends Constraint2D
-- Generated on 2014-05-31
--
-- @module ConstraintGear2D

---
-- Function SetOwnerConstraint()
-- Set owner constraint.
--
-- @function [parent=#ConstraintGear2D] SetOwnerConstraint
-- @param self Self reference
-- @param Constraint2D#Constraint2D constraint constraint

---
-- Function SetOtherConstraint()
-- Set other constraint.
--
-- @function [parent=#ConstraintGear2D] SetOtherConstraint
-- @param self Self reference
-- @param Constraint2D#Constraint2D constraint constraint

---
-- Function SetRatio()
-- Set ratio.
--
-- @function [parent=#ConstraintGear2D] SetRatio
-- @param self Self reference
-- @param #number ratio ratio

---
-- Function GetOwnerConstraint()
-- Return owner constraint.
--
-- @function [parent=#ConstraintGear2D] GetOwnerConstraint
-- @param self Self reference
-- @return Constraint2D#Constraint2D

---
-- Function GetOtherConstraint()
-- Return other constraint.
--
-- @function [parent=#ConstraintGear2D] GetOtherConstraint
-- @param self Self reference
-- @return Constraint2D#Constraint2D

---
-- Function GetRatio()
-- Return ratio.
--
-- @function [parent=#ConstraintGear2D] GetRatio
-- @param self Self reference
-- @return #number

---
-- Field ownerConstraint
--
-- @field [parent=#ConstraintGear2D] Constraint2D#Constraint2D ownerConstraint

---
-- Field otherConstraint
--
-- @field [parent=#ConstraintGear2D] Constraint2D#Constraint2D otherConstraint

---
-- Field ratio
--
-- @field [parent=#ConstraintGear2D] #number ratio


return nil
