---
-- Module RemoteEvent
-- Generated on 2014-05-31
--
-- @module RemoteEvent

---
-- Field senderID
--
-- @field [parent=#RemoteEvent] #number senderID

---
-- Field eventType
--
-- @field [parent=#RemoteEvent] StringHash#StringHash eventType

---
-- Field eventData
--
-- @field [parent=#RemoteEvent] VariantMap#VariantMap eventData

---
-- Field inOrder
--
-- @field [parent=#RemoteEvent] #boolean inOrder


return nil
