---
-- Module StaticModel
-- Extends Drawable
--
-- @module StaticModel

---
-- Function SetModel
--
-- @function [parent=#StaticModel] SetModel
-- @param Model#Model modelmodel

---
-- Function SetMaterial
--
-- @function [parent=#StaticModel] SetMaterial
-- @param Material#Material materialmaterial

---
-- Function SetMaterial
--
-- @function [parent=#StaticModel] SetMaterial
-- @param #number indexindex
-- @param Material#Material materialmaterial
-- @return #boolean

---
-- Function SetOcclusionLodLevel
--
-- @function [parent=#StaticModel] SetOcclusionLodLevel
-- @param #number levellevel

---
-- Function ApplyMaterialList
--
-- @function [parent=#StaticModel] ApplyMaterialList
-- @param #string fileNamefileName

---
-- Function GetModel
--
-- @function [parent=#StaticModel] GetModel
-- @return Model#Model

---
-- Function GetNumGeometries
--
-- @function [parent=#StaticModel] GetNumGeometries
-- @return #number

---
-- Function GetMaterial
--
-- @function [parent=#StaticModel] GetMaterial
-- @param #number indexindex
-- @return Material#Material

---
-- Function GetOcclusionLodLevel
--
-- @function [parent=#StaticModel] GetOcclusionLodLevel
-- @return #number

---
-- Function IsInside
--
-- @function [parent=#StaticModel] IsInside
-- @param Vector3#Vector3 pointpoint
-- @return #boolean

---
-- Function IsInsideLocal
--
-- @function [parent=#StaticModel] IsInsideLocal
-- @param Vector3#Vector3 pointpoint
-- @return #boolean

---
-- Field model
--
-- @field [parent=#StaticModel] Model#Model model

---
-- Field material
--
-- @field [parent=#StaticModel] Material#Material material

---
-- Field boundingBox (Read only)
--
-- @field [parent=#StaticModel] BoundingBox#BoundingBox boundingBox

---
-- Field numGeometries (Read only)
--
-- @field [parent=#StaticModel] #number numGeometries

---
-- Field occlusionLodLevel
--
-- @field [parent=#StaticModel] #number occlusionLodLevel


return nil
