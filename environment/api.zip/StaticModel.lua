---
-- Module StaticModel
-- Module StaticModel extends Drawable
-- Generated on 2014-05-31
--
-- @module StaticModel

---
-- Function SetModel()
-- Set model.
--
-- @function [parent=#StaticModel] SetModel
-- @param self Self reference
-- @param Model#Model model model

---
-- Function SetMaterial()
-- Set material on all geometries.
--
-- @function [parent=#StaticModel] SetMaterial
-- @param self Self reference
-- @param Material#Material material material

---
-- Function SetMaterial()
-- Set material on one geometry. Return true if successful.
--
-- @function [parent=#StaticModel] SetMaterial
-- @param self Self reference
-- @param #number index index
-- @param Material#Material material material
-- @return #boolean

---
-- Function SetOcclusionLodLevel()
-- Set occlusion LOD level. By default (M_MAX_UNSIGNED) same as visible.
--
-- @function [parent=#StaticModel] SetOcclusionLodLevel
-- @param self Self reference
-- @param #number level level

---
-- Function ApplyMaterialList()
-- Apply default materials from a material list file. If filename is empty (default), the model's resource name with extension .txt will be used.
--
-- @function [parent=#StaticModel] ApplyMaterialList
-- @param self Self reference
-- @param #string fileName fileName

---
-- Function GetModel()
-- Return model.
--
-- @function [parent=#StaticModel] GetModel
-- @param self Self reference
-- @return Model#Model

---
-- Function GetNumGeometries()
-- Return number of geometries.
--
-- @function [parent=#StaticModel] GetNumGeometries
-- @param self Self reference
-- @return #number

---
-- Function GetMaterial()
-- Return material by geometry index.
--
-- @function [parent=#StaticModel] GetMaterial
-- @param self Self reference
-- @param #number index index
-- @return Material#Material

---
-- Function GetOcclusionLodLevel()
-- Return occlusion LOD level.
--
-- @function [parent=#StaticModel] GetOcclusionLodLevel
-- @param self Self reference
-- @return #number

---
-- Function IsInside()
-- Determines if the given world space point is within the model geometry.
--
-- @function [parent=#StaticModel] IsInside
-- @param self Self reference
-- @param Vector3#Vector3 point point
-- @return #boolean

---
-- Function IsInsideLocal()
-- Determines if the given local space point is within the model geometry.
--
-- @function [parent=#StaticModel] IsInsideLocal
-- @param self Self reference
-- @param Vector3#Vector3 point point
-- @return #boolean

---
-- Field model
--
-- @field [parent=#StaticModel] Model#Model model

---
-- Field material
--
-- @field [parent=#StaticModel] Material#Material material

---
-- Field boundingBox (Read only)
--
-- @field [parent=#StaticModel] BoundingBox#BoundingBox boundingBox

---
-- Field numGeometries (Read only)
--
-- @field [parent=#StaticModel] #number numGeometries

---
-- Field occlusionLodLevel
--
-- @field [parent=#StaticModel] #number occlusionLodLevel


return nil
