---
-- Module StaticModel
-- Module StaticModel extends Drawable
-- Generated on 2014-03-13
--
-- @module StaticModel

---
-- Function SetModel
--
-- @function [parent=#StaticModel] SetModel
-- @param self Self reference
-- @param Model#Model model model

---
-- Function SetMaterial
--
-- @function [parent=#StaticModel] SetMaterial
-- @param self Self reference
-- @param Material#Material material material

---
-- Function SetMaterial
--
-- @function [parent=#StaticModel] SetMaterial
-- @param self Self reference
-- @param #number index index
-- @param Material#Material material material
-- @return #boolean

---
-- Function SetOcclusionLodLevel
--
-- @function [parent=#StaticModel] SetOcclusionLodLevel
-- @param self Self reference
-- @param #number level level

---
-- Function ApplyMaterialList
--
-- @function [parent=#StaticModel] ApplyMaterialList
-- @param self Self reference
-- @param #string fileName fileName

---
-- Function GetModel
--
-- @function [parent=#StaticModel] GetModel
-- @param self Self reference
-- @return Model#Model

---
-- Function GetNumGeometries
--
-- @function [parent=#StaticModel] GetNumGeometries
-- @param self Self reference
-- @return #number

---
-- Function GetMaterial
--
-- @function [parent=#StaticModel] GetMaterial
-- @param self Self reference
-- @param #number index index
-- @return Material#Material

---
-- Function GetOcclusionLodLevel
--
-- @function [parent=#StaticModel] GetOcclusionLodLevel
-- @param self Self reference
-- @return #number

---
-- Function IsInside
--
-- @function [parent=#StaticModel] IsInside
-- @param self Self reference
-- @param Vector3#Vector3 point point
-- @return #boolean

---
-- Function IsInsideLocal
--
-- @function [parent=#StaticModel] IsInsideLocal
-- @param self Self reference
-- @param Vector3#Vector3 point point
-- @return #boolean

---
-- Field model
--
-- @field [parent=#StaticModel] Model#Model model

---
-- Field material
--
-- @field [parent=#StaticModel] Material#Material material

---
-- Field boundingBox (Read only)
--
-- @field [parent=#StaticModel] BoundingBox#BoundingBox boundingBox

---
-- Field numGeometries (Read only)
--
-- @field [parent=#StaticModel] #number numGeometries

---
-- Field occlusionLodLevel
--
-- @field [parent=#StaticModel] #number occlusionLodLevel

---
-- Function SetDrawDistance
--
-- @function [parent=#StaticModel] SetDrawDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetShadowDistance
--
-- @function [parent=#StaticModel] SetShadowDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetLodBias
--
-- @function [parent=#StaticModel] SetLodBias
-- @param self Self reference
-- @param #number bias bias

---
-- Function SetViewMask
--
-- @function [parent=#StaticModel] SetViewMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetLightMask
--
-- @function [parent=#StaticModel] SetLightMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetShadowMask
--
-- @function [parent=#StaticModel] SetShadowMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetZoneMask
--
-- @function [parent=#StaticModel] SetZoneMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetMaxLights
--
-- @function [parent=#StaticModel] SetMaxLights
-- @param self Self reference
-- @param #number num num

---
-- Function SetCastShadows
--
-- @function [parent=#StaticModel] SetCastShadows
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetOccluder
--
-- @function [parent=#StaticModel] SetOccluder
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetOccludee
--
-- @function [parent=#StaticModel] SetOccludee
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function MarkForUpdate
--
-- @function [parent=#StaticModel] MarkForUpdate
-- @param self Self reference

---
-- Function GetBoundingBox
--
-- @function [parent=#StaticModel] GetBoundingBox
-- @param self Self reference
-- @return const BoundingBox#const BoundingBox

---
-- Function GetWorldBoundingBox
--
-- @function [parent=#StaticModel] GetWorldBoundingBox
-- @param self Self reference
-- @return const BoundingBox#const BoundingBox

---
-- Function GetDrawableFlags
--
-- @function [parent=#StaticModel] GetDrawableFlags
-- @param self Self reference
-- @return #string

---
-- Function GetDrawDistance
--
-- @function [parent=#StaticModel] GetDrawDistance
-- @param self Self reference
-- @return #number

---
-- Function GetShadowDistance
--
-- @function [parent=#StaticModel] GetShadowDistance
-- @param self Self reference
-- @return #number

---
-- Function GetLodBias
--
-- @function [parent=#StaticModel] GetLodBias
-- @param self Self reference
-- @return #number

---
-- Function GetViewMask
--
-- @function [parent=#StaticModel] GetViewMask
-- @param self Self reference
-- @return #number

---
-- Function GetLightMask
--
-- @function [parent=#StaticModel] GetLightMask
-- @param self Self reference
-- @return #number

---
-- Function GetShadowMask
--
-- @function [parent=#StaticModel] GetShadowMask
-- @param self Self reference
-- @return #number

---
-- Function GetZoneMask
--
-- @function [parent=#StaticModel] GetZoneMask
-- @param self Self reference
-- @return #number

---
-- Function GetMaxLights
--
-- @function [parent=#StaticModel] GetMaxLights
-- @param self Self reference
-- @return #number

---
-- Function GetCastShadows
--
-- @function [parent=#StaticModel] GetCastShadows
-- @param self Self reference
-- @return #boolean

---
-- Function IsOccluder
--
-- @function [parent=#StaticModel] IsOccluder
-- @param self Self reference
-- @return #boolean

---
-- Function IsOccludee
--
-- @function [parent=#StaticModel] IsOccludee
-- @param self Self reference
-- @return #boolean

---
-- Function SetZone
--
-- @function [parent=#StaticModel] SetZone
-- @param self Self reference
-- @param Zone#Zone zone zone
-- @param #boolean temporary temporary

---
-- Function SetSortValue
--
-- @function [parent=#StaticModel] SetSortValue
-- @param self Self reference
-- @param #number value value

---
-- Function SetMinMaxZ
--
-- @function [parent=#StaticModel] SetMinMaxZ
-- @param self Self reference
-- @param #number minZ minZ
-- @param #number maxZ maxZ

---
-- Function MarkInView
--
-- @function [parent=#StaticModel] MarkInView
-- @param self Self reference
-- @param FrameInfo#FrameInfo frame frame
-- @param #boolean mainView mainView

---
-- Function ClearLights
--
-- @function [parent=#StaticModel] ClearLights
-- @param self Self reference

---
-- Function AddLight
--
-- @function [parent=#StaticModel] AddLight
-- @param self Self reference
-- @param Light#Light light light

---
-- Function AddVertexLight
--
-- @function [parent=#StaticModel] AddVertexLight
-- @param self Self reference
-- @param Light#Light light light

---
-- Function LimitLights
--
-- @function [parent=#StaticModel] LimitLights
-- @param self Self reference

---
-- Function LimitVertexLights
--
-- @function [parent=#StaticModel] LimitVertexLights
-- @param self Self reference

---
-- Function SetBasePass
--
-- @function [parent=#StaticModel] SetBasePass
-- @param self Self reference
-- @param #number batchIndex batchIndex

---
-- Function GetOctant
--
-- @function [parent=#StaticModel] GetOctant
-- @param self Self reference
-- @return Octant#Octant

---
-- Function GetZone
--
-- @function [parent=#StaticModel] GetZone
-- @param self Self reference
-- @return Zone#Zone

---
-- Function GetLastZone
--
-- @function [parent=#StaticModel] GetLastZone
-- @param self Self reference
-- @return Zone#Zone

---
-- Function IsZoneDirty
--
-- @function [parent=#StaticModel] IsZoneDirty
-- @param self Self reference
-- @return #boolean

---
-- Function GetDistance
--
-- @function [parent=#StaticModel] GetDistance
-- @param self Self reference
-- @return #number

---
-- Function GetLodDistance
--
-- @function [parent=#StaticModel] GetLodDistance
-- @param self Self reference
-- @return #number

---
-- Function GetSortValue
--
-- @function [parent=#StaticModel] GetSortValue
-- @param self Self reference
-- @return #number

---
-- Function IsInView
--
-- @function [parent=#StaticModel] IsInView
-- @param self Self reference
-- @param #number frameNumber frameNumber
-- @return #boolean

---
-- Function IsInView
--
-- @function [parent=#StaticModel] IsInView
-- @param self Self reference
-- @param FrameInfo#FrameInfo frame frame
-- @param #boolean mainView mainView
-- @return #boolean

---
-- Function HasBasePass
--
-- @function [parent=#StaticModel] HasBasePass
-- @param self Self reference
-- @param #number batchIndex batchIndex
-- @return #boolean

---
-- Function GetFirstLight
--
-- @function [parent=#StaticModel] GetFirstLight
-- @param self Self reference
-- @return Light#Light

---
-- Function GetMinZ
--
-- @function [parent=#StaticModel] GetMinZ
-- @param self Self reference
-- @return #number

---
-- Function GetMaxZ
--
-- @function [parent=#StaticModel] GetMaxZ
-- @param self Self reference
-- @return #number

---
-- Field worldBoundingBox (Read only)
--
-- @field [parent=#StaticModel] BoundingBox#BoundingBox worldBoundingBox

---
-- Field drawableFlags (Read only)
--
-- @field [parent=#StaticModel] #string drawableFlags

---
-- Field drawDistance
--
-- @field [parent=#StaticModel] #number drawDistance

---
-- Field shadowDistance
--
-- @field [parent=#StaticModel] #number shadowDistance

---
-- Field lodBias
--
-- @field [parent=#StaticModel] #number lodBias

---
-- Field viewMask
--
-- @field [parent=#StaticModel] #number viewMask

---
-- Field lightMask
--
-- @field [parent=#StaticModel] #number lightMask

---
-- Field shadowMask
--
-- @field [parent=#StaticModel] #number shadowMask

---
-- Field zoneMask
--
-- @field [parent=#StaticModel] #number zoneMask

---
-- Field maxLights
--
-- @field [parent=#StaticModel] #number maxLights

---
-- Field castShadows
--
-- @field [parent=#StaticModel] #boolean castShadows

---
-- Field occluder
--
-- @field [parent=#StaticModel] #boolean occluder

---
-- Field occludee
--
-- @field [parent=#StaticModel] #boolean occludee

---
-- Field octant (Read only)
--
-- @field [parent=#StaticModel] Octant#Octant octant

---
-- Field zone
--
-- @field [parent=#StaticModel] Zone#Zone zone

---
-- Field lastZone (Read only)
--
-- @field [parent=#StaticModel] Zone#Zone lastZone

---
-- Field zoneDirty (Read only)
--
-- @field [parent=#StaticModel] #boolean zoneDirty

---
-- Field distance (Read only)
--
-- @field [parent=#StaticModel] #number distance

---
-- Field lodDistance (Read only)
--
-- @field [parent=#StaticModel] #number lodDistance

---
-- Field sortValue
--
-- @field [parent=#StaticModel] #number sortValue

---
-- Field firstLight (Read only)
--
-- @field [parent=#StaticModel] Light#Light firstLight

---
-- Field minZ (Read only)
--
-- @field [parent=#StaticModel] #number minZ

---
-- Field maxZ (Read only)
--
-- @field [parent=#StaticModel] #number maxZ

---
-- Function SetEnabled
--
-- @function [parent=#StaticModel] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Remove
--
-- @function [parent=#StaticModel] Remove
-- @param self Self reference

---
-- Function GetID
--
-- @function [parent=#StaticModel] GetID
-- @param self Self reference
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#StaticModel] GetNode
-- @param self Self reference
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#StaticModel] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#StaticModel] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#StaticModel] IsEnabledEffective
-- @param self Self reference
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#StaticModel] GetComponent
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#StaticModel] GetComponent
-- @param self Self reference
-- @param #string type type
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#StaticModel] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#StaticModel] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#StaticModel] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#StaticModel] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#StaticModel] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#StaticModel] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#StaticModel] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#StaticModel] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#StaticModel] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#StaticModel] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#StaticModel] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#StaticModel] #string category


return nil
