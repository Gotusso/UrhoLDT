---
-- Module StaticModel
-- extends Drawable
--
-- @module StaticModel

---
-- Function SetModel
--
-- @function [parent=#StaticModel] SetModel
-- @param Model#Model modelmodel

---
-- Function SetMaterial
--
-- @function [parent=#StaticModel] SetMaterial
-- @param Material#Material materialmaterial

---
-- Function SetMaterial
--
-- @function [parent=#StaticModel] SetMaterial
-- @param #number indexindex
-- @param Material#Material materialmaterial
-- @return #boolean

---
-- Function SetOcclusionLodLevel
--
-- @function [parent=#StaticModel] SetOcclusionLodLevel
-- @param #number levellevel

---
-- Function ApplyMaterialList
--
-- @function [parent=#StaticModel] ApplyMaterialList
-- @param #string fileNamefileName

---
-- Function GetModel
--
-- @function [parent=#StaticModel] GetModel
-- @return Model#Model

---
-- Function GetNumGeometries
--
-- @function [parent=#StaticModel] GetNumGeometries
-- @return #number

---
-- Function GetMaterial
--
-- @function [parent=#StaticModel] GetMaterial
-- @param #number indexindex
-- @return Material#Material

---
-- Function GetOcclusionLodLevel
--
-- @function [parent=#StaticModel] GetOcclusionLodLevel
-- @return #number

---
-- Function IsInside
--
-- @function [parent=#StaticModel] IsInside
-- @param Vector3#Vector3 pointpoint
-- @return #boolean

---
-- Function IsInsideLocal
--
-- @function [parent=#StaticModel] IsInsideLocal
-- @param Vector3#Vector3 pointpoint
-- @return #boolean

---
-- Field model
--
-- @field [parent=#StaticModel] Model#Model model

---
-- Field material
--
-- @field [parent=#StaticModel] Material#Material material

---
-- Field boundingBox (Read only)
--
-- @field [parent=#StaticModel] BoundingBox#BoundingBox boundingBox

---
-- Field numGeometries (Read only)
--
-- @field [parent=#StaticModel] #number numGeometries

---
-- Field occlusionLodLevel
--
-- @field [parent=#StaticModel] #number occlusionLodLevel

---
-- Function SetDrawDistance
--
-- @function [parent=#StaticModel] SetDrawDistance
-- @param #number distancedistance

---
-- Function SetShadowDistance
--
-- @function [parent=#StaticModel] SetShadowDistance
-- @param #number distancedistance

---
-- Function SetLodBias
--
-- @function [parent=#StaticModel] SetLodBias
-- @param #number biasbias

---
-- Function SetViewMask
--
-- @function [parent=#StaticModel] SetViewMask
-- @param #number maskmask

---
-- Function SetLightMask
--
-- @function [parent=#StaticModel] SetLightMask
-- @param #number maskmask

---
-- Function SetShadowMask
--
-- @function [parent=#StaticModel] SetShadowMask
-- @param #number maskmask

---
-- Function SetZoneMask
--
-- @function [parent=#StaticModel] SetZoneMask
-- @param #number maskmask

---
-- Function SetMaxLights
--
-- @function [parent=#StaticModel] SetMaxLights
-- @param #number numnum

---
-- Function SetCastShadows
--
-- @function [parent=#StaticModel] SetCastShadows
-- @param #boolean enableenable

---
-- Function SetOccluder
--
-- @function [parent=#StaticModel] SetOccluder
-- @param #boolean enableenable

---
-- Function SetOccludee
--
-- @function [parent=#StaticModel] SetOccludee
-- @param #boolean enableenable

---
-- Function MarkForUpdate
--
-- @function [parent=#StaticModel] MarkForUpdate

---
-- Function GetBoundingBox
--
-- @function [parent=#StaticModel] GetBoundingBox
-- @return const BoundingBox#const BoundingBox

---
-- Function GetWorldBoundingBox
--
-- @function [parent=#StaticModel] GetWorldBoundingBox
-- @return const BoundingBox#const BoundingBox

---
-- Function GetDrawableFlags
--
-- @function [parent=#StaticModel] GetDrawableFlags
-- @return #string

---
-- Function GetDrawDistance
--
-- @function [parent=#StaticModel] GetDrawDistance
-- @return #number

---
-- Function GetShadowDistance
--
-- @function [parent=#StaticModel] GetShadowDistance
-- @return #number

---
-- Function GetLodBias
--
-- @function [parent=#StaticModel] GetLodBias
-- @return #number

---
-- Function GetViewMask
--
-- @function [parent=#StaticModel] GetViewMask
-- @return #number

---
-- Function GetLightMask
--
-- @function [parent=#StaticModel] GetLightMask
-- @return #number

---
-- Function GetShadowMask
--
-- @function [parent=#StaticModel] GetShadowMask
-- @return #number

---
-- Function GetZoneMask
--
-- @function [parent=#StaticModel] GetZoneMask
-- @return #number

---
-- Function GetMaxLights
--
-- @function [parent=#StaticModel] GetMaxLights
-- @return #number

---
-- Function GetCastShadows
--
-- @function [parent=#StaticModel] GetCastShadows
-- @return #boolean

---
-- Function IsOccluder
--
-- @function [parent=#StaticModel] IsOccluder
-- @return #boolean

---
-- Function IsOccludee
--
-- @function [parent=#StaticModel] IsOccludee
-- @return #boolean

---
-- Function SetZone
--
-- @function [parent=#StaticModel] SetZone
-- @param Zone#Zone zonezone
-- @param #boolean temporarytemporary

---
-- Function SetSortValue
--
-- @function [parent=#StaticModel] SetSortValue
-- @param #number valuevalue

---
-- Function SetMinMaxZ
--
-- @function [parent=#StaticModel] SetMinMaxZ
-- @param #number minZminZ
-- @param #number maxZmaxZ

---
-- Function MarkInView
--
-- @function [parent=#StaticModel] MarkInView
-- @param FrameInfo#FrameInfo frameframe
-- @param #boolean mainViewmainView

---
-- Function ClearLights
--
-- @function [parent=#StaticModel] ClearLights

---
-- Function AddLight
--
-- @function [parent=#StaticModel] AddLight
-- @param Light#Light lightlight

---
-- Function AddVertexLight
--
-- @function [parent=#StaticModel] AddVertexLight
-- @param Light#Light lightlight

---
-- Function LimitLights
--
-- @function [parent=#StaticModel] LimitLights

---
-- Function LimitVertexLights
--
-- @function [parent=#StaticModel] LimitVertexLights

---
-- Function SetBasePass
--
-- @function [parent=#StaticModel] SetBasePass
-- @param #number batchIndexbatchIndex

---
-- Function GetOctant
--
-- @function [parent=#StaticModel] GetOctant
-- @return Octant#Octant

---
-- Function GetZone
--
-- @function [parent=#StaticModel] GetZone
-- @return Zone#Zone

---
-- Function GetLastZone
--
-- @function [parent=#StaticModel] GetLastZone
-- @return Zone#Zone

---
-- Function IsZoneDirty
--
-- @function [parent=#StaticModel] IsZoneDirty
-- @return #boolean

---
-- Function GetDistance
--
-- @function [parent=#StaticModel] GetDistance
-- @return #number

---
-- Function GetLodDistance
--
-- @function [parent=#StaticModel] GetLodDistance
-- @return #number

---
-- Function GetSortValue
--
-- @function [parent=#StaticModel] GetSortValue
-- @return #number

---
-- Function IsInView
--
-- @function [parent=#StaticModel] IsInView
-- @param #number frameNumberframeNumber
-- @return #boolean

---
-- Function IsInView
--
-- @function [parent=#StaticModel] IsInView
-- @param FrameInfo#FrameInfo frameframe
-- @param #boolean mainViewmainView
-- @return #boolean

---
-- Function HasBasePass
--
-- @function [parent=#StaticModel] HasBasePass
-- @param #number batchIndexbatchIndex
-- @return #boolean

---
-- Function GetFirstLight
--
-- @function [parent=#StaticModel] GetFirstLight
-- @return Light#Light

---
-- Function GetMinZ
--
-- @function [parent=#StaticModel] GetMinZ
-- @return #number

---
-- Function GetMaxZ
--
-- @function [parent=#StaticModel] GetMaxZ
-- @return #number

---
-- Field worldBoundingBox (Read only)
--
-- @field [parent=#StaticModel] BoundingBox#BoundingBox worldBoundingBox

---
-- Field drawableFlags (Read only)
--
-- @field [parent=#StaticModel] #string drawableFlags

---
-- Field drawDistance
--
-- @field [parent=#StaticModel] #number drawDistance

---
-- Field shadowDistance
--
-- @field [parent=#StaticModel] #number shadowDistance

---
-- Field lodBias
--
-- @field [parent=#StaticModel] #number lodBias

---
-- Field viewMask
--
-- @field [parent=#StaticModel] #number viewMask

---
-- Field lightMask
--
-- @field [parent=#StaticModel] #number lightMask

---
-- Field shadowMask
--
-- @field [parent=#StaticModel] #number shadowMask

---
-- Field zoneMask
--
-- @field [parent=#StaticModel] #number zoneMask

---
-- Field maxLights
--
-- @field [parent=#StaticModel] #number maxLights

---
-- Field castShadows
--
-- @field [parent=#StaticModel] #boolean castShadows

---
-- Field occluder
--
-- @field [parent=#StaticModel] #boolean occluder

---
-- Field occludee
--
-- @field [parent=#StaticModel] #boolean occludee

---
-- Field octant (Read only)
--
-- @field [parent=#StaticModel] Octant#Octant octant

---
-- Field zone
--
-- @field [parent=#StaticModel] Zone#Zone zone

---
-- Field lastZone (Read only)
--
-- @field [parent=#StaticModel] Zone#Zone lastZone

---
-- Field zoneDirty (Read only)
--
-- @field [parent=#StaticModel] #boolean zoneDirty

---
-- Field distance (Read only)
--
-- @field [parent=#StaticModel] #number distance

---
-- Field lodDistance (Read only)
--
-- @field [parent=#StaticModel] #number lodDistance

---
-- Field sortValue
--
-- @field [parent=#StaticModel] #number sortValue

---
-- Field firstLight (Read only)
--
-- @field [parent=#StaticModel] Light#Light firstLight

---
-- Field minZ (Read only)
--
-- @field [parent=#StaticModel] #number minZ

---
-- Field maxZ (Read only)
--
-- @field [parent=#StaticModel] #number maxZ

---
-- Function SetEnabled
--
-- @function [parent=#StaticModel] SetEnabled
-- @param #boolean enableenable

---
-- Function Remove
--
-- @function [parent=#StaticModel] Remove

---
-- Function GetID
--
-- @function [parent=#StaticModel] GetID
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#StaticModel] GetNode
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#StaticModel] GetScene
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#StaticModel] IsEnabled
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#StaticModel] IsEnabledEffective
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#StaticModel] GetComponent
-- @param ShortStringHash#ShortStringHash typetype
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#StaticModel] GetComponent
-- @param #string typetype
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#StaticModel] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#StaticModel] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#StaticModel] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#StaticModel] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#StaticModel] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#StaticModel] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#StaticModel] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#StaticModel] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#StaticModel] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#StaticModel] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#StaticModel] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#StaticModel] #string category


return nil
