---
-- Module FileSelectorEntry
--
-- @module FileSelectorEntry

---
-- Field name
--
-- @field [parent=#FileSelectorEntry] #string name

---
-- Field directory
--
-- @field [parent=#FileSelectorEntry] #boolean directory


return nil
