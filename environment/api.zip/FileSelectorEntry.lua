---
-- Module FileSelectorEntry
-- Generated on 2014-03-13
--
-- @module FileSelectorEntry

---
-- Field name
--
-- @field [parent=#FileSelectorEntry] #string name

---
-- Field directory
--
-- @field [parent=#FileSelectorEntry] #boolean directory


return nil
