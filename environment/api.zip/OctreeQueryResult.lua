---
-- Module OctreeQueryResult
--
-- @module OctreeQueryResult

---
-- Function OctreeQueryResult
--
-- @function [parent=#OctreeQueryResult] OctreeQueryResult

---
-- Function new
--
-- @function [parent=#OctreeQueryResult] new
-- @return OctreeQueryResult#OctreeQueryResult

---
-- Function delete
--
-- @function [parent=#OctreeQueryResult] delete

---
-- Field drawable
--
-- @field [parent=#OctreeQueryResult] Drawable#Drawable drawable

---
-- Field node
--
-- @field [parent=#OctreeQueryResult] Node#Node node


return nil
