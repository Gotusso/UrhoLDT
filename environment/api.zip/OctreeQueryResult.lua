---
-- Module OctreeQueryResult
-- Generated on 2014-03-13
--
-- @module OctreeQueryResult

---
-- Function OctreeQueryResult
--
-- @function [parent=#OctreeQueryResult] OctreeQueryResult
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#OctreeQueryResult] new
-- @param self Self reference
-- @return OctreeQueryResult#OctreeQueryResult

---
-- Function delete
--
-- @function [parent=#OctreeQueryResult] delete
-- @param self Self reference

---
-- Field drawable
--
-- @field [parent=#OctreeQueryResult] Drawable#Drawable drawable

---
-- Field node
--
-- @field [parent=#OctreeQueryResult] Node#Node node


return nil
