---
-- Module Constraint
-- Module Constraint extends Component
-- Generated on 2014-05-31
--
-- @module Constraint

---
-- Function SetConstraintType()
-- Set constraint type and recreate the constraint.
--
-- @function [parent=#Constraint] SetConstraintType
-- @param self Self reference
-- @param ConstraintType#ConstraintType type type

---
-- Function SetOtherBody()
-- Set other body to connect to. Set to null to connect to the static world.
--
-- @function [parent=#Constraint] SetOtherBody
-- @param self Self reference
-- @param RigidBody#RigidBody body body

---
-- Function SetPosition()
-- Set constraint position relative to own body.
--
-- @function [parent=#Constraint] SetPosition
-- @param self Self reference
-- @param Vector3#Vector3 position position

---
-- Function SetRotation()
-- Set constraint rotation relative to own body.
--
-- @function [parent=#Constraint] SetRotation
-- @param self Self reference
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetAxis()
-- Set constraint rotation relative to own body by specifying the axis.
--
-- @function [parent=#Constraint] SetAxis
-- @param self Self reference
-- @param Vector3#Vector3 axis axis

---
-- Function SetOtherPosition()
-- Set constraint position relative to the other body. If connected to the static world, is a world space position.
--
-- @function [parent=#Constraint] SetOtherPosition
-- @param self Self reference
-- @param Vector3#Vector3 position position

---
-- Function SetOtherRotation()
-- Set constraint rotation relative to the other body. If connected to the static world, is a world space rotation.
--
-- @function [parent=#Constraint] SetOtherRotation
-- @param self Self reference
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetOtherAxis()
-- Set constraint rotation relative to the other body by specifying the axis.
--
-- @function [parent=#Constraint] SetOtherAxis
-- @param self Self reference
-- @param Vector3#Vector3 axis axis

---
-- Function SetWorldPosition()
-- Set constraint world space position. Resets both own and other body relative position, ie. zeroes the constraint error.
--
-- @function [parent=#Constraint] SetWorldPosition
-- @param self Self reference
-- @param Vector3#Vector3 position position

---
-- Function SetHighLimit()
-- Set high limit. Interpretation is constraint type specific.
--
-- @function [parent=#Constraint] SetHighLimit
-- @param self Self reference
-- @param Vector2#Vector2 limit limit

---
-- Function SetLowLimit()
-- Set low limit. Interpretation is constraint type specific.
--
-- @function [parent=#Constraint] SetLowLimit
-- @param self Self reference
-- @param Vector2#Vector2 limit limit

---
-- Function SetERP()
-- Set constraint error reduction parameter. Zero = leave to default.
--
-- @function [parent=#Constraint] SetERP
-- @param self Self reference
-- @param #number erp erp

---
-- Function SetCFM()
-- Set constraint force mixing parameter. Zero = leave to default.
--
-- @function [parent=#Constraint] SetCFM
-- @param self Self reference
-- @param #number cfm cfm

---
-- Function SetDisableCollision()
-- Set whether to disable collisions between connected bodies.
--
-- @function [parent=#Constraint] SetDisableCollision
-- @param self Self reference
-- @param #boolean disable disable

---
-- Function GetPhysicsWorld()
-- Return physics world.
--
-- @function [parent=#Constraint] GetPhysicsWorld
-- @param self Self reference
-- @return PhysicsWorld#PhysicsWorld

---
-- Function GetConstraintType()
-- Return constraint type.
--
-- @function [parent=#Constraint] GetConstraintType
-- @param self Self reference
-- @return ConstraintType#ConstraintType

---
-- Function GetOwnBody()
-- Return rigid body in own scene node.
--
-- @function [parent=#Constraint] GetOwnBody
-- @param self Self reference
-- @return RigidBody#RigidBody

---
-- Function GetOtherBody()
-- Return the other rigid body. May be null if connected to the static world.
--
-- @function [parent=#Constraint] GetOtherBody
-- @param self Self reference
-- @return RigidBody#RigidBody

---
-- Function GetPosition()
-- Return constraint position relative to own body.
--
-- @function [parent=#Constraint] GetPosition
-- @param self Self reference
-- @return const Vector3#const Vector3

---
-- Function GetRotation()
-- Return constraint rotation relative to own body.
--
-- @function [parent=#Constraint] GetRotation
-- @param self Self reference
-- @return const Quaternion#const Quaternion

---
-- Function GetOtherPosition()
-- Return constraint position relative to other body.
--
-- @function [parent=#Constraint] GetOtherPosition
-- @param self Self reference
-- @return const Vector3#const Vector3

---
-- Function GetOtherRotation()
-- Return constraint rotation relative to other body.
--
-- @function [parent=#Constraint] GetOtherRotation
-- @param self Self reference
-- @return const Quaternion#const Quaternion

---
-- Function GetWorldPosition()
-- Return constraint world position, calculated from own body.
--
-- @function [parent=#Constraint] GetWorldPosition
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetHighLimit()
-- Return high limit.
--
-- @function [parent=#Constraint] GetHighLimit
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Function GetLowLimit()
-- Return low limit.
--
-- @function [parent=#Constraint] GetLowLimit
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Function GetERP()
-- Return constraint error reduction parameter.
--
-- @function [parent=#Constraint] GetERP
-- @param self Self reference
-- @return #number

---
-- Function GetCFM()
-- Return constraint force mixing parameter.
--
-- @function [parent=#Constraint] GetCFM
-- @param self Self reference
-- @return #number

---
-- Function GetDisableCollision()
-- Return whether collisions between connected bodies are disabled.
--
-- @function [parent=#Constraint] GetDisableCollision
-- @param self Self reference
-- @return #boolean

---
-- Field physicsWorld (Read only)
--
-- @field [parent=#Constraint] PhysicsWorld#PhysicsWorld physicsWorld

---
-- Field constraintType
--
-- @field [parent=#Constraint] ConstraintType#ConstraintType constraintType

---
-- Field ownBody (Read only)
--
-- @field [parent=#Constraint] RigidBody#RigidBody ownBody

---
-- Field otherBody
--
-- @field [parent=#Constraint] RigidBody#RigidBody otherBody

---
-- Field position
--
-- @field [parent=#Constraint] Vector3#Vector3 position

---
-- Field rotation
--
-- @field [parent=#Constraint] Quaternion#Quaternion rotation

---
-- Field axis
--
-- @field [parent=#Constraint] Vector3#Vector3 axis

---
-- Field otherPosition
--
-- @field [parent=#Constraint] Vector3#Vector3 otherPosition

---
-- Field otherRotation
--
-- @field [parent=#Constraint] Quaternion#Quaternion otherRotation

---
-- Field otherAxis
--
-- @field [parent=#Constraint] Vector3#Vector3 otherAxis

---
-- Field worldPosition
--
-- @field [parent=#Constraint] Vector3#Vector3 worldPosition

---
-- Field highLimit
--
-- @field [parent=#Constraint] Vector2#Vector2 highLimit

---
-- Field lowLimit
--
-- @field [parent=#Constraint] Vector2#Vector2 lowLimit

---
-- Field ERP
--
-- @field [parent=#Constraint] #number ERP

---
-- Field CFM
--
-- @field [parent=#Constraint] #number CFM

---
-- Field disableCollision
--
-- @field [parent=#Constraint] #boolean disableCollision


return nil
