---
-- Module Constraint
-- Module Constraint extends Component
-- Generated on 2014-03-13
--
-- @module Constraint

---
-- Function SetConstraintType
--
-- @function [parent=#Constraint] SetConstraintType
-- @param self Self reference
-- @param ConstraintType#ConstraintType type type

---
-- Function SetOtherBody
--
-- @function [parent=#Constraint] SetOtherBody
-- @param self Self reference
-- @param RigidBody#RigidBody body body

---
-- Function SetPosition
--
-- @function [parent=#Constraint] SetPosition
-- @param self Self reference
-- @param Vector3#Vector3 position position

---
-- Function SetRotation
--
-- @function [parent=#Constraint] SetRotation
-- @param self Self reference
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetAxis
--
-- @function [parent=#Constraint] SetAxis
-- @param self Self reference
-- @param Vector3#Vector3 axis axis

---
-- Function SetOtherPosition
--
-- @function [parent=#Constraint] SetOtherPosition
-- @param self Self reference
-- @param Vector3#Vector3 position position

---
-- Function SetOtherRotation
--
-- @function [parent=#Constraint] SetOtherRotation
-- @param self Self reference
-- @param Quaternion#Quaternion rotation rotation

---
-- Function SetOtherAxis
--
-- @function [parent=#Constraint] SetOtherAxis
-- @param self Self reference
-- @param Vector3#Vector3 axis axis

---
-- Function SetWorldPosition
--
-- @function [parent=#Constraint] SetWorldPosition
-- @param self Self reference
-- @param Vector3#Vector3 position position

---
-- Function SetHighLimit
--
-- @function [parent=#Constraint] SetHighLimit
-- @param self Self reference
-- @param Vector2#Vector2 limit limit

---
-- Function SetLowLimit
--
-- @function [parent=#Constraint] SetLowLimit
-- @param self Self reference
-- @param Vector2#Vector2 limit limit

---
-- Function SetERP
--
-- @function [parent=#Constraint] SetERP
-- @param self Self reference
-- @param #number erp erp

---
-- Function SetCFM
--
-- @function [parent=#Constraint] SetCFM
-- @param self Self reference
-- @param #number cfm cfm

---
-- Function SetDisableCollision
--
-- @function [parent=#Constraint] SetDisableCollision
-- @param self Self reference
-- @param #boolean disable disable

---
-- Function GetPhysicsWorld
--
-- @function [parent=#Constraint] GetPhysicsWorld
-- @param self Self reference
-- @return PhysicsWorld#PhysicsWorld

---
-- Function GetConstraintType
--
-- @function [parent=#Constraint] GetConstraintType
-- @param self Self reference
-- @return ConstraintType#ConstraintType

---
-- Function GetOwnBody
--
-- @function [parent=#Constraint] GetOwnBody
-- @param self Self reference
-- @return RigidBody#RigidBody

---
-- Function GetOtherBody
--
-- @function [parent=#Constraint] GetOtherBody
-- @param self Self reference
-- @return RigidBody#RigidBody

---
-- Function GetPosition
--
-- @function [parent=#Constraint] GetPosition
-- @param self Self reference
-- @return const Vector3#const Vector3

---
-- Function GetRotation
--
-- @function [parent=#Constraint] GetRotation
-- @param self Self reference
-- @return const Quaternion#const Quaternion

---
-- Function GetOtherPosition
--
-- @function [parent=#Constraint] GetOtherPosition
-- @param self Self reference
-- @return const Vector3#const Vector3

---
-- Function GetOtherRotation
--
-- @function [parent=#Constraint] GetOtherRotation
-- @param self Self reference
-- @return const Quaternion#const Quaternion

---
-- Function GetWorldPosition
--
-- @function [parent=#Constraint] GetWorldPosition
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetHighLimit
--
-- @function [parent=#Constraint] GetHighLimit
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Function GetLowLimit
--
-- @function [parent=#Constraint] GetLowLimit
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Function GetERP
--
-- @function [parent=#Constraint] GetERP
-- @param self Self reference
-- @return #number

---
-- Function GetCFM
--
-- @function [parent=#Constraint] GetCFM
-- @param self Self reference
-- @return #number

---
-- Function GetDisableCollision
--
-- @function [parent=#Constraint] GetDisableCollision
-- @param self Self reference
-- @return #boolean

---
-- Field physicsWorld (Read only)
--
-- @field [parent=#Constraint] PhysicsWorld#PhysicsWorld physicsWorld

---
-- Field constraintType
--
-- @field [parent=#Constraint] ConstraintType#ConstraintType constraintType

---
-- Field ownBody (Read only)
--
-- @field [parent=#Constraint] RigidBody#RigidBody ownBody

---
-- Field otherBody
--
-- @field [parent=#Constraint] RigidBody#RigidBody otherBody

---
-- Field position
--
-- @field [parent=#Constraint] Vector3#Vector3 position

---
-- Field rotation
--
-- @field [parent=#Constraint] Quaternion#Quaternion rotation

---
-- Field axis
--
-- @field [parent=#Constraint] Vector3#Vector3 axis

---
-- Field otherPosition
--
-- @field [parent=#Constraint] Vector3#Vector3 otherPosition

---
-- Field otherRotation
--
-- @field [parent=#Constraint] Quaternion#Quaternion otherRotation

---
-- Field otherAxis
--
-- @field [parent=#Constraint] Vector3#Vector3 otherAxis

---
-- Field worldPosition
--
-- @field [parent=#Constraint] Vector3#Vector3 worldPosition

---
-- Field highLimit
--
-- @field [parent=#Constraint] Vector2#Vector2 highLimit

---
-- Field lowLimit
--
-- @field [parent=#Constraint] Vector2#Vector2 lowLimit

---
-- Field ERP
--
-- @field [parent=#Constraint] #number ERP

---
-- Field CFM
--
-- @field [parent=#Constraint] #number CFM

---
-- Field disableCollision
--
-- @field [parent=#Constraint] #boolean disableCollision

---
-- Function SetEnabled
--
-- @function [parent=#Constraint] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Remove
--
-- @function [parent=#Constraint] Remove
-- @param self Self reference

---
-- Function GetID
--
-- @function [parent=#Constraint] GetID
-- @param self Self reference
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#Constraint] GetNode
-- @param self Self reference
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#Constraint] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#Constraint] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#Constraint] IsEnabledEffective
-- @param self Self reference
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#Constraint] GetComponent
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#Constraint] GetComponent
-- @param self Self reference
-- @param #string type type
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#Constraint] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#Constraint] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Constraint] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Constraint] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Constraint] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Constraint] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Constraint] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Constraint] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#Constraint] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Constraint] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Constraint] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Constraint] #string category


return nil
