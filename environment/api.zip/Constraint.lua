---
-- Module Constraint
-- Extends Component
--
-- @module Constraint

---
-- Function SetConstraintType
--
-- @function [parent=#Constraint] SetConstraintType
-- @param ConstraintType#ConstraintType typetype

---
-- Function SetOtherBody
--
-- @function [parent=#Constraint] SetOtherBody
-- @param RigidBody#RigidBody bodybody

---
-- Function SetPosition
--
-- @function [parent=#Constraint] SetPosition
-- @param Vector3#Vector3 positionposition

---
-- Function SetRotation
--
-- @function [parent=#Constraint] SetRotation
-- @param Quaternion#Quaternion rotationrotation

---
-- Function SetAxis
--
-- @function [parent=#Constraint] SetAxis
-- @param Vector3#Vector3 axisaxis

---
-- Function SetOtherPosition
--
-- @function [parent=#Constraint] SetOtherPosition
-- @param Vector3#Vector3 positionposition

---
-- Function SetOtherRotation
--
-- @function [parent=#Constraint] SetOtherRotation
-- @param Quaternion#Quaternion rotationrotation

---
-- Function SetOtherAxis
--
-- @function [parent=#Constraint] SetOtherAxis
-- @param Vector3#Vector3 axisaxis

---
-- Function SetWorldPosition
--
-- @function [parent=#Constraint] SetWorldPosition
-- @param Vector3#Vector3 positionposition

---
-- Function SetHighLimit
--
-- @function [parent=#Constraint] SetHighLimit
-- @param Vector2#Vector2 limitlimit

---
-- Function SetLowLimit
--
-- @function [parent=#Constraint] SetLowLimit
-- @param Vector2#Vector2 limitlimit

---
-- Function SetERP
--
-- @function [parent=#Constraint] SetERP
-- @param #number erperp

---
-- Function SetCFM
--
-- @function [parent=#Constraint] SetCFM
-- @param #number cfmcfm

---
-- Function SetDisableCollision
--
-- @function [parent=#Constraint] SetDisableCollision
-- @param #boolean disabledisable

---
-- Function GetPhysicsWorld
--
-- @function [parent=#Constraint] GetPhysicsWorld
-- @return PhysicsWorld#PhysicsWorld

---
-- Function GetConstraintType
--
-- @function [parent=#Constraint] GetConstraintType
-- @return ConstraintType#ConstraintType

---
-- Function GetOwnBody
--
-- @function [parent=#Constraint] GetOwnBody
-- @return RigidBody#RigidBody

---
-- Function GetOtherBody
--
-- @function [parent=#Constraint] GetOtherBody
-- @return RigidBody#RigidBody

---
-- Function GetPosition
--
-- @function [parent=#Constraint] GetPosition
-- @return const Vector3#const Vector3

---
-- Function GetRotation
--
-- @function [parent=#Constraint] GetRotation
-- @return const Quaternion#const Quaternion

---
-- Function GetOtherPosition
--
-- @function [parent=#Constraint] GetOtherPosition
-- @return const Vector3#const Vector3

---
-- Function GetOtherRotation
--
-- @function [parent=#Constraint] GetOtherRotation
-- @return const Quaternion#const Quaternion

---
-- Function GetWorldPosition
--
-- @function [parent=#Constraint] GetWorldPosition
-- @return Vector3#Vector3

---
-- Function GetHighLimit
--
-- @function [parent=#Constraint] GetHighLimit
-- @return const Vector2#const Vector2

---
-- Function GetLowLimit
--
-- @function [parent=#Constraint] GetLowLimit
-- @return const Vector2#const Vector2

---
-- Function GetERP
--
-- @function [parent=#Constraint] GetERP
-- @return #number

---
-- Function GetCFM
--
-- @function [parent=#Constraint] GetCFM
-- @return #number

---
-- Function GetDisableCollision
--
-- @function [parent=#Constraint] GetDisableCollision
-- @return #boolean

---
-- Field physicsWorld (Read only)
--
-- @field [parent=#Constraint] PhysicsWorld#PhysicsWorld physicsWorld

---
-- Field constraintType
--
-- @field [parent=#Constraint] ConstraintType#ConstraintType constraintType

---
-- Field ownBody (Read only)
--
-- @field [parent=#Constraint] RigidBody#RigidBody ownBody

---
-- Field otherBody
--
-- @field [parent=#Constraint] RigidBody#RigidBody otherBody

---
-- Field position
--
-- @field [parent=#Constraint] Vector3#Vector3 position

---
-- Field rotation
--
-- @field [parent=#Constraint] Quaternion#Quaternion rotation

---
-- Field axis
--
-- @field [parent=#Constraint] Vector3#Vector3 axis

---
-- Field otherPosition
--
-- @field [parent=#Constraint] Vector3#Vector3 otherPosition

---
-- Field otherRotation
--
-- @field [parent=#Constraint] Quaternion#Quaternion otherRotation

---
-- Field otherAxis
--
-- @field [parent=#Constraint] Vector3#Vector3 otherAxis

---
-- Field worldPosition
--
-- @field [parent=#Constraint] Vector3#Vector3 worldPosition

---
-- Field highLimit
--
-- @field [parent=#Constraint] Vector2#Vector2 highLimit

---
-- Field lowLimit
--
-- @field [parent=#Constraint] Vector2#Vector2 lowLimit

---
-- Field ERP
--
-- @field [parent=#Constraint] #number ERP

---
-- Field CFM
--
-- @field [parent=#Constraint] #number CFM

---
-- Field disableCollision
--
-- @field [parent=#Constraint] #boolean disableCollision


return nil
