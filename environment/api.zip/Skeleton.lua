---
-- Module Skeleton
-- Generated on 2014-03-13
--
-- @module Skeleton

---
-- Function GetNumBones
--
-- @function [parent=#Skeleton] GetNumBones
-- @param self Self reference
-- @return #number

---
-- Function GetRootBone
--
-- @function [parent=#Skeleton] GetRootBone
-- @param self Self reference
-- @return Bone#Bone

---
-- Function GetBone
--
-- @function [parent=#Skeleton] GetBone
-- @param self Self reference
-- @param #string name name
-- @return Bone#Bone

---
-- Function GetBone
--
-- @function [parent=#Skeleton] GetBone
-- @param self Self reference
-- @param #number index index
-- @return Bone#Bone

---
-- Field numBones (Read only)
--
-- @field [parent=#Skeleton] #number numBones

---
-- Field rootBone (Read only)
--
-- @field [parent=#Skeleton] Bone#Bone rootBone


return nil
