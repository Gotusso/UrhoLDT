---
-- Module Skeleton
--
-- @module Skeleton

---
-- Function GetNumBones
--
-- @function [parent=#Skeleton] GetNumBones
-- @return #number

---
-- Function GetRootBone
--
-- @function [parent=#Skeleton] GetRootBone
-- @return Bone#Bone

---
-- Function GetBone
--
-- @function [parent=#Skeleton] GetBone
-- @param #string namename
-- @return Bone#Bone

---
-- Function GetBone
--
-- @function [parent=#Skeleton] GetBone
-- @param #number indexindex
-- @return Bone#Bone

---
-- Field numBones (Read only)
--
-- @field [parent=#Skeleton] #number numBones

---
-- Field rootBone (Read only)
--
-- @field [parent=#Skeleton] Bone#Bone rootBone


return nil
