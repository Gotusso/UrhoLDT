---
-- Module Skeleton
-- Generated on 2014-05-31
--
-- @module Skeleton

---
-- Function GetNumBones()
-- Return number of bones.
--
-- @function [parent=#Skeleton] GetNumBones
-- @param self Self reference
-- @return #number

---
-- Function GetRootBone()
-- Return root bone.
--
-- @function [parent=#Skeleton] GetRootBone
-- @param self Self reference
-- @return Bone#Bone

---
-- Function GetBone()
-- Return bone by name.
--
-- @function [parent=#Skeleton] GetBone
-- @param self Self reference
-- @param #string name name
-- @return Bone#Bone

---
-- Function GetBone()
-- Return bone by index.
--
-- @function [parent=#Skeleton] GetBone
-- @param self Self reference
-- @param #number index index
-- @return Bone#Bone

---
-- Field numBones (Read only)
--
-- @field [parent=#Skeleton] #number numBones

---
-- Field rootBone (Read only)
--
-- @field [parent=#Skeleton] Bone#Bone rootBone


return nil
