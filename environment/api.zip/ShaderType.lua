---
-- Enumeration ShaderType
--
-- @module ShaderType

---
-- Enumeration value VS
--
-- @field [parent=#ShaderType] #number VS

---
-- Enumeration value PS
--
-- @field [parent=#ShaderType] #number PS


return nil
