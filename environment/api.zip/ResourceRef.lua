---
-- Module ResourceRef
--
-- @module ResourceRef

---
-- Function ResourceRef
--
-- @function [parent=#ResourceRef] ResourceRef

---
-- Function new
--
-- @function [parent=#ResourceRef] new
-- @return ResourceRef#ResourceRef

---
-- Function ResourceRef
--
-- @function [parent=#ResourceRef] ResourceRef
-- @param ShortStringHash#ShortStringHash typetype

---
-- Function new
--
-- @function [parent=#ResourceRef] new
-- @param ShortStringHash#ShortStringHash typetype
-- @return ResourceRef#ResourceRef

---
-- Function ResourceRef
--
-- @function [parent=#ResourceRef] ResourceRef
-- @param ShortStringHash#ShortStringHash typetype
-- @param #string namename

---
-- Function new
--
-- @function [parent=#ResourceRef] new
-- @param ShortStringHash#ShortStringHash typetype
-- @param #string namename
-- @return ResourceRef#ResourceRef

---
-- Function ResourceRef
--
-- @function [parent=#ResourceRef] ResourceRef
-- @param ResourceRef#ResourceRef rhsrhs

---
-- Function new
--
-- @function [parent=#ResourceRef] new
-- @param ResourceRef#ResourceRef rhsrhs
-- @return ResourceRef#ResourceRef

---
-- Function delete
--
-- @function [parent=#ResourceRef] delete

---
-- Function operator==
--
-- @function [parent=#ResourceRef] operator==
-- @param ResourceRef#ResourceRef rhsrhs
-- @return #boolean

---
-- Field type
--
-- @field [parent=#ResourceRef] ShortStringHash#ShortStringHash type

---
-- Field name
--
-- @field [parent=#ResourceRef] #string name


return nil
