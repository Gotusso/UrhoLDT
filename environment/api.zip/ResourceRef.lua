---
-- Module ResourceRef
-- Generated on 2014-05-31
--
-- @module ResourceRef

---
-- Function ResourceRef()
--
-- @function [parent=#ResourceRef] ResourceRef
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#ResourceRef] new
-- @param self Self reference
-- @return ResourceRef#ResourceRef

---
-- Function ResourceRef()
--
-- @function [parent=#ResourceRef] ResourceRef
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type

---
-- Function new()
--
-- @function [parent=#ResourceRef] new
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return ResourceRef#ResourceRef

---
-- Function ResourceRef()
--
-- @function [parent=#ResourceRef] ResourceRef
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @param #string name name

---
-- Function new()
--
-- @function [parent=#ResourceRef] new
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @param #string name name
-- @return ResourceRef#ResourceRef

---
-- Function ResourceRef()
--
-- @function [parent=#ResourceRef] ResourceRef
-- @param self Self reference
-- @param ResourceRef#ResourceRef rhs rhs

---
-- Function new()
--
-- @function [parent=#ResourceRef] new
-- @param self Self reference
-- @param ResourceRef#ResourceRef rhs rhs
-- @return ResourceRef#ResourceRef

---
-- Function delete()
--
-- @function [parent=#ResourceRef] delete
-- @param self Self reference

---
-- Function operator==()
--
-- @function [parent=#ResourceRef] operator==
-- @param self Self reference
-- @param ResourceRef#ResourceRef rhs rhs
-- @return #boolean

---
-- Field type
--
-- @field [parent=#ResourceRef] ShortStringHash#ShortStringHash type

---
-- Field name
--
-- @field [parent=#ResourceRef] #string name


return nil
