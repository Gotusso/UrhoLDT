---
-- Enumeration DeferredLightVSVariation
--
-- @module DeferredLightVSVariation

---
-- Enumeration value DLVS_NONE
--
-- @field [parent=#DeferredLightVSVariation] #number DLVS_NONE

---
-- Enumeration value DLVS_DIR
--
-- @field [parent=#DeferredLightVSVariation] #number DLVS_DIR

---
-- Enumeration value DLVS_ORTHO
--
-- @field [parent=#DeferredLightVSVariation] #number DLVS_ORTHO

---
-- Enumeration value DLVS_ORTHODIR
--
-- @field [parent=#DeferredLightVSVariation] #number DLVS_ORTHODIR

---
-- Enumeration value MAX_DEFERRED_LIGHT_VS_VARIATIONS
--
-- @field [parent=#DeferredLightVSVariation] #number MAX_DEFERRED_LIGHT_VS_VARIATIONS


return nil
