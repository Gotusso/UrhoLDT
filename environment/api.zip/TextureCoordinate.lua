---
-- Enumeration TextureCoordinate
--
-- @module TextureCoordinate

---
-- Enumeration value COORD_U
--
-- @field [parent=#TextureCoordinate] #number COORD_U

---
-- Enumeration value COORD_V
--
-- @field [parent=#TextureCoordinate] #number COORD_V

---
-- Enumeration value COORD_W
--
-- @field [parent=#TextureCoordinate] #number COORD_W

---
-- Enumeration value MAX_COORDS
--
-- @field [parent=#TextureCoordinate] #number MAX_COORDS


return nil
