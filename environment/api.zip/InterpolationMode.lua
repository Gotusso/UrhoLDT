---
-- Enumeration InterpolationMode
--
-- @module InterpolationMode

---
-- Enumeration value BEZIER_CURVE
--
-- @field [parent=#InterpolationMode] #number BEZIER_CURVE


return nil
