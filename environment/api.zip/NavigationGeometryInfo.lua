---
-- Module NavigationGeometryInfo
--
-- @module NavigationGeometryInfo

---
-- Field component
--
-- @field [parent=#NavigationGeometryInfo] Component#Component component

---
-- Field lodLevel
--
-- @field [parent=#NavigationGeometryInfo] #number lodLevel

---
-- Field transform
--
-- @field [parent=#NavigationGeometryInfo] Matrix3x4#Matrix3x4 transform

---
-- Field boundingBox
--
-- @field [parent=#NavigationGeometryInfo] BoundingBox#BoundingBox boundingBox


return nil
