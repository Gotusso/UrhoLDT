---
-- Module Texture2D
-- Module Texture2D extends Texture
-- Generated on 2014-03-13
--
-- @module Texture2D

---
-- Function Texture2D
--
-- @function [parent=#Texture2D] Texture2D
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#Texture2D] new
-- @param self Self reference
-- @return Texture2D#Texture2D

---
-- Function delete
--
-- @function [parent=#Texture2D] delete
-- @param self Self reference

---
-- Function SetSize
--
-- @function [parent=#Texture2D] SetSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height
-- @param #number format format
-- @param TextureUsage#TextureUsage usage usage
-- @return #boolean

---
-- Function Load
--
-- @function [parent=#Texture2D] Load
-- @param self Self reference
-- @param Image#Image image image
-- @param #boolean useAlpha useAlpha
-- @return #boolean

---
-- Function GetRenderSurface
--
-- @function [parent=#Texture2D] GetRenderSurface
-- @param self Self reference
-- @return RenderSurface#RenderSurface

---
-- Field renderSurface (Read only)
--
-- @field [parent=#Texture2D] RenderSurface#RenderSurface renderSurface

---
-- Function SetNumLevels
--
-- @function [parent=#Texture2D] SetNumLevels
-- @param self Self reference
-- @param #number levels levels

---
-- Function SetFilterMode
--
-- @function [parent=#Texture2D] SetFilterMode
-- @param self Self reference
-- @param TextureFilterMode#TextureFilterMode filter filter

---
-- Function SetAddressMode
--
-- @function [parent=#Texture2D] SetAddressMode
-- @param self Self reference
-- @param TextureCoordinate#TextureCoordinate coord coord
-- @param TextureAddressMode#TextureAddressMode address address

---
-- Function SetBorderColor
--
-- @function [parent=#Texture2D] SetBorderColor
-- @param self Self reference
-- @param Color#Color color color

---
-- Function SetSRGB
--
-- @function [parent=#Texture2D] SetSRGB
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetBackupTexture
--
-- @function [parent=#Texture2D] SetBackupTexture
-- @param self Self reference
-- @param Texture#Texture texture texture

---
-- Function SetMipsToSkip
--
-- @function [parent=#Texture2D] SetMipsToSkip
-- @param self Self reference
-- @param #number quality quality
-- @param #number mips mips

---
-- Function GetFormat
--
-- @function [parent=#Texture2D] GetFormat
-- @param self Self reference
-- @return #number

---
-- Function IsCompressed
--
-- @function [parent=#Texture2D] IsCompressed
-- @param self Self reference
-- @return #boolean

---
-- Function GetLevels
--
-- @function [parent=#Texture2D] GetLevels
-- @param self Self reference
-- @return #number

---
-- Function GetWidth
--
-- @function [parent=#Texture2D] GetWidth
-- @param self Self reference
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#Texture2D] GetHeight
-- @param self Self reference
-- @return #number

---
-- Function GetFilterMode
--
-- @function [parent=#Texture2D] GetFilterMode
-- @param self Self reference
-- @return TextureFilterMode#TextureFilterMode

---
-- Function GetAddressMode
--
-- @function [parent=#Texture2D] GetAddressMode
-- @param self Self reference
-- @param TextureCoordinate#TextureCoordinate coord coord
-- @return TextureAddressMode#TextureAddressMode

---
-- Function GetBorderColor
--
-- @function [parent=#Texture2D] GetBorderColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetSRGB
--
-- @function [parent=#Texture2D] GetSRGB
-- @param self Self reference
-- @return #boolean

---
-- Function GetBackupTexture
--
-- @function [parent=#Texture2D] GetBackupTexture
-- @param self Self reference
-- @return Texture#Texture

---
-- Function GetMipsToSkip
--
-- @function [parent=#Texture2D] GetMipsToSkip
-- @param self Self reference
-- @param #number quality quality
-- @return #number

---
-- Function GetLevelWidth
--
-- @function [parent=#Texture2D] GetLevelWidth
-- @param self Self reference
-- @param #number level level
-- @return #number

---
-- Function GetLevelHeight
--
-- @function [parent=#Texture2D] GetLevelHeight
-- @param self Self reference
-- @param #number level level
-- @return #number

---
-- Function GetUsage
--
-- @function [parent=#Texture2D] GetUsage
-- @param self Self reference
-- @return TextureUsage#TextureUsage

---
-- Function GetDataSize
--
-- @function [parent=#Texture2D] GetDataSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height
-- @return #number

---
-- Function GetRowDataSize
--
-- @function [parent=#Texture2D] GetRowDataSize
-- @param self Self reference
-- @param #number width width
-- @return #number

---
-- Field format (Read only)
--
-- @field [parent=#Texture2D] #number format

---
-- Field compressed (Read only)
--
-- @field [parent=#Texture2D] #boolean compressed

---
-- Field levels (Read only)
--
-- @field [parent=#Texture2D] #number levels

---
-- Field width (Read only)
--
-- @field [parent=#Texture2D] #number width

---
-- Field height (Read only)
--
-- @field [parent=#Texture2D] #number height

---
-- Field filterMode
--
-- @field [parent=#Texture2D] TextureFilterMode#TextureFilterMode filterMode

---
-- Field borderColor
--
-- @field [parent=#Texture2D] Color#Color borderColor

---
-- Field sRGB
--
-- @field [parent=#Texture2D] #boolean sRGB

---
-- Field backupTexture
--
-- @field [parent=#Texture2D] Texture#Texture backupTexture

---
-- Field usage (Read only)
--
-- @field [parent=#Texture2D] TextureUsage#TextureUsage usage

---
-- Function Load
--
-- @function [parent=#Texture2D] Load
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#Texture2D] Save
-- @param self Self reference
-- @param Serializer#Serializer dest dest
-- @return #boolean

---
-- Function Load
--
-- @function [parent=#Texture2D] Load
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#Texture2D] Save
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function GetName
--
-- @function [parent=#Texture2D] GetName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetNameHash
--
-- @function [parent=#Texture2D] GetNameHash
-- @param self Self reference
-- @return StringHash#StringHash

---
-- Function GetMemoryUse
--
-- @function [parent=#Texture2D] GetMemoryUse
-- @param self Self reference
-- @return #number

---
-- Field name (Read only)
--
-- @field [parent=#Texture2D] #string name

---
-- Field nameHash (Read only)
--
-- @field [parent=#Texture2D] StringHash#StringHash nameHash

---
-- Field memoryUse (Read only)
--
-- @field [parent=#Texture2D] #number memoryUse


return nil
