---
-- Module Texture2D
-- Extends Texture
--
-- @module Texture2D

---
-- Function Texture2D
--
-- @function [parent=#Texture2D] Texture2D

---
-- Function new
--
-- @function [parent=#Texture2D] new
-- @return Texture2D#Texture2D

---
-- Function delete
--
-- @function [parent=#Texture2D] delete

---
-- Function SetSize
--
-- @function [parent=#Texture2D] SetSize
-- @param #number widthwidth
-- @param #number heightheight
-- @param #number formatformat
-- @param TextureUsage#TextureUsage usageusage
-- @return #boolean

---
-- Function Load
--
-- @function [parent=#Texture2D] Load
-- @param Image#Image imageimage
-- @param #boolean useAlphauseAlpha
-- @return #boolean

---
-- Function GetRenderSurface
--
-- @function [parent=#Texture2D] GetRenderSurface
-- @return RenderSurface#RenderSurface

---
-- Field renderSurface (Read only)
--
-- @field [parent=#Texture2D] RenderSurface#RenderSurface renderSurface


return nil
