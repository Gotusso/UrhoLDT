---
-- Module Texture2D
-- Module Texture2D extends Texture
-- Generated on 2014-05-31
--
-- @module Texture2D

---
-- Function Texture2D()
--
-- @function [parent=#Texture2D] Texture2D
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#Texture2D] new
-- @param self Self reference
-- @return Texture2D#Texture2D

---
-- Function delete()
--
-- @function [parent=#Texture2D] delete
-- @param self Self reference

---
-- Function SetSize()
--
-- @function [parent=#Texture2D] SetSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height
-- @param #number format format
-- @param TextureUsage#TextureUsage usage usage
-- @return #boolean

---
-- Function Load()
--
-- @function [parent=#Texture2D] Load
-- @param self Self reference
-- @param Image#Image image image
-- @param #boolean useAlpha useAlpha
-- @return #boolean

---
-- Function GetRenderSurface()
--
-- @function [parent=#Texture2D] GetRenderSurface
-- @param self Self reference
-- @return RenderSurface#RenderSurface

---
-- Field renderSurface (Read only)
--
-- @field [parent=#Texture2D] RenderSurface#RenderSurface renderSurface


return nil
