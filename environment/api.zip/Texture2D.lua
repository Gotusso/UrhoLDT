---
-- Module Texture2D
-- extends Texture
--
-- @module Texture2D

---
-- Function Texture2D
--
-- @function [parent=#Texture2D] Texture2D

---
-- Function new
--
-- @function [parent=#Texture2D] new
-- @return Texture2D#Texture2D

---
-- Function delete
--
-- @function [parent=#Texture2D] delete

---
-- Function SetSize
--
-- @function [parent=#Texture2D] SetSize
-- @param #number widthwidth
-- @param #number heightheight
-- @param #number formatformat
-- @param TextureUsage#TextureUsage usageusage
-- @return #boolean

---
-- Function Load
--
-- @function [parent=#Texture2D] Load
-- @param Image#Image imageimage
-- @param #boolean useAlphauseAlpha
-- @return #boolean

---
-- Function GetRenderSurface
--
-- @function [parent=#Texture2D] GetRenderSurface
-- @return RenderSurface#RenderSurface

---
-- Field renderSurface (Read only)
--
-- @field [parent=#Texture2D] RenderSurface#RenderSurface renderSurface

---
-- Function SetNumLevels
--
-- @function [parent=#Texture2D] SetNumLevels
-- @param #number levelslevels

---
-- Function SetFilterMode
--
-- @function [parent=#Texture2D] SetFilterMode
-- @param TextureFilterMode#TextureFilterMode filterfilter

---
-- Function SetAddressMode
--
-- @function [parent=#Texture2D] SetAddressMode
-- @param TextureCoordinate#TextureCoordinate coordcoord
-- @param TextureAddressMode#TextureAddressMode addressaddress

---
-- Function SetBorderColor
--
-- @function [parent=#Texture2D] SetBorderColor
-- @param Color#Color colorcolor

---
-- Function SetSRGB
--
-- @function [parent=#Texture2D] SetSRGB
-- @param #boolean enableenable

---
-- Function SetBackupTexture
--
-- @function [parent=#Texture2D] SetBackupTexture
-- @param Texture#Texture texturetexture

---
-- Function SetMipsToSkip
--
-- @function [parent=#Texture2D] SetMipsToSkip
-- @param #number qualityquality
-- @param #number mipsmips

---
-- Function GetFormat
--
-- @function [parent=#Texture2D] GetFormat
-- @return #number

---
-- Function IsCompressed
--
-- @function [parent=#Texture2D] IsCompressed
-- @return #boolean

---
-- Function GetLevels
--
-- @function [parent=#Texture2D] GetLevels
-- @return #number

---
-- Function GetWidth
--
-- @function [parent=#Texture2D] GetWidth
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#Texture2D] GetHeight
-- @return #number

---
-- Function GetFilterMode
--
-- @function [parent=#Texture2D] GetFilterMode
-- @return TextureFilterMode#TextureFilterMode

---
-- Function GetAddressMode
--
-- @function [parent=#Texture2D] GetAddressMode
-- @param TextureCoordinate#TextureCoordinate coordcoord
-- @return TextureAddressMode#TextureAddressMode

---
-- Function GetBorderColor
--
-- @function [parent=#Texture2D] GetBorderColor
-- @return const Color#const Color

---
-- Function GetSRGB
--
-- @function [parent=#Texture2D] GetSRGB
-- @return #boolean

---
-- Function GetBackupTexture
--
-- @function [parent=#Texture2D] GetBackupTexture
-- @return Texture#Texture

---
-- Function GetMipsToSkip
--
-- @function [parent=#Texture2D] GetMipsToSkip
-- @param #number qualityquality
-- @return #number

---
-- Function GetLevelWidth
--
-- @function [parent=#Texture2D] GetLevelWidth
-- @param #number levellevel
-- @return #number

---
-- Function GetLevelHeight
--
-- @function [parent=#Texture2D] GetLevelHeight
-- @param #number levellevel
-- @return #number

---
-- Function GetUsage
--
-- @function [parent=#Texture2D] GetUsage
-- @return TextureUsage#TextureUsage

---
-- Function GetDataSize
--
-- @function [parent=#Texture2D] GetDataSize
-- @param #number widthwidth
-- @param #number heightheight
-- @return #number

---
-- Function GetRowDataSize
--
-- @function [parent=#Texture2D] GetRowDataSize
-- @param #number widthwidth
-- @return #number

---
-- Field format (Read only)
--
-- @field [parent=#Texture2D] #number format

---
-- Field compressed (Read only)
--
-- @field [parent=#Texture2D] #boolean compressed

---
-- Field levels (Read only)
--
-- @field [parent=#Texture2D] #number levels

---
-- Field width (Read only)
--
-- @field [parent=#Texture2D] #number width

---
-- Field height (Read only)
--
-- @field [parent=#Texture2D] #number height

---
-- Field filterMode
--
-- @field [parent=#Texture2D] TextureFilterMode#TextureFilterMode filterMode

---
-- Field borderColor
--
-- @field [parent=#Texture2D] Color#Color borderColor

---
-- Field sRGB
--
-- @field [parent=#Texture2D] #boolean sRGB

---
-- Field backupTexture
--
-- @field [parent=#Texture2D] Texture#Texture backupTexture

---
-- Field usage (Read only)
--
-- @field [parent=#Texture2D] TextureUsage#TextureUsage usage

---
-- Function Load
--
-- @function [parent=#Texture2D] Load
-- @param Deserializer#Deserializer sourcesource
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#Texture2D] Save
-- @param Serializer#Serializer destdest
-- @return #boolean

---
-- Function Load
--
-- @function [parent=#Texture2D] Load
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#Texture2D] Save
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function GetName
--
-- @function [parent=#Texture2D] GetName
-- @return const String#const String

---
-- Function GetNameHash
--
-- @function [parent=#Texture2D] GetNameHash
-- @return StringHash#StringHash

---
-- Function GetMemoryUse
--
-- @function [parent=#Texture2D] GetMemoryUse
-- @return #number

---
-- Field name (Read only)
--
-- @field [parent=#Texture2D] #string name

---
-- Field nameHash (Read only)
--
-- @field [parent=#Texture2D] StringHash#StringHash nameHash

---
-- Field memoryUse (Read only)
--
-- @field [parent=#Texture2D] #number memoryUse


return nil
