---
-- Enumeration UpdateGeometryType
--
-- @module UpdateGeometryType

---
-- Enumeration value UPDATE_NONE
--
-- @field [parent=#UpdateGeometryType] #number UPDATE_NONE

---
-- Enumeration value UPDATE_MAIN_THREAD
--
-- @field [parent=#UpdateGeometryType] #number UPDATE_MAIN_THREAD

---
-- Enumeration value UPDATE_WORKER_THREAD
--
-- @field [parent=#UpdateGeometryType] #number UPDATE_WORKER_THREAD


return nil
