---
-- Module LuaScriptInstance
-- Extends Component
--
-- @module LuaScriptInstance

---
-- Function CreateObject
--
-- @function [parent=#LuaScriptInstance] CreateObject
-- @param #string scriptObjectTypescriptObjectType
-- @return #boolean

---
-- Function CreateObject
--
-- @function [parent=#LuaScriptInstance] CreateObject
-- @param #string scriptFileNamescriptFileName
-- @param #string scriptObjectTypescriptObjectType
-- @return #boolean

---
-- Function SetScriptFileName
--
-- @function [parent=#LuaScriptInstance] SetScriptFileName
-- @param #string scriptFileNamescriptFileName

---
-- Function SetScriptObjectType
--
-- @function [parent=#LuaScriptInstance] SetScriptObjectType
-- @param #string scriptObjectTypescriptObjectType

---
-- Function SubscribeToEvent
--
-- @function [parent=#LuaScriptInstance] SubscribeToEvent
-- @param #string eventNameeventName
-- @param #string functionNamefunctionName

---
-- Function UnsubscribeFromEvent
--
-- @function [parent=#LuaScriptInstance] UnsubscribeFromEvent
-- @param #string eventNameeventName

---
-- Function UnsubscribeFromAllEvents
--
-- @function [parent=#LuaScriptInstance] UnsubscribeFromAllEvents

---
-- Function SubscribeToEvent
--
-- @function [parent=#LuaScriptInstance] SubscribeToEvent
-- @param void*#void* sendersender
-- @param #string eventNameeventName
-- @param #string functionNamefunctionName

---
-- Function UnsubscribeFromEvent
--
-- @function [parent=#LuaScriptInstance] UnsubscribeFromEvent
-- @param void*#void* sendersender
-- @param #string eventNameeventName

---
-- Function UnsubscribeFromEvents
--
-- @function [parent=#LuaScriptInstance] UnsubscribeFromEvents
-- @param void*#void* sendersender

---
-- Function GetScriptFileName
--
-- @function [parent=#LuaScriptInstance] GetScriptFileName
-- @return const String#const String

---
-- Function GetScriptObjectType
--
-- @function [parent=#LuaScriptInstance] GetScriptObjectType
-- @return const String#const String

---
-- Field scriptFileName
--
-- @field [parent=#LuaScriptInstance] #string scriptFileName

---
-- Field scriptObjectType
--
-- @field [parent=#LuaScriptInstance] #string scriptObjectType


return nil
