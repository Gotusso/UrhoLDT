---
-- Module LuaScriptInstance
-- Module LuaScriptInstance extends Component
-- Generated on 2014-03-13
--
-- @module LuaScriptInstance

---
-- Function CreateObject
--
-- @function [parent=#LuaScriptInstance] CreateObject
-- @param self Self reference
-- @param #string scriptObjectType scriptObjectType
-- @return #boolean

---
-- Function CreateObject
--
-- @function [parent=#LuaScriptInstance] CreateObject
-- @param self Self reference
-- @param #string scriptFileName scriptFileName
-- @param #string scriptObjectType scriptObjectType
-- @return #boolean

---
-- Function SetScriptFileName
--
-- @function [parent=#LuaScriptInstance] SetScriptFileName
-- @param self Self reference
-- @param #string scriptFileName scriptFileName

---
-- Function SetScriptObjectType
--
-- @function [parent=#LuaScriptInstance] SetScriptObjectType
-- @param self Self reference
-- @param #string scriptObjectType scriptObjectType

---
-- Function SubscribeToEvent
--
-- @function [parent=#LuaScriptInstance] SubscribeToEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param #string functionName functionName

---
-- Function UnsubscribeFromEvent
--
-- @function [parent=#LuaScriptInstance] UnsubscribeFromEvent
-- @param self Self reference
-- @param #string eventName eventName

---
-- Function UnsubscribeFromAllEvents
--
-- @function [parent=#LuaScriptInstance] UnsubscribeFromAllEvents
-- @param self Self reference

---
-- Function SubscribeToEvent
--
-- @function [parent=#LuaScriptInstance] SubscribeToEvent
-- @param self Self reference
-- @param void*#void* sender sender
-- @param #string eventName eventName
-- @param #string functionName functionName

---
-- Function UnsubscribeFromEvent
--
-- @function [parent=#LuaScriptInstance] UnsubscribeFromEvent
-- @param self Self reference
-- @param void*#void* sender sender
-- @param #string eventName eventName

---
-- Function UnsubscribeFromEvents
--
-- @function [parent=#LuaScriptInstance] UnsubscribeFromEvents
-- @param self Self reference
-- @param void*#void* sender sender

---
-- Function GetScriptFileName
--
-- @function [parent=#LuaScriptInstance] GetScriptFileName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetScriptObjectType
--
-- @function [parent=#LuaScriptInstance] GetScriptObjectType
-- @param self Self reference
-- @return const String#const String

---
-- Field scriptFileName
--
-- @field [parent=#LuaScriptInstance] #string scriptFileName

---
-- Field scriptObjectType
--
-- @field [parent=#LuaScriptInstance] #string scriptObjectType

---
-- Function SetEnabled
--
-- @function [parent=#LuaScriptInstance] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Remove
--
-- @function [parent=#LuaScriptInstance] Remove
-- @param self Self reference

---
-- Function GetID
--
-- @function [parent=#LuaScriptInstance] GetID
-- @param self Self reference
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#LuaScriptInstance] GetNode
-- @param self Self reference
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#LuaScriptInstance] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#LuaScriptInstance] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#LuaScriptInstance] IsEnabledEffective
-- @param self Self reference
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#LuaScriptInstance] GetComponent
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#LuaScriptInstance] GetComponent
-- @param self Self reference
-- @param #string type type
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#LuaScriptInstance] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#LuaScriptInstance] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#LuaScriptInstance] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#LuaScriptInstance] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#LuaScriptInstance] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#LuaScriptInstance] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#LuaScriptInstance] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#LuaScriptInstance] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#LuaScriptInstance] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#LuaScriptInstance] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#LuaScriptInstance] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#LuaScriptInstance] #string category


return nil
