---
-- Module LuaScriptInstance
-- extends Component
--
-- @module LuaScriptInstance

---
-- Function CreateObject
--
-- @function [parent=#LuaScriptInstance] CreateObject
-- @param #string scriptObjectTypescriptObjectType
-- @return #boolean

---
-- Function CreateObject
--
-- @function [parent=#LuaScriptInstance] CreateObject
-- @param #string scriptFileNamescriptFileName
-- @param #string scriptObjectTypescriptObjectType
-- @return #boolean

---
-- Function SetScriptFileName
--
-- @function [parent=#LuaScriptInstance] SetScriptFileName
-- @param #string scriptFileNamescriptFileName

---
-- Function SetScriptObjectType
--
-- @function [parent=#LuaScriptInstance] SetScriptObjectType
-- @param #string scriptObjectTypescriptObjectType

---
-- Function SubscribeToEvent
--
-- @function [parent=#LuaScriptInstance] SubscribeToEvent
-- @param #string eventNameeventName
-- @param #string functionNamefunctionName

---
-- Function UnsubscribeFromEvent
--
-- @function [parent=#LuaScriptInstance] UnsubscribeFromEvent
-- @param #string eventNameeventName

---
-- Function UnsubscribeFromAllEvents
--
-- @function [parent=#LuaScriptInstance] UnsubscribeFromAllEvents

---
-- Function SubscribeToEvent
--
-- @function [parent=#LuaScriptInstance] SubscribeToEvent
-- @param void*#void* sendersender
-- @param #string eventNameeventName
-- @param #string functionNamefunctionName

---
-- Function UnsubscribeFromEvent
--
-- @function [parent=#LuaScriptInstance] UnsubscribeFromEvent
-- @param void*#void* sendersender
-- @param #string eventNameeventName

---
-- Function UnsubscribeFromEvents
--
-- @function [parent=#LuaScriptInstance] UnsubscribeFromEvents
-- @param void*#void* sendersender

---
-- Function GetScriptFileName
--
-- @function [parent=#LuaScriptInstance] GetScriptFileName
-- @return const String#const String

---
-- Function GetScriptObjectType
--
-- @function [parent=#LuaScriptInstance] GetScriptObjectType
-- @return const String#const String

---
-- Field scriptFileName
--
-- @field [parent=#LuaScriptInstance] #string scriptFileName

---
-- Field scriptObjectType
--
-- @field [parent=#LuaScriptInstance] #string scriptObjectType

---
-- Function SetEnabled
--
-- @function [parent=#LuaScriptInstance] SetEnabled
-- @param #boolean enableenable

---
-- Function Remove
--
-- @function [parent=#LuaScriptInstance] Remove

---
-- Function GetID
--
-- @function [parent=#LuaScriptInstance] GetID
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#LuaScriptInstance] GetNode
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#LuaScriptInstance] GetScene
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#LuaScriptInstance] IsEnabled
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#LuaScriptInstance] IsEnabledEffective
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#LuaScriptInstance] GetComponent
-- @param ShortStringHash#ShortStringHash typetype
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#LuaScriptInstance] GetComponent
-- @param #string typetype
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#LuaScriptInstance] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#LuaScriptInstance] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#LuaScriptInstance] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#LuaScriptInstance] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#LuaScriptInstance] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#LuaScriptInstance] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#LuaScriptInstance] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#LuaScriptInstance] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#LuaScriptInstance] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#LuaScriptInstance] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#LuaScriptInstance] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#LuaScriptInstance] #string category


return nil
