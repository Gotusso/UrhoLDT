---
-- Module LuaScriptInstance
-- Module LuaScriptInstance extends Component
-- Generated on 2014-05-31
--
-- @module LuaScriptInstance

---
-- Function CreateObject()
-- Create script object. Return true if successful.
--
-- @function [parent=#LuaScriptInstance] CreateObject
-- @param self Self reference
-- @param #string scriptObjectType scriptObjectType
-- @return #boolean

---
-- Function CreateObject()
-- Create script object. Return true if successful.
--
-- @function [parent=#LuaScriptInstance] CreateObject
-- @param self Self reference
-- @param LuaFile#LuaFile scriptFile scriptFile
-- @param #string scriptObjectType scriptObjectType
-- @return #boolean

---
-- Function SetScriptFile()
-- Set script file.
--
-- @function [parent=#LuaScriptInstance] SetScriptFile
-- @param self Self reference
-- @param LuaFile#LuaFile scriptFile scriptFile

---
-- Function SetScriptObjectType()
-- Set script object type.
--
-- @function [parent=#LuaScriptInstance] SetScriptObjectType
-- @param self Self reference
-- @param #string scriptObjectType scriptObjectType

---
-- Function SubscribeToEvent()
--
-- @function [parent=#LuaScriptInstance] SubscribeToEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param #string functionName functionName

---
-- Function UnsubscribeFromEvent()
--
-- @function [parent=#LuaScriptInstance] UnsubscribeFromEvent
-- @param self Self reference
-- @param #string eventName eventName

---
-- Function UnsubscribeFromAllEvents()
--
-- @function [parent=#LuaScriptInstance] UnsubscribeFromAllEvents
-- @param self Self reference

---
-- Function SubscribeToEvent()
--
-- @function [parent=#LuaScriptInstance] SubscribeToEvent
-- @param self Self reference
-- @param void*#void* sender sender
-- @param #string eventName eventName
-- @param #string functionName functionName

---
-- Function UnsubscribeFromEvent()
--
-- @function [parent=#LuaScriptInstance] UnsubscribeFromEvent
-- @param self Self reference
-- @param void*#void* sender sender
-- @param #string eventName eventName

---
-- Function UnsubscribeFromEvents()
--
-- @function [parent=#LuaScriptInstance] UnsubscribeFromEvents
-- @param self Self reference
-- @param void*#void* sender sender

---
-- Function GetScriptFile()
-- Return script file.
--
-- @function [parent=#LuaScriptInstance] GetScriptFile
-- @param self Self reference
-- @return LuaFile#LuaFile

---
-- Function GetScriptObjectType()
-- Return script object type.
--
-- @function [parent=#LuaScriptInstance] GetScriptObjectType
-- @param self Self reference
-- @return const String#const String

---
-- Field scriptFile
--
-- @field [parent=#LuaScriptInstance] LuaFile#LuaFile scriptFile

---
-- Field scriptObjectType
--
-- @field [parent=#LuaScriptInstance] #string scriptObjectType


return nil
