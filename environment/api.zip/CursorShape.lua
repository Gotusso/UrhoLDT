---
-- Enumeration CursorShape
--
-- @module CursorShape

---
-- Enumeration value CS_NORMAL
--
-- @field [parent=#CursorShape] #number CS_NORMAL

---
-- Enumeration value CS_RESIZEVERTICAL
--
-- @field [parent=#CursorShape] #number CS_RESIZEVERTICAL

---
-- Enumeration value CS_RESIZEDIAGONAL_TOPRIGHT
--
-- @field [parent=#CursorShape] #number CS_RESIZEDIAGONAL_TOPRIGHT

---
-- Enumeration value CS_RESIZEHORIZONTAL
--
-- @field [parent=#CursorShape] #number CS_RESIZEHORIZONTAL

---
-- Enumeration value CS_RESIZEDIAGONAL_TOPLEFT
--
-- @field [parent=#CursorShape] #number CS_RESIZEDIAGONAL_TOPLEFT

---
-- Enumeration value CS_ACCEPTDROP
--
-- @field [parent=#CursorShape] #number CS_ACCEPTDROP

---
-- Enumeration value CS_REJECTDROP
--
-- @field [parent=#CursorShape] #number CS_REJECTDROP

---
-- Enumeration value CS_BUSY
--
-- @field [parent=#CursorShape] #number CS_BUSY

---
-- Enumeration value CS_MAX_SHAPES
--
-- @field [parent=#CursorShape] #number CS_MAX_SHAPES


return nil
