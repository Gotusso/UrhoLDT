---
-- Module ConstraintMotor2D
-- Module ConstraintMotor2D extends Constraint2D
-- Generated on 2014-05-31
--
-- @module ConstraintMotor2D

---
-- Function SetLinearOffset()
-- Set linear offset.
--
-- @function [parent=#ConstraintMotor2D] SetLinearOffset
-- @param self Self reference
-- @param Vector2#Vector2 linearOffset linearOffset

---
-- Function SetAngularOffset()
-- Set angular offset.
--
-- @function [parent=#ConstraintMotor2D] SetAngularOffset
-- @param self Self reference
-- @param #number angularOffset angularOffset

---
-- Function SetMaxForce()
-- Set max force.
--
-- @function [parent=#ConstraintMotor2D] SetMaxForce
-- @param self Self reference
-- @param #number maxForce maxForce

---
-- Function SetMaxTorque()
-- Set max torque.
--
-- @function [parent=#ConstraintMotor2D] SetMaxTorque
-- @param self Self reference
-- @param #number maxTorque maxTorque

---
-- Function SetCorrectionFactor()
-- Set correction factor.
--
-- @function [parent=#ConstraintMotor2D] SetCorrectionFactor
-- @param self Self reference
-- @param #number correctionFactor correctionFactor

---
-- Function GetLinearOffset()
-- Return linear offset.
--
-- @function [parent=#ConstraintMotor2D] GetLinearOffset
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Function GetAngularOffset()
-- Return angular offset.
--
-- @function [parent=#ConstraintMotor2D] GetAngularOffset
-- @param self Self reference
-- @return #number

---
-- Function GetMaxForce()
-- Return max force.
--
-- @function [parent=#ConstraintMotor2D] GetMaxForce
-- @param self Self reference
-- @return #number

---
-- Function GetMaxTorque()
-- Return max torque.
--
-- @function [parent=#ConstraintMotor2D] GetMaxTorque
-- @param self Self reference
-- @return #number

---
-- Function GetCorrectionFactor()
-- Return correction factor.
--
-- @function [parent=#ConstraintMotor2D] GetCorrectionFactor
-- @param self Self reference
-- @return #number

---
-- Field linearOffset
--
-- @field [parent=#ConstraintMotor2D] Vector2#Vector2 linearOffset

---
-- Field angularOffset
--
-- @field [parent=#ConstraintMotor2D] #number angularOffset

---
-- Field maxForce
--
-- @field [parent=#ConstraintMotor2D] #number maxForce

---
-- Field maxTorque
--
-- @field [parent=#ConstraintMotor2D] #number maxTorque

---
-- Field correctionFactor
--
-- @field [parent=#ConstraintMotor2D] #number correctionFactor


return nil
