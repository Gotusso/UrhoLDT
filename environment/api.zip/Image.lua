---
-- Module Image
-- Extends Resource
--
-- @module Image

---
-- Function Image
--
-- @function [parent=#Image] Image

---
-- Function new
--
-- @function [parent=#Image] new
-- @return Image#Image

---
-- Function delete
--
-- @function [parent=#Image] delete

---
-- Function SetSize
--
-- @function [parent=#Image] SetSize
-- @param #number widthwidth
-- @param #number heightheight
-- @param #number componentscomponents
-- @return #boolean

---
-- Function SetSize
--
-- @function [parent=#Image] SetSize
-- @param #number widthwidth
-- @param #number heightheight
-- @param #number depthdepth
-- @param #number componentscomponents
-- @return #boolean

---
-- Function SetPixel
--
-- @function [parent=#Image] SetPixel
-- @param #number xx
-- @param #number yy
-- @param Color#Color colorcolor

---
-- Function SetPixel
--
-- @function [parent=#Image] SetPixel
-- @param #number xx
-- @param #number yy
-- @param #number zz
-- @param Color#Color colorcolor

---
-- Function LoadColorLUT
--
-- @function [parent=#Image] LoadColorLUT
-- @param Deserializer#Deserializer sourcesource
-- @return #boolean

---
-- Function LoadColorLUT
--
-- @function [parent=#Image] LoadColorLUT
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function FlipVertical
--
-- @function [parent=#Image] FlipVertical

---
-- Function Resize
--
-- @function [parent=#Image] Resize
-- @param #number widthwidth
-- @param #number heightheight
-- @return #boolean

---
-- Function Clear
--
-- @function [parent=#Image] Clear
-- @param Color#Color colorcolor

---
-- Function SaveBMP
--
-- @function [parent=#Image] SaveBMP
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function SavePNG
--
-- @function [parent=#Image] SavePNG
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function SaveTGA
--
-- @function [parent=#Image] SaveTGA
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function SaveJPG
--
-- @function [parent=#Image] SaveJPG
-- @param #string fileNamefileName
-- @param #number qualityquality
-- @return #boolean

---
-- Function GetPixel
--
-- @function [parent=#Image] GetPixel
-- @param #number xx
-- @param #number yy
-- @return Color#Color

---
-- Function GetPixel
--
-- @function [parent=#Image] GetPixel
-- @param #number xx
-- @param #number yy
-- @param #number zz
-- @return Color#Color

---
-- Function GetPixelBilinear
--
-- @function [parent=#Image] GetPixelBilinear
-- @param #number xx
-- @param #number yy
-- @return Color#Color

---
-- Function GetPixelTrilinear
--
-- @function [parent=#Image] GetPixelTrilinear
-- @param #number xx
-- @param #number yy
-- @param #number zz
-- @return Color#Color

---
-- Function GetWidth
--
-- @function [parent=#Image] GetWidth
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#Image] GetHeight
-- @return #number

---
-- Function GetDepth
--
-- @function [parent=#Image] GetDepth
-- @return #number

---
-- Function GetComponents
--
-- @function [parent=#Image] GetComponents
-- @return #number

---
-- Function IsCompressed
--
-- @function [parent=#Image] IsCompressed
-- @return #boolean

---
-- Function GetCompressedFormat
--
-- @function [parent=#Image] GetCompressedFormat
-- @return CompressedFormat#CompressedFormat

---
-- Function GetNumCompressedLevels
--
-- @function [parent=#Image] GetNumCompressedLevels
-- @return #number

---
-- Function GetCompressedLevel
--
-- @function [parent=#Image] GetCompressedLevel
-- @param #number indexindex
-- @return CompressedLevel#CompressedLevel

---
-- Field width (Read only)
--
-- @field [parent=#Image] #number width

---
-- Field height (Read only)
--
-- @field [parent=#Image] #number height

---
-- Field depth (Read only)
--
-- @field [parent=#Image] #number depth

---
-- Field components (Read only)
--
-- @field [parent=#Image] #number components

---
-- Field compressed (Read only)
--
-- @field [parent=#Image] #boolean compressed

---
-- Field compressedFormat (Read only)
--
-- @field [parent=#Image] CompressedFormat#CompressedFormat compressedFormat

---
-- Field numCompressedLevels (Read only)
--
-- @field [parent=#Image] #number numCompressedLevels


return nil
