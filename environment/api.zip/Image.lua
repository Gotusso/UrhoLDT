---
-- Module Image
-- Module Image extends Resource
-- Generated on 2014-05-31
--
-- @module Image

---
-- Function Image()
--
-- @function [parent=#Image] Image
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#Image] new
-- @param self Self reference
-- @return Image#Image

---
-- Function delete()
--
-- @function [parent=#Image] delete
-- @param self Self reference

---
-- Function SetSize()
-- Set 2D size and number of color components. Old image data will be destroyed and new data is undefined. Return true if successful.
--
-- @function [parent=#Image] SetSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height
-- @param #number components components
-- @return #boolean

---
-- Function SetSize()
-- Set 3D size and number of color components. Old image data will be destroyed and new data is undefined. Return true if successful.
--
-- @function [parent=#Image] SetSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height
-- @param #number depth depth
-- @param #number components components
-- @return #boolean

---
-- Function SetPixel()
-- Set a 2D pixel.
--
-- @function [parent=#Image] SetPixel
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param Color#Color color color

---
-- Function SetPixel()
-- Set a 3D pixel.
--
-- @function [parent=#Image] SetPixel
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z
-- @param Color#Color color color

---
-- Function LoadColorLUT()
-- Load as color LUT. Return true if successful.
--
-- @function [parent=#Image] LoadColorLUT
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @return #boolean

---
-- Function LoadColorLUT()
--
-- @function [parent=#Image] LoadColorLUT
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function FlipVertical()
-- Flip image vertically.
--
-- @function [parent=#Image] FlipVertical
-- @param self Self reference

---
-- Function Resize()
-- Resize image by bilinear resampling. Return true if successful.
--
-- @function [parent=#Image] Resize
-- @param self Self reference
-- @param #number width width
-- @param #number height height
-- @return #boolean

---
-- Function Clear()
-- Clear the image with a color.
--
-- @function [parent=#Image] Clear
-- @param self Self reference
-- @param Color#Color color color

---
-- Function SaveBMP()
-- Save in BMP format. Return true if successful.
--
-- @function [parent=#Image] SaveBMP
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function SavePNG()
-- Save in PNG format. Return true if successful.
--
-- @function [parent=#Image] SavePNG
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function SaveTGA()
-- Save in TGA format. Return true if successful.
--
-- @function [parent=#Image] SaveTGA
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function SaveJPG()
-- Save in JPG format with compression quality. Return true if successful.
--
-- @function [parent=#Image] SaveJPG
-- @param self Self reference
-- @param #string fileName fileName
-- @param #number quality quality
-- @return #boolean

---
-- Function GetPixel()
-- Return a 2D pixel color.
--
-- @function [parent=#Image] GetPixel
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @return Color#Color

---
-- Function GetPixel()
-- Return a 3D pixel color.
--
-- @function [parent=#Image] GetPixel
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z
-- @return Color#Color

---
-- Function GetPixelBilinear()
-- Return a bilinearly sampled 2D pixel color. X and Y have the range 0-1.
--
-- @function [parent=#Image] GetPixelBilinear
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @return Color#Color

---
-- Function GetPixelTrilinear()
-- Return a trilinearly sampled 3D pixel color. X, Y and Z have the range 0-1.
--
-- @function [parent=#Image] GetPixelTrilinear
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z
-- @return Color#Color

---
-- Function GetWidth()
-- Return width.
--
-- @function [parent=#Image] GetWidth
-- @param self Self reference
-- @return #number

---
-- Function GetHeight()
-- Return height.
--
-- @function [parent=#Image] GetHeight
-- @param self Self reference
-- @return #number

---
-- Function GetDepth()
-- Return depth.
--
-- @function [parent=#Image] GetDepth
-- @param self Self reference
-- @return #number

---
-- Function GetComponents()
-- Return number of color components.
--
-- @function [parent=#Image] GetComponents
-- @param self Self reference
-- @return #number

---
-- Function IsCompressed()
-- Return whether is compressed.
--
-- @function [parent=#Image] IsCompressed
-- @param self Self reference
-- @return #boolean

---
-- Function GetCompressedFormat()
-- Return compressed format.
--
-- @function [parent=#Image] GetCompressedFormat
-- @param self Self reference
-- @return CompressedFormat#CompressedFormat

---
-- Function GetNumCompressedLevels()
-- Return number of compressed mip levels.
--
-- @function [parent=#Image] GetNumCompressedLevels
-- @param self Self reference
-- @return #number

---
-- Function GetCompressedLevel()
-- Return a compressed mip level.
--
-- @function [parent=#Image] GetCompressedLevel
-- @param self Self reference
-- @param #number index index
-- @return CompressedLevel#CompressedLevel

---
-- Function GetSubimage()
-- Return subimage from the image or null if failed. Only RGB images are supported. Specify rect to only return partial image. You must free the subimage yourself.
--
-- @function [parent=#Image] GetSubimage
-- @param self Self reference
-- @param IntRect#IntRect rect rect
-- @return Image#Image

---
-- Field width (Read only)
--
-- @field [parent=#Image] #number width

---
-- Field height (Read only)
--
-- @field [parent=#Image] #number height

---
-- Field depth (Read only)
--
-- @field [parent=#Image] #number depth

---
-- Field components (Read only)
--
-- @field [parent=#Image] #number components

---
-- Field compressed (Read only)
--
-- @field [parent=#Image] #boolean compressed

---
-- Field compressedFormat (Read only)
--
-- @field [parent=#Image] CompressedFormat#CompressedFormat compressedFormat

---
-- Field numCompressedLevels (Read only)
--
-- @field [parent=#Image] #number numCompressedLevels


return nil
