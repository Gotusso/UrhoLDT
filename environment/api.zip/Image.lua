---
-- Module Image
-- Module Image extends Resource
-- Generated on 2014-03-13
--
-- @module Image

---
-- Function Image
--
-- @function [parent=#Image] Image
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#Image] new
-- @param self Self reference
-- @return Image#Image

---
-- Function delete
--
-- @function [parent=#Image] delete
-- @param self Self reference

---
-- Function SetSize
--
-- @function [parent=#Image] SetSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height
-- @param #number components components
-- @return #boolean

---
-- Function SetSize
--
-- @function [parent=#Image] SetSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height
-- @param #number depth depth
-- @param #number components components
-- @return #boolean

---
-- Function SetPixel
--
-- @function [parent=#Image] SetPixel
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param Color#Color color color

---
-- Function SetPixel
--
-- @function [parent=#Image] SetPixel
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z
-- @param Color#Color color color

---
-- Function LoadColorLUT
--
-- @function [parent=#Image] LoadColorLUT
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @return #boolean

---
-- Function LoadColorLUT
--
-- @function [parent=#Image] LoadColorLUT
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function FlipVertical
--
-- @function [parent=#Image] FlipVertical
-- @param self Self reference

---
-- Function Resize
--
-- @function [parent=#Image] Resize
-- @param self Self reference
-- @param #number width width
-- @param #number height height
-- @return #boolean

---
-- Function Clear
--
-- @function [parent=#Image] Clear
-- @param self Self reference
-- @param Color#Color color color

---
-- Function SaveBMP
--
-- @function [parent=#Image] SaveBMP
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function SavePNG
--
-- @function [parent=#Image] SavePNG
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function SaveTGA
--
-- @function [parent=#Image] SaveTGA
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function SaveJPG
--
-- @function [parent=#Image] SaveJPG
-- @param self Self reference
-- @param #string fileName fileName
-- @param #number quality quality
-- @return #boolean

---
-- Function GetPixel
--
-- @function [parent=#Image] GetPixel
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @return Color#Color

---
-- Function GetPixel
--
-- @function [parent=#Image] GetPixel
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z
-- @return Color#Color

---
-- Function GetPixelBilinear
--
-- @function [parent=#Image] GetPixelBilinear
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @return Color#Color

---
-- Function GetPixelTrilinear
--
-- @function [parent=#Image] GetPixelTrilinear
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z
-- @return Color#Color

---
-- Function GetWidth
--
-- @function [parent=#Image] GetWidth
-- @param self Self reference
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#Image] GetHeight
-- @param self Self reference
-- @return #number

---
-- Function GetDepth
--
-- @function [parent=#Image] GetDepth
-- @param self Self reference
-- @return #number

---
-- Function GetComponents
--
-- @function [parent=#Image] GetComponents
-- @param self Self reference
-- @return #number

---
-- Function IsCompressed
--
-- @function [parent=#Image] IsCompressed
-- @param self Self reference
-- @return #boolean

---
-- Function GetCompressedFormat
--
-- @function [parent=#Image] GetCompressedFormat
-- @param self Self reference
-- @return CompressedFormat#CompressedFormat

---
-- Function GetNumCompressedLevels
--
-- @function [parent=#Image] GetNumCompressedLevels
-- @param self Self reference
-- @return #number

---
-- Function GetCompressedLevel
--
-- @function [parent=#Image] GetCompressedLevel
-- @param self Self reference
-- @param #number index index
-- @return CompressedLevel#CompressedLevel

---
-- Field width (Read only)
--
-- @field [parent=#Image] #number width

---
-- Field height (Read only)
--
-- @field [parent=#Image] #number height

---
-- Field depth (Read only)
--
-- @field [parent=#Image] #number depth

---
-- Field components (Read only)
--
-- @field [parent=#Image] #number components

---
-- Field compressed (Read only)
--
-- @field [parent=#Image] #boolean compressed

---
-- Field compressedFormat (Read only)
--
-- @field [parent=#Image] CompressedFormat#CompressedFormat compressedFormat

---
-- Field numCompressedLevels (Read only)
--
-- @field [parent=#Image] #number numCompressedLevels

---
-- Function Load
--
-- @function [parent=#Image] Load
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#Image] Save
-- @param self Self reference
-- @param Serializer#Serializer dest dest
-- @return #boolean

---
-- Function Load
--
-- @function [parent=#Image] Load
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#Image] Save
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function GetName
--
-- @function [parent=#Image] GetName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetNameHash
--
-- @function [parent=#Image] GetNameHash
-- @param self Self reference
-- @return StringHash#StringHash

---
-- Function GetMemoryUse
--
-- @function [parent=#Image] GetMemoryUse
-- @param self Self reference
-- @return #number

---
-- Field name (Read only)
--
-- @field [parent=#Image] #string name

---
-- Field nameHash (Read only)
--
-- @field [parent=#Image] StringHash#StringHash nameHash

---
-- Field memoryUse (Read only)
--
-- @field [parent=#Image] #number memoryUse


return nil
