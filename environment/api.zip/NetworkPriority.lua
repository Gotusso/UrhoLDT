---
-- Module NetworkPriority
-- extends Component
--
-- @module NetworkPriority

---
-- Function SetBasePriority
--
-- @function [parent=#NetworkPriority] SetBasePriority
-- @param #number prioritypriority

---
-- Function SetDistanceFactor
--
-- @function [parent=#NetworkPriority] SetDistanceFactor
-- @param #number factorfactor

---
-- Function SetMinPriority
--
-- @function [parent=#NetworkPriority] SetMinPriority
-- @param #number prioritypriority

---
-- Function SetAlwaysUpdateOwner
--
-- @function [parent=#NetworkPriority] SetAlwaysUpdateOwner
-- @param #boolean enableenable

---
-- Function GetBasePriority
--
-- @function [parent=#NetworkPriority] GetBasePriority
-- @return #number

---
-- Function GetDistanceFactor
--
-- @function [parent=#NetworkPriority] GetDistanceFactor
-- @return #number

---
-- Function GetMinPriority
--
-- @function [parent=#NetworkPriority] GetMinPriority
-- @return #number

---
-- Function GetAlwaysUpdateOwner
--
-- @function [parent=#NetworkPriority] GetAlwaysUpdateOwner
-- @return #boolean

---
-- Function CheckUpdate
--
-- @function [parent=#NetworkPriority] CheckUpdate
-- @param #number distancedistance
-- @param #number accumulatoraccumulator
-- @return #boolean

---
-- Field basePriority
--
-- @field [parent=#NetworkPriority] #number basePriority

---
-- Field distanceFactor
--
-- @field [parent=#NetworkPriority] #number distanceFactor

---
-- Field minPriority
--
-- @field [parent=#NetworkPriority] #number minPriority

---
-- Field alwaysUpdateOwner
--
-- @field [parent=#NetworkPriority] #boolean alwaysUpdateOwner

---
-- Function SetEnabled
--
-- @function [parent=#NetworkPriority] SetEnabled
-- @param #boolean enableenable

---
-- Function Remove
--
-- @function [parent=#NetworkPriority] Remove

---
-- Function GetID
--
-- @function [parent=#NetworkPriority] GetID
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#NetworkPriority] GetNode
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#NetworkPriority] GetScene
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#NetworkPriority] IsEnabled
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#NetworkPriority] IsEnabledEffective
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#NetworkPriority] GetComponent
-- @param ShortStringHash#ShortStringHash typetype
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#NetworkPriority] GetComponent
-- @param #string typetype
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#NetworkPriority] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#NetworkPriority] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#NetworkPriority] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#NetworkPriority] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#NetworkPriority] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#NetworkPriority] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#NetworkPriority] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#NetworkPriority] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#NetworkPriority] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#NetworkPriority] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#NetworkPriority] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#NetworkPriority] #string category


return nil
