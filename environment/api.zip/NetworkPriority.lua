---
-- Module NetworkPriority
-- Module NetworkPriority extends Component
-- Generated on 2014-05-31
--
-- @module NetworkPriority

---
-- Function SetBasePriority()
-- Set base priority. Default 100 (send updates at full frequency.)
--
-- @function [parent=#NetworkPriority] SetBasePriority
-- @param self Self reference
-- @param #number priority priority

---
-- Function SetDistanceFactor()
-- Set priority reduction distance factor. Default 0 (no effect.)
--
-- @function [parent=#NetworkPriority] SetDistanceFactor
-- @param self Self reference
-- @param #number factor factor

---
-- Function SetMinPriority()
-- Set minimum priority. Default 0 (no updates when far away enough.)
--
-- @function [parent=#NetworkPriority] SetMinPriority
-- @param self Self reference
-- @param #number priority priority

---
-- Function SetAlwaysUpdateOwner()
-- Set whether updates to owner should be sent always at full rate. Default true.
--
-- @function [parent=#NetworkPriority] SetAlwaysUpdateOwner
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function GetBasePriority()
-- Return base priority.
--
-- @function [parent=#NetworkPriority] GetBasePriority
-- @param self Self reference
-- @return #number

---
-- Function GetDistanceFactor()
-- Return priority reduction distance factor.
--
-- @function [parent=#NetworkPriority] GetDistanceFactor
-- @param self Self reference
-- @return #number

---
-- Function GetMinPriority()
-- Return minimum priority.
--
-- @function [parent=#NetworkPriority] GetMinPriority
-- @param self Self reference
-- @return #number

---
-- Function GetAlwaysUpdateOwner()
-- Return whether updates to owner should be sent always at full rate.
--
-- @function [parent=#NetworkPriority] GetAlwaysUpdateOwner
-- @param self Self reference
-- @return #boolean

---
-- Function CheckUpdate()
-- Increment and check priority accumulator. Return true if should update. Called by Connection.
--
-- @function [parent=#NetworkPriority] CheckUpdate
-- @param self Self reference
-- @param #number distance distance
-- @param #number accumulator accumulator
-- @return #boolean

---
-- Field basePriority
--
-- @field [parent=#NetworkPriority] #number basePriority

---
-- Field distanceFactor
--
-- @field [parent=#NetworkPriority] #number distanceFactor

---
-- Field minPriority
--
-- @field [parent=#NetworkPriority] #number minPriority

---
-- Field alwaysUpdateOwner
--
-- @field [parent=#NetworkPriority] #boolean alwaysUpdateOwner


return nil
