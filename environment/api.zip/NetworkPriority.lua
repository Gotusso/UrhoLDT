---
-- Module NetworkPriority
-- Module NetworkPriority extends Component
-- Generated on 2014-03-13
--
-- @module NetworkPriority

---
-- Function SetBasePriority
--
-- @function [parent=#NetworkPriority] SetBasePriority
-- @param self Self reference
-- @param #number priority priority

---
-- Function SetDistanceFactor
--
-- @function [parent=#NetworkPriority] SetDistanceFactor
-- @param self Self reference
-- @param #number factor factor

---
-- Function SetMinPriority
--
-- @function [parent=#NetworkPriority] SetMinPriority
-- @param self Self reference
-- @param #number priority priority

---
-- Function SetAlwaysUpdateOwner
--
-- @function [parent=#NetworkPriority] SetAlwaysUpdateOwner
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function GetBasePriority
--
-- @function [parent=#NetworkPriority] GetBasePriority
-- @param self Self reference
-- @return #number

---
-- Function GetDistanceFactor
--
-- @function [parent=#NetworkPriority] GetDistanceFactor
-- @param self Self reference
-- @return #number

---
-- Function GetMinPriority
--
-- @function [parent=#NetworkPriority] GetMinPriority
-- @param self Self reference
-- @return #number

---
-- Function GetAlwaysUpdateOwner
--
-- @function [parent=#NetworkPriority] GetAlwaysUpdateOwner
-- @param self Self reference
-- @return #boolean

---
-- Function CheckUpdate
--
-- @function [parent=#NetworkPriority] CheckUpdate
-- @param self Self reference
-- @param #number distance distance
-- @param #number accumulator accumulator
-- @return #boolean

---
-- Field basePriority
--
-- @field [parent=#NetworkPriority] #number basePriority

---
-- Field distanceFactor
--
-- @field [parent=#NetworkPriority] #number distanceFactor

---
-- Field minPriority
--
-- @field [parent=#NetworkPriority] #number minPriority

---
-- Field alwaysUpdateOwner
--
-- @field [parent=#NetworkPriority] #boolean alwaysUpdateOwner

---
-- Function SetEnabled
--
-- @function [parent=#NetworkPriority] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Remove
--
-- @function [parent=#NetworkPriority] Remove
-- @param self Self reference

---
-- Function GetID
--
-- @function [parent=#NetworkPriority] GetID
-- @param self Self reference
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#NetworkPriority] GetNode
-- @param self Self reference
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#NetworkPriority] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#NetworkPriority] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#NetworkPriority] IsEnabledEffective
-- @param self Self reference
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#NetworkPriority] GetComponent
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#NetworkPriority] GetComponent
-- @param self Self reference
-- @param #string type type
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#NetworkPriority] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#NetworkPriority] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#NetworkPriority] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#NetworkPriority] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#NetworkPriority] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#NetworkPriority] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#NetworkPriority] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#NetworkPriority] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#NetworkPriority] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#NetworkPriority] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#NetworkPriority] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#NetworkPriority] #string category


return nil
