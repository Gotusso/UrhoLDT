---
-- Enumeration VerticalAlignment
--
-- @module VerticalAlignment

---
-- Enumeration value VA_TOP
--
-- @field [parent=#VerticalAlignment] #number VA_TOP

---
-- Enumeration value VA_CENTER
--
-- @field [parent=#VerticalAlignment] #number VA_CENTER

---
-- Enumeration value VA_BOTTOM
--
-- @field [parent=#VerticalAlignment] #number VA_BOTTOM


return nil
