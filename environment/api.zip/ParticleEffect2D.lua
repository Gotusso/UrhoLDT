---
-- Module ParticleEffect2D
-- Module ParticleEffect2D extends Resource
-- Generated on 2014-05-31
--
-- @module ParticleEffect2D


return nil
