---
-- Module NavigationMesh
-- extends Component
--
-- @module NavigationMesh

---
-- Function SetTileSize
--
-- @function [parent=#NavigationMesh] SetTileSize
-- @param #number sizesize

---
-- Function SetCellSize
--
-- @function [parent=#NavigationMesh] SetCellSize
-- @param #number sizesize

---
-- Function SetCellHeight
--
-- @function [parent=#NavigationMesh] SetCellHeight
-- @param #number heightheight

---
-- Function SetAgentHeight
--
-- @function [parent=#NavigationMesh] SetAgentHeight
-- @param #number heightheight

---
-- Function SetAgentRadius
--
-- @function [parent=#NavigationMesh] SetAgentRadius
-- @param #number radiusradius

---
-- Function SetAgentMaxClimb
--
-- @function [parent=#NavigationMesh] SetAgentMaxClimb
-- @param #number maxClimbmaxClimb

---
-- Function SetAgentMaxSlope
--
-- @function [parent=#NavigationMesh] SetAgentMaxSlope
-- @param #number maxSlopemaxSlope

---
-- Function SetRegionMinSize
--
-- @function [parent=#NavigationMesh] SetRegionMinSize
-- @param #number sizesize

---
-- Function SetRegionMergeSize
--
-- @function [parent=#NavigationMesh] SetRegionMergeSize
-- @param #number sizesize

---
-- Function SetEdgeMaxLength
--
-- @function [parent=#NavigationMesh] SetEdgeMaxLength
-- @param #number lengthlength

---
-- Function SetEdgeMaxError
--
-- @function [parent=#NavigationMesh] SetEdgeMaxError
-- @param #number errorerror

---
-- Function SetDetailSampleDistance
--
-- @function [parent=#NavigationMesh] SetDetailSampleDistance
-- @param #number distancedistance

---
-- Function SetDetailSampleMaxError
--
-- @function [parent=#NavigationMesh] SetDetailSampleMaxError
-- @param #number errorerror

---
-- Function SetPadding
--
-- @function [parent=#NavigationMesh] SetPadding
-- @param Vector3#Vector3 paddingpadding

---
-- Function Build
--
-- @function [parent=#NavigationMesh] Build
-- @return #boolean

---
-- Function Build
--
-- @function [parent=#NavigationMesh] Build
-- @param BoundingBox#BoundingBox boundingBoxboundingBox
-- @return #boolean

---
-- Function FindNearestPoint
--
-- @function [parent=#NavigationMesh] FindNearestPoint
-- @param Vector3#Vector3 pointpoint
-- @return Vector3#Vector3

---
-- Function FindNearestPoint
--
-- @function [parent=#NavigationMesh] FindNearestPoint
-- @param Vector3#Vector3 pointpoint
-- @param Vector3#Vector3 extentsextents
-- @return Vector3#Vector3

---
-- Function MoveAlongSurface
--
-- @function [parent=#NavigationMesh] MoveAlongSurface
-- @param Vector3#Vector3 startstart
-- @param Vector3#Vector3 endend
-- @return Vector3#Vector3

---
-- Function MoveAlongSurface
--
-- @function [parent=#NavigationMesh] MoveAlongSurface
-- @param Vector3#Vector3 startstart
-- @param Vector3#Vector3 endend
-- @param Vector3#Vector3 extentsextents
-- @param #number maxVisitedmaxVisited
-- @return Vector3#Vector3

---
-- Function FindPath
--
-- @function [parent=#NavigationMesh] FindPath
-- @param Vector3#Vector3 startstart
-- @param Vector3#Vector3 endend
-- @return const PODVector<Vector3>#const PODVector<Vector3>

---
-- Function FindPath
--
-- @function [parent=#NavigationMesh] FindPath
-- @param Vector3#Vector3 startstart
-- @param Vector3#Vector3 endend
-- @param Vector3#Vector3 extentsextents
-- @return const PODVector<Vector3>#const PODVector<Vector3>

---
-- Function GetRandomPoint
--
-- @function [parent=#NavigationMesh] GetRandomPoint
-- @return Vector3#Vector3

---
-- Function GetRandomPointInCircle
--
-- @function [parent=#NavigationMesh] GetRandomPointInCircle
-- @param Vector3#Vector3 centercenter
-- @param #number radiusradius
-- @return Vector3#Vector3

---
-- Function GetRandomPointInCircle
--
-- @function [parent=#NavigationMesh] GetRandomPointInCircle
-- @param Vector3#Vector3 centercenter
-- @param #number radiusradius
-- @param Vector3#Vector3 extentsextents
-- @return Vector3#Vector3

---
-- Function GetDistanceToWall
--
-- @function [parent=#NavigationMesh] GetDistanceToWall
-- @param Vector3#Vector3 pointpoint
-- @param #number radiusradius
-- @return #number

---
-- Function GetDistanceToWall
--
-- @function [parent=#NavigationMesh] GetDistanceToWall
-- @param Vector3#Vector3 pointpoint
-- @param #number radiusradius
-- @param Vector3#Vector3 extentsextents
-- @return #number

---
-- Function Raycast
--
-- @function [parent=#NavigationMesh] Raycast
-- @param Vector3#Vector3 startstart
-- @param Vector3#Vector3 endend
-- @return Vector3#Vector3

---
-- Function Raycast
--
-- @function [parent=#NavigationMesh] Raycast
-- @param Vector3#Vector3 startstart
-- @param Vector3#Vector3 endend
-- @param Vector3#Vector3 extentsextents
-- @return Vector3#Vector3

---
-- Function DrawDebugGeometry
--
-- @function [parent=#NavigationMesh] DrawDebugGeometry
-- @param #boolean depthTestdepthTest

---
-- Function GetTileSize
--
-- @function [parent=#NavigationMesh] GetTileSize
-- @return #number

---
-- Function GetCellSize
--
-- @function [parent=#NavigationMesh] GetCellSize
-- @return #number

---
-- Function GetCellHeight
--
-- @function [parent=#NavigationMesh] GetCellHeight
-- @return #number

---
-- Function GetAgentHeight
--
-- @function [parent=#NavigationMesh] GetAgentHeight
-- @return #number

---
-- Function GetAgentRadius
--
-- @function [parent=#NavigationMesh] GetAgentRadius
-- @return #number

---
-- Function GetAgentMaxClimb
--
-- @function [parent=#NavigationMesh] GetAgentMaxClimb
-- @return #number

---
-- Function GetAgentMaxSlope
--
-- @function [parent=#NavigationMesh] GetAgentMaxSlope
-- @return #number

---
-- Function GetRegionMinSize
--
-- @function [parent=#NavigationMesh] GetRegionMinSize
-- @return #number

---
-- Function GetRegionMergeSize
--
-- @function [parent=#NavigationMesh] GetRegionMergeSize
-- @return #number

---
-- Function GetEdgeMaxLength
--
-- @function [parent=#NavigationMesh] GetEdgeMaxLength
-- @return #number

---
-- Function GetEdgeMaxError
--
-- @function [parent=#NavigationMesh] GetEdgeMaxError
-- @return #number

---
-- Function GetDetailSampleDistance
--
-- @function [parent=#NavigationMesh] GetDetailSampleDistance
-- @return #number

---
-- Function GetDetailSampleMaxError
--
-- @function [parent=#NavigationMesh] GetDetailSampleMaxError
-- @return #number

---
-- Function GetPadding
--
-- @function [parent=#NavigationMesh] GetPadding
-- @return const Vector3#const Vector3

---
-- Function IsInitialized
--
-- @function [parent=#NavigationMesh] IsInitialized
-- @return #boolean

---
-- Function GetBoundingBox
--
-- @function [parent=#NavigationMesh] GetBoundingBox
-- @return const BoundingBox#const BoundingBox

---
-- Function GetWorldBoundingBox
--
-- @function [parent=#NavigationMesh] GetWorldBoundingBox
-- @return BoundingBox#BoundingBox

---
-- Function GetNumTiles
--
-- @function [parent=#NavigationMesh] GetNumTiles
-- @return IntVector2#IntVector2

---
-- Field tileSize
--
-- @field [parent=#NavigationMesh] #number tileSize

---
-- Field cellSize
--
-- @field [parent=#NavigationMesh] #number cellSize

---
-- Field cellHeight
--
-- @field [parent=#NavigationMesh] #number cellHeight

---
-- Field agentHeight
--
-- @field [parent=#NavigationMesh] #number agentHeight

---
-- Field agentRadius
--
-- @field [parent=#NavigationMesh] #number agentRadius

---
-- Field agentMaxClimb
--
-- @field [parent=#NavigationMesh] #number agentMaxClimb

---
-- Field agentMaxSlope
--
-- @field [parent=#NavigationMesh] #number agentMaxSlope

---
-- Field regionMinSize
--
-- @field [parent=#NavigationMesh] #number regionMinSize

---
-- Field regionMergeSize
--
-- @field [parent=#NavigationMesh] #number regionMergeSize

---
-- Field edgeMaxLength
--
-- @field [parent=#NavigationMesh] #number edgeMaxLength

---
-- Field edgeMaxError
--
-- @field [parent=#NavigationMesh] #number edgeMaxError

---
-- Field detailSampleDistance
--
-- @field [parent=#NavigationMesh] #number detailSampleDistance

---
-- Field detailSampleMaxError
--
-- @field [parent=#NavigationMesh] #number detailSampleMaxError

---
-- Field padding
--
-- @field [parent=#NavigationMesh] Vector3#Vector3 padding

---
-- Field initialized (Read only)
--
-- @field [parent=#NavigationMesh] #boolean initialized

---
-- Field boundingBox (Read only)
--
-- @field [parent=#NavigationMesh] BoundingBox#BoundingBox boundingBox

---
-- Field worldBoundingBox (Read only)
--
-- @field [parent=#NavigationMesh] BoundingBox#BoundingBox worldBoundingBox

---
-- Field numTiles (Read only)
--
-- @field [parent=#NavigationMesh] IntVector2#IntVector2 numTiles

---
-- Function SetEnabled
--
-- @function [parent=#NavigationMesh] SetEnabled
-- @param #boolean enableenable

---
-- Function Remove
--
-- @function [parent=#NavigationMesh] Remove

---
-- Function GetID
--
-- @function [parent=#NavigationMesh] GetID
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#NavigationMesh] GetNode
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#NavigationMesh] GetScene
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#NavigationMesh] IsEnabled
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#NavigationMesh] IsEnabledEffective
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#NavigationMesh] GetComponent
-- @param ShortStringHash#ShortStringHash typetype
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#NavigationMesh] GetComponent
-- @param #string typetype
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#NavigationMesh] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#NavigationMesh] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#NavigationMesh] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#NavigationMesh] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#NavigationMesh] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#NavigationMesh] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#NavigationMesh] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#NavigationMesh] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#NavigationMesh] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#NavigationMesh] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#NavigationMesh] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#NavigationMesh] #string category


return nil
