---
-- Module NavigationMesh
-- Module NavigationMesh extends Component
-- Generated on 2014-05-31
--
-- @module NavigationMesh

---
-- Function SetTileSize()
-- Set tile size.
--
-- @function [parent=#NavigationMesh] SetTileSize
-- @param self Self reference
-- @param #number size size

---
-- Function SetCellSize()
-- Set cell size.
--
-- @function [parent=#NavigationMesh] SetCellSize
-- @param self Self reference
-- @param #number size size

---
-- Function SetCellHeight()
-- Set cell height.
--
-- @function [parent=#NavigationMesh] SetCellHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetAgentHeight()
-- Set navigation agent height.
--
-- @function [parent=#NavigationMesh] SetAgentHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetAgentRadius()
-- Set navigation agent radius.
--
-- @function [parent=#NavigationMesh] SetAgentRadius
-- @param self Self reference
-- @param #number radius radius

---
-- Function SetAgentMaxClimb()
-- Set navigation agent max vertical climb.
--
-- @function [parent=#NavigationMesh] SetAgentMaxClimb
-- @param self Self reference
-- @param #number maxClimb maxClimb

---
-- Function SetAgentMaxSlope()
-- Set navigation agent max slope.
--
-- @function [parent=#NavigationMesh] SetAgentMaxSlope
-- @param self Self reference
-- @param #number maxSlope maxSlope

---
-- Function SetRegionMinSize()
-- Set region minimum size.
--
-- @function [parent=#NavigationMesh] SetRegionMinSize
-- @param self Self reference
-- @param #number size size

---
-- Function SetRegionMergeSize()
-- Set region merge size.
--
-- @function [parent=#NavigationMesh] SetRegionMergeSize
-- @param self Self reference
-- @param #number size size

---
-- Function SetEdgeMaxLength()
-- Set edge max length.
--
-- @function [parent=#NavigationMesh] SetEdgeMaxLength
-- @param self Self reference
-- @param #number length length

---
-- Function SetEdgeMaxError()
-- Set edge max error.
--
-- @function [parent=#NavigationMesh] SetEdgeMaxError
-- @param self Self reference
-- @param #number error error

---
-- Function SetDetailSampleDistance()
-- Set detail sampling distance.
--
-- @function [parent=#NavigationMesh] SetDetailSampleDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetDetailSampleMaxError()
-- Set detail sampling maximum error.
--
-- @function [parent=#NavigationMesh] SetDetailSampleMaxError
-- @param self Self reference
-- @param #number error error

---
-- Function SetPadding()
-- Set padding of the navigation mesh bounding box. Having enough padding allows to add geometry on the extremities of the navigation mesh when doing partial rebuilds.
--
-- @function [parent=#NavigationMesh] SetPadding
-- @param self Self reference
-- @param Vector3#Vector3 padding padding

---
-- Function Build()
-- Rebuild the navigation mesh. Return true if successful.
--
-- @function [parent=#NavigationMesh] Build
-- @param self Self reference
-- @return #boolean

---
-- Function Build()
-- Rebuild part of the navigation mesh contained by the world-space bounding box. Return true if successful.
--
-- @function [parent=#NavigationMesh] Build
-- @param self Self reference
-- @param BoundingBox#BoundingBox boundingBox boundingBox
-- @return #boolean

---
-- Function FindNearestPoint()
-- Find the nearest point on the navigation mesh to a given point. Extens specifies how far out from the specified point to check along each axis.
--
-- @function [parent=#NavigationMesh] FindNearestPoint
-- @param self Self reference
-- @param Vector3#Vector3 point point
-- @return Vector3#Vector3

---
-- Function FindNearestPoint()
--
-- @function [parent=#NavigationMesh] FindNearestPoint
-- @param self Self reference
-- @param Vector3#Vector3 point point
-- @param Vector3#Vector3 extents extents
-- @return Vector3#Vector3

---
-- Function MoveAlongSurface()
-- Try to move along the surface from one point to another
--
-- @function [parent=#NavigationMesh] MoveAlongSurface
-- @param self Self reference
-- @param Vector3#Vector3 start start
-- @param Vector3#Vector3 end end
-- @return Vector3#Vector3

---
-- Function MoveAlongSurface()
--
-- @function [parent=#NavigationMesh] MoveAlongSurface
-- @param self Self reference
-- @param Vector3#Vector3 start start
-- @param Vector3#Vector3 end end
-- @param Vector3#Vector3 extents extents
-- @param #number maxVisited maxVisited
-- @return Vector3#Vector3

---
-- Function FindPath()
--
-- @function [parent=#NavigationMesh] FindPath
-- @param self Self reference
-- @param Vector3#Vector3 start start
-- @param Vector3#Vector3 end end
-- @return const PODVector<Vector3>#const PODVector<Vector3>

---
-- Function FindPath()
--
-- @function [parent=#NavigationMesh] FindPath
-- @param self Self reference
-- @param Vector3#Vector3 start start
-- @param Vector3#Vector3 end end
-- @param Vector3#Vector3 extents extents
-- @return const PODVector<Vector3>#const PODVector<Vector3>

---
-- Function GetRandomPoint()
-- Return a random point on the navigation mesh.
--
-- @function [parent=#NavigationMesh] GetRandomPoint
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetRandomPointInCircle()
-- Return a random point on the navigation mesh within a circle. The circle radius is only a guideline and in practice the returned point may be further away.
--
-- @function [parent=#NavigationMesh] GetRandomPointInCircle
-- @param self Self reference
-- @param Vector3#Vector3 center center
-- @param #number radius radius
-- @return Vector3#Vector3

---
-- Function GetRandomPointInCircle()
--
-- @function [parent=#NavigationMesh] GetRandomPointInCircle
-- @param self Self reference
-- @param Vector3#Vector3 center center
-- @param #number radius radius
-- @param Vector3#Vector3 extents extents
-- @return Vector3#Vector3

---
-- Function GetDistanceToWall()
-- Return distance to wall from a point. Maximum search radius must be specified.
--
-- @function [parent=#NavigationMesh] GetDistanceToWall
-- @param self Self reference
-- @param Vector3#Vector3 point point
-- @param #number radius radius
-- @return #number

---
-- Function GetDistanceToWall()
--
-- @function [parent=#NavigationMesh] GetDistanceToWall
-- @param self Self reference
-- @param Vector3#Vector3 point point
-- @param #number radius radius
-- @param Vector3#Vector3 extents extents
-- @return #number

---
-- Function Raycast()
-- Perform a walkability raycast on the navigation mesh between start and end and return the point where a wall was hit, or the end point if no walls.
--
-- @function [parent=#NavigationMesh] Raycast
-- @param self Self reference
-- @param Vector3#Vector3 start start
-- @param Vector3#Vector3 end end
-- @return Vector3#Vector3

---
-- Function Raycast()
--
-- @function [parent=#NavigationMesh] Raycast
-- @param self Self reference
-- @param Vector3#Vector3 start start
-- @param Vector3#Vector3 end end
-- @param Vector3#Vector3 extents extents
-- @return Vector3#Vector3

---
-- Function DrawDebugGeometry()
-- Add debug geometry to the debug renderer.
--
-- @function [parent=#NavigationMesh] DrawDebugGeometry
-- @param self Self reference
-- @param #boolean depthTest depthTest

---
-- Function GetTileSize()
-- Return tile size.
--
-- @function [parent=#NavigationMesh] GetTileSize
-- @param self Self reference
-- @return #number

---
-- Function GetCellSize()
-- Return cell size.
--
-- @function [parent=#NavigationMesh] GetCellSize
-- @param self Self reference
-- @return #number

---
-- Function GetCellHeight()
-- Return cell height.
--
-- @function [parent=#NavigationMesh] GetCellHeight
-- @param self Self reference
-- @return #number

---
-- Function GetAgentHeight()
-- Return navigation agent height.
--
-- @function [parent=#NavigationMesh] GetAgentHeight
-- @param self Self reference
-- @return #number

---
-- Function GetAgentRadius()
-- Return navigation agent radius.
--
-- @function [parent=#NavigationMesh] GetAgentRadius
-- @param self Self reference
-- @return #number

---
-- Function GetAgentMaxClimb()
-- Return navigation agent max vertical climb.
--
-- @function [parent=#NavigationMesh] GetAgentMaxClimb
-- @param self Self reference
-- @return #number

---
-- Function GetAgentMaxSlope()
-- Return navigation agent max slope.
--
-- @function [parent=#NavigationMesh] GetAgentMaxSlope
-- @param self Self reference
-- @return #number

---
-- Function GetRegionMinSize()
-- Return region minimum size.
--
-- @function [parent=#NavigationMesh] GetRegionMinSize
-- @param self Self reference
-- @return #number

---
-- Function GetRegionMergeSize()
-- Return region merge size.
--
-- @function [parent=#NavigationMesh] GetRegionMergeSize
-- @param self Self reference
-- @return #number

---
-- Function GetEdgeMaxLength()
-- Return edge max length.
--
-- @function [parent=#NavigationMesh] GetEdgeMaxLength
-- @param self Self reference
-- @return #number

---
-- Function GetEdgeMaxError()
-- Return edge max error.
--
-- @function [parent=#NavigationMesh] GetEdgeMaxError
-- @param self Self reference
-- @return #number

---
-- Function GetDetailSampleDistance()
-- Return detail sampling distance.
--
-- @function [parent=#NavigationMesh] GetDetailSampleDistance
-- @param self Self reference
-- @return #number

---
-- Function GetDetailSampleMaxError()
-- Return detail sampling maximum error.
--
-- @function [parent=#NavigationMesh] GetDetailSampleMaxError
-- @param self Self reference
-- @return #number

---
-- Function GetPadding()
-- Return navigation mesh bounding box padding.
--
-- @function [parent=#NavigationMesh] GetPadding
-- @param self Self reference
-- @return const Vector3#const Vector3

---
-- Function IsInitialized()
-- Return whether has been initialized with valid navigation data.
--
-- @function [parent=#NavigationMesh] IsInitialized
-- @param self Self reference
-- @return #boolean

---
-- Function GetBoundingBox()
-- Return local space bounding box of the navigation mesh.
--
-- @function [parent=#NavigationMesh] GetBoundingBox
-- @param self Self reference
-- @return const BoundingBox#const BoundingBox

---
-- Function GetWorldBoundingBox()
-- Return world space bounding box of the navigation mesh.
--
-- @function [parent=#NavigationMesh] GetWorldBoundingBox
-- @param self Self reference
-- @return BoundingBox#BoundingBox

---
-- Function GetNumTiles()
--
-- @function [parent=#NavigationMesh] GetNumTiles
-- @param self Self reference
-- @return IntVector2#IntVector2

---
-- Field tileSize
--
-- @field [parent=#NavigationMesh] #number tileSize

---
-- Field cellSize
--
-- @field [parent=#NavigationMesh] #number cellSize

---
-- Field cellHeight
--
-- @field [parent=#NavigationMesh] #number cellHeight

---
-- Field agentHeight
--
-- @field [parent=#NavigationMesh] #number agentHeight

---
-- Field agentRadius
--
-- @field [parent=#NavigationMesh] #number agentRadius

---
-- Field agentMaxClimb
--
-- @field [parent=#NavigationMesh] #number agentMaxClimb

---
-- Field agentMaxSlope
--
-- @field [parent=#NavigationMesh] #number agentMaxSlope

---
-- Field regionMinSize
--
-- @field [parent=#NavigationMesh] #number regionMinSize

---
-- Field regionMergeSize
--
-- @field [parent=#NavigationMesh] #number regionMergeSize

---
-- Field edgeMaxLength
--
-- @field [parent=#NavigationMesh] #number edgeMaxLength

---
-- Field edgeMaxError
--
-- @field [parent=#NavigationMesh] #number edgeMaxError

---
-- Field detailSampleDistance
--
-- @field [parent=#NavigationMesh] #number detailSampleDistance

---
-- Field detailSampleMaxError
--
-- @field [parent=#NavigationMesh] #number detailSampleMaxError

---
-- Field padding
--
-- @field [parent=#NavigationMesh] Vector3#Vector3 padding

---
-- Field initialized (Read only)
--
-- @field [parent=#NavigationMesh] #boolean initialized

---
-- Field boundingBox (Read only)
--
-- @field [parent=#NavigationMesh] BoundingBox#BoundingBox boundingBox

---
-- Field worldBoundingBox (Read only)
--
-- @field [parent=#NavigationMesh] BoundingBox#BoundingBox worldBoundingBox

---
-- Field numTiles (Read only)
--
-- @field [parent=#NavigationMesh] IntVector2#IntVector2 numTiles


return nil
