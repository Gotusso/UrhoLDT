---
-- Module NavigationMesh
-- Module NavigationMesh extends Component
-- Generated on 2014-03-13
--
-- @module NavigationMesh

---
-- Function SetTileSize
--
-- @function [parent=#NavigationMesh] SetTileSize
-- @param self Self reference
-- @param #number size size

---
-- Function SetCellSize
--
-- @function [parent=#NavigationMesh] SetCellSize
-- @param self Self reference
-- @param #number size size

---
-- Function SetCellHeight
--
-- @function [parent=#NavigationMesh] SetCellHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetAgentHeight
--
-- @function [parent=#NavigationMesh] SetAgentHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetAgentRadius
--
-- @function [parent=#NavigationMesh] SetAgentRadius
-- @param self Self reference
-- @param #number radius radius

---
-- Function SetAgentMaxClimb
--
-- @function [parent=#NavigationMesh] SetAgentMaxClimb
-- @param self Self reference
-- @param #number maxClimb maxClimb

---
-- Function SetAgentMaxSlope
--
-- @function [parent=#NavigationMesh] SetAgentMaxSlope
-- @param self Self reference
-- @param #number maxSlope maxSlope

---
-- Function SetRegionMinSize
--
-- @function [parent=#NavigationMesh] SetRegionMinSize
-- @param self Self reference
-- @param #number size size

---
-- Function SetRegionMergeSize
--
-- @function [parent=#NavigationMesh] SetRegionMergeSize
-- @param self Self reference
-- @param #number size size

---
-- Function SetEdgeMaxLength
--
-- @function [parent=#NavigationMesh] SetEdgeMaxLength
-- @param self Self reference
-- @param #number length length

---
-- Function SetEdgeMaxError
--
-- @function [parent=#NavigationMesh] SetEdgeMaxError
-- @param self Self reference
-- @param #number error error

---
-- Function SetDetailSampleDistance
--
-- @function [parent=#NavigationMesh] SetDetailSampleDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetDetailSampleMaxError
--
-- @function [parent=#NavigationMesh] SetDetailSampleMaxError
-- @param self Self reference
-- @param #number error error

---
-- Function SetPadding
--
-- @function [parent=#NavigationMesh] SetPadding
-- @param self Self reference
-- @param Vector3#Vector3 padding padding

---
-- Function Build
--
-- @function [parent=#NavigationMesh] Build
-- @param self Self reference
-- @return #boolean

---
-- Function Build
--
-- @function [parent=#NavigationMesh] Build
-- @param self Self reference
-- @param BoundingBox#BoundingBox boundingBox boundingBox
-- @return #boolean

---
-- Function FindNearestPoint
--
-- @function [parent=#NavigationMesh] FindNearestPoint
-- @param self Self reference
-- @param Vector3#Vector3 point point
-- @return Vector3#Vector3

---
-- Function FindNearestPoint
--
-- @function [parent=#NavigationMesh] FindNearestPoint
-- @param self Self reference
-- @param Vector3#Vector3 point point
-- @param Vector3#Vector3 extents extents
-- @return Vector3#Vector3

---
-- Function MoveAlongSurface
--
-- @function [parent=#NavigationMesh] MoveAlongSurface
-- @param self Self reference
-- @param Vector3#Vector3 start start
-- @param Vector3#Vector3 end end
-- @return Vector3#Vector3

---
-- Function MoveAlongSurface
--
-- @function [parent=#NavigationMesh] MoveAlongSurface
-- @param self Self reference
-- @param Vector3#Vector3 start start
-- @param Vector3#Vector3 end end
-- @param Vector3#Vector3 extents extents
-- @param #number maxVisited maxVisited
-- @return Vector3#Vector3

---
-- Function FindPath
--
-- @function [parent=#NavigationMesh] FindPath
-- @param self Self reference
-- @param Vector3#Vector3 start start
-- @param Vector3#Vector3 end end
-- @return const PODVector<Vector3>#const PODVector<Vector3>

---
-- Function FindPath
--
-- @function [parent=#NavigationMesh] FindPath
-- @param self Self reference
-- @param Vector3#Vector3 start start
-- @param Vector3#Vector3 end end
-- @param Vector3#Vector3 extents extents
-- @return const PODVector<Vector3>#const PODVector<Vector3>

---
-- Function GetRandomPoint
--
-- @function [parent=#NavigationMesh] GetRandomPoint
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function GetRandomPointInCircle
--
-- @function [parent=#NavigationMesh] GetRandomPointInCircle
-- @param self Self reference
-- @param Vector3#Vector3 center center
-- @param #number radius radius
-- @return Vector3#Vector3

---
-- Function GetRandomPointInCircle
--
-- @function [parent=#NavigationMesh] GetRandomPointInCircle
-- @param self Self reference
-- @param Vector3#Vector3 center center
-- @param #number radius radius
-- @param Vector3#Vector3 extents extents
-- @return Vector3#Vector3

---
-- Function GetDistanceToWall
--
-- @function [parent=#NavigationMesh] GetDistanceToWall
-- @param self Self reference
-- @param Vector3#Vector3 point point
-- @param #number radius radius
-- @return #number

---
-- Function GetDistanceToWall
--
-- @function [parent=#NavigationMesh] GetDistanceToWall
-- @param self Self reference
-- @param Vector3#Vector3 point point
-- @param #number radius radius
-- @param Vector3#Vector3 extents extents
-- @return #number

---
-- Function Raycast
--
-- @function [parent=#NavigationMesh] Raycast
-- @param self Self reference
-- @param Vector3#Vector3 start start
-- @param Vector3#Vector3 end end
-- @return Vector3#Vector3

---
-- Function Raycast
--
-- @function [parent=#NavigationMesh] Raycast
-- @param self Self reference
-- @param Vector3#Vector3 start start
-- @param Vector3#Vector3 end end
-- @param Vector3#Vector3 extents extents
-- @return Vector3#Vector3

---
-- Function DrawDebugGeometry
--
-- @function [parent=#NavigationMesh] DrawDebugGeometry
-- @param self Self reference
-- @param #boolean depthTest depthTest

---
-- Function GetTileSize
--
-- @function [parent=#NavigationMesh] GetTileSize
-- @param self Self reference
-- @return #number

---
-- Function GetCellSize
--
-- @function [parent=#NavigationMesh] GetCellSize
-- @param self Self reference
-- @return #number

---
-- Function GetCellHeight
--
-- @function [parent=#NavigationMesh] GetCellHeight
-- @param self Self reference
-- @return #number

---
-- Function GetAgentHeight
--
-- @function [parent=#NavigationMesh] GetAgentHeight
-- @param self Self reference
-- @return #number

---
-- Function GetAgentRadius
--
-- @function [parent=#NavigationMesh] GetAgentRadius
-- @param self Self reference
-- @return #number

---
-- Function GetAgentMaxClimb
--
-- @function [parent=#NavigationMesh] GetAgentMaxClimb
-- @param self Self reference
-- @return #number

---
-- Function GetAgentMaxSlope
--
-- @function [parent=#NavigationMesh] GetAgentMaxSlope
-- @param self Self reference
-- @return #number

---
-- Function GetRegionMinSize
--
-- @function [parent=#NavigationMesh] GetRegionMinSize
-- @param self Self reference
-- @return #number

---
-- Function GetRegionMergeSize
--
-- @function [parent=#NavigationMesh] GetRegionMergeSize
-- @param self Self reference
-- @return #number

---
-- Function GetEdgeMaxLength
--
-- @function [parent=#NavigationMesh] GetEdgeMaxLength
-- @param self Self reference
-- @return #number

---
-- Function GetEdgeMaxError
--
-- @function [parent=#NavigationMesh] GetEdgeMaxError
-- @param self Self reference
-- @return #number

---
-- Function GetDetailSampleDistance
--
-- @function [parent=#NavigationMesh] GetDetailSampleDistance
-- @param self Self reference
-- @return #number

---
-- Function GetDetailSampleMaxError
--
-- @function [parent=#NavigationMesh] GetDetailSampleMaxError
-- @param self Self reference
-- @return #number

---
-- Function GetPadding
--
-- @function [parent=#NavigationMesh] GetPadding
-- @param self Self reference
-- @return const Vector3#const Vector3

---
-- Function IsInitialized
--
-- @function [parent=#NavigationMesh] IsInitialized
-- @param self Self reference
-- @return #boolean

---
-- Function GetBoundingBox
--
-- @function [parent=#NavigationMesh] GetBoundingBox
-- @param self Self reference
-- @return const BoundingBox#const BoundingBox

---
-- Function GetWorldBoundingBox
--
-- @function [parent=#NavigationMesh] GetWorldBoundingBox
-- @param self Self reference
-- @return BoundingBox#BoundingBox

---
-- Function GetNumTiles
--
-- @function [parent=#NavigationMesh] GetNumTiles
-- @param self Self reference
-- @return IntVector2#IntVector2

---
-- Field tileSize
--
-- @field [parent=#NavigationMesh] #number tileSize

---
-- Field cellSize
--
-- @field [parent=#NavigationMesh] #number cellSize

---
-- Field cellHeight
--
-- @field [parent=#NavigationMesh] #number cellHeight

---
-- Field agentHeight
--
-- @field [parent=#NavigationMesh] #number agentHeight

---
-- Field agentRadius
--
-- @field [parent=#NavigationMesh] #number agentRadius

---
-- Field agentMaxClimb
--
-- @field [parent=#NavigationMesh] #number agentMaxClimb

---
-- Field agentMaxSlope
--
-- @field [parent=#NavigationMesh] #number agentMaxSlope

---
-- Field regionMinSize
--
-- @field [parent=#NavigationMesh] #number regionMinSize

---
-- Field regionMergeSize
--
-- @field [parent=#NavigationMesh] #number regionMergeSize

---
-- Field edgeMaxLength
--
-- @field [parent=#NavigationMesh] #number edgeMaxLength

---
-- Field edgeMaxError
--
-- @field [parent=#NavigationMesh] #number edgeMaxError

---
-- Field detailSampleDistance
--
-- @field [parent=#NavigationMesh] #number detailSampleDistance

---
-- Field detailSampleMaxError
--
-- @field [parent=#NavigationMesh] #number detailSampleMaxError

---
-- Field padding
--
-- @field [parent=#NavigationMesh] Vector3#Vector3 padding

---
-- Field initialized (Read only)
--
-- @field [parent=#NavigationMesh] #boolean initialized

---
-- Field boundingBox (Read only)
--
-- @field [parent=#NavigationMesh] BoundingBox#BoundingBox boundingBox

---
-- Field worldBoundingBox (Read only)
--
-- @field [parent=#NavigationMesh] BoundingBox#BoundingBox worldBoundingBox

---
-- Field numTiles (Read only)
--
-- @field [parent=#NavigationMesh] IntVector2#IntVector2 numTiles

---
-- Function SetEnabled
--
-- @function [parent=#NavigationMesh] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Remove
--
-- @function [parent=#NavigationMesh] Remove
-- @param self Self reference

---
-- Function GetID
--
-- @function [parent=#NavigationMesh] GetID
-- @param self Self reference
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#NavigationMesh] GetNode
-- @param self Self reference
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#NavigationMesh] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#NavigationMesh] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#NavigationMesh] IsEnabledEffective
-- @param self Self reference
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#NavigationMesh] GetComponent
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#NavigationMesh] GetComponent
-- @param self Self reference
-- @param #string type type
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#NavigationMesh] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#NavigationMesh] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#NavigationMesh] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#NavigationMesh] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#NavigationMesh] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#NavigationMesh] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#NavigationMesh] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#NavigationMesh] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#NavigationMesh] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#NavigationMesh] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#NavigationMesh] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#NavigationMesh] #string category


return nil
