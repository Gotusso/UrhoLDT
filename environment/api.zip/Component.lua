---
-- Module Component
-- Extends Serializable
--
-- @module Component

---
-- Function SetEnabled
--
-- @function [parent=#Component] SetEnabled
-- @param #boolean enableenable

---
-- Function Remove
--
-- @function [parent=#Component] Remove

---
-- Function GetID
--
-- @function [parent=#Component] GetID
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#Component] GetNode
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#Component] GetScene
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#Component] IsEnabled
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#Component] IsEnabledEffective
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#Component] GetComponent
-- @param ShortStringHash#ShortStringHash typetype
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#Component] GetComponent
-- @param #string typetype
-- @return Component#Component


return nil
