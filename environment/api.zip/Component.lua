---
-- Module Component
-- Module Component extends Animatable
-- Generated on 2014-05-31
--
-- @module Component

---
-- Function SetEnabled()
-- Set enabled/disabled state.
--
-- @function [parent=#Component] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Remove()
-- Remove from the scene node. If no other shared pointer references exist, causes immediate deletion.
--
-- @function [parent=#Component] Remove
-- @param self Self reference

---
-- Function GetID()
-- Return ID.
--
-- @function [parent=#Component] GetID
-- @param self Self reference
-- @return #number

---
-- Function GetNode()
-- Return scene node.
--
-- @function [parent=#Component] GetNode
-- @param self Self reference
-- @return Node#Node

---
-- Function GetScene()
-- Return the scene the node belongs to.
--
-- @function [parent=#Component] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function IsEnabled()
-- Return whether is enabled.
--
-- @function [parent=#Component] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabledEffective()
-- Return whether is effectively enabled (node is also enabled.)
--
-- @function [parent=#Component] IsEnabledEffective
-- @param self Self reference
-- @return #boolean

---
-- Function GetComponent()
-- Return component in the same scene node by type. If there are several, returns the first.
--
-- @function [parent=#Component] GetComponent
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return Component#Component

---
-- Function GetComponent()
--
-- @function [parent=#Component] GetComponent
-- @param self Self reference
-- @param #string type type
-- @return Component#Component


return nil
