---
-- Module Component
-- extends Serializable
--
-- @module Component

---
-- Function SetEnabled
--
-- @function [parent=#Component] SetEnabled
-- @param #boolean enableenable

---
-- Function Remove
--
-- @function [parent=#Component] Remove

---
-- Function GetID
--
-- @function [parent=#Component] GetID
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#Component] GetNode
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#Component] GetScene
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#Component] IsEnabled
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#Component] IsEnabledEffective
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#Component] GetComponent
-- @param ShortStringHash#ShortStringHash typetype
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#Component] GetComponent
-- @param #string typetype
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#Component] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#Component] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Component] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Component] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Component] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Component] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Component] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Component] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#Component] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Component] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Component] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Component] #string category


return nil
