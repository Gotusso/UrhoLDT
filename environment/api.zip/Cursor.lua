---
-- Module Cursor
-- Module Cursor extends BorderImage
-- Generated on 2014-05-31
--
-- @module Cursor

---
-- Function Cursor()
--
-- @function [parent=#Cursor] Cursor
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#Cursor] new
-- @param self Self reference
-- @return Cursor#Cursor

---
-- Function delete()
--
-- @function [parent=#Cursor] delete
-- @param self Self reference

---
-- Function DefineShape()
-- Define a shape.
--
-- @function [parent=#Cursor] DefineShape
-- @param self Self reference
-- @param CursorShape#CursorShape shape shape
-- @param Image#Image image image
-- @param IntRect#IntRect imageRect imageRect
-- @param IntVector2#IntVector2 hotSpot hotSpot

---
-- Function SetShape()
-- Set current shape.
--
-- @function [parent=#Cursor] SetShape
-- @param self Self reference
-- @param CursorShape#CursorShape shape shape

---
-- Function SetUseSystemShapes()
-- Set whether to use system default shapes. Is only possible when the OS mouse cursor has been set visible from the Input subsystem.
--
-- @function [parent=#Cursor] SetUseSystemShapes
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function GetShape()
-- Get current shape.
--
-- @function [parent=#Cursor] GetShape
-- @param self Self reference
-- @return CursorShape#CursorShape

---
-- Function GetUseSystemShapes()
-- Return whether is using system default shapes.
--
-- @function [parent=#Cursor] GetUseSystemShapes
-- @param self Self reference
-- @return #boolean

---
-- Field shape
--
-- @field [parent=#Cursor] CursorShape#CursorShape shape

---
-- Field useSystemShapes
--
-- @field [parent=#Cursor] #boolean useSystemShapes


return nil
