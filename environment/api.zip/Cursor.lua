---
-- Module Cursor
-- extends BorderImage
--
-- @module Cursor

---
-- Function Cursor
--
-- @function [parent=#Cursor] Cursor

---
-- Function new
--
-- @function [parent=#Cursor] new
-- @return Cursor#Cursor

---
-- Function delete
--
-- @function [parent=#Cursor] delete

---
-- Function DefineShape
--
-- @function [parent=#Cursor] DefineShape
-- @param CursorShape#CursorShape shapeshape
-- @param Image#Image imageimage
-- @param IntRect#IntRect imageRectimageRect
-- @param IntVector2#IntVector2 hotSpothotSpot

---
-- Function SetShape
--
-- @function [parent=#Cursor] SetShape
-- @param CursorShape#CursorShape shapeshape

---
-- Function SetUseSystemShapes
--
-- @function [parent=#Cursor] SetUseSystemShapes
-- @param #boolean enableenable

---
-- Function GetShape
--
-- @function [parent=#Cursor] GetShape
-- @return CursorShape#CursorShape

---
-- Function GetUseSystemShapes
--
-- @function [parent=#Cursor] GetUseSystemShapes
-- @return #boolean

---
-- Field shape
--
-- @field [parent=#Cursor] CursorShape#CursorShape shape

---
-- Field useSystemShapes
--
-- @field [parent=#Cursor] #boolean useSystemShapes

---
-- Function BorderImage
--
-- @function [parent=#Cursor] BorderImage

---
-- Function new
--
-- @function [parent=#Cursor] new
-- @return BorderImage#BorderImage

---
-- Function delete
--
-- @function [parent=#Cursor] delete

---
-- Function SetTexture
--
-- @function [parent=#Cursor] SetTexture
-- @param Texture#Texture texturetexture

---
-- Function SetImageRect
--
-- @function [parent=#Cursor] SetImageRect
-- @param IntRect#IntRect rectrect

---
-- Function SetFullImageRect
--
-- @function [parent=#Cursor] SetFullImageRect

---
-- Function SetBorder
--
-- @function [parent=#Cursor] SetBorder
-- @param IntRect#IntRect rectrect

---
-- Function SetHoverOffset
--
-- @function [parent=#Cursor] SetHoverOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetHoverOffset
--
-- @function [parent=#Cursor] SetHoverOffset
-- @param #number xx
-- @param #number yy

---
-- Function SetBlendMode
--
-- @function [parent=#Cursor] SetBlendMode
-- @param BlendMode#BlendMode modemode

---
-- Function SetTiled
--
-- @function [parent=#Cursor] SetTiled
-- @param #boolean enableenable

---
-- Function GetTexture
--
-- @function [parent=#Cursor] GetTexture
-- @return Texture#Texture

---
-- Function GetImageRect
--
-- @function [parent=#Cursor] GetImageRect
-- @return const IntRect#const IntRect

---
-- Function GetBorder
--
-- @function [parent=#Cursor] GetBorder
-- @return const IntRect#const IntRect

---
-- Function GetHoverOffset
--
-- @function [parent=#Cursor] GetHoverOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetBlendMode
--
-- @function [parent=#Cursor] GetBlendMode
-- @return BlendMode#BlendMode

---
-- Function IsTiled
--
-- @function [parent=#Cursor] IsTiled
-- @return #boolean

---
-- Field texture
--
-- @field [parent=#Cursor] Texture#Texture texture

---
-- Field imageRect
--
-- @field [parent=#Cursor] IntRect#IntRect imageRect

---
-- Field border
--
-- @field [parent=#Cursor] IntRect#IntRect border

---
-- Field hoverOffset
--
-- @field [parent=#Cursor] IntVector2#IntVector2 hoverOffset

---
-- Field blendMode
--
-- @field [parent=#Cursor] BlendMode#BlendMode blendMode

---
-- Field tiled
--
-- @field [parent=#Cursor] #boolean tiled

---
-- Function UIElement
--
-- @function [parent=#Cursor] UIElement

---
-- Function new
--
-- @function [parent=#Cursor] new
-- @return UIElement#UIElement

---
-- Function delete
--
-- @function [parent=#Cursor] delete

---
-- Function GetScreenPosition
--
-- @function [parent=#Cursor] GetScreenPosition
-- @return const IntVector2#const IntVector2

---
-- Function LoadXML
--
-- @function [parent=#Cursor] LoadXML
-- @param Deserializer#Deserializer sourcesource
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#Cursor] SaveXML
-- @param Serializer#Serializer destdest
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#Cursor] LoadXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#Cursor] SaveXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function FilterAttributes
--
-- @function [parent=#Cursor] FilterAttributes
-- @param XMLElement#XMLElement destdest
-- @return #boolean

---
-- Function SetName
--
-- @function [parent=#Cursor] SetName
-- @param #string namename

---
-- Function SetPosition
--
-- @function [parent=#Cursor] SetPosition
-- @param IntVector2#IntVector2 positionposition

---
-- Function SetPosition
--
-- @function [parent=#Cursor] SetPosition
-- @param #number xx
-- @param #number yy

---
-- Function SetSize
--
-- @function [parent=#Cursor] SetSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function SetSize
--
-- @function [parent=#Cursor] SetSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetWidth
--
-- @function [parent=#Cursor] SetWidth
-- @param #number widthwidth

---
-- Function SetHeight
--
-- @function [parent=#Cursor] SetHeight
-- @param #number heightheight

---
-- Function SetMinSize
--
-- @function [parent=#Cursor] SetMinSize
-- @param IntVector2#IntVector2 minSizeminSize

---
-- Function SetMinSize
--
-- @function [parent=#Cursor] SetMinSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetMinWidth
--
-- @function [parent=#Cursor] SetMinWidth
-- @param #number widthwidth

---
-- Function SetMinHeight
--
-- @function [parent=#Cursor] SetMinHeight
-- @param #number heightheight

---
-- Function SetMaxSize
--
-- @function [parent=#Cursor] SetMaxSize
-- @param IntVector2#IntVector2 maxSizemaxSize

---
-- Function SetMaxSize
--
-- @function [parent=#Cursor] SetMaxSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetMaxWidth
--
-- @function [parent=#Cursor] SetMaxWidth
-- @param #number widthwidth

---
-- Function SetMaxHeight
--
-- @function [parent=#Cursor] SetMaxHeight
-- @param #number heightheight

---
-- Function SetFixedSize
--
-- @function [parent=#Cursor] SetFixedSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function SetFixedSize
--
-- @function [parent=#Cursor] SetFixedSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetFixedWidth
--
-- @function [parent=#Cursor] SetFixedWidth
-- @param #number widthwidth

---
-- Function SetFixedHeight
--
-- @function [parent=#Cursor] SetFixedHeight
-- @param #number heightheight

---
-- Function SetAlignment
--
-- @function [parent=#Cursor] SetAlignment
-- @param HorizontalAlignment#HorizontalAlignment hAlignhAlign
-- @param VerticalAlignment#VerticalAlignment vAlignvAlign

---
-- Function SetHorizontalAlignment
--
-- @function [parent=#Cursor] SetHorizontalAlignment
-- @param HorizontalAlignment#HorizontalAlignment alignalign

---
-- Function SetVerticalAlignment
--
-- @function [parent=#Cursor] SetVerticalAlignment
-- @param VerticalAlignment#VerticalAlignment alignalign

---
-- Function SetClipBorder
--
-- @function [parent=#Cursor] SetClipBorder
-- @param IntRect#IntRect rectrect

---
-- Function SetColor
--
-- @function [parent=#Cursor] SetColor
-- @param Color#Color colorcolor

---
-- Function SetColor
--
-- @function [parent=#Cursor] SetColor
-- @param Corner#Corner cornercorner
-- @param Color#Color colorcolor

---
-- Function SetPriority
--
-- @function [parent=#Cursor] SetPriority
-- @param #number prioritypriority

---
-- Function SetOpacity
--
-- @function [parent=#Cursor] SetOpacity
-- @param #number opacityopacity

---
-- Function SetBringToFront
--
-- @function [parent=#Cursor] SetBringToFront
-- @param #boolean enableenable

---
-- Function SetBringToBack
--
-- @function [parent=#Cursor] SetBringToBack
-- @param #boolean enableenable

---
-- Function SetClipChildren
--
-- @function [parent=#Cursor] SetClipChildren
-- @param #boolean enableenable

---
-- Function SetSortChildren
--
-- @function [parent=#Cursor] SetSortChildren
-- @param #boolean enableenable

---
-- Function SetUseDerivedOpacity
--
-- @function [parent=#Cursor] SetUseDerivedOpacity
-- @param #boolean enableenable

---
-- Function SetEnabled
--
-- @function [parent=#Cursor] SetEnabled
-- @param #boolean enableenable

---
-- Function SetEditable
--
-- @function [parent=#Cursor] SetEditable
-- @param #boolean enableenable

---
-- Function SetFocus
--
-- @function [parent=#Cursor] SetFocus
-- @param #boolean enableenable

---
-- Function SetSelected
--
-- @function [parent=#Cursor] SetSelected
-- @param #boolean enableenable

---
-- Function SetVisible
--
-- @function [parent=#Cursor] SetVisible
-- @param #boolean enableenable

---
-- Function SetFocusMode
--
-- @function [parent=#Cursor] SetFocusMode
-- @param FocusMode#FocusMode modemode

---
-- Function SetDragDropMode
--
-- @function [parent=#Cursor] SetDragDropMode
-- @param #number modemode

---
-- Function SetStyle
--
-- @function [parent=#Cursor] SetStyle
-- @param #string styleNamestyleName
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetStyle
--
-- @function [parent=#Cursor] SetStyle
-- @param XMLElement#XMLElement elementelement
-- @return #boolean

---
-- Function SetStyleAuto
--
-- @function [parent=#Cursor] SetStyleAuto
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetDefaultStyle
--
-- @function [parent=#Cursor] SetDefaultStyle
-- @param XMLFile#XMLFile stylestyle

---
-- Function SetLayout
--
-- @function [parent=#Cursor] SetLayout
-- @param LayoutMode#LayoutMode modemode
-- @param #number spacingspacing

---
-- Function SetLayout
--
-- @function [parent=#Cursor] SetLayout
-- @param LayoutMode#LayoutMode modemode
-- @param #number spacingspacing
-- @param IntRect#IntRect borderborder

---
-- Function SetLayoutMode
--
-- @function [parent=#Cursor] SetLayoutMode
-- @param LayoutMode#LayoutMode modemode

---
-- Function SetLayoutSpacing
--
-- @function [parent=#Cursor] SetLayoutSpacing
-- @param #number spacingspacing

---
-- Function SetLayoutBorder
--
-- @function [parent=#Cursor] SetLayoutBorder
-- @param IntRect#IntRect borderborder

---
-- Function SetIndent
--
-- @function [parent=#Cursor] SetIndent
-- @param #number indentindent

---
-- Function SetIndentSpacing
--
-- @function [parent=#Cursor] SetIndentSpacing
-- @param #number indentSpacingindentSpacing

---
-- Function UpdateLayout
--
-- @function [parent=#Cursor] UpdateLayout

---
-- Function DisableLayoutUpdate
--
-- @function [parent=#Cursor] DisableLayoutUpdate

---
-- Function EnableLayoutUpdate
--
-- @function [parent=#Cursor] EnableLayoutUpdate

---
-- Function BringToFront
--
-- @function [parent=#Cursor] BringToFront

---
-- Function CreateChild
--
-- @function [parent=#Cursor] CreateChild
-- @param #string typetype
-- @param #string namename
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function AddChild
--
-- @function [parent=#Cursor] AddChild
-- @param UIElement#UIElement elementelement

---
-- Function InsertChild
--
-- @function [parent=#Cursor] InsertChild
-- @param #number indexindex
-- @param UIElement#UIElement elementelement

---
-- Function RemoveChild
--
-- @function [parent=#Cursor] RemoveChild
-- @param UIElement#UIElement elementelement
-- @param #number indexindex

---
-- Function RemoveChildAtIndex
--
-- @function [parent=#Cursor] RemoveChildAtIndex
-- @param #number indexindex

---
-- Function RemoveAllChildren
--
-- @function [parent=#Cursor] RemoveAllChildren

---
-- Function Remove
--
-- @function [parent=#Cursor] Remove

---
-- Function FindChild
--
-- @function [parent=#Cursor] FindChild
-- @param UIElement#UIElement elementelement
-- @return #number

---
-- Function SetParent
--
-- @function [parent=#Cursor] SetParent
-- @param UIElement#UIElement parentparent
-- @param #number indexindex

---
-- Function SetVar
--
-- @function [parent=#Cursor] SetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @param Variant#Variant valuevalue

---
-- Function SetInternal
--
-- @function [parent=#Cursor] SetInternal
-- @param #boolean enableenable

---
-- Function SetTraversalMode
--
-- @function [parent=#Cursor] SetTraversalMode
-- @param TraversalMode#TraversalMode traversalModetraversalMode

---
-- Function SetElementEventSender
--
-- @function [parent=#Cursor] SetElementEventSender
-- @param #boolean flagflag

---
-- Function GetName
--
-- @function [parent=#Cursor] GetName
-- @return const String#const String

---
-- Function GetPosition
--
-- @function [parent=#Cursor] GetPosition
-- @return const IntVector2#const IntVector2

---
-- Function GetSize
--
-- @function [parent=#Cursor] GetSize
-- @return const IntVector2#const IntVector2

---
-- Function GetWidth
--
-- @function [parent=#Cursor] GetWidth
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#Cursor] GetHeight
-- @return #number

---
-- Function GetMinSize
--
-- @function [parent=#Cursor] GetMinSize
-- @return const IntVector2#const IntVector2

---
-- Function GetMinWidth
--
-- @function [parent=#Cursor] GetMinWidth
-- @return #number

---
-- Function GetMinHeight
--
-- @function [parent=#Cursor] GetMinHeight
-- @return #number

---
-- Function GetMaxSize
--
-- @function [parent=#Cursor] GetMaxSize
-- @return const IntVector2#const IntVector2

---
-- Function GetMaxWidth
--
-- @function [parent=#Cursor] GetMaxWidth
-- @return #number

---
-- Function GetMaxHeight
--
-- @function [parent=#Cursor] GetMaxHeight
-- @return #number

---
-- Function IsFixedSize
--
-- @function [parent=#Cursor] IsFixedSize
-- @return #boolean

---
-- Function IsFixedWidth
--
-- @function [parent=#Cursor] IsFixedWidth
-- @return #boolean

---
-- Function IsFixedHeight
--
-- @function [parent=#Cursor] IsFixedHeight
-- @return #boolean

---
-- Function GetChildOffset
--
-- @function [parent=#Cursor] GetChildOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetHorizontalAlignment
--
-- @function [parent=#Cursor] GetHorizontalAlignment
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetVerticalAlignment
--
-- @function [parent=#Cursor] GetVerticalAlignment
-- @return VerticalAlignment#VerticalAlignment

---
-- Function GetClipBorder
--
-- @function [parent=#Cursor] GetClipBorder
-- @return const IntRect#const IntRect

---
-- Function GetColor
--
-- @function [parent=#Cursor] GetColor
-- @param Corner#Corner cornercorner
-- @return const Color#const Color

---
-- Function GetPriority
--
-- @function [parent=#Cursor] GetPriority
-- @return #number

---
-- Function GetOpacity
--
-- @function [parent=#Cursor] GetOpacity
-- @return #number

---
-- Function GetDerivedOpacity
--
-- @function [parent=#Cursor] GetDerivedOpacity
-- @return #number

---
-- Function GetBringToFront
--
-- @function [parent=#Cursor] GetBringToFront
-- @return #boolean

---
-- Function GetBringToBack
--
-- @function [parent=#Cursor] GetBringToBack
-- @return #boolean

---
-- Function GetClipChildren
--
-- @function [parent=#Cursor] GetClipChildren
-- @return #boolean

---
-- Function GetSortChildren
--
-- @function [parent=#Cursor] GetSortChildren
-- @return #boolean

---
-- Function GetUseDerivedOpacity
--
-- @function [parent=#Cursor] GetUseDerivedOpacity
-- @return #boolean

---
-- Function HasFocus
--
-- @function [parent=#Cursor] HasFocus
-- @return #boolean

---
-- Function IsEnabled
--
-- @function [parent=#Cursor] IsEnabled
-- @return #boolean

---
-- Function IsEditable
--
-- @function [parent=#Cursor] IsEditable
-- @return #boolean

---
-- Function IsSelected
--
-- @function [parent=#Cursor] IsSelected
-- @return #boolean

---
-- Function IsVisible
--
-- @function [parent=#Cursor] IsVisible
-- @return #boolean

---
-- Function IsHovering
--
-- @function [parent=#Cursor] IsHovering
-- @return #boolean

---
-- Function IsInternal
--
-- @function [parent=#Cursor] IsInternal
-- @return #boolean

---
-- Function HasColorGradient
--
-- @function [parent=#Cursor] HasColorGradient
-- @return #boolean

---
-- Function GetFocusMode
--
-- @function [parent=#Cursor] GetFocusMode
-- @return FocusMode#FocusMode

---
-- Function GetDragDropMode
--
-- @function [parent=#Cursor] GetDragDropMode
-- @return #number

---
-- Function GetAppliedStyle
--
-- @function [parent=#Cursor] GetAppliedStyle
-- @return const String#const String

---
-- Function GetDefaultStyle
--
-- @function [parent=#Cursor] GetDefaultStyle
-- @param #boolean recursiveUprecursiveUp
-- @return XMLFile#XMLFile

---
-- Function GetLayoutMode
--
-- @function [parent=#Cursor] GetLayoutMode
-- @return LayoutMode#LayoutMode

---
-- Function GetLayoutSpacing
--
-- @function [parent=#Cursor] GetLayoutSpacing
-- @return #number

---
-- Function GetLayoutBorder
--
-- @function [parent=#Cursor] GetLayoutBorder
-- @return const IntRect#const IntRect

---
-- Function GetNumChildren
--
-- @function [parent=#Cursor] GetNumChildren
-- @param #boolean recursiverecursive
-- @return #number

---
-- Function GetChild
--
-- @function [parent=#Cursor] GetChild
-- @param #string namename
-- @param #boolean recursiverecursive
-- @return UIElement#UIElement

---
-- Function GetChild
--
-- @function [parent=#Cursor] GetChild
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function GetParent
--
-- @function [parent=#Cursor] GetParent
-- @return UIElement#UIElement

---
-- Function GetRoot
--
-- @function [parent=#Cursor] GetRoot
-- @return UIElement#UIElement

---
-- Function GetDerivedColor
--
-- @function [parent=#Cursor] GetDerivedColor
-- @return const Color#const Color

---
-- Function GetVar
--
-- @function [parent=#Cursor] GetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @return const Variant#const Variant

---
-- Function GetVars
--
-- @function [parent=#Cursor] GetVars
-- @return const VariantMap#const VariantMap

---
-- Function ScreenToElement
--
-- @function [parent=#Cursor] ScreenToElement
-- @param IntVector2#IntVector2 screenPositionscreenPosition
-- @return IntVector2#IntVector2

---
-- Function ElementToScreen
--
-- @function [parent=#Cursor] ElementToScreen
-- @param IntVector2#IntVector2 positionposition
-- @return IntVector2#IntVector2

---
-- Function IsInside
--
-- @function [parent=#Cursor] IsInside
-- @param IntVector2#IntVector2 positionposition
-- @param #boolean isScreenisScreen
-- @return #boolean

---
-- Function IsInsideCombined
--
-- @function [parent=#Cursor] IsInsideCombined
-- @param IntVector2#IntVector2 positionposition
-- @param #boolean isScreenisScreen
-- @return #boolean

---
-- Function GetCombinedScreenRect
--
-- @function [parent=#Cursor] GetCombinedScreenRect
-- @return IntRect#IntRect

---
-- Function SortChildren
--
-- @function [parent=#Cursor] SortChildren

---
-- Function GetLayoutMinSize
--
-- @function [parent=#Cursor] GetLayoutMinSize
-- @return #number

---
-- Function GetIndent
--
-- @function [parent=#Cursor] GetIndent
-- @return #number

---
-- Function GetIndentSpacing
--
-- @function [parent=#Cursor] GetIndentSpacing
-- @return #number

---
-- Function GetIndentWidth
--
-- @function [parent=#Cursor] GetIndentWidth
-- @return #number

---
-- Function SetChildOffset
--
-- @function [parent=#Cursor] SetChildOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetHovering
--
-- @function [parent=#Cursor] SetHovering
-- @param #boolean enableenable

---
-- Function GetColor
--
-- @function [parent=#Cursor] GetColor
-- @return const Color#const Color

---
-- Function GetTraversalMode
--
-- @function [parent=#Cursor] GetTraversalMode
-- @return TraversalMode#TraversalMode

---
-- Function IsElementEventSender
--
-- @function [parent=#Cursor] IsElementEventSender
-- @return #boolean

---
-- Function GetElementEventSender
--
-- @function [parent=#Cursor] GetElementEventSender
-- @return UIElement#UIElement

---
-- Field screenPosition (Read only)
--
-- @field [parent=#Cursor] IntVector2#IntVector2 screenPosition

---
-- Field name
--
-- @field [parent=#Cursor] #string name

---
-- Field position
--
-- @field [parent=#Cursor] IntVector2#IntVector2 position

---
-- Field size
--
-- @field [parent=#Cursor] IntVector2#IntVector2 size

---
-- Field width
--
-- @field [parent=#Cursor] #number width

---
-- Field height
--
-- @field [parent=#Cursor] #number height

---
-- Field minSize
--
-- @field [parent=#Cursor] IntVector2#IntVector2 minSize

---
-- Field minWidth
--
-- @field [parent=#Cursor] #number minWidth

---
-- Field minHeight
--
-- @field [parent=#Cursor] #number minHeight

---
-- Field maxSize
--
-- @field [parent=#Cursor] IntVector2#IntVector2 maxSize

---
-- Field maxWidth
--
-- @field [parent=#Cursor] #number maxWidth

---
-- Field maxHeight
--
-- @field [parent=#Cursor] #number maxHeight

---
-- Field fixedSize (Read only)
--
-- @field [parent=#Cursor] #boolean fixedSize

---
-- Field fixedWidth (Read only)
--
-- @field [parent=#Cursor] #boolean fixedWidth

---
-- Field fixedHeight (Read only)
--
-- @field [parent=#Cursor] #boolean fixedHeight

---
-- Field childOffset
--
-- @field [parent=#Cursor] IntVector2#IntVector2 childOffset

---
-- Field horizontalAlignment
--
-- @field [parent=#Cursor] HorizontalAlignment#HorizontalAlignment horizontalAlignment

---
-- Field verticalAlignment
--
-- @field [parent=#Cursor] VerticalAlignment#VerticalAlignment verticalAlignment

---
-- Field clipBorder
--
-- @field [parent=#Cursor] IntRect#IntRect clipBorder

---
-- Field color
--
-- @field [parent=#Cursor] Color#Color color

---
-- Field priority
--
-- @field [parent=#Cursor] #number priority

---
-- Field opacity
--
-- @field [parent=#Cursor] #number opacity

---
-- Field derivedOpacity (Read only)
--
-- @field [parent=#Cursor] #number derivedOpacity

---
-- Field bringToFront
--
-- @field [parent=#Cursor] #boolean bringToFront

---
-- Field bringToBack
--
-- @field [parent=#Cursor] #boolean bringToBack

---
-- Field clipChildren
--
-- @field [parent=#Cursor] #boolean clipChildren

---
-- Field sortChildren
--
-- @field [parent=#Cursor] #boolean sortChildren

---
-- Field useDerivedOpacity
--
-- @field [parent=#Cursor] #boolean useDerivedOpacity

---
-- Field focus
--
-- @field [parent=#Cursor] #boolean focus

---
-- Field enabled
--
-- @field [parent=#Cursor] #boolean enabled

---
-- Field editable
--
-- @field [parent=#Cursor] #boolean editable

---
-- Field selected
--
-- @field [parent=#Cursor] #boolean selected

---
-- Field visible
--
-- @field [parent=#Cursor] #boolean visible

---
-- Field hovering
--
-- @field [parent=#Cursor] #boolean hovering

---
-- Field internal
--
-- @field [parent=#Cursor] #boolean internal

---
-- Field colorGradient (Read only)
--
-- @field [parent=#Cursor] #boolean colorGradient

---
-- Field focusMode
--
-- @field [parent=#Cursor] FocusMode#FocusMode focusMode

---
-- Field dragDropMode
--
-- @field [parent=#Cursor] #number dragDropMode

---
-- Field style
--
-- @field [parent=#Cursor] #string style

---
-- Field defaultStyle
--
-- @field [parent=#Cursor] XMLFile#XMLFile defaultStyle

---
-- Field layoutMode
--
-- @field [parent=#Cursor] LayoutMode#LayoutMode layoutMode

---
-- Field layoutSpacing
--
-- @field [parent=#Cursor] #number layoutSpacing

---
-- Field layoutBorder
--
-- @field [parent=#Cursor] IntRect#IntRect layoutBorder

---
-- Field numChildren (Read only)
--
-- @field [parent=#Cursor] #number numChildren

---
-- Field parent
--
-- @field [parent=#Cursor] UIElement#UIElement parent

---
-- Field root (Read only)
--
-- @field [parent=#Cursor] UIElement#UIElement root

---
-- Field derivedColor (Read only)
--
-- @field [parent=#Cursor] Color#Color derivedColor

---
-- Field combinedScreenRect (Read only)
--
-- @field [parent=#Cursor] IntRect#IntRect combinedScreenRect

---
-- Field layoutMinSize (Read only)
--
-- @field [parent=#Cursor] #number layoutMinSize

---
-- Field indent
--
-- @field [parent=#Cursor] #number indent

---
-- Field indentSpacing
--
-- @field [parent=#Cursor] #number indentSpacing

---
-- Field indentWidth (Read only)
--
-- @field [parent=#Cursor] #number indentWidth

---
-- Field traversalMode
--
-- @field [parent=#Cursor] TraversalMode#TraversalMode traversalMode

---
-- Field elementEventSender
--
-- @field [parent=#Cursor] #boolean elementEventSender

---
-- Function SetTemporary
--
-- @function [parent=#Cursor] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#Cursor] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Cursor] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Cursor] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Cursor] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Cursor] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Cursor] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Cursor] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#Cursor] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Cursor] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Cursor] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Cursor] #string category


return nil
