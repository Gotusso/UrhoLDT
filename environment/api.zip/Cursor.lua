---
-- Module Cursor
-- Extends BorderImage
--
-- @module Cursor

---
-- Function Cursor
--
-- @function [parent=#Cursor] Cursor

---
-- Function new
--
-- @function [parent=#Cursor] new
-- @return Cursor#Cursor

---
-- Function delete
--
-- @function [parent=#Cursor] delete

---
-- Function DefineShape
--
-- @function [parent=#Cursor] DefineShape
-- @param CursorShape#CursorShape shapeshape
-- @param Image#Image imageimage
-- @param IntRect#IntRect imageRectimageRect
-- @param IntVector2#IntVector2 hotSpothotSpot

---
-- Function SetShape
--
-- @function [parent=#Cursor] SetShape
-- @param CursorShape#CursorShape shapeshape

---
-- Function SetUseSystemShapes
--
-- @function [parent=#Cursor] SetUseSystemShapes
-- @param #boolean enableenable

---
-- Function GetShape
--
-- @function [parent=#Cursor] GetShape
-- @return CursorShape#CursorShape

---
-- Function GetUseSystemShapes
--
-- @function [parent=#Cursor] GetUseSystemShapes
-- @return #boolean

---
-- Field shape
--
-- @field [parent=#Cursor] CursorShape#CursorShape shape

---
-- Field useSystemShapes
--
-- @field [parent=#Cursor] #boolean useSystemShapes


return nil
