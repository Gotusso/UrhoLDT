---
-- Module StaticModelGeometryData
-- Generated on 2014-03-13
--
-- @module StaticModelGeometryData

---
-- Field center
--
-- @field [parent=#StaticModelGeometryData] Vector3#Vector3 center

---
-- Field lodLevel
--
-- @field [parent=#StaticModelGeometryData] #number lodLevel


return nil
