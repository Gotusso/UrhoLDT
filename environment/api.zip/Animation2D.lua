---
-- Module Animation2D
-- Module Animation2D extends Resource
-- Generated on 2014-05-31
--
-- @module Animation2D

---
-- Function GetTotalTime()
-- Return total time.
--
-- @function [parent=#Animation2D] GetTotalTime
-- @param self Self reference
-- @return #number

---
-- Function GetNumFrames()
-- Return number of frames.
--
-- @function [parent=#Animation2D] GetNumFrames
-- @param self Self reference
-- @return #number

---
-- Function GetFrameSprite()
-- Return Frame sprite.
--
-- @function [parent=#Animation2D] GetFrameSprite
-- @param self Self reference
-- @param #number index index
-- @return Sprite2D#Sprite2D

---
-- Function GetFrameSpriteByTime()
-- Return frame sprite by time.
--
-- @function [parent=#Animation2D] GetFrameSpriteByTime
-- @param self Self reference
-- @param #number time time
-- @return Sprite2D#Sprite2D

---
-- Field totalTime (Read only)
--
-- @field [parent=#Animation2D] #number totalTime

---
-- Field numFrames (Read only)
--
-- @field [parent=#Animation2D] #number numFrames


return nil
