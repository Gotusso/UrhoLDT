---
-- Module RigidBody2D
-- Module RigidBody2D extends Component
-- Generated on 2014-05-31
--
-- @module RigidBody2D

---
-- Function SetBodyType()
-- Set body type.
--
-- @function [parent=#RigidBody2D] SetBodyType
-- @param self Self reference
-- @param BodyType2D#BodyType2D bodyType bodyType

---
-- Function SetMass()
-- Set Mass.
--
-- @function [parent=#RigidBody2D] SetMass
-- @param self Self reference
-- @param #number mass mass

---
-- Function SetInertia()
-- Set inertia.
--
-- @function [parent=#RigidBody2D] SetInertia
-- @param self Self reference
-- @param #number inertia inertia

---
-- Function SetMassCenter()
-- Set mass center.
--
-- @function [parent=#RigidBody2D] SetMassCenter
-- @param self Self reference
-- @param Vector2#Vector2 center center

---
-- Function SetUseFixtureMass()
-- Use fixture mass (default is true).
--
-- @function [parent=#RigidBody2D] SetUseFixtureMass
-- @param self Self reference
-- @param #boolean useFixtureMass useFixtureMass

---
-- Function SetLinearDamping()
-- Set linear damping.
--
-- @function [parent=#RigidBody2D] SetLinearDamping
-- @param self Self reference
-- @param #number linearDamping linearDamping

---
-- Function SetAngularDamping()
-- Set angular damping.
--
-- @function [parent=#RigidBody2D] SetAngularDamping
-- @param self Self reference
-- @param #number angularDamping angularDamping

---
-- Function SetAllowSleep()
-- Set allow sleep.
--
-- @function [parent=#RigidBody2D] SetAllowSleep
-- @param self Self reference
-- @param #boolean allowSleep allowSleep

---
-- Function SetFixedRotation()
-- Set fixed rotation.
--
-- @function [parent=#RigidBody2D] SetFixedRotation
-- @param self Self reference
-- @param #boolean fixedRotation fixedRotation

---
-- Function SetBullet()
-- Set bullet.
--
-- @function [parent=#RigidBody2D] SetBullet
-- @param self Self reference
-- @param #boolean bullet bullet

---
-- Function SetGravityScale()
-- Set gravity scale.
--
-- @function [parent=#RigidBody2D] SetGravityScale
-- @param self Self reference
-- @param #number gravityScale gravityScale

---
-- Function SetAwake()
-- Set awake.
--
-- @function [parent=#RigidBody2D] SetAwake
-- @param self Self reference
-- @param #boolean awake awake

---
-- Function SetLinearVelocity()
-- Set linear velocity.
--
-- @function [parent=#RigidBody2D] SetLinearVelocity
-- @param self Self reference
-- @param Vector2#Vector2 linearVelocity linearVelocity

---
-- Function SetAngularVelocity()
-- Set angular velocity.
--
-- @function [parent=#RigidBody2D] SetAngularVelocity
-- @param self Self reference
-- @param #number angularVelocity angularVelocity

---
-- Function ApplyForce()
-- Apply force.
--
-- @function [parent=#RigidBody2D] ApplyForce
-- @param self Self reference
-- @param Vector2#Vector2 force force
-- @param Vector2#Vector2 point point
-- @param #boolean wake wake

---
-- Function ApplyForceToCenter()
-- Apply force to center.
--
-- @function [parent=#RigidBody2D] ApplyForceToCenter
-- @param self Self reference
-- @param Vector2#Vector2 force force
-- @param #boolean wake wake

---
-- Function ApplyTorque()
-- Apply Torque.
--
-- @function [parent=#RigidBody2D] ApplyTorque
-- @param self Self reference
-- @param #number torque torque
-- @param #boolean wake wake

---
-- Function ApplyLinearImpulse()
-- Apply linear impulse.
--
-- @function [parent=#RigidBody2D] ApplyLinearImpulse
-- @param self Self reference
-- @param Vector2#Vector2 impulse impulse
-- @param Vector2#Vector2 point point
-- @param #boolean wake wake

---
-- Function ApplyAngularImpulse()
-- Apply angular impulse.
--
-- @function [parent=#RigidBody2D] ApplyAngularImpulse
-- @param self Self reference
-- @param #number impulse impulse
-- @param #boolean wake wake

---
-- Function GetBodyType()
--
-- @function [parent=#RigidBody2D] GetBodyType
-- @param self Self reference
-- @return BodyType2D#BodyType2D

---
-- Function GetMass()
-- Return Mass.
--
-- @function [parent=#RigidBody2D] GetMass
-- @param self Self reference
-- @return #number

---
-- Function GetInertia()
-- Return inertia.
--
-- @function [parent=#RigidBody2D] GetInertia
-- @param self Self reference
-- @return #number

---
-- Function GetMassCenter()
-- Return mass center.
--
-- @function [parent=#RigidBody2D] GetMassCenter
-- @param self Self reference
-- @return Vector2#Vector2

---
-- Function GetUseFixtureMass()
-- Return use fixture mass.
--
-- @function [parent=#RigidBody2D] GetUseFixtureMass
-- @param self Self reference
-- @return #boolean

---
-- Function GetLinearDamping()
-- Return linear damping.
--
-- @function [parent=#RigidBody2D] GetLinearDamping
-- @param self Self reference
-- @return #number

---
-- Function GetAngularDamping()
-- Return angular damping.
--
-- @function [parent=#RigidBody2D] GetAngularDamping
-- @param self Self reference
-- @return #number

---
-- Function IsAllowSleep()
-- Return allow sleep.
--
-- @function [parent=#RigidBody2D] IsAllowSleep
-- @param self Self reference
-- @return #boolean

---
-- Function IsFixedRotation()
-- Return fixed rotation.
--
-- @function [parent=#RigidBody2D] IsFixedRotation
-- @param self Self reference
-- @return #boolean

---
-- Function IsBullet()
-- Return bullet.
--
-- @function [parent=#RigidBody2D] IsBullet
-- @param self Self reference
-- @return #boolean

---
-- Function GetGravityScale()
-- Return gravity scale.
--
-- @function [parent=#RigidBody2D] GetGravityScale
-- @param self Self reference
-- @return #number

---
-- Function IsAwake()
-- Return awake.
--
-- @function [parent=#RigidBody2D] IsAwake
-- @param self Self reference
-- @return #boolean

---
-- Function GetLinearVelocity()
-- Return linear velocity.
--
-- @function [parent=#RigidBody2D] GetLinearVelocity
-- @param self Self reference
-- @return Vector2#Vector2

---
-- Function GetAngularVelocity()
-- Return angular velocity.
--
-- @function [parent=#RigidBody2D] GetAngularVelocity
-- @param self Self reference
-- @return #number

---
-- Field bodyType
--
-- @field [parent=#RigidBody2D] BodyType2D#BodyType2D bodyType

---
-- Field mass
--
-- @field [parent=#RigidBody2D] #number mass

---
-- Field inertia
--
-- @field [parent=#RigidBody2D] #number inertia

---
-- Field massCenter
--
-- @field [parent=#RigidBody2D] Vector2#Vector2 massCenter

---
-- Field useFixtureMass
--
-- @field [parent=#RigidBody2D] #boolean useFixtureMass

---
-- Field linearDamping
--
-- @field [parent=#RigidBody2D] #number linearDamping

---
-- Field angularDamping
--
-- @field [parent=#RigidBody2D] #number angularDamping

---
-- Field allowSleep
--
-- @field [parent=#RigidBody2D] #boolean allowSleep

---
-- Field fixedRotation
--
-- @field [parent=#RigidBody2D] #boolean fixedRotation

---
-- Field bullet
--
-- @field [parent=#RigidBody2D] #boolean bullet

---
-- Field gravityScale
--
-- @field [parent=#RigidBody2D] #number gravityScale

---
-- Field awake
--
-- @field [parent=#RigidBody2D] #boolean awake

---
-- Field linearVelocity
--
-- @field [parent=#RigidBody2D] Vector2#Vector2 linearVelocity

---
-- Field angularVelocity
--
-- @field [parent=#RigidBody2D] #number angularVelocity


return nil
