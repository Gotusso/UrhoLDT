---
-- Module Vector4
--
-- @module Vector4

---
-- Function Vector4
--
-- @function [parent=#Vector4] Vector4

---
-- Function new
--
-- @function [parent=#Vector4] new
-- @return Vector4#Vector4

---
-- Function Vector4
--
-- @function [parent=#Vector4] Vector4
-- @param Vector4#Vector4 vectorvector

---
-- Function new
--
-- @function [parent=#Vector4] new
-- @param Vector4#Vector4 vectorvector
-- @return Vector4#Vector4

---
-- Function Vector4
--
-- @function [parent=#Vector4] Vector4
-- @param Vector3#Vector3 vectorvector
-- @param #number ww

---
-- Function new
--
-- @function [parent=#Vector4] new
-- @param Vector3#Vector3 vectorvector
-- @param #number ww
-- @return Vector4#Vector4

---
-- Function Vector4
--
-- @function [parent=#Vector4] Vector4
-- @param #number xx
-- @param #number yy
-- @param #number zz
-- @param #number ww

---
-- Function new
--
-- @function [parent=#Vector4] new
-- @param #number xx
-- @param #number yy
-- @param #number zz
-- @param #number ww
-- @return Vector4#Vector4

---
-- Function delete
--
-- @function [parent=#Vector4] delete

---
-- Function operator==
--
-- @function [parent=#Vector4] operator==
-- @param Vector4#Vector4 rhsrhs
-- @return #boolean

---
-- Function operator+
--
-- @function [parent=#Vector4] operator+
-- @param Vector4#Vector4 rhsrhs
-- @return Vector4#Vector4

---
-- Function operator-
--
-- @function [parent=#Vector4] operator-
-- @return Vector4#Vector4

---
-- Function operator-
--
-- @function [parent=#Vector4] operator-
-- @param Vector4#Vector4 rhsrhs
-- @return Vector4#Vector4

---
-- Function operator*
--
-- @function [parent=#Vector4] operator*
-- @param #number rhsrhs
-- @return Vector4#Vector4

---
-- Function operator*
--
-- @function [parent=#Vector4] operator*
-- @param Vector4#Vector4 rhsrhs
-- @return Vector4#Vector4

---
-- Function operator/
--
-- @function [parent=#Vector4] operator/
-- @param #number rhsrhs
-- @return Vector4#Vector4

---
-- Function operator/
--
-- @function [parent=#Vector4] operator/
-- @param Vector4#Vector4 rhsrhs
-- @return Vector4#Vector4

---
-- Function operator/
--
-- @function [parent=#Vector4] operator/
-- @param Vector4#Vector4 rhsrhs
-- @return Vector4#Vector4

---
-- Function DotProduct
--
-- @function [parent=#Vector4] DotProduct
-- @param Vector4#Vector4 rhsrhs
-- @return #number

---
-- Function AbsDotProduct
--
-- @function [parent=#Vector4] AbsDotProduct
-- @param Vector4#Vector4 rhsrhs
-- @return #number

---
-- Function Abs
--
-- @function [parent=#Vector4] Abs
-- @return Vector4#Vector4

---
-- Function Lerp
--
-- @function [parent=#Vector4] Lerp
-- @param Vector4#Vector4 rhsrhs
-- @param #number tt
-- @return Vector4#Vector4

---
-- Function Equals
--
-- @function [parent=#Vector4] Equals
-- @param Vector4#Vector4 rhsrhs
-- @return #boolean

---
-- Function ToString
--
-- @function [parent=#Vector4] ToString
-- @return #string

---
-- Field x
--
-- @field [parent=#Vector4] #number x

---
-- Field y
--
-- @field [parent=#Vector4] #number y

---
-- Field z
--
-- @field [parent=#Vector4] #number z

---
-- Field w
--
-- @field [parent=#Vector4] #number w

---
-- Field ZERO
--
-- @field [parent=#Vector4] Vector4#Vector4 ZERO

---
-- Field ONE
--
-- @field [parent=#Vector4] Vector4#Vector4 ONE


return nil
