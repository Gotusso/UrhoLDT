---
-- Module Vector4
-- Generated on 2014-03-13
--
-- @module Vector4

---
-- Function Vector4
--
-- @function [parent=#Vector4] Vector4
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#Vector4] new
-- @param self Self reference
-- @return Vector4#Vector4

---
-- Function Vector4
--
-- @function [parent=#Vector4] Vector4
-- @param self Self reference
-- @param Vector4#Vector4 vector vector

---
-- Function new
--
-- @function [parent=#Vector4] new
-- @param self Self reference
-- @param Vector4#Vector4 vector vector
-- @return Vector4#Vector4

---
-- Function Vector4
--
-- @function [parent=#Vector4] Vector4
-- @param self Self reference
-- @param Vector3#Vector3 vector vector
-- @param #number w w

---
-- Function new
--
-- @function [parent=#Vector4] new
-- @param self Self reference
-- @param Vector3#Vector3 vector vector
-- @param #number w w
-- @return Vector4#Vector4

---
-- Function Vector4
--
-- @function [parent=#Vector4] Vector4
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z
-- @param #number w w

---
-- Function new
--
-- @function [parent=#Vector4] new
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z
-- @param #number w w
-- @return Vector4#Vector4

---
-- Function delete
--
-- @function [parent=#Vector4] delete
-- @param self Self reference

---
-- Function operator==
--
-- @function [parent=#Vector4] operator==
-- @param self Self reference
-- @param Vector4#Vector4 rhs rhs
-- @return #boolean

---
-- Function operator+
--
-- @function [parent=#Vector4] operator+
-- @param self Self reference
-- @param Vector4#Vector4 rhs rhs
-- @return Vector4#Vector4

---
-- Function operator-
--
-- @function [parent=#Vector4] operator-
-- @param self Self reference
-- @return Vector4#Vector4

---
-- Function operator-
--
-- @function [parent=#Vector4] operator-
-- @param self Self reference
-- @param Vector4#Vector4 rhs rhs
-- @return Vector4#Vector4

---
-- Function operator*
--
-- @function [parent=#Vector4] operator*
-- @param self Self reference
-- @param #number rhs rhs
-- @return Vector4#Vector4

---
-- Function operator*
--
-- @function [parent=#Vector4] operator*
-- @param self Self reference
-- @param Vector4#Vector4 rhs rhs
-- @return Vector4#Vector4

---
-- Function operator/
--
-- @function [parent=#Vector4] operator/
-- @param self Self reference
-- @param #number rhs rhs
-- @return Vector4#Vector4

---
-- Function operator/
--
-- @function [parent=#Vector4] operator/
-- @param self Self reference
-- @param Vector4#Vector4 rhs rhs
-- @return Vector4#Vector4

---
-- Function operator/
--
-- @function [parent=#Vector4] operator/
-- @param self Self reference
-- @param Vector4#Vector4 rhs rhs
-- @return Vector4#Vector4

---
-- Function DotProduct
--
-- @function [parent=#Vector4] DotProduct
-- @param self Self reference
-- @param Vector4#Vector4 rhs rhs
-- @return #number

---
-- Function AbsDotProduct
--
-- @function [parent=#Vector4] AbsDotProduct
-- @param self Self reference
-- @param Vector4#Vector4 rhs rhs
-- @return #number

---
-- Function Abs
--
-- @function [parent=#Vector4] Abs
-- @param self Self reference
-- @return Vector4#Vector4

---
-- Function Lerp
--
-- @function [parent=#Vector4] Lerp
-- @param self Self reference
-- @param Vector4#Vector4 rhs rhs
-- @param #number t t
-- @return Vector4#Vector4

---
-- Function Equals
--
-- @function [parent=#Vector4] Equals
-- @param self Self reference
-- @param Vector4#Vector4 rhs rhs
-- @return #boolean

---
-- Function ToString
--
-- @function [parent=#Vector4] ToString
-- @param self Self reference
-- @return #string

---
-- Field x
--
-- @field [parent=#Vector4] #number x

---
-- Field y
--
-- @field [parent=#Vector4] #number y

---
-- Field z
--
-- @field [parent=#Vector4] #number z

---
-- Field w
--
-- @field [parent=#Vector4] #number w

---
-- Field ZERO
--
-- @field [parent=#Vector4] Vector4#Vector4 ZERO

---
-- Field ONE
--
-- @field [parent=#Vector4] Vector4#Vector4 ONE


return nil
