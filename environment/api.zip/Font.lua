---
-- Module Font
-- extends Resource
--
-- @module Font

---
-- Function Load
--
-- @function [parent=#Font] Load
-- @param Deserializer#Deserializer sourcesource
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#Font] Save
-- @param Serializer#Serializer destdest
-- @return #boolean

---
-- Function Load
--
-- @function [parent=#Font] Load
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#Font] Save
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function GetName
--
-- @function [parent=#Font] GetName
-- @return const String#const String

---
-- Function GetNameHash
--
-- @function [parent=#Font] GetNameHash
-- @return StringHash#StringHash

---
-- Function GetMemoryUse
--
-- @function [parent=#Font] GetMemoryUse
-- @return #number

---
-- Field name (Read only)
--
-- @field [parent=#Font] #string name

---
-- Field nameHash (Read only)
--
-- @field [parent=#Font] StringHash#StringHash nameHash

---
-- Field memoryUse (Read only)
--
-- @field [parent=#Font] #number memoryUse


return nil
