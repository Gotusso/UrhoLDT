---
-- Module Font
-- Module Font extends Resource
-- Generated on 2014-03-13
--
-- @module Font

---
-- Function Load
--
-- @function [parent=#Font] Load
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#Font] Save
-- @param self Self reference
-- @param Serializer#Serializer dest dest
-- @return #boolean

---
-- Function Load
--
-- @function [parent=#Font] Load
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#Font] Save
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function GetName
--
-- @function [parent=#Font] GetName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetNameHash
--
-- @function [parent=#Font] GetNameHash
-- @param self Self reference
-- @return StringHash#StringHash

---
-- Function GetMemoryUse
--
-- @function [parent=#Font] GetMemoryUse
-- @param self Self reference
-- @return #number

---
-- Field name (Read only)
--
-- @field [parent=#Font] #string name

---
-- Field nameHash (Read only)
--
-- @field [parent=#Font] StringHash#StringHash nameHash

---
-- Field memoryUse (Read only)
--
-- @field [parent=#Font] #number memoryUse


return nil
