---
-- Enumeration CullMode
--
-- @module CullMode

---
-- Enumeration value CULL_NONE
--
-- @field [parent=#CullMode] #number CULL_NONE

---
-- Enumeration value CULL_CCW
--
-- @field [parent=#CullMode] #number CULL_CCW

---
-- Enumeration value CULL_CW
--
-- @field [parent=#CullMode] #number CULL_CW

---
-- Enumeration value MAX_CULLMODES
--
-- @field [parent=#CullMode] #number MAX_CULLMODES


return nil
