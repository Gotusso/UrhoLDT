---
-- Module CollisionShape2D
-- Module CollisionShape2D extends Component
-- Generated on 2014-05-31
--
-- @module CollisionShape2D

---
-- Function SetTrigger()
-- Set trigger.
--
-- @function [parent=#CollisionShape2D] SetTrigger
-- @param self Self reference
-- @param #boolean trigger trigger

---
-- Function SetCategoryBits()
-- Set filter category bits.
--
-- @function [parent=#CollisionShape2D] SetCategoryBits
-- @param self Self reference
-- @param #number categoryBits categoryBits

---
-- Function SetMaskBits()
-- Set filter mask bits.
--
-- @function [parent=#CollisionShape2D] SetMaskBits
-- @param self Self reference
-- @param #number maskBits maskBits

---
-- Function SetGroupIndex()
-- Set filter group index.
--
-- @function [parent=#CollisionShape2D] SetGroupIndex
-- @param self Self reference
-- @param #number groupIndex groupIndex

---
-- Function SetDensity()
-- Set density.
--
-- @function [parent=#CollisionShape2D] SetDensity
-- @param self Self reference
-- @param #number density density

---
-- Function SetFriction()
-- Set friction.
--
-- @function [parent=#CollisionShape2D] SetFriction
-- @param self Self reference
-- @param #number friction friction

---
-- Function SetRestitution()
-- Set restitution .
--
-- @function [parent=#CollisionShape2D] SetRestitution
-- @param self Self reference
-- @param #number restitution restitution

---
-- Function IsTrigger()
-- Return trigger.
--
-- @function [parent=#CollisionShape2D] IsTrigger
-- @param self Self reference
-- @return #boolean

---
-- Function GetCategoryBits()
-- Return filter category bits.
--
-- @function [parent=#CollisionShape2D] GetCategoryBits
-- @param self Self reference
-- @return #number

---
-- Function GetMaskBits()
-- Return filter mask bits.
--
-- @function [parent=#CollisionShape2D] GetMaskBits
-- @param self Self reference
-- @return #number

---
-- Function GetGroupIndex()
-- Return filter group index.
--
-- @function [parent=#CollisionShape2D] GetGroupIndex
-- @param self Self reference
-- @return #number

---
-- Function GetDensity()
-- Return density.
--
-- @function [parent=#CollisionShape2D] GetDensity
-- @param self Self reference
-- @return #number

---
-- Function GetFriction()
-- Return friction.
--
-- @function [parent=#CollisionShape2D] GetFriction
-- @param self Self reference
-- @return #number

---
-- Function GetRestitution()
-- Return restitution.
--
-- @function [parent=#CollisionShape2D] GetRestitution
-- @param self Self reference
-- @return #number

---
-- Function GetMass()
-- Return mass.
--
-- @function [parent=#CollisionShape2D] GetMass
-- @param self Self reference
-- @return #number

---
-- Function GetInertia()
-- Return inertia.
--
-- @function [parent=#CollisionShape2D] GetInertia
-- @param self Self reference
-- @return #number

---
-- Function GetMassCenter()
-- Return mass center.
--
-- @function [parent=#CollisionShape2D] GetMassCenter
-- @param self Self reference
-- @return Vector2#Vector2

---
-- Field trigger
--
-- @field [parent=#CollisionShape2D] #boolean trigger

---
-- Field categoryBits
--
-- @field [parent=#CollisionShape2D] #number categoryBits

---
-- Field maskBits
--
-- @field [parent=#CollisionShape2D] #number maskBits

---
-- Field groupIndex
--
-- @field [parent=#CollisionShape2D] #number groupIndex

---
-- Field density
--
-- @field [parent=#CollisionShape2D] #number density

---
-- Field friction
--
-- @field [parent=#CollisionShape2D] #number friction

---
-- Field restitution
--
-- @field [parent=#CollisionShape2D] #number restitution

---
-- Field mass (Read only)
--
-- @field [parent=#CollisionShape2D] #number mass

---
-- Field inertia (Read only)
--
-- @field [parent=#CollisionShape2D] #number inertia

---
-- Field massCenter (Read only)
--
-- @field [parent=#CollisionShape2D] Vector2#Vector2 massCenter


return nil
