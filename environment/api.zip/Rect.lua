---
-- Module Rect
-- Generated on 2014-03-13
--
-- @module Rect

---
-- Function Rect
--
-- @function [parent=#Rect] Rect
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#Rect] new
-- @param self Self reference
-- @return Rect#Rect

---
-- Function Rect
--
-- @function [parent=#Rect] Rect
-- @param self Self reference
-- @param Rect#Rect rect rect

---
-- Function new
--
-- @function [parent=#Rect] new
-- @param self Self reference
-- @param Rect#Rect rect rect
-- @return Rect#Rect

---
-- Function Rect
--
-- @function [parent=#Rect] Rect
-- @param self Self reference
-- @param Vector2#Vector2 min min
-- @param Vector2#Vector2 max max

---
-- Function new
--
-- @function [parent=#Rect] new
-- @param self Self reference
-- @param Vector2#Vector2 min min
-- @param Vector2#Vector2 max max
-- @return Rect#Rect

---
-- Function Rect
--
-- @function [parent=#Rect] Rect
-- @param self Self reference
-- @param #number left left
-- @param #number top top
-- @param #number right right
-- @param #number bottom bottom

---
-- Function new
--
-- @function [parent=#Rect] new
-- @param self Self reference
-- @param #number left left
-- @param #number top top
-- @param #number right right
-- @param #number bottom bottom
-- @return Rect#Rect

---
-- Function Rect
--
-- @function [parent=#Rect] Rect
-- @param self Self reference
-- @param Vector4#Vector4 vector vector

---
-- Function new
--
-- @function [parent=#Rect] new
-- @param self Self reference
-- @param Vector4#Vector4 vector vector
-- @return Rect#Rect

---
-- Function delete
--
-- @function [parent=#Rect] delete
-- @param self Self reference

---
-- Function operator==
--
-- @function [parent=#Rect] operator==
-- @param self Self reference
-- @param Rect#Rect rhs rhs
-- @return #boolean

---
-- Function Define
--
-- @function [parent=#Rect] Define
-- @param self Self reference
-- @param Rect#Rect rect rect

---
-- Function Define
--
-- @function [parent=#Rect] Define
-- @param self Self reference
-- @param Vector2#Vector2 min min
-- @param Vector2#Vector2 max max

---
-- Function Define
--
-- @function [parent=#Rect] Define
-- @param self Self reference
-- @param Vector2#Vector2 point point

---
-- Function Merge
--
-- @function [parent=#Rect] Merge
-- @param self Self reference
-- @param Vector2#Vector2 point point

---
-- Function Merge
--
-- @function [parent=#Rect] Merge
-- @param self Self reference
-- @param Rect#Rect rect rect

---
-- Function Clear
--
-- @function [parent=#Rect] Clear
-- @param self Self reference

---
-- Function Clip
--
-- @function [parent=#Rect] Clip
-- @param self Self reference
-- @param Rect#Rect rect rect

---
-- Function Center
--
-- @function [parent=#Rect] Center
-- @param self Self reference
-- @return Vector2#Vector2

---
-- Function Size
--
-- @function [parent=#Rect] Size
-- @param self Self reference
-- @return Vector2#Vector2

---
-- Function HalfSize
--
-- @function [parent=#Rect] HalfSize
-- @param self Self reference
-- @return Vector2#Vector2

---
-- Function Equals
--
-- @function [parent=#Rect] Equals
-- @param self Self reference
-- @param Rect#Rect rhs rhs
-- @return #boolean

---
-- Function IsInside
--
-- @function [parent=#Rect] IsInside
-- @param self Self reference
-- @param Vector2#Vector2 point point
-- @return Intersection#Intersection

---
-- Function ToVector4
--
-- @function [parent=#Rect] ToVector4
-- @param self Self reference
-- @return Vector4#Vector4

---
-- Function ToString
--
-- @function [parent=#Rect] ToString
-- @param self Self reference
-- @return #string

---
-- Field min
--
-- @field [parent=#Rect] Vector2#Vector2 min

---
-- Field max
--
-- @field [parent=#Rect] Vector2#Vector2 max

---
-- Field FULL
--
-- @field [parent=#Rect] Rect#Rect FULL

---
-- Field POSITIVE
--
-- @field [parent=#Rect] Rect#Rect POSITIVE

---
-- Field ZERO
--
-- @field [parent=#Rect] Rect#Rect ZERO

---
-- Field center (Read only)
--
-- @field [parent=#Rect] Vector2#Vector2 center

---
-- Field size (Read only)
--
-- @field [parent=#Rect] Vector2#Vector2 size

---
-- Field halfSize (Read only)
--
-- @field [parent=#Rect] Vector2#Vector2 halfSize


return nil
