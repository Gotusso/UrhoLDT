---
-- Module Rect
--
-- @module Rect

---
-- Function Rect
--
-- @function [parent=#Rect] Rect

---
-- Function new
--
-- @function [parent=#Rect] new
-- @return Rect#Rect

---
-- Function Rect
--
-- @function [parent=#Rect] Rect
-- @param Rect#Rect rectrect

---
-- Function new
--
-- @function [parent=#Rect] new
-- @param Rect#Rect rectrect
-- @return Rect#Rect

---
-- Function Rect
--
-- @function [parent=#Rect] Rect
-- @param Vector2#Vector2 minmin
-- @param Vector2#Vector2 maxmax

---
-- Function new
--
-- @function [parent=#Rect] new
-- @param Vector2#Vector2 minmin
-- @param Vector2#Vector2 maxmax
-- @return Rect#Rect

---
-- Function Rect
--
-- @function [parent=#Rect] Rect
-- @param #number leftleft
-- @param #number toptop
-- @param #number rightright
-- @param #number bottombottom

---
-- Function new
--
-- @function [parent=#Rect] new
-- @param #number leftleft
-- @param #number toptop
-- @param #number rightright
-- @param #number bottombottom
-- @return Rect#Rect

---
-- Function Rect
--
-- @function [parent=#Rect] Rect
-- @param Vector4#Vector4 vectorvector

---
-- Function new
--
-- @function [parent=#Rect] new
-- @param Vector4#Vector4 vectorvector
-- @return Rect#Rect

---
-- Function delete
--
-- @function [parent=#Rect] delete

---
-- Function operator==
--
-- @function [parent=#Rect] operator==
-- @param Rect#Rect rhsrhs
-- @return #boolean

---
-- Function Define
--
-- @function [parent=#Rect] Define
-- @param Rect#Rect rectrect

---
-- Function Define
--
-- @function [parent=#Rect] Define
-- @param Vector2#Vector2 minmin
-- @param Vector2#Vector2 maxmax

---
-- Function Define
--
-- @function [parent=#Rect] Define
-- @param Vector2#Vector2 pointpoint

---
-- Function Merge
--
-- @function [parent=#Rect] Merge
-- @param Vector2#Vector2 pointpoint

---
-- Function Merge
--
-- @function [parent=#Rect] Merge
-- @param Rect#Rect rectrect

---
-- Function Clear
--
-- @function [parent=#Rect] Clear

---
-- Function Clip
--
-- @function [parent=#Rect] Clip
-- @param Rect#Rect rectrect

---
-- Function Center
--
-- @function [parent=#Rect] Center
-- @return Vector2#Vector2

---
-- Function Size
--
-- @function [parent=#Rect] Size
-- @return Vector2#Vector2

---
-- Function HalfSize
--
-- @function [parent=#Rect] HalfSize
-- @return Vector2#Vector2

---
-- Function Equals
--
-- @function [parent=#Rect] Equals
-- @param Rect#Rect rhsrhs
-- @return #boolean

---
-- Function IsInside
--
-- @function [parent=#Rect] IsInside
-- @param Vector2#Vector2 pointpoint
-- @return Intersection#Intersection

---
-- Function ToVector4
--
-- @function [parent=#Rect] ToVector4
-- @return Vector4#Vector4

---
-- Function ToString
--
-- @function [parent=#Rect] ToString
-- @return #string

---
-- Field min
--
-- @field [parent=#Rect] Vector2#Vector2 min

---
-- Field max
--
-- @field [parent=#Rect] Vector2#Vector2 max

---
-- Field FULL
--
-- @field [parent=#Rect] Rect#Rect FULL

---
-- Field POSITIVE
--
-- @field [parent=#Rect] Rect#Rect POSITIVE

---
-- Field ZERO
--
-- @field [parent=#Rect] Rect#Rect ZERO

---
-- Field center (Read only)
--
-- @field [parent=#Rect] Vector2#Vector2 center

---
-- Field size (Read only)
--
-- @field [parent=#Rect] Vector2#Vector2 size

---
-- Field halfSize (Read only)
--
-- @field [parent=#Rect] Vector2#Vector2 halfSize


return nil
