---
-- Module HttpRequest
-- Module HttpRequest extends Deserializer
-- Generated on 2014-03-13
--
-- @module HttpRequest

---
-- Function GetURL
--
-- @function [parent=#HttpRequest] GetURL
-- @param self Self reference
-- @return const String#const String

---
-- Function GetVerb
--
-- @function [parent=#HttpRequest] GetVerb
-- @param self Self reference
-- @return const String#const String

---
-- Function GetError
--
-- @function [parent=#HttpRequest] GetError
-- @param self Self reference
-- @return #string

---
-- Function GetState
--
-- @function [parent=#HttpRequest] GetState
-- @param self Self reference
-- @return HttpRequestState#HttpRequestState

---
-- Function GetAvailableSize
--
-- @function [parent=#HttpRequest] GetAvailableSize
-- @param self Self reference
-- @return #number

---
-- Function IsOpen
--
-- @function [parent=#HttpRequest] IsOpen
-- @param self Self reference
-- @return #boolean

---
-- Field URL (Read only)
--
-- @field [parent=#HttpRequest] #string URL

---
-- Field verb (Read only)
--
-- @field [parent=#HttpRequest] #string verb

---
-- Field error (Read only)
--
-- @field [parent=#HttpRequest] #string error

---
-- Field state (Read only)
--
-- @field [parent=#HttpRequest] HttpRequestState#HttpRequestState state

---
-- Field availableSize (Read only)
--
-- @field [parent=#HttpRequest] #number availableSize

---
-- Field open (Read only)
--
-- @field [parent=#HttpRequest] #boolean open

---
-- Function Read
--
-- @function [parent=#HttpRequest] Read
-- @param self Self reference
-- @param #number size size
-- @return VectorBuffer#VectorBuffer

---
-- Function Seek
--
-- @function [parent=#HttpRequest] Seek
-- @param self Self reference
-- @param #number position position
-- @return #number

---
-- Function GetName
--
-- @function [parent=#HttpRequest] GetName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetChecksum
--
-- @function [parent=#HttpRequest] GetChecksum
-- @param self Self reference
-- @return #number

---
-- Function GetPosition
--
-- @function [parent=#HttpRequest] GetPosition
-- @param self Self reference
-- @return #number

---
-- Function GetSize
--
-- @function [parent=#HttpRequest] GetSize
-- @param self Self reference
-- @return #number

---
-- Function IsEof
--
-- @function [parent=#HttpRequest] IsEof
-- @param self Self reference
-- @return #boolean

---
-- Function ReadInt
--
-- @function [parent=#HttpRequest] ReadInt
-- @param self Self reference
-- @return #number

---
-- Function ReadShort
--
-- @function [parent=#HttpRequest] ReadShort
-- @param self Self reference
-- @return short#short

---
-- Function ReadByte
--
-- @function [parent=#HttpRequest] ReadByte
-- @param self Self reference
-- @return #string

---
-- Function ReadUInt
--
-- @function [parent=#HttpRequest] ReadUInt
-- @param self Self reference
-- @return #number

---
-- Function ReadUShort
--
-- @function [parent=#HttpRequest] ReadUShort
-- @param self Self reference
-- @return short#short

---
-- Function ReadUByte
--
-- @function [parent=#HttpRequest] ReadUByte
-- @param self Self reference
-- @return #string

---
-- Function ReadBool
--
-- @function [parent=#HttpRequest] ReadBool
-- @param self Self reference
-- @return #boolean

---
-- Function ReadFloat
--
-- @function [parent=#HttpRequest] ReadFloat
-- @param self Self reference
-- @return #number

---
-- Function ReadIntRect
--
-- @function [parent=#HttpRequest] ReadIntRect
-- @param self Self reference
-- @return IntRect#IntRect

---
-- Function ReadIntVector2
--
-- @function [parent=#HttpRequest] ReadIntVector2
-- @param self Self reference
-- @return IntVector2#IntVector2

---
-- Function ReadRect
--
-- @function [parent=#HttpRequest] ReadRect
-- @param self Self reference
-- @return Rect#Rect

---
-- Function ReadVector2
--
-- @function [parent=#HttpRequest] ReadVector2
-- @param self Self reference
-- @return Vector2#Vector2

---
-- Function ReadVector3
--
-- @function [parent=#HttpRequest] ReadVector3
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function ReadPackedVector3
--
-- @function [parent=#HttpRequest] ReadPackedVector3
-- @param self Self reference
-- @param #number maxAbsCoord maxAbsCoord
-- @return Vector3#Vector3

---
-- Function ReadVector4
--
-- @function [parent=#HttpRequest] ReadVector4
-- @param self Self reference
-- @return Vector4#Vector4

---
-- Function ReadQuaternion
--
-- @function [parent=#HttpRequest] ReadQuaternion
-- @param self Self reference
-- @return Quaternion#Quaternion

---
-- Function ReadPackedQuaternion
--
-- @function [parent=#HttpRequest] ReadPackedQuaternion
-- @param self Self reference
-- @return Quaternion#Quaternion

---
-- Function ReadColor
--
-- @function [parent=#HttpRequest] ReadColor
-- @param self Self reference
-- @return Color#Color

---
-- Function ReadBoundingBox
--
-- @function [parent=#HttpRequest] ReadBoundingBox
-- @param self Self reference
-- @return BoundingBox#BoundingBox

---
-- Function ReadString
--
-- @function [parent=#HttpRequest] ReadString
-- @param self Self reference
-- @return #string

---
-- Function ReadFileID
--
-- @function [parent=#HttpRequest] ReadFileID
-- @param self Self reference
-- @return #string

---
-- Function ReadStringHash
--
-- @function [parent=#HttpRequest] ReadStringHash
-- @param self Self reference
-- @return StringHash#StringHash

---
-- Function ReadShortStringHash
--
-- @function [parent=#HttpRequest] ReadShortStringHash
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function ReadBuffer
--
-- @function [parent=#HttpRequest] ReadBuffer
-- @param self Self reference
-- @return VectorBuffer#VectorBuffer

---
-- Function ReadResourceRef
--
-- @function [parent=#HttpRequest] ReadResourceRef
-- @param self Self reference
-- @return ResourceRef#ResourceRef

---
-- Function ReadResourceRefList
--
-- @function [parent=#HttpRequest] ReadResourceRefList
-- @param self Self reference
-- @return ResourceRefList#ResourceRefList

---
-- Function ReadVariant
--
-- @function [parent=#HttpRequest] ReadVariant
-- @param self Self reference
-- @return Variant#Variant

---
-- Function ReadVariant
--
-- @function [parent=#HttpRequest] ReadVariant
-- @param self Self reference
-- @param VariantType#VariantType type type
-- @return Variant#Variant

---
-- Function ReadVariantVector
--
-- @function [parent=#HttpRequest] ReadVariantVector
-- @param self Self reference
-- @return VariantVector#VariantVector

---
-- Function ReadVariantMap
--
-- @function [parent=#HttpRequest] ReadVariantMap
-- @param self Self reference
-- @return VariantMap#VariantMap

---
-- Function ReadVLE
--
-- @function [parent=#HttpRequest] ReadVLE
-- @param self Self reference
-- @return #number

---
-- Function ReadNetID
--
-- @function [parent=#HttpRequest] ReadNetID
-- @param self Self reference
-- @return #number

---
-- Function ReadLine
--
-- @function [parent=#HttpRequest] ReadLine
-- @param self Self reference
-- @return #string

---
-- Field name (Read only)
--
-- @field [parent=#HttpRequest] #string name

---
-- Field checksum (Read only)
--
-- @field [parent=#HttpRequest] #number checksum

---
-- Field position (Read only)
--
-- @field [parent=#HttpRequest] #number position

---
-- Field size (Read only)
--
-- @field [parent=#HttpRequest] #number size

---
-- Field eof (Read only)
--
-- @field [parent=#HttpRequest] #boolean eof


return nil
