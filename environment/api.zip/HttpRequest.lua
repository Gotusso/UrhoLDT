---
-- Module HttpRequest
-- Module HttpRequest extends Deserializer
-- Generated on 2014-05-31
--
-- @module HttpRequest

---
-- Function GetURL()
--
-- @function [parent=#HttpRequest] GetURL
-- @param self Self reference
-- @return const String#const String

---
-- Function GetVerb()
--
-- @function [parent=#HttpRequest] GetVerb
-- @param self Self reference
-- @return const String#const String

---
-- Function GetError()
--
-- @function [parent=#HttpRequest] GetError
-- @param self Self reference
-- @return #string

---
-- Function GetState()
--
-- @function [parent=#HttpRequest] GetState
-- @param self Self reference
-- @return HttpRequestState#HttpRequestState

---
-- Function GetAvailableSize()
--
-- @function [parent=#HttpRequest] GetAvailableSize
-- @param self Self reference
-- @return #number

---
-- Function IsOpen()
--
-- @function [parent=#HttpRequest] IsOpen
-- @param self Self reference
-- @return #boolean

---
-- Field URL (Read only)
--
-- @field [parent=#HttpRequest] #string URL

---
-- Field verb (Read only)
--
-- @field [parent=#HttpRequest] #string verb

---
-- Field error (Read only)
--
-- @field [parent=#HttpRequest] #string error

---
-- Field state (Read only)
--
-- @field [parent=#HttpRequest] HttpRequestState#HttpRequestState state

---
-- Field availableSize (Read only)
--
-- @field [parent=#HttpRequest] #number availableSize

---
-- Field open (Read only)
--
-- @field [parent=#HttpRequest] #boolean open


return nil
