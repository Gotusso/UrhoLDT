---
-- Module HttpRequest
-- Extends Deserializer
--
-- @module HttpRequest

---
-- Function GetURL
--
-- @function [parent=#HttpRequest] GetURL
-- @return const String#const String

---
-- Function GetVerb
--
-- @function [parent=#HttpRequest] GetVerb
-- @return const String#const String

---
-- Function GetError
--
-- @function [parent=#HttpRequest] GetError
-- @return #string

---
-- Function GetState
--
-- @function [parent=#HttpRequest] GetState
-- @return HttpRequestState#HttpRequestState

---
-- Function GetAvailableSize
--
-- @function [parent=#HttpRequest] GetAvailableSize
-- @return #number

---
-- Function IsOpen
--
-- @function [parent=#HttpRequest] IsOpen
-- @return #boolean

---
-- Field URL (Read only)
--
-- @field [parent=#HttpRequest] #string URL

---
-- Field verb (Read only)
--
-- @field [parent=#HttpRequest] #string verb

---
-- Field error (Read only)
--
-- @field [parent=#HttpRequest] #string error

---
-- Field state (Read only)
--
-- @field [parent=#HttpRequest] HttpRequestState#HttpRequestState state

---
-- Field availableSize (Read only)
--
-- @field [parent=#HttpRequest] #number availableSize

---
-- Field open (Read only)
--
-- @field [parent=#HttpRequest] #boolean open


return nil
