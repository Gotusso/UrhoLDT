---
-- Module Button
-- Module Button extends BorderImage
-- Generated on 2014-05-31
--
-- @module Button

---
-- Function Button()
--
-- @function [parent=#Button] Button
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#Button] new
-- @param self Self reference
-- @return Button#Button

---
-- Function delete()
--
-- @function [parent=#Button] delete
-- @param self Self reference

---
-- Function SetPressedOffset()
-- Set offset to image rectangle used when pressed.
--
-- @function [parent=#Button] SetPressedOffset
-- @param self Self reference
-- @param IntVector2#IntVector2 offset offset

---
-- Function SetPressedOffset()
-- Set offset to image rectangle used when pressed.
--
-- @function [parent=#Button] SetPressedOffset
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function SetPressedChildOffset()
-- Set offset of child elements when pressed.
--
-- @function [parent=#Button] SetPressedChildOffset
-- @param self Self reference
-- @param IntVector2#IntVector2 offset offset

---
-- Function SetPressedChildOffset()
-- Set offset of child elements when pressed.
--
-- @function [parent=#Button] SetPressedChildOffset
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function SetRepeat()
-- Set repeat properties. Rate 0 (default) disables repeat.
--
-- @function [parent=#Button] SetRepeat
-- @param self Self reference
-- @param #number delay delay
-- @param #number rate rate

---
-- Function SetRepeatDelay()
-- Set repeat delay.
--
-- @function [parent=#Button] SetRepeatDelay
-- @param self Self reference
-- @param #number delay delay

---
-- Function SetRepeatRate()
-- Set repeat rate.
--
-- @function [parent=#Button] SetRepeatRate
-- @param self Self reference
-- @param #number rate rate

---
-- Function GetPressedOffset()
-- Return pressed image offset.
--
-- @function [parent=#Button] GetPressedOffset
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetPressedChildOffset()
-- Return offset of child elements when pressed.
--
-- @function [parent=#Button] GetPressedChildOffset
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetRepeatDelay()
-- Return repeat delay.
--
-- @function [parent=#Button] GetRepeatDelay
-- @param self Self reference
-- @return #number

---
-- Function GetRepeatRate()
-- Return repeat rate.
--
-- @function [parent=#Button] GetRepeatRate
-- @param self Self reference
-- @return #number

---
-- Function IsPressed()
-- Return whether is currently pressed.
--
-- @function [parent=#Button] IsPressed
-- @param self Self reference
-- @return #boolean

---
-- Field pressedOffset
--
-- @field [parent=#Button] IntVector2#IntVector2 pressedOffset

---
-- Field pressedChildOffset
--
-- @field [parent=#Button] IntVector2#IntVector2 pressedChildOffset

---
-- Field repeatDelay
--
-- @field [parent=#Button] #number repeatDelay

---
-- Field repeatRate
--
-- @field [parent=#Button] #number repeatRate

---
-- Field pressed (Read only)
--
-- @field [parent=#Button] #boolean pressed


return nil
