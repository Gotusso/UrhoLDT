---
-- Module Button
-- Extends BorderImage
--
-- @module Button

---
-- Function Button
--
-- @function [parent=#Button] Button

---
-- Function new
--
-- @function [parent=#Button] new
-- @return Button#Button

---
-- Function delete
--
-- @function [parent=#Button] delete

---
-- Function SetPressedOffset
--
-- @function [parent=#Button] SetPressedOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetPressedOffset
--
-- @function [parent=#Button] SetPressedOffset
-- @param #number xx
-- @param #number yy

---
-- Function SetPressedChildOffset
--
-- @function [parent=#Button] SetPressedChildOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetPressedChildOffset
--
-- @function [parent=#Button] SetPressedChildOffset
-- @param #number xx
-- @param #number yy

---
-- Function SetRepeat
--
-- @function [parent=#Button] SetRepeat
-- @param #number delaydelay
-- @param #number raterate

---
-- Function SetRepeatDelay
--
-- @function [parent=#Button] SetRepeatDelay
-- @param #number delaydelay

---
-- Function SetRepeatRate
--
-- @function [parent=#Button] SetRepeatRate
-- @param #number raterate

---
-- Function GetPressedOffset
--
-- @function [parent=#Button] GetPressedOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetPressedChildOffset
--
-- @function [parent=#Button] GetPressedChildOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetRepeatDelay
--
-- @function [parent=#Button] GetRepeatDelay
-- @return #number

---
-- Function GetRepeatRate
--
-- @function [parent=#Button] GetRepeatRate
-- @return #number

---
-- Function IsPressed
--
-- @function [parent=#Button] IsPressed
-- @return #boolean

---
-- Field pressedOffset
--
-- @field [parent=#Button] IntVector2#IntVector2 pressedOffset

---
-- Field pressedChildOffset
--
-- @field [parent=#Button] IntVector2#IntVector2 pressedChildOffset

---
-- Field repeatDelay
--
-- @field [parent=#Button] #number repeatDelay

---
-- Field repeatRate
--
-- @field [parent=#Button] #number repeatRate

---
-- Field pressed (Read only)
--
-- @field [parent=#Button] #boolean pressed


return nil
