---
-- Module Button
-- extends BorderImage
--
-- @module Button

---
-- Function Button
--
-- @function [parent=#Button] Button

---
-- Function new
--
-- @function [parent=#Button] new
-- @return Button#Button

---
-- Function delete
--
-- @function [parent=#Button] delete

---
-- Function SetPressedOffset
--
-- @function [parent=#Button] SetPressedOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetPressedOffset
--
-- @function [parent=#Button] SetPressedOffset
-- @param #number xx
-- @param #number yy

---
-- Function SetPressedChildOffset
--
-- @function [parent=#Button] SetPressedChildOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetPressedChildOffset
--
-- @function [parent=#Button] SetPressedChildOffset
-- @param #number xx
-- @param #number yy

---
-- Function SetRepeat
--
-- @function [parent=#Button] SetRepeat
-- @param #number delaydelay
-- @param #number raterate

---
-- Function SetRepeatDelay
--
-- @function [parent=#Button] SetRepeatDelay
-- @param #number delaydelay

---
-- Function SetRepeatRate
--
-- @function [parent=#Button] SetRepeatRate
-- @param #number raterate

---
-- Function GetPressedOffset
--
-- @function [parent=#Button] GetPressedOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetPressedChildOffset
--
-- @function [parent=#Button] GetPressedChildOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetRepeatDelay
--
-- @function [parent=#Button] GetRepeatDelay
-- @return #number

---
-- Function GetRepeatRate
--
-- @function [parent=#Button] GetRepeatRate
-- @return #number

---
-- Function IsPressed
--
-- @function [parent=#Button] IsPressed
-- @return #boolean

---
-- Field pressedOffset
--
-- @field [parent=#Button] IntVector2#IntVector2 pressedOffset

---
-- Field pressedChildOffset
--
-- @field [parent=#Button] IntVector2#IntVector2 pressedChildOffset

---
-- Field repeatDelay
--
-- @field [parent=#Button] #number repeatDelay

---
-- Field repeatRate
--
-- @field [parent=#Button] #number repeatRate

---
-- Field pressed (Read only)
--
-- @field [parent=#Button] #boolean pressed

---
-- Function BorderImage
--
-- @function [parent=#Button] BorderImage

---
-- Function new
--
-- @function [parent=#Button] new
-- @return BorderImage#BorderImage

---
-- Function delete
--
-- @function [parent=#Button] delete

---
-- Function SetTexture
--
-- @function [parent=#Button] SetTexture
-- @param Texture#Texture texturetexture

---
-- Function SetImageRect
--
-- @function [parent=#Button] SetImageRect
-- @param IntRect#IntRect rectrect

---
-- Function SetFullImageRect
--
-- @function [parent=#Button] SetFullImageRect

---
-- Function SetBorder
--
-- @function [parent=#Button] SetBorder
-- @param IntRect#IntRect rectrect

---
-- Function SetHoverOffset
--
-- @function [parent=#Button] SetHoverOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetHoverOffset
--
-- @function [parent=#Button] SetHoverOffset
-- @param #number xx
-- @param #number yy

---
-- Function SetBlendMode
--
-- @function [parent=#Button] SetBlendMode
-- @param BlendMode#BlendMode modemode

---
-- Function SetTiled
--
-- @function [parent=#Button] SetTiled
-- @param #boolean enableenable

---
-- Function GetTexture
--
-- @function [parent=#Button] GetTexture
-- @return Texture#Texture

---
-- Function GetImageRect
--
-- @function [parent=#Button] GetImageRect
-- @return const IntRect#const IntRect

---
-- Function GetBorder
--
-- @function [parent=#Button] GetBorder
-- @return const IntRect#const IntRect

---
-- Function GetHoverOffset
--
-- @function [parent=#Button] GetHoverOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetBlendMode
--
-- @function [parent=#Button] GetBlendMode
-- @return BlendMode#BlendMode

---
-- Function IsTiled
--
-- @function [parent=#Button] IsTiled
-- @return #boolean

---
-- Field texture
--
-- @field [parent=#Button] Texture#Texture texture

---
-- Field imageRect
--
-- @field [parent=#Button] IntRect#IntRect imageRect

---
-- Field border
--
-- @field [parent=#Button] IntRect#IntRect border

---
-- Field hoverOffset
--
-- @field [parent=#Button] IntVector2#IntVector2 hoverOffset

---
-- Field blendMode
--
-- @field [parent=#Button] BlendMode#BlendMode blendMode

---
-- Field tiled
--
-- @field [parent=#Button] #boolean tiled

---
-- Function UIElement
--
-- @function [parent=#Button] UIElement

---
-- Function new
--
-- @function [parent=#Button] new
-- @return UIElement#UIElement

---
-- Function delete
--
-- @function [parent=#Button] delete

---
-- Function GetScreenPosition
--
-- @function [parent=#Button] GetScreenPosition
-- @return const IntVector2#const IntVector2

---
-- Function LoadXML
--
-- @function [parent=#Button] LoadXML
-- @param Deserializer#Deserializer sourcesource
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#Button] SaveXML
-- @param Serializer#Serializer destdest
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#Button] LoadXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#Button] SaveXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function FilterAttributes
--
-- @function [parent=#Button] FilterAttributes
-- @param XMLElement#XMLElement destdest
-- @return #boolean

---
-- Function SetName
--
-- @function [parent=#Button] SetName
-- @param #string namename

---
-- Function SetPosition
--
-- @function [parent=#Button] SetPosition
-- @param IntVector2#IntVector2 positionposition

---
-- Function SetPosition
--
-- @function [parent=#Button] SetPosition
-- @param #number xx
-- @param #number yy

---
-- Function SetSize
--
-- @function [parent=#Button] SetSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function SetSize
--
-- @function [parent=#Button] SetSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetWidth
--
-- @function [parent=#Button] SetWidth
-- @param #number widthwidth

---
-- Function SetHeight
--
-- @function [parent=#Button] SetHeight
-- @param #number heightheight

---
-- Function SetMinSize
--
-- @function [parent=#Button] SetMinSize
-- @param IntVector2#IntVector2 minSizeminSize

---
-- Function SetMinSize
--
-- @function [parent=#Button] SetMinSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetMinWidth
--
-- @function [parent=#Button] SetMinWidth
-- @param #number widthwidth

---
-- Function SetMinHeight
--
-- @function [parent=#Button] SetMinHeight
-- @param #number heightheight

---
-- Function SetMaxSize
--
-- @function [parent=#Button] SetMaxSize
-- @param IntVector2#IntVector2 maxSizemaxSize

---
-- Function SetMaxSize
--
-- @function [parent=#Button] SetMaxSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetMaxWidth
--
-- @function [parent=#Button] SetMaxWidth
-- @param #number widthwidth

---
-- Function SetMaxHeight
--
-- @function [parent=#Button] SetMaxHeight
-- @param #number heightheight

---
-- Function SetFixedSize
--
-- @function [parent=#Button] SetFixedSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function SetFixedSize
--
-- @function [parent=#Button] SetFixedSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetFixedWidth
--
-- @function [parent=#Button] SetFixedWidth
-- @param #number widthwidth

---
-- Function SetFixedHeight
--
-- @function [parent=#Button] SetFixedHeight
-- @param #number heightheight

---
-- Function SetAlignment
--
-- @function [parent=#Button] SetAlignment
-- @param HorizontalAlignment#HorizontalAlignment hAlignhAlign
-- @param VerticalAlignment#VerticalAlignment vAlignvAlign

---
-- Function SetHorizontalAlignment
--
-- @function [parent=#Button] SetHorizontalAlignment
-- @param HorizontalAlignment#HorizontalAlignment alignalign

---
-- Function SetVerticalAlignment
--
-- @function [parent=#Button] SetVerticalAlignment
-- @param VerticalAlignment#VerticalAlignment alignalign

---
-- Function SetClipBorder
--
-- @function [parent=#Button] SetClipBorder
-- @param IntRect#IntRect rectrect

---
-- Function SetColor
--
-- @function [parent=#Button] SetColor
-- @param Color#Color colorcolor

---
-- Function SetColor
--
-- @function [parent=#Button] SetColor
-- @param Corner#Corner cornercorner
-- @param Color#Color colorcolor

---
-- Function SetPriority
--
-- @function [parent=#Button] SetPriority
-- @param #number prioritypriority

---
-- Function SetOpacity
--
-- @function [parent=#Button] SetOpacity
-- @param #number opacityopacity

---
-- Function SetBringToFront
--
-- @function [parent=#Button] SetBringToFront
-- @param #boolean enableenable

---
-- Function SetBringToBack
--
-- @function [parent=#Button] SetBringToBack
-- @param #boolean enableenable

---
-- Function SetClipChildren
--
-- @function [parent=#Button] SetClipChildren
-- @param #boolean enableenable

---
-- Function SetSortChildren
--
-- @function [parent=#Button] SetSortChildren
-- @param #boolean enableenable

---
-- Function SetUseDerivedOpacity
--
-- @function [parent=#Button] SetUseDerivedOpacity
-- @param #boolean enableenable

---
-- Function SetEnabled
--
-- @function [parent=#Button] SetEnabled
-- @param #boolean enableenable

---
-- Function SetEditable
--
-- @function [parent=#Button] SetEditable
-- @param #boolean enableenable

---
-- Function SetFocus
--
-- @function [parent=#Button] SetFocus
-- @param #boolean enableenable

---
-- Function SetSelected
--
-- @function [parent=#Button] SetSelected
-- @param #boolean enableenable

---
-- Function SetVisible
--
-- @function [parent=#Button] SetVisible
-- @param #boolean enableenable

---
-- Function SetFocusMode
--
-- @function [parent=#Button] SetFocusMode
-- @param FocusMode#FocusMode modemode

---
-- Function SetDragDropMode
--
-- @function [parent=#Button] SetDragDropMode
-- @param #number modemode

---
-- Function SetStyle
--
-- @function [parent=#Button] SetStyle
-- @param #string styleNamestyleName
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetStyle
--
-- @function [parent=#Button] SetStyle
-- @param XMLElement#XMLElement elementelement
-- @return #boolean

---
-- Function SetStyleAuto
--
-- @function [parent=#Button] SetStyleAuto
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetDefaultStyle
--
-- @function [parent=#Button] SetDefaultStyle
-- @param XMLFile#XMLFile stylestyle

---
-- Function SetLayout
--
-- @function [parent=#Button] SetLayout
-- @param LayoutMode#LayoutMode modemode
-- @param #number spacingspacing

---
-- Function SetLayout
--
-- @function [parent=#Button] SetLayout
-- @param LayoutMode#LayoutMode modemode
-- @param #number spacingspacing
-- @param IntRect#IntRect borderborder

---
-- Function SetLayoutMode
--
-- @function [parent=#Button] SetLayoutMode
-- @param LayoutMode#LayoutMode modemode

---
-- Function SetLayoutSpacing
--
-- @function [parent=#Button] SetLayoutSpacing
-- @param #number spacingspacing

---
-- Function SetLayoutBorder
--
-- @function [parent=#Button] SetLayoutBorder
-- @param IntRect#IntRect borderborder

---
-- Function SetIndent
--
-- @function [parent=#Button] SetIndent
-- @param #number indentindent

---
-- Function SetIndentSpacing
--
-- @function [parent=#Button] SetIndentSpacing
-- @param #number indentSpacingindentSpacing

---
-- Function UpdateLayout
--
-- @function [parent=#Button] UpdateLayout

---
-- Function DisableLayoutUpdate
--
-- @function [parent=#Button] DisableLayoutUpdate

---
-- Function EnableLayoutUpdate
--
-- @function [parent=#Button] EnableLayoutUpdate

---
-- Function BringToFront
--
-- @function [parent=#Button] BringToFront

---
-- Function CreateChild
--
-- @function [parent=#Button] CreateChild
-- @param #string typetype
-- @param #string namename
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function AddChild
--
-- @function [parent=#Button] AddChild
-- @param UIElement#UIElement elementelement

---
-- Function InsertChild
--
-- @function [parent=#Button] InsertChild
-- @param #number indexindex
-- @param UIElement#UIElement elementelement

---
-- Function RemoveChild
--
-- @function [parent=#Button] RemoveChild
-- @param UIElement#UIElement elementelement
-- @param #number indexindex

---
-- Function RemoveChildAtIndex
--
-- @function [parent=#Button] RemoveChildAtIndex
-- @param #number indexindex

---
-- Function RemoveAllChildren
--
-- @function [parent=#Button] RemoveAllChildren

---
-- Function Remove
--
-- @function [parent=#Button] Remove

---
-- Function FindChild
--
-- @function [parent=#Button] FindChild
-- @param UIElement#UIElement elementelement
-- @return #number

---
-- Function SetParent
--
-- @function [parent=#Button] SetParent
-- @param UIElement#UIElement parentparent
-- @param #number indexindex

---
-- Function SetVar
--
-- @function [parent=#Button] SetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @param Variant#Variant valuevalue

---
-- Function SetInternal
--
-- @function [parent=#Button] SetInternal
-- @param #boolean enableenable

---
-- Function SetTraversalMode
--
-- @function [parent=#Button] SetTraversalMode
-- @param TraversalMode#TraversalMode traversalModetraversalMode

---
-- Function SetElementEventSender
--
-- @function [parent=#Button] SetElementEventSender
-- @param #boolean flagflag

---
-- Function GetName
--
-- @function [parent=#Button] GetName
-- @return const String#const String

---
-- Function GetPosition
--
-- @function [parent=#Button] GetPosition
-- @return const IntVector2#const IntVector2

---
-- Function GetSize
--
-- @function [parent=#Button] GetSize
-- @return const IntVector2#const IntVector2

---
-- Function GetWidth
--
-- @function [parent=#Button] GetWidth
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#Button] GetHeight
-- @return #number

---
-- Function GetMinSize
--
-- @function [parent=#Button] GetMinSize
-- @return const IntVector2#const IntVector2

---
-- Function GetMinWidth
--
-- @function [parent=#Button] GetMinWidth
-- @return #number

---
-- Function GetMinHeight
--
-- @function [parent=#Button] GetMinHeight
-- @return #number

---
-- Function GetMaxSize
--
-- @function [parent=#Button] GetMaxSize
-- @return const IntVector2#const IntVector2

---
-- Function GetMaxWidth
--
-- @function [parent=#Button] GetMaxWidth
-- @return #number

---
-- Function GetMaxHeight
--
-- @function [parent=#Button] GetMaxHeight
-- @return #number

---
-- Function IsFixedSize
--
-- @function [parent=#Button] IsFixedSize
-- @return #boolean

---
-- Function IsFixedWidth
--
-- @function [parent=#Button] IsFixedWidth
-- @return #boolean

---
-- Function IsFixedHeight
--
-- @function [parent=#Button] IsFixedHeight
-- @return #boolean

---
-- Function GetChildOffset
--
-- @function [parent=#Button] GetChildOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetHorizontalAlignment
--
-- @function [parent=#Button] GetHorizontalAlignment
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetVerticalAlignment
--
-- @function [parent=#Button] GetVerticalAlignment
-- @return VerticalAlignment#VerticalAlignment

---
-- Function GetClipBorder
--
-- @function [parent=#Button] GetClipBorder
-- @return const IntRect#const IntRect

---
-- Function GetColor
--
-- @function [parent=#Button] GetColor
-- @param Corner#Corner cornercorner
-- @return const Color#const Color

---
-- Function GetPriority
--
-- @function [parent=#Button] GetPriority
-- @return #number

---
-- Function GetOpacity
--
-- @function [parent=#Button] GetOpacity
-- @return #number

---
-- Function GetDerivedOpacity
--
-- @function [parent=#Button] GetDerivedOpacity
-- @return #number

---
-- Function GetBringToFront
--
-- @function [parent=#Button] GetBringToFront
-- @return #boolean

---
-- Function GetBringToBack
--
-- @function [parent=#Button] GetBringToBack
-- @return #boolean

---
-- Function GetClipChildren
--
-- @function [parent=#Button] GetClipChildren
-- @return #boolean

---
-- Function GetSortChildren
--
-- @function [parent=#Button] GetSortChildren
-- @return #boolean

---
-- Function GetUseDerivedOpacity
--
-- @function [parent=#Button] GetUseDerivedOpacity
-- @return #boolean

---
-- Function HasFocus
--
-- @function [parent=#Button] HasFocus
-- @return #boolean

---
-- Function IsEnabled
--
-- @function [parent=#Button] IsEnabled
-- @return #boolean

---
-- Function IsEditable
--
-- @function [parent=#Button] IsEditable
-- @return #boolean

---
-- Function IsSelected
--
-- @function [parent=#Button] IsSelected
-- @return #boolean

---
-- Function IsVisible
--
-- @function [parent=#Button] IsVisible
-- @return #boolean

---
-- Function IsHovering
--
-- @function [parent=#Button] IsHovering
-- @return #boolean

---
-- Function IsInternal
--
-- @function [parent=#Button] IsInternal
-- @return #boolean

---
-- Function HasColorGradient
--
-- @function [parent=#Button] HasColorGradient
-- @return #boolean

---
-- Function GetFocusMode
--
-- @function [parent=#Button] GetFocusMode
-- @return FocusMode#FocusMode

---
-- Function GetDragDropMode
--
-- @function [parent=#Button] GetDragDropMode
-- @return #number

---
-- Function GetAppliedStyle
--
-- @function [parent=#Button] GetAppliedStyle
-- @return const String#const String

---
-- Function GetDefaultStyle
--
-- @function [parent=#Button] GetDefaultStyle
-- @param #boolean recursiveUprecursiveUp
-- @return XMLFile#XMLFile

---
-- Function GetLayoutMode
--
-- @function [parent=#Button] GetLayoutMode
-- @return LayoutMode#LayoutMode

---
-- Function GetLayoutSpacing
--
-- @function [parent=#Button] GetLayoutSpacing
-- @return #number

---
-- Function GetLayoutBorder
--
-- @function [parent=#Button] GetLayoutBorder
-- @return const IntRect#const IntRect

---
-- Function GetNumChildren
--
-- @function [parent=#Button] GetNumChildren
-- @param #boolean recursiverecursive
-- @return #number

---
-- Function GetChild
--
-- @function [parent=#Button] GetChild
-- @param #string namename
-- @param #boolean recursiverecursive
-- @return UIElement#UIElement

---
-- Function GetChild
--
-- @function [parent=#Button] GetChild
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function GetParent
--
-- @function [parent=#Button] GetParent
-- @return UIElement#UIElement

---
-- Function GetRoot
--
-- @function [parent=#Button] GetRoot
-- @return UIElement#UIElement

---
-- Function GetDerivedColor
--
-- @function [parent=#Button] GetDerivedColor
-- @return const Color#const Color

---
-- Function GetVar
--
-- @function [parent=#Button] GetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @return const Variant#const Variant

---
-- Function GetVars
--
-- @function [parent=#Button] GetVars
-- @return const VariantMap#const VariantMap

---
-- Function ScreenToElement
--
-- @function [parent=#Button] ScreenToElement
-- @param IntVector2#IntVector2 screenPositionscreenPosition
-- @return IntVector2#IntVector2

---
-- Function ElementToScreen
--
-- @function [parent=#Button] ElementToScreen
-- @param IntVector2#IntVector2 positionposition
-- @return IntVector2#IntVector2

---
-- Function IsInside
--
-- @function [parent=#Button] IsInside
-- @param IntVector2#IntVector2 positionposition
-- @param #boolean isScreenisScreen
-- @return #boolean

---
-- Function IsInsideCombined
--
-- @function [parent=#Button] IsInsideCombined
-- @param IntVector2#IntVector2 positionposition
-- @param #boolean isScreenisScreen
-- @return #boolean

---
-- Function GetCombinedScreenRect
--
-- @function [parent=#Button] GetCombinedScreenRect
-- @return IntRect#IntRect

---
-- Function SortChildren
--
-- @function [parent=#Button] SortChildren

---
-- Function GetLayoutMinSize
--
-- @function [parent=#Button] GetLayoutMinSize
-- @return #number

---
-- Function GetIndent
--
-- @function [parent=#Button] GetIndent
-- @return #number

---
-- Function GetIndentSpacing
--
-- @function [parent=#Button] GetIndentSpacing
-- @return #number

---
-- Function GetIndentWidth
--
-- @function [parent=#Button] GetIndentWidth
-- @return #number

---
-- Function SetChildOffset
--
-- @function [parent=#Button] SetChildOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetHovering
--
-- @function [parent=#Button] SetHovering
-- @param #boolean enableenable

---
-- Function GetColor
--
-- @function [parent=#Button] GetColor
-- @return const Color#const Color

---
-- Function GetTraversalMode
--
-- @function [parent=#Button] GetTraversalMode
-- @return TraversalMode#TraversalMode

---
-- Function IsElementEventSender
--
-- @function [parent=#Button] IsElementEventSender
-- @return #boolean

---
-- Function GetElementEventSender
--
-- @function [parent=#Button] GetElementEventSender
-- @return UIElement#UIElement

---
-- Field screenPosition (Read only)
--
-- @field [parent=#Button] IntVector2#IntVector2 screenPosition

---
-- Field name
--
-- @field [parent=#Button] #string name

---
-- Field position
--
-- @field [parent=#Button] IntVector2#IntVector2 position

---
-- Field size
--
-- @field [parent=#Button] IntVector2#IntVector2 size

---
-- Field width
--
-- @field [parent=#Button] #number width

---
-- Field height
--
-- @field [parent=#Button] #number height

---
-- Field minSize
--
-- @field [parent=#Button] IntVector2#IntVector2 minSize

---
-- Field minWidth
--
-- @field [parent=#Button] #number minWidth

---
-- Field minHeight
--
-- @field [parent=#Button] #number minHeight

---
-- Field maxSize
--
-- @field [parent=#Button] IntVector2#IntVector2 maxSize

---
-- Field maxWidth
--
-- @field [parent=#Button] #number maxWidth

---
-- Field maxHeight
--
-- @field [parent=#Button] #number maxHeight

---
-- Field fixedSize (Read only)
--
-- @field [parent=#Button] #boolean fixedSize

---
-- Field fixedWidth (Read only)
--
-- @field [parent=#Button] #boolean fixedWidth

---
-- Field fixedHeight (Read only)
--
-- @field [parent=#Button] #boolean fixedHeight

---
-- Field childOffset
--
-- @field [parent=#Button] IntVector2#IntVector2 childOffset

---
-- Field horizontalAlignment
--
-- @field [parent=#Button] HorizontalAlignment#HorizontalAlignment horizontalAlignment

---
-- Field verticalAlignment
--
-- @field [parent=#Button] VerticalAlignment#VerticalAlignment verticalAlignment

---
-- Field clipBorder
--
-- @field [parent=#Button] IntRect#IntRect clipBorder

---
-- Field color
--
-- @field [parent=#Button] Color#Color color

---
-- Field priority
--
-- @field [parent=#Button] #number priority

---
-- Field opacity
--
-- @field [parent=#Button] #number opacity

---
-- Field derivedOpacity (Read only)
--
-- @field [parent=#Button] #number derivedOpacity

---
-- Field bringToFront
--
-- @field [parent=#Button] #boolean bringToFront

---
-- Field bringToBack
--
-- @field [parent=#Button] #boolean bringToBack

---
-- Field clipChildren
--
-- @field [parent=#Button] #boolean clipChildren

---
-- Field sortChildren
--
-- @field [parent=#Button] #boolean sortChildren

---
-- Field useDerivedOpacity
--
-- @field [parent=#Button] #boolean useDerivedOpacity

---
-- Field focus
--
-- @field [parent=#Button] #boolean focus

---
-- Field enabled
--
-- @field [parent=#Button] #boolean enabled

---
-- Field editable
--
-- @field [parent=#Button] #boolean editable

---
-- Field selected
--
-- @field [parent=#Button] #boolean selected

---
-- Field visible
--
-- @field [parent=#Button] #boolean visible

---
-- Field hovering
--
-- @field [parent=#Button] #boolean hovering

---
-- Field internal
--
-- @field [parent=#Button] #boolean internal

---
-- Field colorGradient (Read only)
--
-- @field [parent=#Button] #boolean colorGradient

---
-- Field focusMode
--
-- @field [parent=#Button] FocusMode#FocusMode focusMode

---
-- Field dragDropMode
--
-- @field [parent=#Button] #number dragDropMode

---
-- Field style
--
-- @field [parent=#Button] #string style

---
-- Field defaultStyle
--
-- @field [parent=#Button] XMLFile#XMLFile defaultStyle

---
-- Field layoutMode
--
-- @field [parent=#Button] LayoutMode#LayoutMode layoutMode

---
-- Field layoutSpacing
--
-- @field [parent=#Button] #number layoutSpacing

---
-- Field layoutBorder
--
-- @field [parent=#Button] IntRect#IntRect layoutBorder

---
-- Field numChildren (Read only)
--
-- @field [parent=#Button] #number numChildren

---
-- Field parent
--
-- @field [parent=#Button] UIElement#UIElement parent

---
-- Field root (Read only)
--
-- @field [parent=#Button] UIElement#UIElement root

---
-- Field derivedColor (Read only)
--
-- @field [parent=#Button] Color#Color derivedColor

---
-- Field combinedScreenRect (Read only)
--
-- @field [parent=#Button] IntRect#IntRect combinedScreenRect

---
-- Field layoutMinSize (Read only)
--
-- @field [parent=#Button] #number layoutMinSize

---
-- Field indent
--
-- @field [parent=#Button] #number indent

---
-- Field indentSpacing
--
-- @field [parent=#Button] #number indentSpacing

---
-- Field indentWidth (Read only)
--
-- @field [parent=#Button] #number indentWidth

---
-- Field traversalMode
--
-- @field [parent=#Button] TraversalMode#TraversalMode traversalMode

---
-- Field elementEventSender
--
-- @field [parent=#Button] #boolean elementEventSender

---
-- Function SetTemporary
--
-- @function [parent=#Button] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#Button] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Button] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Button] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Button] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Button] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Button] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Button] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#Button] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Button] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Button] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Button] #string category


return nil
