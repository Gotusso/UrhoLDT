---
-- Module JSONValue
-- Generated on 2014-05-31
--
-- @module JSONValue

---
-- Function IsNull()
-- Return whether does not refer to JSON value.
--
-- @function [parent=#JSONValue] IsNull
-- @param self Self reference
-- @return #boolean

---
-- Function NotNull()
-- Return whether refers to JSON value.
--
-- @function [parent=#JSONValue] NotNull
-- @param self Self reference
-- @return #boolean

---
-- Function operatorbool()
--
-- @function [parent=#JSONValue] operatorbool
-- @param self Self reference
-- @return #boolean

---
-- Function CreateChild()
-- Create a child value.
--
-- @function [parent=#JSONValue] CreateChild
-- @param self Self reference
-- @param #string name name
-- @param JSONValueType#JSONValueType valueType valueType
-- @return JSONValue#JSONValue

---
-- Function GetChild()
-- Return a child value by name. Return null if not exist.
--
-- @function [parent=#JSONValue] GetChild
-- @param self Self reference
-- @param #string name name
-- @param JSONValueType#JSONValueType valueType valueType
-- @return JSONValue#JSONValue

---
-- Function SetInt()
-- Set int.
--
-- @function [parent=#JSONValue] SetInt
-- @param self Self reference
-- @param #string name name
-- @param #number value value

---
-- Function SetBool()
-- Set bool.
--
-- @function [parent=#JSONValue] SetBool
-- @param self Self reference
-- @param #string name name
-- @param #boolean value value

---
-- Function SetFloat()
-- Set float.
--
-- @function [parent=#JSONValue] SetFloat
-- @param self Self reference
-- @param #string name name
-- @param #number value value

---
-- Function SetVector2()
-- Set vector2.
--
-- @function [parent=#JSONValue] SetVector2
-- @param self Self reference
-- @param #string name name
-- @param Vector2#Vector2 value value

---
-- Function SetVector3()
-- Set vector3.
--
-- @function [parent=#JSONValue] SetVector3
-- @param self Self reference
-- @param #string name name
-- @param Vector3#Vector3 value value

---
-- Function SetVector4()
-- Set vector4.
--
-- @function [parent=#JSONValue] SetVector4
-- @param self Self reference
-- @param #string name name
-- @param Vector4#Vector4 value value

---
-- Function SetVectorVariant()
-- Set vector variant.
--
-- @function [parent=#JSONValue] SetVectorVariant
-- @param self Self reference
-- @param #string name name
-- @param Variant#Variant value value

---
-- Function SetQuaternion()
-- Set quaternion.
--
-- @function [parent=#JSONValue] SetQuaternion
-- @param self Self reference
-- @param #string name name
-- @param Quaternion#Quaternion value value

---
-- Function SetColor()
-- Set color.
--
-- @function [parent=#JSONValue] SetColor
-- @param self Self reference
-- @param #string name name
-- @param Color#Color value value

---
-- Function SetString()
-- Set string.
--
-- @function [parent=#JSONValue] SetString
-- @param self Self reference
-- @param #string name name
-- @param #string value value

---
-- Function SetResourceRef()
-- Set resource ref.
--
-- @function [parent=#JSONValue] SetResourceRef
-- @param self Self reference
-- @param #string name name
-- @param ResourceRef#ResourceRef value value

---
-- Function SetResourceRefList()
-- Set resource ref list.
--
-- @function [parent=#JSONValue] SetResourceRefList
-- @param self Self reference
-- @param #string name name
-- @param ResourceRefList#ResourceRefList value value

---
-- Function SetIntRect()
-- Set int rect.
--
-- @function [parent=#JSONValue] SetIntRect
-- @param self Self reference
-- @param #string name name
-- @param IntRect#IntRect value value

---
-- Function SetIntVector2()
-- Set int vector2.
--
-- @function [parent=#JSONValue] SetIntVector2
-- @param self Self reference
-- @param #string name name
-- @param IntVector2#IntVector2 value value

---
-- Function SetMatrix3()
-- Set matrix3.
--
-- @function [parent=#JSONValue] SetMatrix3
-- @param self Self reference
-- @param #string name name
-- @param Matrix3#Matrix3 value value

---
-- Function SetMatrix3x4()
-- Set matrix3x4.
--
-- @function [parent=#JSONValue] SetMatrix3x4
-- @param self Self reference
-- @param #string name name
-- @param Matrix3x4#Matrix3x4 value value

---
-- Function SetMatrix4()
-- Set matrix4.
--
-- @function [parent=#JSONValue] SetMatrix4
-- @param self Self reference
-- @param #string name name
-- @param Matrix4#Matrix4 value value

---
-- Function SetVariant()
-- Set variant (include type).
--
-- @function [parent=#JSONValue] SetVariant
-- @param self Self reference
-- @param #string name name
-- @param Variant#Variant value value

---
-- Function SetVariantValue()
-- Set variant value.
--
-- @function [parent=#JSONValue] SetVariantValue
-- @param self Self reference
-- @param #string name name
-- @param Variant#Variant value value

---
-- Function IsObject()
-- Is object type.
--
-- @function [parent=#JSONValue] IsObject
-- @param self Self reference
-- @return #boolean

---
-- Function GetChildNames()
-- Return child names (only object and array child name).
--
-- @function [parent=#JSONValue] GetChildNames
-- @param self Self reference
-- @return Vector<String>#Vector<String>

---
-- Function GetInt()
-- Return int.
--
-- @function [parent=#JSONValue] GetInt
-- @param self Self reference
-- @param #string name name
-- @return #number

---
-- Function GetBool()
-- Return bool.
--
-- @function [parent=#JSONValue] GetBool
-- @param self Self reference
-- @param #string name name
-- @return #boolean

---
-- Function GetFloat()
-- Return float.
--
-- @function [parent=#JSONValue] GetFloat
-- @param self Self reference
-- @param #string name name
-- @return #number

---
-- Function GetVector2()
-- Return vector2.
--
-- @function [parent=#JSONValue] GetVector2
-- @param self Self reference
-- @param #string name name
-- @return Vector2#Vector2

---
-- Function GetVector3()
-- Return vector3.
--
-- @function [parent=#JSONValue] GetVector3
-- @param self Self reference
-- @param #string name name
-- @return Vector3#Vector3

---
-- Function GetVector4()
-- Return vector4.
--
-- @function [parent=#JSONValue] GetVector4
-- @param self Self reference
-- @param #string name name
-- @return Vector4#Vector4

---
-- Function GetVectorVariant()
-- Return vector variant.
--
-- @function [parent=#JSONValue] GetVectorVariant
-- @param self Self reference
-- @param #string name name
-- @return Variant#Variant

---
-- Function GetQuaternion()
-- Return quaternion.
--
-- @function [parent=#JSONValue] GetQuaternion
-- @param self Self reference
-- @param #string name name
-- @return Quaternion#Quaternion

---
-- Function GetColor()
-- Return color.
--
-- @function [parent=#JSONValue] GetColor
-- @param self Self reference
-- @param #string name name
-- @return Color#Color

---
-- Function GetString()
-- Return string.
--
-- @function [parent=#JSONValue] GetString
-- @param self Self reference
-- @param #string name name
-- @return #string

---
-- Function GetCString()
-- Return C string.
--
-- @function [parent=#JSONValue] GetCString
-- @param self Self reference
-- @param #string name name
-- @return const char*#const char*

---
-- Function GetResourceRef()
-- Return resource ref.
--
-- @function [parent=#JSONValue] GetResourceRef
-- @param self Self reference
-- @param #string name name
-- @return ResourceRef#ResourceRef

---
-- Function GetResourceRefList()
-- Return resource ref list.
--
-- @function [parent=#JSONValue] GetResourceRefList
-- @param self Self reference
-- @param #string name name
-- @return ResourceRefList#ResourceRefList

---
-- Function GetIntRect()
-- Return int rect.
--
-- @function [parent=#JSONValue] GetIntRect
-- @param self Self reference
-- @param #string name name
-- @return IntRect#IntRect

---
-- Function GetIntVector2()
-- Return int vector2.
--
-- @function [parent=#JSONValue] GetIntVector2
-- @param self Self reference
-- @param #string name name
-- @return IntVector2#IntVector2

---
-- Function GetMatrix3()
-- Return matrix3.
--
-- @function [parent=#JSONValue] GetMatrix3
-- @param self Self reference
-- @param #string name name
-- @return Matrix3#Matrix3

---
-- Function GetMatrix3x4()
-- Return matrix3x4.
--
-- @function [parent=#JSONValue] GetMatrix3x4
-- @param self Self reference
-- @param #string name name
-- @return Matrix3x4#Matrix3x4

---
-- Function GetMatrix4()
-- Return matrix4.
--
-- @function [parent=#JSONValue] GetMatrix4
-- @param self Self reference
-- @param #string name name
-- @return Matrix4#Matrix4

---
-- Function GetVariant()
-- Return variant.
--
-- @function [parent=#JSONValue] GetVariant
-- @param self Self reference
-- @param #string name name
-- @return Variant#Variant

---
-- Function GetVariantValue()
-- Return variant value.
--
-- @function [parent=#JSONValue] GetVariantValue
-- @param self Self reference
-- @param #string name name
-- @param VariantType#VariantType type type
-- @return Variant#Variant

---
-- Function CreateChild()
-- Create a child value in array.
--
-- @function [parent=#JSONValue] CreateChild
-- @param self Self reference
-- @param JSONValueType#JSONValueType valueType valueType
-- @return JSONValue#JSONValue

---
-- Function GetChild()
-- Remove a child value in array. Return null if not exist.
--
-- @function [parent=#JSONValue] GetChild
-- @param self Self reference
-- @param #number index index
-- @param JSONValueType#JSONValueType valueType valueType
-- @return JSONValue#JSONValue

---
-- Function AddInt()
-- Add int.
--
-- @function [parent=#JSONValue] AddInt
-- @param self Self reference
-- @param #number value value

---
-- Function AddBool()
-- Add bool.
--
-- @function [parent=#JSONValue] AddBool
-- @param self Self reference
-- @param #boolean value value

---
-- Function AddFloat()
-- Add float.
--
-- @function [parent=#JSONValue] AddFloat
-- @param self Self reference
-- @param #number value value

---
-- Function AddVector2()
-- Add vector2.
--
-- @function [parent=#JSONValue] AddVector2
-- @param self Self reference
-- @param Vector2#Vector2 value value

---
-- Function AddVector3()
-- Add vector3.
--
-- @function [parent=#JSONValue] AddVector3
-- @param self Self reference
-- @param Vector3#Vector3 value value

---
-- Function AddVector4()
-- Add vector4.
--
-- @function [parent=#JSONValue] AddVector4
-- @param self Self reference
-- @param Vector4#Vector4 value value

---
-- Function AddVectorVariant()
-- Add vector variant.
--
-- @function [parent=#JSONValue] AddVectorVariant
-- @param self Self reference
-- @param Variant#Variant value value

---
-- Function AddQuaternion()
-- Add quaternion.
--
-- @function [parent=#JSONValue] AddQuaternion
-- @param self Self reference
-- @param Quaternion#Quaternion value value

---
-- Function AddColor()
-- Add color.
--
-- @function [parent=#JSONValue] AddColor
-- @param self Self reference
-- @param Color#Color value value

---
-- Function AddString()
-- Add string.
--
-- @function [parent=#JSONValue] AddString
-- @param self Self reference
-- @param #string value value

---
-- Function AddResourceRef()
-- Add resource ref.
--
-- @function [parent=#JSONValue] AddResourceRef
-- @param self Self reference
-- @param ResourceRef#ResourceRef value value

---
-- Function AddResourceRefList()
-- Add resource ref list.
--
-- @function [parent=#JSONValue] AddResourceRefList
-- @param self Self reference
-- @param ResourceRefList#ResourceRefList value value

---
-- Function AddIntRect()
-- Add int rect.
--
-- @function [parent=#JSONValue] AddIntRect
-- @param self Self reference
-- @param IntRect#IntRect value value

---
-- Function AddIntVector2()
-- Add int vector2.
--
-- @function [parent=#JSONValue] AddIntVector2
-- @param self Self reference
-- @param IntVector2#IntVector2 value value

---
-- Function AddMatrix3()
-- Add matrix3.
--
-- @function [parent=#JSONValue] AddMatrix3
-- @param self Self reference
-- @param Matrix3#Matrix3 value value

---
-- Function AddMatrix3x4()
-- Add matrix3x4.
--
-- @function [parent=#JSONValue] AddMatrix3x4
-- @param self Self reference
-- @param Matrix3x4#Matrix3x4 value value

---
-- Function AddMatrix4()
-- Add matrix4.
--
-- @function [parent=#JSONValue] AddMatrix4
-- @param self Self reference
-- @param Matrix4#Matrix4 value value

---
-- Function AddVariant()
-- Add variant.
--
-- @function [parent=#JSONValue] AddVariant
-- @param self Self reference
-- @param Variant#Variant value value

---
-- Function AddVariantValue()
-- Add variant value.
--
-- @function [parent=#JSONValue] AddVariantValue
-- @param self Self reference
-- @param Variant#Variant value value

---
-- Function IsArray()
-- Is array type.
--
-- @function [parent=#JSONValue] IsArray
-- @param self Self reference
-- @return #boolean

---
-- Function GetSize()
-- Return array size.
--
-- @function [parent=#JSONValue] GetSize
-- @param self Self reference
-- @return #number

---
-- Function GetInt()
-- Return int.
--
-- @function [parent=#JSONValue] GetInt
-- @param self Self reference
-- @param #number index index
-- @return #number

---
-- Function GetBool()
-- Return bool.
--
-- @function [parent=#JSONValue] GetBool
-- @param self Self reference
-- @param #number index index
-- @return #boolean

---
-- Function GetFloat()
-- Return float.
--
-- @function [parent=#JSONValue] GetFloat
-- @param self Self reference
-- @param #number index index
-- @return #number

---
-- Function GetVector2()
-- Return vector2.
--
-- @function [parent=#JSONValue] GetVector2
-- @param self Self reference
-- @param #number index index
-- @return Vector2#Vector2

---
-- Function GetVector3()
-- Return vector3.
--
-- @function [parent=#JSONValue] GetVector3
-- @param self Self reference
-- @param #number index index
-- @return Vector3#Vector3

---
-- Function GetVector4()
-- Return vector4.
--
-- @function [parent=#JSONValue] GetVector4
-- @param self Self reference
-- @param #number index index
-- @return Vector4#Vector4

---
-- Function GetVectorVariant()
-- Return vector variant.
--
-- @function [parent=#JSONValue] GetVectorVariant
-- @param self Self reference
-- @param #number index index
-- @return Variant#Variant

---
-- Function GetQuaternion()
-- Return quaternion.
--
-- @function [parent=#JSONValue] GetQuaternion
-- @param self Self reference
-- @param #number index index
-- @return Quaternion#Quaternion

---
-- Function GetColor()
-- Return color.
--
-- @function [parent=#JSONValue] GetColor
-- @param self Self reference
-- @param #number index index
-- @return Color#Color

---
-- Function GetString()
-- Return string.
--
-- @function [parent=#JSONValue] GetString
-- @param self Self reference
-- @param #number index index
-- @return #string

---
-- Function GetCString()
-- Return C string.
--
-- @function [parent=#JSONValue] GetCString
-- @param self Self reference
-- @param #number index index
-- @return const char*#const char*

---
-- Function GetResourceRef()
-- Return resource ref.
--
-- @function [parent=#JSONValue] GetResourceRef
-- @param self Self reference
-- @param #number index index
-- @return ResourceRef#ResourceRef

---
-- Function GetResourceRefList()
-- Return resource ref list.
--
-- @function [parent=#JSONValue] GetResourceRefList
-- @param self Self reference
-- @param #number index index
-- @return ResourceRefList#ResourceRefList

---
-- Function GetIntRect()
-- Return int rect.
--
-- @function [parent=#JSONValue] GetIntRect
-- @param self Self reference
-- @param #number index index
-- @return IntRect#IntRect

---
-- Function GetIntVector2()
-- Return int vector2.
--
-- @function [parent=#JSONValue] GetIntVector2
-- @param self Self reference
-- @param #number index index
-- @return IntVector2#IntVector2

---
-- Function GetMatrix3()
-- Return matrix3.
--
-- @function [parent=#JSONValue] GetMatrix3
-- @param self Self reference
-- @param #number index index
-- @return Matrix3#Matrix3

---
-- Function GetMatrix3x4()
-- Return matrix3x4.
--
-- @function [parent=#JSONValue] GetMatrix3x4
-- @param self Self reference
-- @param #number index index
-- @return Matrix3x4#Matrix3x4

---
-- Function GetMatrix4()
-- Return matrix4.
--
-- @function [parent=#JSONValue] GetMatrix4
-- @param self Self reference
-- @param #number index index
-- @return Matrix4#Matrix4

---
-- Function GetVariant()
-- Return variant.
--
-- @function [parent=#JSONValue] GetVariant
-- @param self Self reference
-- @param #number index index
-- @return Variant#Variant

---
-- Function GetVariantValue()
-- Return variant.
--
-- @function [parent=#JSONValue] GetVariantValue
-- @param self Self reference
-- @param #number index index
-- @param VariantType#VariantType type type
-- @return Variant#Variant

---
-- Field EMPTY
--
-- @field [parent=#JSONValue] JSONValue#JSONValue EMPTY

---
-- Field null (Read only)
--
-- @field [parent=#JSONValue] #boolean null

---
-- Field object (Read only)
--
-- @field [parent=#JSONValue] #boolean object

---
-- Field array (Read only)
--
-- @field [parent=#JSONValue] #boolean array


return nil
