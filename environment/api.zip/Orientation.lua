---
-- Enumeration Orientation
--
-- @module Orientation

---
-- Enumeration value O_HORIZONTAL
--
-- @field [parent=#Orientation] #number O_HORIZONTAL

---
-- Enumeration value O_VERTICAL
--
-- @field [parent=#Orientation] #number O_VERTICAL


return nil
