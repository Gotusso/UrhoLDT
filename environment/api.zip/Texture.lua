---
-- Module Texture
-- Extends Resource
--
-- @module Texture

---
-- Function SetNumLevels
--
-- @function [parent=#Texture] SetNumLevels
-- @param #number levelslevels

---
-- Function SetFilterMode
--
-- @function [parent=#Texture] SetFilterMode
-- @param TextureFilterMode#TextureFilterMode filterfilter

---
-- Function SetAddressMode
--
-- @function [parent=#Texture] SetAddressMode
-- @param TextureCoordinate#TextureCoordinate coordcoord
-- @param TextureAddressMode#TextureAddressMode addressaddress

---
-- Function SetBorderColor
--
-- @function [parent=#Texture] SetBorderColor
-- @param Color#Color colorcolor

---
-- Function SetSRGB
--
-- @function [parent=#Texture] SetSRGB
-- @param #boolean enableenable

---
-- Function SetBackupTexture
--
-- @function [parent=#Texture] SetBackupTexture
-- @param Texture#Texture texturetexture

---
-- Function SetMipsToSkip
--
-- @function [parent=#Texture] SetMipsToSkip
-- @param #number qualityquality
-- @param #number mipsmips

---
-- Function GetFormat
--
-- @function [parent=#Texture] GetFormat
-- @return #number

---
-- Function IsCompressed
--
-- @function [parent=#Texture] IsCompressed
-- @return #boolean

---
-- Function GetLevels
--
-- @function [parent=#Texture] GetLevels
-- @return #number

---
-- Function GetWidth
--
-- @function [parent=#Texture] GetWidth
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#Texture] GetHeight
-- @return #number

---
-- Function GetFilterMode
--
-- @function [parent=#Texture] GetFilterMode
-- @return TextureFilterMode#TextureFilterMode

---
-- Function GetAddressMode
--
-- @function [parent=#Texture] GetAddressMode
-- @param TextureCoordinate#TextureCoordinate coordcoord
-- @return TextureAddressMode#TextureAddressMode

---
-- Function GetBorderColor
--
-- @function [parent=#Texture] GetBorderColor
-- @return const Color#const Color

---
-- Function GetSRGB
--
-- @function [parent=#Texture] GetSRGB
-- @return #boolean

---
-- Function GetBackupTexture
--
-- @function [parent=#Texture] GetBackupTexture
-- @return Texture#Texture

---
-- Function GetMipsToSkip
--
-- @function [parent=#Texture] GetMipsToSkip
-- @param #number qualityquality
-- @return #number

---
-- Function GetLevelWidth
--
-- @function [parent=#Texture] GetLevelWidth
-- @param #number levellevel
-- @return #number

---
-- Function GetLevelHeight
--
-- @function [parent=#Texture] GetLevelHeight
-- @param #number levellevel
-- @return #number

---
-- Function GetUsage
--
-- @function [parent=#Texture] GetUsage
-- @return TextureUsage#TextureUsage

---
-- Function GetDataSize
--
-- @function [parent=#Texture] GetDataSize
-- @param #number widthwidth
-- @param #number heightheight
-- @return #number

---
-- Function GetRowDataSize
--
-- @function [parent=#Texture] GetRowDataSize
-- @param #number widthwidth
-- @return #number

---
-- Field format (Read only)
--
-- @field [parent=#Texture] #number format

---
-- Field compressed (Read only)
--
-- @field [parent=#Texture] #boolean compressed

---
-- Field levels (Read only)
--
-- @field [parent=#Texture] #number levels

---
-- Field width (Read only)
--
-- @field [parent=#Texture] #number width

---
-- Field height (Read only)
--
-- @field [parent=#Texture] #number height

---
-- Field filterMode
--
-- @field [parent=#Texture] TextureFilterMode#TextureFilterMode filterMode

---
-- Field borderColor
--
-- @field [parent=#Texture] Color#Color borderColor

---
-- Field sRGB
--
-- @field [parent=#Texture] #boolean sRGB

---
-- Field backupTexture
--
-- @field [parent=#Texture] Texture#Texture backupTexture

---
-- Field usage (Read only)
--
-- @field [parent=#Texture] TextureUsage#TextureUsage usage


return nil
