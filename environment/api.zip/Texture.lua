---
-- Module Texture
-- Module Texture extends Resource
-- Generated on 2014-03-13
--
-- @module Texture

---
-- Function SetNumLevels
--
-- @function [parent=#Texture] SetNumLevels
-- @param self Self reference
-- @param #number levels levels

---
-- Function SetFilterMode
--
-- @function [parent=#Texture] SetFilterMode
-- @param self Self reference
-- @param TextureFilterMode#TextureFilterMode filter filter

---
-- Function SetAddressMode
--
-- @function [parent=#Texture] SetAddressMode
-- @param self Self reference
-- @param TextureCoordinate#TextureCoordinate coord coord
-- @param TextureAddressMode#TextureAddressMode address address

---
-- Function SetBorderColor
--
-- @function [parent=#Texture] SetBorderColor
-- @param self Self reference
-- @param Color#Color color color

---
-- Function SetSRGB
--
-- @function [parent=#Texture] SetSRGB
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetBackupTexture
--
-- @function [parent=#Texture] SetBackupTexture
-- @param self Self reference
-- @param Texture#Texture texture texture

---
-- Function SetMipsToSkip
--
-- @function [parent=#Texture] SetMipsToSkip
-- @param self Self reference
-- @param #number quality quality
-- @param #number mips mips

---
-- Function GetFormat
--
-- @function [parent=#Texture] GetFormat
-- @param self Self reference
-- @return #number

---
-- Function IsCompressed
--
-- @function [parent=#Texture] IsCompressed
-- @param self Self reference
-- @return #boolean

---
-- Function GetLevels
--
-- @function [parent=#Texture] GetLevels
-- @param self Self reference
-- @return #number

---
-- Function GetWidth
--
-- @function [parent=#Texture] GetWidth
-- @param self Self reference
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#Texture] GetHeight
-- @param self Self reference
-- @return #number

---
-- Function GetFilterMode
--
-- @function [parent=#Texture] GetFilterMode
-- @param self Self reference
-- @return TextureFilterMode#TextureFilterMode

---
-- Function GetAddressMode
--
-- @function [parent=#Texture] GetAddressMode
-- @param self Self reference
-- @param TextureCoordinate#TextureCoordinate coord coord
-- @return TextureAddressMode#TextureAddressMode

---
-- Function GetBorderColor
--
-- @function [parent=#Texture] GetBorderColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetSRGB
--
-- @function [parent=#Texture] GetSRGB
-- @param self Self reference
-- @return #boolean

---
-- Function GetBackupTexture
--
-- @function [parent=#Texture] GetBackupTexture
-- @param self Self reference
-- @return Texture#Texture

---
-- Function GetMipsToSkip
--
-- @function [parent=#Texture] GetMipsToSkip
-- @param self Self reference
-- @param #number quality quality
-- @return #number

---
-- Function GetLevelWidth
--
-- @function [parent=#Texture] GetLevelWidth
-- @param self Self reference
-- @param #number level level
-- @return #number

---
-- Function GetLevelHeight
--
-- @function [parent=#Texture] GetLevelHeight
-- @param self Self reference
-- @param #number level level
-- @return #number

---
-- Function GetUsage
--
-- @function [parent=#Texture] GetUsage
-- @param self Self reference
-- @return TextureUsage#TextureUsage

---
-- Function GetDataSize
--
-- @function [parent=#Texture] GetDataSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height
-- @return #number

---
-- Function GetRowDataSize
--
-- @function [parent=#Texture] GetRowDataSize
-- @param self Self reference
-- @param #number width width
-- @return #number

---
-- Field format (Read only)
--
-- @field [parent=#Texture] #number format

---
-- Field compressed (Read only)
--
-- @field [parent=#Texture] #boolean compressed

---
-- Field levels (Read only)
--
-- @field [parent=#Texture] #number levels

---
-- Field width (Read only)
--
-- @field [parent=#Texture] #number width

---
-- Field height (Read only)
--
-- @field [parent=#Texture] #number height

---
-- Field filterMode
--
-- @field [parent=#Texture] TextureFilterMode#TextureFilterMode filterMode

---
-- Field borderColor
--
-- @field [parent=#Texture] Color#Color borderColor

---
-- Field sRGB
--
-- @field [parent=#Texture] #boolean sRGB

---
-- Field backupTexture
--
-- @field [parent=#Texture] Texture#Texture backupTexture

---
-- Field usage (Read only)
--
-- @field [parent=#Texture] TextureUsage#TextureUsage usage

---
-- Function Load
--
-- @function [parent=#Texture] Load
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#Texture] Save
-- @param self Self reference
-- @param Serializer#Serializer dest dest
-- @return #boolean

---
-- Function Load
--
-- @function [parent=#Texture] Load
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#Texture] Save
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function GetName
--
-- @function [parent=#Texture] GetName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetNameHash
--
-- @function [parent=#Texture] GetNameHash
-- @param self Self reference
-- @return StringHash#StringHash

---
-- Function GetMemoryUse
--
-- @function [parent=#Texture] GetMemoryUse
-- @param self Self reference
-- @return #number

---
-- Field name (Read only)
--
-- @field [parent=#Texture] #string name

---
-- Field nameHash (Read only)
--
-- @field [parent=#Texture] StringHash#StringHash nameHash

---
-- Field memoryUse (Read only)
--
-- @field [parent=#Texture] #number memoryUse


return nil
