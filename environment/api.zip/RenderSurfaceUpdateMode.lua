---
-- Enumeration RenderSurfaceUpdateMode
--
-- @module RenderSurfaceUpdateMode

---
-- Enumeration value SURFACE_MANUALUPDATE
--
-- @field [parent=#RenderSurfaceUpdateMode] #number SURFACE_MANUALUPDATE

---
-- Enumeration value SURFACE_UPDATEVISIBLE
--
-- @field [parent=#RenderSurfaceUpdateMode] #number SURFACE_UPDATEVISIBLE

---
-- Enumeration value SURFACE_UPDATEALWAYS
--
-- @field [parent=#RenderSurfaceUpdateMode] #number SURFACE_UPDATEALWAYS


return nil
