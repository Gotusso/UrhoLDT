---
-- Module BiasParameters
--
-- @module BiasParameters

---
-- Function BiasParameters
--
-- @function [parent=#BiasParameters] BiasParameters

---
-- Function new
--
-- @function [parent=#BiasParameters] new
-- @return BiasParameters#BiasParameters

---
-- Function BiasParameters
--
-- @function [parent=#BiasParameters] BiasParameters
-- @param #number constantBiasconstantBias
-- @param #number slopeScaledBiasslopeScaledBias

---
-- Function new
--
-- @function [parent=#BiasParameters] new
-- @param #number constantBiasconstantBias
-- @param #number slopeScaledBiasslopeScaledBias
-- @return BiasParameters#BiasParameters

---
-- Function delete
--
-- @function [parent=#BiasParameters] delete


return nil
