---
-- Module BiasParameters
-- Generated on 2014-05-31
--
-- @module BiasParameters

---
-- Function BiasParameters()
--
-- @function [parent=#BiasParameters] BiasParameters
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#BiasParameters] new
-- @param self Self reference
-- @return BiasParameters#BiasParameters

---
-- Function BiasParameters()
--
-- @function [parent=#BiasParameters] BiasParameters
-- @param self Self reference
-- @param #number constantBias constantBias
-- @param #number slopeScaledBias slopeScaledBias

---
-- Function new()
--
-- @function [parent=#BiasParameters] new
-- @param self Self reference
-- @param #number constantBias constantBias
-- @param #number slopeScaledBias slopeScaledBias
-- @return BiasParameters#BiasParameters

---
-- Function delete()
--
-- @function [parent=#BiasParameters] delete
-- @param self Self reference


return nil
