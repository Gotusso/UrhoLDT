---
-- Enumeration CompareMode
--
-- @module CompareMode

---
-- Enumeration value CMP_ALWAYS
--
-- @field [parent=#CompareMode] #number CMP_ALWAYS

---
-- Enumeration value CMP_EQUAL
--
-- @field [parent=#CompareMode] #number CMP_EQUAL

---
-- Enumeration value CMP_NOTEQUAL
--
-- @field [parent=#CompareMode] #number CMP_NOTEQUAL

---
-- Enumeration value CMP_LESS
--
-- @field [parent=#CompareMode] #number CMP_LESS

---
-- Enumeration value CMP_LESSEQUAL
--
-- @field [parent=#CompareMode] #number CMP_LESSEQUAL

---
-- Enumeration value CMP_GREATER
--
-- @field [parent=#CompareMode] #number CMP_GREATER

---
-- Enumeration value CMP_GREATEREQUAL
--
-- @field [parent=#CompareMode] #number CMP_GREATEREQUAL

---
-- Enumeration value MAX_COMPAREMODES
--
-- @field [parent=#CompareMode] #number MAX_COMPAREMODES


return nil
