---
-- Module Resource
-- Generated on 2014-05-31
--
-- @module Resource

---
-- Function Load()
-- Load resource. Return true if successful.
--
-- @function [parent=#Resource] Load
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @return #boolean

---
-- Function Save()
-- Save resource. Return true if successful.
--
-- @function [parent=#Resource] Save
-- @param self Self reference
-- @param Serializer#Serializer dest dest
-- @return #boolean

---
-- Function Load()
--
-- @function [parent=#Resource] Load
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function Save()
--
-- @function [parent=#Resource] Save
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function GetName()
-- Return name.
--
-- @function [parent=#Resource] GetName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetNameHash()
-- Return name hash.
--
-- @function [parent=#Resource] GetNameHash
-- @param self Self reference
-- @return StringHash#StringHash

---
-- Function GetMemoryUse()
-- Return memory use in bytes, possibly approximate.
--
-- @function [parent=#Resource] GetMemoryUse
-- @param self Self reference
-- @return #number

---
-- Field name (Read only)
--
-- @field [parent=#Resource] #string name

---
-- Field nameHash (Read only)
--
-- @field [parent=#Resource] StringHash#StringHash nameHash

---
-- Field memoryUse (Read only)
--
-- @field [parent=#Resource] #number memoryUse


return nil
