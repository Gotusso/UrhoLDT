---
-- Module Resource
--
-- @module Resource

---
-- Function Load
--
-- @function [parent=#Resource] Load
-- @param Deserializer#Deserializer sourcesource
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#Resource] Save
-- @param Serializer#Serializer destdest
-- @return #boolean

---
-- Function Load
--
-- @function [parent=#Resource] Load
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#Resource] Save
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function GetName
--
-- @function [parent=#Resource] GetName
-- @return const String#const String

---
-- Function GetNameHash
--
-- @function [parent=#Resource] GetNameHash
-- @return StringHash#StringHash

---
-- Function GetMemoryUse
--
-- @function [parent=#Resource] GetMemoryUse
-- @return #number

---
-- Field name (Read only)
--
-- @field [parent=#Resource] #string name

---
-- Field nameHash (Read only)
--
-- @field [parent=#Resource] StringHash#StringHash nameHash

---
-- Field memoryUse (Read only)
--
-- @field [parent=#Resource] #number memoryUse


return nil
