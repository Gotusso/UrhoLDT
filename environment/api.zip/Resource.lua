---
-- Module Resource
-- Generated on 2014-03-13
--
-- @module Resource

---
-- Function Load
--
-- @function [parent=#Resource] Load
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#Resource] Save
-- @param self Self reference
-- @param Serializer#Serializer dest dest
-- @return #boolean

---
-- Function Load
--
-- @function [parent=#Resource] Load
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#Resource] Save
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function GetName
--
-- @function [parent=#Resource] GetName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetNameHash
--
-- @function [parent=#Resource] GetNameHash
-- @param self Self reference
-- @return StringHash#StringHash

---
-- Function GetMemoryUse
--
-- @function [parent=#Resource] GetMemoryUse
-- @param self Self reference
-- @return #number

---
-- Field name (Read only)
--
-- @field [parent=#Resource] #string name

---
-- Field nameHash (Read only)
--
-- @field [parent=#Resource] StringHash#StringHash nameHash

---
-- Field memoryUse (Read only)
--
-- @field [parent=#Resource] #number memoryUse


return nil
