---
-- Module Renderer
--
-- @module Renderer

---
-- Function SetNumViewports
--
-- @function [parent=#Renderer] SetNumViewports
-- @param #number numnum

---
-- Function SetViewport
--
-- @function [parent=#Renderer] SetViewport
-- @param #number indexindex
-- @param Viewport#Viewport viewportviewport

---
-- Function SetDefaultRenderPath
--
-- @function [parent=#Renderer] SetDefaultRenderPath
-- @param RenderPath#RenderPath renderPathrenderPath

---
-- Function SetDefaultRenderPath
--
-- @function [parent=#Renderer] SetDefaultRenderPath
-- @param XMLFile#XMLFile filefile

---
-- Function SetHDRRendering
--
-- @function [parent=#Renderer] SetHDRRendering
-- @param #boolean enableenable

---
-- Function SetSpecularLighting
--
-- @function [parent=#Renderer] SetSpecularLighting
-- @param #boolean enableenable

---
-- Function SetTextureAnisotropy
--
-- @function [parent=#Renderer] SetTextureAnisotropy
-- @param #number levellevel

---
-- Function SetTextureFilterMode
--
-- @function [parent=#Renderer] SetTextureFilterMode
-- @param TextureFilterMode#TextureFilterMode modemode

---
-- Function SetTextureQuality
--
-- @function [parent=#Renderer] SetTextureQuality
-- @param #number qualityquality

---
-- Function SetMaterialQuality
--
-- @function [parent=#Renderer] SetMaterialQuality
-- @param #number qualityquality

---
-- Function SetDrawShadows
--
-- @function [parent=#Renderer] SetDrawShadows
-- @param #boolean enableenable

---
-- Function SetShadowMapSize
--
-- @function [parent=#Renderer] SetShadowMapSize
-- @param #number sizesize

---
-- Function SetShadowQuality
--
-- @function [parent=#Renderer] SetShadowQuality
-- @param #number qualityquality

---
-- Function SetReuseShadowMaps
--
-- @function [parent=#Renderer] SetReuseShadowMaps
-- @param #boolean enableenable

---
-- Function SetMaxShadowMaps
--
-- @function [parent=#Renderer] SetMaxShadowMaps
-- @param #number shadowMapsshadowMaps

---
-- Function SetMaxShadowCascades
--
-- @function [parent=#Renderer] SetMaxShadowCascades
-- @param #number cascadescascades

---
-- Function SetDynamicInstancing
--
-- @function [parent=#Renderer] SetDynamicInstancing
-- @param #boolean enableenable

---
-- Function SetMinInstances
--
-- @function [parent=#Renderer] SetMinInstances
-- @param #number instancesinstances

---
-- Function SetMaxInstanceTriangles
--
-- @function [parent=#Renderer] SetMaxInstanceTriangles
-- @param #number trianglestriangles

---
-- Function SetMaxSortedInstances
--
-- @function [parent=#Renderer] SetMaxSortedInstances
-- @param #number instancesinstances

---
-- Function SetMaxOccluderTriangles
--
-- @function [parent=#Renderer] SetMaxOccluderTriangles
-- @param #number trianglestriangles

---
-- Function SetOcclusionBufferSize
--
-- @function [parent=#Renderer] SetOcclusionBufferSize
-- @param #number sizesize

---
-- Function SetOccluderSizeThreshold
--
-- @function [parent=#Renderer] SetOccluderSizeThreshold
-- @param #number screenSizescreenSize

---
-- Function ReloadShaders
--
-- @function [parent=#Renderer] ReloadShaders

---
-- Function GetNumViewports
--
-- @function [parent=#Renderer] GetNumViewports
-- @return #number

---
-- Function GetViewport
--
-- @function [parent=#Renderer] GetViewport
-- @param #number indexindex
-- @return Viewport#Viewport

---
-- Function GetDefaultRenderPath
--
-- @function [parent=#Renderer] GetDefaultRenderPath
-- @return RenderPath#RenderPath

---
-- Function GetHDRRendering
--
-- @function [parent=#Renderer] GetHDRRendering
-- @return #boolean

---
-- Function GetSpecularLighting
--
-- @function [parent=#Renderer] GetSpecularLighting
-- @return #boolean

---
-- Function GetDrawShadows
--
-- @function [parent=#Renderer] GetDrawShadows
-- @return #boolean

---
-- Function GetTextureAnisotropy
--
-- @function [parent=#Renderer] GetTextureAnisotropy
-- @return #number

---
-- Function GetTextureFilterMode
--
-- @function [parent=#Renderer] GetTextureFilterMode
-- @return TextureFilterMode#TextureFilterMode

---
-- Function GetTextureQuality
--
-- @function [parent=#Renderer] GetTextureQuality
-- @return #number

---
-- Function GetMaterialQuality
--
-- @function [parent=#Renderer] GetMaterialQuality
-- @return #number

---
-- Function GetShadowMapSize
--
-- @function [parent=#Renderer] GetShadowMapSize
-- @return #number

---
-- Function GetShadowQuality
--
-- @function [parent=#Renderer] GetShadowQuality
-- @return #number

---
-- Function GetReuseShadowMaps
--
-- @function [parent=#Renderer] GetReuseShadowMaps
-- @return #boolean

---
-- Function GetMaxShadowMaps
--
-- @function [parent=#Renderer] GetMaxShadowMaps
-- @return #number

---
-- Function GetMaxShadowCascades
--
-- @function [parent=#Renderer] GetMaxShadowCascades
-- @return #number

---
-- Function GetDynamicInstancing
--
-- @function [parent=#Renderer] GetDynamicInstancing
-- @return #boolean

---
-- Function GetMinInstances
--
-- @function [parent=#Renderer] GetMinInstances
-- @return #number

---
-- Function GetMaxInstanceTriangles
--
-- @function [parent=#Renderer] GetMaxInstanceTriangles
-- @return #number

---
-- Function GetMaxSortedInstances
--
-- @function [parent=#Renderer] GetMaxSortedInstances
-- @return #number

---
-- Function GetMaxOccluderTriangles
--
-- @function [parent=#Renderer] GetMaxOccluderTriangles
-- @return #number

---
-- Function GetOcclusionBufferSize
--
-- @function [parent=#Renderer] GetOcclusionBufferSize
-- @return #number

---
-- Function GetOccluderSizeThreshold
--
-- @function [parent=#Renderer] GetOccluderSizeThreshold
-- @return #number

---
-- Function GetNumViews
--
-- @function [parent=#Renderer] GetNumViews
-- @return #number

---
-- Function GetNumPrimitives
--
-- @function [parent=#Renderer] GetNumPrimitives
-- @return #number

---
-- Function GetNumBatches
--
-- @function [parent=#Renderer] GetNumBatches
-- @return #number

---
-- Function GetNumGeometries
--
-- @function [parent=#Renderer] GetNumGeometries
-- @param #boolean allViewsallViews
-- @return #number

---
-- Function GetNumLights
--
-- @function [parent=#Renderer] GetNumLights
-- @param #boolean allViewsallViews
-- @return #number

---
-- Function GetNumShadowMaps
--
-- @function [parent=#Renderer] GetNumShadowMaps
-- @param #boolean allViewsallViews
-- @return #number

---
-- Function GetNumOccluders
--
-- @function [parent=#Renderer] GetNumOccluders
-- @param #boolean allViewsallViews
-- @return #number

---
-- Function GetDefaultZone
--
-- @function [parent=#Renderer] GetDefaultZone
-- @return Zone#Zone

---
-- Function GetQuadDirLight
--
-- @function [parent=#Renderer] GetQuadDirLight
-- @return Light#Light

---
-- Function GetDefaultMaterial
--
-- @function [parent=#Renderer] GetDefaultMaterial
-- @return Material#Material

---
-- Function GetDefaultLightRamp
--
-- @function [parent=#Renderer] GetDefaultLightRamp
-- @return Texture2D#Texture2D

---
-- Function GetDefaultLightSpot
--
-- @function [parent=#Renderer] GetDefaultLightSpot
-- @return Texture2D#Texture2D

---
-- Function GetFaceSelectCubeMap
--
-- @function [parent=#Renderer] GetFaceSelectCubeMap
-- @return TextureCube#TextureCube

---
-- Function GetIndirectionCubeMap
--
-- @function [parent=#Renderer] GetIndirectionCubeMap
-- @return TextureCube#TextureCube

---
-- Function GetInstancingBuffer
--
-- @function [parent=#Renderer] GetInstancingBuffer
-- @return VertexBuffer#VertexBuffer

---
-- Function GetFrameInfo
--
-- @function [parent=#Renderer] GetFrameInfo
-- @return const FrameInfo#const FrameInfo

---
-- Function DrawDebugGeometry
--
-- @function [parent=#Renderer] DrawDebugGeometry
-- @param #boolean depthTestdepthTest

---
-- Field numViewports
--
-- @field [parent=#Renderer] #number numViewports

---
-- Field defaultRenderPath
--
-- @field [parent=#Renderer] RenderPath#RenderPath defaultRenderPath

---
-- Field HDRRendering
--
-- @field [parent=#Renderer] #boolean HDRRendering

---
-- Field specularLighting
--
-- @field [parent=#Renderer] #boolean specularLighting

---
-- Field drawShadows
--
-- @field [parent=#Renderer] #boolean drawShadows

---
-- Field textureAnisotropy
--
-- @field [parent=#Renderer] #number textureAnisotropy

---
-- Field textureFilterMode
--
-- @field [parent=#Renderer] TextureFilterMode#TextureFilterMode textureFilterMode

---
-- Field textureQuality
--
-- @field [parent=#Renderer] #number textureQuality

---
-- Field materialQuality
--
-- @field [parent=#Renderer] #number materialQuality

---
-- Field shadowMapSize
--
-- @field [parent=#Renderer] #number shadowMapSize

---
-- Field shadowQuality
--
-- @field [parent=#Renderer] #number shadowQuality

---
-- Field reuseShadowMaps
--
-- @field [parent=#Renderer] #boolean reuseShadowMaps

---
-- Field maxShadowMaps
--
-- @field [parent=#Renderer] #number maxShadowMaps

---
-- Field maxShadowCascades
--
-- @field [parent=#Renderer] #number maxShadowCascades

---
-- Field dynamicInstancing
--
-- @field [parent=#Renderer] #boolean dynamicInstancing

---
-- Field minInstances
--
-- @field [parent=#Renderer] #number minInstances

---
-- Field maxInstanceTriangles
--
-- @field [parent=#Renderer] #number maxInstanceTriangles

---
-- Field maxSortedInstances
--
-- @field [parent=#Renderer] #number maxSortedInstances

---
-- Field maxOccluderTriangles
--
-- @field [parent=#Renderer] #number maxOccluderTriangles

---
-- Field occlusionBufferSize
--
-- @field [parent=#Renderer] #number occlusionBufferSize

---
-- Field occluderSizeThreshold
--
-- @field [parent=#Renderer] #number occluderSizeThreshold

---
-- Field numViews (Read only)
--
-- @field [parent=#Renderer] #number numViews

---
-- Field numPrimitives (Read only)
--
-- @field [parent=#Renderer] #number numPrimitives

---
-- Field numBatches (Read only)
--
-- @field [parent=#Renderer] #number numBatches

---
-- Field defaultZone (Read only)
--
-- @field [parent=#Renderer] Zone#Zone defaultZone

---
-- Field defaultMaterial (Read only)
--
-- @field [parent=#Renderer] Material#Material defaultMaterial

---
-- Field defaultLightRamp (Read only)
--
-- @field [parent=#Renderer] Texture2D#Texture2D defaultLightRamp

---
-- Field defaultLightSpot (Read only)
--
-- @field [parent=#Renderer] Texture2D#Texture2D defaultLightSpot


return nil
