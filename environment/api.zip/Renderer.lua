---
-- Module Renderer
-- Generated on 2014-05-31
--
-- @module Renderer

---
-- Function SetNumViewports()
-- Set number of backbuffer viewports to render.
--
-- @function [parent=#Renderer] SetNumViewports
-- @param self Self reference
-- @param #number num num

---
-- Function SetViewport()
-- Set a backbuffer viewport.
--
-- @function [parent=#Renderer] SetViewport
-- @param self Self reference
-- @param #number index index
-- @param Viewport#Viewport viewport viewport

---
-- Function SetDefaultRenderPath()
-- Set default renderpath.
--
-- @function [parent=#Renderer] SetDefaultRenderPath
-- @param self Self reference
-- @param RenderPath#RenderPath renderPath renderPath

---
-- Function SetDefaultRenderPath()
-- Set default renderpath from an XML file.
--
-- @function [parent=#Renderer] SetDefaultRenderPath
-- @param self Self reference
-- @param XMLFile#XMLFile file file

---
-- Function SetHDRRendering()
-- Set HDR rendering on/off.
--
-- @function [parent=#Renderer] SetHDRRendering
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetSpecularLighting()
-- Set specular lighting on/off.
--
-- @function [parent=#Renderer] SetSpecularLighting
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetTextureAnisotropy()
-- Set texture anisotropy.
--
-- @function [parent=#Renderer] SetTextureAnisotropy
-- @param self Self reference
-- @param #number level level

---
-- Function SetTextureFilterMode()
-- Set texture filtering.
--
-- @function [parent=#Renderer] SetTextureFilterMode
-- @param self Self reference
-- @param TextureFilterMode#TextureFilterMode mode mode

---
-- Function SetTextureQuality()
-- Set texture quality level.
--
-- @function [parent=#Renderer] SetTextureQuality
-- @param self Self reference
-- @param #number quality quality

---
-- Function SetMaterialQuality()
-- Set material quality level.
--
-- @function [parent=#Renderer] SetMaterialQuality
-- @param self Self reference
-- @param #number quality quality

---
-- Function SetDrawShadows()
-- Set shadows on/off.
--
-- @function [parent=#Renderer] SetDrawShadows
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetShadowMapSize()
-- Set shadow map resolution.
--
-- @function [parent=#Renderer] SetShadowMapSize
-- @param self Self reference
-- @param #number size size

---
-- Function SetShadowQuality()
-- Set shadow quality (amount of samples and bit depth.)
--
-- @function [parent=#Renderer] SetShadowQuality
-- @param self Self reference
-- @param #number quality quality

---
-- Function SetReuseShadowMaps()
-- Set reuse of shadow maps. Default is true. If disabled, also transparent geometry can be shadowed.
--
-- @function [parent=#Renderer] SetReuseShadowMaps
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetMaxShadowMaps()
-- Set maximum number of shadow maps created for one resolution. Only has effect if reuse of shadow maps is disabled.
--
-- @function [parent=#Renderer] SetMaxShadowMaps
-- @param self Self reference
-- @param #number shadowMaps shadowMaps

---
-- Function SetDynamicInstancing()
-- Set dynamic instancing on/off.
--
-- @function [parent=#Renderer] SetDynamicInstancing
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetMinInstances()
-- Set minimum number of instances required in a batch group to render as instanced.
--
-- @function [parent=#Renderer] SetMinInstances
-- @param self Self reference
-- @param #number instances instances

---
-- Function SetMaxInstanceTriangles()
-- Set maximum number of triangles per object for instancing.
--
-- @function [parent=#Renderer] SetMaxInstanceTriangles
-- @param self Self reference
-- @param #number triangles triangles

---
-- Function SetMaxSortedInstances()
-- Set maximum number of sorted instances per batch group. If exceeded, instances are rendered unsorted.
--
-- @function [parent=#Renderer] SetMaxSortedInstances
-- @param self Self reference
-- @param #number instances instances

---
-- Function SetMaxOccluderTriangles()
-- Set maximum number of occluder trianges.
--
-- @function [parent=#Renderer] SetMaxOccluderTriangles
-- @param self Self reference
-- @param #number triangles triangles

---
-- Function SetOcclusionBufferSize()
-- Set occluder buffer width.
--
-- @function [parent=#Renderer] SetOcclusionBufferSize
-- @param self Self reference
-- @param #number size size

---
-- Function SetOccluderSizeThreshold()
-- Set required screen size (1.0 = full screen) for occluders.
--
-- @function [parent=#Renderer] SetOccluderSizeThreshold
-- @param self Self reference
-- @param #number screenSize screenSize

---
-- Function SetMobileShadowBiasMul()
-- Set shadow depth bias multiplier for mobile platforms (OpenGL ES.) No effect on desktops. Default 2.
--
-- @function [parent=#Renderer] SetMobileShadowBiasMul
-- @param self Self reference
-- @param #number mul mul

---
-- Function SetMobileShadowBiasAdd()
-- Set shadow depth bias addition for mobile platforms (OpenGL ES.)  No effect on desktops. Default 0.0001.
--
-- @function [parent=#Renderer] SetMobileShadowBiasAdd
-- @param self Self reference
-- @param #number add add

---
-- Function ReloadShaders()
-- Force reload of shaders.
--
-- @function [parent=#Renderer] ReloadShaders
-- @param self Self reference

---
-- Function GetNumViewports()
-- Return number of backbuffer viewports.
--
-- @function [parent=#Renderer] GetNumViewports
-- @param self Self reference
-- @return #number

---
-- Function GetViewport()
-- Return backbuffer viewport by index.
--
-- @function [parent=#Renderer] GetViewport
-- @param self Self reference
-- @param #number index index
-- @return Viewport#Viewport

---
-- Function GetDefaultRenderPath()
-- Return default renderpath.
--
-- @function [parent=#Renderer] GetDefaultRenderPath
-- @param self Self reference
-- @return RenderPath#RenderPath

---
-- Function GetHDRRendering()
-- Return whether HDR rendering is enabled.
--
-- @function [parent=#Renderer] GetHDRRendering
-- @param self Self reference
-- @return #boolean

---
-- Function GetSpecularLighting()
-- Return whether specular lighting is enabled.
--
-- @function [parent=#Renderer] GetSpecularLighting
-- @param self Self reference
-- @return #boolean

---
-- Function GetDrawShadows()
-- Return whether drawing shadows is enabled.
--
-- @function [parent=#Renderer] GetDrawShadows
-- @param self Self reference
-- @return #boolean

---
-- Function GetTextureAnisotropy()
-- Return texture anisotropy.
--
-- @function [parent=#Renderer] GetTextureAnisotropy
-- @param self Self reference
-- @return #number

---
-- Function GetTextureFilterMode()
-- Return texture filtering.
--
-- @function [parent=#Renderer] GetTextureFilterMode
-- @param self Self reference
-- @return TextureFilterMode#TextureFilterMode

---
-- Function GetTextureQuality()
-- Return texture quality level.
--
-- @function [parent=#Renderer] GetTextureQuality
-- @param self Self reference
-- @return #number

---
-- Function GetMaterialQuality()
-- Return material quality level.
--
-- @function [parent=#Renderer] GetMaterialQuality
-- @param self Self reference
-- @return #number

---
-- Function GetShadowMapSize()
-- Return shadow map resolution.
--
-- @function [parent=#Renderer] GetShadowMapSize
-- @param self Self reference
-- @return #number

---
-- Function GetShadowQuality()
-- Return shadow quality.
--
-- @function [parent=#Renderer] GetShadowQuality
-- @param self Self reference
-- @return #number

---
-- Function GetReuseShadowMaps()
-- Return whether shadow maps are reused.
--
-- @function [parent=#Renderer] GetReuseShadowMaps
-- @param self Self reference
-- @return #boolean

---
-- Function GetMaxShadowMaps()
-- Return maximum number of shadow maps per resolution.
--
-- @function [parent=#Renderer] GetMaxShadowMaps
-- @param self Self reference
-- @return #number

---
-- Function GetDynamicInstancing()
-- Return whether dynamic instancing is in use.
--
-- @function [parent=#Renderer] GetDynamicInstancing
-- @param self Self reference
-- @return #boolean

---
-- Function GetMinInstances()
-- Return minimum number of instances required in a batch group to render as instanced.
--
-- @function [parent=#Renderer] GetMinInstances
-- @param self Self reference
-- @return #number

---
-- Function GetMaxInstanceTriangles()
-- Return maximum number of triangles per object for instancing.
--
-- @function [parent=#Renderer] GetMaxInstanceTriangles
-- @param self Self reference
-- @return #number

---
-- Function GetMaxSortedInstances()
-- Return maximum number of sorted instances per batch group.
--
-- @function [parent=#Renderer] GetMaxSortedInstances
-- @param self Self reference
-- @return #number

---
-- Function GetMaxOccluderTriangles()
-- Return maximum number of occluder triangles.
--
-- @function [parent=#Renderer] GetMaxOccluderTriangles
-- @param self Self reference
-- @return #number

---
-- Function GetOcclusionBufferSize()
-- Return occlusion buffer width.
--
-- @function [parent=#Renderer] GetOcclusionBufferSize
-- @param self Self reference
-- @return #number

---
-- Function GetOccluderSizeThreshold()
-- Return occluder screen size threshold.
--
-- @function [parent=#Renderer] GetOccluderSizeThreshold
-- @param self Self reference
-- @return #number

---
-- Function GetMobileShadowBiasMul()
-- Return shadow depth bias multiplier for mobile platforms.
--
-- @function [parent=#Renderer] GetMobileShadowBiasMul
-- @param self Self reference
-- @return #number

---
-- Function GetMobileShadowBiasAdd()
-- Return shadow depth bias addition for mobile platforms.
--
-- @function [parent=#Renderer] GetMobileShadowBiasAdd
-- @param self Self reference
-- @return #number

---
-- Function GetNumViews()
-- Return number of views rendered.
--
-- @function [parent=#Renderer] GetNumViews
-- @param self Self reference
-- @return #number

---
-- Function GetNumPrimitives()
-- Return number of primitives rendered.
--
-- @function [parent=#Renderer] GetNumPrimitives
-- @param self Self reference
-- @return #number

---
-- Function GetNumBatches()
-- Return number of batches rendered.
--
-- @function [parent=#Renderer] GetNumBatches
-- @param self Self reference
-- @return #number

---
-- Function GetNumGeometries()
-- Return number of geometries rendered.
--
-- @function [parent=#Renderer] GetNumGeometries
-- @param self Self reference
-- @param #boolean allViews allViews
-- @return #number

---
-- Function GetNumLights()
-- Return number of lights rendered.
--
-- @function [parent=#Renderer] GetNumLights
-- @param self Self reference
-- @param #boolean allViews allViews
-- @return #number

---
-- Function GetNumShadowMaps()
-- Return number of shadow maps rendered.
--
-- @function [parent=#Renderer] GetNumShadowMaps
-- @param self Self reference
-- @param #boolean allViews allViews
-- @return #number

---
-- Function GetNumOccluders()
-- Return number of occluders rendered.
--
-- @function [parent=#Renderer] GetNumOccluders
-- @param self Self reference
-- @param #boolean allViews allViews
-- @return #number

---
-- Function GetDefaultZone()
-- Return the default zone.
--
-- @function [parent=#Renderer] GetDefaultZone
-- @param self Self reference
-- @return Zone#Zone

---
-- Function GetDefaultMaterial()
-- Return the default material.
--
-- @function [parent=#Renderer] GetDefaultMaterial
-- @param self Self reference
-- @return Material#Material

---
-- Function GetDefaultLightRamp()
-- Return the default range attenuation texture.
--
-- @function [parent=#Renderer] GetDefaultLightRamp
-- @param self Self reference
-- @return Texture2D#Texture2D

---
-- Function GetDefaultLightSpot()
-- Return the default spotlight attenuation texture.
--
-- @function [parent=#Renderer] GetDefaultLightSpot
-- @param self Self reference
-- @return Texture2D#Texture2D

---
-- Function DrawDebugGeometry()
-- Add debug geometry to the debug renderer.
--
-- @function [parent=#Renderer] DrawDebugGeometry
-- @param self Self reference
-- @param #boolean depthTest depthTest

---
-- Field numViewports
--
-- @field [parent=#Renderer] #number numViewports

---
-- Field defaultRenderPath
--
-- @field [parent=#Renderer] RenderPath#RenderPath defaultRenderPath

---
-- Field HDRRendering
--
-- @field [parent=#Renderer] #boolean HDRRendering

---
-- Field specularLighting
--
-- @field [parent=#Renderer] #boolean specularLighting

---
-- Field drawShadows
--
-- @field [parent=#Renderer] #boolean drawShadows

---
-- Field textureAnisotropy
--
-- @field [parent=#Renderer] #number textureAnisotropy

---
-- Field textureFilterMode
--
-- @field [parent=#Renderer] TextureFilterMode#TextureFilterMode textureFilterMode

---
-- Field textureQuality
--
-- @field [parent=#Renderer] #number textureQuality

---
-- Field materialQuality
--
-- @field [parent=#Renderer] #number materialQuality

---
-- Field shadowMapSize
--
-- @field [parent=#Renderer] #number shadowMapSize

---
-- Field shadowQuality
--
-- @field [parent=#Renderer] #number shadowQuality

---
-- Field reuseShadowMaps
--
-- @field [parent=#Renderer] #boolean reuseShadowMaps

---
-- Field maxShadowMaps
--
-- @field [parent=#Renderer] #number maxShadowMaps

---
-- Field dynamicInstancing
--
-- @field [parent=#Renderer] #boolean dynamicInstancing

---
-- Field minInstances
--
-- @field [parent=#Renderer] #number minInstances

---
-- Field maxInstanceTriangles
--
-- @field [parent=#Renderer] #number maxInstanceTriangles

---
-- Field maxSortedInstances
--
-- @field [parent=#Renderer] #number maxSortedInstances

---
-- Field maxOccluderTriangles
--
-- @field [parent=#Renderer] #number maxOccluderTriangles

---
-- Field occlusionBufferSize
--
-- @field [parent=#Renderer] #number occlusionBufferSize

---
-- Field occluderSizeThreshold
--
-- @field [parent=#Renderer] #number occluderSizeThreshold

---
-- Field mobileShadowBiasMul
--
-- @field [parent=#Renderer] #number mobileShadowBiasMul

---
-- Field mobileShadowBiasAdd
--
-- @field [parent=#Renderer] #number mobileShadowBiasAdd

---
-- Field numViews (Read only)
--
-- @field [parent=#Renderer] #number numViews

---
-- Field numPrimitives (Read only)
--
-- @field [parent=#Renderer] #number numPrimitives

---
-- Field numBatches (Read only)
--
-- @field [parent=#Renderer] #number numBatches

---
-- Field defaultZone (Read only)
--
-- @field [parent=#Renderer] Zone#Zone defaultZone

---
-- Field defaultMaterial (Read only)
--
-- @field [parent=#Renderer] Material#Material defaultMaterial

---
-- Field defaultLightRamp (Read only)
--
-- @field [parent=#Renderer] Texture2D#Texture2D defaultLightRamp

---
-- Field defaultLightSpot (Read only)
--
-- @field [parent=#Renderer] Texture2D#Texture2D defaultLightSpot


return nil
