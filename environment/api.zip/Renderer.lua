---
-- Module Renderer
-- Generated on 2014-03-13
--
-- @module Renderer

---
-- Function SetNumViewports
--
-- @function [parent=#Renderer] SetNumViewports
-- @param self Self reference
-- @param #number num num

---
-- Function SetViewport
--
-- @function [parent=#Renderer] SetViewport
-- @param self Self reference
-- @param #number index index
-- @param Viewport#Viewport viewport viewport

---
-- Function SetDefaultRenderPath
--
-- @function [parent=#Renderer] SetDefaultRenderPath
-- @param self Self reference
-- @param RenderPath#RenderPath renderPath renderPath

---
-- Function SetDefaultRenderPath
--
-- @function [parent=#Renderer] SetDefaultRenderPath
-- @param self Self reference
-- @param XMLFile#XMLFile file file

---
-- Function SetHDRRendering
--
-- @function [parent=#Renderer] SetHDRRendering
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetSpecularLighting
--
-- @function [parent=#Renderer] SetSpecularLighting
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetTextureAnisotropy
--
-- @function [parent=#Renderer] SetTextureAnisotropy
-- @param self Self reference
-- @param #number level level

---
-- Function SetTextureFilterMode
--
-- @function [parent=#Renderer] SetTextureFilterMode
-- @param self Self reference
-- @param TextureFilterMode#TextureFilterMode mode mode

---
-- Function SetTextureQuality
--
-- @function [parent=#Renderer] SetTextureQuality
-- @param self Self reference
-- @param #number quality quality

---
-- Function SetMaterialQuality
--
-- @function [parent=#Renderer] SetMaterialQuality
-- @param self Self reference
-- @param #number quality quality

---
-- Function SetDrawShadows
--
-- @function [parent=#Renderer] SetDrawShadows
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetShadowMapSize
--
-- @function [parent=#Renderer] SetShadowMapSize
-- @param self Self reference
-- @param #number size size

---
-- Function SetShadowQuality
--
-- @function [parent=#Renderer] SetShadowQuality
-- @param self Self reference
-- @param #number quality quality

---
-- Function SetReuseShadowMaps
--
-- @function [parent=#Renderer] SetReuseShadowMaps
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetMaxShadowMaps
--
-- @function [parent=#Renderer] SetMaxShadowMaps
-- @param self Self reference
-- @param #number shadowMaps shadowMaps

---
-- Function SetMaxShadowCascades
--
-- @function [parent=#Renderer] SetMaxShadowCascades
-- @param self Self reference
-- @param #number cascades cascades

---
-- Function SetDynamicInstancing
--
-- @function [parent=#Renderer] SetDynamicInstancing
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetMinInstances
--
-- @function [parent=#Renderer] SetMinInstances
-- @param self Self reference
-- @param #number instances instances

---
-- Function SetMaxInstanceTriangles
--
-- @function [parent=#Renderer] SetMaxInstanceTriangles
-- @param self Self reference
-- @param #number triangles triangles

---
-- Function SetMaxSortedInstances
--
-- @function [parent=#Renderer] SetMaxSortedInstances
-- @param self Self reference
-- @param #number instances instances

---
-- Function SetMaxOccluderTriangles
--
-- @function [parent=#Renderer] SetMaxOccluderTriangles
-- @param self Self reference
-- @param #number triangles triangles

---
-- Function SetOcclusionBufferSize
--
-- @function [parent=#Renderer] SetOcclusionBufferSize
-- @param self Self reference
-- @param #number size size

---
-- Function SetOccluderSizeThreshold
--
-- @function [parent=#Renderer] SetOccluderSizeThreshold
-- @param self Self reference
-- @param #number screenSize screenSize

---
-- Function ReloadShaders
--
-- @function [parent=#Renderer] ReloadShaders
-- @param self Self reference

---
-- Function GetNumViewports
--
-- @function [parent=#Renderer] GetNumViewports
-- @param self Self reference
-- @return #number

---
-- Function GetViewport
--
-- @function [parent=#Renderer] GetViewport
-- @param self Self reference
-- @param #number index index
-- @return Viewport#Viewport

---
-- Function GetDefaultRenderPath
--
-- @function [parent=#Renderer] GetDefaultRenderPath
-- @param self Self reference
-- @return RenderPath#RenderPath

---
-- Function GetHDRRendering
--
-- @function [parent=#Renderer] GetHDRRendering
-- @param self Self reference
-- @return #boolean

---
-- Function GetSpecularLighting
--
-- @function [parent=#Renderer] GetSpecularLighting
-- @param self Self reference
-- @return #boolean

---
-- Function GetDrawShadows
--
-- @function [parent=#Renderer] GetDrawShadows
-- @param self Self reference
-- @return #boolean

---
-- Function GetTextureAnisotropy
--
-- @function [parent=#Renderer] GetTextureAnisotropy
-- @param self Self reference
-- @return #number

---
-- Function GetTextureFilterMode
--
-- @function [parent=#Renderer] GetTextureFilterMode
-- @param self Self reference
-- @return TextureFilterMode#TextureFilterMode

---
-- Function GetTextureQuality
--
-- @function [parent=#Renderer] GetTextureQuality
-- @param self Self reference
-- @return #number

---
-- Function GetMaterialQuality
--
-- @function [parent=#Renderer] GetMaterialQuality
-- @param self Self reference
-- @return #number

---
-- Function GetShadowMapSize
--
-- @function [parent=#Renderer] GetShadowMapSize
-- @param self Self reference
-- @return #number

---
-- Function GetShadowQuality
--
-- @function [parent=#Renderer] GetShadowQuality
-- @param self Self reference
-- @return #number

---
-- Function GetReuseShadowMaps
--
-- @function [parent=#Renderer] GetReuseShadowMaps
-- @param self Self reference
-- @return #boolean

---
-- Function GetMaxShadowMaps
--
-- @function [parent=#Renderer] GetMaxShadowMaps
-- @param self Self reference
-- @return #number

---
-- Function GetMaxShadowCascades
--
-- @function [parent=#Renderer] GetMaxShadowCascades
-- @param self Self reference
-- @return #number

---
-- Function GetDynamicInstancing
--
-- @function [parent=#Renderer] GetDynamicInstancing
-- @param self Self reference
-- @return #boolean

---
-- Function GetMinInstances
--
-- @function [parent=#Renderer] GetMinInstances
-- @param self Self reference
-- @return #number

---
-- Function GetMaxInstanceTriangles
--
-- @function [parent=#Renderer] GetMaxInstanceTriangles
-- @param self Self reference
-- @return #number

---
-- Function GetMaxSortedInstances
--
-- @function [parent=#Renderer] GetMaxSortedInstances
-- @param self Self reference
-- @return #number

---
-- Function GetMaxOccluderTriangles
--
-- @function [parent=#Renderer] GetMaxOccluderTriangles
-- @param self Self reference
-- @return #number

---
-- Function GetOcclusionBufferSize
--
-- @function [parent=#Renderer] GetOcclusionBufferSize
-- @param self Self reference
-- @return #number

---
-- Function GetOccluderSizeThreshold
--
-- @function [parent=#Renderer] GetOccluderSizeThreshold
-- @param self Self reference
-- @return #number

---
-- Function GetNumViews
--
-- @function [parent=#Renderer] GetNumViews
-- @param self Self reference
-- @return #number

---
-- Function GetNumPrimitives
--
-- @function [parent=#Renderer] GetNumPrimitives
-- @param self Self reference
-- @return #number

---
-- Function GetNumBatches
--
-- @function [parent=#Renderer] GetNumBatches
-- @param self Self reference
-- @return #number

---
-- Function GetNumGeometries
--
-- @function [parent=#Renderer] GetNumGeometries
-- @param self Self reference
-- @param #boolean allViews allViews
-- @return #number

---
-- Function GetNumLights
--
-- @function [parent=#Renderer] GetNumLights
-- @param self Self reference
-- @param #boolean allViews allViews
-- @return #number

---
-- Function GetNumShadowMaps
--
-- @function [parent=#Renderer] GetNumShadowMaps
-- @param self Self reference
-- @param #boolean allViews allViews
-- @return #number

---
-- Function GetNumOccluders
--
-- @function [parent=#Renderer] GetNumOccluders
-- @param self Self reference
-- @param #boolean allViews allViews
-- @return #number

---
-- Function GetDefaultZone
--
-- @function [parent=#Renderer] GetDefaultZone
-- @param self Self reference
-- @return Zone#Zone

---
-- Function GetQuadDirLight
--
-- @function [parent=#Renderer] GetQuadDirLight
-- @param self Self reference
-- @return Light#Light

---
-- Function GetDefaultMaterial
--
-- @function [parent=#Renderer] GetDefaultMaterial
-- @param self Self reference
-- @return Material#Material

---
-- Function GetDefaultLightRamp
--
-- @function [parent=#Renderer] GetDefaultLightRamp
-- @param self Self reference
-- @return Texture2D#Texture2D

---
-- Function GetDefaultLightSpot
--
-- @function [parent=#Renderer] GetDefaultLightSpot
-- @param self Self reference
-- @return Texture2D#Texture2D

---
-- Function GetFaceSelectCubeMap
--
-- @function [parent=#Renderer] GetFaceSelectCubeMap
-- @param self Self reference
-- @return TextureCube#TextureCube

---
-- Function GetIndirectionCubeMap
--
-- @function [parent=#Renderer] GetIndirectionCubeMap
-- @param self Self reference
-- @return TextureCube#TextureCube

---
-- Function GetInstancingBuffer
--
-- @function [parent=#Renderer] GetInstancingBuffer
-- @param self Self reference
-- @return VertexBuffer#VertexBuffer

---
-- Function GetFrameInfo
--
-- @function [parent=#Renderer] GetFrameInfo
-- @param self Self reference
-- @return const FrameInfo#const FrameInfo

---
-- Function DrawDebugGeometry
--
-- @function [parent=#Renderer] DrawDebugGeometry
-- @param self Self reference
-- @param #boolean depthTest depthTest

---
-- Field numViewports
--
-- @field [parent=#Renderer] #number numViewports

---
-- Field defaultRenderPath
--
-- @field [parent=#Renderer] RenderPath#RenderPath defaultRenderPath

---
-- Field HDRRendering
--
-- @field [parent=#Renderer] #boolean HDRRendering

---
-- Field specularLighting
--
-- @field [parent=#Renderer] #boolean specularLighting

---
-- Field drawShadows
--
-- @field [parent=#Renderer] #boolean drawShadows

---
-- Field textureAnisotropy
--
-- @field [parent=#Renderer] #number textureAnisotropy

---
-- Field textureFilterMode
--
-- @field [parent=#Renderer] TextureFilterMode#TextureFilterMode textureFilterMode

---
-- Field textureQuality
--
-- @field [parent=#Renderer] #number textureQuality

---
-- Field materialQuality
--
-- @field [parent=#Renderer] #number materialQuality

---
-- Field shadowMapSize
--
-- @field [parent=#Renderer] #number shadowMapSize

---
-- Field shadowQuality
--
-- @field [parent=#Renderer] #number shadowQuality

---
-- Field reuseShadowMaps
--
-- @field [parent=#Renderer] #boolean reuseShadowMaps

---
-- Field maxShadowMaps
--
-- @field [parent=#Renderer] #number maxShadowMaps

---
-- Field maxShadowCascades
--
-- @field [parent=#Renderer] #number maxShadowCascades

---
-- Field dynamicInstancing
--
-- @field [parent=#Renderer] #boolean dynamicInstancing

---
-- Field minInstances
--
-- @field [parent=#Renderer] #number minInstances

---
-- Field maxInstanceTriangles
--
-- @field [parent=#Renderer] #number maxInstanceTriangles

---
-- Field maxSortedInstances
--
-- @field [parent=#Renderer] #number maxSortedInstances

---
-- Field maxOccluderTriangles
--
-- @field [parent=#Renderer] #number maxOccluderTriangles

---
-- Field occlusionBufferSize
--
-- @field [parent=#Renderer] #number occlusionBufferSize

---
-- Field occluderSizeThreshold
--
-- @field [parent=#Renderer] #number occluderSizeThreshold

---
-- Field numViews (Read only)
--
-- @field [parent=#Renderer] #number numViews

---
-- Field numPrimitives (Read only)
--
-- @field [parent=#Renderer] #number numPrimitives

---
-- Field numBatches (Read only)
--
-- @field [parent=#Renderer] #number numBatches

---
-- Field defaultZone (Read only)
--
-- @field [parent=#Renderer] Zone#Zone defaultZone

---
-- Field defaultMaterial (Read only)
--
-- @field [parent=#Renderer] Material#Material defaultMaterial

---
-- Field defaultLightRamp (Read only)
--
-- @field [parent=#Renderer] Texture2D#Texture2D defaultLightRamp

---
-- Field defaultLightSpot (Read only)
--
-- @field [parent=#Renderer] Texture2D#Texture2D defaultLightSpot


return nil
