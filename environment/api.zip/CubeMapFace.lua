---
-- Enumeration CubeMapFace
--
-- @module CubeMapFace

---
-- Enumeration value FACE_POSITIVE_X
--
-- @field [parent=#CubeMapFace] #number FACE_POSITIVE_X

---
-- Enumeration value FACE_NEGATIVE_X
--
-- @field [parent=#CubeMapFace] #number FACE_NEGATIVE_X

---
-- Enumeration value FACE_POSITIVE_Y
--
-- @field [parent=#CubeMapFace] #number FACE_POSITIVE_Y

---
-- Enumeration value FACE_NEGATIVE_Y
--
-- @field [parent=#CubeMapFace] #number FACE_NEGATIVE_Y

---
-- Enumeration value FACE_POSITIVE_Z
--
-- @field [parent=#CubeMapFace] #number FACE_POSITIVE_Z

---
-- Enumeration value FACE_NEGATIVE_Z
--
-- @field [parent=#CubeMapFace] #number FACE_NEGATIVE_Z

---
-- Enumeration value MAX_CUBEMAP_FACES
--
-- @field [parent=#CubeMapFace] #number MAX_CUBEMAP_FACES


return nil
