---
-- Module Sprite2D
-- Module Sprite2D extends Resource
-- Generated on 2014-05-31
--
-- @module Sprite2D

---
-- Function SetTexture()
-- Set texture.
--
-- @function [parent=#Sprite2D] SetTexture
-- @param self Self reference
-- @param Texture2D#Texture2D texture texture

---
-- Function SetRectangle()
-- Set rectangle.
--
-- @function [parent=#Sprite2D] SetRectangle
-- @param self Self reference
-- @param IntRect#IntRect rectangle rectangle

---
-- Function SetHotSpot()
-- Set hot spot.
--
-- @function [parent=#Sprite2D] SetHotSpot
-- @param self Self reference
-- @param Vector2#Vector2 hotSpot hotSpot

---
-- Function SetSpriteSheet()
-- Set sprite sheet.
--
-- @function [parent=#Sprite2D] SetSpriteSheet
-- @param self Self reference
-- @param SpriteSheet2D#SpriteSheet2D spriteSheet spriteSheet

---
-- Function GetTexture()
-- Return texture.
--
-- @function [parent=#Sprite2D] GetTexture
-- @param self Self reference
-- @return Texture2D#Texture2D

---
-- Function GetRectangle()
-- Return rectangle.
--
-- @function [parent=#Sprite2D] GetRectangle
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetHotSpot()
-- Return hot spot.
--
-- @function [parent=#Sprite2D] GetHotSpot
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Function GetSpriteSheet()
-- Return sprite sheet.
--
-- @function [parent=#Sprite2D] GetSpriteSheet
-- @param self Self reference
-- @return SpriteSheet2D#SpriteSheet2D

---
-- Field texture
--
-- @field [parent=#Sprite2D] Texture2D#Texture2D texture

---
-- Field rectangle
--
-- @field [parent=#Sprite2D] IntRect#IntRect rectangle

---
-- Field hotSpot
--
-- @field [parent=#Sprite2D] Vector2#Vector2 hotSpot

---
-- Field spriteSheet
--
-- @field [parent=#Sprite2D] SpriteSheet2D#SpriteSheet2D spriteSheet


return nil
