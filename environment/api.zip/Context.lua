---
-- Module Context
-- Generated on 2014-05-31
--
-- @module Context

---
-- Function GetEventSender()
-- Return active event sender. Null outside event handling.
--
-- @function [parent=#Context] GetEventSender
-- @param self Self reference
-- @return Object#Object

---
-- Function GetEventHandler()
-- Return active event handler. Set by Object. Null outside event handling.
--
-- @function [parent=#Context] GetEventHandler
-- @param self Self reference
-- @return EventHandler#EventHandler

---
-- Function GetTypeName()
-- Return object type name from hash, or empty if unknown.
--
-- @function [parent=#Context] GetTypeName
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash objectType objectType
-- @return const String#const String


return nil
