---
-- Module Context
--
-- @module Context

---
-- Function GetEventSender
--
-- @function [parent=#Context] GetEventSender
-- @return Object#Object

---
-- Function GetEventHandler
--
-- @function [parent=#Context] GetEventHandler
-- @return EventHandler#EventHandler

---
-- Function GetTypeName
--
-- @function [parent=#Context] GetTypeName
-- @param ShortStringHash#ShortStringHash objectTypeobjectType
-- @return const String#const String


return nil
