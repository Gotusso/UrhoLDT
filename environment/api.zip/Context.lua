---
-- Module Context
-- Generated on 2014-03-13
--
-- @module Context

---
-- Function GetEventSender
--
-- @function [parent=#Context] GetEventSender
-- @param self Self reference
-- @return Object#Object

---
-- Function GetEventHandler
--
-- @function [parent=#Context] GetEventHandler
-- @param self Self reference
-- @return EventHandler#EventHandler

---
-- Function GetTypeName
--
-- @function [parent=#Context] GetTypeName
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash objectType objectType
-- @return const String#const String


return nil
