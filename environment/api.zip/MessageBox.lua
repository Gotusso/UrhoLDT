---
-- Module MessageBox
-- Module MessageBox extends Object
-- Generated on 2014-05-31
--
-- @module MessageBox

---
-- Function MessageBox()
--
-- @function [parent=#MessageBox] MessageBox
-- @param self Self reference
-- @param #string messageString messageString
-- @param #string titleString titleString
-- @param XMLFile#XMLFile layoutFile layoutFile
-- @param XMLFile#XMLFile styleFile styleFile

---
-- Function new()
--
-- @function [parent=#MessageBox] new
-- @param self Self reference
-- @param #string messageString messageString
-- @param #string titleString titleString
-- @param XMLFile#XMLFile layoutFile layoutFile
-- @param XMLFile#XMLFile styleFile styleFile
-- @return MessageBox#MessageBox

---
-- Function delete()
--
-- @function [parent=#MessageBox] delete
-- @param self Self reference

---
-- Function SetTitle()
-- Set title text. No-ops if there is no title text element.
--
-- @function [parent=#MessageBox] SetTitle
-- @param self Self reference
-- @param #string text text

---
-- Function SetMessage()
-- Set message text. No-ops if there is no message text element.
--
-- @function [parent=#MessageBox] SetMessage
-- @param self Self reference
-- @param #string text text

---
-- Function GetTitle()
-- Return title text. Return empty string if there is no title text element.
--
-- @function [parent=#MessageBox] GetTitle
-- @param self Self reference
-- @return const String#const String

---
-- Function GetMessage()
-- Return message text. Return empty string if there is no message text element.
--
-- @function [parent=#MessageBox] GetMessage
-- @param self Self reference
-- @return const String#const String

---
-- Function GetWindow()
-- Return dialog window.
--
-- @function [parent=#MessageBox] GetWindow
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Field title
--
-- @field [parent=#MessageBox] #string title

---
-- Field message
--
-- @field [parent=#MessageBox] #string message

---
-- Field window (Read only)
--
-- @field [parent=#MessageBox] UIElement#UIElement window


return nil
