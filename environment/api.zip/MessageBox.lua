---
-- Module MessageBox
-- Module MessageBox extends Object
-- Generated on 2014-03-13
--
-- @module MessageBox

---
-- Function MessageBox
--
-- @function [parent=#MessageBox] MessageBox
-- @param self Self reference
-- @param #string messageString messageString
-- @param #string titleString titleString
-- @param XMLFile#XMLFile layoutFile layoutFile
-- @param XMLFile#XMLFile styleFile styleFile

---
-- Function new
--
-- @function [parent=#MessageBox] new
-- @param self Self reference
-- @param #string messageString messageString
-- @param #string titleString titleString
-- @param XMLFile#XMLFile layoutFile layoutFile
-- @param XMLFile#XMLFile styleFile styleFile
-- @return MessageBox#MessageBox

---
-- Function delete
--
-- @function [parent=#MessageBox] delete
-- @param self Self reference

---
-- Function SetTitle
--
-- @function [parent=#MessageBox] SetTitle
-- @param self Self reference
-- @param #string text text

---
-- Function SetMessage
--
-- @function [parent=#MessageBox] SetMessage
-- @param self Self reference
-- @param #string text text

---
-- Function GetTitle
--
-- @function [parent=#MessageBox] GetTitle
-- @param self Self reference
-- @return const String#const String

---
-- Function GetMessage
--
-- @function [parent=#MessageBox] GetMessage
-- @param self Self reference
-- @return const String#const String

---
-- Function GetWindow
--
-- @function [parent=#MessageBox] GetWindow
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Field title
--
-- @field [parent=#MessageBox] #string title

---
-- Field message
--
-- @field [parent=#MessageBox] #string message

---
-- Field window (Read only)
--
-- @field [parent=#MessageBox] UIElement#UIElement window

---
-- Function GetType
--
-- @function [parent=#MessageBox] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#MessageBox] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#MessageBox] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#MessageBox] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#MessageBox] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#MessageBox] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#MessageBox] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#MessageBox] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#MessageBox] #string category


return nil
