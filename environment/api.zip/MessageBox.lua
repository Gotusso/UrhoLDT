---
-- Module MessageBox
-- Extends Object
--
-- @module MessageBox

---
-- Function MessageBox
--
-- @function [parent=#MessageBox] MessageBox
-- @param #string messageStringmessageString
-- @param #string titleStringtitleString
-- @param XMLFile#XMLFile layoutFilelayoutFile
-- @param XMLFile#XMLFile styleFilestyleFile

---
-- Function new
--
-- @function [parent=#MessageBox] new
-- @param #string messageStringmessageString
-- @param #string titleStringtitleString
-- @param XMLFile#XMLFile layoutFilelayoutFile
-- @param XMLFile#XMLFile styleFilestyleFile
-- @return MessageBox#MessageBox

---
-- Function delete
--
-- @function [parent=#MessageBox] delete

---
-- Function SetTitle
--
-- @function [parent=#MessageBox] SetTitle
-- @param #string texttext

---
-- Function SetMessage
--
-- @function [parent=#MessageBox] SetMessage
-- @param #string texttext

---
-- Function GetTitle
--
-- @function [parent=#MessageBox] GetTitle
-- @return const String#const String

---
-- Function GetMessage
--
-- @function [parent=#MessageBox] GetMessage
-- @return const String#const String

---
-- Function GetWindow
--
-- @function [parent=#MessageBox] GetWindow
-- @return UIElement#UIElement

---
-- Field title
--
-- @field [parent=#MessageBox] #string title

---
-- Field message
--
-- @field [parent=#MessageBox] #string message

---
-- Field window (Read only)
--
-- @field [parent=#MessageBox] UIElement#UIElement window


return nil
