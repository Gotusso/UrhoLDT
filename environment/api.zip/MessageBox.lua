---
-- Module MessageBox
-- extends Object
--
-- @module MessageBox

---
-- Function MessageBox
--
-- @function [parent=#MessageBox] MessageBox
-- @param #string messageStringmessageString
-- @param #string titleStringtitleString
-- @param XMLFile#XMLFile layoutFilelayoutFile
-- @param XMLFile#XMLFile styleFilestyleFile

---
-- Function new
--
-- @function [parent=#MessageBox] new
-- @param #string messageStringmessageString
-- @param #string titleStringtitleString
-- @param XMLFile#XMLFile layoutFilelayoutFile
-- @param XMLFile#XMLFile styleFilestyleFile
-- @return MessageBox#MessageBox

---
-- Function delete
--
-- @function [parent=#MessageBox] delete

---
-- Function SetTitle
--
-- @function [parent=#MessageBox] SetTitle
-- @param #string texttext

---
-- Function SetMessage
--
-- @function [parent=#MessageBox] SetMessage
-- @param #string texttext

---
-- Function GetTitle
--
-- @function [parent=#MessageBox] GetTitle
-- @return const String#const String

---
-- Function GetMessage
--
-- @function [parent=#MessageBox] GetMessage
-- @return const String#const String

---
-- Function GetWindow
--
-- @function [parent=#MessageBox] GetWindow
-- @return UIElement#UIElement

---
-- Field title
--
-- @field [parent=#MessageBox] #string title

---
-- Field message
--
-- @field [parent=#MessageBox] #string message

---
-- Field window (Read only)
--
-- @field [parent=#MessageBox] UIElement#UIElement window

---
-- Function GetType
--
-- @function [parent=#MessageBox] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#MessageBox] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#MessageBox] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#MessageBox] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#MessageBox] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#MessageBox] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#MessageBox] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#MessageBox] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#MessageBox] #string category


return nil
