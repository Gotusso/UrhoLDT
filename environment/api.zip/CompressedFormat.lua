---
-- Enumeration CompressedFormat
--
-- @module CompressedFormat

---
-- Enumeration value CF_NONE
--
-- @field [parent=#CompressedFormat] #number CF_NONE

---
-- Enumeration value CF_DXT1
--
-- @field [parent=#CompressedFormat] #number CF_DXT1

---
-- Enumeration value CF_DXT3
--
-- @field [parent=#CompressedFormat] #number CF_DXT3

---
-- Enumeration value CF_DXT5
--
-- @field [parent=#CompressedFormat] #number CF_DXT5

---
-- Enumeration value CF_ETC1
--
-- @field [parent=#CompressedFormat] #number CF_ETC1

---
-- Enumeration value CF_PVRTC_RGB_2BPP
--
-- @field [parent=#CompressedFormat] #number CF_PVRTC_RGB_2BPP

---
-- Enumeration value CF_PVRTC_RGBA_2BPP
--
-- @field [parent=#CompressedFormat] #number CF_PVRTC_RGBA_2BPP

---
-- Enumeration value CF_PVRTC_RGB_4BPP
--
-- @field [parent=#CompressedFormat] #number CF_PVRTC_RGB_4BPP

---
-- Enumeration value CF_PVRTC_RGBA_4BPP
--
-- @field [parent=#CompressedFormat] #number CF_PVRTC_RGBA_4BPP


return nil
