---
-- Enumeration StencilOp
--
-- @module StencilOp

---
-- Enumeration value OP_KEEP
--
-- @field [parent=#StencilOp] #number OP_KEEP

---
-- Enumeration value OP_ZERO
--
-- @field [parent=#StencilOp] #number OP_ZERO

---
-- Enumeration value OP_REF
--
-- @field [parent=#StencilOp] #number OP_REF

---
-- Enumeration value OP_INCR
--
-- @field [parent=#StencilOp] #number OP_INCR

---
-- Enumeration value OP_DECR
--
-- @field [parent=#StencilOp] #number OP_DECR


return nil
