---
-- Enumeration Intersection
--
-- @module Intersection

---
-- Enumeration value OUTSIDE
--
-- @field [parent=#Intersection] #number OUTSIDE

---
-- Enumeration value INTERSECTS
--
-- @field [parent=#Intersection] #number INTERSECTS

---
-- Enumeration value INSIDE
--
-- @field [parent=#Intersection] #number INSIDE


return nil
