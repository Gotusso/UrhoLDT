---
-- Module PhysicsRaycastResult
-- Generated on 2014-03-13
--
-- @module PhysicsRaycastResult

---
-- Function PhysicsRaycastResult
--
-- @function [parent=#PhysicsRaycastResult] PhysicsRaycastResult
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#PhysicsRaycastResult] new
-- @param self Self reference
-- @return PhysicsRaycastResult#PhysicsRaycastResult

---
-- Function delete
--
-- @function [parent=#PhysicsRaycastResult] delete
-- @param self Self reference

---
-- Field position
--
-- @field [parent=#PhysicsRaycastResult] Vector3#Vector3 position

---
-- Field normal
--
-- @field [parent=#PhysicsRaycastResult] Vector3#Vector3 normal

---
-- Field distance
--
-- @field [parent=#PhysicsRaycastResult] #number distance

---
-- Field body
--
-- @field [parent=#PhysicsRaycastResult] RigidBody#RigidBody body


return nil
