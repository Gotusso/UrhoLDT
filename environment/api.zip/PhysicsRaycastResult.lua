---
-- Module PhysicsRaycastResult
--
-- @module PhysicsRaycastResult

---
-- Function PhysicsRaycastResult
--
-- @function [parent=#PhysicsRaycastResult] PhysicsRaycastResult

---
-- Function new
--
-- @function [parent=#PhysicsRaycastResult] new
-- @return PhysicsRaycastResult#PhysicsRaycastResult

---
-- Function delete
--
-- @function [parent=#PhysicsRaycastResult] delete

---
-- Field position
--
-- @field [parent=#PhysicsRaycastResult] Vector3#Vector3 position

---
-- Field normal
--
-- @field [parent=#PhysicsRaycastResult] Vector3#Vector3 normal

---
-- Field distance
--
-- @field [parent=#PhysicsRaycastResult] #number distance

---
-- Field body
--
-- @field [parent=#PhysicsRaycastResult] RigidBody#RigidBody body


return nil
