---
-- Enumeration HighlightMode
--
-- @module HighlightMode

---
-- Enumeration value HM_NEVER
--
-- @field [parent=#HighlightMode] #number HM_NEVER

---
-- Enumeration value HM_FOCUS
--
-- @field [parent=#HighlightMode] #number HM_FOCUS

---
-- Enumeration value HM_ALWAYS
--
-- @field [parent=#HighlightMode] #number HM_ALWAYS


return nil
