---
-- Module FileWatcher
-- Module FileWatcher extends Object
-- Generated on 2014-03-13
--
-- @module FileWatcher

---
-- Function StartWatching
--
-- @function [parent=#FileWatcher] StartWatching
-- @param self Self reference
-- @param #string pathName pathName
-- @param #boolean watchSubDirs watchSubDirs
-- @return #boolean

---
-- Function StopWatching
--
-- @function [parent=#FileWatcher] StopWatching
-- @param self Self reference

---
-- Function AddChange
--
-- @function [parent=#FileWatcher] AddChange
-- @param self Self reference
-- @param #string fileName fileName

---
-- Function GetPath
--
-- @function [parent=#FileWatcher] GetPath
-- @param self Self reference
-- @return const String#const String

---
-- Function GetType
--
-- @function [parent=#FileWatcher] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#FileWatcher] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#FileWatcher] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#FileWatcher] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#FileWatcher] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#FileWatcher] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#FileWatcher] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#FileWatcher] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#FileWatcher] #string category


return nil
