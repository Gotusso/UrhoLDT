---
-- Module FileWatcher
-- Extends Object
--
-- @module FileWatcher

---
-- Function StartWatching
--
-- @function [parent=#FileWatcher] StartWatching
-- @param #string pathNamepathName
-- @param #boolean watchSubDirswatchSubDirs
-- @return #boolean

---
-- Function StopWatching
--
-- @function [parent=#FileWatcher] StopWatching

---
-- Function AddChange
--
-- @function [parent=#FileWatcher] AddChange
-- @param #string fileNamefileName

---
-- Function GetPath
--
-- @function [parent=#FileWatcher] GetPath
-- @return const String#const String


return nil
