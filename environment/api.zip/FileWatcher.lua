---
-- Module FileWatcher
-- extends Object
--
-- @module FileWatcher

---
-- Function StartWatching
--
-- @function [parent=#FileWatcher] StartWatching
-- @param #string pathNamepathName
-- @param #boolean watchSubDirswatchSubDirs
-- @return #boolean

---
-- Function StopWatching
--
-- @function [parent=#FileWatcher] StopWatching

---
-- Function AddChange
--
-- @function [parent=#FileWatcher] AddChange
-- @param #string fileNamefileName

---
-- Function GetPath
--
-- @function [parent=#FileWatcher] GetPath
-- @return const String#const String

---
-- Function GetType
--
-- @function [parent=#FileWatcher] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#FileWatcher] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#FileWatcher] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#FileWatcher] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#FileWatcher] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#FileWatcher] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#FileWatcher] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#FileWatcher] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#FileWatcher] #string category


return nil
