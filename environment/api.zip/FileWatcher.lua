---
-- Module FileWatcher
-- Module FileWatcher extends Object
-- Generated on 2014-05-31
--
-- @module FileWatcher

---
-- Function StartWatching()
-- Start watching a directory. Return true if successful.
--
-- @function [parent=#FileWatcher] StartWatching
-- @param self Self reference
-- @param #string pathName pathName
-- @param #boolean watchSubDirs watchSubDirs
-- @return #boolean

---
-- Function StopWatching()
-- Stop watching the directory.
--
-- @function [parent=#FileWatcher] StopWatching
-- @param self Self reference

---
-- Function AddChange()
-- Add a file change into the changes queue.
--
-- @function [parent=#FileWatcher] AddChange
-- @param self Self reference
-- @param #string fileName fileName

---
-- Function GetPath()
-- Return the path being watched, or empty if not watching.
--
-- @function [parent=#FileWatcher] GetPath
-- @param self Self reference
-- @return const String#const String


return nil
