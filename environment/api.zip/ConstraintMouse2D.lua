---
-- Module ConstraintMouse2D
-- Module ConstraintMouse2D extends Constraint2D
-- Generated on 2014-05-31
--
-- @module ConstraintMouse2D

---
-- Function SetTarget()
-- Set target.
--
-- @function [parent=#ConstraintMouse2D] SetTarget
-- @param self Self reference
-- @param Vector2#Vector2 target target

---
-- Function SetMaxForce()
-- Set max force.
--
-- @function [parent=#ConstraintMouse2D] SetMaxForce
-- @param self Self reference
-- @param #number maxForce maxForce

---
-- Function SetFrequencyHz()
-- Set frequency Hz.
--
-- @function [parent=#ConstraintMouse2D] SetFrequencyHz
-- @param self Self reference
-- @param #number frequencyHz frequencyHz

---
-- Function SetDampingRatio()
-- Set damping ratio.
--
-- @function [parent=#ConstraintMouse2D] SetDampingRatio
-- @param self Self reference
-- @param #number dampingRatio dampingRatio

---
-- Function GetTarget()
-- Return target.
--
-- @function [parent=#ConstraintMouse2D] GetTarget
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Function GetMaxForce()
-- Return max force.
--
-- @function [parent=#ConstraintMouse2D] GetMaxForce
-- @param self Self reference
-- @return #number

---
-- Function GetFrequencyHz()
-- Return frequency Hz.
--
-- @function [parent=#ConstraintMouse2D] GetFrequencyHz
-- @param self Self reference
-- @return #number

---
-- Function GetDampingRatio()
-- Return damping ratio.
--
-- @function [parent=#ConstraintMouse2D] GetDampingRatio
-- @param self Self reference
-- @return #number

---
-- Field target
--
-- @field [parent=#ConstraintMouse2D] Vector2#Vector2 target

---
-- Field maxForce
--
-- @field [parent=#ConstraintMouse2D] #number maxForce

---
-- Field frequencyHz
--
-- @field [parent=#ConstraintMouse2D] #number frequencyHz

---
-- Field dampingRatio
--
-- @field [parent=#ConstraintMouse2D] #number dampingRatio


return nil
