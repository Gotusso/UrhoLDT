---
-- Enumeration TextureAddressMode
--
-- @module TextureAddressMode

---
-- Enumeration value ADDRESS_WRAP
--
-- @field [parent=#TextureAddressMode] #number ADDRESS_WRAP

---
-- Enumeration value ADDRESS_MIRROR
--
-- @field [parent=#TextureAddressMode] #number ADDRESS_MIRROR

---
-- Enumeration value ADDRESS_CLAMP
--
-- @field [parent=#TextureAddressMode] #number ADDRESS_CLAMP

---
-- Enumeration value ADDRESS_BORDER
--
-- @field [parent=#TextureAddressMode] #number ADDRESS_BORDER

---
-- Enumeration value MAX_ADDRESSMODES
--
-- @field [parent=#TextureAddressMode] #number MAX_ADDRESSMODES


return nil
