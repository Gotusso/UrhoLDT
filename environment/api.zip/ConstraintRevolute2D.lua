---
-- Module ConstraintRevolute2D
-- Module ConstraintRevolute2D extends Constraint2D
-- Generated on 2014-05-31
--
-- @module ConstraintRevolute2D

---
-- Function SetAnchor()
-- Set anchor.
--
-- @function [parent=#ConstraintRevolute2D] SetAnchor
-- @param self Self reference
-- @param Vector2#Vector2 anchor anchor

---
-- Function SetEnableLimit()
-- Set enable limit.
--
-- @function [parent=#ConstraintRevolute2D] SetEnableLimit
-- @param self Self reference
-- @param #boolean enableLimit enableLimit

---
-- Function SetLowerAngle()
-- Set lower angle.
--
-- @function [parent=#ConstraintRevolute2D] SetLowerAngle
-- @param self Self reference
-- @param #number lowerAngle lowerAngle

---
-- Function SetUpperAngle()
-- Set upper angle.
--
-- @function [parent=#ConstraintRevolute2D] SetUpperAngle
-- @param self Self reference
-- @param #number upperAngle upperAngle

---
-- Function SetEnableMotor()
-- Set enable motor.
--
-- @function [parent=#ConstraintRevolute2D] SetEnableMotor
-- @param self Self reference
-- @param #boolean enableMotor enableMotor

---
-- Function SetMotorSpeed()
-- Set motor speed.
--
-- @function [parent=#ConstraintRevolute2D] SetMotorSpeed
-- @param self Self reference
-- @param #number motorSpeed motorSpeed

---
-- Function SetMaxMotorTorque()
-- Set max motor torque.
--
-- @function [parent=#ConstraintRevolute2D] SetMaxMotorTorque
-- @param self Self reference
-- @param #number maxMotorTorque maxMotorTorque

---
-- Function GetAnchor()
-- Return anchor.
--
-- @function [parent=#ConstraintRevolute2D] GetAnchor
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Function GetEnableLimit()
-- Return enable limit.
--
-- @function [parent=#ConstraintRevolute2D] GetEnableLimit
-- @param self Self reference
-- @return #boolean

---
-- Function GetLowerAngle()
-- Return lower angle.
--
-- @function [parent=#ConstraintRevolute2D] GetLowerAngle
-- @param self Self reference
-- @return #number

---
-- Function GetUpperAngle()
-- Return upper angle.
--
-- @function [parent=#ConstraintRevolute2D] GetUpperAngle
-- @param self Self reference
-- @return #number

---
-- Function GetEnableMotor()
-- Return enable motor.
--
-- @function [parent=#ConstraintRevolute2D] GetEnableMotor
-- @param self Self reference
-- @return #boolean

---
-- Function GetMotorSpeed()
-- Return motor speed.
--
-- @function [parent=#ConstraintRevolute2D] GetMotorSpeed
-- @param self Self reference
-- @return #number

---
-- Function GetMaxMotorTorque()
-- Return max motor torque.
--
-- @function [parent=#ConstraintRevolute2D] GetMaxMotorTorque
-- @param self Self reference
-- @return #number

---
-- Field anchor
--
-- @field [parent=#ConstraintRevolute2D] Vector2#Vector2 anchor

---
-- Field enableLimit
--
-- @field [parent=#ConstraintRevolute2D] #boolean enableLimit

---
-- Field lowerAngle
--
-- @field [parent=#ConstraintRevolute2D] #number lowerAngle

---
-- Field upperAngle
--
-- @field [parent=#ConstraintRevolute2D] #number upperAngle

---
-- Field enableMotor
--
-- @field [parent=#ConstraintRevolute2D] #boolean enableMotor

---
-- Field motorSpeed
--
-- @field [parent=#ConstraintRevolute2D] #number motorSpeed

---
-- Field maxMotorTorque
--
-- @field [parent=#ConstraintRevolute2D] #number maxMotorTorque


return nil
