---
-- Module RayQueryResult
--
-- @module RayQueryResult

---
-- Function RayQueryResult
--
-- @function [parent=#RayQueryResult] RayQueryResult

---
-- Function new
--
-- @function [parent=#RayQueryResult] new
-- @return RayQueryResult#RayQueryResult

---
-- Function delete
--
-- @function [parent=#RayQueryResult] delete

---
-- Field position
--
-- @field [parent=#RayQueryResult] Vector3#Vector3 position

---
-- Field normal
--
-- @field [parent=#RayQueryResult] Vector3#Vector3 normal

---
-- Field distance
--
-- @field [parent=#RayQueryResult] #number distance

---
-- Field drawable
--
-- @field [parent=#RayQueryResult] Drawable#Drawable drawable

---
-- Field node
--
-- @field [parent=#RayQueryResult] Node#Node node

---
-- Field subObject
--
-- @field [parent=#RayQueryResult] #number subObject


return nil
