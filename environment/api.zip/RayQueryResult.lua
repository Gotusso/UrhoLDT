---
-- Module RayQueryResult
-- Generated on 2014-05-31
--
-- @module RayQueryResult

---
-- Function RayQueryResult()
--
-- @function [parent=#RayQueryResult] RayQueryResult
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#RayQueryResult] new
-- @param self Self reference
-- @return RayQueryResult#RayQueryResult

---
-- Function delete()
--
-- @function [parent=#RayQueryResult] delete
-- @param self Self reference

---
-- Field position
--
-- @field [parent=#RayQueryResult] Vector3#Vector3 position

---
-- Field normal
--
-- @field [parent=#RayQueryResult] Vector3#Vector3 normal

---
-- Field distance
--
-- @field [parent=#RayQueryResult] #number distance

---
-- Field drawable
--
-- @field [parent=#RayQueryResult] Drawable#Drawable drawable

---
-- Field node
--
-- @field [parent=#RayQueryResult] Node#Node node

---
-- Field subObject
--
-- @field [parent=#RayQueryResult] #number subObject


return nil
