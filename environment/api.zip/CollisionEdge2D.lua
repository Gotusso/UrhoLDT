---
-- Module CollisionEdge2D
-- Module CollisionEdge2D extends CollisionShape2D
-- Generated on 2014-05-31
--
-- @module CollisionEdge2D

---
-- Function SetVertex1()
-- Set vertex 1.
--
-- @function [parent=#CollisionEdge2D] SetVertex1
-- @param self Self reference
-- @param Vector2#Vector2 vertex vertex

---
-- Function SetVertex2()
-- Set vertex 2.
--
-- @function [parent=#CollisionEdge2D] SetVertex2
-- @param self Self reference
-- @param Vector2#Vector2 vertex vertex

---
-- Function SetVertices()
-- Set vertices.
--
-- @function [parent=#CollisionEdge2D] SetVertices
-- @param self Self reference
-- @param Vector2#Vector2 vertex1 vertex1
-- @param Vector2#Vector2 vertex2 vertex2

---
-- Function GetVertex1()
-- Return vertex 1.
--
-- @function [parent=#CollisionEdge2D] GetVertex1
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Function GetVertex2()
-- Return vertex 2.
--
-- @function [parent=#CollisionEdge2D] GetVertex2
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Field vertex1
--
-- @field [parent=#CollisionEdge2D] Vector2#Vector2 vertex1

---
-- Field vertex2
--
-- @field [parent=#CollisionEdge2D] Vector2#Vector2 vertex2


return nil
