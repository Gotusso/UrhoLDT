---
-- Module AnimationController
-- Module AnimationController extends Component
-- Generated on 2014-05-31
--
-- @module AnimationController

---
-- Function Play()
--
-- @function [parent=#AnimationController] Play
-- @param self Self reference
-- @param #string name name
-- @param #string layer layer
-- @param #boolean looped looped
-- @param #number fadeInTime fadeInTime
-- @return #boolean

---
-- Function PlayExclusive()
--
-- @function [parent=#AnimationController] PlayExclusive
-- @param self Self reference
-- @param #string name name
-- @param #string layer layer
-- @param #boolean looped looped
-- @param #number fadeTime fadeTime
-- @return #boolean

---
-- Function Stop()
-- Stop an animation. Zero fadetime is instant. Return true on success.
--
-- @function [parent=#AnimationController] Stop
-- @param self Self reference
-- @param #string name name
-- @param #number fadeOutTime fadeOutTime
-- @return #boolean

---
-- Function StopLayer()
--
-- @function [parent=#AnimationController] StopLayer
-- @param self Self reference
-- @param #string layer layer
-- @param #number fadeOutTime fadeOutTime

---
-- Function StopAll()
-- Stop all animations. Zero fadetime is instant.
--
-- @function [parent=#AnimationController] StopAll
-- @param self Self reference
-- @param #number fadeTime fadeTime

---
-- Function Fade()
-- Fade animation to target weight. Return true on success.
--
-- @function [parent=#AnimationController] Fade
-- @param self Self reference
-- @param #string name name
-- @param #number targetWeight targetWeight
-- @param #number fadeTime fadeTime
-- @return #boolean

---
-- Function FadeOthers()
-- Fade other animations on the same layer to target weight. Return true on success.
--
-- @function [parent=#AnimationController] FadeOthers
-- @param self Self reference
-- @param #string name name
-- @param #number targetWeight targetWeight
-- @param #number fadeTime fadeTime
-- @return #boolean

---
-- Function SetLayer()
--
-- @function [parent=#AnimationController] SetLayer
-- @param self Self reference
-- @param #string name name
-- @param #string layer layer
-- @return #boolean

---
-- Function SetStartBone()
-- Set animation start bone. Return true on success.
--
-- @function [parent=#AnimationController] SetStartBone
-- @param self Self reference
-- @param #string name name
-- @param #string startBoneName startBoneName
-- @return #boolean

---
-- Function SetTime()
-- Set animation time position. Return true on success.
--
-- @function [parent=#AnimationController] SetTime
-- @param self Self reference
-- @param #string name name
-- @param #number time time
-- @return #boolean

---
-- Function SetWeight()
-- Set animation weight. Return true on success.
--
-- @function [parent=#AnimationController] SetWeight
-- @param self Self reference
-- @param #string name name
-- @param #number weight weight
-- @return #boolean

---
-- Function SetLooped()
-- Set animation looping. Return true on success.
--
-- @function [parent=#AnimationController] SetLooped
-- @param self Self reference
-- @param #string name name
-- @param #boolean enable enable
-- @return #boolean

---
-- Function SetSpeed()
-- Set animation speed. Return true on success.
--
-- @function [parent=#AnimationController] SetSpeed
-- @param self Self reference
-- @param #string name name
-- @param #number speed speed
-- @return #boolean

---
-- Function SetAutoFade()
-- Set animation autofade on stop (non-looped animations only.) Zero time disables. Return true on success.
--
-- @function [parent=#AnimationController] SetAutoFade
-- @param self Self reference
-- @param #string name name
-- @param #number fadeOutTime fadeOutTime
-- @return #boolean

---
-- Function IsPlaying()
-- Return whether an animation is active.
--
-- @function [parent=#AnimationController] IsPlaying
-- @param self Self reference
-- @param #string name name
-- @return #boolean

---
-- Function IsFadingIn()
-- Return whether an animation is fading in.
--
-- @function [parent=#AnimationController] IsFadingIn
-- @param self Self reference
-- @param #string name name
-- @return #boolean

---
-- Function IsFadingOut()
-- Return whether an animation is fading out.
--
-- @function [parent=#AnimationController] IsFadingOut
-- @param self Self reference
-- @param #string name name
-- @return #boolean

---
-- Function GetLayer()
-- Return animation blending layer.
--
-- @function [parent=#AnimationController] GetLayer
-- @param self Self reference
-- @param #string name name
-- @return #string

---
-- Function GetStartBone()
-- Return animation start bone, or null if no such animation.
--
-- @function [parent=#AnimationController] GetStartBone
-- @param self Self reference
-- @param #string name name
-- @return Bone#Bone

---
-- Function GetStartBoneName()
-- Return animation start bone name, or empty string if no such animation.
--
-- @function [parent=#AnimationController] GetStartBoneName
-- @param self Self reference
-- @param #string name name
-- @return const String#const String

---
-- Function GetTime()
-- Return animation time position.
--
-- @function [parent=#AnimationController] GetTime
-- @param self Self reference
-- @param #string name name
-- @return #number

---
-- Function GetWeight()
-- Return animation weight.
--
-- @function [parent=#AnimationController] GetWeight
-- @param self Self reference
-- @param #string name name
-- @return #number

---
-- Function IsLooped()
-- Return animation looping.
--
-- @function [parent=#AnimationController] IsLooped
-- @param self Self reference
-- @param #string name name
-- @return #boolean

---
-- Function GetLength()
-- Return animation length.
--
-- @function [parent=#AnimationController] GetLength
-- @param self Self reference
-- @param #string name name
-- @return #number

---
-- Function GetSpeed()
-- Return animation speed.
--
-- @function [parent=#AnimationController] GetSpeed
-- @param self Self reference
-- @param #string name name
-- @return #number

---
-- Function GetFadeTarget()
-- Return animation fade target weight.
--
-- @function [parent=#AnimationController] GetFadeTarget
-- @param self Self reference
-- @param #string name name
-- @return #number

---
-- Function GetFadeTime()
-- Return animation fade time.
--
-- @function [parent=#AnimationController] GetFadeTime
-- @param self Self reference
-- @param #string name name
-- @return #number

---
-- Function GetAutoFade()
-- Return animation autofade time.
--
-- @function [parent=#AnimationController] GetAutoFade
-- @param self Self reference
-- @param #string name name
-- @return #number

---
-- Function GetAnimationState()
-- Find an animation state by animation name.
--
-- @function [parent=#AnimationController] GetAnimationState
-- @param self Self reference
-- @param #string name name
-- @return AnimationState#AnimationState

---
-- Function GetAnimationState()
-- Find an animation state by animation name hash
--
-- @function [parent=#AnimationController] GetAnimationState
-- @param self Self reference
-- @param StringHash#StringHash nameHash nameHash
-- @return AnimationState#AnimationState


return nil
