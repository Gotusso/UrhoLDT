---
-- Module AnimationController
-- Extends Component
--
-- @module AnimationController

---
-- Function Play
--
-- @function [parent=#AnimationController] Play
-- @param #string namename
-- @param #string layerlayer
-- @param #boolean loopedlooped
-- @param #number fadeInTimefadeInTime
-- @return #boolean

---
-- Function PlayExclusive
--
-- @function [parent=#AnimationController] PlayExclusive
-- @param #string namename
-- @param #string layerlayer
-- @param #boolean loopedlooped
-- @param #number fadeTimefadeTime
-- @return #boolean

---
-- Function Stop
--
-- @function [parent=#AnimationController] Stop
-- @param #string namename
-- @param #number fadeOutTimefadeOutTime
-- @return #boolean

---
-- Function StopLayer
--
-- @function [parent=#AnimationController] StopLayer
-- @param #string layerlayer
-- @param #number fadeOutTimefadeOutTime

---
-- Function StopAll
--
-- @function [parent=#AnimationController] StopAll
-- @param #number fadeTimefadeTime

---
-- Function Fade
--
-- @function [parent=#AnimationController] Fade
-- @param #string namename
-- @param #number targetWeighttargetWeight
-- @param #number fadeTimefadeTime
-- @return #boolean

---
-- Function FadeOthers
--
-- @function [parent=#AnimationController] FadeOthers
-- @param #string namename
-- @param #number targetWeighttargetWeight
-- @param #number fadeTimefadeTime
-- @return #boolean

---
-- Function SetLayer
--
-- @function [parent=#AnimationController] SetLayer
-- @param #string namename
-- @param #string layerlayer
-- @return #boolean

---
-- Function SetStartBone
--
-- @function [parent=#AnimationController] SetStartBone
-- @param #string namename
-- @param #string startBoneNamestartBoneName
-- @return #boolean

---
-- Function SetTime
--
-- @function [parent=#AnimationController] SetTime
-- @param #string namename
-- @param #number timetime
-- @return #boolean

---
-- Function SetWeight
--
-- @function [parent=#AnimationController] SetWeight
-- @param #string namename
-- @param #number weightweight
-- @return #boolean

---
-- Function SetLooped
--
-- @function [parent=#AnimationController] SetLooped
-- @param #string namename
-- @param #boolean enableenable
-- @return #boolean

---
-- Function SetSpeed
--
-- @function [parent=#AnimationController] SetSpeed
-- @param #string namename
-- @param #number speedspeed
-- @return #boolean

---
-- Function SetAutoFade
--
-- @function [parent=#AnimationController] SetAutoFade
-- @param #string namename
-- @param #number fadeOutTimefadeOutTime
-- @return #boolean

---
-- Function IsPlaying
--
-- @function [parent=#AnimationController] IsPlaying
-- @param #string namename
-- @return #boolean

---
-- Function IsFadingIn
--
-- @function [parent=#AnimationController] IsFadingIn
-- @param #string namename
-- @return #boolean

---
-- Function IsFadingOut
--
-- @function [parent=#AnimationController] IsFadingOut
-- @param #string namename
-- @return #boolean

---
-- Function GetLayer
--
-- @function [parent=#AnimationController] GetLayer
-- @param #string namename
-- @return #string

---
-- Function GetStartBone
--
-- @function [parent=#AnimationController] GetStartBone
-- @param #string namename
-- @return Bone#Bone

---
-- Function GetStartBoneName
--
-- @function [parent=#AnimationController] GetStartBoneName
-- @param #string namename
-- @return const String#const String

---
-- Function GetTime
--
-- @function [parent=#AnimationController] GetTime
-- @param #string namename
-- @return #number

---
-- Function GetWeight
--
-- @function [parent=#AnimationController] GetWeight
-- @param #string namename
-- @return #number

---
-- Function IsLooped
--
-- @function [parent=#AnimationController] IsLooped
-- @param #string namename
-- @return #boolean

---
-- Function GetLength
--
-- @function [parent=#AnimationController] GetLength
-- @param #string namename
-- @return #number

---
-- Function GetSpeed
--
-- @function [parent=#AnimationController] GetSpeed
-- @param #string namename
-- @return #number

---
-- Function GetFadeTarget
--
-- @function [parent=#AnimationController] GetFadeTarget
-- @param #string namename
-- @return #number

---
-- Function GetFadeTime
--
-- @function [parent=#AnimationController] GetFadeTime
-- @param #string namename
-- @return #number

---
-- Function GetAutoFade
--
-- @function [parent=#AnimationController] GetAutoFade
-- @param #string namename
-- @return #number

---
-- Function GetAnimationState
--
-- @function [parent=#AnimationController] GetAnimationState
-- @param #string namename
-- @return AnimationState#AnimationState

---
-- Function GetAnimationState
--
-- @function [parent=#AnimationController] GetAnimationState
-- @param StringHash#StringHash nameHashnameHash
-- @return AnimationState#AnimationState


return nil
