---
-- Module AnimationController
-- Module AnimationController extends Component
-- Generated on 2014-03-13
--
-- @module AnimationController

---
-- Function Play
--
-- @function [parent=#AnimationController] Play
-- @param self Self reference
-- @param #string name name
-- @param #string layer layer
-- @param #boolean looped looped
-- @param #number fadeInTime fadeInTime
-- @return #boolean

---
-- Function PlayExclusive
--
-- @function [parent=#AnimationController] PlayExclusive
-- @param self Self reference
-- @param #string name name
-- @param #string layer layer
-- @param #boolean looped looped
-- @param #number fadeTime fadeTime
-- @return #boolean

---
-- Function Stop
--
-- @function [parent=#AnimationController] Stop
-- @param self Self reference
-- @param #string name name
-- @param #number fadeOutTime fadeOutTime
-- @return #boolean

---
-- Function StopLayer
--
-- @function [parent=#AnimationController] StopLayer
-- @param self Self reference
-- @param #string layer layer
-- @param #number fadeOutTime fadeOutTime

---
-- Function StopAll
--
-- @function [parent=#AnimationController] StopAll
-- @param self Self reference
-- @param #number fadeTime fadeTime

---
-- Function Fade
--
-- @function [parent=#AnimationController] Fade
-- @param self Self reference
-- @param #string name name
-- @param #number targetWeight targetWeight
-- @param #number fadeTime fadeTime
-- @return #boolean

---
-- Function FadeOthers
--
-- @function [parent=#AnimationController] FadeOthers
-- @param self Self reference
-- @param #string name name
-- @param #number targetWeight targetWeight
-- @param #number fadeTime fadeTime
-- @return #boolean

---
-- Function SetLayer
--
-- @function [parent=#AnimationController] SetLayer
-- @param self Self reference
-- @param #string name name
-- @param #string layer layer
-- @return #boolean

---
-- Function SetStartBone
--
-- @function [parent=#AnimationController] SetStartBone
-- @param self Self reference
-- @param #string name name
-- @param #string startBoneName startBoneName
-- @return #boolean

---
-- Function SetTime
--
-- @function [parent=#AnimationController] SetTime
-- @param self Self reference
-- @param #string name name
-- @param #number time time
-- @return #boolean

---
-- Function SetWeight
--
-- @function [parent=#AnimationController] SetWeight
-- @param self Self reference
-- @param #string name name
-- @param #number weight weight
-- @return #boolean

---
-- Function SetLooped
--
-- @function [parent=#AnimationController] SetLooped
-- @param self Self reference
-- @param #string name name
-- @param #boolean enable enable
-- @return #boolean

---
-- Function SetSpeed
--
-- @function [parent=#AnimationController] SetSpeed
-- @param self Self reference
-- @param #string name name
-- @param #number speed speed
-- @return #boolean

---
-- Function SetAutoFade
--
-- @function [parent=#AnimationController] SetAutoFade
-- @param self Self reference
-- @param #string name name
-- @param #number fadeOutTime fadeOutTime
-- @return #boolean

---
-- Function IsPlaying
--
-- @function [parent=#AnimationController] IsPlaying
-- @param self Self reference
-- @param #string name name
-- @return #boolean

---
-- Function IsFadingIn
--
-- @function [parent=#AnimationController] IsFadingIn
-- @param self Self reference
-- @param #string name name
-- @return #boolean

---
-- Function IsFadingOut
--
-- @function [parent=#AnimationController] IsFadingOut
-- @param self Self reference
-- @param #string name name
-- @return #boolean

---
-- Function GetLayer
--
-- @function [parent=#AnimationController] GetLayer
-- @param self Self reference
-- @param #string name name
-- @return #string

---
-- Function GetStartBone
--
-- @function [parent=#AnimationController] GetStartBone
-- @param self Self reference
-- @param #string name name
-- @return Bone#Bone

---
-- Function GetStartBoneName
--
-- @function [parent=#AnimationController] GetStartBoneName
-- @param self Self reference
-- @param #string name name
-- @return const String#const String

---
-- Function GetTime
--
-- @function [parent=#AnimationController] GetTime
-- @param self Self reference
-- @param #string name name
-- @return #number

---
-- Function GetWeight
--
-- @function [parent=#AnimationController] GetWeight
-- @param self Self reference
-- @param #string name name
-- @return #number

---
-- Function IsLooped
--
-- @function [parent=#AnimationController] IsLooped
-- @param self Self reference
-- @param #string name name
-- @return #boolean

---
-- Function GetLength
--
-- @function [parent=#AnimationController] GetLength
-- @param self Self reference
-- @param #string name name
-- @return #number

---
-- Function GetSpeed
--
-- @function [parent=#AnimationController] GetSpeed
-- @param self Self reference
-- @param #string name name
-- @return #number

---
-- Function GetFadeTarget
--
-- @function [parent=#AnimationController] GetFadeTarget
-- @param self Self reference
-- @param #string name name
-- @return #number

---
-- Function GetFadeTime
--
-- @function [parent=#AnimationController] GetFadeTime
-- @param self Self reference
-- @param #string name name
-- @return #number

---
-- Function GetAutoFade
--
-- @function [parent=#AnimationController] GetAutoFade
-- @param self Self reference
-- @param #string name name
-- @return #number

---
-- Function GetAnimationState
--
-- @function [parent=#AnimationController] GetAnimationState
-- @param self Self reference
-- @param #string name name
-- @return AnimationState#AnimationState

---
-- Function GetAnimationState
--
-- @function [parent=#AnimationController] GetAnimationState
-- @param self Self reference
-- @param StringHash#StringHash nameHash nameHash
-- @return AnimationState#AnimationState

---
-- Function SetEnabled
--
-- @function [parent=#AnimationController] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Remove
--
-- @function [parent=#AnimationController] Remove
-- @param self Self reference

---
-- Function GetID
--
-- @function [parent=#AnimationController] GetID
-- @param self Self reference
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#AnimationController] GetNode
-- @param self Self reference
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#AnimationController] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#AnimationController] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#AnimationController] IsEnabledEffective
-- @param self Self reference
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#AnimationController] GetComponent
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#AnimationController] GetComponent
-- @param self Self reference
-- @param #string type type
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#AnimationController] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#AnimationController] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#AnimationController] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#AnimationController] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#AnimationController] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#AnimationController] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#AnimationController] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#AnimationController] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#AnimationController] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#AnimationController] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#AnimationController] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#AnimationController] #string category


return nil
