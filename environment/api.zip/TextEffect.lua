---
-- Enumeration TextEffect
--
-- @module TextEffect

---
-- Enumeration value TE_NONE
--
-- @field [parent=#TextEffect] #number TE_NONE

---
-- Enumeration value TE_SHADOW
--
-- @field [parent=#TextEffect] #number TE_SHADOW

---
-- Enumeration value TE_STROKE
--
-- @field [parent=#TextEffect] #number TE_STROKE


return nil
