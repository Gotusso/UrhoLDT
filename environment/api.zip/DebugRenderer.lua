---
-- Module DebugRenderer
-- Module DebugRenderer extends Component
-- Generated on 2014-03-13
--
-- @module DebugRenderer

---
-- Function SetView
--
-- @function [parent=#DebugRenderer] SetView
-- @param self Self reference
-- @param Camera#Camera camera camera

---
-- Function AddLine
--
-- @function [parent=#DebugRenderer] AddLine
-- @param self Self reference
-- @param Vector3#Vector3 start start
-- @param Vector3#Vector3 end end
-- @param Color#Color color color
-- @param #boolean depthTest depthTest

---
-- Function AddLine
--
-- @function [parent=#DebugRenderer] AddLine
-- @param self Self reference
-- @param Vector3#Vector3 start start
-- @param Vector3#Vector3 end end
-- @param #number color color
-- @param #boolean depthTest depthTest

---
-- Function AddNode
--
-- @function [parent=#DebugRenderer] AddNode
-- @param self Self reference
-- @param Node#Node node node
-- @param #number scale scale
-- @param #boolean depthTest depthTest

---
-- Function AddBoundingBox
--
-- @function [parent=#DebugRenderer] AddBoundingBox
-- @param self Self reference
-- @param BoundingBox#BoundingBox box box
-- @param Color#Color color color
-- @param #boolean depthTest depthTest

---
-- Function AddBoundingBox
--
-- @function [parent=#DebugRenderer] AddBoundingBox
-- @param self Self reference
-- @param BoundingBox#BoundingBox box box
-- @param Matrix3x4#Matrix3x4 transform transform
-- @param Color#Color color color
-- @param #boolean depthTest depthTest

---
-- Function AddFrustum
--
-- @function [parent=#DebugRenderer] AddFrustum
-- @param self Self reference
-- @param Frustum#Frustum frustum frustum
-- @param Color#Color color color
-- @param #boolean depthTest depthTest

---
-- Function AddPolyhedron
--
-- @function [parent=#DebugRenderer] AddPolyhedron
-- @param self Self reference
-- @param Polyhedron#Polyhedron poly poly
-- @param Color#Color color color
-- @param #boolean depthTest depthTest

---
-- Function AddSphere
--
-- @function [parent=#DebugRenderer] AddSphere
-- @param self Self reference
-- @param Sphere#Sphere sphere sphere
-- @param Color#Color color color
-- @param #boolean depthTest depthTest

---
-- Function AddSkeleton
--
-- @function [parent=#DebugRenderer] AddSkeleton
-- @param self Self reference
-- @param Skeleton#Skeleton skeleton skeleton
-- @param Color#Color color color
-- @param #boolean depthTest depthTest

---
-- Function AddTriangleMesh
--
-- @function [parent=#DebugRenderer] AddTriangleMesh
-- @param self Self reference
-- @param void*#void* vertexData vertexData
-- @param #number vertexSize vertexSize
-- @param void*#void* indexData indexData
-- @param #number indexSize indexSize
-- @param #number indexStart indexStart
-- @param #number indexCount indexCount
-- @param Matrix3x4#Matrix3x4 transform transform
-- @param Color#Color color color
-- @param #boolean depthTest depthTest

---
-- Function Render
--
-- @function [parent=#DebugRenderer] Render
-- @param self Self reference

---
-- Function GetView
--
-- @function [parent=#DebugRenderer] GetView
-- @param self Self reference
-- @return const Matrix3x4#const Matrix3x4

---
-- Function GetProjection
--
-- @function [parent=#DebugRenderer] GetProjection
-- @param self Self reference
-- @return const Matrix4#const Matrix4

---
-- Function GetFrustum
--
-- @function [parent=#DebugRenderer] GetFrustum
-- @param self Self reference
-- @return const Frustum#const Frustum

---
-- Function IsInside
--
-- @function [parent=#DebugRenderer] IsInside
-- @param self Self reference
-- @param BoundingBox#BoundingBox box box
-- @return #boolean

---
-- Field view (Read only)
--
-- @field [parent=#DebugRenderer] Matrix3x4#Matrix3x4 view

---
-- Field projection (Read only)
--
-- @field [parent=#DebugRenderer] Matrix4#Matrix4 projection

---
-- Field frustum (Read only)
--
-- @field [parent=#DebugRenderer] Frustum#Frustum frustum

---
-- Function SetEnabled
--
-- @function [parent=#DebugRenderer] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Remove
--
-- @function [parent=#DebugRenderer] Remove
-- @param self Self reference

---
-- Function GetID
--
-- @function [parent=#DebugRenderer] GetID
-- @param self Self reference
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#DebugRenderer] GetNode
-- @param self Self reference
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#DebugRenderer] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#DebugRenderer] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#DebugRenderer] IsEnabledEffective
-- @param self Self reference
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#DebugRenderer] GetComponent
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#DebugRenderer] GetComponent
-- @param self Self reference
-- @param #string type type
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#DebugRenderer] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#DebugRenderer] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#DebugRenderer] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#DebugRenderer] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#DebugRenderer] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#DebugRenderer] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#DebugRenderer] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#DebugRenderer] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#DebugRenderer] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#DebugRenderer] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#DebugRenderer] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#DebugRenderer] #string category


return nil
