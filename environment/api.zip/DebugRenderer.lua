---
-- Module DebugRenderer
-- Extends Component
--
-- @module DebugRenderer

---
-- Function SetView
--
-- @function [parent=#DebugRenderer] SetView
-- @param Camera#Camera cameracamera

---
-- Function AddLine
--
-- @function [parent=#DebugRenderer] AddLine
-- @param Vector3#Vector3 startstart
-- @param Vector3#Vector3 endend
-- @param Color#Color colorcolor
-- @param #boolean depthTestdepthTest

---
-- Function AddLine
--
-- @function [parent=#DebugRenderer] AddLine
-- @param Vector3#Vector3 startstart
-- @param Vector3#Vector3 endend
-- @param #number colorcolor
-- @param #boolean depthTestdepthTest

---
-- Function AddNode
--
-- @function [parent=#DebugRenderer] AddNode
-- @param Node#Node nodenode
-- @param #number scalescale
-- @param #boolean depthTestdepthTest

---
-- Function AddBoundingBox
--
-- @function [parent=#DebugRenderer] AddBoundingBox
-- @param BoundingBox#BoundingBox boxbox
-- @param Color#Color colorcolor
-- @param #boolean depthTestdepthTest

---
-- Function AddBoundingBox
--
-- @function [parent=#DebugRenderer] AddBoundingBox
-- @param BoundingBox#BoundingBox boxbox
-- @param Matrix3x4#Matrix3x4 transformtransform
-- @param Color#Color colorcolor
-- @param #boolean depthTestdepthTest

---
-- Function AddFrustum
--
-- @function [parent=#DebugRenderer] AddFrustum
-- @param Frustum#Frustum frustumfrustum
-- @param Color#Color colorcolor
-- @param #boolean depthTestdepthTest

---
-- Function AddPolyhedron
--
-- @function [parent=#DebugRenderer] AddPolyhedron
-- @param Polyhedron#Polyhedron polypoly
-- @param Color#Color colorcolor
-- @param #boolean depthTestdepthTest

---
-- Function AddSphere
--
-- @function [parent=#DebugRenderer] AddSphere
-- @param Sphere#Sphere spheresphere
-- @param Color#Color colorcolor
-- @param #boolean depthTestdepthTest

---
-- Function AddSkeleton
--
-- @function [parent=#DebugRenderer] AddSkeleton
-- @param Skeleton#Skeleton skeletonskeleton
-- @param Color#Color colorcolor
-- @param #boolean depthTestdepthTest

---
-- Function AddTriangleMesh
--
-- @function [parent=#DebugRenderer] AddTriangleMesh
-- @param void*#void* vertexDatavertexData
-- @param #number vertexSizevertexSize
-- @param void*#void* indexDataindexData
-- @param #number indexSizeindexSize
-- @param #number indexStartindexStart
-- @param #number indexCountindexCount
-- @param Matrix3x4#Matrix3x4 transformtransform
-- @param Color#Color colorcolor
-- @param #boolean depthTestdepthTest

---
-- Function Render
--
-- @function [parent=#DebugRenderer] Render

---
-- Function GetView
--
-- @function [parent=#DebugRenderer] GetView
-- @return const Matrix3x4#const Matrix3x4

---
-- Function GetProjection
--
-- @function [parent=#DebugRenderer] GetProjection
-- @return const Matrix4#const Matrix4

---
-- Function GetFrustum
--
-- @function [parent=#DebugRenderer] GetFrustum
-- @return const Frustum#const Frustum

---
-- Function IsInside
--
-- @function [parent=#DebugRenderer] IsInside
-- @param BoundingBox#BoundingBox boxbox
-- @return #boolean

---
-- Field view (Read only)
--
-- @field [parent=#DebugRenderer] Matrix3x4#Matrix3x4 view

---
-- Field projection (Read only)
--
-- @field [parent=#DebugRenderer] Matrix4#Matrix4 projection

---
-- Field frustum (Read only)
--
-- @field [parent=#DebugRenderer] Frustum#Frustum frustum


return nil
