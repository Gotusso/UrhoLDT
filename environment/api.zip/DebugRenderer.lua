---
-- Module DebugRenderer
-- Module DebugRenderer extends Component
-- Generated on 2014-05-31
--
-- @module DebugRenderer

---
-- Function SetView()
-- Set the camera viewpoint. Call before rendering, or before adding geometry if you want to use culling.
--
-- @function [parent=#DebugRenderer] SetView
-- @param self Self reference
-- @param Camera#Camera camera camera

---
-- Function AddLine()
-- Add a line.
--
-- @function [parent=#DebugRenderer] AddLine
-- @param self Self reference
-- @param Vector3#Vector3 start start
-- @param Vector3#Vector3 end end
-- @param Color#Color color color
-- @param #boolean depthTest depthTest

---
-- Function AddLine()
-- Add a line with color already converted to unsigned.
--
-- @function [parent=#DebugRenderer] AddLine
-- @param self Self reference
-- @param Vector3#Vector3 start start
-- @param Vector3#Vector3 end end
-- @param #number color color
-- @param #boolean depthTest depthTest

---
-- Function AddTriangle()
-- Add a triangle.
--
-- @function [parent=#DebugRenderer] AddTriangle
-- @param self Self reference
-- @param Vector3#Vector3 v1 v1
-- @param Vector3#Vector3 v2 v2
-- @param Vector3#Vector3 v3 v3
-- @param Color#Color color color
-- @param #boolean depthTest depthTest

---
-- Function AddTriangle()
-- Add a triangle with color already converted to unsigned.
--
-- @function [parent=#DebugRenderer] AddTriangle
-- @param self Self reference
-- @param Vector3#Vector3 v1 v1
-- @param Vector3#Vector3 v2 v2
-- @param Vector3#Vector3 v3 v3
-- @param #number color color
-- @param #boolean depthTest depthTest

---
-- Function AddNode()
-- Add a scene node represented as its coordinate axes.
--
-- @function [parent=#DebugRenderer] AddNode
-- @param self Self reference
-- @param Node#Node node node
-- @param #number scale scale
-- @param #boolean depthTest depthTest

---
-- Function AddBoundingBox()
-- Add a bounding box.
--
-- @function [parent=#DebugRenderer] AddBoundingBox
-- @param self Self reference
-- @param BoundingBox#BoundingBox box box
-- @param Color#Color color color
-- @param #boolean depthTest depthTest

---
-- Function AddBoundingBox()
-- Add a bounding box with transform.
--
-- @function [parent=#DebugRenderer] AddBoundingBox
-- @param self Self reference
-- @param BoundingBox#BoundingBox box box
-- @param Matrix3x4#Matrix3x4 transform transform
-- @param Color#Color color color
-- @param #boolean depthTest depthTest

---
-- Function AddFrustum()
-- Add a frustum.
--
-- @function [parent=#DebugRenderer] AddFrustum
-- @param self Self reference
-- @param Frustum#Frustum frustum frustum
-- @param Color#Color color color
-- @param #boolean depthTest depthTest

---
-- Function AddPolyhedron()
-- Add a polyhedron.
--
-- @function [parent=#DebugRenderer] AddPolyhedron
-- @param self Self reference
-- @param Polyhedron#Polyhedron poly poly
-- @param Color#Color color color
-- @param #boolean depthTest depthTest

---
-- Function AddSphere()
-- Add a sphere.
--
-- @function [parent=#DebugRenderer] AddSphere
-- @param self Self reference
-- @param Sphere#Sphere sphere sphere
-- @param Color#Color color color
-- @param #boolean depthTest depthTest

---
-- Function AddSkeleton()
-- Add a skeleton.
--
-- @function [parent=#DebugRenderer] AddSkeleton
-- @param self Self reference
-- @param Skeleton#Skeleton skeleton skeleton
-- @param Color#Color color color
-- @param #boolean depthTest depthTest

---
-- Function AddTriangleMesh()
--
-- @function [parent=#DebugRenderer] AddTriangleMesh
-- @param self Self reference
-- @param void*#void* vertexData vertexData
-- @param #number vertexSize vertexSize
-- @param void*#void* indexData indexData
-- @param #number indexSize indexSize
-- @param #number indexStart indexStart
-- @param #number indexCount indexCount
-- @param Matrix3x4#Matrix3x4 transform transform
-- @param Color#Color color color
-- @param #boolean depthTest depthTest

---
-- Function Render()
-- Update vertex buffer and render all debug lines. The viewport and rendertarget should be set before.
--
-- @function [parent=#DebugRenderer] Render
-- @param self Self reference

---
-- Function GetView()
-- Return the view transform.
--
-- @function [parent=#DebugRenderer] GetView
-- @param self Self reference
-- @return const Matrix3x4#const Matrix3x4

---
-- Function GetProjection()
-- Return the projection transform.
--
-- @function [parent=#DebugRenderer] GetProjection
-- @param self Self reference
-- @return const Matrix4#const Matrix4

---
-- Function GetFrustum()
-- Return the view frustum.
--
-- @function [parent=#DebugRenderer] GetFrustum
-- @param self Self reference
-- @return const Frustum#const Frustum

---
-- Function IsInside()
-- Check whether a bounding box is inside the view frustum.
--
-- @function [parent=#DebugRenderer] IsInside
-- @param self Self reference
-- @param BoundingBox#BoundingBox box box
-- @return #boolean

---
-- Field view (Read only)
--
-- @field [parent=#DebugRenderer] Matrix3x4#Matrix3x4 view

---
-- Field projection (Read only)
--
-- @field [parent=#DebugRenderer] Matrix4#Matrix4 projection

---
-- Field frustum (Read only)
--
-- @field [parent=#DebugRenderer] Frustum#Frustum frustum


return nil
