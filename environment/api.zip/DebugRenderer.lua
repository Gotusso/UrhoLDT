---
-- Module DebugRenderer
-- extends Component
--
-- @module DebugRenderer

---
-- Function SetView
--
-- @function [parent=#DebugRenderer] SetView
-- @param Camera#Camera cameracamera

---
-- Function AddLine
--
-- @function [parent=#DebugRenderer] AddLine
-- @param Vector3#Vector3 startstart
-- @param Vector3#Vector3 endend
-- @param Color#Color colorcolor
-- @param #boolean depthTestdepthTest

---
-- Function AddLine
--
-- @function [parent=#DebugRenderer] AddLine
-- @param Vector3#Vector3 startstart
-- @param Vector3#Vector3 endend
-- @param #number colorcolor
-- @param #boolean depthTestdepthTest

---
-- Function AddNode
--
-- @function [parent=#DebugRenderer] AddNode
-- @param Node#Node nodenode
-- @param #number scalescale
-- @param #boolean depthTestdepthTest

---
-- Function AddBoundingBox
--
-- @function [parent=#DebugRenderer] AddBoundingBox
-- @param BoundingBox#BoundingBox boxbox
-- @param Color#Color colorcolor
-- @param #boolean depthTestdepthTest

---
-- Function AddBoundingBox
--
-- @function [parent=#DebugRenderer] AddBoundingBox
-- @param BoundingBox#BoundingBox boxbox
-- @param Matrix3x4#Matrix3x4 transformtransform
-- @param Color#Color colorcolor
-- @param #boolean depthTestdepthTest

---
-- Function AddFrustum
--
-- @function [parent=#DebugRenderer] AddFrustum
-- @param Frustum#Frustum frustumfrustum
-- @param Color#Color colorcolor
-- @param #boolean depthTestdepthTest

---
-- Function AddPolyhedron
--
-- @function [parent=#DebugRenderer] AddPolyhedron
-- @param Polyhedron#Polyhedron polypoly
-- @param Color#Color colorcolor
-- @param #boolean depthTestdepthTest

---
-- Function AddSphere
--
-- @function [parent=#DebugRenderer] AddSphere
-- @param Sphere#Sphere spheresphere
-- @param Color#Color colorcolor
-- @param #boolean depthTestdepthTest

---
-- Function AddSkeleton
--
-- @function [parent=#DebugRenderer] AddSkeleton
-- @param Skeleton#Skeleton skeletonskeleton
-- @param Color#Color colorcolor
-- @param #boolean depthTestdepthTest

---
-- Function AddTriangleMesh
--
-- @function [parent=#DebugRenderer] AddTriangleMesh
-- @param void*#void* vertexDatavertexData
-- @param #number vertexSizevertexSize
-- @param void*#void* indexDataindexData
-- @param #number indexSizeindexSize
-- @param #number indexStartindexStart
-- @param #number indexCountindexCount
-- @param Matrix3x4#Matrix3x4 transformtransform
-- @param Color#Color colorcolor
-- @param #boolean depthTestdepthTest

---
-- Function Render
--
-- @function [parent=#DebugRenderer] Render

---
-- Function GetView
--
-- @function [parent=#DebugRenderer] GetView
-- @return const Matrix3x4#const Matrix3x4

---
-- Function GetProjection
--
-- @function [parent=#DebugRenderer] GetProjection
-- @return const Matrix4#const Matrix4

---
-- Function GetFrustum
--
-- @function [parent=#DebugRenderer] GetFrustum
-- @return const Frustum#const Frustum

---
-- Function IsInside
--
-- @function [parent=#DebugRenderer] IsInside
-- @param BoundingBox#BoundingBox boxbox
-- @return #boolean

---
-- Field view (Read only)
--
-- @field [parent=#DebugRenderer] Matrix3x4#Matrix3x4 view

---
-- Field projection (Read only)
--
-- @field [parent=#DebugRenderer] Matrix4#Matrix4 projection

---
-- Field frustum (Read only)
--
-- @field [parent=#DebugRenderer] Frustum#Frustum frustum

---
-- Function SetEnabled
--
-- @function [parent=#DebugRenderer] SetEnabled
-- @param #boolean enableenable

---
-- Function Remove
--
-- @function [parent=#DebugRenderer] Remove

---
-- Function GetID
--
-- @function [parent=#DebugRenderer] GetID
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#DebugRenderer] GetNode
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#DebugRenderer] GetScene
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#DebugRenderer] IsEnabled
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#DebugRenderer] IsEnabledEffective
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#DebugRenderer] GetComponent
-- @param ShortStringHash#ShortStringHash typetype
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#DebugRenderer] GetComponent
-- @param #string typetype
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#DebugRenderer] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#DebugRenderer] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#DebugRenderer] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#DebugRenderer] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#DebugRenderer] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#DebugRenderer] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#DebugRenderer] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#DebugRenderer] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#DebugRenderer] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#DebugRenderer] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#DebugRenderer] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#DebugRenderer] #string category


return nil
