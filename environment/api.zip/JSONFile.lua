---
-- Module JSONFile
-- Module JSONFile extends Resource
-- Generated on 2014-05-31
--
-- @module JSONFile

---
-- Function JSONFile()
--
-- @function [parent=#JSONFile] JSONFile
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#JSONFile] new
-- @param self Self reference
-- @return JSONFile#JSONFile

---
-- Function delete()
--
-- @function [parent=#JSONFile] delete
-- @param self Self reference

---
-- Function CreateRoot()
-- Clear the document and create a root value, default is object type.
--
-- @function [parent=#JSONFile] CreateRoot
-- @param self Self reference
-- @param JSONValueType#JSONValueType valueType valueType
-- @return JSONValue#JSONValue

---
-- Function GetRoot()
-- Return the root value with specific value type, Return null value if not found.
--
-- @function [parent=#JSONFile] GetRoot
-- @param self Self reference
-- @param JSONValueType#JSONValueType valueType valueType
-- @return JSONValue#JSONValue


return nil
