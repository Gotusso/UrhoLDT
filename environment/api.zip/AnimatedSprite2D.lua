---
-- Module AnimatedSprite2D
-- Module AnimatedSprite2D extends StaticSprite2D
-- Generated on 2014-05-31
--
-- @module AnimatedSprite2D

---
-- Function SetSpeed()
-- Set speed.
--
-- @function [parent=#AnimatedSprite2D] SetSpeed
-- @param self Self reference
-- @param #number speed speed

---
-- Function SetCycleMode()
-- Set cycle mode.
--
-- @function [parent=#AnimatedSprite2D] SetCycleMode
-- @param self Self reference
-- @param CycleMode#CycleMode cycleMode cycleMode

---
-- Function SetAnimation()
-- Set animation.
--
-- @function [parent=#AnimatedSprite2D] SetAnimation
-- @param self Self reference
-- @param Animation2D#Animation2D animation animation

---
-- Function GetSpeed()
-- Return speed.
--
-- @function [parent=#AnimatedSprite2D] GetSpeed
-- @param self Self reference
-- @return #number

---
-- Function GetCycleMode()
-- Return cycle mode.
--
-- @function [parent=#AnimatedSprite2D] GetCycleMode
-- @param self Self reference
-- @return CycleMode#CycleMode

---
-- Function GetAnimation()
-- Return Animation.
--
-- @function [parent=#AnimatedSprite2D] GetAnimation
-- @param self Self reference
-- @return Animation2D#Animation2D

---
-- Field speed
--
-- @field [parent=#AnimatedSprite2D] #number speed

---
-- Field cycleMode
--
-- @field [parent=#AnimatedSprite2D] CycleMode#CycleMode cycleMode

---
-- Field animation
--
-- @field [parent=#AnimatedSprite2D] Animation2D#Animation2D animation


return nil
