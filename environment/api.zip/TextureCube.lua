---
-- Module TextureCube
-- Module TextureCube extends Texture
-- Generated on 2014-03-13
--
-- @module TextureCube

---
-- Function GetRenderSurface
--
-- @function [parent=#TextureCube] GetRenderSurface
-- @param self Self reference
-- @param CubeMapFace#CubeMapFace face face
-- @return RenderSurface#RenderSurface

---
-- Function SetNumLevels
--
-- @function [parent=#TextureCube] SetNumLevels
-- @param self Self reference
-- @param #number levels levels

---
-- Function SetFilterMode
--
-- @function [parent=#TextureCube] SetFilterMode
-- @param self Self reference
-- @param TextureFilterMode#TextureFilterMode filter filter

---
-- Function SetAddressMode
--
-- @function [parent=#TextureCube] SetAddressMode
-- @param self Self reference
-- @param TextureCoordinate#TextureCoordinate coord coord
-- @param TextureAddressMode#TextureAddressMode address address

---
-- Function SetBorderColor
--
-- @function [parent=#TextureCube] SetBorderColor
-- @param self Self reference
-- @param Color#Color color color

---
-- Function SetSRGB
--
-- @function [parent=#TextureCube] SetSRGB
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetBackupTexture
--
-- @function [parent=#TextureCube] SetBackupTexture
-- @param self Self reference
-- @param Texture#Texture texture texture

---
-- Function SetMipsToSkip
--
-- @function [parent=#TextureCube] SetMipsToSkip
-- @param self Self reference
-- @param #number quality quality
-- @param #number mips mips

---
-- Function GetFormat
--
-- @function [parent=#TextureCube] GetFormat
-- @param self Self reference
-- @return #number

---
-- Function IsCompressed
--
-- @function [parent=#TextureCube] IsCompressed
-- @param self Self reference
-- @return #boolean

---
-- Function GetLevels
--
-- @function [parent=#TextureCube] GetLevels
-- @param self Self reference
-- @return #number

---
-- Function GetWidth
--
-- @function [parent=#TextureCube] GetWidth
-- @param self Self reference
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#TextureCube] GetHeight
-- @param self Self reference
-- @return #number

---
-- Function GetFilterMode
--
-- @function [parent=#TextureCube] GetFilterMode
-- @param self Self reference
-- @return TextureFilterMode#TextureFilterMode

---
-- Function GetAddressMode
--
-- @function [parent=#TextureCube] GetAddressMode
-- @param self Self reference
-- @param TextureCoordinate#TextureCoordinate coord coord
-- @return TextureAddressMode#TextureAddressMode

---
-- Function GetBorderColor
--
-- @function [parent=#TextureCube] GetBorderColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetSRGB
--
-- @function [parent=#TextureCube] GetSRGB
-- @param self Self reference
-- @return #boolean

---
-- Function GetBackupTexture
--
-- @function [parent=#TextureCube] GetBackupTexture
-- @param self Self reference
-- @return Texture#Texture

---
-- Function GetMipsToSkip
--
-- @function [parent=#TextureCube] GetMipsToSkip
-- @param self Self reference
-- @param #number quality quality
-- @return #number

---
-- Function GetLevelWidth
--
-- @function [parent=#TextureCube] GetLevelWidth
-- @param self Self reference
-- @param #number level level
-- @return #number

---
-- Function GetLevelHeight
--
-- @function [parent=#TextureCube] GetLevelHeight
-- @param self Self reference
-- @param #number level level
-- @return #number

---
-- Function GetUsage
--
-- @function [parent=#TextureCube] GetUsage
-- @param self Self reference
-- @return TextureUsage#TextureUsage

---
-- Function GetDataSize
--
-- @function [parent=#TextureCube] GetDataSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height
-- @return #number

---
-- Function GetRowDataSize
--
-- @function [parent=#TextureCube] GetRowDataSize
-- @param self Self reference
-- @param #number width width
-- @return #number

---
-- Field format (Read only)
--
-- @field [parent=#TextureCube] #number format

---
-- Field compressed (Read only)
--
-- @field [parent=#TextureCube] #boolean compressed

---
-- Field levels (Read only)
--
-- @field [parent=#TextureCube] #number levels

---
-- Field width (Read only)
--
-- @field [parent=#TextureCube] #number width

---
-- Field height (Read only)
--
-- @field [parent=#TextureCube] #number height

---
-- Field filterMode
--
-- @field [parent=#TextureCube] TextureFilterMode#TextureFilterMode filterMode

---
-- Field borderColor
--
-- @field [parent=#TextureCube] Color#Color borderColor

---
-- Field sRGB
--
-- @field [parent=#TextureCube] #boolean sRGB

---
-- Field backupTexture
--
-- @field [parent=#TextureCube] Texture#Texture backupTexture

---
-- Field usage (Read only)
--
-- @field [parent=#TextureCube] TextureUsage#TextureUsage usage

---
-- Function Load
--
-- @function [parent=#TextureCube] Load
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#TextureCube] Save
-- @param self Self reference
-- @param Serializer#Serializer dest dest
-- @return #boolean

---
-- Function Load
--
-- @function [parent=#TextureCube] Load
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#TextureCube] Save
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function GetName
--
-- @function [parent=#TextureCube] GetName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetNameHash
--
-- @function [parent=#TextureCube] GetNameHash
-- @param self Self reference
-- @return StringHash#StringHash

---
-- Function GetMemoryUse
--
-- @function [parent=#TextureCube] GetMemoryUse
-- @param self Self reference
-- @return #number

---
-- Field name (Read only)
--
-- @field [parent=#TextureCube] #string name

---
-- Field nameHash (Read only)
--
-- @field [parent=#TextureCube] StringHash#StringHash nameHash

---
-- Field memoryUse (Read only)
--
-- @field [parent=#TextureCube] #number memoryUse


return nil
