---
-- Module TextureCube
-- extends Texture
--
-- @module TextureCube

---
-- Function GetRenderSurface
--
-- @function [parent=#TextureCube] GetRenderSurface
-- @param CubeMapFace#CubeMapFace faceface
-- @return RenderSurface#RenderSurface

---
-- Function SetNumLevels
--
-- @function [parent=#TextureCube] SetNumLevels
-- @param #number levelslevels

---
-- Function SetFilterMode
--
-- @function [parent=#TextureCube] SetFilterMode
-- @param TextureFilterMode#TextureFilterMode filterfilter

---
-- Function SetAddressMode
--
-- @function [parent=#TextureCube] SetAddressMode
-- @param TextureCoordinate#TextureCoordinate coordcoord
-- @param TextureAddressMode#TextureAddressMode addressaddress

---
-- Function SetBorderColor
--
-- @function [parent=#TextureCube] SetBorderColor
-- @param Color#Color colorcolor

---
-- Function SetSRGB
--
-- @function [parent=#TextureCube] SetSRGB
-- @param #boolean enableenable

---
-- Function SetBackupTexture
--
-- @function [parent=#TextureCube] SetBackupTexture
-- @param Texture#Texture texturetexture

---
-- Function SetMipsToSkip
--
-- @function [parent=#TextureCube] SetMipsToSkip
-- @param #number qualityquality
-- @param #number mipsmips

---
-- Function GetFormat
--
-- @function [parent=#TextureCube] GetFormat
-- @return #number

---
-- Function IsCompressed
--
-- @function [parent=#TextureCube] IsCompressed
-- @return #boolean

---
-- Function GetLevels
--
-- @function [parent=#TextureCube] GetLevels
-- @return #number

---
-- Function GetWidth
--
-- @function [parent=#TextureCube] GetWidth
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#TextureCube] GetHeight
-- @return #number

---
-- Function GetFilterMode
--
-- @function [parent=#TextureCube] GetFilterMode
-- @return TextureFilterMode#TextureFilterMode

---
-- Function GetAddressMode
--
-- @function [parent=#TextureCube] GetAddressMode
-- @param TextureCoordinate#TextureCoordinate coordcoord
-- @return TextureAddressMode#TextureAddressMode

---
-- Function GetBorderColor
--
-- @function [parent=#TextureCube] GetBorderColor
-- @return const Color#const Color

---
-- Function GetSRGB
--
-- @function [parent=#TextureCube] GetSRGB
-- @return #boolean

---
-- Function GetBackupTexture
--
-- @function [parent=#TextureCube] GetBackupTexture
-- @return Texture#Texture

---
-- Function GetMipsToSkip
--
-- @function [parent=#TextureCube] GetMipsToSkip
-- @param #number qualityquality
-- @return #number

---
-- Function GetLevelWidth
--
-- @function [parent=#TextureCube] GetLevelWidth
-- @param #number levellevel
-- @return #number

---
-- Function GetLevelHeight
--
-- @function [parent=#TextureCube] GetLevelHeight
-- @param #number levellevel
-- @return #number

---
-- Function GetUsage
--
-- @function [parent=#TextureCube] GetUsage
-- @return TextureUsage#TextureUsage

---
-- Function GetDataSize
--
-- @function [parent=#TextureCube] GetDataSize
-- @param #number widthwidth
-- @param #number heightheight
-- @return #number

---
-- Function GetRowDataSize
--
-- @function [parent=#TextureCube] GetRowDataSize
-- @param #number widthwidth
-- @return #number

---
-- Field format (Read only)
--
-- @field [parent=#TextureCube] #number format

---
-- Field compressed (Read only)
--
-- @field [parent=#TextureCube] #boolean compressed

---
-- Field levels (Read only)
--
-- @field [parent=#TextureCube] #number levels

---
-- Field width (Read only)
--
-- @field [parent=#TextureCube] #number width

---
-- Field height (Read only)
--
-- @field [parent=#TextureCube] #number height

---
-- Field filterMode
--
-- @field [parent=#TextureCube] TextureFilterMode#TextureFilterMode filterMode

---
-- Field borderColor
--
-- @field [parent=#TextureCube] Color#Color borderColor

---
-- Field sRGB
--
-- @field [parent=#TextureCube] #boolean sRGB

---
-- Field backupTexture
--
-- @field [parent=#TextureCube] Texture#Texture backupTexture

---
-- Field usage (Read only)
--
-- @field [parent=#TextureCube] TextureUsage#TextureUsage usage

---
-- Function Load
--
-- @function [parent=#TextureCube] Load
-- @param Deserializer#Deserializer sourcesource
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#TextureCube] Save
-- @param Serializer#Serializer destdest
-- @return #boolean

---
-- Function Load
--
-- @function [parent=#TextureCube] Load
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#TextureCube] Save
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function GetName
--
-- @function [parent=#TextureCube] GetName
-- @return const String#const String

---
-- Function GetNameHash
--
-- @function [parent=#TextureCube] GetNameHash
-- @return StringHash#StringHash

---
-- Function GetMemoryUse
--
-- @function [parent=#TextureCube] GetMemoryUse
-- @return #number

---
-- Field name (Read only)
--
-- @field [parent=#TextureCube] #string name

---
-- Field nameHash (Read only)
--
-- @field [parent=#TextureCube] StringHash#StringHash nameHash

---
-- Field memoryUse (Read only)
--
-- @field [parent=#TextureCube] #number memoryUse


return nil
