---
-- Module TextureCube
-- Module TextureCube extends Texture
-- Generated on 2014-05-31
--
-- @module TextureCube

---
-- Function GetRenderSurface()
--
-- @function [parent=#TextureCube] GetRenderSurface
-- @param self Self reference
-- @param CubeMapFace#CubeMapFace face face
-- @return RenderSurface#RenderSurface


return nil
