---
-- Module TextureCube
-- Extends Texture
--
-- @module TextureCube

---
-- Function GetRenderSurface
--
-- @function [parent=#TextureCube] GetRenderSurface
-- @param CubeMapFace#CubeMapFace faceface
-- @return RenderSurface#RenderSurface


return nil
