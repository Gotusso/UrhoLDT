---
-- Module CollisionPolygon2D
-- Module CollisionPolygon2D extends CollisionShape2D
-- Generated on 2014-05-31
--
-- @module CollisionPolygon2D

---
-- Function SetVertexCount()
-- Set vertex count.
--
-- @function [parent=#CollisionPolygon2D] SetVertexCount
-- @param self Self reference
-- @param #number count count

---
-- Function SetVertex()
-- Set vertex.
--
-- @function [parent=#CollisionPolygon2D] SetVertex
-- @param self Self reference
-- @param #number index index
-- @param Vector2#Vector2 vertex vertex

---
-- Function SetVertices()
--
-- @function [parent=#CollisionPolygon2D] SetVertices
-- @param self Self reference
-- @param PODVector<Vector2>#PODVector<Vector2> vertices vertices

---
-- Function GetVertexCount()
-- Return vertex count.
--
-- @function [parent=#CollisionPolygon2D] GetVertexCount
-- @param self Self reference
-- @return #number

---
-- Function GetVertex()
--
-- @function [parent=#CollisionPolygon2D] GetVertex
-- @param self Self reference
-- @param #number index index
-- @return const Vector2#const Vector2

---
-- Field vertexCount
--
-- @field [parent=#CollisionPolygon2D] #number vertexCount


return nil
