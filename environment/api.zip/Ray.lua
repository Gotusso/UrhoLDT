---
-- Module Ray
--
-- @module Ray

---
-- Function Ray
--
-- @function [parent=#Ray] Ray

---
-- Function new
--
-- @function [parent=#Ray] new
-- @return Ray#Ray

---
-- Function Ray
--
-- @function [parent=#Ray] Ray
-- @param Vector3#Vector3 originorigin
-- @param Vector3#Vector3 directiondirection

---
-- Function new
--
-- @function [parent=#Ray] new
-- @param Vector3#Vector3 originorigin
-- @param Vector3#Vector3 directiondirection
-- @return Ray#Ray

---
-- Function Ray
--
-- @function [parent=#Ray] Ray
-- @param Ray#Ray rayray

---
-- Function new
--
-- @function [parent=#Ray] new
-- @param Ray#Ray rayray
-- @return Ray#Ray

---
-- Function delete
--
-- @function [parent=#Ray] delete

---
-- Function operator==
--
-- @function [parent=#Ray] operator==
-- @param Ray#Ray rhsrhs
-- @return #boolean

---
-- Function Define
--
-- @function [parent=#Ray] Define
-- @param Vector3#Vector3 originorigin
-- @param Vector3#Vector3 directiondirection

---
-- Function Project
--
-- @function [parent=#Ray] Project
-- @param Vector3#Vector3 pointpoint
-- @return Vector3#Vector3

---
-- Function Distance
--
-- @function [parent=#Ray] Distance
-- @param Vector3#Vector3 pointpoint
-- @return #number

---
-- Function ClosestPoint
--
-- @function [parent=#Ray] ClosestPoint
-- @param Ray#Ray rayray
-- @return Vector3#Vector3

---
-- Function HitDistance
--
-- @function [parent=#Ray] HitDistance
-- @param Plane#Plane planeplane
-- @return #number

---
-- Function HitDistance
--
-- @function [parent=#Ray] HitDistance
-- @param BoundingBox#BoundingBox boxbox
-- @return #number

---
-- Function HitDistance
--
-- @function [parent=#Ray] HitDistance
-- @param Frustum#Frustum frustumfrustum
-- @param #boolean solidInsidesolidInside
-- @return #number

---
-- Function HitDistance
--
-- @function [parent=#Ray] HitDistance
-- @param Sphere#Sphere spheresphere
-- @return #number

---
-- Function HitDistance
--
-- @function [parent=#Ray] HitDistance
-- @param Vector3#Vector3 v0v0
-- @param Vector3#Vector3 v1v1
-- @param Vector3#Vector3 v2v2
-- @return #number

---
-- Function Transformed
--
-- @function [parent=#Ray] Transformed
-- @param Matrix3x4#Matrix3x4 transformtransform
-- @return Ray#Ray

---
-- Field origin
--
-- @field [parent=#Ray] Vector3#Vector3 origin

---
-- Field direction
--
-- @field [parent=#Ray] Vector3#Vector3 direction


return nil
