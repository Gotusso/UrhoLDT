---
-- Module Ray
-- Generated on 2014-05-31
--
-- @module Ray

---
-- Function Ray()
-- Construct a degenerate ray with zero origin and direction.
--
-- @function [parent=#Ray] Ray
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#Ray] new
-- @param self Self reference
-- @return Ray#Ray

---
-- Function Ray()
--
-- @function [parent=#Ray] Ray
-- @param self Self reference
-- @param Vector3#Vector3 origin origin
-- @param Vector3#Vector3 direction direction

---
-- Function new()
--
-- @function [parent=#Ray] new
-- @param self Self reference
-- @param Vector3#Vector3 origin origin
-- @param Vector3#Vector3 direction direction
-- @return Ray#Ray

---
-- Function Ray()
--
-- @function [parent=#Ray] Ray
-- @param self Self reference
-- @param Ray#Ray ray ray

---
-- Function new()
--
-- @function [parent=#Ray] new
-- @param self Self reference
-- @param Ray#Ray ray ray
-- @return Ray#Ray

---
-- Function delete()
--
-- @function [parent=#Ray] delete
-- @param self Self reference

---
-- Function operator==()
--
-- @function [parent=#Ray] operator==
-- @param self Self reference
-- @param Ray#Ray rhs rhs
-- @return #boolean

---
-- Function Define()
--
-- @function [parent=#Ray] Define
-- @param self Self reference
-- @param Vector3#Vector3 origin origin
-- @param Vector3#Vector3 direction direction

---
-- Function Project()
--
-- @function [parent=#Ray] Project
-- @param self Self reference
-- @param Vector3#Vector3 point point
-- @return Vector3#Vector3

---
-- Function Distance()
--
-- @function [parent=#Ray] Distance
-- @param self Self reference
-- @param Vector3#Vector3 point point
-- @return #number

---
-- Function ClosestPoint()
--
-- @function [parent=#Ray] ClosestPoint
-- @param self Self reference
-- @param Ray#Ray ray ray
-- @return Vector3#Vector3

---
-- Function HitDistance()
--
-- @function [parent=#Ray] HitDistance
-- @param self Self reference
-- @param Plane#Plane plane plane
-- @return #number

---
-- Function HitDistance()
--
-- @function [parent=#Ray] HitDistance
-- @param self Self reference
-- @param BoundingBox#BoundingBox box box
-- @return #number

---
-- Function HitDistance()
--
-- @function [parent=#Ray] HitDistance
-- @param self Self reference
-- @param Frustum#Frustum frustum frustum
-- @param #boolean solidInside solidInside
-- @return #number

---
-- Function HitDistance()
--
-- @function [parent=#Ray] HitDistance
-- @param self Self reference
-- @param Sphere#Sphere sphere sphere
-- @return #number

---
-- Function HitDistance()
--
-- @function [parent=#Ray] HitDistance
-- @param self Self reference
-- @param Vector3#Vector3 v0 v0
-- @param Vector3#Vector3 v1 v1
-- @param Vector3#Vector3 v2 v2
-- @return #number

---
-- Function Transformed()
--
-- @function [parent=#Ray] Transformed
-- @param self Self reference
-- @param Matrix3x4#Matrix3x4 transform transform
-- @return Ray#Ray

---
-- Field origin
--
-- @field [parent=#Ray] Vector3#Vector3 origin

---
-- Field direction
--
-- @field [parent=#Ray] Vector3#Vector3 direction


return nil
