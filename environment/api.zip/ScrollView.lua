---
-- Module ScrollView
-- Module ScrollView extends UIElement
-- Generated on 2014-05-31
--
-- @module ScrollView

---
-- Function ScrollView()
--
-- @function [parent=#ScrollView] ScrollView
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#ScrollView] new
-- @param self Self reference
-- @return ScrollView#ScrollView

---
-- Function delete()
--
-- @function [parent=#ScrollView] delete
-- @param self Self reference

---
-- Function SetContentElement()
-- Set content element.
--
-- @function [parent=#ScrollView] SetContentElement
-- @param self Self reference
-- @param UIElement#UIElement element element

---
-- Function SetViewPosition()
-- Set view offset from the top-left corner.
--
-- @function [parent=#ScrollView] SetViewPosition
-- @param self Self reference
-- @param IntVector2#IntVector2 position position

---
-- Function SetViewPosition()
-- Set view offset from the top-left corner.
--
-- @function [parent=#ScrollView] SetViewPosition
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function SetScrollBarsVisible()
-- Set scrollbars' visibility manually. Disables scrollbar autoshow/hide.
--
-- @function [parent=#ScrollView] SetScrollBarsVisible
-- @param self Self reference
-- @param #boolean horizontal horizontal
-- @param #boolean vertical vertical

---
-- Function SetScrollBarsAutoVisible()
-- Set whether to automatically show/hide scrollbars. Default true.
--
-- @function [parent=#ScrollView] SetScrollBarsAutoVisible
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetScrollStep()
-- Set arrow key scroll step. Also sets it on the scrollbars.
--
-- @function [parent=#ScrollView] SetScrollStep
-- @param self Self reference
-- @param #number step step

---
-- Function SetPageStep()
-- Set arrow key page step.
--
-- @function [parent=#ScrollView] SetPageStep
-- @param self Self reference
-- @param #number step step

---
-- Function GetViewPosition()
-- Return view offset from the top-left corner.
--
-- @function [parent=#ScrollView] GetViewPosition
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetContentElement()
-- Return content element.
--
-- @function [parent=#ScrollView] GetContentElement
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetHorizontalScrollBar()
-- Return horizontal scroll bar.
--
-- @function [parent=#ScrollView] GetHorizontalScrollBar
-- @param self Self reference
-- @return ScrollBar#ScrollBar

---
-- Function GetVerticalScrollBar()
-- Return vertical scroll bar.
--
-- @function [parent=#ScrollView] GetVerticalScrollBar
-- @param self Self reference
-- @return ScrollBar#ScrollBar

---
-- Function GetScrollPanel()
-- Return scroll panel.
--
-- @function [parent=#ScrollView] GetScrollPanel
-- @param self Self reference
-- @return BorderImage#BorderImage

---
-- Function GetScrollBarsAutoVisible()
-- Return whether scrollbars are automatically shown/hidden.
--
-- @function [parent=#ScrollView] GetScrollBarsAutoVisible
-- @param self Self reference
-- @return #boolean

---
-- Function GetScrollStep()
-- Return arrow key scroll step.
--
-- @function [parent=#ScrollView] GetScrollStep
-- @param self Self reference
-- @return #number

---
-- Function GetPageStep()
-- Return arrow key page step.
--
-- @function [parent=#ScrollView] GetPageStep
-- @param self Self reference
-- @return #number

---
-- Field viewPosition
--
-- @field [parent=#ScrollView] IntVector2#IntVector2 viewPosition

---
-- Field contentElement
--
-- @field [parent=#ScrollView] UIElement#UIElement contentElement

---
-- Field horizontalScrollBar (Read only)
--
-- @field [parent=#ScrollView] ScrollBar#ScrollBar horizontalScrollBar

---
-- Field verticalScrollBar (Read only)
--
-- @field [parent=#ScrollView] ScrollBar#ScrollBar verticalScrollBar

---
-- Field scrollPanel (Read only)
--
-- @field [parent=#ScrollView] BorderImage#BorderImage scrollPanel

---
-- Field scrollBarsAutoVisible
--
-- @field [parent=#ScrollView] #boolean scrollBarsAutoVisible

---
-- Field scrollStep
--
-- @field [parent=#ScrollView] #number scrollStep

---
-- Field pageStep
--
-- @field [parent=#ScrollView] #number pageStep


return nil
