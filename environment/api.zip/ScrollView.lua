---
-- Module ScrollView
-- Extends UIElement
--
-- @module ScrollView

---
-- Function ScrollView
--
-- @function [parent=#ScrollView] ScrollView

---
-- Function new
--
-- @function [parent=#ScrollView] new
-- @return ScrollView#ScrollView

---
-- Function delete
--
-- @function [parent=#ScrollView] delete

---
-- Function SetContentElement
--
-- @function [parent=#ScrollView] SetContentElement
-- @param UIElement#UIElement elementelement

---
-- Function SetViewPosition
--
-- @function [parent=#ScrollView] SetViewPosition
-- @param IntVector2#IntVector2 positionposition

---
-- Function SetViewPosition
--
-- @function [parent=#ScrollView] SetViewPosition
-- @param #number xx
-- @param #number yy

---
-- Function SetScrollBarsVisible
--
-- @function [parent=#ScrollView] SetScrollBarsVisible
-- @param #boolean horizontalhorizontal
-- @param #boolean verticalvertical

---
-- Function SetScrollBarsAutoVisible
--
-- @function [parent=#ScrollView] SetScrollBarsAutoVisible
-- @param #boolean enableenable

---
-- Function SetScrollStep
--
-- @function [parent=#ScrollView] SetScrollStep
-- @param #number stepstep

---
-- Function SetPageStep
--
-- @function [parent=#ScrollView] SetPageStep
-- @param #number stepstep

---
-- Function GetViewPosition
--
-- @function [parent=#ScrollView] GetViewPosition
-- @return const IntVector2#const IntVector2

---
-- Function GetContentElement
--
-- @function [parent=#ScrollView] GetContentElement
-- @return UIElement#UIElement

---
-- Function GetHorizontalScrollBar
--
-- @function [parent=#ScrollView] GetHorizontalScrollBar
-- @return ScrollBar#ScrollBar

---
-- Function GetVerticalScrollBar
--
-- @function [parent=#ScrollView] GetVerticalScrollBar
-- @return ScrollBar#ScrollBar

---
-- Function GetScrollPanel
--
-- @function [parent=#ScrollView] GetScrollPanel
-- @return BorderImage#BorderImage

---
-- Function GetScrollBarsAutoVisible
--
-- @function [parent=#ScrollView] GetScrollBarsAutoVisible
-- @return #boolean

---
-- Function GetScrollStep
--
-- @function [parent=#ScrollView] GetScrollStep
-- @return #number

---
-- Function GetPageStep
--
-- @function [parent=#ScrollView] GetPageStep
-- @return #number

---
-- Field viewPosition
--
-- @field [parent=#ScrollView] IntVector2#IntVector2 viewPosition

---
-- Field contentElement
--
-- @field [parent=#ScrollView] UIElement#UIElement contentElement

---
-- Field horizontalScrollBar (Read only)
--
-- @field [parent=#ScrollView] ScrollBar#ScrollBar horizontalScrollBar

---
-- Field verticalScrollBar (Read only)
--
-- @field [parent=#ScrollView] ScrollBar#ScrollBar verticalScrollBar

---
-- Field scrollPanel (Read only)
--
-- @field [parent=#ScrollView] BorderImage#BorderImage scrollPanel

---
-- Field scrollBarsAutoVisible
--
-- @field [parent=#ScrollView] #boolean scrollBarsAutoVisible

---
-- Field scrollStep
--
-- @field [parent=#ScrollView] #number scrollStep

---
-- Field pageStep
--
-- @field [parent=#ScrollView] #number pageStep


return nil
