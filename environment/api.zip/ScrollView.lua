---
-- Module ScrollView
-- extends UIElement
--
-- @module ScrollView

---
-- Function ScrollView
--
-- @function [parent=#ScrollView] ScrollView

---
-- Function new
--
-- @function [parent=#ScrollView] new
-- @return ScrollView#ScrollView

---
-- Function delete
--
-- @function [parent=#ScrollView] delete

---
-- Function SetContentElement
--
-- @function [parent=#ScrollView] SetContentElement
-- @param UIElement#UIElement elementelement

---
-- Function SetViewPosition
--
-- @function [parent=#ScrollView] SetViewPosition
-- @param IntVector2#IntVector2 positionposition

---
-- Function SetViewPosition
--
-- @function [parent=#ScrollView] SetViewPosition
-- @param #number xx
-- @param #number yy

---
-- Function SetScrollBarsVisible
--
-- @function [parent=#ScrollView] SetScrollBarsVisible
-- @param #boolean horizontalhorizontal
-- @param #boolean verticalvertical

---
-- Function SetScrollBarsAutoVisible
--
-- @function [parent=#ScrollView] SetScrollBarsAutoVisible
-- @param #boolean enableenable

---
-- Function SetScrollStep
--
-- @function [parent=#ScrollView] SetScrollStep
-- @param #number stepstep

---
-- Function SetPageStep
--
-- @function [parent=#ScrollView] SetPageStep
-- @param #number stepstep

---
-- Function GetViewPosition
--
-- @function [parent=#ScrollView] GetViewPosition
-- @return const IntVector2#const IntVector2

---
-- Function GetContentElement
--
-- @function [parent=#ScrollView] GetContentElement
-- @return UIElement#UIElement

---
-- Function GetHorizontalScrollBar
--
-- @function [parent=#ScrollView] GetHorizontalScrollBar
-- @return ScrollBar#ScrollBar

---
-- Function GetVerticalScrollBar
--
-- @function [parent=#ScrollView] GetVerticalScrollBar
-- @return ScrollBar#ScrollBar

---
-- Function GetScrollPanel
--
-- @function [parent=#ScrollView] GetScrollPanel
-- @return BorderImage#BorderImage

---
-- Function GetScrollBarsAutoVisible
--
-- @function [parent=#ScrollView] GetScrollBarsAutoVisible
-- @return #boolean

---
-- Function GetScrollStep
--
-- @function [parent=#ScrollView] GetScrollStep
-- @return #number

---
-- Function GetPageStep
--
-- @function [parent=#ScrollView] GetPageStep
-- @return #number

---
-- Field viewPosition
--
-- @field [parent=#ScrollView] IntVector2#IntVector2 viewPosition

---
-- Field contentElement
--
-- @field [parent=#ScrollView] UIElement#UIElement contentElement

---
-- Field horizontalScrollBar (Read only)
--
-- @field [parent=#ScrollView] ScrollBar#ScrollBar horizontalScrollBar

---
-- Field verticalScrollBar (Read only)
--
-- @field [parent=#ScrollView] ScrollBar#ScrollBar verticalScrollBar

---
-- Field scrollPanel (Read only)
--
-- @field [parent=#ScrollView] BorderImage#BorderImage scrollPanel

---
-- Field scrollBarsAutoVisible
--
-- @field [parent=#ScrollView] #boolean scrollBarsAutoVisible

---
-- Field scrollStep
--
-- @field [parent=#ScrollView] #number scrollStep

---
-- Field pageStep
--
-- @field [parent=#ScrollView] #number pageStep

---
-- Function UIElement
--
-- @function [parent=#ScrollView] UIElement

---
-- Function new
--
-- @function [parent=#ScrollView] new
-- @return UIElement#UIElement

---
-- Function delete
--
-- @function [parent=#ScrollView] delete

---
-- Function GetScreenPosition
--
-- @function [parent=#ScrollView] GetScreenPosition
-- @return const IntVector2#const IntVector2

---
-- Function LoadXML
--
-- @function [parent=#ScrollView] LoadXML
-- @param Deserializer#Deserializer sourcesource
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#ScrollView] SaveXML
-- @param Serializer#Serializer destdest
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#ScrollView] LoadXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#ScrollView] SaveXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function FilterAttributes
--
-- @function [parent=#ScrollView] FilterAttributes
-- @param XMLElement#XMLElement destdest
-- @return #boolean

---
-- Function SetName
--
-- @function [parent=#ScrollView] SetName
-- @param #string namename

---
-- Function SetPosition
--
-- @function [parent=#ScrollView] SetPosition
-- @param IntVector2#IntVector2 positionposition

---
-- Function SetPosition
--
-- @function [parent=#ScrollView] SetPosition
-- @param #number xx
-- @param #number yy

---
-- Function SetSize
--
-- @function [parent=#ScrollView] SetSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function SetSize
--
-- @function [parent=#ScrollView] SetSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetWidth
--
-- @function [parent=#ScrollView] SetWidth
-- @param #number widthwidth

---
-- Function SetHeight
--
-- @function [parent=#ScrollView] SetHeight
-- @param #number heightheight

---
-- Function SetMinSize
--
-- @function [parent=#ScrollView] SetMinSize
-- @param IntVector2#IntVector2 minSizeminSize

---
-- Function SetMinSize
--
-- @function [parent=#ScrollView] SetMinSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetMinWidth
--
-- @function [parent=#ScrollView] SetMinWidth
-- @param #number widthwidth

---
-- Function SetMinHeight
--
-- @function [parent=#ScrollView] SetMinHeight
-- @param #number heightheight

---
-- Function SetMaxSize
--
-- @function [parent=#ScrollView] SetMaxSize
-- @param IntVector2#IntVector2 maxSizemaxSize

---
-- Function SetMaxSize
--
-- @function [parent=#ScrollView] SetMaxSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetMaxWidth
--
-- @function [parent=#ScrollView] SetMaxWidth
-- @param #number widthwidth

---
-- Function SetMaxHeight
--
-- @function [parent=#ScrollView] SetMaxHeight
-- @param #number heightheight

---
-- Function SetFixedSize
--
-- @function [parent=#ScrollView] SetFixedSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function SetFixedSize
--
-- @function [parent=#ScrollView] SetFixedSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetFixedWidth
--
-- @function [parent=#ScrollView] SetFixedWidth
-- @param #number widthwidth

---
-- Function SetFixedHeight
--
-- @function [parent=#ScrollView] SetFixedHeight
-- @param #number heightheight

---
-- Function SetAlignment
--
-- @function [parent=#ScrollView] SetAlignment
-- @param HorizontalAlignment#HorizontalAlignment hAlignhAlign
-- @param VerticalAlignment#VerticalAlignment vAlignvAlign

---
-- Function SetHorizontalAlignment
--
-- @function [parent=#ScrollView] SetHorizontalAlignment
-- @param HorizontalAlignment#HorizontalAlignment alignalign

---
-- Function SetVerticalAlignment
--
-- @function [parent=#ScrollView] SetVerticalAlignment
-- @param VerticalAlignment#VerticalAlignment alignalign

---
-- Function SetClipBorder
--
-- @function [parent=#ScrollView] SetClipBorder
-- @param IntRect#IntRect rectrect

---
-- Function SetColor
--
-- @function [parent=#ScrollView] SetColor
-- @param Color#Color colorcolor

---
-- Function SetColor
--
-- @function [parent=#ScrollView] SetColor
-- @param Corner#Corner cornercorner
-- @param Color#Color colorcolor

---
-- Function SetPriority
--
-- @function [parent=#ScrollView] SetPriority
-- @param #number prioritypriority

---
-- Function SetOpacity
--
-- @function [parent=#ScrollView] SetOpacity
-- @param #number opacityopacity

---
-- Function SetBringToFront
--
-- @function [parent=#ScrollView] SetBringToFront
-- @param #boolean enableenable

---
-- Function SetBringToBack
--
-- @function [parent=#ScrollView] SetBringToBack
-- @param #boolean enableenable

---
-- Function SetClipChildren
--
-- @function [parent=#ScrollView] SetClipChildren
-- @param #boolean enableenable

---
-- Function SetSortChildren
--
-- @function [parent=#ScrollView] SetSortChildren
-- @param #boolean enableenable

---
-- Function SetUseDerivedOpacity
--
-- @function [parent=#ScrollView] SetUseDerivedOpacity
-- @param #boolean enableenable

---
-- Function SetEnabled
--
-- @function [parent=#ScrollView] SetEnabled
-- @param #boolean enableenable

---
-- Function SetEditable
--
-- @function [parent=#ScrollView] SetEditable
-- @param #boolean enableenable

---
-- Function SetFocus
--
-- @function [parent=#ScrollView] SetFocus
-- @param #boolean enableenable

---
-- Function SetSelected
--
-- @function [parent=#ScrollView] SetSelected
-- @param #boolean enableenable

---
-- Function SetVisible
--
-- @function [parent=#ScrollView] SetVisible
-- @param #boolean enableenable

---
-- Function SetFocusMode
--
-- @function [parent=#ScrollView] SetFocusMode
-- @param FocusMode#FocusMode modemode

---
-- Function SetDragDropMode
--
-- @function [parent=#ScrollView] SetDragDropMode
-- @param #number modemode

---
-- Function SetStyle
--
-- @function [parent=#ScrollView] SetStyle
-- @param #string styleNamestyleName
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetStyle
--
-- @function [parent=#ScrollView] SetStyle
-- @param XMLElement#XMLElement elementelement
-- @return #boolean

---
-- Function SetStyleAuto
--
-- @function [parent=#ScrollView] SetStyleAuto
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetDefaultStyle
--
-- @function [parent=#ScrollView] SetDefaultStyle
-- @param XMLFile#XMLFile stylestyle

---
-- Function SetLayout
--
-- @function [parent=#ScrollView] SetLayout
-- @param LayoutMode#LayoutMode modemode
-- @param #number spacingspacing

---
-- Function SetLayout
--
-- @function [parent=#ScrollView] SetLayout
-- @param LayoutMode#LayoutMode modemode
-- @param #number spacingspacing
-- @param IntRect#IntRect borderborder

---
-- Function SetLayoutMode
--
-- @function [parent=#ScrollView] SetLayoutMode
-- @param LayoutMode#LayoutMode modemode

---
-- Function SetLayoutSpacing
--
-- @function [parent=#ScrollView] SetLayoutSpacing
-- @param #number spacingspacing

---
-- Function SetLayoutBorder
--
-- @function [parent=#ScrollView] SetLayoutBorder
-- @param IntRect#IntRect borderborder

---
-- Function SetIndent
--
-- @function [parent=#ScrollView] SetIndent
-- @param #number indentindent

---
-- Function SetIndentSpacing
--
-- @function [parent=#ScrollView] SetIndentSpacing
-- @param #number indentSpacingindentSpacing

---
-- Function UpdateLayout
--
-- @function [parent=#ScrollView] UpdateLayout

---
-- Function DisableLayoutUpdate
--
-- @function [parent=#ScrollView] DisableLayoutUpdate

---
-- Function EnableLayoutUpdate
--
-- @function [parent=#ScrollView] EnableLayoutUpdate

---
-- Function BringToFront
--
-- @function [parent=#ScrollView] BringToFront

---
-- Function CreateChild
--
-- @function [parent=#ScrollView] CreateChild
-- @param #string typetype
-- @param #string namename
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function AddChild
--
-- @function [parent=#ScrollView] AddChild
-- @param UIElement#UIElement elementelement

---
-- Function InsertChild
--
-- @function [parent=#ScrollView] InsertChild
-- @param #number indexindex
-- @param UIElement#UIElement elementelement

---
-- Function RemoveChild
--
-- @function [parent=#ScrollView] RemoveChild
-- @param UIElement#UIElement elementelement
-- @param #number indexindex

---
-- Function RemoveChildAtIndex
--
-- @function [parent=#ScrollView] RemoveChildAtIndex
-- @param #number indexindex

---
-- Function RemoveAllChildren
--
-- @function [parent=#ScrollView] RemoveAllChildren

---
-- Function Remove
--
-- @function [parent=#ScrollView] Remove

---
-- Function FindChild
--
-- @function [parent=#ScrollView] FindChild
-- @param UIElement#UIElement elementelement
-- @return #number

---
-- Function SetParent
--
-- @function [parent=#ScrollView] SetParent
-- @param UIElement#UIElement parentparent
-- @param #number indexindex

---
-- Function SetVar
--
-- @function [parent=#ScrollView] SetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @param Variant#Variant valuevalue

---
-- Function SetInternal
--
-- @function [parent=#ScrollView] SetInternal
-- @param #boolean enableenable

---
-- Function SetTraversalMode
--
-- @function [parent=#ScrollView] SetTraversalMode
-- @param TraversalMode#TraversalMode traversalModetraversalMode

---
-- Function SetElementEventSender
--
-- @function [parent=#ScrollView] SetElementEventSender
-- @param #boolean flagflag

---
-- Function GetName
--
-- @function [parent=#ScrollView] GetName
-- @return const String#const String

---
-- Function GetPosition
--
-- @function [parent=#ScrollView] GetPosition
-- @return const IntVector2#const IntVector2

---
-- Function GetSize
--
-- @function [parent=#ScrollView] GetSize
-- @return const IntVector2#const IntVector2

---
-- Function GetWidth
--
-- @function [parent=#ScrollView] GetWidth
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#ScrollView] GetHeight
-- @return #number

---
-- Function GetMinSize
--
-- @function [parent=#ScrollView] GetMinSize
-- @return const IntVector2#const IntVector2

---
-- Function GetMinWidth
--
-- @function [parent=#ScrollView] GetMinWidth
-- @return #number

---
-- Function GetMinHeight
--
-- @function [parent=#ScrollView] GetMinHeight
-- @return #number

---
-- Function GetMaxSize
--
-- @function [parent=#ScrollView] GetMaxSize
-- @return const IntVector2#const IntVector2

---
-- Function GetMaxWidth
--
-- @function [parent=#ScrollView] GetMaxWidth
-- @return #number

---
-- Function GetMaxHeight
--
-- @function [parent=#ScrollView] GetMaxHeight
-- @return #number

---
-- Function IsFixedSize
--
-- @function [parent=#ScrollView] IsFixedSize
-- @return #boolean

---
-- Function IsFixedWidth
--
-- @function [parent=#ScrollView] IsFixedWidth
-- @return #boolean

---
-- Function IsFixedHeight
--
-- @function [parent=#ScrollView] IsFixedHeight
-- @return #boolean

---
-- Function GetChildOffset
--
-- @function [parent=#ScrollView] GetChildOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetHorizontalAlignment
--
-- @function [parent=#ScrollView] GetHorizontalAlignment
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetVerticalAlignment
--
-- @function [parent=#ScrollView] GetVerticalAlignment
-- @return VerticalAlignment#VerticalAlignment

---
-- Function GetClipBorder
--
-- @function [parent=#ScrollView] GetClipBorder
-- @return const IntRect#const IntRect

---
-- Function GetColor
--
-- @function [parent=#ScrollView] GetColor
-- @param Corner#Corner cornercorner
-- @return const Color#const Color

---
-- Function GetPriority
--
-- @function [parent=#ScrollView] GetPriority
-- @return #number

---
-- Function GetOpacity
--
-- @function [parent=#ScrollView] GetOpacity
-- @return #number

---
-- Function GetDerivedOpacity
--
-- @function [parent=#ScrollView] GetDerivedOpacity
-- @return #number

---
-- Function GetBringToFront
--
-- @function [parent=#ScrollView] GetBringToFront
-- @return #boolean

---
-- Function GetBringToBack
--
-- @function [parent=#ScrollView] GetBringToBack
-- @return #boolean

---
-- Function GetClipChildren
--
-- @function [parent=#ScrollView] GetClipChildren
-- @return #boolean

---
-- Function GetSortChildren
--
-- @function [parent=#ScrollView] GetSortChildren
-- @return #boolean

---
-- Function GetUseDerivedOpacity
--
-- @function [parent=#ScrollView] GetUseDerivedOpacity
-- @return #boolean

---
-- Function HasFocus
--
-- @function [parent=#ScrollView] HasFocus
-- @return #boolean

---
-- Function IsEnabled
--
-- @function [parent=#ScrollView] IsEnabled
-- @return #boolean

---
-- Function IsEditable
--
-- @function [parent=#ScrollView] IsEditable
-- @return #boolean

---
-- Function IsSelected
--
-- @function [parent=#ScrollView] IsSelected
-- @return #boolean

---
-- Function IsVisible
--
-- @function [parent=#ScrollView] IsVisible
-- @return #boolean

---
-- Function IsHovering
--
-- @function [parent=#ScrollView] IsHovering
-- @return #boolean

---
-- Function IsInternal
--
-- @function [parent=#ScrollView] IsInternal
-- @return #boolean

---
-- Function HasColorGradient
--
-- @function [parent=#ScrollView] HasColorGradient
-- @return #boolean

---
-- Function GetFocusMode
--
-- @function [parent=#ScrollView] GetFocusMode
-- @return FocusMode#FocusMode

---
-- Function GetDragDropMode
--
-- @function [parent=#ScrollView] GetDragDropMode
-- @return #number

---
-- Function GetAppliedStyle
--
-- @function [parent=#ScrollView] GetAppliedStyle
-- @return const String#const String

---
-- Function GetDefaultStyle
--
-- @function [parent=#ScrollView] GetDefaultStyle
-- @param #boolean recursiveUprecursiveUp
-- @return XMLFile#XMLFile

---
-- Function GetLayoutMode
--
-- @function [parent=#ScrollView] GetLayoutMode
-- @return LayoutMode#LayoutMode

---
-- Function GetLayoutSpacing
--
-- @function [parent=#ScrollView] GetLayoutSpacing
-- @return #number

---
-- Function GetLayoutBorder
--
-- @function [parent=#ScrollView] GetLayoutBorder
-- @return const IntRect#const IntRect

---
-- Function GetNumChildren
--
-- @function [parent=#ScrollView] GetNumChildren
-- @param #boolean recursiverecursive
-- @return #number

---
-- Function GetChild
--
-- @function [parent=#ScrollView] GetChild
-- @param #string namename
-- @param #boolean recursiverecursive
-- @return UIElement#UIElement

---
-- Function GetChild
--
-- @function [parent=#ScrollView] GetChild
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function GetParent
--
-- @function [parent=#ScrollView] GetParent
-- @return UIElement#UIElement

---
-- Function GetRoot
--
-- @function [parent=#ScrollView] GetRoot
-- @return UIElement#UIElement

---
-- Function GetDerivedColor
--
-- @function [parent=#ScrollView] GetDerivedColor
-- @return const Color#const Color

---
-- Function GetVar
--
-- @function [parent=#ScrollView] GetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @return const Variant#const Variant

---
-- Function GetVars
--
-- @function [parent=#ScrollView] GetVars
-- @return const VariantMap#const VariantMap

---
-- Function ScreenToElement
--
-- @function [parent=#ScrollView] ScreenToElement
-- @param IntVector2#IntVector2 screenPositionscreenPosition
-- @return IntVector2#IntVector2

---
-- Function ElementToScreen
--
-- @function [parent=#ScrollView] ElementToScreen
-- @param IntVector2#IntVector2 positionposition
-- @return IntVector2#IntVector2

---
-- Function IsInside
--
-- @function [parent=#ScrollView] IsInside
-- @param IntVector2#IntVector2 positionposition
-- @param #boolean isScreenisScreen
-- @return #boolean

---
-- Function IsInsideCombined
--
-- @function [parent=#ScrollView] IsInsideCombined
-- @param IntVector2#IntVector2 positionposition
-- @param #boolean isScreenisScreen
-- @return #boolean

---
-- Function GetCombinedScreenRect
--
-- @function [parent=#ScrollView] GetCombinedScreenRect
-- @return IntRect#IntRect

---
-- Function SortChildren
--
-- @function [parent=#ScrollView] SortChildren

---
-- Function GetLayoutMinSize
--
-- @function [parent=#ScrollView] GetLayoutMinSize
-- @return #number

---
-- Function GetIndent
--
-- @function [parent=#ScrollView] GetIndent
-- @return #number

---
-- Function GetIndentSpacing
--
-- @function [parent=#ScrollView] GetIndentSpacing
-- @return #number

---
-- Function GetIndentWidth
--
-- @function [parent=#ScrollView] GetIndentWidth
-- @return #number

---
-- Function SetChildOffset
--
-- @function [parent=#ScrollView] SetChildOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetHovering
--
-- @function [parent=#ScrollView] SetHovering
-- @param #boolean enableenable

---
-- Function GetColor
--
-- @function [parent=#ScrollView] GetColor
-- @return const Color#const Color

---
-- Function GetTraversalMode
--
-- @function [parent=#ScrollView] GetTraversalMode
-- @return TraversalMode#TraversalMode

---
-- Function IsElementEventSender
--
-- @function [parent=#ScrollView] IsElementEventSender
-- @return #boolean

---
-- Function GetElementEventSender
--
-- @function [parent=#ScrollView] GetElementEventSender
-- @return UIElement#UIElement

---
-- Field screenPosition (Read only)
--
-- @field [parent=#ScrollView] IntVector2#IntVector2 screenPosition

---
-- Field name
--
-- @field [parent=#ScrollView] #string name

---
-- Field position
--
-- @field [parent=#ScrollView] IntVector2#IntVector2 position

---
-- Field size
--
-- @field [parent=#ScrollView] IntVector2#IntVector2 size

---
-- Field width
--
-- @field [parent=#ScrollView] #number width

---
-- Field height
--
-- @field [parent=#ScrollView] #number height

---
-- Field minSize
--
-- @field [parent=#ScrollView] IntVector2#IntVector2 minSize

---
-- Field minWidth
--
-- @field [parent=#ScrollView] #number minWidth

---
-- Field minHeight
--
-- @field [parent=#ScrollView] #number minHeight

---
-- Field maxSize
--
-- @field [parent=#ScrollView] IntVector2#IntVector2 maxSize

---
-- Field maxWidth
--
-- @field [parent=#ScrollView] #number maxWidth

---
-- Field maxHeight
--
-- @field [parent=#ScrollView] #number maxHeight

---
-- Field fixedSize (Read only)
--
-- @field [parent=#ScrollView] #boolean fixedSize

---
-- Field fixedWidth (Read only)
--
-- @field [parent=#ScrollView] #boolean fixedWidth

---
-- Field fixedHeight (Read only)
--
-- @field [parent=#ScrollView] #boolean fixedHeight

---
-- Field childOffset
--
-- @field [parent=#ScrollView] IntVector2#IntVector2 childOffset

---
-- Field horizontalAlignment
--
-- @field [parent=#ScrollView] HorizontalAlignment#HorizontalAlignment horizontalAlignment

---
-- Field verticalAlignment
--
-- @field [parent=#ScrollView] VerticalAlignment#VerticalAlignment verticalAlignment

---
-- Field clipBorder
--
-- @field [parent=#ScrollView] IntRect#IntRect clipBorder

---
-- Field color
--
-- @field [parent=#ScrollView] Color#Color color

---
-- Field priority
--
-- @field [parent=#ScrollView] #number priority

---
-- Field opacity
--
-- @field [parent=#ScrollView] #number opacity

---
-- Field derivedOpacity (Read only)
--
-- @field [parent=#ScrollView] #number derivedOpacity

---
-- Field bringToFront
--
-- @field [parent=#ScrollView] #boolean bringToFront

---
-- Field bringToBack
--
-- @field [parent=#ScrollView] #boolean bringToBack

---
-- Field clipChildren
--
-- @field [parent=#ScrollView] #boolean clipChildren

---
-- Field sortChildren
--
-- @field [parent=#ScrollView] #boolean sortChildren

---
-- Field useDerivedOpacity
--
-- @field [parent=#ScrollView] #boolean useDerivedOpacity

---
-- Field focus
--
-- @field [parent=#ScrollView] #boolean focus

---
-- Field enabled
--
-- @field [parent=#ScrollView] #boolean enabled

---
-- Field editable
--
-- @field [parent=#ScrollView] #boolean editable

---
-- Field selected
--
-- @field [parent=#ScrollView] #boolean selected

---
-- Field visible
--
-- @field [parent=#ScrollView] #boolean visible

---
-- Field hovering
--
-- @field [parent=#ScrollView] #boolean hovering

---
-- Field internal
--
-- @field [parent=#ScrollView] #boolean internal

---
-- Field colorGradient (Read only)
--
-- @field [parent=#ScrollView] #boolean colorGradient

---
-- Field focusMode
--
-- @field [parent=#ScrollView] FocusMode#FocusMode focusMode

---
-- Field dragDropMode
--
-- @field [parent=#ScrollView] #number dragDropMode

---
-- Field style
--
-- @field [parent=#ScrollView] #string style

---
-- Field defaultStyle
--
-- @field [parent=#ScrollView] XMLFile#XMLFile defaultStyle

---
-- Field layoutMode
--
-- @field [parent=#ScrollView] LayoutMode#LayoutMode layoutMode

---
-- Field layoutSpacing
--
-- @field [parent=#ScrollView] #number layoutSpacing

---
-- Field layoutBorder
--
-- @field [parent=#ScrollView] IntRect#IntRect layoutBorder

---
-- Field numChildren (Read only)
--
-- @field [parent=#ScrollView] #number numChildren

---
-- Field parent
--
-- @field [parent=#ScrollView] UIElement#UIElement parent

---
-- Field root (Read only)
--
-- @field [parent=#ScrollView] UIElement#UIElement root

---
-- Field derivedColor (Read only)
--
-- @field [parent=#ScrollView] Color#Color derivedColor

---
-- Field combinedScreenRect (Read only)
--
-- @field [parent=#ScrollView] IntRect#IntRect combinedScreenRect

---
-- Field layoutMinSize (Read only)
--
-- @field [parent=#ScrollView] #number layoutMinSize

---
-- Field indent
--
-- @field [parent=#ScrollView] #number indent

---
-- Field indentSpacing
--
-- @field [parent=#ScrollView] #number indentSpacing

---
-- Field indentWidth (Read only)
--
-- @field [parent=#ScrollView] #number indentWidth

---
-- Field traversalMode
--
-- @field [parent=#ScrollView] TraversalMode#TraversalMode traversalMode

---
-- Field elementEventSender
--
-- @field [parent=#ScrollView] #boolean elementEventSender

---
-- Function SetTemporary
--
-- @function [parent=#ScrollView] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#ScrollView] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#ScrollView] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#ScrollView] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#ScrollView] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#ScrollView] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#ScrollView] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#ScrollView] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#ScrollView] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#ScrollView] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#ScrollView] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#ScrollView] #string category


return nil
