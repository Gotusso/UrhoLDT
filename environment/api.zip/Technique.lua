---
-- Module Technique
-- Module Technique extends Resource
-- Generated on 2014-05-31
--
-- @module Technique

---
-- Function HasPass()
--
-- @function [parent=#Technique] HasPass
-- @param self Self reference
-- @param #string type type
-- @return #boolean

---
-- Function GetPass()
--
-- @function [parent=#Technique] GetPass
-- @param self Self reference
-- @param #string type type
-- @return Pass#Pass

---
-- Function IsSM3()
-- Return whether requires %Shader %Model 3.
--
-- @function [parent=#Technique] IsSM3
-- @param self Self reference
-- @return #boolean

---
-- Field SM3 (Read only)
--
-- @field [parent=#Technique] #boolean SM3


return nil
