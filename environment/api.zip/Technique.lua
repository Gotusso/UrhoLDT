---
-- Module Technique
-- Extends Resource
--
-- @module Technique

---
-- Function HasPass
--
-- @function [parent=#Technique] HasPass
-- @param #string typetype
-- @return #boolean

---
-- Function GetPass
--
-- @function [parent=#Technique] GetPass
-- @param #string typetype
-- @return Pass#Pass

---
-- Function IsSM3
--
-- @function [parent=#Technique] IsSM3
-- @return #boolean

---
-- Field SM3 (Read only)
--
-- @field [parent=#Technique] #boolean SM3


return nil
