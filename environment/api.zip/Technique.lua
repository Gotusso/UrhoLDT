---
-- Module Technique
-- extends Resource
--
-- @module Technique

---
-- Function HasPass
--
-- @function [parent=#Technique] HasPass
-- @param #string typetype
-- @return #boolean

---
-- Function GetPass
--
-- @function [parent=#Technique] GetPass
-- @param #string typetype
-- @return Pass#Pass

---
-- Function IsSM3
--
-- @function [parent=#Technique] IsSM3
-- @return #boolean

---
-- Field SM3 (Read only)
--
-- @field [parent=#Technique] #boolean SM3

---
-- Function Load
--
-- @function [parent=#Technique] Load
-- @param Deserializer#Deserializer sourcesource
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#Technique] Save
-- @param Serializer#Serializer destdest
-- @return #boolean

---
-- Function Load
--
-- @function [parent=#Technique] Load
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#Technique] Save
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function GetName
--
-- @function [parent=#Technique] GetName
-- @return const String#const String

---
-- Function GetNameHash
--
-- @function [parent=#Technique] GetNameHash
-- @return StringHash#StringHash

---
-- Function GetMemoryUse
--
-- @function [parent=#Technique] GetMemoryUse
-- @return #number

---
-- Field name (Read only)
--
-- @field [parent=#Technique] #string name

---
-- Field nameHash (Read only)
--
-- @field [parent=#Technique] StringHash#StringHash nameHash

---
-- Field memoryUse (Read only)
--
-- @field [parent=#Technique] #number memoryUse


return nil
