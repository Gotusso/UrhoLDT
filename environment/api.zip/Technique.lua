---
-- Module Technique
-- Module Technique extends Resource
-- Generated on 2014-03-13
--
-- @module Technique

---
-- Function HasPass
--
-- @function [parent=#Technique] HasPass
-- @param self Self reference
-- @param #string type type
-- @return #boolean

---
-- Function GetPass
--
-- @function [parent=#Technique] GetPass
-- @param self Self reference
-- @param #string type type
-- @return Pass#Pass

---
-- Function IsSM3
--
-- @function [parent=#Technique] IsSM3
-- @param self Self reference
-- @return #boolean

---
-- Field SM3 (Read only)
--
-- @field [parent=#Technique] #boolean SM3

---
-- Function Load
--
-- @function [parent=#Technique] Load
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#Technique] Save
-- @param self Self reference
-- @param Serializer#Serializer dest dest
-- @return #boolean

---
-- Function Load
--
-- @function [parent=#Technique] Load
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#Technique] Save
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function GetName
--
-- @function [parent=#Technique] GetName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetNameHash
--
-- @function [parent=#Technique] GetNameHash
-- @param self Self reference
-- @return StringHash#StringHash

---
-- Function GetMemoryUse
--
-- @function [parent=#Technique] GetMemoryUse
-- @param self Self reference
-- @return #number

---
-- Field name (Read only)
--
-- @field [parent=#Technique] #string name

---
-- Field nameHash (Read only)
--
-- @field [parent=#Technique] StringHash#StringHash nameHash

---
-- Field memoryUse (Read only)
--
-- @field [parent=#Technique] #number memoryUse


return nil
