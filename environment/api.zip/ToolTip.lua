---
-- Module ToolTip
-- extends UIElement
--
-- @module ToolTip

---
-- Function ToolTip
--
-- @function [parent=#ToolTip] ToolTip

---
-- Function new
--
-- @function [parent=#ToolTip] new
-- @return ToolTip#ToolTip

---
-- Function delete
--
-- @function [parent=#ToolTip] delete

---
-- Function SetDelay
--
-- @function [parent=#ToolTip] SetDelay
-- @param #number delaydelay

---
-- Function GetDelay
--
-- @function [parent=#ToolTip] GetDelay
-- @return #number

---
-- Field delay
--
-- @field [parent=#ToolTip] #number delay

---
-- Function UIElement
--
-- @function [parent=#ToolTip] UIElement

---
-- Function new
--
-- @function [parent=#ToolTip] new
-- @return UIElement#UIElement

---
-- Function delete
--
-- @function [parent=#ToolTip] delete

---
-- Function GetScreenPosition
--
-- @function [parent=#ToolTip] GetScreenPosition
-- @return const IntVector2#const IntVector2

---
-- Function LoadXML
--
-- @function [parent=#ToolTip] LoadXML
-- @param Deserializer#Deserializer sourcesource
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#ToolTip] SaveXML
-- @param Serializer#Serializer destdest
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#ToolTip] LoadXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#ToolTip] SaveXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function FilterAttributes
--
-- @function [parent=#ToolTip] FilterAttributes
-- @param XMLElement#XMLElement destdest
-- @return #boolean

---
-- Function SetName
--
-- @function [parent=#ToolTip] SetName
-- @param #string namename

---
-- Function SetPosition
--
-- @function [parent=#ToolTip] SetPosition
-- @param IntVector2#IntVector2 positionposition

---
-- Function SetPosition
--
-- @function [parent=#ToolTip] SetPosition
-- @param #number xx
-- @param #number yy

---
-- Function SetSize
--
-- @function [parent=#ToolTip] SetSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function SetSize
--
-- @function [parent=#ToolTip] SetSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetWidth
--
-- @function [parent=#ToolTip] SetWidth
-- @param #number widthwidth

---
-- Function SetHeight
--
-- @function [parent=#ToolTip] SetHeight
-- @param #number heightheight

---
-- Function SetMinSize
--
-- @function [parent=#ToolTip] SetMinSize
-- @param IntVector2#IntVector2 minSizeminSize

---
-- Function SetMinSize
--
-- @function [parent=#ToolTip] SetMinSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetMinWidth
--
-- @function [parent=#ToolTip] SetMinWidth
-- @param #number widthwidth

---
-- Function SetMinHeight
--
-- @function [parent=#ToolTip] SetMinHeight
-- @param #number heightheight

---
-- Function SetMaxSize
--
-- @function [parent=#ToolTip] SetMaxSize
-- @param IntVector2#IntVector2 maxSizemaxSize

---
-- Function SetMaxSize
--
-- @function [parent=#ToolTip] SetMaxSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetMaxWidth
--
-- @function [parent=#ToolTip] SetMaxWidth
-- @param #number widthwidth

---
-- Function SetMaxHeight
--
-- @function [parent=#ToolTip] SetMaxHeight
-- @param #number heightheight

---
-- Function SetFixedSize
--
-- @function [parent=#ToolTip] SetFixedSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function SetFixedSize
--
-- @function [parent=#ToolTip] SetFixedSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetFixedWidth
--
-- @function [parent=#ToolTip] SetFixedWidth
-- @param #number widthwidth

---
-- Function SetFixedHeight
--
-- @function [parent=#ToolTip] SetFixedHeight
-- @param #number heightheight

---
-- Function SetAlignment
--
-- @function [parent=#ToolTip] SetAlignment
-- @param HorizontalAlignment#HorizontalAlignment hAlignhAlign
-- @param VerticalAlignment#VerticalAlignment vAlignvAlign

---
-- Function SetHorizontalAlignment
--
-- @function [parent=#ToolTip] SetHorizontalAlignment
-- @param HorizontalAlignment#HorizontalAlignment alignalign

---
-- Function SetVerticalAlignment
--
-- @function [parent=#ToolTip] SetVerticalAlignment
-- @param VerticalAlignment#VerticalAlignment alignalign

---
-- Function SetClipBorder
--
-- @function [parent=#ToolTip] SetClipBorder
-- @param IntRect#IntRect rectrect

---
-- Function SetColor
--
-- @function [parent=#ToolTip] SetColor
-- @param Color#Color colorcolor

---
-- Function SetColor
--
-- @function [parent=#ToolTip] SetColor
-- @param Corner#Corner cornercorner
-- @param Color#Color colorcolor

---
-- Function SetPriority
--
-- @function [parent=#ToolTip] SetPriority
-- @param #number prioritypriority

---
-- Function SetOpacity
--
-- @function [parent=#ToolTip] SetOpacity
-- @param #number opacityopacity

---
-- Function SetBringToFront
--
-- @function [parent=#ToolTip] SetBringToFront
-- @param #boolean enableenable

---
-- Function SetBringToBack
--
-- @function [parent=#ToolTip] SetBringToBack
-- @param #boolean enableenable

---
-- Function SetClipChildren
--
-- @function [parent=#ToolTip] SetClipChildren
-- @param #boolean enableenable

---
-- Function SetSortChildren
--
-- @function [parent=#ToolTip] SetSortChildren
-- @param #boolean enableenable

---
-- Function SetUseDerivedOpacity
--
-- @function [parent=#ToolTip] SetUseDerivedOpacity
-- @param #boolean enableenable

---
-- Function SetEnabled
--
-- @function [parent=#ToolTip] SetEnabled
-- @param #boolean enableenable

---
-- Function SetEditable
--
-- @function [parent=#ToolTip] SetEditable
-- @param #boolean enableenable

---
-- Function SetFocus
--
-- @function [parent=#ToolTip] SetFocus
-- @param #boolean enableenable

---
-- Function SetSelected
--
-- @function [parent=#ToolTip] SetSelected
-- @param #boolean enableenable

---
-- Function SetVisible
--
-- @function [parent=#ToolTip] SetVisible
-- @param #boolean enableenable

---
-- Function SetFocusMode
--
-- @function [parent=#ToolTip] SetFocusMode
-- @param FocusMode#FocusMode modemode

---
-- Function SetDragDropMode
--
-- @function [parent=#ToolTip] SetDragDropMode
-- @param #number modemode

---
-- Function SetStyle
--
-- @function [parent=#ToolTip] SetStyle
-- @param #string styleNamestyleName
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetStyle
--
-- @function [parent=#ToolTip] SetStyle
-- @param XMLElement#XMLElement elementelement
-- @return #boolean

---
-- Function SetStyleAuto
--
-- @function [parent=#ToolTip] SetStyleAuto
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetDefaultStyle
--
-- @function [parent=#ToolTip] SetDefaultStyle
-- @param XMLFile#XMLFile stylestyle

---
-- Function SetLayout
--
-- @function [parent=#ToolTip] SetLayout
-- @param LayoutMode#LayoutMode modemode
-- @param #number spacingspacing

---
-- Function SetLayout
--
-- @function [parent=#ToolTip] SetLayout
-- @param LayoutMode#LayoutMode modemode
-- @param #number spacingspacing
-- @param IntRect#IntRect borderborder

---
-- Function SetLayoutMode
--
-- @function [parent=#ToolTip] SetLayoutMode
-- @param LayoutMode#LayoutMode modemode

---
-- Function SetLayoutSpacing
--
-- @function [parent=#ToolTip] SetLayoutSpacing
-- @param #number spacingspacing

---
-- Function SetLayoutBorder
--
-- @function [parent=#ToolTip] SetLayoutBorder
-- @param IntRect#IntRect borderborder

---
-- Function SetIndent
--
-- @function [parent=#ToolTip] SetIndent
-- @param #number indentindent

---
-- Function SetIndentSpacing
--
-- @function [parent=#ToolTip] SetIndentSpacing
-- @param #number indentSpacingindentSpacing

---
-- Function UpdateLayout
--
-- @function [parent=#ToolTip] UpdateLayout

---
-- Function DisableLayoutUpdate
--
-- @function [parent=#ToolTip] DisableLayoutUpdate

---
-- Function EnableLayoutUpdate
--
-- @function [parent=#ToolTip] EnableLayoutUpdate

---
-- Function BringToFront
--
-- @function [parent=#ToolTip] BringToFront

---
-- Function CreateChild
--
-- @function [parent=#ToolTip] CreateChild
-- @param #string typetype
-- @param #string namename
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function AddChild
--
-- @function [parent=#ToolTip] AddChild
-- @param UIElement#UIElement elementelement

---
-- Function InsertChild
--
-- @function [parent=#ToolTip] InsertChild
-- @param #number indexindex
-- @param UIElement#UIElement elementelement

---
-- Function RemoveChild
--
-- @function [parent=#ToolTip] RemoveChild
-- @param UIElement#UIElement elementelement
-- @param #number indexindex

---
-- Function RemoveChildAtIndex
--
-- @function [parent=#ToolTip] RemoveChildAtIndex
-- @param #number indexindex

---
-- Function RemoveAllChildren
--
-- @function [parent=#ToolTip] RemoveAllChildren

---
-- Function Remove
--
-- @function [parent=#ToolTip] Remove

---
-- Function FindChild
--
-- @function [parent=#ToolTip] FindChild
-- @param UIElement#UIElement elementelement
-- @return #number

---
-- Function SetParent
--
-- @function [parent=#ToolTip] SetParent
-- @param UIElement#UIElement parentparent
-- @param #number indexindex

---
-- Function SetVar
--
-- @function [parent=#ToolTip] SetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @param Variant#Variant valuevalue

---
-- Function SetInternal
--
-- @function [parent=#ToolTip] SetInternal
-- @param #boolean enableenable

---
-- Function SetTraversalMode
--
-- @function [parent=#ToolTip] SetTraversalMode
-- @param TraversalMode#TraversalMode traversalModetraversalMode

---
-- Function SetElementEventSender
--
-- @function [parent=#ToolTip] SetElementEventSender
-- @param #boolean flagflag

---
-- Function GetName
--
-- @function [parent=#ToolTip] GetName
-- @return const String#const String

---
-- Function GetPosition
--
-- @function [parent=#ToolTip] GetPosition
-- @return const IntVector2#const IntVector2

---
-- Function GetSize
--
-- @function [parent=#ToolTip] GetSize
-- @return const IntVector2#const IntVector2

---
-- Function GetWidth
--
-- @function [parent=#ToolTip] GetWidth
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#ToolTip] GetHeight
-- @return #number

---
-- Function GetMinSize
--
-- @function [parent=#ToolTip] GetMinSize
-- @return const IntVector2#const IntVector2

---
-- Function GetMinWidth
--
-- @function [parent=#ToolTip] GetMinWidth
-- @return #number

---
-- Function GetMinHeight
--
-- @function [parent=#ToolTip] GetMinHeight
-- @return #number

---
-- Function GetMaxSize
--
-- @function [parent=#ToolTip] GetMaxSize
-- @return const IntVector2#const IntVector2

---
-- Function GetMaxWidth
--
-- @function [parent=#ToolTip] GetMaxWidth
-- @return #number

---
-- Function GetMaxHeight
--
-- @function [parent=#ToolTip] GetMaxHeight
-- @return #number

---
-- Function IsFixedSize
--
-- @function [parent=#ToolTip] IsFixedSize
-- @return #boolean

---
-- Function IsFixedWidth
--
-- @function [parent=#ToolTip] IsFixedWidth
-- @return #boolean

---
-- Function IsFixedHeight
--
-- @function [parent=#ToolTip] IsFixedHeight
-- @return #boolean

---
-- Function GetChildOffset
--
-- @function [parent=#ToolTip] GetChildOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetHorizontalAlignment
--
-- @function [parent=#ToolTip] GetHorizontalAlignment
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetVerticalAlignment
--
-- @function [parent=#ToolTip] GetVerticalAlignment
-- @return VerticalAlignment#VerticalAlignment

---
-- Function GetClipBorder
--
-- @function [parent=#ToolTip] GetClipBorder
-- @return const IntRect#const IntRect

---
-- Function GetColor
--
-- @function [parent=#ToolTip] GetColor
-- @param Corner#Corner cornercorner
-- @return const Color#const Color

---
-- Function GetPriority
--
-- @function [parent=#ToolTip] GetPriority
-- @return #number

---
-- Function GetOpacity
--
-- @function [parent=#ToolTip] GetOpacity
-- @return #number

---
-- Function GetDerivedOpacity
--
-- @function [parent=#ToolTip] GetDerivedOpacity
-- @return #number

---
-- Function GetBringToFront
--
-- @function [parent=#ToolTip] GetBringToFront
-- @return #boolean

---
-- Function GetBringToBack
--
-- @function [parent=#ToolTip] GetBringToBack
-- @return #boolean

---
-- Function GetClipChildren
--
-- @function [parent=#ToolTip] GetClipChildren
-- @return #boolean

---
-- Function GetSortChildren
--
-- @function [parent=#ToolTip] GetSortChildren
-- @return #boolean

---
-- Function GetUseDerivedOpacity
--
-- @function [parent=#ToolTip] GetUseDerivedOpacity
-- @return #boolean

---
-- Function HasFocus
--
-- @function [parent=#ToolTip] HasFocus
-- @return #boolean

---
-- Function IsEnabled
--
-- @function [parent=#ToolTip] IsEnabled
-- @return #boolean

---
-- Function IsEditable
--
-- @function [parent=#ToolTip] IsEditable
-- @return #boolean

---
-- Function IsSelected
--
-- @function [parent=#ToolTip] IsSelected
-- @return #boolean

---
-- Function IsVisible
--
-- @function [parent=#ToolTip] IsVisible
-- @return #boolean

---
-- Function IsHovering
--
-- @function [parent=#ToolTip] IsHovering
-- @return #boolean

---
-- Function IsInternal
--
-- @function [parent=#ToolTip] IsInternal
-- @return #boolean

---
-- Function HasColorGradient
--
-- @function [parent=#ToolTip] HasColorGradient
-- @return #boolean

---
-- Function GetFocusMode
--
-- @function [parent=#ToolTip] GetFocusMode
-- @return FocusMode#FocusMode

---
-- Function GetDragDropMode
--
-- @function [parent=#ToolTip] GetDragDropMode
-- @return #number

---
-- Function GetAppliedStyle
--
-- @function [parent=#ToolTip] GetAppliedStyle
-- @return const String#const String

---
-- Function GetDefaultStyle
--
-- @function [parent=#ToolTip] GetDefaultStyle
-- @param #boolean recursiveUprecursiveUp
-- @return XMLFile#XMLFile

---
-- Function GetLayoutMode
--
-- @function [parent=#ToolTip] GetLayoutMode
-- @return LayoutMode#LayoutMode

---
-- Function GetLayoutSpacing
--
-- @function [parent=#ToolTip] GetLayoutSpacing
-- @return #number

---
-- Function GetLayoutBorder
--
-- @function [parent=#ToolTip] GetLayoutBorder
-- @return const IntRect#const IntRect

---
-- Function GetNumChildren
--
-- @function [parent=#ToolTip] GetNumChildren
-- @param #boolean recursiverecursive
-- @return #number

---
-- Function GetChild
--
-- @function [parent=#ToolTip] GetChild
-- @param #string namename
-- @param #boolean recursiverecursive
-- @return UIElement#UIElement

---
-- Function GetChild
--
-- @function [parent=#ToolTip] GetChild
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function GetParent
--
-- @function [parent=#ToolTip] GetParent
-- @return UIElement#UIElement

---
-- Function GetRoot
--
-- @function [parent=#ToolTip] GetRoot
-- @return UIElement#UIElement

---
-- Function GetDerivedColor
--
-- @function [parent=#ToolTip] GetDerivedColor
-- @return const Color#const Color

---
-- Function GetVar
--
-- @function [parent=#ToolTip] GetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @return const Variant#const Variant

---
-- Function GetVars
--
-- @function [parent=#ToolTip] GetVars
-- @return const VariantMap#const VariantMap

---
-- Function ScreenToElement
--
-- @function [parent=#ToolTip] ScreenToElement
-- @param IntVector2#IntVector2 screenPositionscreenPosition
-- @return IntVector2#IntVector2

---
-- Function ElementToScreen
--
-- @function [parent=#ToolTip] ElementToScreen
-- @param IntVector2#IntVector2 positionposition
-- @return IntVector2#IntVector2

---
-- Function IsInside
--
-- @function [parent=#ToolTip] IsInside
-- @param IntVector2#IntVector2 positionposition
-- @param #boolean isScreenisScreen
-- @return #boolean

---
-- Function IsInsideCombined
--
-- @function [parent=#ToolTip] IsInsideCombined
-- @param IntVector2#IntVector2 positionposition
-- @param #boolean isScreenisScreen
-- @return #boolean

---
-- Function GetCombinedScreenRect
--
-- @function [parent=#ToolTip] GetCombinedScreenRect
-- @return IntRect#IntRect

---
-- Function SortChildren
--
-- @function [parent=#ToolTip] SortChildren

---
-- Function GetLayoutMinSize
--
-- @function [parent=#ToolTip] GetLayoutMinSize
-- @return #number

---
-- Function GetIndent
--
-- @function [parent=#ToolTip] GetIndent
-- @return #number

---
-- Function GetIndentSpacing
--
-- @function [parent=#ToolTip] GetIndentSpacing
-- @return #number

---
-- Function GetIndentWidth
--
-- @function [parent=#ToolTip] GetIndentWidth
-- @return #number

---
-- Function SetChildOffset
--
-- @function [parent=#ToolTip] SetChildOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetHovering
--
-- @function [parent=#ToolTip] SetHovering
-- @param #boolean enableenable

---
-- Function GetColor
--
-- @function [parent=#ToolTip] GetColor
-- @return const Color#const Color

---
-- Function GetTraversalMode
--
-- @function [parent=#ToolTip] GetTraversalMode
-- @return TraversalMode#TraversalMode

---
-- Function IsElementEventSender
--
-- @function [parent=#ToolTip] IsElementEventSender
-- @return #boolean

---
-- Function GetElementEventSender
--
-- @function [parent=#ToolTip] GetElementEventSender
-- @return UIElement#UIElement

---
-- Field screenPosition (Read only)
--
-- @field [parent=#ToolTip] IntVector2#IntVector2 screenPosition

---
-- Field name
--
-- @field [parent=#ToolTip] #string name

---
-- Field position
--
-- @field [parent=#ToolTip] IntVector2#IntVector2 position

---
-- Field size
--
-- @field [parent=#ToolTip] IntVector2#IntVector2 size

---
-- Field width
--
-- @field [parent=#ToolTip] #number width

---
-- Field height
--
-- @field [parent=#ToolTip] #number height

---
-- Field minSize
--
-- @field [parent=#ToolTip] IntVector2#IntVector2 minSize

---
-- Field minWidth
--
-- @field [parent=#ToolTip] #number minWidth

---
-- Field minHeight
--
-- @field [parent=#ToolTip] #number minHeight

---
-- Field maxSize
--
-- @field [parent=#ToolTip] IntVector2#IntVector2 maxSize

---
-- Field maxWidth
--
-- @field [parent=#ToolTip] #number maxWidth

---
-- Field maxHeight
--
-- @field [parent=#ToolTip] #number maxHeight

---
-- Field fixedSize (Read only)
--
-- @field [parent=#ToolTip] #boolean fixedSize

---
-- Field fixedWidth (Read only)
--
-- @field [parent=#ToolTip] #boolean fixedWidth

---
-- Field fixedHeight (Read only)
--
-- @field [parent=#ToolTip] #boolean fixedHeight

---
-- Field childOffset
--
-- @field [parent=#ToolTip] IntVector2#IntVector2 childOffset

---
-- Field horizontalAlignment
--
-- @field [parent=#ToolTip] HorizontalAlignment#HorizontalAlignment horizontalAlignment

---
-- Field verticalAlignment
--
-- @field [parent=#ToolTip] VerticalAlignment#VerticalAlignment verticalAlignment

---
-- Field clipBorder
--
-- @field [parent=#ToolTip] IntRect#IntRect clipBorder

---
-- Field color
--
-- @field [parent=#ToolTip] Color#Color color

---
-- Field priority
--
-- @field [parent=#ToolTip] #number priority

---
-- Field opacity
--
-- @field [parent=#ToolTip] #number opacity

---
-- Field derivedOpacity (Read only)
--
-- @field [parent=#ToolTip] #number derivedOpacity

---
-- Field bringToFront
--
-- @field [parent=#ToolTip] #boolean bringToFront

---
-- Field bringToBack
--
-- @field [parent=#ToolTip] #boolean bringToBack

---
-- Field clipChildren
--
-- @field [parent=#ToolTip] #boolean clipChildren

---
-- Field sortChildren
--
-- @field [parent=#ToolTip] #boolean sortChildren

---
-- Field useDerivedOpacity
--
-- @field [parent=#ToolTip] #boolean useDerivedOpacity

---
-- Field focus
--
-- @field [parent=#ToolTip] #boolean focus

---
-- Field enabled
--
-- @field [parent=#ToolTip] #boolean enabled

---
-- Field editable
--
-- @field [parent=#ToolTip] #boolean editable

---
-- Field selected
--
-- @field [parent=#ToolTip] #boolean selected

---
-- Field visible
--
-- @field [parent=#ToolTip] #boolean visible

---
-- Field hovering
--
-- @field [parent=#ToolTip] #boolean hovering

---
-- Field internal
--
-- @field [parent=#ToolTip] #boolean internal

---
-- Field colorGradient (Read only)
--
-- @field [parent=#ToolTip] #boolean colorGradient

---
-- Field focusMode
--
-- @field [parent=#ToolTip] FocusMode#FocusMode focusMode

---
-- Field dragDropMode
--
-- @field [parent=#ToolTip] #number dragDropMode

---
-- Field style
--
-- @field [parent=#ToolTip] #string style

---
-- Field defaultStyle
--
-- @field [parent=#ToolTip] XMLFile#XMLFile defaultStyle

---
-- Field layoutMode
--
-- @field [parent=#ToolTip] LayoutMode#LayoutMode layoutMode

---
-- Field layoutSpacing
--
-- @field [parent=#ToolTip] #number layoutSpacing

---
-- Field layoutBorder
--
-- @field [parent=#ToolTip] IntRect#IntRect layoutBorder

---
-- Field numChildren (Read only)
--
-- @field [parent=#ToolTip] #number numChildren

---
-- Field parent
--
-- @field [parent=#ToolTip] UIElement#UIElement parent

---
-- Field root (Read only)
--
-- @field [parent=#ToolTip] UIElement#UIElement root

---
-- Field derivedColor (Read only)
--
-- @field [parent=#ToolTip] Color#Color derivedColor

---
-- Field combinedScreenRect (Read only)
--
-- @field [parent=#ToolTip] IntRect#IntRect combinedScreenRect

---
-- Field layoutMinSize (Read only)
--
-- @field [parent=#ToolTip] #number layoutMinSize

---
-- Field indent
--
-- @field [parent=#ToolTip] #number indent

---
-- Field indentSpacing
--
-- @field [parent=#ToolTip] #number indentSpacing

---
-- Field indentWidth (Read only)
--
-- @field [parent=#ToolTip] #number indentWidth

---
-- Field traversalMode
--
-- @field [parent=#ToolTip] TraversalMode#TraversalMode traversalMode

---
-- Field elementEventSender
--
-- @field [parent=#ToolTip] #boolean elementEventSender

---
-- Function SetTemporary
--
-- @function [parent=#ToolTip] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#ToolTip] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#ToolTip] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#ToolTip] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#ToolTip] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#ToolTip] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#ToolTip] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#ToolTip] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#ToolTip] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#ToolTip] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#ToolTip] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#ToolTip] #string category


return nil
