---
-- Module ToolTip
-- Extends UIElement
--
-- @module ToolTip

---
-- Function ToolTip
--
-- @function [parent=#ToolTip] ToolTip

---
-- Function new
--
-- @function [parent=#ToolTip] new
-- @return ToolTip#ToolTip

---
-- Function delete
--
-- @function [parent=#ToolTip] delete

---
-- Function SetDelay
--
-- @function [parent=#ToolTip] SetDelay
-- @param #number delaydelay

---
-- Function GetDelay
--
-- @function [parent=#ToolTip] GetDelay
-- @return #number

---
-- Field delay
--
-- @field [parent=#ToolTip] #number delay


return nil
