---
-- Module ToolTip
-- Module ToolTip extends UIElement
-- Generated on 2014-05-31
--
-- @module ToolTip

---
-- Function ToolTip()
--
-- @function [parent=#ToolTip] ToolTip
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#ToolTip] new
-- @param self Self reference
-- @return ToolTip#ToolTip

---
-- Function delete()
--
-- @function [parent=#ToolTip] delete
-- @param self Self reference

---
-- Function SetDelay()
-- Set the delay in seconds until the tooltip shows once hovering. Set zero to use the default from the UI subsystem.
--
-- @function [parent=#ToolTip] SetDelay
-- @param self Self reference
-- @param #number delay delay

---
-- Function GetDelay()
-- Return the delay in seconds until the tooltip shows once hovering.
--
-- @function [parent=#ToolTip] GetDelay
-- @param self Self reference
-- @return #number

---
-- Field delay
--
-- @field [parent=#ToolTip] #number delay


return nil
