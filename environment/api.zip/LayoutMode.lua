---
-- Enumeration LayoutMode
--
-- @module LayoutMode

---
-- Enumeration value LM_FREE
--
-- @field [parent=#LayoutMode] #number LM_FREE

---
-- Enumeration value LM_HORIZONTAL
--
-- @field [parent=#LayoutMode] #number LM_HORIZONTAL

---
-- Enumeration value LM_VERTICAL
--
-- @field [parent=#LayoutMode] #number LM_VERTICAL


return nil
