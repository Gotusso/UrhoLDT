---
-- Module UI
-- Extends Object
--
-- @module UI

---
-- Function SetCursor
--
-- @function [parent=#UI] SetCursor
-- @param Cursor#Cursor cursorcursor

---
-- Function SetFocusElement
--
-- @function [parent=#UI] SetFocusElement
-- @param UIElement#UIElement elementelement
-- @param #boolean byKeybyKey

---
-- Function SetModalElement
--
-- @function [parent=#UI] SetModalElement
-- @param UIElement#UIElement modalElementmodalElement
-- @param #boolean enableenable
-- @return #boolean

---
-- Function Clear
--
-- @function [parent=#UI] Clear

---
-- Function Update
--
-- @function [parent=#UI] Update
-- @param #number timeSteptimeStep

---
-- Function RenderUpdate
--
-- @function [parent=#UI] RenderUpdate

---
-- Function Render
--
-- @function [parent=#UI] Render

---
-- Function DebugDraw
--
-- @function [parent=#UI] DebugDraw
-- @param UIElement#UIElement elementelement

---
-- Function SaveLayout
--
-- @function [parent=#UI] SaveLayout
-- @param Serializer#Serializer destdest
-- @param UIElement#UIElement elementelement
-- @return #boolean

---
-- Function SetClipBoardText
--
-- @function [parent=#UI] SetClipBoardText
-- @param #string texttext

---
-- Function SetDoubleClickInterval
--
-- @function [parent=#UI] SetDoubleClickInterval
-- @param #number intervalinterval

---
-- Function SetDragBeginInterval
--
-- @function [parent=#UI] SetDragBeginInterval
-- @param #number intervalinterval

---
-- Function SetDragBeginDistance
--
-- @function [parent=#UI] SetDragBeginDistance
-- @param #number pixelspixels

---
-- Function SetDefaultToolTipDelay
--
-- @function [parent=#UI] SetDefaultToolTipDelay
-- @param #number delaydelay

---
-- Function SetMaxFontTextureSize
--
-- @function [parent=#UI] SetMaxFontTextureSize
-- @param #number sizesize

---
-- Function SetNonFocusedMouseWheel
--
-- @function [parent=#UI] SetNonFocusedMouseWheel
-- @param #boolean nonFocusedMouseWheelnonFocusedMouseWheel

---
-- Function SetUseSystemClipBoard
--
-- @function [parent=#UI] SetUseSystemClipBoard
-- @param #boolean enableenable

---
-- Function SetUseScreenKeyboard
--
-- @function [parent=#UI] SetUseScreenKeyboard
-- @param #boolean enableenable

---
-- Function SetUseMutableGlyphs
--
-- @function [parent=#UI] SetUseMutableGlyphs
-- @param #boolean enableenable

---
-- Function SetForceAutoHint
--
-- @function [parent=#UI] SetForceAutoHint
-- @param #boolean enableenable

---
-- Function GetRoot
--
-- @function [parent=#UI] GetRoot
-- @return UIElement#UIElement

---
-- Function GetRootModalElement
--
-- @function [parent=#UI] GetRootModalElement
-- @return UIElement#UIElement

---
-- Function GetCursor
--
-- @function [parent=#UI] GetCursor
-- @return Cursor#Cursor

---
-- Function GetCursorPosition
--
-- @function [parent=#UI] GetCursorPosition
-- @return IntVector2#IntVector2

---
-- Function GetElementAt
--
-- @function [parent=#UI] GetElementAt
-- @param IntVector2#IntVector2 positionposition
-- @param #boolean enabledOnlyenabledOnly
-- @return UIElement#UIElement

---
-- Function GetElementAt
--
-- @function [parent=#UI] GetElementAt
-- @param #number xx
-- @param #number yy
-- @param #boolean enabledOnlyenabledOnly
-- @return UIElement#UIElement

---
-- Function GetFocusElement
--
-- @function [parent=#UI] GetFocusElement
-- @return UIElement#UIElement

---
-- Function GetFrontElement
--
-- @function [parent=#UI] GetFrontElement
-- @return UIElement#UIElement

---
-- Function GetDragElement
--
-- @function [parent=#UI] GetDragElement
-- @return UIElement#UIElement

---
-- Function GetClipBoardText
--
-- @function [parent=#UI] GetClipBoardText
-- @return const String#const String

---
-- Function GetDoubleClickInterval
--
-- @function [parent=#UI] GetDoubleClickInterval
-- @return #number

---
-- Function GetDragBeginInterval
--
-- @function [parent=#UI] GetDragBeginInterval
-- @return #number

---
-- Function GetDragBeginDistance
--
-- @function [parent=#UI] GetDragBeginDistance
-- @return #number

---
-- Function GetDefaultToolTipDelay
--
-- @function [parent=#UI] GetDefaultToolTipDelay
-- @return #number

---
-- Function GetMaxFontTextureSize
--
-- @function [parent=#UI] GetMaxFontTextureSize
-- @return #number

---
-- Function IsNonFocusedMouseWheel
--
-- @function [parent=#UI] IsNonFocusedMouseWheel
-- @return #boolean

---
-- Function GetUseSystemClipBoard
--
-- @function [parent=#UI] GetUseSystemClipBoard
-- @return #boolean

---
-- Function GetUseScreenKeyboard
--
-- @function [parent=#UI] GetUseScreenKeyboard
-- @return #boolean

---
-- Function GetUseMutableGlyphs
--
-- @function [parent=#UI] GetUseMutableGlyphs
-- @return #boolean

---
-- Function GetForceAutoHint
--
-- @function [parent=#UI] GetForceAutoHint
-- @return #boolean

---
-- Function HasModalElement
--
-- @function [parent=#UI] HasModalElement
-- @return #boolean

---
-- Field root (Read only)
--
-- @field [parent=#UI] UIElement#UIElement root

---
-- Field rootModalElement (Read only)
--
-- @field [parent=#UI] UIElement#UIElement rootModalElement

---
-- Field cursor
--
-- @field [parent=#UI] Cursor#Cursor cursor

---
-- Field cursorPosition (Read only)
--
-- @field [parent=#UI] IntVector2#IntVector2 cursorPosition

---
-- Field focusElement (Read only)
--
-- @field [parent=#UI] UIElement#UIElement focusElement

---
-- Field frontElement (Read only)
--
-- @field [parent=#UI] UIElement#UIElement frontElement

---
-- Field dragElement (Read only)
--
-- @field [parent=#UI] UIElement#UIElement dragElement

---
-- Field clipBoardText
--
-- @field [parent=#UI] #string clipBoardText

---
-- Field doubleClickInterval
--
-- @field [parent=#UI] #number doubleClickInterval

---
-- Field dragBeginInterval
--
-- @field [parent=#UI] #number dragBeginInterval

---
-- Field dragBeginDistance
--
-- @field [parent=#UI] #number dragBeginDistance

---
-- Field defaultToolTipDelay
--
-- @field [parent=#UI] #number defaultToolTipDelay

---
-- Field maxFontTextureSize
--
-- @field [parent=#UI] #number maxFontTextureSize

---
-- Field nonFocusedMouseWheel
--
-- @field [parent=#UI] #boolean nonFocusedMouseWheel

---
-- Field useSystemClipBoard
--
-- @field [parent=#UI] #boolean useSystemClipBoard

---
-- Field useScreenKeyboard
--
-- @field [parent=#UI] #boolean useScreenKeyboard

---
-- Field useMutableGlyphs
--
-- @field [parent=#UI] #boolean useMutableGlyphs

---
-- Field forceAutoHint
--
-- @field [parent=#UI] #boolean forceAutoHint

---
-- Field modalElement (Read only)
--
-- @field [parent=#UI] #boolean modalElement


return nil
