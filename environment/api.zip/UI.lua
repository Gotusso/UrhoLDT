---
-- Module UI
-- Module UI extends Object
-- Generated on 2014-05-31
--
-- @module UI

---
-- Function SetCursor()
-- Set cursor UI element.
--
-- @function [parent=#UI] SetCursor
-- @param self Self reference
-- @param Cursor#Cursor cursor cursor

---
-- Function SetFocusElement()
-- Set focused UI element.
--
-- @function [parent=#UI] SetFocusElement
-- @param self Self reference
-- @param UIElement#UIElement element element
-- @param #boolean byKey byKey

---
-- Function SetModalElement()
-- Only the modal element can clear its modal status or when it is being destructed.
--
-- @function [parent=#UI] SetModalElement
-- @param self Self reference
-- @param UIElement#UIElement modalElement modalElement
-- @param #boolean enable enable
-- @return #boolean

---
-- Function Clear()
-- Clear the UI (excluding the cursor.)
--
-- @function [parent=#UI] Clear
-- @param self Self reference

---
-- Function Update()
-- Update the UI logic. Called by HandlePostUpdate().
--
-- @function [parent=#UI] Update
-- @param self Self reference
-- @param #number timeStep timeStep

---
-- Function RenderUpdate()
-- Update the UI for rendering. Called by HandleRenderUpdate().
--
-- @function [parent=#UI] RenderUpdate
-- @param self Self reference

---
-- Function Render()
-- Render the UI.
--
-- @function [parent=#UI] Render
-- @param self Self reference

---
-- Function DebugDraw()
-- Debug draw a UI element.
--
-- @function [parent=#UI] DebugDraw
-- @param self Self reference
-- @param UIElement#UIElement element element

---
-- Function LoadLayout()
--
-- @function [parent=#UI] LoadLayout
-- @param self Self reference
-- @param File#File source source
-- @param XMLFile#XMLFile styleFile styleFile
-- @return UIElement#UIElement

---
-- Function LoadLayout()
--
-- @function [parent=#UI] LoadLayout
-- @param self Self reference
-- @param #string fileName fileName
-- @param XMLFile#XMLFile styleFile styleFile
-- @return UIElement#UIElement

---
-- Function LoadLayout()
-- Load a UI layout from an XML file. Optionally specify another XML file for element style. Return the root element.
--
-- @function [parent=#UI] LoadLayout
-- @param self Self reference
-- @param XMLFile#XMLFile file file
-- @param XMLFile#XMLFile styleFile styleFile
-- @return UIElement#UIElement

---
-- Function SaveLayout()
-- Save a UI layout to an XML file. Return true if successful.
--
-- @function [parent=#UI] SaveLayout
-- @param self Self reference
-- @param Serializer#Serializer dest dest
-- @param UIElement#UIElement element element
-- @return #boolean

---
-- Function SetClipboardText()
-- Set clipboard text.
--
-- @function [parent=#UI] SetClipboardText
-- @param self Self reference
-- @param #string text text

---
-- Function SetDoubleClickInterval()
-- Set UI element double click interval in seconds.
--
-- @function [parent=#UI] SetDoubleClickInterval
-- @param self Self reference
-- @param #number interval interval

---
-- Function SetDragBeginInterval()
-- Set UI drag event start interval in seconds.
--
-- @function [parent=#UI] SetDragBeginInterval
-- @param self Self reference
-- @param #number interval interval

---
-- Function SetDragBeginDistance()
-- Set UI drag event start distance threshold in pixels.
--
-- @function [parent=#UI] SetDragBeginDistance
-- @param self Self reference
-- @param #number pixels pixels

---
-- Function SetDefaultToolTipDelay()
-- Set tooltip default display delay in seconds.
--
-- @function [parent=#UI] SetDefaultToolTipDelay
-- @param self Self reference
-- @param #number delay delay

---
-- Function SetMaxFontTextureSize()
-- Set maximum font face texture size. Must be a power of two. Default is 2048.
--
-- @function [parent=#UI] SetMaxFontTextureSize
-- @param self Self reference
-- @param #number size size

---
-- Function SetNonFocusedMouseWheel()
-- Set whether mouse wheel can control also a non-focused element.
--
-- @function [parent=#UI] SetNonFocusedMouseWheel
-- @param self Self reference
-- @param #boolean nonFocusedMouseWheel nonFocusedMouseWheel

---
-- Function SetUseSystemClipboard()
-- Set whether to use system clipboard. Default false.
--
-- @function [parent=#UI] SetUseSystemClipboard
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetUseScreenKeyboard()
-- Set whether to show the on-screen keyboard (if supported) when a %LineEdit is focused. Default true on mobile devices.
--
-- @function [parent=#UI] SetUseScreenKeyboard
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetUseMutableGlyphs()
-- Set whether to use mutable (eraseable) glyphs to ensure a font face never expands to more than one texture. Default false.
--
-- @function [parent=#UI] SetUseMutableGlyphs
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetForceAutoHint()
-- Set whether to force font autohinting instead of using FreeType's TTF bytecode interpreter.
--
-- @function [parent=#UI] SetForceAutoHint
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function GetRoot()
-- Return root UI element.
--
-- @function [parent=#UI] GetRoot
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetRootModalElement()
-- Return root modal element.
--
-- @function [parent=#UI] GetRootModalElement
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetCursor()
-- Return cursor.
--
-- @function [parent=#UI] GetCursor
-- @param self Self reference
-- @return Cursor#Cursor

---
-- Function GetCursorPosition()
-- Return cursor position.
--
-- @function [parent=#UI] GetCursorPosition
-- @param self Self reference
-- @return IntVector2#IntVector2

---
-- Function GetElementAt()
-- Return UI element at screen coordinates. By default returns only input-enabled elements.
--
-- @function [parent=#UI] GetElementAt
-- @param self Self reference
-- @param IntVector2#IntVector2 position position
-- @param #boolean enabledOnly enabledOnly
-- @return UIElement#UIElement

---
-- Function GetElementAt()
-- Return UI element at screen coordinates. By default returns only input-enabled elements.
--
-- @function [parent=#UI] GetElementAt
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #boolean enabledOnly enabledOnly
-- @return UIElement#UIElement

---
-- Function GetFocusElement()
-- Return focused element.
--
-- @function [parent=#UI] GetFocusElement
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetFrontElement()
-- Return topmost enabled root-level non-modal element.
--
-- @function [parent=#UI] GetFrontElement
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetDragElement()
-- Return currently dragged element.
--
-- @function [parent=#UI] GetDragElement
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetClipboardText()
-- Return clipboard text.
--
-- @function [parent=#UI] GetClipboardText
-- @param self Self reference
-- @return const String#const String

---
-- Function GetDoubleClickInterval()
-- Return UI element double click interval in seconds.
--
-- @function [parent=#UI] GetDoubleClickInterval
-- @param self Self reference
-- @return #number

---
-- Function GetDragBeginInterval()
-- Return UI drag start event interval in seconds.
--
-- @function [parent=#UI] GetDragBeginInterval
-- @param self Self reference
-- @return #number

---
-- Function GetDragBeginDistance()
-- Return UI drag start event distance threshold in pixels.
--
-- @function [parent=#UI] GetDragBeginDistance
-- @param self Self reference
-- @return #number

---
-- Function GetDefaultToolTipDelay()
-- Return tooltip default display delay in seconds.
--
-- @function [parent=#UI] GetDefaultToolTipDelay
-- @param self Self reference
-- @return #number

---
-- Function GetMaxFontTextureSize()
-- Return font texture maximum size.
--
-- @function [parent=#UI] GetMaxFontTextureSize
-- @param self Self reference
-- @return #number

---
-- Function IsNonFocusedMouseWheel()
-- Return whether mouse wheel can control also a non-focused element.
--
-- @function [parent=#UI] IsNonFocusedMouseWheel
-- @param self Self reference
-- @return #boolean

---
-- Function GetUseSystemClipboard()
-- Return whether is using the system clipboard.
--
-- @function [parent=#UI] GetUseSystemClipboard
-- @param self Self reference
-- @return #boolean

---
-- Function GetUseScreenKeyboard()
-- Return whether focusing a %LineEdit will show the on-screen keyboard.
--
-- @function [parent=#UI] GetUseScreenKeyboard
-- @param self Self reference
-- @return #boolean

---
-- Function GetUseMutableGlyphs()
-- Return whether is using mutable (eraseable) glyphs for fonts.
--
-- @function [parent=#UI] GetUseMutableGlyphs
-- @param self Self reference
-- @return #boolean

---
-- Function GetForceAutoHint()
-- Return whether is using forced autohinting.
--
-- @function [parent=#UI] GetForceAutoHint
-- @param self Self reference
-- @return #boolean

---
-- Function HasModalElement()
-- Return true when UI has modal element(s).
--
-- @function [parent=#UI] HasModalElement
-- @param self Self reference
-- @return #boolean

---
-- Field root (Read only)
--
-- @field [parent=#UI] UIElement#UIElement root

---
-- Field rootModalElement (Read only)
--
-- @field [parent=#UI] UIElement#UIElement rootModalElement

---
-- Field cursor
--
-- @field [parent=#UI] Cursor#Cursor cursor

---
-- Field cursorPosition (Read only)
--
-- @field [parent=#UI] IntVector2#IntVector2 cursorPosition

---
-- Field focusElement (Read only)
--
-- @field [parent=#UI] UIElement#UIElement focusElement

---
-- Field frontElement (Read only)
--
-- @field [parent=#UI] UIElement#UIElement frontElement

---
-- Field dragElement (Read only)
--
-- @field [parent=#UI] UIElement#UIElement dragElement

---
-- Field clipboardText
--
-- @field [parent=#UI] #string clipboardText

---
-- Field doubleClickInterval
--
-- @field [parent=#UI] #number doubleClickInterval

---
-- Field dragBeginInterval
--
-- @field [parent=#UI] #number dragBeginInterval

---
-- Field dragBeginDistance
--
-- @field [parent=#UI] #number dragBeginDistance

---
-- Field defaultToolTipDelay
--
-- @field [parent=#UI] #number defaultToolTipDelay

---
-- Field maxFontTextureSize
--
-- @field [parent=#UI] #number maxFontTextureSize

---
-- Field nonFocusedMouseWheel
--
-- @field [parent=#UI] #boolean nonFocusedMouseWheel

---
-- Field useSystemClipboard
--
-- @field [parent=#UI] #boolean useSystemClipboard

---
-- Field useScreenKeyboard
--
-- @field [parent=#UI] #boolean useScreenKeyboard

---
-- Field useMutableGlyphs
--
-- @field [parent=#UI] #boolean useMutableGlyphs

---
-- Field forceAutoHint
--
-- @field [parent=#UI] #boolean forceAutoHint

---
-- Field modalElement (Read only)
--
-- @field [parent=#UI] #boolean modalElement


return nil
