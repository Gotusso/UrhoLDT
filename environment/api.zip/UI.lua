---
-- Module UI
-- Module UI extends Object
-- Generated on 2014-03-13
--
-- @module UI

---
-- Function SetCursor
--
-- @function [parent=#UI] SetCursor
-- @param self Self reference
-- @param Cursor#Cursor cursor cursor

---
-- Function SetFocusElement
--
-- @function [parent=#UI] SetFocusElement
-- @param self Self reference
-- @param UIElement#UIElement element element
-- @param #boolean byKey byKey

---
-- Function SetModalElement
--
-- @function [parent=#UI] SetModalElement
-- @param self Self reference
-- @param UIElement#UIElement modalElement modalElement
-- @param #boolean enable enable
-- @return #boolean

---
-- Function Clear
--
-- @function [parent=#UI] Clear
-- @param self Self reference

---
-- Function Update
--
-- @function [parent=#UI] Update
-- @param self Self reference
-- @param #number timeStep timeStep

---
-- Function RenderUpdate
--
-- @function [parent=#UI] RenderUpdate
-- @param self Self reference

---
-- Function Render
--
-- @function [parent=#UI] Render
-- @param self Self reference

---
-- Function DebugDraw
--
-- @function [parent=#UI] DebugDraw
-- @param self Self reference
-- @param UIElement#UIElement element element

---
-- Function SaveLayout
--
-- @function [parent=#UI] SaveLayout
-- @param self Self reference
-- @param Serializer#Serializer dest dest
-- @param UIElement#UIElement element element
-- @return #boolean

---
-- Function SetClipBoardText
--
-- @function [parent=#UI] SetClipBoardText
-- @param self Self reference
-- @param #string text text

---
-- Function SetDoubleClickInterval
--
-- @function [parent=#UI] SetDoubleClickInterval
-- @param self Self reference
-- @param #number interval interval

---
-- Function SetDragBeginInterval
--
-- @function [parent=#UI] SetDragBeginInterval
-- @param self Self reference
-- @param #number interval interval

---
-- Function SetDragBeginDistance
--
-- @function [parent=#UI] SetDragBeginDistance
-- @param self Self reference
-- @param #number pixels pixels

---
-- Function SetDefaultToolTipDelay
--
-- @function [parent=#UI] SetDefaultToolTipDelay
-- @param self Self reference
-- @param #number delay delay

---
-- Function SetMaxFontTextureSize
--
-- @function [parent=#UI] SetMaxFontTextureSize
-- @param self Self reference
-- @param #number size size

---
-- Function SetNonFocusedMouseWheel
--
-- @function [parent=#UI] SetNonFocusedMouseWheel
-- @param self Self reference
-- @param #boolean nonFocusedMouseWheel nonFocusedMouseWheel

---
-- Function SetUseSystemClipBoard
--
-- @function [parent=#UI] SetUseSystemClipBoard
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetUseScreenKeyboard
--
-- @function [parent=#UI] SetUseScreenKeyboard
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetUseMutableGlyphs
--
-- @function [parent=#UI] SetUseMutableGlyphs
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetForceAutoHint
--
-- @function [parent=#UI] SetForceAutoHint
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function GetRoot
--
-- @function [parent=#UI] GetRoot
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetRootModalElement
--
-- @function [parent=#UI] GetRootModalElement
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetCursor
--
-- @function [parent=#UI] GetCursor
-- @param self Self reference
-- @return Cursor#Cursor

---
-- Function GetCursorPosition
--
-- @function [parent=#UI] GetCursorPosition
-- @param self Self reference
-- @return IntVector2#IntVector2

---
-- Function GetElementAt
--
-- @function [parent=#UI] GetElementAt
-- @param self Self reference
-- @param IntVector2#IntVector2 position position
-- @param #boolean enabledOnly enabledOnly
-- @return UIElement#UIElement

---
-- Function GetElementAt
--
-- @function [parent=#UI] GetElementAt
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #boolean enabledOnly enabledOnly
-- @return UIElement#UIElement

---
-- Function GetFocusElement
--
-- @function [parent=#UI] GetFocusElement
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetFrontElement
--
-- @function [parent=#UI] GetFrontElement
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetDragElement
--
-- @function [parent=#UI] GetDragElement
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetClipBoardText
--
-- @function [parent=#UI] GetClipBoardText
-- @param self Self reference
-- @return const String#const String

---
-- Function GetDoubleClickInterval
--
-- @function [parent=#UI] GetDoubleClickInterval
-- @param self Self reference
-- @return #number

---
-- Function GetDragBeginInterval
--
-- @function [parent=#UI] GetDragBeginInterval
-- @param self Self reference
-- @return #number

---
-- Function GetDragBeginDistance
--
-- @function [parent=#UI] GetDragBeginDistance
-- @param self Self reference
-- @return #number

---
-- Function GetDefaultToolTipDelay
--
-- @function [parent=#UI] GetDefaultToolTipDelay
-- @param self Self reference
-- @return #number

---
-- Function GetMaxFontTextureSize
--
-- @function [parent=#UI] GetMaxFontTextureSize
-- @param self Self reference
-- @return #number

---
-- Function IsNonFocusedMouseWheel
--
-- @function [parent=#UI] IsNonFocusedMouseWheel
-- @param self Self reference
-- @return #boolean

---
-- Function GetUseSystemClipBoard
--
-- @function [parent=#UI] GetUseSystemClipBoard
-- @param self Self reference
-- @return #boolean

---
-- Function GetUseScreenKeyboard
--
-- @function [parent=#UI] GetUseScreenKeyboard
-- @param self Self reference
-- @return #boolean

---
-- Function GetUseMutableGlyphs
--
-- @function [parent=#UI] GetUseMutableGlyphs
-- @param self Self reference
-- @return #boolean

---
-- Function GetForceAutoHint
--
-- @function [parent=#UI] GetForceAutoHint
-- @param self Self reference
-- @return #boolean

---
-- Function HasModalElement
--
-- @function [parent=#UI] HasModalElement
-- @param self Self reference
-- @return #boolean

---
-- Field root (Read only)
--
-- @field [parent=#UI] UIElement#UIElement root

---
-- Field rootModalElement (Read only)
--
-- @field [parent=#UI] UIElement#UIElement rootModalElement

---
-- Field cursor
--
-- @field [parent=#UI] Cursor#Cursor cursor

---
-- Field cursorPosition (Read only)
--
-- @field [parent=#UI] IntVector2#IntVector2 cursorPosition

---
-- Field focusElement (Read only)
--
-- @field [parent=#UI] UIElement#UIElement focusElement

---
-- Field frontElement (Read only)
--
-- @field [parent=#UI] UIElement#UIElement frontElement

---
-- Field dragElement (Read only)
--
-- @field [parent=#UI] UIElement#UIElement dragElement

---
-- Field clipBoardText
--
-- @field [parent=#UI] #string clipBoardText

---
-- Field doubleClickInterval
--
-- @field [parent=#UI] #number doubleClickInterval

---
-- Field dragBeginInterval
--
-- @field [parent=#UI] #number dragBeginInterval

---
-- Field dragBeginDistance
--
-- @field [parent=#UI] #number dragBeginDistance

---
-- Field defaultToolTipDelay
--
-- @field [parent=#UI] #number defaultToolTipDelay

---
-- Field maxFontTextureSize
--
-- @field [parent=#UI] #number maxFontTextureSize

---
-- Field nonFocusedMouseWheel
--
-- @field [parent=#UI] #boolean nonFocusedMouseWheel

---
-- Field useSystemClipBoard
--
-- @field [parent=#UI] #boolean useSystemClipBoard

---
-- Field useScreenKeyboard
--
-- @field [parent=#UI] #boolean useScreenKeyboard

---
-- Field useMutableGlyphs
--
-- @field [parent=#UI] #boolean useMutableGlyphs

---
-- Field forceAutoHint
--
-- @field [parent=#UI] #boolean forceAutoHint

---
-- Field modalElement (Read only)
--
-- @field [parent=#UI] #boolean modalElement

---
-- Function GetType
--
-- @function [parent=#UI] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#UI] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#UI] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#UI] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#UI] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#UI] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#UI] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#UI] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#UI] #string category


return nil
