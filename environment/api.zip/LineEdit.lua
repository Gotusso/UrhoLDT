---
-- Module LineEdit
-- Module LineEdit extends BorderImage
-- Generated on 2014-05-31
--
-- @module LineEdit

---
-- Function LineEdit()
--
-- @function [parent=#LineEdit] LineEdit
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#LineEdit] new
-- @param self Self reference
-- @return LineEdit#LineEdit

---
-- Function delete()
--
-- @function [parent=#LineEdit] delete
-- @param self Self reference

---
-- Function SetText()
-- Set text.
--
-- @function [parent=#LineEdit] SetText
-- @param self Self reference
-- @param #string text text

---
-- Function SetCursorPosition()
-- Set cursor position.
--
-- @function [parent=#LineEdit] SetCursorPosition
-- @param self Self reference
-- @param #number position position

---
-- Function SetCursorBlinkRate()
-- Set cursor blink rate. 0 disables blinking.
--
-- @function [parent=#LineEdit] SetCursorBlinkRate
-- @param self Self reference
-- @param #number rate rate

---
-- Function SetMaxLength()
-- Set maximum text length. 0 for unlimited.
--
-- @function [parent=#LineEdit] SetMaxLength
-- @param self Self reference
-- @param #number length length

---
-- Function SetEchoCharacter()
-- Set echo character for password entry and such. 0 (default) shows the actual text.
--
-- @function [parent=#LineEdit] SetEchoCharacter
-- @param self Self reference
-- @param #number c c

---
-- Function SetCursorMovable()
-- Set whether can move cursor with arrows or mouse, default true.
--
-- @function [parent=#LineEdit] SetCursorMovable
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetTextSelectable()
-- Set whether selections are allowed, default true.
--
-- @function [parent=#LineEdit] SetTextSelectable
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetTextCopyable()
-- Set whether copy-paste operations are allowed, default true.
--
-- @function [parent=#LineEdit] SetTextCopyable
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function GetText()
-- Return text.
--
-- @function [parent=#LineEdit] GetText
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCursorPosition()
-- Return cursor position.
--
-- @function [parent=#LineEdit] GetCursorPosition
-- @param self Self reference
-- @return #number

---
-- Function GetCursorBlinkRate()
-- Return cursor blink rate.
--
-- @function [parent=#LineEdit] GetCursorBlinkRate
-- @param self Self reference
-- @return #number

---
-- Function GetMaxLength()
-- Return maximum text length.
--
-- @function [parent=#LineEdit] GetMaxLength
-- @param self Self reference
-- @return #number

---
-- Function GetEchoCharacter()
-- Return echo character.
--
-- @function [parent=#LineEdit] GetEchoCharacter
-- @param self Self reference
-- @return #number

---
-- Function IsCursorMovable()
-- Return whether can move cursor with arrows or mouse.
--
-- @function [parent=#LineEdit] IsCursorMovable
-- @param self Self reference
-- @return #boolean

---
-- Function IsTextSelectable()
-- Return whether selections are allowed.
--
-- @function [parent=#LineEdit] IsTextSelectable
-- @param self Self reference
-- @return #boolean

---
-- Function IsTextCopyable()
-- Return whether copy-paste operations are allowed.
--
-- @function [parent=#LineEdit] IsTextCopyable
-- @param self Self reference
-- @return #boolean

---
-- Function GetTextElement()
-- Return text element.
--
-- @function [parent=#LineEdit] GetTextElement
-- @param self Self reference
-- @return Text#Text

---
-- Function GetCursor()
-- Return cursor element.
--
-- @function [parent=#LineEdit] GetCursor
-- @param self Self reference
-- @return BorderImage#BorderImage

---
-- Field text
--
-- @field [parent=#LineEdit] #string text

---
-- Field cursorPosition
--
-- @field [parent=#LineEdit] #number cursorPosition

---
-- Field cursorBlinkRate
--
-- @field [parent=#LineEdit] #number cursorBlinkRate

---
-- Field maxLength
--
-- @field [parent=#LineEdit] #number maxLength

---
-- Field echoCharacter
--
-- @field [parent=#LineEdit] #number echoCharacter

---
-- Field cursorMovable
--
-- @field [parent=#LineEdit] #boolean cursorMovable

---
-- Field textSelectable
--
-- @field [parent=#LineEdit] #boolean textSelectable

---
-- Field textCopyable
--
-- @field [parent=#LineEdit] #boolean textCopyable

---
-- Field textElement (Read only)
--
-- @field [parent=#LineEdit] Text#Text textElement

---
-- Field cursor (Read only)
--
-- @field [parent=#LineEdit] BorderImage#BorderImage cursor


return nil
