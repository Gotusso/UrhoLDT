---
-- Module LineEdit
-- Extends BorderImage
--
-- @module LineEdit

---
-- Function LineEdit
--
-- @function [parent=#LineEdit] LineEdit

---
-- Function new
--
-- @function [parent=#LineEdit] new
-- @return LineEdit#LineEdit

---
-- Function delete
--
-- @function [parent=#LineEdit] delete

---
-- Function SetText
--
-- @function [parent=#LineEdit] SetText
-- @param #string texttext

---
-- Function SetCursorPosition
--
-- @function [parent=#LineEdit] SetCursorPosition
-- @param #number positionposition

---
-- Function SetCursorBlinkRate
--
-- @function [parent=#LineEdit] SetCursorBlinkRate
-- @param #number raterate

---
-- Function SetMaxLength
--
-- @function [parent=#LineEdit] SetMaxLength
-- @param #number lengthlength

---
-- Function SetEchoCharacter
--
-- @function [parent=#LineEdit] SetEchoCharacter
-- @param #number cc

---
-- Function SetCursorMovable
--
-- @function [parent=#LineEdit] SetCursorMovable
-- @param #boolean enableenable

---
-- Function SetTextSelectable
--
-- @function [parent=#LineEdit] SetTextSelectable
-- @param #boolean enableenable

---
-- Function SetTextCopyable
--
-- @function [parent=#LineEdit] SetTextCopyable
-- @param #boolean enableenable

---
-- Function GetText
--
-- @function [parent=#LineEdit] GetText
-- @return const String#const String

---
-- Function GetCursorPosition
--
-- @function [parent=#LineEdit] GetCursorPosition
-- @return #number

---
-- Function GetCursorBlinkRate
--
-- @function [parent=#LineEdit] GetCursorBlinkRate
-- @return #number

---
-- Function GetMaxLength
--
-- @function [parent=#LineEdit] GetMaxLength
-- @return #number

---
-- Function GetEchoCharacter
--
-- @function [parent=#LineEdit] GetEchoCharacter
-- @return #number

---
-- Function IsCursorMovable
--
-- @function [parent=#LineEdit] IsCursorMovable
-- @return #boolean

---
-- Function IsTextSelectable
--
-- @function [parent=#LineEdit] IsTextSelectable
-- @return #boolean

---
-- Function IsTextCopyable
--
-- @function [parent=#LineEdit] IsTextCopyable
-- @return #boolean

---
-- Function GetTextElement
--
-- @function [parent=#LineEdit] GetTextElement
-- @return Text#Text

---
-- Function GetCursor
--
-- @function [parent=#LineEdit] GetCursor
-- @return BorderImage#BorderImage

---
-- Field text
--
-- @field [parent=#LineEdit] #string text

---
-- Field cursorPosition
--
-- @field [parent=#LineEdit] #number cursorPosition

---
-- Field cursorBlinkRate
--
-- @field [parent=#LineEdit] #number cursorBlinkRate

---
-- Field maxLength
--
-- @field [parent=#LineEdit] #number maxLength

---
-- Field echoCharacter
--
-- @field [parent=#LineEdit] #number echoCharacter

---
-- Field cursorMovable
--
-- @field [parent=#LineEdit] #boolean cursorMovable

---
-- Field textSelectable
--
-- @field [parent=#LineEdit] #boolean textSelectable

---
-- Field textCopyable
--
-- @field [parent=#LineEdit] #boolean textCopyable

---
-- Field textElement (Read only)
--
-- @field [parent=#LineEdit] Text#Text textElement

---
-- Field cursor (Read only)
--
-- @field [parent=#LineEdit] BorderImage#BorderImage cursor


return nil
