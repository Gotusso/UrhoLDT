---
-- Module LineEdit
-- extends BorderImage
--
-- @module LineEdit

---
-- Function LineEdit
--
-- @function [parent=#LineEdit] LineEdit

---
-- Function new
--
-- @function [parent=#LineEdit] new
-- @return LineEdit#LineEdit

---
-- Function delete
--
-- @function [parent=#LineEdit] delete

---
-- Function SetText
--
-- @function [parent=#LineEdit] SetText
-- @param #string texttext

---
-- Function SetCursorPosition
--
-- @function [parent=#LineEdit] SetCursorPosition
-- @param #number positionposition

---
-- Function SetCursorBlinkRate
--
-- @function [parent=#LineEdit] SetCursorBlinkRate
-- @param #number raterate

---
-- Function SetMaxLength
--
-- @function [parent=#LineEdit] SetMaxLength
-- @param #number lengthlength

---
-- Function SetEchoCharacter
--
-- @function [parent=#LineEdit] SetEchoCharacter
-- @param #number cc

---
-- Function SetCursorMovable
--
-- @function [parent=#LineEdit] SetCursorMovable
-- @param #boolean enableenable

---
-- Function SetTextSelectable
--
-- @function [parent=#LineEdit] SetTextSelectable
-- @param #boolean enableenable

---
-- Function SetTextCopyable
--
-- @function [parent=#LineEdit] SetTextCopyable
-- @param #boolean enableenable

---
-- Function GetText
--
-- @function [parent=#LineEdit] GetText
-- @return const String#const String

---
-- Function GetCursorPosition
--
-- @function [parent=#LineEdit] GetCursorPosition
-- @return #number

---
-- Function GetCursorBlinkRate
--
-- @function [parent=#LineEdit] GetCursorBlinkRate
-- @return #number

---
-- Function GetMaxLength
--
-- @function [parent=#LineEdit] GetMaxLength
-- @return #number

---
-- Function GetEchoCharacter
--
-- @function [parent=#LineEdit] GetEchoCharacter
-- @return #number

---
-- Function IsCursorMovable
--
-- @function [parent=#LineEdit] IsCursorMovable
-- @return #boolean

---
-- Function IsTextSelectable
--
-- @function [parent=#LineEdit] IsTextSelectable
-- @return #boolean

---
-- Function IsTextCopyable
--
-- @function [parent=#LineEdit] IsTextCopyable
-- @return #boolean

---
-- Function GetTextElement
--
-- @function [parent=#LineEdit] GetTextElement
-- @return Text#Text

---
-- Function GetCursor
--
-- @function [parent=#LineEdit] GetCursor
-- @return BorderImage#BorderImage

---
-- Field text
--
-- @field [parent=#LineEdit] #string text

---
-- Field cursorPosition
--
-- @field [parent=#LineEdit] #number cursorPosition

---
-- Field cursorBlinkRate
--
-- @field [parent=#LineEdit] #number cursorBlinkRate

---
-- Field maxLength
--
-- @field [parent=#LineEdit] #number maxLength

---
-- Field echoCharacter
--
-- @field [parent=#LineEdit] #number echoCharacter

---
-- Field cursorMovable
--
-- @field [parent=#LineEdit] #boolean cursorMovable

---
-- Field textSelectable
--
-- @field [parent=#LineEdit] #boolean textSelectable

---
-- Field textCopyable
--
-- @field [parent=#LineEdit] #boolean textCopyable

---
-- Field textElement (Read only)
--
-- @field [parent=#LineEdit] Text#Text textElement

---
-- Field cursor (Read only)
--
-- @field [parent=#LineEdit] BorderImage#BorderImage cursor

---
-- Function BorderImage
--
-- @function [parent=#LineEdit] BorderImage

---
-- Function new
--
-- @function [parent=#LineEdit] new
-- @return BorderImage#BorderImage

---
-- Function delete
--
-- @function [parent=#LineEdit] delete

---
-- Function SetTexture
--
-- @function [parent=#LineEdit] SetTexture
-- @param Texture#Texture texturetexture

---
-- Function SetImageRect
--
-- @function [parent=#LineEdit] SetImageRect
-- @param IntRect#IntRect rectrect

---
-- Function SetFullImageRect
--
-- @function [parent=#LineEdit] SetFullImageRect

---
-- Function SetBorder
--
-- @function [parent=#LineEdit] SetBorder
-- @param IntRect#IntRect rectrect

---
-- Function SetHoverOffset
--
-- @function [parent=#LineEdit] SetHoverOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetHoverOffset
--
-- @function [parent=#LineEdit] SetHoverOffset
-- @param #number xx
-- @param #number yy

---
-- Function SetBlendMode
--
-- @function [parent=#LineEdit] SetBlendMode
-- @param BlendMode#BlendMode modemode

---
-- Function SetTiled
--
-- @function [parent=#LineEdit] SetTiled
-- @param #boolean enableenable

---
-- Function GetTexture
--
-- @function [parent=#LineEdit] GetTexture
-- @return Texture#Texture

---
-- Function GetImageRect
--
-- @function [parent=#LineEdit] GetImageRect
-- @return const IntRect#const IntRect

---
-- Function GetBorder
--
-- @function [parent=#LineEdit] GetBorder
-- @return const IntRect#const IntRect

---
-- Function GetHoverOffset
--
-- @function [parent=#LineEdit] GetHoverOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetBlendMode
--
-- @function [parent=#LineEdit] GetBlendMode
-- @return BlendMode#BlendMode

---
-- Function IsTiled
--
-- @function [parent=#LineEdit] IsTiled
-- @return #boolean

---
-- Field texture
--
-- @field [parent=#LineEdit] Texture#Texture texture

---
-- Field imageRect
--
-- @field [parent=#LineEdit] IntRect#IntRect imageRect

---
-- Field border
--
-- @field [parent=#LineEdit] IntRect#IntRect border

---
-- Field hoverOffset
--
-- @field [parent=#LineEdit] IntVector2#IntVector2 hoverOffset

---
-- Field blendMode
--
-- @field [parent=#LineEdit] BlendMode#BlendMode blendMode

---
-- Field tiled
--
-- @field [parent=#LineEdit] #boolean tiled

---
-- Function UIElement
--
-- @function [parent=#LineEdit] UIElement

---
-- Function new
--
-- @function [parent=#LineEdit] new
-- @return UIElement#UIElement

---
-- Function delete
--
-- @function [parent=#LineEdit] delete

---
-- Function GetScreenPosition
--
-- @function [parent=#LineEdit] GetScreenPosition
-- @return const IntVector2#const IntVector2

---
-- Function LoadXML
--
-- @function [parent=#LineEdit] LoadXML
-- @param Deserializer#Deserializer sourcesource
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#LineEdit] SaveXML
-- @param Serializer#Serializer destdest
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#LineEdit] LoadXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#LineEdit] SaveXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function FilterAttributes
--
-- @function [parent=#LineEdit] FilterAttributes
-- @param XMLElement#XMLElement destdest
-- @return #boolean

---
-- Function SetName
--
-- @function [parent=#LineEdit] SetName
-- @param #string namename

---
-- Function SetPosition
--
-- @function [parent=#LineEdit] SetPosition
-- @param IntVector2#IntVector2 positionposition

---
-- Function SetPosition
--
-- @function [parent=#LineEdit] SetPosition
-- @param #number xx
-- @param #number yy

---
-- Function SetSize
--
-- @function [parent=#LineEdit] SetSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function SetSize
--
-- @function [parent=#LineEdit] SetSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetWidth
--
-- @function [parent=#LineEdit] SetWidth
-- @param #number widthwidth

---
-- Function SetHeight
--
-- @function [parent=#LineEdit] SetHeight
-- @param #number heightheight

---
-- Function SetMinSize
--
-- @function [parent=#LineEdit] SetMinSize
-- @param IntVector2#IntVector2 minSizeminSize

---
-- Function SetMinSize
--
-- @function [parent=#LineEdit] SetMinSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetMinWidth
--
-- @function [parent=#LineEdit] SetMinWidth
-- @param #number widthwidth

---
-- Function SetMinHeight
--
-- @function [parent=#LineEdit] SetMinHeight
-- @param #number heightheight

---
-- Function SetMaxSize
--
-- @function [parent=#LineEdit] SetMaxSize
-- @param IntVector2#IntVector2 maxSizemaxSize

---
-- Function SetMaxSize
--
-- @function [parent=#LineEdit] SetMaxSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetMaxWidth
--
-- @function [parent=#LineEdit] SetMaxWidth
-- @param #number widthwidth

---
-- Function SetMaxHeight
--
-- @function [parent=#LineEdit] SetMaxHeight
-- @param #number heightheight

---
-- Function SetFixedSize
--
-- @function [parent=#LineEdit] SetFixedSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function SetFixedSize
--
-- @function [parent=#LineEdit] SetFixedSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetFixedWidth
--
-- @function [parent=#LineEdit] SetFixedWidth
-- @param #number widthwidth

---
-- Function SetFixedHeight
--
-- @function [parent=#LineEdit] SetFixedHeight
-- @param #number heightheight

---
-- Function SetAlignment
--
-- @function [parent=#LineEdit] SetAlignment
-- @param HorizontalAlignment#HorizontalAlignment hAlignhAlign
-- @param VerticalAlignment#VerticalAlignment vAlignvAlign

---
-- Function SetHorizontalAlignment
--
-- @function [parent=#LineEdit] SetHorizontalAlignment
-- @param HorizontalAlignment#HorizontalAlignment alignalign

---
-- Function SetVerticalAlignment
--
-- @function [parent=#LineEdit] SetVerticalAlignment
-- @param VerticalAlignment#VerticalAlignment alignalign

---
-- Function SetClipBorder
--
-- @function [parent=#LineEdit] SetClipBorder
-- @param IntRect#IntRect rectrect

---
-- Function SetColor
--
-- @function [parent=#LineEdit] SetColor
-- @param Color#Color colorcolor

---
-- Function SetColor
--
-- @function [parent=#LineEdit] SetColor
-- @param Corner#Corner cornercorner
-- @param Color#Color colorcolor

---
-- Function SetPriority
--
-- @function [parent=#LineEdit] SetPriority
-- @param #number prioritypriority

---
-- Function SetOpacity
--
-- @function [parent=#LineEdit] SetOpacity
-- @param #number opacityopacity

---
-- Function SetBringToFront
--
-- @function [parent=#LineEdit] SetBringToFront
-- @param #boolean enableenable

---
-- Function SetBringToBack
--
-- @function [parent=#LineEdit] SetBringToBack
-- @param #boolean enableenable

---
-- Function SetClipChildren
--
-- @function [parent=#LineEdit] SetClipChildren
-- @param #boolean enableenable

---
-- Function SetSortChildren
--
-- @function [parent=#LineEdit] SetSortChildren
-- @param #boolean enableenable

---
-- Function SetUseDerivedOpacity
--
-- @function [parent=#LineEdit] SetUseDerivedOpacity
-- @param #boolean enableenable

---
-- Function SetEnabled
--
-- @function [parent=#LineEdit] SetEnabled
-- @param #boolean enableenable

---
-- Function SetEditable
--
-- @function [parent=#LineEdit] SetEditable
-- @param #boolean enableenable

---
-- Function SetFocus
--
-- @function [parent=#LineEdit] SetFocus
-- @param #boolean enableenable

---
-- Function SetSelected
--
-- @function [parent=#LineEdit] SetSelected
-- @param #boolean enableenable

---
-- Function SetVisible
--
-- @function [parent=#LineEdit] SetVisible
-- @param #boolean enableenable

---
-- Function SetFocusMode
--
-- @function [parent=#LineEdit] SetFocusMode
-- @param FocusMode#FocusMode modemode

---
-- Function SetDragDropMode
--
-- @function [parent=#LineEdit] SetDragDropMode
-- @param #number modemode

---
-- Function SetStyle
--
-- @function [parent=#LineEdit] SetStyle
-- @param #string styleNamestyleName
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetStyle
--
-- @function [parent=#LineEdit] SetStyle
-- @param XMLElement#XMLElement elementelement
-- @return #boolean

---
-- Function SetStyleAuto
--
-- @function [parent=#LineEdit] SetStyleAuto
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetDefaultStyle
--
-- @function [parent=#LineEdit] SetDefaultStyle
-- @param XMLFile#XMLFile stylestyle

---
-- Function SetLayout
--
-- @function [parent=#LineEdit] SetLayout
-- @param LayoutMode#LayoutMode modemode
-- @param #number spacingspacing

---
-- Function SetLayout
--
-- @function [parent=#LineEdit] SetLayout
-- @param LayoutMode#LayoutMode modemode
-- @param #number spacingspacing
-- @param IntRect#IntRect borderborder

---
-- Function SetLayoutMode
--
-- @function [parent=#LineEdit] SetLayoutMode
-- @param LayoutMode#LayoutMode modemode

---
-- Function SetLayoutSpacing
--
-- @function [parent=#LineEdit] SetLayoutSpacing
-- @param #number spacingspacing

---
-- Function SetLayoutBorder
--
-- @function [parent=#LineEdit] SetLayoutBorder
-- @param IntRect#IntRect borderborder

---
-- Function SetIndent
--
-- @function [parent=#LineEdit] SetIndent
-- @param #number indentindent

---
-- Function SetIndentSpacing
--
-- @function [parent=#LineEdit] SetIndentSpacing
-- @param #number indentSpacingindentSpacing

---
-- Function UpdateLayout
--
-- @function [parent=#LineEdit] UpdateLayout

---
-- Function DisableLayoutUpdate
--
-- @function [parent=#LineEdit] DisableLayoutUpdate

---
-- Function EnableLayoutUpdate
--
-- @function [parent=#LineEdit] EnableLayoutUpdate

---
-- Function BringToFront
--
-- @function [parent=#LineEdit] BringToFront

---
-- Function CreateChild
--
-- @function [parent=#LineEdit] CreateChild
-- @param #string typetype
-- @param #string namename
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function AddChild
--
-- @function [parent=#LineEdit] AddChild
-- @param UIElement#UIElement elementelement

---
-- Function InsertChild
--
-- @function [parent=#LineEdit] InsertChild
-- @param #number indexindex
-- @param UIElement#UIElement elementelement

---
-- Function RemoveChild
--
-- @function [parent=#LineEdit] RemoveChild
-- @param UIElement#UIElement elementelement
-- @param #number indexindex

---
-- Function RemoveChildAtIndex
--
-- @function [parent=#LineEdit] RemoveChildAtIndex
-- @param #number indexindex

---
-- Function RemoveAllChildren
--
-- @function [parent=#LineEdit] RemoveAllChildren

---
-- Function Remove
--
-- @function [parent=#LineEdit] Remove

---
-- Function FindChild
--
-- @function [parent=#LineEdit] FindChild
-- @param UIElement#UIElement elementelement
-- @return #number

---
-- Function SetParent
--
-- @function [parent=#LineEdit] SetParent
-- @param UIElement#UIElement parentparent
-- @param #number indexindex

---
-- Function SetVar
--
-- @function [parent=#LineEdit] SetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @param Variant#Variant valuevalue

---
-- Function SetInternal
--
-- @function [parent=#LineEdit] SetInternal
-- @param #boolean enableenable

---
-- Function SetTraversalMode
--
-- @function [parent=#LineEdit] SetTraversalMode
-- @param TraversalMode#TraversalMode traversalModetraversalMode

---
-- Function SetElementEventSender
--
-- @function [parent=#LineEdit] SetElementEventSender
-- @param #boolean flagflag

---
-- Function GetName
--
-- @function [parent=#LineEdit] GetName
-- @return const String#const String

---
-- Function GetPosition
--
-- @function [parent=#LineEdit] GetPosition
-- @return const IntVector2#const IntVector2

---
-- Function GetSize
--
-- @function [parent=#LineEdit] GetSize
-- @return const IntVector2#const IntVector2

---
-- Function GetWidth
--
-- @function [parent=#LineEdit] GetWidth
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#LineEdit] GetHeight
-- @return #number

---
-- Function GetMinSize
--
-- @function [parent=#LineEdit] GetMinSize
-- @return const IntVector2#const IntVector2

---
-- Function GetMinWidth
--
-- @function [parent=#LineEdit] GetMinWidth
-- @return #number

---
-- Function GetMinHeight
--
-- @function [parent=#LineEdit] GetMinHeight
-- @return #number

---
-- Function GetMaxSize
--
-- @function [parent=#LineEdit] GetMaxSize
-- @return const IntVector2#const IntVector2

---
-- Function GetMaxWidth
--
-- @function [parent=#LineEdit] GetMaxWidth
-- @return #number

---
-- Function GetMaxHeight
--
-- @function [parent=#LineEdit] GetMaxHeight
-- @return #number

---
-- Function IsFixedSize
--
-- @function [parent=#LineEdit] IsFixedSize
-- @return #boolean

---
-- Function IsFixedWidth
--
-- @function [parent=#LineEdit] IsFixedWidth
-- @return #boolean

---
-- Function IsFixedHeight
--
-- @function [parent=#LineEdit] IsFixedHeight
-- @return #boolean

---
-- Function GetChildOffset
--
-- @function [parent=#LineEdit] GetChildOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetHorizontalAlignment
--
-- @function [parent=#LineEdit] GetHorizontalAlignment
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetVerticalAlignment
--
-- @function [parent=#LineEdit] GetVerticalAlignment
-- @return VerticalAlignment#VerticalAlignment

---
-- Function GetClipBorder
--
-- @function [parent=#LineEdit] GetClipBorder
-- @return const IntRect#const IntRect

---
-- Function GetColor
--
-- @function [parent=#LineEdit] GetColor
-- @param Corner#Corner cornercorner
-- @return const Color#const Color

---
-- Function GetPriority
--
-- @function [parent=#LineEdit] GetPriority
-- @return #number

---
-- Function GetOpacity
--
-- @function [parent=#LineEdit] GetOpacity
-- @return #number

---
-- Function GetDerivedOpacity
--
-- @function [parent=#LineEdit] GetDerivedOpacity
-- @return #number

---
-- Function GetBringToFront
--
-- @function [parent=#LineEdit] GetBringToFront
-- @return #boolean

---
-- Function GetBringToBack
--
-- @function [parent=#LineEdit] GetBringToBack
-- @return #boolean

---
-- Function GetClipChildren
--
-- @function [parent=#LineEdit] GetClipChildren
-- @return #boolean

---
-- Function GetSortChildren
--
-- @function [parent=#LineEdit] GetSortChildren
-- @return #boolean

---
-- Function GetUseDerivedOpacity
--
-- @function [parent=#LineEdit] GetUseDerivedOpacity
-- @return #boolean

---
-- Function HasFocus
--
-- @function [parent=#LineEdit] HasFocus
-- @return #boolean

---
-- Function IsEnabled
--
-- @function [parent=#LineEdit] IsEnabled
-- @return #boolean

---
-- Function IsEditable
--
-- @function [parent=#LineEdit] IsEditable
-- @return #boolean

---
-- Function IsSelected
--
-- @function [parent=#LineEdit] IsSelected
-- @return #boolean

---
-- Function IsVisible
--
-- @function [parent=#LineEdit] IsVisible
-- @return #boolean

---
-- Function IsHovering
--
-- @function [parent=#LineEdit] IsHovering
-- @return #boolean

---
-- Function IsInternal
--
-- @function [parent=#LineEdit] IsInternal
-- @return #boolean

---
-- Function HasColorGradient
--
-- @function [parent=#LineEdit] HasColorGradient
-- @return #boolean

---
-- Function GetFocusMode
--
-- @function [parent=#LineEdit] GetFocusMode
-- @return FocusMode#FocusMode

---
-- Function GetDragDropMode
--
-- @function [parent=#LineEdit] GetDragDropMode
-- @return #number

---
-- Function GetAppliedStyle
--
-- @function [parent=#LineEdit] GetAppliedStyle
-- @return const String#const String

---
-- Function GetDefaultStyle
--
-- @function [parent=#LineEdit] GetDefaultStyle
-- @param #boolean recursiveUprecursiveUp
-- @return XMLFile#XMLFile

---
-- Function GetLayoutMode
--
-- @function [parent=#LineEdit] GetLayoutMode
-- @return LayoutMode#LayoutMode

---
-- Function GetLayoutSpacing
--
-- @function [parent=#LineEdit] GetLayoutSpacing
-- @return #number

---
-- Function GetLayoutBorder
--
-- @function [parent=#LineEdit] GetLayoutBorder
-- @return const IntRect#const IntRect

---
-- Function GetNumChildren
--
-- @function [parent=#LineEdit] GetNumChildren
-- @param #boolean recursiverecursive
-- @return #number

---
-- Function GetChild
--
-- @function [parent=#LineEdit] GetChild
-- @param #string namename
-- @param #boolean recursiverecursive
-- @return UIElement#UIElement

---
-- Function GetChild
--
-- @function [parent=#LineEdit] GetChild
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function GetParent
--
-- @function [parent=#LineEdit] GetParent
-- @return UIElement#UIElement

---
-- Function GetRoot
--
-- @function [parent=#LineEdit] GetRoot
-- @return UIElement#UIElement

---
-- Function GetDerivedColor
--
-- @function [parent=#LineEdit] GetDerivedColor
-- @return const Color#const Color

---
-- Function GetVar
--
-- @function [parent=#LineEdit] GetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @return const Variant#const Variant

---
-- Function GetVars
--
-- @function [parent=#LineEdit] GetVars
-- @return const VariantMap#const VariantMap

---
-- Function ScreenToElement
--
-- @function [parent=#LineEdit] ScreenToElement
-- @param IntVector2#IntVector2 screenPositionscreenPosition
-- @return IntVector2#IntVector2

---
-- Function ElementToScreen
--
-- @function [parent=#LineEdit] ElementToScreen
-- @param IntVector2#IntVector2 positionposition
-- @return IntVector2#IntVector2

---
-- Function IsInside
--
-- @function [parent=#LineEdit] IsInside
-- @param IntVector2#IntVector2 positionposition
-- @param #boolean isScreenisScreen
-- @return #boolean

---
-- Function IsInsideCombined
--
-- @function [parent=#LineEdit] IsInsideCombined
-- @param IntVector2#IntVector2 positionposition
-- @param #boolean isScreenisScreen
-- @return #boolean

---
-- Function GetCombinedScreenRect
--
-- @function [parent=#LineEdit] GetCombinedScreenRect
-- @return IntRect#IntRect

---
-- Function SortChildren
--
-- @function [parent=#LineEdit] SortChildren

---
-- Function GetLayoutMinSize
--
-- @function [parent=#LineEdit] GetLayoutMinSize
-- @return #number

---
-- Function GetIndent
--
-- @function [parent=#LineEdit] GetIndent
-- @return #number

---
-- Function GetIndentSpacing
--
-- @function [parent=#LineEdit] GetIndentSpacing
-- @return #number

---
-- Function GetIndentWidth
--
-- @function [parent=#LineEdit] GetIndentWidth
-- @return #number

---
-- Function SetChildOffset
--
-- @function [parent=#LineEdit] SetChildOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetHovering
--
-- @function [parent=#LineEdit] SetHovering
-- @param #boolean enableenable

---
-- Function GetColor
--
-- @function [parent=#LineEdit] GetColor
-- @return const Color#const Color

---
-- Function GetTraversalMode
--
-- @function [parent=#LineEdit] GetTraversalMode
-- @return TraversalMode#TraversalMode

---
-- Function IsElementEventSender
--
-- @function [parent=#LineEdit] IsElementEventSender
-- @return #boolean

---
-- Function GetElementEventSender
--
-- @function [parent=#LineEdit] GetElementEventSender
-- @return UIElement#UIElement

---
-- Field screenPosition (Read only)
--
-- @field [parent=#LineEdit] IntVector2#IntVector2 screenPosition

---
-- Field name
--
-- @field [parent=#LineEdit] #string name

---
-- Field position
--
-- @field [parent=#LineEdit] IntVector2#IntVector2 position

---
-- Field size
--
-- @field [parent=#LineEdit] IntVector2#IntVector2 size

---
-- Field width
--
-- @field [parent=#LineEdit] #number width

---
-- Field height
--
-- @field [parent=#LineEdit] #number height

---
-- Field minSize
--
-- @field [parent=#LineEdit] IntVector2#IntVector2 minSize

---
-- Field minWidth
--
-- @field [parent=#LineEdit] #number minWidth

---
-- Field minHeight
--
-- @field [parent=#LineEdit] #number minHeight

---
-- Field maxSize
--
-- @field [parent=#LineEdit] IntVector2#IntVector2 maxSize

---
-- Field maxWidth
--
-- @field [parent=#LineEdit] #number maxWidth

---
-- Field maxHeight
--
-- @field [parent=#LineEdit] #number maxHeight

---
-- Field fixedSize (Read only)
--
-- @field [parent=#LineEdit] #boolean fixedSize

---
-- Field fixedWidth (Read only)
--
-- @field [parent=#LineEdit] #boolean fixedWidth

---
-- Field fixedHeight (Read only)
--
-- @field [parent=#LineEdit] #boolean fixedHeight

---
-- Field childOffset
--
-- @field [parent=#LineEdit] IntVector2#IntVector2 childOffset

---
-- Field horizontalAlignment
--
-- @field [parent=#LineEdit] HorizontalAlignment#HorizontalAlignment horizontalAlignment

---
-- Field verticalAlignment
--
-- @field [parent=#LineEdit] VerticalAlignment#VerticalAlignment verticalAlignment

---
-- Field clipBorder
--
-- @field [parent=#LineEdit] IntRect#IntRect clipBorder

---
-- Field color
--
-- @field [parent=#LineEdit] Color#Color color

---
-- Field priority
--
-- @field [parent=#LineEdit] #number priority

---
-- Field opacity
--
-- @field [parent=#LineEdit] #number opacity

---
-- Field derivedOpacity (Read only)
--
-- @field [parent=#LineEdit] #number derivedOpacity

---
-- Field bringToFront
--
-- @field [parent=#LineEdit] #boolean bringToFront

---
-- Field bringToBack
--
-- @field [parent=#LineEdit] #boolean bringToBack

---
-- Field clipChildren
--
-- @field [parent=#LineEdit] #boolean clipChildren

---
-- Field sortChildren
--
-- @field [parent=#LineEdit] #boolean sortChildren

---
-- Field useDerivedOpacity
--
-- @field [parent=#LineEdit] #boolean useDerivedOpacity

---
-- Field focus
--
-- @field [parent=#LineEdit] #boolean focus

---
-- Field enabled
--
-- @field [parent=#LineEdit] #boolean enabled

---
-- Field editable
--
-- @field [parent=#LineEdit] #boolean editable

---
-- Field selected
--
-- @field [parent=#LineEdit] #boolean selected

---
-- Field visible
--
-- @field [parent=#LineEdit] #boolean visible

---
-- Field hovering
--
-- @field [parent=#LineEdit] #boolean hovering

---
-- Field internal
--
-- @field [parent=#LineEdit] #boolean internal

---
-- Field colorGradient (Read only)
--
-- @field [parent=#LineEdit] #boolean colorGradient

---
-- Field focusMode
--
-- @field [parent=#LineEdit] FocusMode#FocusMode focusMode

---
-- Field dragDropMode
--
-- @field [parent=#LineEdit] #number dragDropMode

---
-- Field style
--
-- @field [parent=#LineEdit] #string style

---
-- Field defaultStyle
--
-- @field [parent=#LineEdit] XMLFile#XMLFile defaultStyle

---
-- Field layoutMode
--
-- @field [parent=#LineEdit] LayoutMode#LayoutMode layoutMode

---
-- Field layoutSpacing
--
-- @field [parent=#LineEdit] #number layoutSpacing

---
-- Field layoutBorder
--
-- @field [parent=#LineEdit] IntRect#IntRect layoutBorder

---
-- Field numChildren (Read only)
--
-- @field [parent=#LineEdit] #number numChildren

---
-- Field parent
--
-- @field [parent=#LineEdit] UIElement#UIElement parent

---
-- Field root (Read only)
--
-- @field [parent=#LineEdit] UIElement#UIElement root

---
-- Field derivedColor (Read only)
--
-- @field [parent=#LineEdit] Color#Color derivedColor

---
-- Field combinedScreenRect (Read only)
--
-- @field [parent=#LineEdit] IntRect#IntRect combinedScreenRect

---
-- Field layoutMinSize (Read only)
--
-- @field [parent=#LineEdit] #number layoutMinSize

---
-- Field indent
--
-- @field [parent=#LineEdit] #number indent

---
-- Field indentSpacing
--
-- @field [parent=#LineEdit] #number indentSpacing

---
-- Field indentWidth (Read only)
--
-- @field [parent=#LineEdit] #number indentWidth

---
-- Field traversalMode
--
-- @field [parent=#LineEdit] TraversalMode#TraversalMode traversalMode

---
-- Field elementEventSender
--
-- @field [parent=#LineEdit] #boolean elementEventSender

---
-- Function SetTemporary
--
-- @function [parent=#LineEdit] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#LineEdit] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#LineEdit] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#LineEdit] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#LineEdit] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#LineEdit] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#LineEdit] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#LineEdit] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#LineEdit] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#LineEdit] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#LineEdit] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#LineEdit] #string category


return nil
