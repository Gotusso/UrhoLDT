---
-- Module IntRect
--
-- @module IntRect

---
-- Function IntRect
--
-- @function [parent=#IntRect] IntRect

---
-- Function new
--
-- @function [parent=#IntRect] new
-- @return IntRect#IntRect

---
-- Function IntRect
--
-- @function [parent=#IntRect] IntRect
-- @param #number leftleft
-- @param #number toptop
-- @param #number rightright
-- @param #number bottombottom

---
-- Function new
--
-- @function [parent=#IntRect] new
-- @param #number leftleft
-- @param #number toptop
-- @param #number rightright
-- @param #number bottombottom
-- @return IntRect#IntRect

---
-- Function delete
--
-- @function [parent=#IntRect] delete

---
-- Function operator==
--
-- @function [parent=#IntRect] operator==
-- @param IntRect#IntRect rhsrhs
-- @return #boolean

---
-- Function Size
--
-- @function [parent=#IntRect] Size
-- @return IntVector2#IntVector2

---
-- Function Width
--
-- @function [parent=#IntRect] Width
-- @return #number

---
-- Function Height
--
-- @function [parent=#IntRect] Height
-- @return #number

---
-- Function IsInside
--
-- @function [parent=#IntRect] IsInside
-- @param IntVector2#IntVector2 pointpoint
-- @return Intersection#Intersection

---
-- Field left
--
-- @field [parent=#IntRect] #number left

---
-- Field top
--
-- @field [parent=#IntRect] #number top

---
-- Field right
--
-- @field [parent=#IntRect] #number right

---
-- Field bottom
--
-- @field [parent=#IntRect] #number bottom

---
-- Field ZERO
--
-- @field [parent=#IntRect] IntRect#IntRect ZERO

---
-- Field size (Read only)
--
-- @field [parent=#IntRect] IntVector2#IntVector2 size

---
-- Field width (Read only)
--
-- @field [parent=#IntRect] #number width

---
-- Field height (Read only)
--
-- @field [parent=#IntRect] #number height


return nil
