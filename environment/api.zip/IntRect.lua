---
-- Module IntRect
-- Generated on 2014-03-13
--
-- @module IntRect

---
-- Function IntRect
--
-- @function [parent=#IntRect] IntRect
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#IntRect] new
-- @param self Self reference
-- @return IntRect#IntRect

---
-- Function IntRect
--
-- @function [parent=#IntRect] IntRect
-- @param self Self reference
-- @param #number left left
-- @param #number top top
-- @param #number right right
-- @param #number bottom bottom

---
-- Function new
--
-- @function [parent=#IntRect] new
-- @param self Self reference
-- @param #number left left
-- @param #number top top
-- @param #number right right
-- @param #number bottom bottom
-- @return IntRect#IntRect

---
-- Function delete
--
-- @function [parent=#IntRect] delete
-- @param self Self reference

---
-- Function operator==
--
-- @function [parent=#IntRect] operator==
-- @param self Self reference
-- @param IntRect#IntRect rhs rhs
-- @return #boolean

---
-- Function Size
--
-- @function [parent=#IntRect] Size
-- @param self Self reference
-- @return IntVector2#IntVector2

---
-- Function Width
--
-- @function [parent=#IntRect] Width
-- @param self Self reference
-- @return #number

---
-- Function Height
--
-- @function [parent=#IntRect] Height
-- @param self Self reference
-- @return #number

---
-- Function IsInside
--
-- @function [parent=#IntRect] IsInside
-- @param self Self reference
-- @param IntVector2#IntVector2 point point
-- @return Intersection#Intersection

---
-- Field left
--
-- @field [parent=#IntRect] #number left

---
-- Field top
--
-- @field [parent=#IntRect] #number top

---
-- Field right
--
-- @field [parent=#IntRect] #number right

---
-- Field bottom
--
-- @field [parent=#IntRect] #number bottom

---
-- Field ZERO
--
-- @field [parent=#IntRect] IntRect#IntRect ZERO

---
-- Field size (Read only)
--
-- @field [parent=#IntRect] IntVector2#IntVector2 size

---
-- Field width (Read only)
--
-- @field [parent=#IntRect] #number width

---
-- Field height (Read only)
--
-- @field [parent=#IntRect] #number height


return nil
