---
-- Enumeration RayQueryLevel
--
-- @module RayQueryLevel

---
-- Enumeration value RAY_AABB
--
-- @field [parent=#RayQueryLevel] #number RAY_AABB

---
-- Enumeration value RAY_OBB
--
-- @field [parent=#RayQueryLevel] #number RAY_OBB

---
-- Enumeration value RAY_TRIANGLE
--
-- @field [parent=#RayQueryLevel] #number RAY_TRIANGLE


return nil
