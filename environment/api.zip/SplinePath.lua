---
-- Module SplinePath
-- Module SplinePath extends Component
-- Generated on 2014-05-31
--
-- @module SplinePath

---
-- Function AddControlPoint()
-- Add a Node to the SplinePath as a Control Point.
--
-- @function [parent=#SplinePath] AddControlPoint
-- @param self Self reference
-- @param Node#Node point point
-- @param #number index index

---
-- Function RemoveControlPoint()
-- Remove a Node Control Point from the SplinePath.
--
-- @function [parent=#SplinePath] RemoveControlPoint
-- @param self Self reference
-- @param Node#Node point point

---
-- Function ClearControlPoints()
-- Clear the Control Points from the SplinePath.
--
-- @function [parent=#SplinePath] ClearControlPoints
-- @param self Self reference

---
-- Function GetPoint()
-- Get a point on the SplinePath from 0.f to 1.f where 0 is the start and 1 is the end.
--
-- @function [parent=#SplinePath] GetPoint
-- @param self Self reference
-- @param #number factor factor
-- @return Vector3#Vector3

---
-- Function GetInterpolationMode()
-- Get the Interpolation Mode.
--
-- @function [parent=#SplinePath] GetInterpolationMode
-- @param self Self reference
-- @return InterpolationMode#InterpolationMode

---
-- Function GetPosition()
--
-- @function [parent=#SplinePath] GetPosition
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function SetInterpolationMode()
-- Set the Interpolation Mode.
--
-- @function [parent=#SplinePath] SetInterpolationMode
-- @param self Self reference
-- @param InterpolationMode#InterpolationMode mode mode

---
-- Function SetPosition()
-- Set the controlled Node's position on the SplinePath.
--
-- @function [parent=#SplinePath] SetPosition
-- @param self Self reference
-- @param #number factor factor

---
-- Function Move()
-- Move the controlled Node to the next position along the SplinePath based off the Speed value.
--
-- @function [parent=#SplinePath] Move
-- @param self Self reference
-- @param #number timeStep timeStep

---
-- Function Reset()
-- Reset movement along the path.
--
-- @function [parent=#SplinePath] Reset
-- @param self Self reference

---
-- Function IsFinished()
-- Returns whether the movement along the SplinePath is complete.
--
-- @function [parent=#SplinePath] IsFinished
-- @param self Self reference
-- @return #boolean

---
-- Field speed
--
-- @field [parent=#SplinePath] #number speed

---
-- Field controlledNode
--
-- @field [parent=#SplinePath] Node#Node controlledNode


return nil
