---
-- Module Console
-- Extends Object
--
-- @module Console

---
-- Function SetDefaultStyle
--
-- @function [parent=#Console] SetDefaultStyle
-- @param XMLFile#XMLFile stylestyle

---
-- Function SetVisible
--
-- @function [parent=#Console] SetVisible
-- @param #boolean enableenable

---
-- Function Toggle
--
-- @function [parent=#Console] Toggle

---
-- Function SetNumRows
--
-- @function [parent=#Console] SetNumRows
-- @param #number rowsrows

---
-- Function SetNumHistoryRows
--
-- @function [parent=#Console] SetNumHistoryRows
-- @param #number rowsrows

---
-- Function UpdateElements
--
-- @function [parent=#Console] UpdateElements

---
-- Function GetDefaultStyle
--
-- @function [parent=#Console] GetDefaultStyle
-- @return XMLFile#XMLFile

---
-- Function GetBackground
--
-- @function [parent=#Console] GetBackground
-- @return BorderImage#BorderImage

---
-- Function GetLineEdit
--
-- @function [parent=#Console] GetLineEdit
-- @return LineEdit#LineEdit

---
-- Function IsVisible
--
-- @function [parent=#Console] IsVisible
-- @return #boolean

---
-- Function GetNumRows
--
-- @function [parent=#Console] GetNumRows
-- @return #number

---
-- Function GetNumHistoryRows
--
-- @function [parent=#Console] GetNumHistoryRows
-- @return #number

---
-- Function GetHistoryPosition
--
-- @function [parent=#Console] GetHistoryPosition
-- @return #number

---
-- Function GetHistoryRow
--
-- @function [parent=#Console] GetHistoryRow
-- @param #number indexindex
-- @return const String#const String

---
-- Field defaultStyle
--
-- @field [parent=#Console] XMLFile#XMLFile defaultStyle

---
-- Field background (Read only)
--
-- @field [parent=#Console] BorderImage#BorderImage background

---
-- Field lineEdit (Read only)
--
-- @field [parent=#Console] LineEdit#LineEdit lineEdit

---
-- Field visible
--
-- @field [parent=#Console] #boolean visible

---
-- Field numRows
--
-- @field [parent=#Console] #number numRows

---
-- Field numHistoryRows
--
-- @field [parent=#Console] #number numHistoryRows

---
-- Field historyPosition (Read only)
--
-- @field [parent=#Console] #number historyPosition


return nil
