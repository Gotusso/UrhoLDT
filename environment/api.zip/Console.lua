---
-- Module Console
-- Module Console extends Object
-- Generated on 2014-03-13
--
-- @module Console

---
-- Function SetDefaultStyle
--
-- @function [parent=#Console] SetDefaultStyle
-- @param self Self reference
-- @param XMLFile#XMLFile style style

---
-- Function SetVisible
--
-- @function [parent=#Console] SetVisible
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Toggle
--
-- @function [parent=#Console] Toggle
-- @param self Self reference

---
-- Function SetNumRows
--
-- @function [parent=#Console] SetNumRows
-- @param self Self reference
-- @param #number rows rows

---
-- Function SetNumHistoryRows
--
-- @function [parent=#Console] SetNumHistoryRows
-- @param self Self reference
-- @param #number rows rows

---
-- Function UpdateElements
--
-- @function [parent=#Console] UpdateElements
-- @param self Self reference

---
-- Function GetDefaultStyle
--
-- @function [parent=#Console] GetDefaultStyle
-- @param self Self reference
-- @return XMLFile#XMLFile

---
-- Function GetBackground
--
-- @function [parent=#Console] GetBackground
-- @param self Self reference
-- @return BorderImage#BorderImage

---
-- Function GetLineEdit
--
-- @function [parent=#Console] GetLineEdit
-- @param self Self reference
-- @return LineEdit#LineEdit

---
-- Function IsVisible
--
-- @function [parent=#Console] IsVisible
-- @param self Self reference
-- @return #boolean

---
-- Function GetNumRows
--
-- @function [parent=#Console] GetNumRows
-- @param self Self reference
-- @return #number

---
-- Function GetNumHistoryRows
--
-- @function [parent=#Console] GetNumHistoryRows
-- @param self Self reference
-- @return #number

---
-- Function GetHistoryPosition
--
-- @function [parent=#Console] GetHistoryPosition
-- @param self Self reference
-- @return #number

---
-- Function GetHistoryRow
--
-- @function [parent=#Console] GetHistoryRow
-- @param self Self reference
-- @param #number index index
-- @return const String#const String

---
-- Field defaultStyle
--
-- @field [parent=#Console] XMLFile#XMLFile defaultStyle

---
-- Field background (Read only)
--
-- @field [parent=#Console] BorderImage#BorderImage background

---
-- Field lineEdit (Read only)
--
-- @field [parent=#Console] LineEdit#LineEdit lineEdit

---
-- Field visible
--
-- @field [parent=#Console] #boolean visible

---
-- Field numRows
--
-- @field [parent=#Console] #number numRows

---
-- Field numHistoryRows
--
-- @field [parent=#Console] #number numHistoryRows

---
-- Field historyPosition (Read only)
--
-- @field [parent=#Console] #number historyPosition

---
-- Function GetType
--
-- @function [parent=#Console] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Console] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Console] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Console] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Console] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#Console] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Console] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Console] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Console] #string category


return nil
