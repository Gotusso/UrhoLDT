---
-- Module Console
-- Module Console extends Object
-- Generated on 2014-05-31
--
-- @module Console

---
-- Function SetDefaultStyle()
-- Set UI elements' style from an XML file.
--
-- @function [parent=#Console] SetDefaultStyle
-- @param self Self reference
-- @param XMLFile#XMLFile style style

---
-- Function SetVisible()
-- Show or hide.
--
-- @function [parent=#Console] SetVisible
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Toggle()
-- Toggle visibility.
--
-- @function [parent=#Console] Toggle
-- @param self Self reference

---
-- Function SetAutoVisibleOnError()
-- Automatically set console to visible when receiving an error log message.
--
-- @function [parent=#Console] SetAutoVisibleOnError
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetCommandInterpreter()
-- Set the command interpreter.
--
-- @function [parent=#Console] SetCommandInterpreter
-- @param self Self reference
-- @param #string interpreter interpreter

---
-- Function SetNumBufferedRows()
-- Set number of buffered rows.
--
-- @function [parent=#Console] SetNumBufferedRows
-- @param self Self reference
-- @param #number rows rows

---
-- Function SetNumRows()
-- Set number of displayed rows.
--
-- @function [parent=#Console] SetNumRows
-- @param self Self reference
-- @param #number rows rows

---
-- Function SetNumHistoryRows()
-- Set command history maximum size, 0 disables history.
--
-- @function [parent=#Console] SetNumHistoryRows
-- @param self Self reference
-- @param #number rows rows

---
-- Function SetFocusOnShow()
-- Set whether to automatically focus the line edit when showing. Default true on desktops and false on mobile devices, as on mobiles it would pop up the screen keyboard.
--
-- @function [parent=#Console] SetFocusOnShow
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function UpdateElements()
-- Update elements to layout properly. Call this after manually adjusting the sub-elements.
--
-- @function [parent=#Console] UpdateElements
-- @param self Self reference

---
-- Function GetDefaultStyle()
-- Return the UI style file.
--
-- @function [parent=#Console] GetDefaultStyle
-- @param self Self reference
-- @return XMLFile#XMLFile

---
-- Function GetBackground()
-- Return the background element.
--
-- @function [parent=#Console] GetBackground
-- @param self Self reference
-- @return BorderImage#BorderImage

---
-- Function GetLineEdit()
-- Return the line edit element.
--
-- @function [parent=#Console] GetLineEdit
-- @param self Self reference
-- @return LineEdit#LineEdit

---
-- Function GetCloseButton()
-- Return the close butoon element.
--
-- @function [parent=#Console] GetCloseButton
-- @param self Self reference
-- @return Button#Button

---
-- Function IsVisible()
-- Return whether is visible.
--
-- @function [parent=#Console] IsVisible
-- @param self Self reference
-- @return #boolean

---
-- Function IsAutoVisibleOnError()
-- Return true when console is set to automatically visible when receiving an error log message.
--
-- @function [parent=#Console] IsAutoVisibleOnError
-- @param self Self reference
-- @return #boolean

---
-- Function GetCommandInterpreter()
-- Return the last used command interpreter.
--
-- @function [parent=#Console] GetCommandInterpreter
-- @param self Self reference
-- @return const String#const String

---
-- Function GetNumBufferedRows()
-- Return number of buffered rows.
--
-- @function [parent=#Console] GetNumBufferedRows
-- @param self Self reference
-- @return #number

---
-- Function GetNumRows()
-- Return number of displayed rows.
--
-- @function [parent=#Console] GetNumRows
-- @param self Self reference
-- @return #number

---
-- Function CopySelectedRows()
-- Copy selected rows to system clipboard.
--
-- @function [parent=#Console] CopySelectedRows
-- @param self Self reference

---
-- Function GetNumHistoryRows()
-- Return history maximum size.
--
-- @function [parent=#Console] GetNumHistoryRows
-- @param self Self reference
-- @return #number

---
-- Function GetHistoryPosition()
-- Return current history position.
--
-- @function [parent=#Console] GetHistoryPosition
-- @param self Self reference
-- @return #number

---
-- Function GetHistoryRow()
-- Return history row at index.
--
-- @function [parent=#Console] GetHistoryRow
-- @param self Self reference
-- @param #number index index
-- @return const String#const String

---
-- Function GetFocusOnShow()
-- Return whether automatically focuses the line edit when showing.
--
-- @function [parent=#Console] GetFocusOnShow
-- @param self Self reference
-- @return #boolean

---
-- Field defaultStyle
--
-- @field [parent=#Console] XMLFile#XMLFile defaultStyle

---
-- Field background (Read only)
--
-- @field [parent=#Console] BorderImage#BorderImage background

---
-- Field lineEdit (Read only)
--
-- @field [parent=#Console] LineEdit#LineEdit lineEdit

---
-- Field closeButton (Read only)
--
-- @field [parent=#Console] Button#Button closeButton

---
-- Field visible
--
-- @field [parent=#Console] #boolean visible

---
-- Field autoVisibleOnError
--
-- @field [parent=#Console] #boolean autoVisibleOnError

---
-- Field commandInterpreter
--
-- @field [parent=#Console] #string commandInterpreter

---
-- Field numBufferedRows
--
-- @field [parent=#Console] #number numBufferedRows

---
-- Field numRows
--
-- @field [parent=#Console] #number numRows

---
-- Field numHistoryRows
--
-- @field [parent=#Console] #number numHistoryRows

---
-- Field historyPosition (Read only)
--
-- @field [parent=#Console] #number historyPosition

---
-- Field focusOnShow
--
-- @field [parent=#Console] #boolean focusOnShow


return nil
