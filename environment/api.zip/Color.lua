---
-- Module Color
-- Generated on 2014-05-31
--
-- @module Color

---
-- Function Color()
-- Construct with default values (opaque white.)
--
-- @function [parent=#Color] Color
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#Color] new
-- @param self Self reference
-- @return Color#Color

---
-- Function Color()
--
-- @function [parent=#Color] Color
-- @param self Self reference
-- @param Color#Color color color

---
-- Function new()
--
-- @function [parent=#Color] new
-- @param self Self reference
-- @param Color#Color color color
-- @return Color#Color

---
-- Function Color()
--
-- @function [parent=#Color] Color
-- @param self Self reference
-- @param Color#Color color color
-- @param #number a a

---
-- Function new()
--
-- @function [parent=#Color] new
-- @param self Self reference
-- @param Color#Color color color
-- @param #number a a
-- @return Color#Color

---
-- Function Color()
--
-- @function [parent=#Color] Color
-- @param self Self reference
-- @param #number r r
-- @param #number g g
-- @param #number b b

---
-- Function new()
--
-- @function [parent=#Color] new
-- @param self Self reference
-- @param #number r r
-- @param #number g g
-- @param #number b b
-- @return Color#Color

---
-- Function Color()
--
-- @function [parent=#Color] Color
-- @param self Self reference
-- @param #number r r
-- @param #number g g
-- @param #number b b
-- @param #number a a

---
-- Function new()
--
-- @function [parent=#Color] new
-- @param self Self reference
-- @param #number r r
-- @param #number g g
-- @param #number b b
-- @param #number a a
-- @return Color#Color

---
-- Function delete()
--
-- @function [parent=#Color] delete
-- @param self Self reference

---
-- Function operator==()
--
-- @function [parent=#Color] operator==
-- @param self Self reference
-- @param Color#Color rhs rhs
-- @return #boolean

---
-- Function operator*()
--
-- @function [parent=#Color] operator*
-- @param self Self reference
-- @param #number rhs rhs
-- @return Color#Color

---
-- Function operator+()
--
-- @function [parent=#Color] operator+
-- @param self Self reference
-- @param Color#Color rhs rhs
-- @return Color#Color

---
-- Function ToUInt()
--
-- @function [parent=#Color] ToUInt
-- @param self Self reference
-- @return #number

---
-- Function ToHSL()
--
-- @function [parent=#Color] ToHSL
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function ToHSV()
--
-- @function [parent=#Color] ToHSV
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function FromHSL()
--
-- @function [parent=#Color] FromHSL
-- @param self Self reference
-- @param #number h h
-- @param #number s s
-- @param #number l l
-- @param #number a a

---
-- Function FromHSV()
--
-- @function [parent=#Color] FromHSV
-- @param self Self reference
-- @param #number h h
-- @param #number s s
-- @param #number v v
-- @param #number a a

---
-- Function ToVector3()
--
-- @function [parent=#Color] ToVector3
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function ToVector4()
--
-- @function [parent=#Color] ToVector4
-- @param self Self reference
-- @return Vector4#Vector4

---
-- Function SumRGB()
--
-- @function [parent=#Color] SumRGB
-- @param self Self reference
-- @return #number

---
-- Function Average()
--
-- @function [parent=#Color] Average
-- @param self Self reference
-- @return #number

---
-- Function Luma()
--
-- @function [parent=#Color] Luma
-- @param self Self reference
-- @return #number

---
-- Function Chroma()
--
-- @function [parent=#Color] Chroma
-- @param self Self reference
-- @return #number

---
-- Function Hue()
--
-- @function [parent=#Color] Hue
-- @param self Self reference
-- @return #number

---
-- Function SaturationHSL()
--
-- @function [parent=#Color] SaturationHSL
-- @param self Self reference
-- @return #number

---
-- Function SaturationHSV()
--
-- @function [parent=#Color] SaturationHSV
-- @param self Self reference
-- @return #number

---
-- Function Value()
--
-- @function [parent=#Color] Value
-- @param self Self reference
-- @return #number

---
-- Function Lightness()
--
-- @function [parent=#Color] Lightness
-- @param self Self reference
-- @return #number

---
-- Function MaxRGB()
--
-- @function [parent=#Color] MaxRGB
-- @param self Self reference
-- @return #number

---
-- Function MinRGB()
--
-- @function [parent=#Color] MinRGB
-- @param self Self reference
-- @return #number

---
-- Function Range()
--
-- @function [parent=#Color] Range
-- @param self Self reference
-- @return #number

---
-- Function Clip()
--
-- @function [parent=#Color] Clip
-- @param self Self reference
-- @param #boolean clipAlpha clipAlpha

---
-- Function Invert()
--
-- @function [parent=#Color] Invert
-- @param self Self reference
-- @param #boolean invertAlpha invertAlpha

---
-- Function Lerp()
--
-- @function [parent=#Color] Lerp
-- @param self Self reference
-- @param Color#Color rhs rhs
-- @param #number t t
-- @return Color#Color

---
-- Function Abs()
--
-- @function [parent=#Color] Abs
-- @param self Self reference
-- @return Color#Color

---
-- Function Equals()
--
-- @function [parent=#Color] Equals
-- @param self Self reference
-- @param Color#Color rhs rhs
-- @return #boolean

---
-- Function ToString()
--
-- @function [parent=#Color] ToString
-- @param self Self reference
-- @return #string

---
-- Field r
--
-- @field [parent=#Color] #number r

---
-- Field g
--
-- @field [parent=#Color] #number g

---
-- Field b
--
-- @field [parent=#Color] #number b

---
-- Field a
--
-- @field [parent=#Color] #number a

---
-- Field WHITE
--
-- @field [parent=#Color] Color#Color WHITE

---
-- Field GRAY
--
-- @field [parent=#Color] Color#Color GRAY

---
-- Field BLACK
--
-- @field [parent=#Color] Color#Color BLACK

---
-- Field RED
--
-- @field [parent=#Color] Color#Color RED

---
-- Field GREEN
--
-- @field [parent=#Color] Color#Color GREEN

---
-- Field BLUE
--
-- @field [parent=#Color] Color#Color BLUE

---
-- Field CYAN
--
-- @field [parent=#Color] Color#Color CYAN

---
-- Field MAGENTA
--
-- @field [parent=#Color] Color#Color MAGENTA

---
-- Field YELLOW
--
-- @field [parent=#Color] Color#Color YELLOW

---
-- Field TRANSPARENT
--
-- @field [parent=#Color] Color#Color TRANSPARENT


return nil
