---
-- Module Color
--
-- @module Color

---
-- Function Color
--
-- @function [parent=#Color] Color

---
-- Function new
--
-- @function [parent=#Color] new
-- @return Color#Color

---
-- Function Color
--
-- @function [parent=#Color] Color
-- @param Color#Color colorcolor

---
-- Function new
--
-- @function [parent=#Color] new
-- @param Color#Color colorcolor
-- @return Color#Color

---
-- Function Color
--
-- @function [parent=#Color] Color
-- @param Color#Color colorcolor
-- @param #number aa

---
-- Function new
--
-- @function [parent=#Color] new
-- @param Color#Color colorcolor
-- @param #number aa
-- @return Color#Color

---
-- Function Color
--
-- @function [parent=#Color] Color
-- @param #number rr
-- @param #number gg
-- @param #number bb

---
-- Function new
--
-- @function [parent=#Color] new
-- @param #number rr
-- @param #number gg
-- @param #number bb
-- @return Color#Color

---
-- Function Color
--
-- @function [parent=#Color] Color
-- @param #number rr
-- @param #number gg
-- @param #number bb
-- @param #number aa

---
-- Function new
--
-- @function [parent=#Color] new
-- @param #number rr
-- @param #number gg
-- @param #number bb
-- @param #number aa
-- @return Color#Color

---
-- Function delete
--
-- @function [parent=#Color] delete

---
-- Function operator==
--
-- @function [parent=#Color] operator==
-- @param Color#Color rhsrhs
-- @return #boolean

---
-- Function operator*
--
-- @function [parent=#Color] operator*
-- @param #number rhsrhs
-- @return Color#Color

---
-- Function operator+
--
-- @function [parent=#Color] operator+
-- @param Color#Color rhsrhs
-- @return Color#Color

---
-- Function ToUInt
--
-- @function [parent=#Color] ToUInt
-- @return #number

---
-- Function ToHSL
--
-- @function [parent=#Color] ToHSL
-- @return Vector3#Vector3

---
-- Function ToHSV
--
-- @function [parent=#Color] ToHSV
-- @return Vector3#Vector3

---
-- Function FromHSL
--
-- @function [parent=#Color] FromHSL
-- @param #number hh
-- @param #number ss
-- @param #number ll
-- @param #number aa

---
-- Function FromHSV
--
-- @function [parent=#Color] FromHSV
-- @param #number hh
-- @param #number ss
-- @param #number vv
-- @param #number aa

---
-- Function ToVector3
--
-- @function [parent=#Color] ToVector3
-- @return Vector3#Vector3

---
-- Function ToVector4
--
-- @function [parent=#Color] ToVector4
-- @return Vector4#Vector4

---
-- Function SumRGB
--
-- @function [parent=#Color] SumRGB
-- @return #number

---
-- Function Average
--
-- @function [parent=#Color] Average
-- @return #number

---
-- Function Luma
--
-- @function [parent=#Color] Luma
-- @return #number

---
-- Function Chroma
--
-- @function [parent=#Color] Chroma
-- @return #number

---
-- Function Hue
--
-- @function [parent=#Color] Hue
-- @return #number

---
-- Function SaturationHSL
--
-- @function [parent=#Color] SaturationHSL
-- @return #number

---
-- Function SaturationHSV
--
-- @function [parent=#Color] SaturationHSV
-- @return #number

---
-- Function Value
--
-- @function [parent=#Color] Value
-- @return #number

---
-- Function Lightness
--
-- @function [parent=#Color] Lightness
-- @return #number

---
-- Function MaxRGB
--
-- @function [parent=#Color] MaxRGB
-- @return #number

---
-- Function MinRGB
--
-- @function [parent=#Color] MinRGB
-- @return #number

---
-- Function Range
--
-- @function [parent=#Color] Range
-- @return #number

---
-- Function Clip
--
-- @function [parent=#Color] Clip
-- @param #boolean clipAlphaclipAlpha

---
-- Function Invert
--
-- @function [parent=#Color] Invert
-- @param #boolean invertAlphainvertAlpha

---
-- Function Lerp
--
-- @function [parent=#Color] Lerp
-- @param Color#Color rhsrhs
-- @param #number tt
-- @return Color#Color

---
-- Function ToString
--
-- @function [parent=#Color] ToString
-- @return #string

---
-- Field r
--
-- @field [parent=#Color] #number r

---
-- Field g
--
-- @field [parent=#Color] #number g

---
-- Field b
--
-- @field [parent=#Color] #number b

---
-- Field a
--
-- @field [parent=#Color] #number a

---
-- Field WHITE
--
-- @field [parent=#Color] Color#Color WHITE

---
-- Field GRAY
--
-- @field [parent=#Color] Color#Color GRAY

---
-- Field BLACK
--
-- @field [parent=#Color] Color#Color BLACK

---
-- Field RED
--
-- @field [parent=#Color] Color#Color RED

---
-- Field GREEN
--
-- @field [parent=#Color] Color#Color GREEN

---
-- Field BLUE
--
-- @field [parent=#Color] Color#Color BLUE

---
-- Field CYAN
--
-- @field [parent=#Color] Color#Color CYAN

---
-- Field MAGENTA
--
-- @field [parent=#Color] Color#Color MAGENTA

---
-- Field YELLOW
--
-- @field [parent=#Color] Color#Color YELLOW

---
-- Field TRANSPARENT
--
-- @field [parent=#Color] Color#Color TRANSPARENT


return nil
