---
-- Enumeration VariantType
--
-- @module VariantType

---
-- Enumeration value VAR_NONE
--
-- @field [parent=#VariantType] #number VAR_NONE

---
-- Enumeration value VAR_INT
--
-- @field [parent=#VariantType] #number VAR_INT

---
-- Enumeration value VAR_BOOL
--
-- @field [parent=#VariantType] #number VAR_BOOL

---
-- Enumeration value VAR_FLOAT
--
-- @field [parent=#VariantType] #number VAR_FLOAT

---
-- Enumeration value VAR_VECTOR2
--
-- @field [parent=#VariantType] #number VAR_VECTOR2

---
-- Enumeration value VAR_VECTOR3
--
-- @field [parent=#VariantType] #number VAR_VECTOR3

---
-- Enumeration value VAR_VECTOR4
--
-- @field [parent=#VariantType] #number VAR_VECTOR4

---
-- Enumeration value VAR_QUATERNION
--
-- @field [parent=#VariantType] #number VAR_QUATERNION

---
-- Enumeration value VAR_COLOR
--
-- @field [parent=#VariantType] #number VAR_COLOR

---
-- Enumeration value VAR_STRING
--
-- @field [parent=#VariantType] #number VAR_STRING

---
-- Enumeration value VAR_BUFFER
--
-- @field [parent=#VariantType] #number VAR_BUFFER

---
-- Enumeration value VAR_VOIDPTR
--
-- @field [parent=#VariantType] #number VAR_VOIDPTR

---
-- Enumeration value VAR_RESOURCEREF
--
-- @field [parent=#VariantType] #number VAR_RESOURCEREF

---
-- Enumeration value VAR_RESOURCEREFLIST
--
-- @field [parent=#VariantType] #number VAR_RESOURCEREFLIST

---
-- Enumeration value VAR_VARIANTVECTOR
--
-- @field [parent=#VariantType] #number VAR_VARIANTVECTOR

---
-- Enumeration value VAR_VARIANTMAP
--
-- @field [parent=#VariantType] #number VAR_VARIANTMAP

---
-- Enumeration value VAR_INTRECT
--
-- @field [parent=#VariantType] #number VAR_INTRECT

---
-- Enumeration value VAR_INTVECTOR2
--
-- @field [parent=#VariantType] #number VAR_INTVECTOR2

---
-- Enumeration value VAR_PTR
--
-- @field [parent=#VariantType] #number VAR_PTR

---
-- Enumeration value MAX_VAR_TYPES
--
-- @field [parent=#VariantType] #number MAX_VAR_TYPES


return nil
