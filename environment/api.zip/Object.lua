---
-- Module Object
-- Module Object extends RefCounted
-- Generated on 2014-05-31
--
-- @module Object

---
-- Function GetType()
-- Return type hash.
--
-- @function [parent=#Object] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType()
-- Return base class type hash.
--
-- @function [parent=#Object] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName()
-- Return type name.
--
-- @function [parent=#Object] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory()
-- Return object category. Categories are (optionally) registered along with the object factory. Return an empty string if the object category is not registered.
--
-- @function [parent=#Object] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent()
--
-- @function [parent=#Object] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#Object] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Object] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Object] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Object] #string category


return nil
