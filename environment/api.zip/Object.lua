---
-- Module Object
-- extends RefCounted
--
-- @module Object

---
-- Function GetType
--
-- @function [parent=#Object] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Object] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Object] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Object] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Object] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#Object] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Object] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Object] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Object] #string category


return nil
