---
-- Enumeration TextureFilterMode
--
-- @module TextureFilterMode

---
-- Enumeration value FILTER_NEAREST
--
-- @field [parent=#TextureFilterMode] #number FILTER_NEAREST

---
-- Enumeration value FILTER_BILINEAR
--
-- @field [parent=#TextureFilterMode] #number FILTER_BILINEAR

---
-- Enumeration value FILTER_TRILINEAR
--
-- @field [parent=#TextureFilterMode] #number FILTER_TRILINEAR

---
-- Enumeration value FILTER_ANISOTROPIC
--
-- @field [parent=#TextureFilterMode] #number FILTER_ANISOTROPIC

---
-- Enumeration value FILTER_DEFAULT
--
-- @field [parent=#TextureFilterMode] #number FILTER_DEFAULT

---
-- Enumeration value MAX_FILTERMODES
--
-- @field [parent=#TextureFilterMode] #number MAX_FILTERMODES


return nil
