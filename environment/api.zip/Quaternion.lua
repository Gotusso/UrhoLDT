---
-- Module Quaternion
--
-- @module Quaternion

---
-- Function Quaternion
--
-- @function [parent=#Quaternion] Quaternion

---
-- Function new
--
-- @function [parent=#Quaternion] new
-- @return Quaternion#Quaternion

---
-- Function Quaternion
--
-- @function [parent=#Quaternion] Quaternion
-- @param Quaternion#Quaternion quatquat

---
-- Function new
--
-- @function [parent=#Quaternion] new
-- @param Quaternion#Quaternion quatquat
-- @return Quaternion#Quaternion

---
-- Function Quaternion
--
-- @function [parent=#Quaternion] Quaternion
-- @param #number ww
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function new
--
-- @function [parent=#Quaternion] new
-- @param #number ww
-- @param #number xx
-- @param #number yy
-- @param #number zz
-- @return Quaternion#Quaternion

---
-- Function Quaternion
--
-- @function [parent=#Quaternion] Quaternion
-- @param #number angleangle
-- @param Vector3#Vector3 axisaxis

---
-- Function new
--
-- @function [parent=#Quaternion] new
-- @param #number angleangle
-- @param Vector3#Vector3 axisaxis
-- @return Quaternion#Quaternion

---
-- Function Quaternion
--
-- @function [parent=#Quaternion] Quaternion
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function new
--
-- @function [parent=#Quaternion] new
-- @param #number xx
-- @param #number yy
-- @param #number zz
-- @return Quaternion#Quaternion

---
-- Function Quaternion
--
-- @function [parent=#Quaternion] Quaternion
-- @param Vector3#Vector3 startstart
-- @param Vector3#Vector3 endend

---
-- Function new
--
-- @function [parent=#Quaternion] new
-- @param Vector3#Vector3 startstart
-- @param Vector3#Vector3 endend
-- @return Quaternion#Quaternion

---
-- Function Quaternion
--
-- @function [parent=#Quaternion] Quaternion
-- @param Vector3#Vector3 xAxisxAxis
-- @param Vector3#Vector3 yAxisyAxis
-- @param Vector3#Vector3 zAxiszAxis

---
-- Function new
--
-- @function [parent=#Quaternion] new
-- @param Vector3#Vector3 xAxisxAxis
-- @param Vector3#Vector3 yAxisyAxis
-- @param Vector3#Vector3 zAxiszAxis
-- @return Quaternion#Quaternion

---
-- Function Quaternion
--
-- @function [parent=#Quaternion] Quaternion
-- @param Matrix3#Matrix3 matrixmatrix

---
-- Function new
--
-- @function [parent=#Quaternion] new
-- @param Matrix3#Matrix3 matrixmatrix
-- @return Quaternion#Quaternion

---
-- Function delete
--
-- @function [parent=#Quaternion] delete

---
-- Function operator==
--
-- @function [parent=#Quaternion] operator==
-- @param Quaternion#Quaternion rhsrhs
-- @return #boolean

---
-- Function operator*
--
-- @function [parent=#Quaternion] operator*
-- @param #number rhsrhs
-- @return Quaternion#Quaternion

---
-- Function operator-
--
-- @function [parent=#Quaternion] operator-
-- @return Quaternion#Quaternion

---
-- Function operator==
--
-- @function [parent=#Quaternion] operator==
-- @param Quaternion#Quaternion rhsrhs
-- @return #boolean

---
-- Function operator*
--
-- @function [parent=#Quaternion] operator*
-- @param #number rhsrhs
-- @return Quaternion#Quaternion

---
-- Function operator-
--
-- @function [parent=#Quaternion] operator-
-- @return Quaternion#Quaternion

---
-- Function operator+
--
-- @function [parent=#Quaternion] operator+
-- @param Quaternion#Quaternion rhsrhs
-- @return Quaternion#Quaternion

---
-- Function operator-
--
-- @function [parent=#Quaternion] operator-
-- @param Quaternion#Quaternion rhsrhs
-- @return Quaternion#Quaternion

---
-- Function operator*
--
-- @function [parent=#Quaternion] operator*
-- @param Quaternion#Quaternion rhsrhs
-- @return Quaternion#Quaternion

---
-- Function operator*
--
-- @function [parent=#Quaternion] operator*
-- @param Vector3#Vector3 rhsrhs
-- @return Vector3#Vector3

---
-- Function FromAngleAxis
--
-- @function [parent=#Quaternion] FromAngleAxis
-- @param #number angleangle
-- @param Vector3#Vector3 axisaxis

---
-- Function FromEulerAngles
--
-- @function [parent=#Quaternion] FromEulerAngles
-- @param #number xx
-- @param #number yy
-- @param #number zz

---
-- Function FromRotationTo
--
-- @function [parent=#Quaternion] FromRotationTo
-- @param Vector3#Vector3 startstart
-- @param Vector3#Vector3 endend

---
-- Function FromAxes
--
-- @function [parent=#Quaternion] FromAxes
-- @param Vector3#Vector3 xAxisxAxis
-- @param Vector3#Vector3 yAxisyAxis
-- @param Vector3#Vector3 zAxiszAxis

---
-- Function FromRotationMatrix
--
-- @function [parent=#Quaternion] FromRotationMatrix
-- @param Matrix3#Matrix3 matrixmatrix

---
-- Function FromLookRotation
--
-- @function [parent=#Quaternion] FromLookRotation
-- @param Vector3#Vector3 directiondirection
-- @param Vector3#Vector3 upup

---
-- Function Normalize
--
-- @function [parent=#Quaternion] Normalize

---
-- Function Normalized
--
-- @function [parent=#Quaternion] Normalized
-- @return Quaternion#Quaternion

---
-- Function Inverse
--
-- @function [parent=#Quaternion] Inverse
-- @return Quaternion#Quaternion

---
-- Function LengthSquared
--
-- @function [parent=#Quaternion] LengthSquared
-- @return #number

---
-- Function DotProduct
--
-- @function [parent=#Quaternion] DotProduct
-- @param Quaternion#Quaternion rhsrhs
-- @return #number

---
-- Function Equals
--
-- @function [parent=#Quaternion] Equals
-- @param Quaternion#Quaternion rhsrhs
-- @return #boolean

---
-- Function Conjugate
--
-- @function [parent=#Quaternion] Conjugate
-- @return Quaternion#Quaternion

---
-- Function EulerAngles
--
-- @function [parent=#Quaternion] EulerAngles
-- @return Vector3#Vector3

---
-- Function YawAngle
--
-- @function [parent=#Quaternion] YawAngle
-- @return #number

---
-- Function PitchAngle
--
-- @function [parent=#Quaternion] PitchAngle
-- @return #number

---
-- Function RollAngle
--
-- @function [parent=#Quaternion] RollAngle
-- @return #number

---
-- Function RotationMatrix
--
-- @function [parent=#Quaternion] RotationMatrix
-- @return Matrix3#Matrix3

---
-- Function Slerp
--
-- @function [parent=#Quaternion] Slerp
-- @param Quaternion#Quaternion rhsrhs
-- @param #number tt
-- @return Quaternion#Quaternion

---
-- Function Nlerp
--
-- @function [parent=#Quaternion] Nlerp
-- @param Quaternion#Quaternion rhsrhs
-- @param #number tt
-- @param #boolean shortestPathshortestPath
-- @return Quaternion#Quaternion

---
-- Function ToString
--
-- @function [parent=#Quaternion] ToString
-- @return #string

---
-- Field w
--
-- @field [parent=#Quaternion] #number w

---
-- Field x
--
-- @field [parent=#Quaternion] #number x

---
-- Field y
--
-- @field [parent=#Quaternion] #number y

---
-- Field z
--
-- @field [parent=#Quaternion] #number z

---
-- Field IDENTITY
--
-- @field [parent=#Quaternion] Quaternion#Quaternion IDENTITY


return nil
