---
-- Module Quaternion
-- Generated on 2014-05-31
--
-- @module Quaternion

---
-- Function Quaternion()
-- Construct an identity quaternion.
--
-- @function [parent=#Quaternion] Quaternion
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#Quaternion] new
-- @param self Self reference
-- @return Quaternion#Quaternion

---
-- Function Quaternion()
--
-- @function [parent=#Quaternion] Quaternion
-- @param self Self reference
-- @param Quaternion#Quaternion quat quat

---
-- Function new()
--
-- @function [parent=#Quaternion] new
-- @param self Self reference
-- @param Quaternion#Quaternion quat quat
-- @return Quaternion#Quaternion

---
-- Function Quaternion()
--
-- @function [parent=#Quaternion] Quaternion
-- @param self Self reference
-- @param #number w w
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function new()
--
-- @function [parent=#Quaternion] new
-- @param self Self reference
-- @param #number w w
-- @param #number x x
-- @param #number y y
-- @param #number z z
-- @return Quaternion#Quaternion

---
-- Function Quaternion()
--
-- @function [parent=#Quaternion] Quaternion
-- @param self Self reference
-- @param #number angle angle
-- @param Vector3#Vector3 axis axis

---
-- Function new()
--
-- @function [parent=#Quaternion] new
-- @param self Self reference
-- @param #number angle angle
-- @param Vector3#Vector3 axis axis
-- @return Quaternion#Quaternion

---
-- Function Quaternion()
--
-- @function [parent=#Quaternion] Quaternion
-- @param self Self reference
-- @param #number angle angle

---
-- Function new()
--
-- @function [parent=#Quaternion] new
-- @param self Self reference
-- @param #number angle angle
-- @return Quaternion#Quaternion

---
-- Function Quaternion()
--
-- @function [parent=#Quaternion] Quaternion
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function new()
--
-- @function [parent=#Quaternion] new
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z
-- @return Quaternion#Quaternion

---
-- Function Quaternion()
--
-- @function [parent=#Quaternion] Quaternion
-- @param self Self reference
-- @param Vector3#Vector3 start start
-- @param Vector3#Vector3 end end

---
-- Function new()
--
-- @function [parent=#Quaternion] new
-- @param self Self reference
-- @param Vector3#Vector3 start start
-- @param Vector3#Vector3 end end
-- @return Quaternion#Quaternion

---
-- Function Quaternion()
--
-- @function [parent=#Quaternion] Quaternion
-- @param self Self reference
-- @param Vector3#Vector3 xAxis xAxis
-- @param Vector3#Vector3 yAxis yAxis
-- @param Vector3#Vector3 zAxis zAxis

---
-- Function new()
--
-- @function [parent=#Quaternion] new
-- @param self Self reference
-- @param Vector3#Vector3 xAxis xAxis
-- @param Vector3#Vector3 yAxis yAxis
-- @param Vector3#Vector3 zAxis zAxis
-- @return Quaternion#Quaternion

---
-- Function Quaternion()
--
-- @function [parent=#Quaternion] Quaternion
-- @param self Self reference
-- @param Matrix3#Matrix3 matrix matrix

---
-- Function new()
--
-- @function [parent=#Quaternion] new
-- @param self Self reference
-- @param Matrix3#Matrix3 matrix matrix
-- @return Quaternion#Quaternion

---
-- Function delete()
--
-- @function [parent=#Quaternion] delete
-- @param self Self reference

---
-- Function operator==()
--
-- @function [parent=#Quaternion] operator==
-- @param self Self reference
-- @param Quaternion#Quaternion rhs rhs
-- @return #boolean

---
-- Function operator*()
--
-- @function [parent=#Quaternion] operator*
-- @param self Self reference
-- @param #number rhs rhs
-- @return Quaternion#Quaternion

---
-- Function operator-()
--
-- @function [parent=#Quaternion] operator-
-- @param self Self reference
-- @return Quaternion#Quaternion

---
-- Function operator==()
--
-- @function [parent=#Quaternion] operator==
-- @param self Self reference
-- @param Quaternion#Quaternion rhs rhs
-- @return #boolean

---
-- Function operator*()
--
-- @function [parent=#Quaternion] operator*
-- @param self Self reference
-- @param #number rhs rhs
-- @return Quaternion#Quaternion

---
-- Function operator-()
--
-- @function [parent=#Quaternion] operator-
-- @param self Self reference
-- @return Quaternion#Quaternion

---
-- Function operator+()
--
-- @function [parent=#Quaternion] operator+
-- @param self Self reference
-- @param Quaternion#Quaternion rhs rhs
-- @return Quaternion#Quaternion

---
-- Function operator-()
--
-- @function [parent=#Quaternion] operator-
-- @param self Self reference
-- @param Quaternion#Quaternion rhs rhs
-- @return Quaternion#Quaternion

---
-- Function operator*()
--
-- @function [parent=#Quaternion] operator*
-- @param self Self reference
-- @param Quaternion#Quaternion rhs rhs
-- @return Quaternion#Quaternion

---
-- Function operator*()
--
-- @function [parent=#Quaternion] operator*
-- @param self Self reference
-- @param Vector3#Vector3 rhs rhs
-- @return Vector3#Vector3

---
-- Function FromAngleAxis()
--
-- @function [parent=#Quaternion] FromAngleAxis
-- @param self Self reference
-- @param #number angle angle
-- @param Vector3#Vector3 axis axis

---
-- Function FromEulerAngles()
--
-- @function [parent=#Quaternion] FromEulerAngles
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @param #number z z

---
-- Function FromRotationTo()
--
-- @function [parent=#Quaternion] FromRotationTo
-- @param self Self reference
-- @param Vector3#Vector3 start start
-- @param Vector3#Vector3 end end

---
-- Function FromAxes()
--
-- @function [parent=#Quaternion] FromAxes
-- @param self Self reference
-- @param Vector3#Vector3 xAxis xAxis
-- @param Vector3#Vector3 yAxis yAxis
-- @param Vector3#Vector3 zAxis zAxis

---
-- Function FromRotationMatrix()
--
-- @function [parent=#Quaternion] FromRotationMatrix
-- @param self Self reference
-- @param Matrix3#Matrix3 matrix matrix

---
-- Function FromLookRotation()
--
-- @function [parent=#Quaternion] FromLookRotation
-- @param self Self reference
-- @param Vector3#Vector3 direction direction
-- @param Vector3#Vector3 up up
-- @return #boolean

---
-- Function Normalize()
--
-- @function [parent=#Quaternion] Normalize
-- @param self Self reference

---
-- Function Normalized()
--
-- @function [parent=#Quaternion] Normalized
-- @param self Self reference
-- @return Quaternion#Quaternion

---
-- Function Inverse()
--
-- @function [parent=#Quaternion] Inverse
-- @param self Self reference
-- @return Quaternion#Quaternion

---
-- Function LengthSquared()
--
-- @function [parent=#Quaternion] LengthSquared
-- @param self Self reference
-- @return #number

---
-- Function DotProduct()
--
-- @function [parent=#Quaternion] DotProduct
-- @param self Self reference
-- @param Quaternion#Quaternion rhs rhs
-- @return #number

---
-- Function Equals()
--
-- @function [parent=#Quaternion] Equals
-- @param self Self reference
-- @param Quaternion#Quaternion rhs rhs
-- @return #boolean

---
-- Function IsNaN()
--
-- @function [parent=#Quaternion] IsNaN
-- @param self Self reference
-- @return #boolean

---
-- Function Conjugate()
--
-- @function [parent=#Quaternion] Conjugate
-- @param self Self reference
-- @return Quaternion#Quaternion

---
-- Function EulerAngles()
--
-- @function [parent=#Quaternion] EulerAngles
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function YawAngle()
--
-- @function [parent=#Quaternion] YawAngle
-- @param self Self reference
-- @return #number

---
-- Function PitchAngle()
--
-- @function [parent=#Quaternion] PitchAngle
-- @param self Self reference
-- @return #number

---
-- Function RollAngle()
--
-- @function [parent=#Quaternion] RollAngle
-- @param self Self reference
-- @return #number

---
-- Function RotationMatrix()
--
-- @function [parent=#Quaternion] RotationMatrix
-- @param self Self reference
-- @return Matrix3#Matrix3

---
-- Function Slerp()
--
-- @function [parent=#Quaternion] Slerp
-- @param self Self reference
-- @param Quaternion#Quaternion rhs rhs
-- @param #number t t
-- @return Quaternion#Quaternion

---
-- Function Nlerp()
--
-- @function [parent=#Quaternion] Nlerp
-- @param self Self reference
-- @param Quaternion#Quaternion rhs rhs
-- @param #number t t
-- @param #boolean shortestPath shortestPath
-- @return Quaternion#Quaternion

---
-- Function ToString()
--
-- @function [parent=#Quaternion] ToString
-- @param self Self reference
-- @return #string

---
-- Field w
--
-- @field [parent=#Quaternion] #number w

---
-- Field x
--
-- @field [parent=#Quaternion] #number x

---
-- Field y
--
-- @field [parent=#Quaternion] #number y

---
-- Field z
--
-- @field [parent=#Quaternion] #number z

---
-- Field IDENTITY
--
-- @field [parent=#Quaternion] Quaternion#Quaternion IDENTITY


return nil
