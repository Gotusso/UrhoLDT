---
-- Enumeration PassLightingMode
--
-- @module PassLightingMode

---
-- Enumeration value LIGHTING_UNLIT
--
-- @field [parent=#PassLightingMode] #number LIGHTING_UNLIT

---
-- Enumeration value LIGHTING_PERVERTEX
--
-- @field [parent=#PassLightingMode] #number LIGHTING_PERVERTEX

---
-- Enumeration value LIGHTING_PERPIXEL
--
-- @field [parent=#PassLightingMode] #number LIGHTING_PERPIXEL


return nil
