---
-- Module Billboard
-- Generated on 2014-03-13
--
-- @module Billboard

---
-- Field position
--
-- @field [parent=#Billboard] Vector3#Vector3 position

---
-- Field size
--
-- @field [parent=#Billboard] Vector2#Vector2 size

---
-- Field uv
--
-- @field [parent=#Billboard] Rect#Rect uv

---
-- Field color
--
-- @field [parent=#Billboard] Color#Color color

---
-- Field rotation
--
-- @field [parent=#Billboard] #number rotation

---
-- Field enabled
--
-- @field [parent=#Billboard] #boolean enabled

---
-- Field sortDistance
--
-- @field [parent=#Billboard] #number sortDistance


return nil
