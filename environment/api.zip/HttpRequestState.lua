---
-- Enumeration HttpRequestState
--
-- @module HttpRequestState

---
-- Enumeration value HTTP_INITIALIZING
--
-- @field [parent=#HttpRequestState] #number HTTP_INITIALIZING

---
-- Enumeration value HTTP_ERROR
--
-- @field [parent=#HttpRequestState] #number HTTP_ERROR

---
-- Enumeration value HTTP_OPEN
--
-- @field [parent=#HttpRequestState] #number HTTP_OPEN

---
-- Enumeration value HTTP_CLOSED
--
-- @field [parent=#HttpRequestState] #number HTTP_CLOSED


return nil
