---
-- Module JoystickState
-- Generated on 2014-05-31
--
-- @module JoystickState

---
-- Function IsController()
--
-- @function [parent=#JoystickState] IsController
-- @param self Self reference
-- @return #boolean

---
-- Function GetNumButtons()
--
-- @function [parent=#JoystickState] GetNumButtons
-- @param self Self reference
-- @return #number

---
-- Function GetNumAxes()
--
-- @function [parent=#JoystickState] GetNumAxes
-- @param self Self reference
-- @return #number

---
-- Function GetNumHats()
--
-- @function [parent=#JoystickState] GetNumHats
-- @param self Self reference
-- @return #number

---
-- Function GetButtonDown()
--
-- @function [parent=#JoystickState] GetButtonDown
-- @param self Self reference
-- @param #number index index
-- @return #boolean

---
-- Function GetButtonPress()
--
-- @function [parent=#JoystickState] GetButtonPress
-- @param self Self reference
-- @param #number index index
-- @return #boolean

---
-- Function GetAxisPosition()
--
-- @function [parent=#JoystickState] GetAxisPosition
-- @param self Self reference
-- @param #number index index
-- @return #number

---
-- Function GetHatPosition()
--
-- @function [parent=#JoystickState] GetHatPosition
-- @param self Self reference
-- @param #number index index
-- @return #number

---
-- Field name
--
-- @field [parent=#JoystickState] #string name

---
-- Field joystickID
--
-- @field [parent=#JoystickState] #number joystickID

---
-- Field controller (Read only)
--
-- @field [parent=#JoystickState] #boolean controller

---
-- Field numButtons (Read only)
--
-- @field [parent=#JoystickState] #number numButtons

---
-- Field numAxes (Read only)
--
-- @field [parent=#JoystickState] #number numAxes

---
-- Field numHats (Read only)
--
-- @field [parent=#JoystickState] #number numHats


return nil
