---
-- Module JoystickState
--
-- @module JoystickState

---
-- Function GetNumButtons
--
-- @function [parent=#JoystickState] GetNumButtons
-- @return #number

---
-- Function GetNumAxes
--
-- @function [parent=#JoystickState] GetNumAxes
-- @return #number

---
-- Function GetNumHats
--
-- @function [parent=#JoystickState] GetNumHats
-- @return #number

---
-- Function GetButtonDown
--
-- @function [parent=#JoystickState] GetButtonDown
-- @param #number indexindex
-- @return #boolean

---
-- Function GetButtonPress
--
-- @function [parent=#JoystickState] GetButtonPress
-- @param #number indexindex
-- @return #boolean

---
-- Function GetAxisPosition
--
-- @function [parent=#JoystickState] GetAxisPosition
-- @param #number indexindex
-- @return #number

---
-- Function GetHatPosition
--
-- @function [parent=#JoystickState] GetHatPosition
-- @param #number indexindex
-- @return #number

---
-- Field numButtons (Read only)
--
-- @field [parent=#JoystickState] #number numButtons

---
-- Field numAxes (Read only)
--
-- @field [parent=#JoystickState] #number numAxes

---
-- Field numHats (Read only)
--
-- @field [parent=#JoystickState] #number numHats


return nil
