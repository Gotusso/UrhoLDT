---
-- Enumeration VertexLightVSVariation
--
-- @module VertexLightVSVariation

---
-- Enumeration value VLVS_NOLIGHTS
--
-- @field [parent=#VertexLightVSVariation] #number VLVS_NOLIGHTS

---
-- Enumeration value VLVS_1LIGHT
--
-- @field [parent=#VertexLightVSVariation] #number VLVS_1LIGHT

---
-- Enumeration value VLVS_2LIGHTS
--
-- @field [parent=#VertexLightVSVariation] #number VLVS_2LIGHTS

---
-- Enumeration value VLVS_3LIGHTS
--
-- @field [parent=#VertexLightVSVariation] #number VLVS_3LIGHTS

---
-- Enumeration value VLVS_4LIGHTS
--
-- @field [parent=#VertexLightVSVariation] #number VLVS_4LIGHTS

---
-- Enumeration value MAX_VERTEXLIGHT_VS_VARIATIONS
--
-- @field [parent=#VertexLightVSVariation] #number MAX_VERTEXLIGHT_VS_VARIATIONS


return nil
