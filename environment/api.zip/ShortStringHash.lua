---
-- Module ShortStringHash
--
-- @module ShortStringHash

---
-- Function ShortStringHash
--
-- @function [parent=#ShortStringHash] ShortStringHash

---
-- Function new
--
-- @function [parent=#ShortStringHash] new
-- @return ShortStringHash#ShortStringHash

---
-- Function ShortStringHash
--
-- @function [parent=#ShortStringHash] ShortStringHash
-- @param ShortStringHash#ShortStringHash rhsrhs

---
-- Function new
--
-- @function [parent=#ShortStringHash] new
-- @param ShortStringHash#ShortStringHash rhsrhs
-- @return ShortStringHash#ShortStringHash

---
-- Function ShortStringHash
--
-- @function [parent=#ShortStringHash] ShortStringHash
-- @param StringHash#StringHash rhsrhs

---
-- Function new
--
-- @function [parent=#ShortStringHash] new
-- @param StringHash#StringHash rhsrhs
-- @return ShortStringHash#ShortStringHash

---
-- Function ShortStringHash
--
-- @function [parent=#ShortStringHash] ShortStringHash
-- @param short#short valuevalue

---
-- Function new
--
-- @function [parent=#ShortStringHash] new
-- @param short#short valuevalue
-- @return ShortStringHash#ShortStringHash

---
-- Function ShortStringHash
--
-- @function [parent=#ShortStringHash] ShortStringHash
-- @param #string strstr

---
-- Function new
--
-- @function [parent=#ShortStringHash] new
-- @param #string strstr
-- @return ShortStringHash#ShortStringHash

---
-- Function delete
--
-- @function [parent=#ShortStringHash] delete

---
-- Function operator+
--
-- @function [parent=#ShortStringHash] operator+
-- @param ShortStringHash#ShortStringHash rhsrhs
-- @return ShortStringHash#ShortStringHash

---
-- Function operator==
--
-- @function [parent=#ShortStringHash] operator==
-- @param ShortStringHash#ShortStringHash rhsrhs
-- @return #boolean

---
-- Function operator<
--
-- @function [parent=#ShortStringHash] operator<
-- @param ShortStringHash#ShortStringHash rhsrhs
-- @return #boolean

---
-- Function Value
--
-- @function [parent=#ShortStringHash] Value
-- @return short#short

---
-- Function Calculate
--
-- @function [parent=#ShortStringHash] Calculate
-- @param char*#char* strstr
-- @return short#short

---
-- Field ZERO
--
-- @field [parent=#ShortStringHash] ShortStringHash#ShortStringHash ZERO

---
-- Field value (Read only)
--
-- @field [parent=#ShortStringHash] short#short value


return nil
