---
-- Module ShortStringHash
-- Generated on 2014-03-13
--
-- @module ShortStringHash

---
-- Function ShortStringHash
--
-- @function [parent=#ShortStringHash] ShortStringHash
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#ShortStringHash] new
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function ShortStringHash
--
-- @function [parent=#ShortStringHash] ShortStringHash
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash rhs rhs

---
-- Function new
--
-- @function [parent=#ShortStringHash] new
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash rhs rhs
-- @return ShortStringHash#ShortStringHash

---
-- Function ShortStringHash
--
-- @function [parent=#ShortStringHash] ShortStringHash
-- @param self Self reference
-- @param StringHash#StringHash rhs rhs

---
-- Function new
--
-- @function [parent=#ShortStringHash] new
-- @param self Self reference
-- @param StringHash#StringHash rhs rhs
-- @return ShortStringHash#ShortStringHash

---
-- Function ShortStringHash
--
-- @function [parent=#ShortStringHash] ShortStringHash
-- @param self Self reference
-- @param short#short value value

---
-- Function new
--
-- @function [parent=#ShortStringHash] new
-- @param self Self reference
-- @param short#short value value
-- @return ShortStringHash#ShortStringHash

---
-- Function ShortStringHash
--
-- @function [parent=#ShortStringHash] ShortStringHash
-- @param self Self reference
-- @param #string str str

---
-- Function new
--
-- @function [parent=#ShortStringHash] new
-- @param self Self reference
-- @param #string str str
-- @return ShortStringHash#ShortStringHash

---
-- Function delete
--
-- @function [parent=#ShortStringHash] delete
-- @param self Self reference

---
-- Function operator+
--
-- @function [parent=#ShortStringHash] operator+
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash rhs rhs
-- @return ShortStringHash#ShortStringHash

---
-- Function operator==
--
-- @function [parent=#ShortStringHash] operator==
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash rhs rhs
-- @return #boolean

---
-- Function operator<
--
-- @function [parent=#ShortStringHash] operator<
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash rhs rhs
-- @return #boolean

---
-- Function Value
--
-- @function [parent=#ShortStringHash] Value
-- @param self Self reference
-- @return short#short

---
-- Function Calculate
--
-- @function [parent=#ShortStringHash] Calculate
-- @param self Self reference
-- @param char*#char* str str
-- @return short#short

---
-- Field ZERO
--
-- @field [parent=#ShortStringHash] ShortStringHash#ShortStringHash ZERO

---
-- Field value (Read only)
--
-- @field [parent=#ShortStringHash] short#short value


return nil
