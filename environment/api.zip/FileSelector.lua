---
-- Module FileSelector
-- Module FileSelector extends Object
-- Generated on 2014-05-31
--
-- @module FileSelector

---
-- Function FileSelector()
--
-- @function [parent=#FileSelector] FileSelector
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#FileSelector] new
-- @param self Self reference
-- @return FileSelector#FileSelector

---
-- Function delete()
--
-- @function [parent=#FileSelector] delete
-- @param self Self reference

---
-- Function SetDefaultStyle()
-- Set fileselector UI style.
--
-- @function [parent=#FileSelector] SetDefaultStyle
-- @param self Self reference
-- @param XMLFile#XMLFile style style

---
-- Function SetTitle()
-- Set title text.
--
-- @function [parent=#FileSelector] SetTitle
-- @param self Self reference
-- @param #string text text

---
-- Function SetButtonTexts()
-- Set button texts.
--
-- @function [parent=#FileSelector] SetButtonTexts
-- @param self Self reference
-- @param #string okText okText
-- @param #string cancelText cancelText

---
-- Function SetPath()
-- Set current path.
--
-- @function [parent=#FileSelector] SetPath
-- @param self Self reference
-- @param #string path path

---
-- Function SetFileName()
-- Set current filename.
--
-- @function [parent=#FileSelector] SetFileName
-- @param self Self reference
-- @param #string fileName fileName

---
-- Function SetFilters()
--
-- @function [parent=#FileSelector] SetFilters
-- @param self Self reference
-- @param Vector<String>#Vector<String> filters filters
-- @param #number defaultIndex defaultIndex

---
-- Function SetDirectoryMode()
-- Set directory selection mode. Default false.
--
-- @function [parent=#FileSelector] SetDirectoryMode
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function UpdateElements()
-- Update elements to layout properly. Call this after manually adjusting the sub-elements.
--
-- @function [parent=#FileSelector] UpdateElements
-- @param self Self reference

---
-- Function GetDefaultStyle()
-- Return the UI style file.
--
-- @function [parent=#FileSelector] GetDefaultStyle
-- @param self Self reference
-- @return XMLFile#XMLFile

---
-- Function GetWindow()
-- Return fileselector window.
--
-- @function [parent=#FileSelector] GetWindow
-- @param self Self reference
-- @return Window#Window

---
-- Function GetTitleText()
-- Return window title text element.
--
-- @function [parent=#FileSelector] GetTitleText
-- @param self Self reference
-- @return Text#Text

---
-- Function GetFileList()
-- Return file list.
--
-- @function [parent=#FileSelector] GetFileList
-- @param self Self reference
-- @return ListView#ListView

---
-- Function GetPathEdit()
-- Return path editor.
--
-- @function [parent=#FileSelector] GetPathEdit
-- @param self Self reference
-- @return LineEdit#LineEdit

---
-- Function GetFileNameEdit()
-- Return filename editor.
--
-- @function [parent=#FileSelector] GetFileNameEdit
-- @param self Self reference
-- @return LineEdit#LineEdit

---
-- Function GetFilterList()
-- Return filter dropdown.
--
-- @function [parent=#FileSelector] GetFilterList
-- @param self Self reference
-- @return DropDownList#DropDownList

---
-- Function GetOKButton()
-- Return OK button.
--
-- @function [parent=#FileSelector] GetOKButton
-- @param self Self reference
-- @return Button#Button

---
-- Function GetCancelButton()
-- Return cancel button.
--
-- @function [parent=#FileSelector] GetCancelButton
-- @param self Self reference
-- @return Button#Button

---
-- Function GetCloseButton()
-- Return close button.
--
-- @function [parent=#FileSelector] GetCloseButton
-- @param self Self reference
-- @return Button#Button

---
-- Function GetTitle()
-- Return window title.
--
-- @function [parent=#FileSelector] GetTitle
-- @param self Self reference
-- @return const String#const String

---
-- Function GetPath()
-- Return current path.
--
-- @function [parent=#FileSelector] GetPath
-- @param self Self reference
-- @return const String#const String

---
-- Function GetFileName()
-- Return current filename.
--
-- @function [parent=#FileSelector] GetFileName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetFilter()
-- Return current filter.
--
-- @function [parent=#FileSelector] GetFilter
-- @param self Self reference
-- @return const String#const String

---
-- Function GetFilterIndex()
-- Return current filter index.
--
-- @function [parent=#FileSelector] GetFilterIndex
-- @param self Self reference
-- @return #number

---
-- Function GetDirectoryMode()
-- Return directory mode flag.
--
-- @function [parent=#FileSelector] GetDirectoryMode
-- @param self Self reference
-- @return #boolean

---
-- Field defaultStyle
--
-- @field [parent=#FileSelector] XMLFile#XMLFile defaultStyle

---
-- Field window (Read only)
--
-- @field [parent=#FileSelector] Window#Window window

---
-- Field titleText (Read only)
--
-- @field [parent=#FileSelector] Text#Text titleText

---
-- Field fileList (Read only)
--
-- @field [parent=#FileSelector] ListView#ListView fileList

---
-- Field pathEdit (Read only)
--
-- @field [parent=#FileSelector] LineEdit#LineEdit pathEdit

---
-- Field fileNameEdit (Read only)
--
-- @field [parent=#FileSelector] LineEdit#LineEdit fileNameEdit

---
-- Field filterList (Read only)
--
-- @field [parent=#FileSelector] DropDownList#DropDownList filterList

---
-- Field OKButton (Read only)
--
-- @field [parent=#FileSelector] Button#Button OKButton

---
-- Field cancelButton (Read only)
--
-- @field [parent=#FileSelector] Button#Button cancelButton

---
-- Field closeButton (Read only)
--
-- @field [parent=#FileSelector] Button#Button closeButton

---
-- Field title
--
-- @field [parent=#FileSelector] #string title

---
-- Field path
--
-- @field [parent=#FileSelector] #string path

---
-- Field fileName
--
-- @field [parent=#FileSelector] #string fileName

---
-- Field filter (Read only)
--
-- @field [parent=#FileSelector] #string filter

---
-- Field filterIndex (Read only)
--
-- @field [parent=#FileSelector] #number filterIndex

---
-- Field directoryMode
--
-- @field [parent=#FileSelector] #boolean directoryMode


return nil
