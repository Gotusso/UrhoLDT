---
-- Module FileSelector
-- Extends Object
--
-- @module FileSelector

---
-- Function FileSelector
--
-- @function [parent=#FileSelector] FileSelector

---
-- Function new
--
-- @function [parent=#FileSelector] new
-- @return FileSelector#FileSelector

---
-- Function delete
--
-- @function [parent=#FileSelector] delete

---
-- Function SetDefaultStyle
--
-- @function [parent=#FileSelector] SetDefaultStyle
-- @param XMLFile#XMLFile stylestyle

---
-- Function SetTitle
--
-- @function [parent=#FileSelector] SetTitle
-- @param #string texttext

---
-- Function SetButtonTexts
--
-- @function [parent=#FileSelector] SetButtonTexts
-- @param #string okTextokText
-- @param #string cancelTextcancelText

---
-- Function SetPath
--
-- @function [parent=#FileSelector] SetPath
-- @param #string pathpath

---
-- Function SetFileName
--
-- @function [parent=#FileSelector] SetFileName
-- @param #string fileNamefileName

---
-- Function SetFilters
--
-- @function [parent=#FileSelector] SetFilters
-- @param Vector<String>#Vector<String> filtersfilters
-- @param #number defaultIndexdefaultIndex

---
-- Function SetDirectoryMode
--
-- @function [parent=#FileSelector] SetDirectoryMode
-- @param #boolean enableenable

---
-- Function UpdateElements
--
-- @function [parent=#FileSelector] UpdateElements

---
-- Function GetDefaultStyle
--
-- @function [parent=#FileSelector] GetDefaultStyle
-- @return XMLFile#XMLFile

---
-- Function GetWindow
--
-- @function [parent=#FileSelector] GetWindow
-- @return Window#Window

---
-- Function GetTitleText
--
-- @function [parent=#FileSelector] GetTitleText
-- @return Text#Text

---
-- Function GetFileList
--
-- @function [parent=#FileSelector] GetFileList
-- @return ListView#ListView

---
-- Function GetPathEdit
--
-- @function [parent=#FileSelector] GetPathEdit
-- @return LineEdit#LineEdit

---
-- Function GetFileNameEdit
--
-- @function [parent=#FileSelector] GetFileNameEdit
-- @return LineEdit#LineEdit

---
-- Function GetFilterList
--
-- @function [parent=#FileSelector] GetFilterList
-- @return DropDownList#DropDownList

---
-- Function GetOKButton
--
-- @function [parent=#FileSelector] GetOKButton
-- @return Button#Button

---
-- Function GetCancelButton
--
-- @function [parent=#FileSelector] GetCancelButton
-- @return Button#Button

---
-- Function GetCloseButton
--
-- @function [parent=#FileSelector] GetCloseButton
-- @return Button#Button

---
-- Function GetTitle
--
-- @function [parent=#FileSelector] GetTitle
-- @return const String#const String

---
-- Function GetPath
--
-- @function [parent=#FileSelector] GetPath
-- @return const String#const String

---
-- Function GetFileName
--
-- @function [parent=#FileSelector] GetFileName
-- @return const String#const String

---
-- Function GetFilter
--
-- @function [parent=#FileSelector] GetFilter
-- @return const String#const String

---
-- Function GetFilterIndex
--
-- @function [parent=#FileSelector] GetFilterIndex
-- @return #number

---
-- Function GetDirectoryMode
--
-- @function [parent=#FileSelector] GetDirectoryMode
-- @return #boolean

---
-- Field defaultStyle
--
-- @field [parent=#FileSelector] XMLFile#XMLFile defaultStyle

---
-- Field window (Read only)
--
-- @field [parent=#FileSelector] Window#Window window

---
-- Field titleText (Read only)
--
-- @field [parent=#FileSelector] Text#Text titleText

---
-- Field fileList (Read only)
--
-- @field [parent=#FileSelector] ListView#ListView fileList

---
-- Field pathEdit (Read only)
--
-- @field [parent=#FileSelector] LineEdit#LineEdit pathEdit

---
-- Field fileNameEdit (Read only)
--
-- @field [parent=#FileSelector] LineEdit#LineEdit fileNameEdit

---
-- Field filterList (Read only)
--
-- @field [parent=#FileSelector] DropDownList#DropDownList filterList

---
-- Field OKButton (Read only)
--
-- @field [parent=#FileSelector] Button#Button OKButton

---
-- Field cancelButton (Read only)
--
-- @field [parent=#FileSelector] Button#Button cancelButton

---
-- Field closeButton (Read only)
--
-- @field [parent=#FileSelector] Button#Button closeButton

---
-- Field title
--
-- @field [parent=#FileSelector] #string title

---
-- Field path
--
-- @field [parent=#FileSelector] #string path

---
-- Field fileName
--
-- @field [parent=#FileSelector] #string fileName

---
-- Field filter (Read only)
--
-- @field [parent=#FileSelector] #string filter

---
-- Field filterIndex (Read only)
--
-- @field [parent=#FileSelector] #number filterIndex

---
-- Field directoryMode
--
-- @field [parent=#FileSelector] #boolean directoryMode


return nil
