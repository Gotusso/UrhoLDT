---
-- Module FileSelector
-- Module FileSelector extends Object
-- Generated on 2014-03-13
--
-- @module FileSelector

---
-- Function FileSelector
--
-- @function [parent=#FileSelector] FileSelector
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#FileSelector] new
-- @param self Self reference
-- @return FileSelector#FileSelector

---
-- Function delete
--
-- @function [parent=#FileSelector] delete
-- @param self Self reference

---
-- Function SetDefaultStyle
--
-- @function [parent=#FileSelector] SetDefaultStyle
-- @param self Self reference
-- @param XMLFile#XMLFile style style

---
-- Function SetTitle
--
-- @function [parent=#FileSelector] SetTitle
-- @param self Self reference
-- @param #string text text

---
-- Function SetButtonTexts
--
-- @function [parent=#FileSelector] SetButtonTexts
-- @param self Self reference
-- @param #string okText okText
-- @param #string cancelText cancelText

---
-- Function SetPath
--
-- @function [parent=#FileSelector] SetPath
-- @param self Self reference
-- @param #string path path

---
-- Function SetFileName
--
-- @function [parent=#FileSelector] SetFileName
-- @param self Self reference
-- @param #string fileName fileName

---
-- Function SetFilters
--
-- @function [parent=#FileSelector] SetFilters
-- @param self Self reference
-- @param Vector<String>#Vector<String> filters filters
-- @param #number defaultIndex defaultIndex

---
-- Function SetDirectoryMode
--
-- @function [parent=#FileSelector] SetDirectoryMode
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function UpdateElements
--
-- @function [parent=#FileSelector] UpdateElements
-- @param self Self reference

---
-- Function GetDefaultStyle
--
-- @function [parent=#FileSelector] GetDefaultStyle
-- @param self Self reference
-- @return XMLFile#XMLFile

---
-- Function GetWindow
--
-- @function [parent=#FileSelector] GetWindow
-- @param self Self reference
-- @return Window#Window

---
-- Function GetTitleText
--
-- @function [parent=#FileSelector] GetTitleText
-- @param self Self reference
-- @return Text#Text

---
-- Function GetFileList
--
-- @function [parent=#FileSelector] GetFileList
-- @param self Self reference
-- @return ListView#ListView

---
-- Function GetPathEdit
--
-- @function [parent=#FileSelector] GetPathEdit
-- @param self Self reference
-- @return LineEdit#LineEdit

---
-- Function GetFileNameEdit
--
-- @function [parent=#FileSelector] GetFileNameEdit
-- @param self Self reference
-- @return LineEdit#LineEdit

---
-- Function GetFilterList
--
-- @function [parent=#FileSelector] GetFilterList
-- @param self Self reference
-- @return DropDownList#DropDownList

---
-- Function GetOKButton
--
-- @function [parent=#FileSelector] GetOKButton
-- @param self Self reference
-- @return Button#Button

---
-- Function GetCancelButton
--
-- @function [parent=#FileSelector] GetCancelButton
-- @param self Self reference
-- @return Button#Button

---
-- Function GetCloseButton
--
-- @function [parent=#FileSelector] GetCloseButton
-- @param self Self reference
-- @return Button#Button

---
-- Function GetTitle
--
-- @function [parent=#FileSelector] GetTitle
-- @param self Self reference
-- @return const String#const String

---
-- Function GetPath
--
-- @function [parent=#FileSelector] GetPath
-- @param self Self reference
-- @return const String#const String

---
-- Function GetFileName
--
-- @function [parent=#FileSelector] GetFileName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetFilter
--
-- @function [parent=#FileSelector] GetFilter
-- @param self Self reference
-- @return const String#const String

---
-- Function GetFilterIndex
--
-- @function [parent=#FileSelector] GetFilterIndex
-- @param self Self reference
-- @return #number

---
-- Function GetDirectoryMode
--
-- @function [parent=#FileSelector] GetDirectoryMode
-- @param self Self reference
-- @return #boolean

---
-- Field defaultStyle
--
-- @field [parent=#FileSelector] XMLFile#XMLFile defaultStyle

---
-- Field window (Read only)
--
-- @field [parent=#FileSelector] Window#Window window

---
-- Field titleText (Read only)
--
-- @field [parent=#FileSelector] Text#Text titleText

---
-- Field fileList (Read only)
--
-- @field [parent=#FileSelector] ListView#ListView fileList

---
-- Field pathEdit (Read only)
--
-- @field [parent=#FileSelector] LineEdit#LineEdit pathEdit

---
-- Field fileNameEdit (Read only)
--
-- @field [parent=#FileSelector] LineEdit#LineEdit fileNameEdit

---
-- Field filterList (Read only)
--
-- @field [parent=#FileSelector] DropDownList#DropDownList filterList

---
-- Field OKButton (Read only)
--
-- @field [parent=#FileSelector] Button#Button OKButton

---
-- Field cancelButton (Read only)
--
-- @field [parent=#FileSelector] Button#Button cancelButton

---
-- Field closeButton (Read only)
--
-- @field [parent=#FileSelector] Button#Button closeButton

---
-- Field title
--
-- @field [parent=#FileSelector] #string title

---
-- Field path
--
-- @field [parent=#FileSelector] #string path

---
-- Field fileName
--
-- @field [parent=#FileSelector] #string fileName

---
-- Field filter (Read only)
--
-- @field [parent=#FileSelector] #string filter

---
-- Field filterIndex (Read only)
--
-- @field [parent=#FileSelector] #number filterIndex

---
-- Field directoryMode
--
-- @field [parent=#FileSelector] #boolean directoryMode

---
-- Function GetType
--
-- @function [parent=#FileSelector] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#FileSelector] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#FileSelector] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#FileSelector] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#FileSelector] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#FileSelector] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#FileSelector] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#FileSelector] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#FileSelector] #string category


return nil
