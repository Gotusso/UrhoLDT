---
-- Enumeration TextureUnit
--
-- @module TextureUnit

---
-- Enumeration value TU_DIFFUSE
--
-- @field [parent=#TextureUnit] #number TU_DIFFUSE

---
-- Enumeration value TU_ALBEDOBUFFER
--
-- @field [parent=#TextureUnit] #number TU_ALBEDOBUFFER

---
-- Enumeration value TU_NORMAL
--
-- @field [parent=#TextureUnit] #number TU_NORMAL

---
-- Enumeration value TU_NORMALBUFFER
--
-- @field [parent=#TextureUnit] #number TU_NORMALBUFFER

---
-- Enumeration value TU_SPECULAR
--
-- @field [parent=#TextureUnit] #number TU_SPECULAR

---
-- Enumeration value TU_EMISSIVE
--
-- @field [parent=#TextureUnit] #number TU_EMISSIVE

---
-- Enumeration value TU_ENVIRONMENT
--
-- @field [parent=#TextureUnit] #number TU_ENVIRONMENT

---
-- Enumeration value MAX_MATERIAL_TEXTURE_UNITS
--
-- @field [parent=#TextureUnit] #number MAX_MATERIAL_TEXTURE_UNITS

---
-- Enumeration value TU_LIGHTRAMP
--
-- @field [parent=#TextureUnit] #number TU_LIGHTRAMP

---
-- Enumeration value TU_LIGHTSHAPE
--
-- @field [parent=#TextureUnit] #number TU_LIGHTSHAPE

---
-- Enumeration value TU_SHADOWMAP
--
-- @field [parent=#TextureUnit] #number TU_SHADOWMAP

---
-- Enumeration value TU_FACESELECT
--
-- @field [parent=#TextureUnit] #number TU_FACESELECT

---
-- Enumeration value TU_INDIRECTION
--
-- @field [parent=#TextureUnit] #number TU_INDIRECTION

---
-- Enumeration value TU_DEPTHBUFFER
--
-- @field [parent=#TextureUnit] #number TU_DEPTHBUFFER

---
-- Enumeration value TU_LIGHTBUFFER
--
-- @field [parent=#TextureUnit] #number TU_LIGHTBUFFER

---
-- Enumeration value TU_VOLUMEMAP
--
-- @field [parent=#TextureUnit] #number TU_VOLUMEMAP

---
-- Enumeration value MAX_TEXTURE_UNITS
--
-- @field [parent=#TextureUnit] #number MAX_TEXTURE_UNITS


return nil
