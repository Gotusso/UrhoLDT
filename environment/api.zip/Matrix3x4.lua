---
-- Module Matrix3x4
-- Generated on 2014-05-31
--
-- @module Matrix3x4

---
-- Function Matrix3x4()
-- Construct an identity matrix.
--
-- @function [parent=#Matrix3x4] Matrix3x4
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#Matrix3x4] new
-- @param self Self reference
-- @return Matrix3x4#Matrix3x4

---
-- Function Matrix3x4()
--
-- @function [parent=#Matrix3x4] Matrix3x4
-- @param self Self reference
-- @param Matrix3x4#Matrix3x4 matrix matrix

---
-- Function new()
--
-- @function [parent=#Matrix3x4] new
-- @param self Self reference
-- @param Matrix3x4#Matrix3x4 matrix matrix
-- @return Matrix3x4#Matrix3x4

---
-- Function Matrix3x4()
--
-- @function [parent=#Matrix3x4] Matrix3x4
-- @param self Self reference
-- @param Matrix3#Matrix3 matrix matrix

---
-- Function new()
--
-- @function [parent=#Matrix3x4] new
-- @param self Self reference
-- @param Matrix3#Matrix3 matrix matrix
-- @return Matrix3x4#Matrix3x4

---
-- Function Matrix3x4()
--
-- @function [parent=#Matrix3x4] Matrix3x4
-- @param self Self reference
-- @param Matrix4#Matrix4 matrix matrix

---
-- Function new()
--
-- @function [parent=#Matrix3x4] new
-- @param self Self reference
-- @param Matrix4#Matrix4 matrix matrix
-- @return Matrix3x4#Matrix3x4

---
-- Function Matrix3x4()
--
-- @function [parent=#Matrix3x4] Matrix3x4
-- @param self Self reference
-- @param #number v00 v00
-- @param #number v01 v01
-- @param #number v02 v02
-- @param #number v03 v03
-- @param #number v10 v10
-- @param #number v11 v11
-- @param #number v12 v12
-- @param #number v13 v13
-- @param #number v20 v20
-- @param #number v21 v21
-- @param #number v22 v22
-- @param #number v23 v23

---
-- Function new()
--
-- @function [parent=#Matrix3x4] new
-- @param self Self reference
-- @param #number v00 v00
-- @param #number v01 v01
-- @param #number v02 v02
-- @param #number v03 v03
-- @param #number v10 v10
-- @param #number v11 v11
-- @param #number v12 v12
-- @param #number v13 v13
-- @param #number v20 v20
-- @param #number v21 v21
-- @param #number v22 v22
-- @param #number v23 v23
-- @return Matrix3x4#Matrix3x4

---
-- Function Matrix3x4()
--
-- @function [parent=#Matrix3x4] Matrix3x4
-- @param self Self reference
-- @param Vector3#Vector3 translation translation
-- @param Quaternion#Quaternion rotation rotation
-- @param #number scale scale

---
-- Function new()
--
-- @function [parent=#Matrix3x4] new
-- @param self Self reference
-- @param Vector3#Vector3 translation translation
-- @param Quaternion#Quaternion rotation rotation
-- @param #number scale scale
-- @return Matrix3x4#Matrix3x4

---
-- Function Matrix3x4()
--
-- @function [parent=#Matrix3x4] Matrix3x4
-- @param self Self reference
-- @param Vector3#Vector3 translation translation
-- @param Quaternion#Quaternion rotation rotation
-- @param Vector3#Vector3 scale scale

---
-- Function new()
--
-- @function [parent=#Matrix3x4] new
-- @param self Self reference
-- @param Vector3#Vector3 translation translation
-- @param Quaternion#Quaternion rotation rotation
-- @param Vector3#Vector3 scale scale
-- @return Matrix3x4#Matrix3x4

---
-- Function delete()
--
-- @function [parent=#Matrix3x4] delete
-- @param self Self reference

---
-- Function operator==()
--
-- @function [parent=#Matrix3x4] operator==
-- @param self Self reference
-- @param Matrix3x4#Matrix3x4 rhs rhs
-- @return #boolean

---
-- Function operator*()
--
-- @function [parent=#Matrix3x4] operator*
-- @param self Self reference
-- @param Vector3#Vector3 rhs rhs
-- @return Vector3#Vector3

---
-- Function operator*()
--
-- @function [parent=#Matrix3x4] operator*
-- @param self Self reference
-- @param Vector4#Vector4 rhs rhs
-- @return Vector3#Vector3

---
-- Function operator+()
--
-- @function [parent=#Matrix3x4] operator+
-- @param self Self reference
-- @param Matrix3x4#Matrix3x4 rhs rhs
-- @return Matrix3x4#Matrix3x4

---
-- Function operator-()
--
-- @function [parent=#Matrix3x4] operator-
-- @param self Self reference
-- @param Matrix3x4#Matrix3x4 rhs rhs
-- @return Matrix3x4#Matrix3x4

---
-- Function operator*()
--
-- @function [parent=#Matrix3x4] operator*
-- @param self Self reference
-- @param #number rhs rhs
-- @return Matrix3x4#Matrix3x4

---
-- Function operator*()
--
-- @function [parent=#Matrix3x4] operator*
-- @param self Self reference
-- @param Matrix3x4#Matrix3x4 rhs rhs
-- @return Matrix3x4#Matrix3x4

---
-- Function operator*()
--
-- @function [parent=#Matrix3x4] operator*
-- @param self Self reference
-- @param Matrix4#Matrix4 rhs rhs
-- @return Matrix4#Matrix4

---
-- Function SetTranslation()
--
-- @function [parent=#Matrix3x4] SetTranslation
-- @param self Self reference
-- @param Vector3#Vector3 translation translation

---
-- Function SetRotation()
--
-- @function [parent=#Matrix3x4] SetRotation
-- @param self Self reference
-- @param Matrix3#Matrix3 rotation rotation

---
-- Function SetScale()
--
-- @function [parent=#Matrix3x4] SetScale
-- @param self Self reference
-- @param Vector3#Vector3 scale scale

---
-- Function SetScale()
--
-- @function [parent=#Matrix3x4] SetScale
-- @param self Self reference
-- @param #number scale scale

---
-- Function ToMatrix3()
--
-- @function [parent=#Matrix3x4] ToMatrix3
-- @param self Self reference
-- @return Matrix3#Matrix3

---
-- Function ToMatrix4()
--
-- @function [parent=#Matrix3x4] ToMatrix4
-- @param self Self reference
-- @return Matrix4#Matrix4

---
-- Function RotationMatrix()
--
-- @function [parent=#Matrix3x4] RotationMatrix
-- @param self Self reference
-- @return Matrix3#Matrix3

---
-- Function Translation()
--
-- @function [parent=#Matrix3x4] Translation
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function Rotation()
--
-- @function [parent=#Matrix3x4] Rotation
-- @param self Self reference
-- @return Quaternion#Quaternion

---
-- Function Scale()
--
-- @function [parent=#Matrix3x4] Scale
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function Equals()
--
-- @function [parent=#Matrix3x4] Equals
-- @param self Self reference
-- @param Matrix3x4#Matrix3x4 rhs rhs
-- @return #boolean

---
-- Function Decompose()
--
-- @function [parent=#Matrix3x4] Decompose
-- @param self Self reference
-- @param Vector3#Vector3 translation translation
-- @param Quaternion#Quaternion rotation rotation
-- @param Vector3#Vector3 scale scale

---
-- Function Inverse()
--
-- @function [parent=#Matrix3x4] Inverse
-- @param self Self reference
-- @return Matrix3x4#Matrix3x4

---
-- Function ToString()
--
-- @function [parent=#Matrix3x4] ToString
-- @param self Self reference
-- @return #string

---
-- Field m00
--
-- @field [parent=#Matrix3x4] #number m00

---
-- Field m01
--
-- @field [parent=#Matrix3x4] #number m01

---
-- Field m02
--
-- @field [parent=#Matrix3x4] #number m02

---
-- Field m03
--
-- @field [parent=#Matrix3x4] #number m03

---
-- Field m10
--
-- @field [parent=#Matrix3x4] #number m10

---
-- Field m11
--
-- @field [parent=#Matrix3x4] #number m11

---
-- Field m12
--
-- @field [parent=#Matrix3x4] #number m12

---
-- Field m13
--
-- @field [parent=#Matrix3x4] #number m13

---
-- Field m20
--
-- @field [parent=#Matrix3x4] #number m20

---
-- Field m21
--
-- @field [parent=#Matrix3x4] #number m21

---
-- Field m22
--
-- @field [parent=#Matrix3x4] #number m22

---
-- Field m23
--
-- @field [parent=#Matrix3x4] #number m23

---
-- Field ZERO
--
-- @field [parent=#Matrix3x4] Matrix3x4#Matrix3x4 ZERO

---
-- Field IDENTITY
--
-- @field [parent=#Matrix3x4] Matrix3x4#Matrix3x4 IDENTITY


return nil
