---
-- Module Matrix3x4
--
-- @module Matrix3x4

---
-- Function Matrix3x4
--
-- @function [parent=#Matrix3x4] Matrix3x4

---
-- Function new
--
-- @function [parent=#Matrix3x4] new
-- @return Matrix3x4#Matrix3x4

---
-- Function Matrix3x4
--
-- @function [parent=#Matrix3x4] Matrix3x4
-- @param Matrix3x4#Matrix3x4 matrixmatrix

---
-- Function new
--
-- @function [parent=#Matrix3x4] new
-- @param Matrix3x4#Matrix3x4 matrixmatrix
-- @return Matrix3x4#Matrix3x4

---
-- Function Matrix3x4
--
-- @function [parent=#Matrix3x4] Matrix3x4
-- @param Matrix3#Matrix3 matrixmatrix

---
-- Function new
--
-- @function [parent=#Matrix3x4] new
-- @param Matrix3#Matrix3 matrixmatrix
-- @return Matrix3x4#Matrix3x4

---
-- Function Matrix3x4
--
-- @function [parent=#Matrix3x4] Matrix3x4
-- @param Matrix4#Matrix4 matrixmatrix

---
-- Function new
--
-- @function [parent=#Matrix3x4] new
-- @param Matrix4#Matrix4 matrixmatrix
-- @return Matrix3x4#Matrix3x4

---
-- Function Matrix3x4
--
-- @function [parent=#Matrix3x4] Matrix3x4
-- @param #number v00v00
-- @param #number v01v01
-- @param #number v02v02
-- @param #number v03v03
-- @param #number v10v10
-- @param #number v11v11
-- @param #number v12v12
-- @param #number v13v13
-- @param #number v20v20
-- @param #number v21v21
-- @param #number v22v22
-- @param #number v23v23

---
-- Function new
--
-- @function [parent=#Matrix3x4] new
-- @param #number v00v00
-- @param #number v01v01
-- @param #number v02v02
-- @param #number v03v03
-- @param #number v10v10
-- @param #number v11v11
-- @param #number v12v12
-- @param #number v13v13
-- @param #number v20v20
-- @param #number v21v21
-- @param #number v22v22
-- @param #number v23v23
-- @return Matrix3x4#Matrix3x4

---
-- Function Matrix3x4
--
-- @function [parent=#Matrix3x4] Matrix3x4
-- @param Vector3#Vector3 translationtranslation
-- @param Quaternion#Quaternion rotationrotation
-- @param #number scalescale

---
-- Function new
--
-- @function [parent=#Matrix3x4] new
-- @param Vector3#Vector3 translationtranslation
-- @param Quaternion#Quaternion rotationrotation
-- @param #number scalescale
-- @return Matrix3x4#Matrix3x4

---
-- Function Matrix3x4
--
-- @function [parent=#Matrix3x4] Matrix3x4
-- @param Vector3#Vector3 translationtranslation
-- @param Quaternion#Quaternion rotationrotation
-- @param Vector3#Vector3 scalescale

---
-- Function new
--
-- @function [parent=#Matrix3x4] new
-- @param Vector3#Vector3 translationtranslation
-- @param Quaternion#Quaternion rotationrotation
-- @param Vector3#Vector3 scalescale
-- @return Matrix3x4#Matrix3x4

---
-- Function delete
--
-- @function [parent=#Matrix3x4] delete

---
-- Function operator==
--
-- @function [parent=#Matrix3x4] operator==
-- @param Matrix3x4#Matrix3x4 rhsrhs
-- @return #boolean

---
-- Function operator*
--
-- @function [parent=#Matrix3x4] operator*
-- @param Vector3#Vector3 rhsrhs
-- @return Vector3#Vector3

---
-- Function operator*
--
-- @function [parent=#Matrix3x4] operator*
-- @param Vector4#Vector4 rhsrhs
-- @return Vector3#Vector3

---
-- Function operator+
--
-- @function [parent=#Matrix3x4] operator+
-- @param Matrix3x4#Matrix3x4 rhsrhs
-- @return Matrix3x4#Matrix3x4

---
-- Function operator-
--
-- @function [parent=#Matrix3x4] operator-
-- @param Matrix3x4#Matrix3x4 rhsrhs
-- @return Matrix3x4#Matrix3x4

---
-- Function operator*
--
-- @function [parent=#Matrix3x4] operator*
-- @param #number rhsrhs
-- @return Matrix3x4#Matrix3x4

---
-- Function operator*
--
-- @function [parent=#Matrix3x4] operator*
-- @param Matrix3x4#Matrix3x4 rhsrhs
-- @return Matrix3x4#Matrix3x4

---
-- Function operator*
--
-- @function [parent=#Matrix3x4] operator*
-- @param Matrix4#Matrix4 rhsrhs
-- @return Matrix4#Matrix4

---
-- Function SetTranslation
--
-- @function [parent=#Matrix3x4] SetTranslation
-- @param Vector3#Vector3 translationtranslation

---
-- Function SetRotation
--
-- @function [parent=#Matrix3x4] SetRotation
-- @param Matrix3#Matrix3 rotationrotation

---
-- Function SetScale
--
-- @function [parent=#Matrix3x4] SetScale
-- @param Vector3#Vector3 scalescale

---
-- Function SetScale
--
-- @function [parent=#Matrix3x4] SetScale
-- @param #number scalescale

---
-- Function ToMatrix3
--
-- @function [parent=#Matrix3x4] ToMatrix3
-- @return Matrix3#Matrix3

---
-- Function ToMatrix4
--
-- @function [parent=#Matrix3x4] ToMatrix4
-- @return Matrix4#Matrix4

---
-- Function RotationMatrix
--
-- @function [parent=#Matrix3x4] RotationMatrix
-- @return Matrix3#Matrix3

---
-- Function Translation
--
-- @function [parent=#Matrix3x4] Translation
-- @return Vector3#Vector3

---
-- Function Rotation
--
-- @function [parent=#Matrix3x4] Rotation
-- @return Quaternion#Quaternion

---
-- Function Scale
--
-- @function [parent=#Matrix3x4] Scale
-- @return Vector3#Vector3

---
-- Function Equals
--
-- @function [parent=#Matrix3x4] Equals
-- @param Matrix3x4#Matrix3x4 rhsrhs
-- @return #boolean

---
-- Function Decompose
--
-- @function [parent=#Matrix3x4] Decompose
-- @param Vector3#Vector3 translationtranslation
-- @param Quaternion#Quaternion rotationrotation
-- @param Vector3#Vector3 scalescale

---
-- Function Inverse
--
-- @function [parent=#Matrix3x4] Inverse
-- @return Matrix3x4#Matrix3x4

---
-- Field m00
--
-- @field [parent=#Matrix3x4] #number m00

---
-- Field m01
--
-- @field [parent=#Matrix3x4] #number m01

---
-- Field m02
--
-- @field [parent=#Matrix3x4] #number m02

---
-- Field m03
--
-- @field [parent=#Matrix3x4] #number m03

---
-- Field m10
--
-- @field [parent=#Matrix3x4] #number m10

---
-- Field m11
--
-- @field [parent=#Matrix3x4] #number m11

---
-- Field m12
--
-- @field [parent=#Matrix3x4] #number m12

---
-- Field m13
--
-- @field [parent=#Matrix3x4] #number m13

---
-- Field m20
--
-- @field [parent=#Matrix3x4] #number m20

---
-- Field m21
--
-- @field [parent=#Matrix3x4] #number m21

---
-- Field m22
--
-- @field [parent=#Matrix3x4] #number m22

---
-- Field m23
--
-- @field [parent=#Matrix3x4] #number m23

---
-- Field ZERO
--
-- @field [parent=#Matrix3x4] Matrix3x4#Matrix3x4 ZERO

---
-- Field IDENTITY
--
-- @field [parent=#Matrix3x4] Matrix3x4#Matrix3x4 IDENTITY


return nil
