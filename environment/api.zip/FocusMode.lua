---
-- Enumeration FocusMode
--
-- @module FocusMode

---
-- Enumeration value FM_NOTFOCUSABLE
--
-- @field [parent=#FocusMode] #number FM_NOTFOCUSABLE

---
-- Enumeration value FM_RESETFOCUS
--
-- @field [parent=#FocusMode] #number FM_RESETFOCUS

---
-- Enumeration value FM_FOCUSABLE
--
-- @field [parent=#FocusMode] #number FM_FOCUSABLE

---
-- Enumeration value FM_FOCUSABLE_DEFOCUSABLE
--
-- @field [parent=#FocusMode] #number FM_FOCUSABLE_DEFOCUSABLE


return nil
