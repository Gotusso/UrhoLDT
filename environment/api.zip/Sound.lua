---
-- Module Sound
-- extends Resource
--
-- @module Sound

---
-- Function Sound
--
-- @function [parent=#Sound] Sound

---
-- Function new
--
-- @function [parent=#Sound] new
-- @return Sound#Sound

---
-- Function delete
--
-- @function [parent=#Sound] delete

---
-- Function LoadRaw
--
-- @function [parent=#Sound] LoadRaw
-- @param Deserializer#Deserializer sourcesource
-- @return #boolean

---
-- Function LoadWav
--
-- @function [parent=#Sound] LoadWav
-- @param Deserializer#Deserializer sourcesource
-- @return #boolean

---
-- Function LoadOggVorbis
--
-- @function [parent=#Sound] LoadOggVorbis
-- @param Deserializer#Deserializer sourcesource
-- @return #boolean

---
-- Function LoadRaw
--
-- @function [parent=#Sound] LoadRaw
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function LoadWav
--
-- @function [parent=#Sound] LoadWav
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function LoadOggVorbis
--
-- @function [parent=#Sound] LoadOggVorbis
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function SetSize
--
-- @function [parent=#Sound] SetSize
-- @param #number dataSizedataSize

---
-- Function SetData
--
-- @function [parent=#Sound] SetData
-- @param void*#void* datadata
-- @param #number dataSizedataSize

---
-- Function SetFormat
--
-- @function [parent=#Sound] SetFormat
-- @param #number frequencyfrequency
-- @param #boolean sixteenBitsixteenBit
-- @param #boolean stereostereo

---
-- Function SetLooped
--
-- @function [parent=#Sound] SetLooped
-- @param #boolean enableenable

---
-- Function SetLoop
--
-- @function [parent=#Sound] SetLoop
-- @param #number repeatOffsetrepeatOffset
-- @param #number endOffsetendOffset

---
-- Function FixInterpolation
--
-- @function [parent=#Sound] FixInterpolation

---
-- Function GetLength
--
-- @function [parent=#Sound] GetLength
-- @return #number

---
-- Function GetDataSize
--
-- @function [parent=#Sound] GetDataSize
-- @return #number

---
-- Function GetSampleSize
--
-- @function [parent=#Sound] GetSampleSize
-- @return #number

---
-- Function GetFrequency
--
-- @function [parent=#Sound] GetFrequency
-- @return #number

---
-- Function GetIntFrequency
--
-- @function [parent=#Sound] GetIntFrequency
-- @return #number

---
-- Function IsLooped
--
-- @function [parent=#Sound] IsLooped
-- @return #boolean

---
-- Function IsSixteenBit
--
-- @function [parent=#Sound] IsSixteenBit
-- @return #boolean

---
-- Function IsStereo
--
-- @function [parent=#Sound] IsStereo
-- @return #boolean

---
-- Function IsCompressed
--
-- @function [parent=#Sound] IsCompressed
-- @return #boolean

---
-- Field length (Read only)
--
-- @field [parent=#Sound] #number length

---
-- Field dataSize (Read only)
--
-- @field [parent=#Sound] #number dataSize

---
-- Field sampleSize (Read only)
--
-- @field [parent=#Sound] #number sampleSize

---
-- Field frequency (Read only)
--
-- @field [parent=#Sound] #number frequency

---
-- Field intFrequency (Read only)
--
-- @field [parent=#Sound] #number intFrequency

---
-- Field looped
--
-- @field [parent=#Sound] #boolean looped

---
-- Field sixteenBit (Read only)
--
-- @field [parent=#Sound] #boolean sixteenBit

---
-- Field stereo (Read only)
--
-- @field [parent=#Sound] #boolean stereo

---
-- Field compressed (Read only)
--
-- @field [parent=#Sound] #boolean compressed

---
-- Function Load
--
-- @function [parent=#Sound] Load
-- @param Deserializer#Deserializer sourcesource
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#Sound] Save
-- @param Serializer#Serializer destdest
-- @return #boolean

---
-- Function Load
--
-- @function [parent=#Sound] Load
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#Sound] Save
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function GetName
--
-- @function [parent=#Sound] GetName
-- @return const String#const String

---
-- Function GetNameHash
--
-- @function [parent=#Sound] GetNameHash
-- @return StringHash#StringHash

---
-- Function GetMemoryUse
--
-- @function [parent=#Sound] GetMemoryUse
-- @return #number

---
-- Field name (Read only)
--
-- @field [parent=#Sound] #string name

---
-- Field nameHash (Read only)
--
-- @field [parent=#Sound] StringHash#StringHash nameHash

---
-- Field memoryUse (Read only)
--
-- @field [parent=#Sound] #number memoryUse


return nil
