---
-- Module Sound
-- Module Sound extends Resource
-- Generated on 2014-05-31
--
-- @module Sound

---
-- Function Sound()
--
-- @function [parent=#Sound] Sound
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#Sound] new
-- @param self Self reference
-- @return Sound#Sound

---
-- Function delete()
--
-- @function [parent=#Sound] delete
-- @param self Self reference

---
-- Function LoadRaw()
-- Load raw sound data.
--
-- @function [parent=#Sound] LoadRaw
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @return #boolean

---
-- Function LoadWav()
-- Load WAV format sound data.
--
-- @function [parent=#Sound] LoadWav
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @return #boolean

---
-- Function LoadOggVorbis()
-- Load Ogg Vorbis format sound data. Does not decode at load, but will rather be decoded while playing.
--
-- @function [parent=#Sound] LoadOggVorbis
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @return #boolean

---
-- Function LoadRaw()
--
-- @function [parent=#Sound] LoadRaw
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function LoadWav()
--
-- @function [parent=#Sound] LoadWav
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function LoadOggVorbis()
--
-- @function [parent=#Sound] LoadOggVorbis
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function SetSize()
-- Set sound size in bytes. Also resets the sound to be uncompressed and one-shot.
--
-- @function [parent=#Sound] SetSize
-- @param self Self reference
-- @param #number dataSize dataSize

---
-- Function SetData()
--
-- @function [parent=#Sound] SetData
-- @param self Self reference
-- @param void*#void* data data
-- @param #number dataSize dataSize

---
-- Function SetFormat()
-- Set uncompressed sound data format.
--
-- @function [parent=#Sound] SetFormat
-- @param self Self reference
-- @param #number frequency frequency
-- @param #boolean sixteenBit sixteenBit
-- @param #boolean stereo stereo

---
-- Function SetLooped()
-- Set loop on/off. If loop is enabled, sets the full sound as loop range.
--
-- @function [parent=#Sound] SetLooped
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetLoop()
-- Define loop.
--
-- @function [parent=#Sound] SetLoop
-- @param self Self reference
-- @param #number repeatOffset repeatOffset
-- @param #number endOffset endOffset

---
-- Function FixInterpolation()
-- Fix interpolation by copying data from loop start to loop end (looped), or adding silence (oneshot.)
--
-- @function [parent=#Sound] FixInterpolation
-- @param self Self reference

---
-- Function GetLength()
-- Return length in seconds.
--
-- @function [parent=#Sound] GetLength
-- @param self Self reference
-- @return #number

---
-- Function GetDataSize()
-- Return total sound data size.
--
-- @function [parent=#Sound] GetDataSize
-- @param self Self reference
-- @return #number

---
-- Function GetSampleSize()
-- Return sample size.
--
-- @function [parent=#Sound] GetSampleSize
-- @param self Self reference
-- @return #number

---
-- Function GetFrequency()
--
-- @function [parent=#Sound] GetFrequency
-- @param self Self reference
-- @return #number

---
-- Function GetIntFrequency()
-- Return default frequency as an integer.
--
-- @function [parent=#Sound] GetIntFrequency
-- @param self Self reference
-- @return #number

---
-- Function IsLooped()
-- Return whether is looped.
--
-- @function [parent=#Sound] IsLooped
-- @param self Self reference
-- @return #boolean

---
-- Function IsSixteenBit()
-- Return whether data is sixteen bit.
--
-- @function [parent=#Sound] IsSixteenBit
-- @param self Self reference
-- @return #boolean

---
-- Function IsStereo()
-- Return whether data is stereo.
--
-- @function [parent=#Sound] IsStereo
-- @param self Self reference
-- @return #boolean

---
-- Function IsCompressed()
-- Return whether is compressed.
--
-- @function [parent=#Sound] IsCompressed
-- @param self Self reference
-- @return #boolean

---
-- Field length (Read only)
--
-- @field [parent=#Sound] #number length

---
-- Field dataSize (Read only)
--
-- @field [parent=#Sound] #number dataSize

---
-- Field sampleSize (Read only)
--
-- @field [parent=#Sound] #number sampleSize

---
-- Field frequency (Read only)
--
-- @field [parent=#Sound] #number frequency

---
-- Field intFrequency (Read only)
--
-- @field [parent=#Sound] #number intFrequency

---
-- Field looped
--
-- @field [parent=#Sound] #boolean looped

---
-- Field sixteenBit (Read only)
--
-- @field [parent=#Sound] #boolean sixteenBit

---
-- Field stereo (Read only)
--
-- @field [parent=#Sound] #boolean stereo

---
-- Field compressed (Read only)
--
-- @field [parent=#Sound] #boolean compressed


return nil
