---
-- Module Sound
-- Module Sound extends Resource
-- Generated on 2014-03-13
--
-- @module Sound

---
-- Function Sound
--
-- @function [parent=#Sound] Sound
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#Sound] new
-- @param self Self reference
-- @return Sound#Sound

---
-- Function delete
--
-- @function [parent=#Sound] delete
-- @param self Self reference

---
-- Function LoadRaw
--
-- @function [parent=#Sound] LoadRaw
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @return #boolean

---
-- Function LoadWav
--
-- @function [parent=#Sound] LoadWav
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @return #boolean

---
-- Function LoadOggVorbis
--
-- @function [parent=#Sound] LoadOggVorbis
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @return #boolean

---
-- Function LoadRaw
--
-- @function [parent=#Sound] LoadRaw
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function LoadWav
--
-- @function [parent=#Sound] LoadWav
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function LoadOggVorbis
--
-- @function [parent=#Sound] LoadOggVorbis
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function SetSize
--
-- @function [parent=#Sound] SetSize
-- @param self Self reference
-- @param #number dataSize dataSize

---
-- Function SetData
--
-- @function [parent=#Sound] SetData
-- @param self Self reference
-- @param void*#void* data data
-- @param #number dataSize dataSize

---
-- Function SetFormat
--
-- @function [parent=#Sound] SetFormat
-- @param self Self reference
-- @param #number frequency frequency
-- @param #boolean sixteenBit sixteenBit
-- @param #boolean stereo stereo

---
-- Function SetLooped
--
-- @function [parent=#Sound] SetLooped
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetLoop
--
-- @function [parent=#Sound] SetLoop
-- @param self Self reference
-- @param #number repeatOffset repeatOffset
-- @param #number endOffset endOffset

---
-- Function FixInterpolation
--
-- @function [parent=#Sound] FixInterpolation
-- @param self Self reference

---
-- Function GetLength
--
-- @function [parent=#Sound] GetLength
-- @param self Self reference
-- @return #number

---
-- Function GetDataSize
--
-- @function [parent=#Sound] GetDataSize
-- @param self Self reference
-- @return #number

---
-- Function GetSampleSize
--
-- @function [parent=#Sound] GetSampleSize
-- @param self Self reference
-- @return #number

---
-- Function GetFrequency
--
-- @function [parent=#Sound] GetFrequency
-- @param self Self reference
-- @return #number

---
-- Function GetIntFrequency
--
-- @function [parent=#Sound] GetIntFrequency
-- @param self Self reference
-- @return #number

---
-- Function IsLooped
--
-- @function [parent=#Sound] IsLooped
-- @param self Self reference
-- @return #boolean

---
-- Function IsSixteenBit
--
-- @function [parent=#Sound] IsSixteenBit
-- @param self Self reference
-- @return #boolean

---
-- Function IsStereo
--
-- @function [parent=#Sound] IsStereo
-- @param self Self reference
-- @return #boolean

---
-- Function IsCompressed
--
-- @function [parent=#Sound] IsCompressed
-- @param self Self reference
-- @return #boolean

---
-- Field length (Read only)
--
-- @field [parent=#Sound] #number length

---
-- Field dataSize (Read only)
--
-- @field [parent=#Sound] #number dataSize

---
-- Field sampleSize (Read only)
--
-- @field [parent=#Sound] #number sampleSize

---
-- Field frequency (Read only)
--
-- @field [parent=#Sound] #number frequency

---
-- Field intFrequency (Read only)
--
-- @field [parent=#Sound] #number intFrequency

---
-- Field looped
--
-- @field [parent=#Sound] #boolean looped

---
-- Field sixteenBit (Read only)
--
-- @field [parent=#Sound] #boolean sixteenBit

---
-- Field stereo (Read only)
--
-- @field [parent=#Sound] #boolean stereo

---
-- Field compressed (Read only)
--
-- @field [parent=#Sound] #boolean compressed

---
-- Function Load
--
-- @function [parent=#Sound] Load
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#Sound] Save
-- @param self Self reference
-- @param Serializer#Serializer dest dest
-- @return #boolean

---
-- Function Load
--
-- @function [parent=#Sound] Load
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#Sound] Save
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function GetName
--
-- @function [parent=#Sound] GetName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetNameHash
--
-- @function [parent=#Sound] GetNameHash
-- @param self Self reference
-- @return StringHash#StringHash

---
-- Function GetMemoryUse
--
-- @function [parent=#Sound] GetMemoryUse
-- @param self Self reference
-- @return #number

---
-- Field name (Read only)
--
-- @field [parent=#Sound] #string name

---
-- Field nameHash (Read only)
--
-- @field [parent=#Sound] StringHash#StringHash nameHash

---
-- Field memoryUse (Read only)
--
-- @field [parent=#Sound] #number memoryUse


return nil
