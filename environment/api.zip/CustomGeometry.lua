---
-- Module CustomGeometry
-- Module CustomGeometry extends Drawable
-- Generated on 2014-05-31
--
-- @module CustomGeometry

---
-- Function Clear()
-- Clear all geometries.
--
-- @function [parent=#CustomGeometry] Clear
-- @param self Self reference

---
-- Function SetNumGeometries()
-- Set number of geometries.
--
-- @function [parent=#CustomGeometry] SetNumGeometries
-- @param self Self reference
-- @param #number num num

---
-- Function BeginGeometry()
-- Begin defining a geometry. Clears existing geometry in that index.
--
-- @function [parent=#CustomGeometry] BeginGeometry
-- @param self Self reference
-- @param #number index index
-- @param PrimitiveType#PrimitiveType type type

---
-- Function DefineVertex()
-- Define a vertex position. This begins a new vertex.
--
-- @function [parent=#CustomGeometry] DefineVertex
-- @param self Self reference
-- @param Vector3#Vector3 position position

---
-- Function DefineNormal()
-- Define a vertex normal.
--
-- @function [parent=#CustomGeometry] DefineNormal
-- @param self Self reference
-- @param Vector3#Vector3 normal normal

---
-- Function DefineTangent()
-- Define a vertex tangent.
--
-- @function [parent=#CustomGeometry] DefineTangent
-- @param self Self reference
-- @param Vector4#Vector4 tangent tangent

---
-- Function DefineColor()
-- Define a vertex color.
--
-- @function [parent=#CustomGeometry] DefineColor
-- @param self Self reference
-- @param Color#Color color color

---
-- Function DefineTexCoord()
-- Define a vertex UV coordinate.
--
-- @function [parent=#CustomGeometry] DefineTexCoord
-- @param self Self reference
-- @param Vector2#Vector2 texCoord texCoord

---
-- Function Commit()
-- Update vertex buffer and calculate the bounding box. Call after finishing defining geometry.
--
-- @function [parent=#CustomGeometry] Commit
-- @param self Self reference

---
-- Function SetMaterial()
-- Set material on all geometries.
--
-- @function [parent=#CustomGeometry] SetMaterial
-- @param self Self reference
-- @param Material#Material material material

---
-- Function SetMaterial()
-- Set material on one geometry. Return true if successful.
--
-- @function [parent=#CustomGeometry] SetMaterial
-- @param self Self reference
-- @param #number index index
-- @param Material#Material material material
-- @return #boolean

---
-- Function GetNumGeometries()
-- Return number of geometries.
--
-- @function [parent=#CustomGeometry] GetNumGeometries
-- @param self Self reference
-- @return #number

---
-- Function GetMaterial()
-- Return material by geometry index.
--
-- @function [parent=#CustomGeometry] GetMaterial
-- @param self Self reference
-- @param #number index index
-- @return Material#Material

---
-- Field material
--
-- @field [parent=#CustomGeometry] Material#Material material

---
-- Field numGeometries
--
-- @field [parent=#CustomGeometry] #number numGeometries


return nil
