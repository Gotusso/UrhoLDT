---
-- Module ConstraintPrismatic2D
-- Module ConstraintPrismatic2D extends Constraint2D
-- Generated on 2014-05-31
--
-- @module ConstraintPrismatic2D

---
-- Function SetAnchor()
-- Set anchor.
--
-- @function [parent=#ConstraintPrismatic2D] SetAnchor
-- @param self Self reference
-- @param Vector2#Vector2 anchor anchor

---
-- Function SetAxis()
-- Set axis.
--
-- @function [parent=#ConstraintPrismatic2D] SetAxis
-- @param self Self reference
-- @param Vector2#Vector2 axis axis

---
-- Function SetEnableLimit()
-- Set enable limit.
--
-- @function [parent=#ConstraintPrismatic2D] SetEnableLimit
-- @param self Self reference
-- @param #boolean enableLimit enableLimit

---
-- Function SetLowerTranslation()
-- Set lower translation.
--
-- @function [parent=#ConstraintPrismatic2D] SetLowerTranslation
-- @param self Self reference
-- @param #number lowerTranslation lowerTranslation

---
-- Function SetUpperTranslation()
-- Set upper translation.
--
-- @function [parent=#ConstraintPrismatic2D] SetUpperTranslation
-- @param self Self reference
-- @param #number upperTranslation upperTranslation

---
-- Function SetEnableMotor()
-- Set enable motor.
--
-- @function [parent=#ConstraintPrismatic2D] SetEnableMotor
-- @param self Self reference
-- @param #boolean enableMotor enableMotor

---
-- Function SetMaxMotorForce()
-- Set maxmotor force.
--
-- @function [parent=#ConstraintPrismatic2D] SetMaxMotorForce
-- @param self Self reference
-- @param #number maxMotorForce maxMotorForce

---
-- Function SetMotorSpeed()
-- Set motor speed.
--
-- @function [parent=#ConstraintPrismatic2D] SetMotorSpeed
-- @param self Self reference
-- @param #number motorSpeed motorSpeed

---
-- Function GetAnchor()
-- Return anchor.
--
-- @function [parent=#ConstraintPrismatic2D] GetAnchor
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Function GetAxis()
-- Return axis.
--
-- @function [parent=#ConstraintPrismatic2D] GetAxis
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Function GetEnableLimit()
-- Return enable limit.
--
-- @function [parent=#ConstraintPrismatic2D] GetEnableLimit
-- @param self Self reference
-- @return #boolean

---
-- Function GetLowerTranslation()
-- Return lower translation.
--
-- @function [parent=#ConstraintPrismatic2D] GetLowerTranslation
-- @param self Self reference
-- @return #number

---
-- Function GetUpperTranslation()
-- Return upper translation.
--
-- @function [parent=#ConstraintPrismatic2D] GetUpperTranslation
-- @param self Self reference
-- @return #number

---
-- Function GetEnableMotor()
-- Return enable motor.
--
-- @function [parent=#ConstraintPrismatic2D] GetEnableMotor
-- @param self Self reference
-- @return #boolean

---
-- Function GetMaxMotorForce()
-- Return maxmotor force.
--
-- @function [parent=#ConstraintPrismatic2D] GetMaxMotorForce
-- @param self Self reference
-- @return #number

---
-- Function GetMotorSpeed()
-- Return motor speed.
--
-- @function [parent=#ConstraintPrismatic2D] GetMotorSpeed
-- @param self Self reference
-- @return #number

---
-- Field anchor
--
-- @field [parent=#ConstraintPrismatic2D] Vector2#Vector2 anchor

---
-- Field axis
--
-- @field [parent=#ConstraintPrismatic2D] Vector2#Vector2 axis

---
-- Field enableLimit
--
-- @field [parent=#ConstraintPrismatic2D] #boolean enableLimit

---
-- Field lowerTranslation
--
-- @field [parent=#ConstraintPrismatic2D] #number lowerTranslation

---
-- Field upperTranslation
--
-- @field [parent=#ConstraintPrismatic2D] #number upperTranslation

---
-- Field enableMotor
--
-- @field [parent=#ConstraintPrismatic2D] #boolean enableMotor

---
-- Field maxMotorForce
--
-- @field [parent=#ConstraintPrismatic2D] #number maxMotorForce

---
-- Field motorSpeed
--
-- @field [parent=#ConstraintPrismatic2D] #number motorSpeed


return nil
