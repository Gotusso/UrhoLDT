---
-- Module BillboardSet
-- Module BillboardSet extends Drawable
-- Generated on 2014-03-13
--
-- @module BillboardSet

---
-- Function SetMaterial
--
-- @function [parent=#BillboardSet] SetMaterial
-- @param self Self reference
-- @param Material#Material material material

---
-- Function SetNumBillboards
--
-- @function [parent=#BillboardSet] SetNumBillboards
-- @param self Self reference
-- @param #number num num

---
-- Function SetRelative
--
-- @function [parent=#BillboardSet] SetRelative
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetScaled
--
-- @function [parent=#BillboardSet] SetScaled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetSorted
--
-- @function [parent=#BillboardSet] SetSorted
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetFaceCamera
--
-- @function [parent=#BillboardSet] SetFaceCamera
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetAnimationLodBias
--
-- @function [parent=#BillboardSet] SetAnimationLodBias
-- @param self Self reference
-- @param #number bias bias

---
-- Function Commit
--
-- @function [parent=#BillboardSet] Commit
-- @param self Self reference

---
-- Function GetMaterial
--
-- @function [parent=#BillboardSet] GetMaterial
-- @param self Self reference
-- @return Material#Material

---
-- Function GetNumBillboards
--
-- @function [parent=#BillboardSet] GetNumBillboards
-- @param self Self reference
-- @return #number

---
-- Function GetBillboard
--
-- @function [parent=#BillboardSet] GetBillboard
-- @param self Self reference
-- @param #number index index
-- @return Billboard#Billboard

---
-- Function IsRelative
--
-- @function [parent=#BillboardSet] IsRelative
-- @param self Self reference
-- @return #boolean

---
-- Function IsScaled
--
-- @function [parent=#BillboardSet] IsScaled
-- @param self Self reference
-- @return #boolean

---
-- Function IsSorted
--
-- @function [parent=#BillboardSet] IsSorted
-- @param self Self reference
-- @return #boolean

---
-- Function GetFaceCamera
--
-- @function [parent=#BillboardSet] GetFaceCamera
-- @param self Self reference
-- @return #boolean

---
-- Function GetAnimationLodBias
--
-- @function [parent=#BillboardSet] GetAnimationLodBias
-- @param self Self reference
-- @return #number

---
-- Field material
--
-- @field [parent=#BillboardSet] Material#Material material

---
-- Field numBillboards
--
-- @field [parent=#BillboardSet] #number numBillboards

---
-- Field relative
--
-- @field [parent=#BillboardSet] #boolean relative

---
-- Field scaled
--
-- @field [parent=#BillboardSet] #boolean scaled

---
-- Field sorted
--
-- @field [parent=#BillboardSet] #boolean sorted

---
-- Field faceCamera
--
-- @field [parent=#BillboardSet] #boolean faceCamera

---
-- Field animationLodBias
--
-- @field [parent=#BillboardSet] #number animationLodBias

---
-- Function SetDrawDistance
--
-- @function [parent=#BillboardSet] SetDrawDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetShadowDistance
--
-- @function [parent=#BillboardSet] SetShadowDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetLodBias
--
-- @function [parent=#BillboardSet] SetLodBias
-- @param self Self reference
-- @param #number bias bias

---
-- Function SetViewMask
--
-- @function [parent=#BillboardSet] SetViewMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetLightMask
--
-- @function [parent=#BillboardSet] SetLightMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetShadowMask
--
-- @function [parent=#BillboardSet] SetShadowMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetZoneMask
--
-- @function [parent=#BillboardSet] SetZoneMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetMaxLights
--
-- @function [parent=#BillboardSet] SetMaxLights
-- @param self Self reference
-- @param #number num num

---
-- Function SetCastShadows
--
-- @function [parent=#BillboardSet] SetCastShadows
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetOccluder
--
-- @function [parent=#BillboardSet] SetOccluder
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetOccludee
--
-- @function [parent=#BillboardSet] SetOccludee
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function MarkForUpdate
--
-- @function [parent=#BillboardSet] MarkForUpdate
-- @param self Self reference

---
-- Function GetBoundingBox
--
-- @function [parent=#BillboardSet] GetBoundingBox
-- @param self Self reference
-- @return const BoundingBox#const BoundingBox

---
-- Function GetWorldBoundingBox
--
-- @function [parent=#BillboardSet] GetWorldBoundingBox
-- @param self Self reference
-- @return const BoundingBox#const BoundingBox

---
-- Function GetDrawableFlags
--
-- @function [parent=#BillboardSet] GetDrawableFlags
-- @param self Self reference
-- @return #string

---
-- Function GetDrawDistance
--
-- @function [parent=#BillboardSet] GetDrawDistance
-- @param self Self reference
-- @return #number

---
-- Function GetShadowDistance
--
-- @function [parent=#BillboardSet] GetShadowDistance
-- @param self Self reference
-- @return #number

---
-- Function GetLodBias
--
-- @function [parent=#BillboardSet] GetLodBias
-- @param self Self reference
-- @return #number

---
-- Function GetViewMask
--
-- @function [parent=#BillboardSet] GetViewMask
-- @param self Self reference
-- @return #number

---
-- Function GetLightMask
--
-- @function [parent=#BillboardSet] GetLightMask
-- @param self Self reference
-- @return #number

---
-- Function GetShadowMask
--
-- @function [parent=#BillboardSet] GetShadowMask
-- @param self Self reference
-- @return #number

---
-- Function GetZoneMask
--
-- @function [parent=#BillboardSet] GetZoneMask
-- @param self Self reference
-- @return #number

---
-- Function GetMaxLights
--
-- @function [parent=#BillboardSet] GetMaxLights
-- @param self Self reference
-- @return #number

---
-- Function GetCastShadows
--
-- @function [parent=#BillboardSet] GetCastShadows
-- @param self Self reference
-- @return #boolean

---
-- Function IsOccluder
--
-- @function [parent=#BillboardSet] IsOccluder
-- @param self Self reference
-- @return #boolean

---
-- Function IsOccludee
--
-- @function [parent=#BillboardSet] IsOccludee
-- @param self Self reference
-- @return #boolean

---
-- Function SetZone
--
-- @function [parent=#BillboardSet] SetZone
-- @param self Self reference
-- @param Zone#Zone zone zone
-- @param #boolean temporary temporary

---
-- Function SetSortValue
--
-- @function [parent=#BillboardSet] SetSortValue
-- @param self Self reference
-- @param #number value value

---
-- Function SetMinMaxZ
--
-- @function [parent=#BillboardSet] SetMinMaxZ
-- @param self Self reference
-- @param #number minZ minZ
-- @param #number maxZ maxZ

---
-- Function MarkInView
--
-- @function [parent=#BillboardSet] MarkInView
-- @param self Self reference
-- @param FrameInfo#FrameInfo frame frame
-- @param #boolean mainView mainView

---
-- Function ClearLights
--
-- @function [parent=#BillboardSet] ClearLights
-- @param self Self reference

---
-- Function AddLight
--
-- @function [parent=#BillboardSet] AddLight
-- @param self Self reference
-- @param Light#Light light light

---
-- Function AddVertexLight
--
-- @function [parent=#BillboardSet] AddVertexLight
-- @param self Self reference
-- @param Light#Light light light

---
-- Function LimitLights
--
-- @function [parent=#BillboardSet] LimitLights
-- @param self Self reference

---
-- Function LimitVertexLights
--
-- @function [parent=#BillboardSet] LimitVertexLights
-- @param self Self reference

---
-- Function SetBasePass
--
-- @function [parent=#BillboardSet] SetBasePass
-- @param self Self reference
-- @param #number batchIndex batchIndex

---
-- Function GetOctant
--
-- @function [parent=#BillboardSet] GetOctant
-- @param self Self reference
-- @return Octant#Octant

---
-- Function GetZone
--
-- @function [parent=#BillboardSet] GetZone
-- @param self Self reference
-- @return Zone#Zone

---
-- Function GetLastZone
--
-- @function [parent=#BillboardSet] GetLastZone
-- @param self Self reference
-- @return Zone#Zone

---
-- Function IsZoneDirty
--
-- @function [parent=#BillboardSet] IsZoneDirty
-- @param self Self reference
-- @return #boolean

---
-- Function GetDistance
--
-- @function [parent=#BillboardSet] GetDistance
-- @param self Self reference
-- @return #number

---
-- Function GetLodDistance
--
-- @function [parent=#BillboardSet] GetLodDistance
-- @param self Self reference
-- @return #number

---
-- Function GetSortValue
--
-- @function [parent=#BillboardSet] GetSortValue
-- @param self Self reference
-- @return #number

---
-- Function IsInView
--
-- @function [parent=#BillboardSet] IsInView
-- @param self Self reference
-- @param #number frameNumber frameNumber
-- @return #boolean

---
-- Function IsInView
--
-- @function [parent=#BillboardSet] IsInView
-- @param self Self reference
-- @param FrameInfo#FrameInfo frame frame
-- @param #boolean mainView mainView
-- @return #boolean

---
-- Function HasBasePass
--
-- @function [parent=#BillboardSet] HasBasePass
-- @param self Self reference
-- @param #number batchIndex batchIndex
-- @return #boolean

---
-- Function GetFirstLight
--
-- @function [parent=#BillboardSet] GetFirstLight
-- @param self Self reference
-- @return Light#Light

---
-- Function GetMinZ
--
-- @function [parent=#BillboardSet] GetMinZ
-- @param self Self reference
-- @return #number

---
-- Function GetMaxZ
--
-- @function [parent=#BillboardSet] GetMaxZ
-- @param self Self reference
-- @return #number

---
-- Field worldBoundingBox (Read only)
--
-- @field [parent=#BillboardSet] BoundingBox#BoundingBox worldBoundingBox

---
-- Field drawableFlags (Read only)
--
-- @field [parent=#BillboardSet] #string drawableFlags

---
-- Field drawDistance
--
-- @field [parent=#BillboardSet] #number drawDistance

---
-- Field shadowDistance
--
-- @field [parent=#BillboardSet] #number shadowDistance

---
-- Field lodBias
--
-- @field [parent=#BillboardSet] #number lodBias

---
-- Field viewMask
--
-- @field [parent=#BillboardSet] #number viewMask

---
-- Field lightMask
--
-- @field [parent=#BillboardSet] #number lightMask

---
-- Field shadowMask
--
-- @field [parent=#BillboardSet] #number shadowMask

---
-- Field zoneMask
--
-- @field [parent=#BillboardSet] #number zoneMask

---
-- Field maxLights
--
-- @field [parent=#BillboardSet] #number maxLights

---
-- Field castShadows
--
-- @field [parent=#BillboardSet] #boolean castShadows

---
-- Field occluder
--
-- @field [parent=#BillboardSet] #boolean occluder

---
-- Field occludee
--
-- @field [parent=#BillboardSet] #boolean occludee

---
-- Field octant (Read only)
--
-- @field [parent=#BillboardSet] Octant#Octant octant

---
-- Field zone
--
-- @field [parent=#BillboardSet] Zone#Zone zone

---
-- Field lastZone (Read only)
--
-- @field [parent=#BillboardSet] Zone#Zone lastZone

---
-- Field zoneDirty (Read only)
--
-- @field [parent=#BillboardSet] #boolean zoneDirty

---
-- Field distance (Read only)
--
-- @field [parent=#BillboardSet] #number distance

---
-- Field lodDistance (Read only)
--
-- @field [parent=#BillboardSet] #number lodDistance

---
-- Field sortValue
--
-- @field [parent=#BillboardSet] #number sortValue

---
-- Field firstLight (Read only)
--
-- @field [parent=#BillboardSet] Light#Light firstLight

---
-- Field minZ (Read only)
--
-- @field [parent=#BillboardSet] #number minZ

---
-- Field maxZ (Read only)
--
-- @field [parent=#BillboardSet] #number maxZ

---
-- Function SetEnabled
--
-- @function [parent=#BillboardSet] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Remove
--
-- @function [parent=#BillboardSet] Remove
-- @param self Self reference

---
-- Function GetID
--
-- @function [parent=#BillboardSet] GetID
-- @param self Self reference
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#BillboardSet] GetNode
-- @param self Self reference
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#BillboardSet] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#BillboardSet] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#BillboardSet] IsEnabledEffective
-- @param self Self reference
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#BillboardSet] GetComponent
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#BillboardSet] GetComponent
-- @param self Self reference
-- @param #string type type
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#BillboardSet] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#BillboardSet] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#BillboardSet] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#BillboardSet] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#BillboardSet] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#BillboardSet] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#BillboardSet] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#BillboardSet] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#BillboardSet] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#BillboardSet] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#BillboardSet] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#BillboardSet] #string category


return nil
