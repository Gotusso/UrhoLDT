---
-- Module BillboardSet
-- extends Drawable
--
-- @module BillboardSet

---
-- Function SetMaterial
--
-- @function [parent=#BillboardSet] SetMaterial
-- @param Material#Material materialmaterial

---
-- Function SetNumBillboards
--
-- @function [parent=#BillboardSet] SetNumBillboards
-- @param #number numnum

---
-- Function SetRelative
--
-- @function [parent=#BillboardSet] SetRelative
-- @param #boolean enableenable

---
-- Function SetScaled
--
-- @function [parent=#BillboardSet] SetScaled
-- @param #boolean enableenable

---
-- Function SetSorted
--
-- @function [parent=#BillboardSet] SetSorted
-- @param #boolean enableenable

---
-- Function SetFaceCamera
--
-- @function [parent=#BillboardSet] SetFaceCamera
-- @param #boolean enableenable

---
-- Function SetAnimationLodBias
--
-- @function [parent=#BillboardSet] SetAnimationLodBias
-- @param #number biasbias

---
-- Function Commit
--
-- @function [parent=#BillboardSet] Commit

---
-- Function GetMaterial
--
-- @function [parent=#BillboardSet] GetMaterial
-- @return Material#Material

---
-- Function GetNumBillboards
--
-- @function [parent=#BillboardSet] GetNumBillboards
-- @return #number

---
-- Function GetBillboard
--
-- @function [parent=#BillboardSet] GetBillboard
-- @param #number indexindex
-- @return Billboard#Billboard

---
-- Function IsRelative
--
-- @function [parent=#BillboardSet] IsRelative
-- @return #boolean

---
-- Function IsScaled
--
-- @function [parent=#BillboardSet] IsScaled
-- @return #boolean

---
-- Function IsSorted
--
-- @function [parent=#BillboardSet] IsSorted
-- @return #boolean

---
-- Function GetFaceCamera
--
-- @function [parent=#BillboardSet] GetFaceCamera
-- @return #boolean

---
-- Function GetAnimationLodBias
--
-- @function [parent=#BillboardSet] GetAnimationLodBias
-- @return #number

---
-- Field material
--
-- @field [parent=#BillboardSet] Material#Material material

---
-- Field numBillboards
--
-- @field [parent=#BillboardSet] #number numBillboards

---
-- Field relative
--
-- @field [parent=#BillboardSet] #boolean relative

---
-- Field scaled
--
-- @field [parent=#BillboardSet] #boolean scaled

---
-- Field sorted
--
-- @field [parent=#BillboardSet] #boolean sorted

---
-- Field faceCamera
--
-- @field [parent=#BillboardSet] #boolean faceCamera

---
-- Field animationLodBias
--
-- @field [parent=#BillboardSet] #number animationLodBias

---
-- Function SetDrawDistance
--
-- @function [parent=#BillboardSet] SetDrawDistance
-- @param #number distancedistance

---
-- Function SetShadowDistance
--
-- @function [parent=#BillboardSet] SetShadowDistance
-- @param #number distancedistance

---
-- Function SetLodBias
--
-- @function [parent=#BillboardSet] SetLodBias
-- @param #number biasbias

---
-- Function SetViewMask
--
-- @function [parent=#BillboardSet] SetViewMask
-- @param #number maskmask

---
-- Function SetLightMask
--
-- @function [parent=#BillboardSet] SetLightMask
-- @param #number maskmask

---
-- Function SetShadowMask
--
-- @function [parent=#BillboardSet] SetShadowMask
-- @param #number maskmask

---
-- Function SetZoneMask
--
-- @function [parent=#BillboardSet] SetZoneMask
-- @param #number maskmask

---
-- Function SetMaxLights
--
-- @function [parent=#BillboardSet] SetMaxLights
-- @param #number numnum

---
-- Function SetCastShadows
--
-- @function [parent=#BillboardSet] SetCastShadows
-- @param #boolean enableenable

---
-- Function SetOccluder
--
-- @function [parent=#BillboardSet] SetOccluder
-- @param #boolean enableenable

---
-- Function SetOccludee
--
-- @function [parent=#BillboardSet] SetOccludee
-- @param #boolean enableenable

---
-- Function MarkForUpdate
--
-- @function [parent=#BillboardSet] MarkForUpdate

---
-- Function GetBoundingBox
--
-- @function [parent=#BillboardSet] GetBoundingBox
-- @return const BoundingBox#const BoundingBox

---
-- Function GetWorldBoundingBox
--
-- @function [parent=#BillboardSet] GetWorldBoundingBox
-- @return const BoundingBox#const BoundingBox

---
-- Function GetDrawableFlags
--
-- @function [parent=#BillboardSet] GetDrawableFlags
-- @return #string

---
-- Function GetDrawDistance
--
-- @function [parent=#BillboardSet] GetDrawDistance
-- @return #number

---
-- Function GetShadowDistance
--
-- @function [parent=#BillboardSet] GetShadowDistance
-- @return #number

---
-- Function GetLodBias
--
-- @function [parent=#BillboardSet] GetLodBias
-- @return #number

---
-- Function GetViewMask
--
-- @function [parent=#BillboardSet] GetViewMask
-- @return #number

---
-- Function GetLightMask
--
-- @function [parent=#BillboardSet] GetLightMask
-- @return #number

---
-- Function GetShadowMask
--
-- @function [parent=#BillboardSet] GetShadowMask
-- @return #number

---
-- Function GetZoneMask
--
-- @function [parent=#BillboardSet] GetZoneMask
-- @return #number

---
-- Function GetMaxLights
--
-- @function [parent=#BillboardSet] GetMaxLights
-- @return #number

---
-- Function GetCastShadows
--
-- @function [parent=#BillboardSet] GetCastShadows
-- @return #boolean

---
-- Function IsOccluder
--
-- @function [parent=#BillboardSet] IsOccluder
-- @return #boolean

---
-- Function IsOccludee
--
-- @function [parent=#BillboardSet] IsOccludee
-- @return #boolean

---
-- Function SetZone
--
-- @function [parent=#BillboardSet] SetZone
-- @param Zone#Zone zonezone
-- @param #boolean temporarytemporary

---
-- Function SetSortValue
--
-- @function [parent=#BillboardSet] SetSortValue
-- @param #number valuevalue

---
-- Function SetMinMaxZ
--
-- @function [parent=#BillboardSet] SetMinMaxZ
-- @param #number minZminZ
-- @param #number maxZmaxZ

---
-- Function MarkInView
--
-- @function [parent=#BillboardSet] MarkInView
-- @param FrameInfo#FrameInfo frameframe
-- @param #boolean mainViewmainView

---
-- Function ClearLights
--
-- @function [parent=#BillboardSet] ClearLights

---
-- Function AddLight
--
-- @function [parent=#BillboardSet] AddLight
-- @param Light#Light lightlight

---
-- Function AddVertexLight
--
-- @function [parent=#BillboardSet] AddVertexLight
-- @param Light#Light lightlight

---
-- Function LimitLights
--
-- @function [parent=#BillboardSet] LimitLights

---
-- Function LimitVertexLights
--
-- @function [parent=#BillboardSet] LimitVertexLights

---
-- Function SetBasePass
--
-- @function [parent=#BillboardSet] SetBasePass
-- @param #number batchIndexbatchIndex

---
-- Function GetOctant
--
-- @function [parent=#BillboardSet] GetOctant
-- @return Octant#Octant

---
-- Function GetZone
--
-- @function [parent=#BillboardSet] GetZone
-- @return Zone#Zone

---
-- Function GetLastZone
--
-- @function [parent=#BillboardSet] GetLastZone
-- @return Zone#Zone

---
-- Function IsZoneDirty
--
-- @function [parent=#BillboardSet] IsZoneDirty
-- @return #boolean

---
-- Function GetDistance
--
-- @function [parent=#BillboardSet] GetDistance
-- @return #number

---
-- Function GetLodDistance
--
-- @function [parent=#BillboardSet] GetLodDistance
-- @return #number

---
-- Function GetSortValue
--
-- @function [parent=#BillboardSet] GetSortValue
-- @return #number

---
-- Function IsInView
--
-- @function [parent=#BillboardSet] IsInView
-- @param #number frameNumberframeNumber
-- @return #boolean

---
-- Function IsInView
--
-- @function [parent=#BillboardSet] IsInView
-- @param FrameInfo#FrameInfo frameframe
-- @param #boolean mainViewmainView
-- @return #boolean

---
-- Function HasBasePass
--
-- @function [parent=#BillboardSet] HasBasePass
-- @param #number batchIndexbatchIndex
-- @return #boolean

---
-- Function GetFirstLight
--
-- @function [parent=#BillboardSet] GetFirstLight
-- @return Light#Light

---
-- Function GetMinZ
--
-- @function [parent=#BillboardSet] GetMinZ
-- @return #number

---
-- Function GetMaxZ
--
-- @function [parent=#BillboardSet] GetMaxZ
-- @return #number

---
-- Field worldBoundingBox (Read only)
--
-- @field [parent=#BillboardSet] BoundingBox#BoundingBox worldBoundingBox

---
-- Field drawableFlags (Read only)
--
-- @field [parent=#BillboardSet] #string drawableFlags

---
-- Field drawDistance
--
-- @field [parent=#BillboardSet] #number drawDistance

---
-- Field shadowDistance
--
-- @field [parent=#BillboardSet] #number shadowDistance

---
-- Field lodBias
--
-- @field [parent=#BillboardSet] #number lodBias

---
-- Field viewMask
--
-- @field [parent=#BillboardSet] #number viewMask

---
-- Field lightMask
--
-- @field [parent=#BillboardSet] #number lightMask

---
-- Field shadowMask
--
-- @field [parent=#BillboardSet] #number shadowMask

---
-- Field zoneMask
--
-- @field [parent=#BillboardSet] #number zoneMask

---
-- Field maxLights
--
-- @field [parent=#BillboardSet] #number maxLights

---
-- Field castShadows
--
-- @field [parent=#BillboardSet] #boolean castShadows

---
-- Field occluder
--
-- @field [parent=#BillboardSet] #boolean occluder

---
-- Field occludee
--
-- @field [parent=#BillboardSet] #boolean occludee

---
-- Field octant (Read only)
--
-- @field [parent=#BillboardSet] Octant#Octant octant

---
-- Field zone
--
-- @field [parent=#BillboardSet] Zone#Zone zone

---
-- Field lastZone (Read only)
--
-- @field [parent=#BillboardSet] Zone#Zone lastZone

---
-- Field zoneDirty (Read only)
--
-- @field [parent=#BillboardSet] #boolean zoneDirty

---
-- Field distance (Read only)
--
-- @field [parent=#BillboardSet] #number distance

---
-- Field lodDistance (Read only)
--
-- @field [parent=#BillboardSet] #number lodDistance

---
-- Field sortValue
--
-- @field [parent=#BillboardSet] #number sortValue

---
-- Field firstLight (Read only)
--
-- @field [parent=#BillboardSet] Light#Light firstLight

---
-- Field minZ (Read only)
--
-- @field [parent=#BillboardSet] #number minZ

---
-- Field maxZ (Read only)
--
-- @field [parent=#BillboardSet] #number maxZ

---
-- Function SetEnabled
--
-- @function [parent=#BillboardSet] SetEnabled
-- @param #boolean enableenable

---
-- Function Remove
--
-- @function [parent=#BillboardSet] Remove

---
-- Function GetID
--
-- @function [parent=#BillboardSet] GetID
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#BillboardSet] GetNode
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#BillboardSet] GetScene
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#BillboardSet] IsEnabled
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#BillboardSet] IsEnabledEffective
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#BillboardSet] GetComponent
-- @param ShortStringHash#ShortStringHash typetype
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#BillboardSet] GetComponent
-- @param #string typetype
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#BillboardSet] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#BillboardSet] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#BillboardSet] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#BillboardSet] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#BillboardSet] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#BillboardSet] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#BillboardSet] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#BillboardSet] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#BillboardSet] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#BillboardSet] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#BillboardSet] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#BillboardSet] #string category


return nil
