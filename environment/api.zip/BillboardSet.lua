---
-- Module BillboardSet
-- Module BillboardSet extends Drawable
-- Generated on 2014-05-31
--
-- @module BillboardSet

---
-- Function SetMaterial()
-- Set material.
--
-- @function [parent=#BillboardSet] SetMaterial
-- @param self Self reference
-- @param Material#Material material material

---
-- Function SetNumBillboards()
-- Set number of billboards.
--
-- @function [parent=#BillboardSet] SetNumBillboards
-- @param self Self reference
-- @param #number num num

---
-- Function SetRelative()
-- Set whether billboards are relative to the scene node. Default true.
--
-- @function [parent=#BillboardSet] SetRelative
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetScaled()
-- Set whether scene node scale affects billboards' size. Default true.
--
-- @function [parent=#BillboardSet] SetScaled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetSorted()
-- Set whether billboards are sorted by distance. Default false.
--
-- @function [parent=#BillboardSet] SetSorted
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetFaceCameraMode()
-- Set how the billboards should rotate in relation to the camera. Default is to follow camera rotation on all axes (FC_ROTATE_XYZ.)
--
-- @function [parent=#BillboardSet] SetFaceCameraMode
-- @param self Self reference
-- @param FaceCameraMode#FaceCameraMode mode mode

---
-- Function SetAnimationLodBias()
-- Set animation LOD bias.
--
-- @function [parent=#BillboardSet] SetAnimationLodBias
-- @param self Self reference
-- @param #number bias bias

---
-- Function Commit()
-- Mark for bounding box and vertex buffer update. Call after modifying the billboards.
--
-- @function [parent=#BillboardSet] Commit
-- @param self Self reference

---
-- Function GetMaterial()
-- Return material.
--
-- @function [parent=#BillboardSet] GetMaterial
-- @param self Self reference
-- @return Material#Material

---
-- Function GetNumBillboards()
-- Return number of billboards.
--
-- @function [parent=#BillboardSet] GetNumBillboards
-- @param self Self reference
-- @return #number

---
-- Function GetBillboard()
-- Return billboard by index.
--
-- @function [parent=#BillboardSet] GetBillboard
-- @param self Self reference
-- @param #number index index
-- @return Billboard#Billboard

---
-- Function IsRelative()
-- Return whether billboards are relative to the scene node.
--
-- @function [parent=#BillboardSet] IsRelative
-- @param self Self reference
-- @return #boolean

---
-- Function IsScaled()
-- Return whether scene node scale affects billboards' size.
--
-- @function [parent=#BillboardSet] IsScaled
-- @param self Self reference
-- @return #boolean

---
-- Function IsSorted()
-- Return whether billboards are sorted.
--
-- @function [parent=#BillboardSet] IsSorted
-- @param self Self reference
-- @return #boolean

---
-- Function GetFaceCameraMode()
-- Return how the billboards rotate in relation to the camera.
--
-- @function [parent=#BillboardSet] GetFaceCameraMode
-- @param self Self reference
-- @return FaceCameraMode#FaceCameraMode

---
-- Function GetAnimationLodBias()
-- Return animation LOD bias.
--
-- @function [parent=#BillboardSet] GetAnimationLodBias
-- @param self Self reference
-- @return #number

---
-- Field material
--
-- @field [parent=#BillboardSet] Material#Material material

---
-- Field numBillboards
--
-- @field [parent=#BillboardSet] #number numBillboards

---
-- Field relative
--
-- @field [parent=#BillboardSet] #boolean relative

---
-- Field scaled
--
-- @field [parent=#BillboardSet] #boolean scaled

---
-- Field sorted
--
-- @field [parent=#BillboardSet] #boolean sorted

---
-- Field faceCameraMode
--
-- @field [parent=#BillboardSet] FaceCameraMode#FaceCameraMode faceCameraMode

---
-- Field animationLodBias
--
-- @field [parent=#BillboardSet] #number animationLodBias


return nil
