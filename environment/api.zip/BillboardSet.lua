---
-- Module BillboardSet
-- Extends Drawable
--
-- @module BillboardSet

---
-- Function SetMaterial
--
-- @function [parent=#BillboardSet] SetMaterial
-- @param Material#Material materialmaterial

---
-- Function SetNumBillboards
--
-- @function [parent=#BillboardSet] SetNumBillboards
-- @param #number numnum

---
-- Function SetRelative
--
-- @function [parent=#BillboardSet] SetRelative
-- @param #boolean enableenable

---
-- Function SetScaled
--
-- @function [parent=#BillboardSet] SetScaled
-- @param #boolean enableenable

---
-- Function SetSorted
--
-- @function [parent=#BillboardSet] SetSorted
-- @param #boolean enableenable

---
-- Function SetFaceCamera
--
-- @function [parent=#BillboardSet] SetFaceCamera
-- @param #boolean enableenable

---
-- Function SetAnimationLodBias
--
-- @function [parent=#BillboardSet] SetAnimationLodBias
-- @param #number biasbias

---
-- Function Commit
--
-- @function [parent=#BillboardSet] Commit

---
-- Function GetMaterial
--
-- @function [parent=#BillboardSet] GetMaterial
-- @return Material#Material

---
-- Function GetNumBillboards
--
-- @function [parent=#BillboardSet] GetNumBillboards
-- @return #number

---
-- Function GetBillboard
--
-- @function [parent=#BillboardSet] GetBillboard
-- @param #number indexindex
-- @return Billboard#Billboard

---
-- Function IsRelative
--
-- @function [parent=#BillboardSet] IsRelative
-- @return #boolean

---
-- Function IsScaled
--
-- @function [parent=#BillboardSet] IsScaled
-- @return #boolean

---
-- Function IsSorted
--
-- @function [parent=#BillboardSet] IsSorted
-- @return #boolean

---
-- Function GetFaceCamera
--
-- @function [parent=#BillboardSet] GetFaceCamera
-- @return #boolean

---
-- Function GetAnimationLodBias
--
-- @function [parent=#BillboardSet] GetAnimationLodBias
-- @return #number

---
-- Field material
--
-- @field [parent=#BillboardSet] Material#Material material

---
-- Field numBillboards
--
-- @field [parent=#BillboardSet] #number numBillboards

---
-- Field relative
--
-- @field [parent=#BillboardSet] #boolean relative

---
-- Field scaled
--
-- @field [parent=#BillboardSet] #boolean scaled

---
-- Field sorted
--
-- @field [parent=#BillboardSet] #boolean sorted

---
-- Field faceCamera
--
-- @field [parent=#BillboardSet] #boolean faceCamera

---
-- Field animationLodBias
--
-- @field [parent=#BillboardSet] #number animationLodBias


return nil
