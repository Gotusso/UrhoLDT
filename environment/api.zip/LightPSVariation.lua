---
-- Enumeration LightPSVariation
--
-- @module LightPSVariation

---
-- Enumeration value LPS_NONE
--
-- @field [parent=#LightPSVariation] #number LPS_NONE

---
-- Enumeration value LPS_SPOT
--
-- @field [parent=#LightPSVariation] #number LPS_SPOT

---
-- Enumeration value LPS_POINT
--
-- @field [parent=#LightPSVariation] #number LPS_POINT

---
-- Enumeration value LPS_POINTMASK
--
-- @field [parent=#LightPSVariation] #number LPS_POINTMASK

---
-- Enumeration value LPS_SPEC
--
-- @field [parent=#LightPSVariation] #number LPS_SPEC

---
-- Enumeration value LPS_SPOTSPEC
--
-- @field [parent=#LightPSVariation] #number LPS_SPOTSPEC

---
-- Enumeration value LPS_POINTSPEC
--
-- @field [parent=#LightPSVariation] #number LPS_POINTSPEC

---
-- Enumeration value LPS_POINTMASKSPEC
--
-- @field [parent=#LightPSVariation] #number LPS_POINTMASKSPEC

---
-- Enumeration value LPS_SHADOW
--
-- @field [parent=#LightPSVariation] #number LPS_SHADOW

---
-- Enumeration value LPS_SPOTSHADOW
--
-- @field [parent=#LightPSVariation] #number LPS_SPOTSHADOW

---
-- Enumeration value LPS_POINTSHADOW
--
-- @field [parent=#LightPSVariation] #number LPS_POINTSHADOW

---
-- Enumeration value LPS_POINTMASKSHADOW
--
-- @field [parent=#LightPSVariation] #number LPS_POINTMASKSHADOW

---
-- Enumeration value LPS_SHADOWSPEC
--
-- @field [parent=#LightPSVariation] #number LPS_SHADOWSPEC

---
-- Enumeration value LPS_SPOTSHADOWSPEC
--
-- @field [parent=#LightPSVariation] #number LPS_SPOTSHADOWSPEC

---
-- Enumeration value LPS_POINTSHADOWSPEC
--
-- @field [parent=#LightPSVariation] #number LPS_POINTSHADOWSPEC

---
-- Enumeration value LPS_POINTMASKSHADOWSPEC
--
-- @field [parent=#LightPSVariation] #number LPS_POINTMASKSHADOWSPEC

---
-- Enumeration value MAX_LIGHT_PS_VARIATIONS
--
-- @field [parent=#LightPSVariation] #number MAX_LIGHT_PS_VARIATIONS


return nil
