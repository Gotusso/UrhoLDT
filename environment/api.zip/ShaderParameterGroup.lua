---
-- Enumeration ShaderParameterGroup
--
-- @module ShaderParameterGroup

---
-- Enumeration value SP_FRAME
--
-- @field [parent=#ShaderParameterGroup] #number SP_FRAME

---
-- Enumeration value SP_CAMERA
--
-- @field [parent=#ShaderParameterGroup] #number SP_CAMERA

---
-- Enumeration value SP_VIEWPORT
--
-- @field [parent=#ShaderParameterGroup] #number SP_VIEWPORT

---
-- Enumeration value SP_ZONE
--
-- @field [parent=#ShaderParameterGroup] #number SP_ZONE

---
-- Enumeration value SP_LIGHT
--
-- @field [parent=#ShaderParameterGroup] #number SP_LIGHT

---
-- Enumeration value SP_VERTEXLIGHTS
--
-- @field [parent=#ShaderParameterGroup] #number SP_VERTEXLIGHTS

---
-- Enumeration value SP_MATERIAL
--
-- @field [parent=#ShaderParameterGroup] #number SP_MATERIAL

---
-- Enumeration value SP_OBJECTTRANSFORM
--
-- @field [parent=#ShaderParameterGroup] #number SP_OBJECTTRANSFORM

---
-- Enumeration value MAX_SHADER_PARAMETER_GROUPS
--
-- @field [parent=#ShaderParameterGroup] #number MAX_SHADER_PARAMETER_GROUPS


return nil
