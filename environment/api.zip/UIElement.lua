---
-- Module UIElement
-- extends Serializable
--
-- @module UIElement

---
-- Function UIElement
--
-- @function [parent=#UIElement] UIElement

---
-- Function new
--
-- @function [parent=#UIElement] new
-- @return UIElement#UIElement

---
-- Function delete
--
-- @function [parent=#UIElement] delete

---
-- Function GetScreenPosition
--
-- @function [parent=#UIElement] GetScreenPosition
-- @return const IntVector2#const IntVector2

---
-- Function LoadXML
--
-- @function [parent=#UIElement] LoadXML
-- @param Deserializer#Deserializer sourcesource
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#UIElement] SaveXML
-- @param Serializer#Serializer destdest
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#UIElement] LoadXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#UIElement] SaveXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function FilterAttributes
--
-- @function [parent=#UIElement] FilterAttributes
-- @param XMLElement#XMLElement destdest
-- @return #boolean

---
-- Function SetName
--
-- @function [parent=#UIElement] SetName
-- @param #string namename

---
-- Function SetPosition
--
-- @function [parent=#UIElement] SetPosition
-- @param IntVector2#IntVector2 positionposition

---
-- Function SetPosition
--
-- @function [parent=#UIElement] SetPosition
-- @param #number xx
-- @param #number yy

---
-- Function SetSize
--
-- @function [parent=#UIElement] SetSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function SetSize
--
-- @function [parent=#UIElement] SetSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetWidth
--
-- @function [parent=#UIElement] SetWidth
-- @param #number widthwidth

---
-- Function SetHeight
--
-- @function [parent=#UIElement] SetHeight
-- @param #number heightheight

---
-- Function SetMinSize
--
-- @function [parent=#UIElement] SetMinSize
-- @param IntVector2#IntVector2 minSizeminSize

---
-- Function SetMinSize
--
-- @function [parent=#UIElement] SetMinSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetMinWidth
--
-- @function [parent=#UIElement] SetMinWidth
-- @param #number widthwidth

---
-- Function SetMinHeight
--
-- @function [parent=#UIElement] SetMinHeight
-- @param #number heightheight

---
-- Function SetMaxSize
--
-- @function [parent=#UIElement] SetMaxSize
-- @param IntVector2#IntVector2 maxSizemaxSize

---
-- Function SetMaxSize
--
-- @function [parent=#UIElement] SetMaxSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetMaxWidth
--
-- @function [parent=#UIElement] SetMaxWidth
-- @param #number widthwidth

---
-- Function SetMaxHeight
--
-- @function [parent=#UIElement] SetMaxHeight
-- @param #number heightheight

---
-- Function SetFixedSize
--
-- @function [parent=#UIElement] SetFixedSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function SetFixedSize
--
-- @function [parent=#UIElement] SetFixedSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetFixedWidth
--
-- @function [parent=#UIElement] SetFixedWidth
-- @param #number widthwidth

---
-- Function SetFixedHeight
--
-- @function [parent=#UIElement] SetFixedHeight
-- @param #number heightheight

---
-- Function SetAlignment
--
-- @function [parent=#UIElement] SetAlignment
-- @param HorizontalAlignment#HorizontalAlignment hAlignhAlign
-- @param VerticalAlignment#VerticalAlignment vAlignvAlign

---
-- Function SetHorizontalAlignment
--
-- @function [parent=#UIElement] SetHorizontalAlignment
-- @param HorizontalAlignment#HorizontalAlignment alignalign

---
-- Function SetVerticalAlignment
--
-- @function [parent=#UIElement] SetVerticalAlignment
-- @param VerticalAlignment#VerticalAlignment alignalign

---
-- Function SetClipBorder
--
-- @function [parent=#UIElement] SetClipBorder
-- @param IntRect#IntRect rectrect

---
-- Function SetColor
--
-- @function [parent=#UIElement] SetColor
-- @param Color#Color colorcolor

---
-- Function SetColor
--
-- @function [parent=#UIElement] SetColor
-- @param Corner#Corner cornercorner
-- @param Color#Color colorcolor

---
-- Function SetPriority
--
-- @function [parent=#UIElement] SetPriority
-- @param #number prioritypriority

---
-- Function SetOpacity
--
-- @function [parent=#UIElement] SetOpacity
-- @param #number opacityopacity

---
-- Function SetBringToFront
--
-- @function [parent=#UIElement] SetBringToFront
-- @param #boolean enableenable

---
-- Function SetBringToBack
--
-- @function [parent=#UIElement] SetBringToBack
-- @param #boolean enableenable

---
-- Function SetClipChildren
--
-- @function [parent=#UIElement] SetClipChildren
-- @param #boolean enableenable

---
-- Function SetSortChildren
--
-- @function [parent=#UIElement] SetSortChildren
-- @param #boolean enableenable

---
-- Function SetUseDerivedOpacity
--
-- @function [parent=#UIElement] SetUseDerivedOpacity
-- @param #boolean enableenable

---
-- Function SetEnabled
--
-- @function [parent=#UIElement] SetEnabled
-- @param #boolean enableenable

---
-- Function SetEditable
--
-- @function [parent=#UIElement] SetEditable
-- @param #boolean enableenable

---
-- Function SetFocus
--
-- @function [parent=#UIElement] SetFocus
-- @param #boolean enableenable

---
-- Function SetSelected
--
-- @function [parent=#UIElement] SetSelected
-- @param #boolean enableenable

---
-- Function SetVisible
--
-- @function [parent=#UIElement] SetVisible
-- @param #boolean enableenable

---
-- Function SetFocusMode
--
-- @function [parent=#UIElement] SetFocusMode
-- @param FocusMode#FocusMode modemode

---
-- Function SetDragDropMode
--
-- @function [parent=#UIElement] SetDragDropMode
-- @param #number modemode

---
-- Function SetStyle
--
-- @function [parent=#UIElement] SetStyle
-- @param #string styleNamestyleName
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetStyle
--
-- @function [parent=#UIElement] SetStyle
-- @param XMLElement#XMLElement elementelement
-- @return #boolean

---
-- Function SetStyleAuto
--
-- @function [parent=#UIElement] SetStyleAuto
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetDefaultStyle
--
-- @function [parent=#UIElement] SetDefaultStyle
-- @param XMLFile#XMLFile stylestyle

---
-- Function SetLayout
--
-- @function [parent=#UIElement] SetLayout
-- @param LayoutMode#LayoutMode modemode
-- @param #number spacingspacing

---
-- Function SetLayout
--
-- @function [parent=#UIElement] SetLayout
-- @param LayoutMode#LayoutMode modemode
-- @param #number spacingspacing
-- @param IntRect#IntRect borderborder

---
-- Function SetLayoutMode
--
-- @function [parent=#UIElement] SetLayoutMode
-- @param LayoutMode#LayoutMode modemode

---
-- Function SetLayoutSpacing
--
-- @function [parent=#UIElement] SetLayoutSpacing
-- @param #number spacingspacing

---
-- Function SetLayoutBorder
--
-- @function [parent=#UIElement] SetLayoutBorder
-- @param IntRect#IntRect borderborder

---
-- Function SetIndent
--
-- @function [parent=#UIElement] SetIndent
-- @param #number indentindent

---
-- Function SetIndentSpacing
--
-- @function [parent=#UIElement] SetIndentSpacing
-- @param #number indentSpacingindentSpacing

---
-- Function UpdateLayout
--
-- @function [parent=#UIElement] UpdateLayout

---
-- Function DisableLayoutUpdate
--
-- @function [parent=#UIElement] DisableLayoutUpdate

---
-- Function EnableLayoutUpdate
--
-- @function [parent=#UIElement] EnableLayoutUpdate

---
-- Function BringToFront
--
-- @function [parent=#UIElement] BringToFront

---
-- Function CreateChild
--
-- @function [parent=#UIElement] CreateChild
-- @param #string typetype
-- @param #string namename
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function AddChild
--
-- @function [parent=#UIElement] AddChild
-- @param UIElement#UIElement elementelement

---
-- Function InsertChild
--
-- @function [parent=#UIElement] InsertChild
-- @param #number indexindex
-- @param UIElement#UIElement elementelement

---
-- Function RemoveChild
--
-- @function [parent=#UIElement] RemoveChild
-- @param UIElement#UIElement elementelement
-- @param #number indexindex

---
-- Function RemoveChildAtIndex
--
-- @function [parent=#UIElement] RemoveChildAtIndex
-- @param #number indexindex

---
-- Function RemoveAllChildren
--
-- @function [parent=#UIElement] RemoveAllChildren

---
-- Function Remove
--
-- @function [parent=#UIElement] Remove

---
-- Function FindChild
--
-- @function [parent=#UIElement] FindChild
-- @param UIElement#UIElement elementelement
-- @return #number

---
-- Function SetParent
--
-- @function [parent=#UIElement] SetParent
-- @param UIElement#UIElement parentparent
-- @param #number indexindex

---
-- Function SetVar
--
-- @function [parent=#UIElement] SetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @param Variant#Variant valuevalue

---
-- Function SetInternal
--
-- @function [parent=#UIElement] SetInternal
-- @param #boolean enableenable

---
-- Function SetTraversalMode
--
-- @function [parent=#UIElement] SetTraversalMode
-- @param TraversalMode#TraversalMode traversalModetraversalMode

---
-- Function SetElementEventSender
--
-- @function [parent=#UIElement] SetElementEventSender
-- @param #boolean flagflag

---
-- Function GetName
--
-- @function [parent=#UIElement] GetName
-- @return const String#const String

---
-- Function GetPosition
--
-- @function [parent=#UIElement] GetPosition
-- @return const IntVector2#const IntVector2

---
-- Function GetSize
--
-- @function [parent=#UIElement] GetSize
-- @return const IntVector2#const IntVector2

---
-- Function GetWidth
--
-- @function [parent=#UIElement] GetWidth
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#UIElement] GetHeight
-- @return #number

---
-- Function GetMinSize
--
-- @function [parent=#UIElement] GetMinSize
-- @return const IntVector2#const IntVector2

---
-- Function GetMinWidth
--
-- @function [parent=#UIElement] GetMinWidth
-- @return #number

---
-- Function GetMinHeight
--
-- @function [parent=#UIElement] GetMinHeight
-- @return #number

---
-- Function GetMaxSize
--
-- @function [parent=#UIElement] GetMaxSize
-- @return const IntVector2#const IntVector2

---
-- Function GetMaxWidth
--
-- @function [parent=#UIElement] GetMaxWidth
-- @return #number

---
-- Function GetMaxHeight
--
-- @function [parent=#UIElement] GetMaxHeight
-- @return #number

---
-- Function IsFixedSize
--
-- @function [parent=#UIElement] IsFixedSize
-- @return #boolean

---
-- Function IsFixedWidth
--
-- @function [parent=#UIElement] IsFixedWidth
-- @return #boolean

---
-- Function IsFixedHeight
--
-- @function [parent=#UIElement] IsFixedHeight
-- @return #boolean

---
-- Function GetChildOffset
--
-- @function [parent=#UIElement] GetChildOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetHorizontalAlignment
--
-- @function [parent=#UIElement] GetHorizontalAlignment
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetVerticalAlignment
--
-- @function [parent=#UIElement] GetVerticalAlignment
-- @return VerticalAlignment#VerticalAlignment

---
-- Function GetClipBorder
--
-- @function [parent=#UIElement] GetClipBorder
-- @return const IntRect#const IntRect

---
-- Function GetColor
--
-- @function [parent=#UIElement] GetColor
-- @param Corner#Corner cornercorner
-- @return const Color#const Color

---
-- Function GetPriority
--
-- @function [parent=#UIElement] GetPriority
-- @return #number

---
-- Function GetOpacity
--
-- @function [parent=#UIElement] GetOpacity
-- @return #number

---
-- Function GetDerivedOpacity
--
-- @function [parent=#UIElement] GetDerivedOpacity
-- @return #number

---
-- Function GetBringToFront
--
-- @function [parent=#UIElement] GetBringToFront
-- @return #boolean

---
-- Function GetBringToBack
--
-- @function [parent=#UIElement] GetBringToBack
-- @return #boolean

---
-- Function GetClipChildren
--
-- @function [parent=#UIElement] GetClipChildren
-- @return #boolean

---
-- Function GetSortChildren
--
-- @function [parent=#UIElement] GetSortChildren
-- @return #boolean

---
-- Function GetUseDerivedOpacity
--
-- @function [parent=#UIElement] GetUseDerivedOpacity
-- @return #boolean

---
-- Function HasFocus
--
-- @function [parent=#UIElement] HasFocus
-- @return #boolean

---
-- Function IsEnabled
--
-- @function [parent=#UIElement] IsEnabled
-- @return #boolean

---
-- Function IsEditable
--
-- @function [parent=#UIElement] IsEditable
-- @return #boolean

---
-- Function IsSelected
--
-- @function [parent=#UIElement] IsSelected
-- @return #boolean

---
-- Function IsVisible
--
-- @function [parent=#UIElement] IsVisible
-- @return #boolean

---
-- Function IsHovering
--
-- @function [parent=#UIElement] IsHovering
-- @return #boolean

---
-- Function IsInternal
--
-- @function [parent=#UIElement] IsInternal
-- @return #boolean

---
-- Function HasColorGradient
--
-- @function [parent=#UIElement] HasColorGradient
-- @return #boolean

---
-- Function GetFocusMode
--
-- @function [parent=#UIElement] GetFocusMode
-- @return FocusMode#FocusMode

---
-- Function GetDragDropMode
--
-- @function [parent=#UIElement] GetDragDropMode
-- @return #number

---
-- Function GetAppliedStyle
--
-- @function [parent=#UIElement] GetAppliedStyle
-- @return const String#const String

---
-- Function GetDefaultStyle
--
-- @function [parent=#UIElement] GetDefaultStyle
-- @param #boolean recursiveUprecursiveUp
-- @return XMLFile#XMLFile

---
-- Function GetLayoutMode
--
-- @function [parent=#UIElement] GetLayoutMode
-- @return LayoutMode#LayoutMode

---
-- Function GetLayoutSpacing
--
-- @function [parent=#UIElement] GetLayoutSpacing
-- @return #number

---
-- Function GetLayoutBorder
--
-- @function [parent=#UIElement] GetLayoutBorder
-- @return const IntRect#const IntRect

---
-- Function GetNumChildren
--
-- @function [parent=#UIElement] GetNumChildren
-- @param #boolean recursiverecursive
-- @return #number

---
-- Function GetChild
--
-- @function [parent=#UIElement] GetChild
-- @param #string namename
-- @param #boolean recursiverecursive
-- @return UIElement#UIElement

---
-- Function GetChild
--
-- @function [parent=#UIElement] GetChild
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function GetParent
--
-- @function [parent=#UIElement] GetParent
-- @return UIElement#UIElement

---
-- Function GetRoot
--
-- @function [parent=#UIElement] GetRoot
-- @return UIElement#UIElement

---
-- Function GetDerivedColor
--
-- @function [parent=#UIElement] GetDerivedColor
-- @return const Color#const Color

---
-- Function GetVar
--
-- @function [parent=#UIElement] GetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @return const Variant#const Variant

---
-- Function GetVars
--
-- @function [parent=#UIElement] GetVars
-- @return const VariantMap#const VariantMap

---
-- Function ScreenToElement
--
-- @function [parent=#UIElement] ScreenToElement
-- @param IntVector2#IntVector2 screenPositionscreenPosition
-- @return IntVector2#IntVector2

---
-- Function ElementToScreen
--
-- @function [parent=#UIElement] ElementToScreen
-- @param IntVector2#IntVector2 positionposition
-- @return IntVector2#IntVector2

---
-- Function IsInside
--
-- @function [parent=#UIElement] IsInside
-- @param IntVector2#IntVector2 positionposition
-- @param #boolean isScreenisScreen
-- @return #boolean

---
-- Function IsInsideCombined
--
-- @function [parent=#UIElement] IsInsideCombined
-- @param IntVector2#IntVector2 positionposition
-- @param #boolean isScreenisScreen
-- @return #boolean

---
-- Function GetCombinedScreenRect
--
-- @function [parent=#UIElement] GetCombinedScreenRect
-- @return IntRect#IntRect

---
-- Function SortChildren
--
-- @function [parent=#UIElement] SortChildren

---
-- Function GetLayoutMinSize
--
-- @function [parent=#UIElement] GetLayoutMinSize
-- @return #number

---
-- Function GetIndent
--
-- @function [parent=#UIElement] GetIndent
-- @return #number

---
-- Function GetIndentSpacing
--
-- @function [parent=#UIElement] GetIndentSpacing
-- @return #number

---
-- Function GetIndentWidth
--
-- @function [parent=#UIElement] GetIndentWidth
-- @return #number

---
-- Function SetChildOffset
--
-- @function [parent=#UIElement] SetChildOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetHovering
--
-- @function [parent=#UIElement] SetHovering
-- @param #boolean enableenable

---
-- Function GetColor
--
-- @function [parent=#UIElement] GetColor
-- @return const Color#const Color

---
-- Function GetTraversalMode
--
-- @function [parent=#UIElement] GetTraversalMode
-- @return TraversalMode#TraversalMode

---
-- Function IsElementEventSender
--
-- @function [parent=#UIElement] IsElementEventSender
-- @return #boolean

---
-- Function GetElementEventSender
--
-- @function [parent=#UIElement] GetElementEventSender
-- @return UIElement#UIElement

---
-- Field screenPosition (Read only)
--
-- @field [parent=#UIElement] IntVector2#IntVector2 screenPosition

---
-- Field name
--
-- @field [parent=#UIElement] #string name

---
-- Field position
--
-- @field [parent=#UIElement] IntVector2#IntVector2 position

---
-- Field size
--
-- @field [parent=#UIElement] IntVector2#IntVector2 size

---
-- Field width
--
-- @field [parent=#UIElement] #number width

---
-- Field height
--
-- @field [parent=#UIElement] #number height

---
-- Field minSize
--
-- @field [parent=#UIElement] IntVector2#IntVector2 minSize

---
-- Field minWidth
--
-- @field [parent=#UIElement] #number minWidth

---
-- Field minHeight
--
-- @field [parent=#UIElement] #number minHeight

---
-- Field maxSize
--
-- @field [parent=#UIElement] IntVector2#IntVector2 maxSize

---
-- Field maxWidth
--
-- @field [parent=#UIElement] #number maxWidth

---
-- Field maxHeight
--
-- @field [parent=#UIElement] #number maxHeight

---
-- Field fixedSize (Read only)
--
-- @field [parent=#UIElement] #boolean fixedSize

---
-- Field fixedWidth (Read only)
--
-- @field [parent=#UIElement] #boolean fixedWidth

---
-- Field fixedHeight (Read only)
--
-- @field [parent=#UIElement] #boolean fixedHeight

---
-- Field childOffset
--
-- @field [parent=#UIElement] IntVector2#IntVector2 childOffset

---
-- Field horizontalAlignment
--
-- @field [parent=#UIElement] HorizontalAlignment#HorizontalAlignment horizontalAlignment

---
-- Field verticalAlignment
--
-- @field [parent=#UIElement] VerticalAlignment#VerticalAlignment verticalAlignment

---
-- Field clipBorder
--
-- @field [parent=#UIElement] IntRect#IntRect clipBorder

---
-- Field color
--
-- @field [parent=#UIElement] Color#Color color

---
-- Field priority
--
-- @field [parent=#UIElement] #number priority

---
-- Field opacity
--
-- @field [parent=#UIElement] #number opacity

---
-- Field derivedOpacity (Read only)
--
-- @field [parent=#UIElement] #number derivedOpacity

---
-- Field bringToFront
--
-- @field [parent=#UIElement] #boolean bringToFront

---
-- Field bringToBack
--
-- @field [parent=#UIElement] #boolean bringToBack

---
-- Field clipChildren
--
-- @field [parent=#UIElement] #boolean clipChildren

---
-- Field sortChildren
--
-- @field [parent=#UIElement] #boolean sortChildren

---
-- Field useDerivedOpacity
--
-- @field [parent=#UIElement] #boolean useDerivedOpacity

---
-- Field focus
--
-- @field [parent=#UIElement] #boolean focus

---
-- Field enabled
--
-- @field [parent=#UIElement] #boolean enabled

---
-- Field editable
--
-- @field [parent=#UIElement] #boolean editable

---
-- Field selected
--
-- @field [parent=#UIElement] #boolean selected

---
-- Field visible
--
-- @field [parent=#UIElement] #boolean visible

---
-- Field hovering
--
-- @field [parent=#UIElement] #boolean hovering

---
-- Field internal
--
-- @field [parent=#UIElement] #boolean internal

---
-- Field colorGradient (Read only)
--
-- @field [parent=#UIElement] #boolean colorGradient

---
-- Field focusMode
--
-- @field [parent=#UIElement] FocusMode#FocusMode focusMode

---
-- Field dragDropMode
--
-- @field [parent=#UIElement] #number dragDropMode

---
-- Field style
--
-- @field [parent=#UIElement] #string style

---
-- Field defaultStyle
--
-- @field [parent=#UIElement] XMLFile#XMLFile defaultStyle

---
-- Field layoutMode
--
-- @field [parent=#UIElement] LayoutMode#LayoutMode layoutMode

---
-- Field layoutSpacing
--
-- @field [parent=#UIElement] #number layoutSpacing

---
-- Field layoutBorder
--
-- @field [parent=#UIElement] IntRect#IntRect layoutBorder

---
-- Field numChildren (Read only)
--
-- @field [parent=#UIElement] #number numChildren

---
-- Field parent
--
-- @field [parent=#UIElement] UIElement#UIElement parent

---
-- Field root (Read only)
--
-- @field [parent=#UIElement] UIElement#UIElement root

---
-- Field derivedColor (Read only)
--
-- @field [parent=#UIElement] Color#Color derivedColor

---
-- Field combinedScreenRect (Read only)
--
-- @field [parent=#UIElement] IntRect#IntRect combinedScreenRect

---
-- Field layoutMinSize (Read only)
--
-- @field [parent=#UIElement] #number layoutMinSize

---
-- Field indent
--
-- @field [parent=#UIElement] #number indent

---
-- Field indentSpacing
--
-- @field [parent=#UIElement] #number indentSpacing

---
-- Field indentWidth (Read only)
--
-- @field [parent=#UIElement] #number indentWidth

---
-- Field traversalMode
--
-- @field [parent=#UIElement] TraversalMode#TraversalMode traversalMode

---
-- Field elementEventSender
--
-- @field [parent=#UIElement] #boolean elementEventSender

---
-- Function SetTemporary
--
-- @function [parent=#UIElement] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#UIElement] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#UIElement] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#UIElement] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#UIElement] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#UIElement] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#UIElement] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#UIElement] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#UIElement] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#UIElement] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#UIElement] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#UIElement] #string category


return nil
