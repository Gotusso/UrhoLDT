---
-- Module UIElement
-- Module UIElement extends Animatable
-- Generated on 2014-05-31
--
-- @module UIElement

---
-- Function UIElement()
--
-- @function [parent=#UIElement] UIElement
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#UIElement] new
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function delete()
--
-- @function [parent=#UIElement] delete
-- @param self Self reference

---
-- Function GetScreenPosition()
-- Update and return screen position.
--
-- @function [parent=#UIElement] GetScreenPosition
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function LoadXML()
-- Load from an XML file. Return true if successful.
--
-- @function [parent=#UIElement] LoadXML
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @return #boolean

---
-- Function SaveXML()
-- Save to an XML file. Return true if successful.
--
-- @function [parent=#UIElement] SaveXML
-- @param self Self reference
-- @param Serializer#Serializer dest dest
-- @return #boolean

---
-- Function LoadXML()
--
-- @function [parent=#UIElement] LoadXML
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function SaveXML()
--
-- @function [parent=#UIElement] SaveXML
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function FilterAttributes()
-- Filter attributes in serialization process.
--
-- @function [parent=#UIElement] FilterAttributes
-- @param self Self reference
-- @param XMLElement#XMLElement dest dest
-- @return #boolean

---
-- Function SetName()
-- Set name.
--
-- @function [parent=#UIElement] SetName
-- @param self Self reference
-- @param #string name name

---
-- Function SetPosition()
-- Set position.
--
-- @function [parent=#UIElement] SetPosition
-- @param self Self reference
-- @param IntVector2#IntVector2 position position

---
-- Function SetPosition()
-- Set position.
--
-- @function [parent=#UIElement] SetPosition
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function SetSize()
-- Set size.
--
-- @function [parent=#UIElement] SetSize
-- @param self Self reference
-- @param IntVector2#IntVector2 size size

---
-- Function SetSize()
-- Set size.
--
-- @function [parent=#UIElement] SetSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetWidth()
-- Set width only.
--
-- @function [parent=#UIElement] SetWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetHeight()
-- Set height only.
--
-- @function [parent=#UIElement] SetHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetMinSize()
-- Set minimum size.
--
-- @function [parent=#UIElement] SetMinSize
-- @param self Self reference
-- @param IntVector2#IntVector2 minSize minSize

---
-- Function SetMinSize()
-- Set minimum size.
--
-- @function [parent=#UIElement] SetMinSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetMinWidth()
-- Set minimum width.
--
-- @function [parent=#UIElement] SetMinWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetMinHeight()
-- Set minimum height.
--
-- @function [parent=#UIElement] SetMinHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetMaxSize()
-- Set maximum size.
--
-- @function [parent=#UIElement] SetMaxSize
-- @param self Self reference
-- @param IntVector2#IntVector2 maxSize maxSize

---
-- Function SetMaxSize()
-- Set maximum size.
--
-- @function [parent=#UIElement] SetMaxSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetMaxWidth()
-- Set maximum width.
--
-- @function [parent=#UIElement] SetMaxWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetMaxHeight()
-- Set maximum height.
--
-- @function [parent=#UIElement] SetMaxHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetFixedSize()
-- Set fixed size.
--
-- @function [parent=#UIElement] SetFixedSize
-- @param self Self reference
-- @param IntVector2#IntVector2 size size

---
-- Function SetFixedSize()
-- Set fixed size.
--
-- @function [parent=#UIElement] SetFixedSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetFixedWidth()
-- Set fixed width.
--
-- @function [parent=#UIElement] SetFixedWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetFixedHeight()
-- Set fixed height.
--
-- @function [parent=#UIElement] SetFixedHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetAlignment()
-- Set horizontal and vertical alignment.
--
-- @function [parent=#UIElement] SetAlignment
-- @param self Self reference
-- @param HorizontalAlignment#HorizontalAlignment hAlign hAlign
-- @param VerticalAlignment#VerticalAlignment vAlign vAlign

---
-- Function SetHorizontalAlignment()
-- Set horizontal alignment.
--
-- @function [parent=#UIElement] SetHorizontalAlignment
-- @param self Self reference
-- @param HorizontalAlignment#HorizontalAlignment align align

---
-- Function SetVerticalAlignment()
-- Set vertical alignment.
--
-- @function [parent=#UIElement] SetVerticalAlignment
-- @param self Self reference
-- @param VerticalAlignment#VerticalAlignment align align

---
-- Function SetClipBorder()
-- Set child element clipping border.
--
-- @function [parent=#UIElement] SetClipBorder
-- @param self Self reference
-- @param IntRect#IntRect rect rect

---
-- Function SetColor()
-- Set color on all corners.
--
-- @function [parent=#UIElement] SetColor
-- @param self Self reference
-- @param Color#Color color color

---
-- Function SetColor()
-- Set color on one corner.
--
-- @function [parent=#UIElement] SetColor
-- @param self Self reference
-- @param Corner#Corner corner corner
-- @param Color#Color color color

---
-- Function SetPriority()
-- Set priority.
--
-- @function [parent=#UIElement] SetPriority
-- @param self Self reference
-- @param #number priority priority

---
-- Function SetOpacity()
-- Set opacity.
--
-- @function [parent=#UIElement] SetOpacity
-- @param self Self reference
-- @param #number opacity opacity

---
-- Function SetBringToFront()
-- Set whether should be brought to front when focused.
--
-- @function [parent=#UIElement] SetBringToFront
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetBringToBack()
-- Set whether should be put to background when another element is focused.
--
-- @function [parent=#UIElement] SetBringToBack
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetClipChildren()
-- Set whether should clip child elements. Default false.
--
-- @function [parent=#UIElement] SetClipChildren
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetSortChildren()
-- Set whether should sort child elements according to priority. Default true.
--
-- @function [parent=#UIElement] SetSortChildren
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetUseDerivedOpacity()
-- Set whether parent elements' opacity affects opacity. Default true.
--
-- @function [parent=#UIElement] SetUseDerivedOpacity
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetEnabled()
-- Set whether reacts to input. Default false, but is enabled by subclasses if applicable.
--
-- @function [parent=#UIElement] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetEditable()
-- Set whether value is editable through input. Not applicable to all elements. Default true.
--
-- @function [parent=#UIElement] SetEditable
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetFocus()
-- Set whether is focused. Only one element can be focused at a time.
--
-- @function [parent=#UIElement] SetFocus
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetSelected()
-- Set selected mode. Actual meaning is element dependent, for example constant hover or pressed effect.
--
-- @function [parent=#UIElement] SetSelected
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetVisible()
-- Set whether is visible.
--
-- @function [parent=#UIElement] SetVisible
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetFocusMode()
-- Set focus mode.
--
-- @function [parent=#UIElement] SetFocusMode
-- @param self Self reference
-- @param FocusMode#FocusMode mode mode

---
-- Function SetDragDropMode()
-- Set drag and drop flags.
--
-- @function [parent=#UIElement] SetDragDropMode
-- @param self Self reference
-- @param #number mode mode

---
-- Function SetStyle()
-- Set style from an XML file. Find the style element by name. If the style file is not explicitly provided, use the default style from parental chain. Return true if the style is applied successfully.
--
-- @function [parent=#UIElement] SetStyle
-- @param self Self reference
-- @param #string styleName styleName
-- @param XMLFile#XMLFile file file
-- @return #boolean

---
-- Function SetStyle()
-- Set style from an XML element. Return true if the style is applied successfully.
--
-- @function [parent=#UIElement] SetStyle
-- @param self Self reference
-- @param XMLElement#XMLElement element element
-- @return #boolean

---
-- Function SetStyleAuto()
-- Set style from an XML file. Find the style element automatically. If the style file is not explicitly provided, use the default style from parental chain. Return true if the style is applied successfully.
--
-- @function [parent=#UIElement] SetStyleAuto
-- @param self Self reference
-- @param XMLFile#XMLFile file file
-- @return #boolean

---
-- Function SetDefaultStyle()
-- Set default style file for later use by children elements.
--
-- @function [parent=#UIElement] SetDefaultStyle
-- @param self Self reference
-- @param XMLFile#XMLFile style style

---
-- Function SetLayout()
-- Set layout.
--
-- @function [parent=#UIElement] SetLayout
-- @param self Self reference
-- @param LayoutMode#LayoutMode mode mode
-- @param #number spacing spacing

---
-- Function SetLayout()
--
-- @function [parent=#UIElement] SetLayout
-- @param self Self reference
-- @param LayoutMode#LayoutMode mode mode
-- @param #number spacing spacing
-- @param IntRect#IntRect border border

---
-- Function SetLayoutMode()
-- Set layout mode only.
--
-- @function [parent=#UIElement] SetLayoutMode
-- @param self Self reference
-- @param LayoutMode#LayoutMode mode mode

---
-- Function SetLayoutSpacing()
-- Set layout spacing.
--
-- @function [parent=#UIElement] SetLayoutSpacing
-- @param self Self reference
-- @param #number spacing spacing

---
-- Function SetLayoutBorder()
-- Set layout border.
--
-- @function [parent=#UIElement] SetLayoutBorder
-- @param self Self reference
-- @param IntRect#IntRect border border

---
-- Function SetIndent()
-- Set horizontal indentation.
--
-- @function [parent=#UIElement] SetIndent
-- @param self Self reference
-- @param #number indent indent

---
-- Function SetIndentSpacing()
-- Set indent spacing (number of pixels per indentation level).
--
-- @function [parent=#UIElement] SetIndentSpacing
-- @param self Self reference
-- @param #number indentSpacing indentSpacing

---
-- Function UpdateLayout()
-- Manually update layout. Should not be necessary in most cases, but is provided for completeness.
--
-- @function [parent=#UIElement] UpdateLayout
-- @param self Self reference

---
-- Function DisableLayoutUpdate()
-- Disable automatic layout update. Should only be used if there are performance problems.
--
-- @function [parent=#UIElement] DisableLayoutUpdate
-- @param self Self reference

---
-- Function EnableLayoutUpdate()
-- Enable automatic layout update.
--
-- @function [parent=#UIElement] EnableLayoutUpdate
-- @param self Self reference

---
-- Function BringToFront()
-- Bring UI element to front.
--
-- @function [parent=#UIElement] BringToFront
-- @param self Self reference

---
-- Function CreateChild()
--
-- @function [parent=#UIElement] CreateChild
-- @param self Self reference
-- @param #string type type
-- @param #string name name
-- @param #number index index
-- @return UIElement#UIElement

---
-- Function AddChild()
-- Add a child element.
--
-- @function [parent=#UIElement] AddChild
-- @param self Self reference
-- @param UIElement#UIElement element element

---
-- Function InsertChild()
-- Insert a child element into a specific position in the child list.
--
-- @function [parent=#UIElement] InsertChild
-- @param self Self reference
-- @param #number index index
-- @param UIElement#UIElement element element

---
-- Function RemoveChild()
-- Remove a child element. Starting search at specified index if provided.
--
-- @function [parent=#UIElement] RemoveChild
-- @param self Self reference
-- @param UIElement#UIElement element element
-- @param #number index index

---
-- Function RemoveChildAtIndex()
-- Remove a child element at index.
--
-- @function [parent=#UIElement] RemoveChildAtIndex
-- @param self Self reference
-- @param #number index index

---
-- Function RemoveAllChildren()
-- Remove all child elements.
--
-- @function [parent=#UIElement] RemoveAllChildren
-- @param self Self reference

---
-- Function Remove()
-- Remove from the parent element. If no other shared pointer references exist, causes immediate deletion.
--
-- @function [parent=#UIElement] Remove
-- @param self Self reference

---
-- Function FindChild()
-- Find child index. Return M_MAX_UNSIGNED if not found.
--
-- @function [parent=#UIElement] FindChild
-- @param self Self reference
-- @param UIElement#UIElement element element
-- @return #number

---
-- Function SetParent()
-- Set parent element. Same as parent->InsertChild(index, this).
--
-- @function [parent=#UIElement] SetParent
-- @param self Self reference
-- @param UIElement#UIElement parent parent
-- @param #number index index

---
-- Function SetVar()
-- Set a user variable.
--
-- @function [parent=#UIElement] SetVar
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash key key
-- @param Variant#Variant value value

---
-- Function SetInternal()
-- Mark as internally (programmatically) created. Used when an element composes itself out of child elements.
--
-- @function [parent=#UIElement] SetInternal
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetTraversalMode()
-- Set traversal mode for rendering. The default traversal mode is TM_BREADTH_FIRST for non-root element. Root element should be set to TM_DEPTH_FIRST to avoid artifacts during rendering.
--
-- @function [parent=#UIElement] SetTraversalMode
-- @param self Self reference
-- @param TraversalMode#TraversalMode traversalMode traversalMode

---
-- Function SetElementEventSender()
-- Set element event sender flag. When child element is added or deleted, the event would be sent using UIElement found in the parental chain having this flag set. If not set, the event is sent using UI's root as per normal.
--
-- @function [parent=#UIElement] SetElementEventSender
-- @param self Self reference
-- @param #boolean flag flag

---
-- Function GetName()
-- Return name.
--
-- @function [parent=#UIElement] GetName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetPosition()
-- Return position.
--
-- @function [parent=#UIElement] GetPosition
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetSize()
-- Return size.
--
-- @function [parent=#UIElement] GetSize
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetWidth()
-- Return width.
--
-- @function [parent=#UIElement] GetWidth
-- @param self Self reference
-- @return #number

---
-- Function GetHeight()
-- Return height.
--
-- @function [parent=#UIElement] GetHeight
-- @param self Self reference
-- @return #number

---
-- Function GetMinSize()
-- Return minimum size.
--
-- @function [parent=#UIElement] GetMinSize
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetMinWidth()
-- Return minimum width.
--
-- @function [parent=#UIElement] GetMinWidth
-- @param self Self reference
-- @return #number

---
-- Function GetMinHeight()
-- Return minimum height.
--
-- @function [parent=#UIElement] GetMinHeight
-- @param self Self reference
-- @return #number

---
-- Function GetMaxSize()
-- Return maximum size.
--
-- @function [parent=#UIElement] GetMaxSize
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetMaxWidth()
-- Return minimum width.
--
-- @function [parent=#UIElement] GetMaxWidth
-- @param self Self reference
-- @return #number

---
-- Function GetMaxHeight()
-- Return minimum height.
--
-- @function [parent=#UIElement] GetMaxHeight
-- @param self Self reference
-- @return #number

---
-- Function IsFixedSize()
-- Return true if size is fixed.
--
-- @function [parent=#UIElement] IsFixedSize
-- @param self Self reference
-- @return #boolean

---
-- Function IsFixedWidth()
-- Return true if width is fixed.
--
-- @function [parent=#UIElement] IsFixedWidth
-- @param self Self reference
-- @return #boolean

---
-- Function IsFixedHeight()
-- Return true if height is fixed.
--
-- @function [parent=#UIElement] IsFixedHeight
-- @param self Self reference
-- @return #boolean

---
-- Function GetChildOffset()
-- Return child element offset.
--
-- @function [parent=#UIElement] GetChildOffset
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetHorizontalAlignment()
-- Return horizontal alignment.
--
-- @function [parent=#UIElement] GetHorizontalAlignment
-- @param self Self reference
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetVerticalAlignment()
-- Return vertical alignment.
--
-- @function [parent=#UIElement] GetVerticalAlignment
-- @param self Self reference
-- @return VerticalAlignment#VerticalAlignment

---
-- Function GetClipBorder()
-- Return child element clipping border.
--
-- @function [parent=#UIElement] GetClipBorder
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetColor()
-- Return corner color.
--
-- @function [parent=#UIElement] GetColor
-- @param self Self reference
-- @param Corner#Corner corner corner
-- @return const Color#const Color

---
-- Function GetPriority()
-- Return priority.
--
-- @function [parent=#UIElement] GetPriority
-- @param self Self reference
-- @return #number

---
-- Function GetOpacity()
-- Return opacity.
--
-- @function [parent=#UIElement] GetOpacity
-- @param self Self reference
-- @return #number

---
-- Function GetDerivedOpacity()
-- Return derived opacity (affected by parent elements.) If UseDerivedOpacity is false, returns same as element's own opacity.
--
-- @function [parent=#UIElement] GetDerivedOpacity
-- @param self Self reference
-- @return #number

---
-- Function GetBringToFront()
-- Return whether should be brought to front when focused.
--
-- @function [parent=#UIElement] GetBringToFront
-- @param self Self reference
-- @return #boolean

---
-- Function GetBringToBack()
-- Return whether should be put to background when another element is focused.
--
-- @function [parent=#UIElement] GetBringToBack
-- @param self Self reference
-- @return #boolean

---
-- Function GetClipChildren()
-- Return whether should clip child elements.
--
-- @function [parent=#UIElement] GetClipChildren
-- @param self Self reference
-- @return #boolean

---
-- Function GetSortChildren()
-- Return whether should sort child elements according to priority.
--
-- @function [parent=#UIElement] GetSortChildren
-- @param self Self reference
-- @return #boolean

---
-- Function GetUseDerivedOpacity()
-- Return whether parent elements' opacity affects opacity.
--
-- @function [parent=#UIElement] GetUseDerivedOpacity
-- @param self Self reference
-- @return #boolean

---
-- Function HasFocus()
-- Return whether has focus.
--
-- @function [parent=#UIElement] HasFocus
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabled()
-- Return whether reacts to input.
--
-- @function [parent=#UIElement] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEditable()
-- Return whether value is editable through input.
--
-- @function [parent=#UIElement] IsEditable
-- @param self Self reference
-- @return #boolean

---
-- Function IsSelected()
-- Return whether is selected. Actual meaning is element dependent.
--
-- @function [parent=#UIElement] IsSelected
-- @param self Self reference
-- @return #boolean

---
-- Function IsVisible()
-- Return whether is visible.
--
-- @function [parent=#UIElement] IsVisible
-- @param self Self reference
-- @return #boolean

---
-- Function IsHovering()
-- Return whether the cursor is hovering on this element.
--
-- @function [parent=#UIElement] IsHovering
-- @param self Self reference
-- @return #boolean

---
-- Function IsInternal()
-- Return whether is internally created.
--
-- @function [parent=#UIElement] IsInternal
-- @param self Self reference
-- @return #boolean

---
-- Function HasColorGradient()
-- Return whether has different color in at least one corner.
--
-- @function [parent=#UIElement] HasColorGradient
-- @param self Self reference
-- @return #boolean

---
-- Function GetFocusMode()
-- Return focus mode.
--
-- @function [parent=#UIElement] GetFocusMode
-- @param self Self reference
-- @return FocusMode#FocusMode

---
-- Function GetDragDropMode()
-- Return drag and drop flags.
--
-- @function [parent=#UIElement] GetDragDropMode
-- @param self Self reference
-- @return #number

---
-- Function GetAppliedStyle()
-- Return applied style name. Return an empty string when the applied style is an 'auto' style (i.e. style derived from instance's type).
--
-- @function [parent=#UIElement] GetAppliedStyle
-- @param self Self reference
-- @return const String#const String

---
-- Function GetDefaultStyle()
-- Return default style.
--
-- @function [parent=#UIElement] GetDefaultStyle
-- @param self Self reference
-- @param #boolean recursiveUp recursiveUp
-- @return XMLFile#XMLFile

---
-- Function GetLayoutMode()
-- Return layout mode.
--
-- @function [parent=#UIElement] GetLayoutMode
-- @param self Self reference
-- @return LayoutMode#LayoutMode

---
-- Function GetLayoutSpacing()
-- Return layout spacing.
--
-- @function [parent=#UIElement] GetLayoutSpacing
-- @param self Self reference
-- @return #number

---
-- Function GetLayoutBorder()
-- Return layout border.
--
-- @function [parent=#UIElement] GetLayoutBorder
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetNumChildren()
-- Return number of child elements.
--
-- @function [parent=#UIElement] GetNumChildren
-- @param self Self reference
-- @param #boolean recursive recursive
-- @return #number

---
-- Function GetChild()
-- Return child element by name.
--
-- @function [parent=#UIElement] GetChild
-- @param self Self reference
-- @param #string name name
-- @param #boolean recursive recursive
-- @return UIElement#UIElement

---
-- Function GetChild()
-- Return child element by index.
--
-- @function [parent=#UIElement] GetChild
-- @param self Self reference
-- @param #number index index
-- @return UIElement#UIElement

---
-- Function GetParent()
-- Return parent element.
--
-- @function [parent=#UIElement] GetParent
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetRoot()
-- Return root element.
--
-- @function [parent=#UIElement] GetRoot
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetDerivedColor()
-- Return derived color. Only valid when no gradient.
--
-- @function [parent=#UIElement] GetDerivedColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetVar()
--
-- @function [parent=#UIElement] GetVar
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash key key
-- @return const Variant#const Variant

---
-- Function GetVars()
-- Return all user variables.
--
-- @function [parent=#UIElement] GetVars
-- @param self Self reference
-- @return const VariantMap#const VariantMap

---
-- Function ScreenToElement()
-- Convert screen coordinates to element coordinates.
--
-- @function [parent=#UIElement] ScreenToElement
-- @param self Self reference
-- @param IntVector2#IntVector2 screenPosition screenPosition
-- @return IntVector2#IntVector2

---
-- Function ElementToScreen()
-- Convert element coordinates to screen coordinates.
--
-- @function [parent=#UIElement] ElementToScreen
-- @param self Self reference
-- @param IntVector2#IntVector2 position position
-- @return IntVector2#IntVector2

---
-- Function IsInside()
-- Return whether a point (either in element or screen coordinates) is inside the element.
--
-- @function [parent=#UIElement] IsInside
-- @param self Self reference
-- @param IntVector2#IntVector2 position position
-- @param #boolean isScreen isScreen
-- @return #boolean

---
-- Function IsInsideCombined()
-- Return whether a point (either in element or screen coordinates) is inside the combined rect of the element and its children.
--
-- @function [parent=#UIElement] IsInsideCombined
-- @param self Self reference
-- @param IntVector2#IntVector2 position position
-- @param #boolean isScreen isScreen
-- @return #boolean

---
-- Function GetCombinedScreenRect()
-- Return combined screen coordinate rect of element and its children.
--
-- @function [parent=#UIElement] GetCombinedScreenRect
-- @param self Self reference
-- @return IntRect#IntRect

---
-- Function SortChildren()
-- Sort child elements if sorting enabled and order dirty. Called by UI.
--
-- @function [parent=#UIElement] SortChildren
-- @param self Self reference

---
-- Function GetLayoutMinSize()
-- Return minimum layout element size in the layout direction. Only valid after layout has been calculated.
--
-- @function [parent=#UIElement] GetLayoutMinSize
-- @param self Self reference
-- @return #number

---
-- Function GetIndent()
-- Return horizontal indentation.
--
-- @function [parent=#UIElement] GetIndent
-- @param self Self reference
-- @return #number

---
-- Function GetIndentSpacing()
-- Return indent spacing (number of pixels per indentation level).
--
-- @function [parent=#UIElement] GetIndentSpacing
-- @param self Self reference
-- @return #number

---
-- Function GetIndentWidth()
-- Return indent width in pixels.
--
-- @function [parent=#UIElement] GetIndentWidth
-- @param self Self reference
-- @return #number

---
-- Function SetChildOffset()
-- Set child offset.
--
-- @function [parent=#UIElement] SetChildOffset
-- @param self Self reference
-- @param IntVector2#IntVector2 offset offset

---
-- Function SetHovering()
-- Set hovering state.
--
-- @function [parent=#UIElement] SetHovering
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function GetColor()
--
-- @function [parent=#UIElement] GetColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetTraversalMode()
-- Return traversal mode for rendering.
--
-- @function [parent=#UIElement] GetTraversalMode
-- @param self Self reference
-- @return TraversalMode#TraversalMode

---
-- Function IsElementEventSender()
-- Return whether element should send child added / removed events by itself. If false, defers to parent element.
--
-- @function [parent=#UIElement] IsElementEventSender
-- @param self Self reference
-- @return #boolean

---
-- Function GetElementEventSender()
-- Get element which should send child added / removed events.
--
-- @function [parent=#UIElement] GetElementEventSender
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Field screenPosition (Read only)
--
-- @field [parent=#UIElement] IntVector2#IntVector2 screenPosition

---
-- Field name
--
-- @field [parent=#UIElement] #string name

---
-- Field position
--
-- @field [parent=#UIElement] IntVector2#IntVector2 position

---
-- Field size
--
-- @field [parent=#UIElement] IntVector2#IntVector2 size

---
-- Field width
--
-- @field [parent=#UIElement] #number width

---
-- Field height
--
-- @field [parent=#UIElement] #number height

---
-- Field minSize
--
-- @field [parent=#UIElement] IntVector2#IntVector2 minSize

---
-- Field minWidth
--
-- @field [parent=#UIElement] #number minWidth

---
-- Field minHeight
--
-- @field [parent=#UIElement] #number minHeight

---
-- Field maxSize
--
-- @field [parent=#UIElement] IntVector2#IntVector2 maxSize

---
-- Field maxWidth
--
-- @field [parent=#UIElement] #number maxWidth

---
-- Field maxHeight
--
-- @field [parent=#UIElement] #number maxHeight

---
-- Field fixedSize (Read only)
--
-- @field [parent=#UIElement] #boolean fixedSize

---
-- Field fixedWidth (Read only)
--
-- @field [parent=#UIElement] #boolean fixedWidth

---
-- Field fixedHeight (Read only)
--
-- @field [parent=#UIElement] #boolean fixedHeight

---
-- Field childOffset
--
-- @field [parent=#UIElement] IntVector2#IntVector2 childOffset

---
-- Field horizontalAlignment
--
-- @field [parent=#UIElement] HorizontalAlignment#HorizontalAlignment horizontalAlignment

---
-- Field verticalAlignment
--
-- @field [parent=#UIElement] VerticalAlignment#VerticalAlignment verticalAlignment

---
-- Field clipBorder
--
-- @field [parent=#UIElement] IntRect#IntRect clipBorder

---
-- Field color
--
-- @field [parent=#UIElement] Color#Color color

---
-- Field priority
--
-- @field [parent=#UIElement] #number priority

---
-- Field opacity
--
-- @field [parent=#UIElement] #number opacity

---
-- Field derivedOpacity (Read only)
--
-- @field [parent=#UIElement] #number derivedOpacity

---
-- Field bringToFront
--
-- @field [parent=#UIElement] #boolean bringToFront

---
-- Field bringToBack
--
-- @field [parent=#UIElement] #boolean bringToBack

---
-- Field clipChildren
--
-- @field [parent=#UIElement] #boolean clipChildren

---
-- Field sortChildren
--
-- @field [parent=#UIElement] #boolean sortChildren

---
-- Field useDerivedOpacity
--
-- @field [parent=#UIElement] #boolean useDerivedOpacity

---
-- Field focus
--
-- @field [parent=#UIElement] #boolean focus

---
-- Field enabled
--
-- @field [parent=#UIElement] #boolean enabled

---
-- Field editable
--
-- @field [parent=#UIElement] #boolean editable

---
-- Field selected
--
-- @field [parent=#UIElement] #boolean selected

---
-- Field visible
--
-- @field [parent=#UIElement] #boolean visible

---
-- Field hovering
--
-- @field [parent=#UIElement] #boolean hovering

---
-- Field internal
--
-- @field [parent=#UIElement] #boolean internal

---
-- Field colorGradient (Read only)
--
-- @field [parent=#UIElement] #boolean colorGradient

---
-- Field focusMode
--
-- @field [parent=#UIElement] FocusMode#FocusMode focusMode

---
-- Field dragDropMode
--
-- @field [parent=#UIElement] #number dragDropMode

---
-- Field style
--
-- @field [parent=#UIElement] #string style

---
-- Field defaultStyle
--
-- @field [parent=#UIElement] XMLFile#XMLFile defaultStyle

---
-- Field layoutMode
--
-- @field [parent=#UIElement] LayoutMode#LayoutMode layoutMode

---
-- Field layoutSpacing
--
-- @field [parent=#UIElement] #number layoutSpacing

---
-- Field layoutBorder
--
-- @field [parent=#UIElement] IntRect#IntRect layoutBorder

---
-- Field numChildren (Read only)
--
-- @field [parent=#UIElement] #number numChildren

---
-- Field parent
--
-- @field [parent=#UIElement] UIElement#UIElement parent

---
-- Field root (Read only)
--
-- @field [parent=#UIElement] UIElement#UIElement root

---
-- Field derivedColor (Read only)
--
-- @field [parent=#UIElement] Color#Color derivedColor

---
-- Field combinedScreenRect (Read only)
--
-- @field [parent=#UIElement] IntRect#IntRect combinedScreenRect

---
-- Field layoutMinSize (Read only)
--
-- @field [parent=#UIElement] #number layoutMinSize

---
-- Field indent
--
-- @field [parent=#UIElement] #number indent

---
-- Field indentSpacing
--
-- @field [parent=#UIElement] #number indentSpacing

---
-- Field indentWidth (Read only)
--
-- @field [parent=#UIElement] #number indentWidth

---
-- Field traversalMode
--
-- @field [parent=#UIElement] TraversalMode#TraversalMode traversalMode

---
-- Field elementEventSender
--
-- @field [parent=#UIElement] #boolean elementEventSender


return nil
