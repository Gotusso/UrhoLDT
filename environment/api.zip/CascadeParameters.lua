---
-- Module CascadeParameters
-- Generated on 2014-03-13
--
-- @module CascadeParameters

---
-- Function CascadeParameters
--
-- @function [parent=#CascadeParameters] CascadeParameters
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#CascadeParameters] new
-- @param self Self reference
-- @return CascadeParameters#CascadeParameters

---
-- Function CascadeParameters
--
-- @function [parent=#CascadeParameters] CascadeParameters
-- @param self Self reference
-- @param #number split1 split1
-- @param #number split2 split2
-- @param #number split3 split3
-- @param #number split4 split4
-- @param #number fadeStart fadeStart
-- @param #number biasAutoAdjust biasAutoAdjust

---
-- Function new
--
-- @function [parent=#CascadeParameters] new
-- @param self Self reference
-- @param #number split1 split1
-- @param #number split2 split2
-- @param #number split3 split3
-- @param #number split4 split4
-- @param #number fadeStart fadeStart
-- @param #number biasAutoAdjust biasAutoAdjust
-- @return CascadeParameters#CascadeParameters

---
-- Function delete
--
-- @function [parent=#CascadeParameters] delete
-- @param self Self reference


return nil
