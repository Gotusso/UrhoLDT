---
-- Module CascadeParameters
--
-- @module CascadeParameters

---
-- Function CascadeParameters
--
-- @function [parent=#CascadeParameters] CascadeParameters

---
-- Function new
--
-- @function [parent=#CascadeParameters] new
-- @return CascadeParameters#CascadeParameters

---
-- Function CascadeParameters
--
-- @function [parent=#CascadeParameters] CascadeParameters
-- @param #number split1split1
-- @param #number split2split2
-- @param #number split3split3
-- @param #number split4split4
-- @param #number fadeStartfadeStart
-- @param #number biasAutoAdjustbiasAutoAdjust

---
-- Function new
--
-- @function [parent=#CascadeParameters] new
-- @param #number split1split1
-- @param #number split2split2
-- @param #number split3split3
-- @param #number split4split4
-- @param #number fadeStartfadeStart
-- @param #number biasAutoAdjustbiasAutoAdjust
-- @return CascadeParameters#CascadeParameters

---
-- Function delete
--
-- @function [parent=#CascadeParameters] delete


return nil
