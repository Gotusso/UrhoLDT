---
-- Enumeration TraversalMode
--
-- @module TraversalMode

---
-- Enumeration value TM_BREADTH_FIRST
--
-- @field [parent=#TraversalMode] #number TM_BREADTH_FIRST

---
-- Enumeration value TM_DEPTH_FIRST
--
-- @field [parent=#TraversalMode] #number TM_DEPTH_FIRST


return nil
