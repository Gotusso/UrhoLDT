-------------------------------------------------------------------------------
-- Urho3D global variables.
-- @module global

------------------------------------------------------------------------------
-- This library provides generic functions for coroutine manipulation.
-- This is a global variable which hold the preloaded @{coroutine} module.
-- @field[parent = #global] coroutine#coroutine coroutine preloaded module

------------------------------------------------------------------------------
-- The package library provides basic facilities for loading and building modules in Lua.
-- This is a global variable which hold the preloaded @{package} module.
-- @field[parent = #global] package#package package preloaded module

------------------------------------------------------------------------------
-- This library provides generic functions for string manipulation.
-- This is a global variable which hold the preloaded @{string} module.
-- @field[parent = #global] string#string string preloaded module

------------------------------------------------------------------------------
-- This library provides generic functions for table manipulation.
-- This is a global variable which hold the preloaded @{table} module.
-- @field[parent = #global] table#table table preloaded module

------------------------------------------------------------------------------
-- This library is an interface to the standard C math library.
-- This is a global variable which hold the preloaded @{math} module.
-- @field[parent = #global] math#math math preloaded module

------------------------------------------------------------------------------
-- The I/O library provides function for file manipulation.
-- This is a global variable which hold the preloaded @{io} module.
-- @field[parent = #global] io#io io preloaded module

------------------------------------------------------------------------------
-- Operating System Facilities.
-- This is a global variable which hold the preloaded @{os} module.
-- @field[parent = #global] os#os os preloaded module

------------------------------------------------------------------------------
-- The Debug Library.
-- This is a  global variable which hold the preloaded @{debug} module.
-- @field[parent = #global] debug#debug debug preloaded module

-------------------------------------------------------------------------------
-- Issues an error when the value of its argument `v` is false (i.e.,
-- **nil** or **false**); otherwise, returns all its arguments. `message` is an error
-- message; when absent, it defaults to *"assertion failed!"*.
-- @function [parent=#global] assert
-- @param v if this argument is false an error is issued.
-- @param #string message an error message. defaults value is *"assertion failed"*.
-- @return All its arguments.

-------------------------------------------------------------------------------
-- This function is a generic interface to the garbage collector.
-- It performs different functions according to its first argument, `opt`:
--
--   * **"stop":** stops the garbage collector.
--   * **"restart":** restarts the garbage collector.
--   * **"collect":** performs a full garbage-collection cycle.
--   * **"count":** returns the total memory in use by Lua (in Kbytes).
--   * **"step":** performs a garbage-collection step. The step "size" is controlled
--       by `arg` (larger values mean more steps) in a non-specified way. If you
--       want to control the step size you must experimentally tune the value of
--      `arg`. Returns true if the step finished a collection cycle.
--   * **"setpause":** sets `arg` as the new value for the *pause* of the collector.
--       Returns the previous value for *pause*.
--   * **"setstepmul":** sets `arg` as the new value for the *step multiplier*
--       of the collector. Returns the previous value for *step*.
-- @function [parent=#global] collectgarbage
-- @param #string opt the command to send.
-- @param arg the argument of the command. (optional)

-------------------------------------------------------------------------------
-- Opens the named file and executes its contents as a Lua chunk. When
-- called without arguments,
-- `dofile` executes the contents of the standard input (`stdin`). Returns
-- all values returned by the chunk. In case of errors, `dofile` propagates
-- the error to its caller (that is, `dofile` does not run in protected mode).
-- @function [parent=#global] dofile
-- @param #string filename the path to the file. (optional)

-------------------------------------------------------------------------------
-- Terminates the last protected function called and returns `message`
-- as the error message. Function `error` never returns.
--
-- Usually, `error` adds some information about the error position at the
-- beginning of the message. The `level` argument specifies how to get the
-- error position.  
-- With level 1 (the default), the error position is where the
-- `error` function was called.  
-- Level 2 points the error to where the function
-- that called `error` was called; and so on.  
-- Passing a level 0 avoids the addition of error position information to the message.
-- @function [parent=#global] error
-- @param #string message an error message.
-- @param #number level specifies how to get the error position, default value is `1`.

-------------------------------------------------------------------------------
-- A global variable (not a function) that holds the global environment
-- (that is, `_G._G = _G`). Lua itself does not use this variable; changing
-- its value does not affect any environment, nor vice-versa. (Use `setfenv`
-- to change environments.)
-- @field [parent = #global] #table _G

-------------------------------------------------------------------------------
-- Returns the current environment in use by the function.
-- @function [parent=#global] getfenv
-- @param f can be a Lua function or a number that specifies the function at that
-- stack level: Level 1 is the function calling `getfenv`. If the given
-- function is not a Lua function, or if `f` is `0`, `getfenv` returns the
-- global environment. The default for `f` is `1`.

-------------------------------------------------------------------------------
-- If `object` does not have a metatable, returns nil. Otherwise, if the
-- object's metatable has a `"__metatable"` field, returns the associated
-- value. Otherwise, returns the metatable of the given object.
-- @function [parent=#global] getmetatable
-- @param object
-- @return #table the metatable of object.

-------------------------------------------------------------------------------
-- Use to iterate over a table by index.
-- Returns three values: an iterator function, the table `t`, and 0,
-- so that the construction :
-- 
--     for i,v in ipairs(t) do *body* end
-- will iterate over the pairs (`1,t[1]`), (`2,t[2]`), ..., up to the
-- first integer key absent from the table.
-- @function [parent=#global] ipairs
-- @param #table t a table by index.

-------------------------------------------------------------------------------
-- Loads a chunk using function `func` to get its pieces. Each call to
-- `func` must return a string that concatenates with previous results. A
-- return of an empty string, **nil,** or no value signals the end of the chunk.
--
-- If there are no errors, returns the compiled chunk as a function; otherwise,
-- returns nil plus the error message. The environment of the returned function
-- is the global environment.
--
-- `chunkname` is used as the chunk name for error messages and debug
-- information. When absent, it defaults to "`=(load)`".
-- @function [parent=#global] load
-- @param func function which loads the chunk.
-- @param #string chunkname chunk name used for error messages and debug information, default value is "`=(load)`".

-------------------------------------------------------------------------------
-- Similar to `load`, but gets the chunk from file `filename` or from the
-- standard input, if no file name is given.
-- @function [parent=#global] loadfile
-- @param #string filename the path to the file. (optional)

-------------------------------------------------------------------------------
-- Similar to `load`, but gets the chunk from the given string.
-- To load and run a given string, use the idiom  
-- 
--     assert(loadstring(s))()
-- When absent, `chunkname` defaults to the given string.
-- @function [parent=#global] loadstring
-- @param #string string lua code to load.
-- @param #string chunkname chunk name used for error messages and debug information, default value is the given string.

-------------------------------------------------------------------------------
-- Allows a program to traverse all fields of a table. Its first argument is
-- a table and its second argument is an index in this table. `next` returns
-- the next index of the table and its associated value.
--
-- When called with nil
-- as its second argument, `next` returns an initial index and its associated
-- value. When called with the last index, or with nil in an empty table, `next`
-- returns nil.
--
-- If the second argument is absent, then it is interpreted as
-- nil. In particular, you can use `next(t)` to check whether a table is empty.
-- The order in which the indices are enumerated is not specified, *even for
-- numeric indices*. (To traverse a table in numeric order, use a numerical
-- for or the `ipairs` function.)
--
-- The behavior of `next` is *undefined* if, during the traversal, you assign
-- any value to a non-existent field in the table. You may however modify
-- existing fields. In particular, you may clear existing fields.
-- @function [parent=#global] next
-- @param #table table table to traverse.
-- @param index initial index.

-------------------------------------------------------------------------------
-- Use to iterate over a table.
-- Returns three values: the `next` function, the table `t`, and nil,
-- so that the construction :
-- 
--     for k,v in pairs(t) do *body* end
-- will iterate over all key-value pairs of table `t`.
-- 
-- See function `next` for the caveats of modifying the table during its
-- traversal.
-- @function [parent=#global] pairs
-- @param #table t table to traverse.

-------------------------------------------------------------------------------
-- Calls function `f` with the given arguments in *protected mode*. This
-- means that any error inside `f` is not propagated; instead, `pcall` catches
-- the error and returns a status code. Its first result is the status code (a
-- boolean), which is true if the call succeeds without errors. In such case,
-- `pcall` also returns all results from the call, after this first result. In
-- case of any error, `pcall` returns false plus the error message.
-- @function [parent=#global] pcall
-- @param f function to be call in *protected mode*.
-- @param ... function arguments.
-- @return #boolean true plus the result of `f` function if its call succeeds without errors.
-- @return #boolean,#string  false plus the error message in case of any error.

-------------------------------------------------------------------------------
-- Receives any number of arguments, and prints their values to `stdout`,
-- using the `tostring` function to convert them to strings. `print` is not
-- intended for formatted output, but only as a quick way to show a value,
-- typically for debugging. For formatted output, use `string.format`.
-- @function [parent=#global] print
-- @param ... values to print to `stdout`.

-------------------------------------------------------------------------------
-- Checks whether `v1` is equal to `v2`, without invoking any
-- metamethod. Returns a boolean.
-- @function [parent=#global] rawequal
-- @param v1
-- @param v2
-- @return #boolean true if `v1` is equal to `v2`. 

-------------------------------------------------------------------------------
-- Gets the real value of `table[index]`, without invoking any
-- metamethod. `table` must be a table; `index` may be any value.
-- @function [parent=#global] rawget
-- @param #table table
-- @param index may be any value.
-- @return The real value of `table[index]`, without invoking any
-- metamethod.

-------------------------------------------------------------------------------
-- Sets the real value of `table[index]` to `value`, without invoking any
-- metamethod. `table` must be a table, `index` any value different from nil,
-- and `value` any Lua value.  
-- This function returns `table`.
-- @function [parent=#global] rawset
-- @param #table table
-- @param index any value different from nil.
-- @param value any Lua value.

-------------------------------------------------------------------------------
-- If `index` is a number, returns all arguments after argument number
-- `index`. Otherwise, `index` must be the string `"#"`, and `select` returns
-- the total number of extra arguments it received.
-- @function [parent=#global] select
-- @param index a number or the string `"#"`
-- @param ...

-------------------------------------------------------------------------------
-- Sets the environment to be used by the given function. `f` can be a Lua
-- function or a number that specifies the function at that stack level: Level
-- 1 is the function calling `setfenv`. `setfenv` returns the given function.  
-- As a special case, when `f` is 0 `setfenv` changes the environment of the
-- running thread. In this case, `setfenv` returns no values.
-- @function [parent=#global] setfenv
-- @param f a Lua function or a number that specifies the stack level.
-- @param #table table used as environment for `f`.
-- @return The given function.

-------------------------------------------------------------------------------
-- Sets the metatable for the given table. (You cannot change the metatable
-- of other types from Lua, only from C.) If `metatable` is nil, removes the
-- metatable of the given table. If the original metatable has a `"__metatable"`
-- field, raises an error.  
-- This function returns `table`.
-- @function [parent=#global] setmetatable
-- @param #table table 
-- @param #table metatable
-- @return The first argument `table`. 

-------------------------------------------------------------------------------
-- Tries to convert its argument to a number. If the argument is already
-- a number or a string convertible to a number, then `tonumber` returns this
-- number; otherwise, it returns **nil.**
--
-- An optional argument specifies the base to interpret the numeral. The base
-- may be any integer between 2 and 36, inclusive. In bases above 10, the
-- letter '`A`' (in either upper or lower case) represents 10, '`B`' represents
-- 11, and so forth, with '`Z`' representing 35. In base 10 (the default),
-- the number can have a decimal part, as well as an optional exponent part.
-- In other bases, only unsigned integers are accepted.
-- @function [parent=#global] tonumber
-- @param e a number or string to convert to a number.
-- @param #number base the base to interpret the numeral, any integer between 2 and 36.(default is 10).
-- @return #number a number if conversion succeeds else **nil**.

-------------------------------------------------------------------------------
-- Receives an argument of any type and converts it to a string in a
-- reasonable format. For complete control of how numbers are converted, use
-- `string.format`.
--
-- If the metatable of `e` has a `"__tostring"` field, then `tostring` calls
-- the corresponding value with `e` as argument, and uses the result of the
-- call as its result.
-- @function [parent=#global] tostring
-- @param e an argument of any type.
-- @return #string a string in a reasonable format.

-------------------------------------------------------------------------------
-- Returns the type of its only argument, coded as a string. The possible
-- results of this function are "
-- `nil`" (a string, not the value nil), "`number`", "`string`", "`boolean`",
-- "`table`", "`function`", "`thread`", and "`userdata`".
-- @function [parent=#global] type
-- @param v any value.
-- @return #string the type of `v`.

-------------------------------------------------------------------------------
-- Returns the elements from the given table. This function is equivalent to
-- 
--     return list[i], list[i+1], ..., list[j]
-- except that the above code can be written only for a fixed number of
-- elements. By default, `i` is 1 and `j` is the length of the list, as
-- defined by the length operator.
-- @function [parent=#global] unpack
-- @param #table list a table by index
-- @param i index of first value.
-- @param j index of last value.

-------------------------------------------------------------------------------
-- A global variable (not a function) that holds a string containing the
-- current interpreter version. The current contents of this variable is
-- "`Lua 5.1`".
-- @field [parent = #global] #string _VERSION

-------------------------------------------------------------------------------
-- This function is similar to `pcall`, except that you can set a new
-- error handler.
--
-- `xpcall` calls function `f` in protected mode, using `err` as the error
-- handler. Any error inside `f` is not propagated; instead, `xpcall` catches
-- the error, calls the `err` function with the original error object, and
-- returns a status code. Its first result is the status code (a boolean),
-- which is true if the call succeeds without errors. In this case, `xpcall`
-- also returns all results from the call, after this first result. In case
-- of any error, `xpcall` returns false plus the result from `err`.
-- @function [parent=#global] xpcall
-- @param f function to be call in *protected mode*.
-- @param err function used as error handler.
-- @return #boolean true plus the result of `f` function if its call succeeds without errors.
-- @return #boolean,#string  false plus the result of `err` function. 

-------------------------------------------------------------------------------
-- Creates a module. If there is a table in `package.loaded[name]`,
-- this table is the module. Otherwise, if there is a global table `t`
-- with the given name, this table is the module. 
-- 
-- Otherwise creates a new table `t` and sets it as the value of the global 
-- `name` and the value of `package.loaded[name]`. 
--  This function also initializes `t._NAME` with the
-- given name, `t._M` with the module (`t` itself), and `t._PACKAGE` with the
-- package name (the full module name minus last component; see below). Finally,
-- `module` sets `t` as the new environment of the current function and the
-- new value of `package.loaded[name]`, so that `require` returns `t`.
--
-- If `name` is a compound name (that is, one with components separated by
-- dots), `module` creates (or reuses, if they already exist) tables for each
-- component. For instance, if `name` is `a.b.c`, then `module` stores the
-- module table in field `c` of field `b` of global `a`.
--
-- This function can receive optional *options* after the module name, where
-- each option is a function to be applied over the module.
-- @function [parent=#global] module
-- @param name the module name.

-------------------------------------------------------------------------------
-- Loads the given module. The function starts by looking into the
-- `package.loaded` table to determine whether `modname` is already
-- loaded. If it is, then `require` returns the value stored at
-- `package.loaded[modname]`. Otherwise, it tries to find a *loader* for
-- the module.
--
-- To find a loader, `require` is guided by the `package.loaders` array. By
-- changing this array, we can change how `require` looks for a module. The
-- following explanation is based on the default configuration for
-- `package.loaders`.
--
-- First `require` queries `package.preload[modname]`. If it has a value,
-- this value (which should be a function) is the loader. Otherwise `require`
-- searches for a Lua loader using the path stored in `package.path`. If
-- that also fails, it searches for a C loader using the path stored in
-- `package.cpath`. If that also fails, it tries an *all-in-one* loader (see
-- `package.loaders`).
--
-- Once a loader is found, `require` calls the loader with a single argument,
-- `modname`. If the loader returns any value, `require` assigns the returned
-- value to `package.loaded[modname]`. If the loader returns no value and
-- has not assigned any value to `package.loaded[modname]`, then `require`
-- assigns true to this entry. In any case, `require` returns the final value
-- of `package.loaded[modname]`.
--
-- If there is any error loading or running the module, or if it cannot find
-- any loader for the module, then `require` signals an error.
-- @function [parent=#global] require
-- @param #string modname name of module to load.
---
-- Function Abs()
--
-- @function [parent=#global] Abs
-- @param self Self reference
-- @param #number value value
-- @return #number

---
-- Function AbsInt()
--
-- @function [parent=#global] AbsInt
-- @param self Self reference
-- @param #number value value
-- @return #number

---
-- Function Acos()
--
-- @function [parent=#global] Acos
-- @param self Self reference
-- @param #number x x
-- @return #number

---
-- Function AddTrailingSlash()
--
-- @function [parent=#global] AddTrailingSlash
-- @param self Self reference
-- @param #string pathName pathName
-- @return #string

---
-- Function Asin()
--
-- @function [parent=#global] Asin
-- @param self Self reference
-- @param #number x x
-- @return #number

---
-- Function Atan()
--
-- @function [parent=#global] Atan
-- @param self Self reference
-- @param #number x x
-- @return #number

---
-- Function Atan2()
--
-- @function [parent=#global] Atan2
-- @param self Self reference
-- @param #number y y
-- @param #number x x
-- @return #number

---
-- Function Clamp()
--
-- @function [parent=#global] Clamp
-- @param self Self reference
-- @param #number value value
-- @param #number min min
-- @param #number max max
-- @return #number

---
-- Function ClampInt()
--
-- @function [parent=#global] ClampInt
-- @param self Self reference
-- @param #number value value
-- @param #number min min
-- @param #number max max
-- @return #number

---
-- Function Cos()
--
-- @function [parent=#global] Cos
-- @param self Self reference
-- @param #number angle angle
-- @return #number

---
-- Function Equals()
--
-- @function [parent=#global] Equals
-- @param self Self reference
-- @param #number lhs lhs
-- @param #number rhs rhs
-- @return #boolean

---
-- Function ErrorDialog()
--
-- @function [parent=#global] ErrorDialog
-- @param self Self reference
-- @param #string title title
-- @param #string message message

---
-- Function ErrorExit()
--
-- @function [parent=#global] ErrorExit
-- @param self Self reference
-- @param #string message message
-- @param #number exitCode exitCode

---
-- Function GetArguments()
--
-- @function [parent=#global] GetArguments
-- @param self Self reference
-- @return const Vector<String>#const Vector<String>

---
-- Function GetAudio()
--
-- @function [parent=#global] GetAudio
-- @param self Self reference
-- @return Audio#Audio

---
-- Function GetCache()
--
-- @function [parent=#global] GetCache
-- @param self Self reference
-- @return ResourceCache#ResourceCache

---
-- Function GetConsole()
--
-- @function [parent=#global] GetConsole
-- @param self Self reference
-- @return Console#Console

---
-- Function GetConsoleInput()
--
-- @function [parent=#global] GetConsoleInput
-- @param self Self reference
-- @return #string

---
-- Function GetContext()
--
-- @function [parent=#global] GetContext
-- @param self Self reference
-- @return Context#Context

---
-- Function GetDebugHud()
--
-- @function [parent=#global] GetDebugHud
-- @param self Self reference
-- @return DebugHud#DebugHud

---
-- Function GetEngine()
--
-- @function [parent=#global] GetEngine
-- @param self Self reference
-- @return Engine#Engine

---
-- Function GetEventHandler()
--
-- @function [parent=#global] GetEventHandler
-- @param self Self reference
-- @return EventHandler#EventHandler

---
-- Function GetEventSender()
--
-- @function [parent=#global] GetEventSender
-- @param self Self reference
-- @return Object#Object

---
-- Function GetExecuteConsoleCommands()
--
-- @function [parent=#global] GetExecuteConsoleCommands
-- @param self Self reference
-- @return #boolean

---
-- Function GetExtension()
--
-- @function [parent=#global] GetExtension
-- @param self Self reference
-- @param #string fullPath fullPath
-- @param #boolean lowercaseExtension lowercaseExtension
-- @return #string

---
-- Function GetFileName()
--
-- @function [parent=#global] GetFileName
-- @param self Self reference
-- @param #string fullPath fullPath
-- @return #string

---
-- Function GetFileNameAndExtension()
--
-- @function [parent=#global] GetFileNameAndExtension
-- @param self Self reference
-- @param #string fullPath fullPath
-- @param #boolean lowercaseExtension lowercaseExtension
-- @return #string

---
-- Function GetFileSystem()
--
-- @function [parent=#global] GetFileSystem
-- @param self Self reference
-- @return FileSystem#FileSystem

---
-- Function GetGraphics()
--
-- @function [parent=#global] GetGraphics
-- @param self Self reference
-- @return Graphics#Graphics

---
-- Function GetInput()
--
-- @function [parent=#global] GetInput
-- @param self Self reference
-- @return Input#Input

---
-- Function GetInternalPath()
--
-- @function [parent=#global] GetInternalPath
-- @param self Self reference
-- @param #string pathName pathName
-- @return #string

---
-- Function GetLog()
--
-- @function [parent=#global] GetLog
-- @param self Self reference
-- @return Log#Log

---
-- Function GetNativePath()
--
-- @function [parent=#global] GetNativePath
-- @param self Self reference
-- @param #string pathName pathName
-- @return #string

---
-- Function GetNetwork()
--
-- @function [parent=#global] GetNetwork
-- @param self Self reference
-- @return Network#Network

---
-- Function GetNumLogicalCPUs()
--
-- @function [parent=#global] GetNumLogicalCPUs
-- @param self Self reference
-- @return #number

---
-- Function GetNumPhysicalCPUs()
--
-- @function [parent=#global] GetNumPhysicalCPUs
-- @param self Self reference
-- @return #number

---
-- Function GetParentPath()
--
-- @function [parent=#global] GetParentPath
-- @param self Self reference
-- @param #string pathName pathName
-- @return #string

---
-- Function GetPath()
--
-- @function [parent=#global] GetPath
-- @param self Self reference
-- @param #string fullPath fullPath
-- @return #string

---
-- Function GetPlatform()
--
-- @function [parent=#global] GetPlatform
-- @param self Self reference
-- @return #string

---
-- Function GetRandomSeed()
--
-- @function [parent=#global] GetRandomSeed
-- @param self Self reference
-- @return #number

---
-- Function GetRenderer()
--
-- @function [parent=#global] GetRenderer
-- @param self Self reference
-- @return Renderer#Renderer

---
-- Function GetTime()
--
-- @function [parent=#global] GetTime
-- @param self Self reference
-- @return Time#Time

---
-- Function GetUI()
--
-- @function [parent=#global] GetUI
-- @param self Self reference
-- @return UI#UI

---
-- Function IsAbsolutePath()
--
-- @function [parent=#global] IsAbsolutePath
-- @param self Self reference
-- @param #string pathName pathName
-- @return #boolean

---
-- Function IsAlpha()
--
-- @function [parent=#global] IsAlpha
-- @param self Self reference
-- @param #number ch ch
-- @return #boolean

---
-- Function IsDigit()
--
-- @function [parent=#global] IsDigit
-- @param self Self reference
-- @param #number ch ch
-- @return #boolean

---
-- Function IsNaN()
--
-- @function [parent=#global] IsNaN
-- @param self Self reference
-- @param #number value value
-- @return #boolean

---
-- Function IsPowerOfTwo()
--
-- @function [parent=#global] IsPowerOfTwo
-- @param self Self reference
-- @param #number value value
-- @return #boolean

---
-- Function Lerp()
--
-- @function [parent=#global] Lerp
-- @param self Self reference
-- @param #number lhs lhs
-- @param #number rhs rhs
-- @param #number t t
-- @return #number

---
-- Function Max()
--
-- @function [parent=#global] Max
-- @param self Self reference
-- @param #number lhs lhs
-- @param #number rhs rhs
-- @return #number

---
-- Function MaxInt()
--
-- @function [parent=#global] MaxInt
-- @param self Self reference
-- @param #number lhs lhs
-- @param #number rhs rhs
-- @return #number

---
-- Function Min()
--
-- @function [parent=#global] Min
-- @param self Self reference
-- @param #number lhs lhs
-- @param #number rhs rhs
-- @return #number

---
-- Function MinInt()
--
-- @function [parent=#global] MinInt
-- @param self Self reference
-- @param #number lhs lhs
-- @param #number rhs rhs
-- @return #number

---
-- Function NextPowerOfTwo()
--
-- @function [parent=#global] NextPowerOfTwo
-- @param self Self reference
-- @param #number value value
-- @return #number

---
-- Function OpenConsoleWindow()
--
-- @function [parent=#global] OpenConsoleWindow
-- @param self Self reference

---
-- Function PrintLine()
--
-- @function [parent=#global] PrintLine
-- @param self Self reference
-- @param #string str str
-- @param #boolean error error

---
-- Function Rand()
--
-- @function [parent=#global] Rand
-- @param self Self reference
-- @return #number

---
-- Function RandStandardNormal()
--
-- @function [parent=#global] RandStandardNormal
-- @param self Self reference
-- @return #number

---
-- Function Random()
--
-- @function [parent=#global] Random
-- @param self Self reference
-- @param #number min min
-- @param #number max max
-- @return #number

---
-- Function Random()
--
-- @function [parent=#global] Random
-- @param self Self reference
-- @return #number

---
-- Function Random()
--
-- @function [parent=#global] Random
-- @param self Self reference
-- @param #number range range
-- @return #number

---
-- Function RandomInt()
--
-- @function [parent=#global] RandomInt
-- @param self Self reference
-- @param #number range range
-- @return #number

---
-- Function RandomInt()
--
-- @function [parent=#global] RandomInt
-- @param self Self reference
-- @param #number min min
-- @param #number max max
-- @return #number

---
-- Function RandomNormal()
--
-- @function [parent=#global] RandomNormal
-- @param self Self reference
-- @param #number meanValue meanValue
-- @param #number variance variance
-- @return #number

---
-- Function RemoveTrailingSlash()
--
-- @function [parent=#global] RemoveTrailingSlash
-- @param self Self reference
-- @param #string pathName pathName
-- @return #string

---
-- Function ReplaceExtension()
--
-- @function [parent=#global] ReplaceExtension
-- @param self Self reference
-- @param #string fullPath fullPath
-- @param #string newExtension newExtension
-- @return #string

---
-- Function SDBMHash()
--
-- @function [parent=#global] SDBMHash
-- @param self Self reference
-- @param #number hash hash
-- @param #string c c
-- @return #number

---
-- Function SendEvent()
--
-- @function [parent=#global] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Function SetExecuteConsoleCommands()
--
-- @function [parent=#global] SetExecuteConsoleCommands
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetRandomSeed()
--
-- @function [parent=#global] SetRandomSeed
-- @param self Self reference
-- @param #number seed seed

---
-- Function Sign()
--
-- @function [parent=#global] Sign
-- @param self Self reference
-- @param #number value value
-- @return #number

---
-- Function Sin()
--
-- @function [parent=#global] Sin
-- @param self Self reference
-- @param #number angle angle
-- @return #number

---
-- Function SmoothStep()
--
-- @function [parent=#global] SmoothStep
-- @param self Self reference
-- @param #number lhs lhs
-- @param #number rhs rhs
-- @param #number t t
-- @return #number

---
-- Function SubscribeToEvent()
--
-- @function [parent=#global] SubscribeToEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param #string functionName functionName

---
-- Function SubscribeToEvent()
--
-- @function [parent=#global] SubscribeToEvent
-- @param self Self reference
-- @param void*#void* sender sender
-- @param #string eventName eventName
-- @param #string functionName functionName

---
-- Function Tan()
--
-- @function [parent=#global] Tan
-- @param self Self reference
-- @param #number angle angle
-- @return #number

---
-- Function ToBool()
--
-- @function [parent=#global] ToBool
-- @param self Self reference
-- @param #string source source
-- @return #boolean

---
-- Function ToColor()
--
-- @function [parent=#global] ToColor
-- @param self Self reference
-- @param #string source source
-- @return Color#Color

---
-- Function ToFloat()
--
-- @function [parent=#global] ToFloat
-- @param self Self reference
-- @param #string source source
-- @return #number

---
-- Function ToInt()
--
-- @function [parent=#global] ToInt
-- @param self Self reference
-- @param #string source source
-- @return #number

---
-- Function ToIntRect()
--
-- @function [parent=#global] ToIntRect
-- @param self Self reference
-- @param #string source source
-- @return IntRect#IntRect

---
-- Function ToIntVector2()
--
-- @function [parent=#global] ToIntVector2
-- @param self Self reference
-- @param #string source source
-- @return IntVector2#IntVector2

---
-- Function ToLower()
--
-- @function [parent=#global] ToLower
-- @param self Self reference
-- @param #number ch ch
-- @return #number

---
-- Function ToMatrix3()
--
-- @function [parent=#global] ToMatrix3
-- @param self Self reference
-- @param #string source source
-- @return Matrix3#Matrix3

---
-- Function ToMatrix3x4()
--
-- @function [parent=#global] ToMatrix3x4
-- @param self Self reference
-- @param #string source source
-- @return Matrix3x4#Matrix3x4

---
-- Function ToMatrix4()
--
-- @function [parent=#global] ToMatrix4
-- @param self Self reference
-- @param #string source source
-- @return Matrix4#Matrix4

---
-- Function ToQuaternion()
--
-- @function [parent=#global] ToQuaternion
-- @param self Self reference
-- @param #string source source
-- @return Quaternion#Quaternion

---
-- Function ToRect()
--
-- @function [parent=#global] ToRect
-- @param self Self reference
-- @param #string source source
-- @return Rect#Rect

---
-- Function ToString()
--
-- @function [parent=#global] ToString
-- @param self Self reference
-- @param void*#void* value value
-- @return #string

---
-- Function ToStringHex()
--
-- @function [parent=#global] ToStringHex
-- @param self Self reference
-- @param #number value value
-- @return #string

---
-- Function ToUInt()
--
-- @function [parent=#global] ToUInt
-- @param self Self reference
-- @param #string source source
-- @return #number

---
-- Function ToUpper()
--
-- @function [parent=#global] ToUpper
-- @param self Self reference
-- @param #number ch ch
-- @return #number

---
-- Function ToVector2()
--
-- @function [parent=#global] ToVector2
-- @param self Self reference
-- @param #string source source
-- @return Vector2#Vector2

---
-- Function ToVector3()
--
-- @function [parent=#global] ToVector3
-- @param self Self reference
-- @param #string source source
-- @return Vector3#Vector3

---
-- Function ToVector4()
--
-- @function [parent=#global] ToVector4
-- @param self Self reference
-- @param #string source source
-- @param #boolean allowMissingCoords allowMissingCoords
-- @return Vector4#Vector4

---
-- Function UnsubscribeFromAllEvents()
--
-- @function [parent=#global] UnsubscribeFromAllEvents
-- @param self Self reference

---
-- Function UnsubscribeFromEvent()
--
-- @function [parent=#global] UnsubscribeFromEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param #string functionName functionName

---
-- Function UnsubscribeFromEvent()
--
-- @function [parent=#global] UnsubscribeFromEvent
-- @param self Self reference
-- @param void*#void* sender sender
-- @param #string eventName eventName
-- @param #string functionName functionName

---
-- Function UnsubscribeFromEvents()
--
-- @function [parent=#global] UnsubscribeFromEvents
-- @param self Self reference
-- @param void*#void* sender sender


---
-- Field audio (Read only)
--
-- @field [parent=#global] Audio#Audio audio

---
-- Field cache (Read only)
--
-- @field [parent=#global] ResourceCache#ResourceCache cache

---
-- Field console (Read only)
--
-- @field [parent=#global] Console#Console console

---
-- Field debugHud (Read only)
--
-- @field [parent=#global] DebugHud#DebugHud debugHud

---
-- Field engine (Read only)
--
-- @field [parent=#global] Engine#Engine engine

---
-- Field fileSystem (Read only)
--
-- @field [parent=#global] FileSystem#FileSystem fileSystem

---
-- Field graphics (Read only)
--
-- @field [parent=#global] Graphics#Graphics graphics

---
-- Field input (Read only)
--
-- @field [parent=#global] Input#Input input

---
-- Field log (Read only)
--
-- @field [parent=#global] Log#Log log

---
-- Field network (Read only)
--
-- @field [parent=#global] Network#Network network

---
-- Field renderer (Read only)
--
-- @field [parent=#global] Renderer#Renderer renderer

---
-- Field time (Read only)
--
-- @field [parent=#global] Time#Time time

---
-- Field ui (Read only)
--
-- @field [parent=#global] UI#UI ui

---
-- Field ANIMATION_LOD_BASESCALE (Read only)
--
-- @field [parent=#global] #number ANIMATION_LOD_BASESCALE

---
-- Field CHANNEL_POSITION (Read only)
--
-- @field [parent=#global] #string CHANNEL_POSITION

---
-- Field CHANNEL_ROTATION (Read only)
--
-- @field [parent=#global] #string CHANNEL_ROTATION

---
-- Field CHANNEL_SCALE (Read only)
--
-- @field [parent=#global] #string CHANNEL_SCALE

---
-- Field CLEAR_COLOR (Read only)
--
-- @field [parent=#global] #number CLEAR_COLOR

---
-- Field CLEAR_DEPTH (Read only)
--
-- @field [parent=#global] #number CLEAR_DEPTH

---
-- Field CLEAR_STENCIL (Read only)
--
-- @field [parent=#global] #number CLEAR_STENCIL

---
-- Field CONTROLLER_AXIS_LEFTX (Read only)
--
-- @field [parent=#global] #number CONTROLLER_AXIS_LEFTX

---
-- Field CONTROLLER_AXIS_LEFTY (Read only)
--
-- @field [parent=#global] #number CONTROLLER_AXIS_LEFTY

---
-- Field CONTROLLER_AXIS_RIGHTX (Read only)
--
-- @field [parent=#global] #number CONTROLLER_AXIS_RIGHTX

---
-- Field CONTROLLER_AXIS_RIGHTY (Read only)
--
-- @field [parent=#global] #number CONTROLLER_AXIS_RIGHTY

---
-- Field CONTROLLER_AXIS_TRIGGERLEFT (Read only)
--
-- @field [parent=#global] #number CONTROLLER_AXIS_TRIGGERLEFT

---
-- Field CONTROLLER_AXIS_TRIGGERRIGHT (Read only)
--
-- @field [parent=#global] #number CONTROLLER_AXIS_TRIGGERRIGHT

---
-- Field CONTROLLER_BUTTON_A (Read only)
--
-- @field [parent=#global] #number CONTROLLER_BUTTON_A

---
-- Field CONTROLLER_BUTTON_B (Read only)
--
-- @field [parent=#global] #number CONTROLLER_BUTTON_B

---
-- Field CONTROLLER_BUTTON_BACK (Read only)
--
-- @field [parent=#global] #number CONTROLLER_BUTTON_BACK

---
-- Field CONTROLLER_BUTTON_DPAD_DOWN (Read only)
--
-- @field [parent=#global] #number CONTROLLER_BUTTON_DPAD_DOWN

---
-- Field CONTROLLER_BUTTON_DPAD_LEFT (Read only)
--
-- @field [parent=#global] #number CONTROLLER_BUTTON_DPAD_LEFT

---
-- Field CONTROLLER_BUTTON_DPAD_RIGHT (Read only)
--
-- @field [parent=#global] #number CONTROLLER_BUTTON_DPAD_RIGHT

---
-- Field CONTROLLER_BUTTON_DPAD_UP (Read only)
--
-- @field [parent=#global] #number CONTROLLER_BUTTON_DPAD_UP

---
-- Field CONTROLLER_BUTTON_GUIDE (Read only)
--
-- @field [parent=#global] #number CONTROLLER_BUTTON_GUIDE

---
-- Field CONTROLLER_BUTTON_LEFTSHOULDER (Read only)
--
-- @field [parent=#global] #number CONTROLLER_BUTTON_LEFTSHOULDER

---
-- Field CONTROLLER_BUTTON_LEFTSTICK (Read only)
--
-- @field [parent=#global] #number CONTROLLER_BUTTON_LEFTSTICK

---
-- Field CONTROLLER_BUTTON_RIGHTSHOULDER (Read only)
--
-- @field [parent=#global] #number CONTROLLER_BUTTON_RIGHTSHOULDER

---
-- Field CONTROLLER_BUTTON_RIGHTSTICK (Read only)
--
-- @field [parent=#global] #number CONTROLLER_BUTTON_RIGHTSTICK

---
-- Field CONTROLLER_BUTTON_START (Read only)
--
-- @field [parent=#global] #number CONTROLLER_BUTTON_START

---
-- Field CONTROLLER_BUTTON_X (Read only)
--
-- @field [parent=#global] #number CONTROLLER_BUTTON_X

---
-- Field CONTROLLER_BUTTON_Y (Read only)
--
-- @field [parent=#global] #number CONTROLLER_BUTTON_Y

---
-- Field DD_DISABLED (Read only)
--
-- @field [parent=#global] #number DD_DISABLED

---
-- Field DD_SOURCE (Read only)
--
-- @field [parent=#global] #number DD_SOURCE

---
-- Field DD_SOURCE_AND_TARGET (Read only)
--
-- @field [parent=#global] #number DD_SOURCE_AND_TARGET

---
-- Field DD_TARGET (Read only)
--
-- @field [parent=#global] #number DD_TARGET

---
-- Field DEBUGHUD_SHOW_ALL (Read only)
--
-- @field [parent=#global] #number DEBUGHUD_SHOW_ALL

---
-- Field DEBUGHUD_SHOW_MODE (Read only)
--
-- @field [parent=#global] #number DEBUGHUD_SHOW_MODE

---
-- Field DEBUGHUD_SHOW_NONE (Read only)
--
-- @field [parent=#global] #number DEBUGHUD_SHOW_NONE

---
-- Field DEBUGHUD_SHOW_PROFILER (Read only)
--
-- @field [parent=#global] #number DEBUGHUD_SHOW_PROFILER

---
-- Field DEBUGHUD_SHOW_STATS (Read only)
--
-- @field [parent=#global] #number DEBUGHUD_SHOW_STATS

---
-- Field DEFAULT_LIGHTMASK (Read only)
--
-- @field [parent=#global] #number DEFAULT_LIGHTMASK

---
-- Field DEFAULT_SHADOWMASK (Read only)
--
-- @field [parent=#global] #number DEFAULT_SHADOWMASK

---
-- Field DEFAULT_VIEWMASK (Read only)
--
-- @field [parent=#global] #number DEFAULT_VIEWMASK

---
-- Field DEFAULT_ZONEMASK (Read only)
--
-- @field [parent=#global] #number DEFAULT_ZONEMASK

---
-- Field DRAWABLE_ANY (Read only)
--
-- @field [parent=#global] #number DRAWABLE_ANY

---
-- Field DRAWABLE_GEOMETRY (Read only)
--
-- @field [parent=#global] #number DRAWABLE_GEOMETRY

---
-- Field DRAWABLE_LIGHT (Read only)
--
-- @field [parent=#global] #number DRAWABLE_LIGHT

---
-- Field DRAWABLE_PROXYGEOMETRY (Read only)
--
-- @field [parent=#global] #number DRAWABLE_PROXYGEOMETRY

---
-- Field DRAWABLE_ZONE (Read only)
--
-- @field [parent=#global] #number DRAWABLE_ZONE

---
-- Field FIRST_LOCAL_ID (Read only)
--
-- @field [parent=#global] #number FIRST_LOCAL_ID

---
-- Field FIRST_REPLICATED_ID (Read only)
--
-- @field [parent=#global] #number FIRST_REPLICATED_ID

---
-- Field HAT_CENTER (Read only)
--
-- @field [parent=#global] #number HAT_CENTER

---
-- Field HAT_DOWN (Read only)
--
-- @field [parent=#global] #number HAT_DOWN

---
-- Field HAT_LEFT (Read only)
--
-- @field [parent=#global] #number HAT_LEFT

---
-- Field HAT_RIGHT (Read only)
--
-- @field [parent=#global] #number HAT_RIGHT

---
-- Field HAT_UP (Read only)
--
-- @field [parent=#global] #number HAT_UP

---
-- Field KEY_0 (Read only)
--
-- @field [parent=#global] #number KEY_0

---
-- Field KEY_1 (Read only)
--
-- @field [parent=#global] #number KEY_1

---
-- Field KEY_2 (Read only)
--
-- @field [parent=#global] #number KEY_2

---
-- Field KEY_3 (Read only)
--
-- @field [parent=#global] #number KEY_3

---
-- Field KEY_4 (Read only)
--
-- @field [parent=#global] #number KEY_4

---
-- Field KEY_5 (Read only)
--
-- @field [parent=#global] #number KEY_5

---
-- Field KEY_6 (Read only)
--
-- @field [parent=#global] #number KEY_6

---
-- Field KEY_7 (Read only)
--
-- @field [parent=#global] #number KEY_7

---
-- Field KEY_8 (Read only)
--
-- @field [parent=#global] #number KEY_8

---
-- Field KEY_9 (Read only)
--
-- @field [parent=#global] #number KEY_9

---
-- Field KEY_A (Read only)
--
-- @field [parent=#global] #number KEY_A

---
-- Field KEY_ALT (Read only)
--
-- @field [parent=#global] #number KEY_ALT

---
-- Field KEY_APPLICATION (Read only)
--
-- @field [parent=#global] #number KEY_APPLICATION

---
-- Field KEY_B (Read only)
--
-- @field [parent=#global] #number KEY_B

---
-- Field KEY_BACKSPACE (Read only)
--
-- @field [parent=#global] #number KEY_BACKSPACE

---
-- Field KEY_C (Read only)
--
-- @field [parent=#global] #number KEY_C

---
-- Field KEY_CAPSLOCK (Read only)
--
-- @field [parent=#global] #number KEY_CAPSLOCK

---
-- Field KEY_CTRL (Read only)
--
-- @field [parent=#global] #number KEY_CTRL

---
-- Field KEY_D (Read only)
--
-- @field [parent=#global] #number KEY_D

---
-- Field KEY_DELETE (Read only)
--
-- @field [parent=#global] #number KEY_DELETE

---
-- Field KEY_DOWN (Read only)
--
-- @field [parent=#global] #number KEY_DOWN

---
-- Field KEY_E (Read only)
--
-- @field [parent=#global] #number KEY_E

---
-- Field KEY_END (Read only)
--
-- @field [parent=#global] #number KEY_END

---
-- Field KEY_ESC (Read only)
--
-- @field [parent=#global] #number KEY_ESC

---
-- Field KEY_F (Read only)
--
-- @field [parent=#global] #number KEY_F

---
-- Field KEY_F1 (Read only)
--
-- @field [parent=#global] #number KEY_F1

---
-- Field KEY_F10 (Read only)
--
-- @field [parent=#global] #number KEY_F10

---
-- Field KEY_F11 (Read only)
--
-- @field [parent=#global] #number KEY_F11

---
-- Field KEY_F12 (Read only)
--
-- @field [parent=#global] #number KEY_F12

---
-- Field KEY_F13 (Read only)
--
-- @field [parent=#global] #number KEY_F13

---
-- Field KEY_F14 (Read only)
--
-- @field [parent=#global] #number KEY_F14

---
-- Field KEY_F15 (Read only)
--
-- @field [parent=#global] #number KEY_F15

---
-- Field KEY_F16 (Read only)
--
-- @field [parent=#global] #number KEY_F16

---
-- Field KEY_F17 (Read only)
--
-- @field [parent=#global] #number KEY_F17

---
-- Field KEY_F18 (Read only)
--
-- @field [parent=#global] #number KEY_F18

---
-- Field KEY_F19 (Read only)
--
-- @field [parent=#global] #number KEY_F19

---
-- Field KEY_F2 (Read only)
--
-- @field [parent=#global] #number KEY_F2

---
-- Field KEY_F20 (Read only)
--
-- @field [parent=#global] #number KEY_F20

---
-- Field KEY_F21 (Read only)
--
-- @field [parent=#global] #number KEY_F21

---
-- Field KEY_F22 (Read only)
--
-- @field [parent=#global] #number KEY_F22

---
-- Field KEY_F23 (Read only)
--
-- @field [parent=#global] #number KEY_F23

---
-- Field KEY_F24 (Read only)
--
-- @field [parent=#global] #number KEY_F24

---
-- Field KEY_F3 (Read only)
--
-- @field [parent=#global] #number KEY_F3

---
-- Field KEY_F4 (Read only)
--
-- @field [parent=#global] #number KEY_F4

---
-- Field KEY_F5 (Read only)
--
-- @field [parent=#global] #number KEY_F5

---
-- Field KEY_F6 (Read only)
--
-- @field [parent=#global] #number KEY_F6

---
-- Field KEY_F7 (Read only)
--
-- @field [parent=#global] #number KEY_F7

---
-- Field KEY_F8 (Read only)
--
-- @field [parent=#global] #number KEY_F8

---
-- Field KEY_F9 (Read only)
--
-- @field [parent=#global] #number KEY_F9

---
-- Field KEY_G (Read only)
--
-- @field [parent=#global] #number KEY_G

---
-- Field KEY_GUI (Read only)
--
-- @field [parent=#global] #number KEY_GUI

---
-- Field KEY_H (Read only)
--
-- @field [parent=#global] #number KEY_H

---
-- Field KEY_HOME (Read only)
--
-- @field [parent=#global] #number KEY_HOME

---
-- Field KEY_I (Read only)
--
-- @field [parent=#global] #number KEY_I

---
-- Field KEY_INSERT (Read only)
--
-- @field [parent=#global] #number KEY_INSERT

---
-- Field KEY_J (Read only)
--
-- @field [parent=#global] #number KEY_J

---
-- Field KEY_K (Read only)
--
-- @field [parent=#global] #number KEY_K

---
-- Field KEY_KP_0 (Read only)
--
-- @field [parent=#global] #number KEY_KP_0

---
-- Field KEY_KP_1 (Read only)
--
-- @field [parent=#global] #number KEY_KP_1

---
-- Field KEY_KP_2 (Read only)
--
-- @field [parent=#global] #number KEY_KP_2

---
-- Field KEY_KP_3 (Read only)
--
-- @field [parent=#global] #number KEY_KP_3

---
-- Field KEY_KP_4 (Read only)
--
-- @field [parent=#global] #number KEY_KP_4

---
-- Field KEY_KP_5 (Read only)
--
-- @field [parent=#global] #number KEY_KP_5

---
-- Field KEY_KP_6 (Read only)
--
-- @field [parent=#global] #number KEY_KP_6

---
-- Field KEY_KP_7 (Read only)
--
-- @field [parent=#global] #number KEY_KP_7

---
-- Field KEY_KP_8 (Read only)
--
-- @field [parent=#global] #number KEY_KP_8

---
-- Field KEY_KP_9 (Read only)
--
-- @field [parent=#global] #number KEY_KP_9

---
-- Field KEY_KP_DIVIDE (Read only)
--
-- @field [parent=#global] #number KEY_KP_DIVIDE

---
-- Field KEY_KP_ENTER (Read only)
--
-- @field [parent=#global] #number KEY_KP_ENTER

---
-- Field KEY_KP_MINUS (Read only)
--
-- @field [parent=#global] #number KEY_KP_MINUS

---
-- Field KEY_KP_MULTIPLY (Read only)
--
-- @field [parent=#global] #number KEY_KP_MULTIPLY

---
-- Field KEY_KP_PERIOD (Read only)
--
-- @field [parent=#global] #number KEY_KP_PERIOD

---
-- Field KEY_KP_PLUS (Read only)
--
-- @field [parent=#global] #number KEY_KP_PLUS

---
-- Field KEY_L (Read only)
--
-- @field [parent=#global] #number KEY_L

---
-- Field KEY_LALT (Read only)
--
-- @field [parent=#global] #number KEY_LALT

---
-- Field KEY_LCTRL (Read only)
--
-- @field [parent=#global] #number KEY_LCTRL

---
-- Field KEY_LEFT (Read only)
--
-- @field [parent=#global] #number KEY_LEFT

---
-- Field KEY_LGUI (Read only)
--
-- @field [parent=#global] #number KEY_LGUI

---
-- Field KEY_LSHIFT (Read only)
--
-- @field [parent=#global] #number KEY_LSHIFT

---
-- Field KEY_M (Read only)
--
-- @field [parent=#global] #number KEY_M

---
-- Field KEY_N (Read only)
--
-- @field [parent=#global] #number KEY_N

---
-- Field KEY_NUMLOCKCLEAR (Read only)
--
-- @field [parent=#global] #number KEY_NUMLOCKCLEAR

---
-- Field KEY_O (Read only)
--
-- @field [parent=#global] #number KEY_O

---
-- Field KEY_P (Read only)
--
-- @field [parent=#global] #number KEY_P

---
-- Field KEY_PAGEDOWN (Read only)
--
-- @field [parent=#global] #number KEY_PAGEDOWN

---
-- Field KEY_PAGEUP (Read only)
--
-- @field [parent=#global] #number KEY_PAGEUP

---
-- Field KEY_PAUSE (Read only)
--
-- @field [parent=#global] #number KEY_PAUSE

---
-- Field KEY_PRINTSCREEN (Read only)
--
-- @field [parent=#global] #number KEY_PRINTSCREEN

---
-- Field KEY_Q (Read only)
--
-- @field [parent=#global] #number KEY_Q

---
-- Field KEY_R (Read only)
--
-- @field [parent=#global] #number KEY_R

---
-- Field KEY_RALT (Read only)
--
-- @field [parent=#global] #number KEY_RALT

---
-- Field KEY_RCTRL (Read only)
--
-- @field [parent=#global] #number KEY_RCTRL

---
-- Field KEY_RETURN (Read only)
--
-- @field [parent=#global] #number KEY_RETURN

---
-- Field KEY_RETURN2 (Read only)
--
-- @field [parent=#global] #number KEY_RETURN2

---
-- Field KEY_RGUI (Read only)
--
-- @field [parent=#global] #number KEY_RGUI

---
-- Field KEY_RIGHT (Read only)
--
-- @field [parent=#global] #number KEY_RIGHT

---
-- Field KEY_RSHIFT (Read only)
--
-- @field [parent=#global] #number KEY_RSHIFT

---
-- Field KEY_S (Read only)
--
-- @field [parent=#global] #number KEY_S

---
-- Field KEY_SCROLLLOCK (Read only)
--
-- @field [parent=#global] #number KEY_SCROLLLOCK

---
-- Field KEY_SELECT (Read only)
--
-- @field [parent=#global] #number KEY_SELECT

---
-- Field KEY_SHIFT (Read only)
--
-- @field [parent=#global] #number KEY_SHIFT

---
-- Field KEY_SPACE (Read only)
--
-- @field [parent=#global] #number KEY_SPACE

---
-- Field KEY_T (Read only)
--
-- @field [parent=#global] #number KEY_T

---
-- Field KEY_TAB (Read only)
--
-- @field [parent=#global] #number KEY_TAB

---
-- Field KEY_U (Read only)
--
-- @field [parent=#global] #number KEY_U

---
-- Field KEY_UP (Read only)
--
-- @field [parent=#global] #number KEY_UP

---
-- Field KEY_V (Read only)
--
-- @field [parent=#global] #number KEY_V

---
-- Field KEY_W (Read only)
--
-- @field [parent=#global] #number KEY_W

---
-- Field KEY_X (Read only)
--
-- @field [parent=#global] #number KEY_X

---
-- Field KEY_Y (Read only)
--
-- @field [parent=#global] #number KEY_Y

---
-- Field KEY_Z (Read only)
--
-- @field [parent=#global] #number KEY_Z

---
-- Field LAST_LOCAL_ID (Read only)
--
-- @field [parent=#global] #number LAST_LOCAL_ID

---
-- Field LAST_REPLICATED_ID (Read only)
--
-- @field [parent=#global] #number LAST_REPLICATED_ID

---
-- Field LOG_DEBUG (Read only)
--
-- @field [parent=#global] #number LOG_DEBUG

---
-- Field LOG_ERROR (Read only)
--
-- @field [parent=#global] #number LOG_ERROR

---
-- Field LOG_INFO (Read only)
--
-- @field [parent=#global] #number LOG_INFO

---
-- Field LOG_NONE (Read only)
--
-- @field [parent=#global] #number LOG_NONE

---
-- Field LOG_WARNING (Read only)
--
-- @field [parent=#global] #number LOG_WARNING

---
-- Field MAX_VERTEX_LIGHTS (Read only)
--
-- @field [parent=#global] #number MAX_VERTEX_LIGHTS

---
-- Field MOUSEB_LEFT (Read only)
--
-- @field [parent=#global] #number MOUSEB_LEFT

---
-- Field MOUSEB_MIDDLE (Read only)
--
-- @field [parent=#global] #number MOUSEB_MIDDLE

---
-- Field MOUSEB_RIGHT (Read only)
--
-- @field [parent=#global] #number MOUSEB_RIGHT

---
-- Field M_DEGTORAD (Read only)
--
-- @field [parent=#global] #number M_DEGTORAD

---
-- Field M_DEGTORAD_2 (Read only)
--
-- @field [parent=#global] #number M_DEGTORAD_2

---
-- Field M_EPSILON (Read only)
--
-- @field [parent=#global] #number M_EPSILON

---
-- Field M_HALF_PI (Read only)
--
-- @field [parent=#global] #number M_HALF_PI

---
-- Field M_INFINITY (Read only)
--
-- @field [parent=#global] #number M_INFINITY

---
-- Field M_LARGE_EPSILON (Read only)
--
-- @field [parent=#global] #number M_LARGE_EPSILON

---
-- Field M_LARGE_VALUE (Read only)
--
-- @field [parent=#global] #number M_LARGE_VALUE

---
-- Field M_MAX_FOV (Read only)
--
-- @field [parent=#global] #number M_MAX_FOV

---
-- Field M_MAX_INT (Read only)
--
-- @field [parent=#global] #number M_MAX_INT

---
-- Field M_MAX_UNSIGNED (Read only)
--
-- @field [parent=#global] #number M_MAX_UNSIGNED

---
-- Field M_MIN_INT (Read only)
--
-- @field [parent=#global] #number M_MIN_INT

---
-- Field M_MIN_NEARCLIP (Read only)
--
-- @field [parent=#global] #number M_MIN_NEARCLIP

---
-- Field M_MIN_UNSIGNED (Read only)
--
-- @field [parent=#global] #number M_MIN_UNSIGNED

---
-- Field M_PI (Read only)
--
-- @field [parent=#global] #number M_PI

---
-- Field M_RADTODEG (Read only)
--
-- @field [parent=#global] #number M_RADTODEG

---
-- Field NUM_FRUSTUM_PLANES (Read only)
--
-- @field [parent=#global] #number NUM_FRUSTUM_PLANES

---
-- Field NUM_FRUSTUM_VERTICES (Read only)
--
-- @field [parent=#global] #number NUM_FRUSTUM_VERTICES

---
-- Field PIXEL_SIZE (Read only)
--
-- @field [parent=#global] #number PIXEL_SIZE

---
-- Field QUALITY_HIGH (Read only)
--
-- @field [parent=#global] #number QUALITY_HIGH

---
-- Field QUALITY_LOW (Read only)
--
-- @field [parent=#global] #number QUALITY_LOW

---
-- Field QUALITY_MAX (Read only)
--
-- @field [parent=#global] #number QUALITY_MAX

---
-- Field QUALITY_MEDIUM (Read only)
--
-- @field [parent=#global] #number QUALITY_MEDIUM

---
-- Field QUAL_ALT (Read only)
--
-- @field [parent=#global] #number QUAL_ALT

---
-- Field QUAL_ANY (Read only)
--
-- @field [parent=#global] #number QUAL_ANY

---
-- Field QUAL_CTRL (Read only)
--
-- @field [parent=#global] #number QUAL_CTRL

---
-- Field QUAL_SHIFT (Read only)
--
-- @field [parent=#global] #number QUAL_SHIFT

---
-- Field SCANCODE_0 (Read only)
--
-- @field [parent=#global] #number SCANCODE_0

---
-- Field SCANCODE_1 (Read only)
--
-- @field [parent=#global] #number SCANCODE_1

---
-- Field SCANCODE_2 (Read only)
--
-- @field [parent=#global] #number SCANCODE_2

---
-- Field SCANCODE_3 (Read only)
--
-- @field [parent=#global] #number SCANCODE_3

---
-- Field SCANCODE_4 (Read only)
--
-- @field [parent=#global] #number SCANCODE_4

---
-- Field SCANCODE_5 (Read only)
--
-- @field [parent=#global] #number SCANCODE_5

---
-- Field SCANCODE_6 (Read only)
--
-- @field [parent=#global] #number SCANCODE_6

---
-- Field SCANCODE_7 (Read only)
--
-- @field [parent=#global] #number SCANCODE_7

---
-- Field SCANCODE_8 (Read only)
--
-- @field [parent=#global] #number SCANCODE_8

---
-- Field SCANCODE_9 (Read only)
--
-- @field [parent=#global] #number SCANCODE_9

---
-- Field SCANCODE_A (Read only)
--
-- @field [parent=#global] #number SCANCODE_A

---
-- Field SCANCODE_AC_BACK (Read only)
--
-- @field [parent=#global] #number SCANCODE_AC_BACK

---
-- Field SCANCODE_AC_BOOKMARKS (Read only)
--
-- @field [parent=#global] #number SCANCODE_AC_BOOKMARKS

---
-- Field SCANCODE_AC_FORWARD (Read only)
--
-- @field [parent=#global] #number SCANCODE_AC_FORWARD

---
-- Field SCANCODE_AC_HOME (Read only)
--
-- @field [parent=#global] #number SCANCODE_AC_HOME

---
-- Field SCANCODE_AC_REFRESH (Read only)
--
-- @field [parent=#global] #number SCANCODE_AC_REFRESH

---
-- Field SCANCODE_AC_SEARCH (Read only)
--
-- @field [parent=#global] #number SCANCODE_AC_SEARCH

---
-- Field SCANCODE_AC_STOP (Read only)
--
-- @field [parent=#global] #number SCANCODE_AC_STOP

---
-- Field SCANCODE_AGAIN (Read only)
--
-- @field [parent=#global] #number SCANCODE_AGAIN

---
-- Field SCANCODE_ALT (Read only)
--
-- @field [parent=#global] #number SCANCODE_ALT

---
-- Field SCANCODE_ALTERASE (Read only)
--
-- @field [parent=#global] #number SCANCODE_ALTERASE

---
-- Field SCANCODE_APOSTROPHE (Read only)
--
-- @field [parent=#global] #number SCANCODE_APOSTROPHE

---
-- Field SCANCODE_APP1 (Read only)
--
-- @field [parent=#global] #number SCANCODE_APP1

---
-- Field SCANCODE_APP2 (Read only)
--
-- @field [parent=#global] #number SCANCODE_APP2

---
-- Field SCANCODE_APPLICATION (Read only)
--
-- @field [parent=#global] #number SCANCODE_APPLICATION

---
-- Field SCANCODE_AUDIOMUTE (Read only)
--
-- @field [parent=#global] #number SCANCODE_AUDIOMUTE

---
-- Field SCANCODE_AUDIONEXT (Read only)
--
-- @field [parent=#global] #number SCANCODE_AUDIONEXT

---
-- Field SCANCODE_AUDIOPLAY (Read only)
--
-- @field [parent=#global] #number SCANCODE_AUDIOPLAY

---
-- Field SCANCODE_AUDIOPREV (Read only)
--
-- @field [parent=#global] #number SCANCODE_AUDIOPREV

---
-- Field SCANCODE_AUDIOSTOP (Read only)
--
-- @field [parent=#global] #number SCANCODE_AUDIOSTOP

---
-- Field SCANCODE_B (Read only)
--
-- @field [parent=#global] #number SCANCODE_B

---
-- Field SCANCODE_BACKSLASH (Read only)
--
-- @field [parent=#global] #number SCANCODE_BACKSLASH

---
-- Field SCANCODE_BACKSPACE (Read only)
--
-- @field [parent=#global] #number SCANCODE_BACKSPACE

---
-- Field SCANCODE_BRIGHTNESSDOWN (Read only)
--
-- @field [parent=#global] #number SCANCODE_BRIGHTNESSDOWN

---
-- Field SCANCODE_BRIGHTNESSUP (Read only)
--
-- @field [parent=#global] #number SCANCODE_BRIGHTNESSUP

---
-- Field SCANCODE_C (Read only)
--
-- @field [parent=#global] #number SCANCODE_C

---
-- Field SCANCODE_CALCULATOR (Read only)
--
-- @field [parent=#global] #number SCANCODE_CALCULATOR

---
-- Field SCANCODE_CANCEL (Read only)
--
-- @field [parent=#global] #number SCANCODE_CANCEL

---
-- Field SCANCODE_CAPSLOCK (Read only)
--
-- @field [parent=#global] #number SCANCODE_CAPSLOCK

---
-- Field SCANCODE_CLEAR (Read only)
--
-- @field [parent=#global] #number SCANCODE_CLEAR

---
-- Field SCANCODE_CLEARAGAIN (Read only)
--
-- @field [parent=#global] #number SCANCODE_CLEARAGAIN

---
-- Field SCANCODE_COMMA (Read only)
--
-- @field [parent=#global] #number SCANCODE_COMMA

---
-- Field SCANCODE_COMPUTER (Read only)
--
-- @field [parent=#global] #number SCANCODE_COMPUTER

---
-- Field SCANCODE_COPY (Read only)
--
-- @field [parent=#global] #number SCANCODE_COPY

---
-- Field SCANCODE_CRSEL (Read only)
--
-- @field [parent=#global] #number SCANCODE_CRSEL

---
-- Field SCANCODE_CTRL (Read only)
--
-- @field [parent=#global] #number SCANCODE_CTRL

---
-- Field SCANCODE_CURRENCYSUBUNIT (Read only)
--
-- @field [parent=#global] #number SCANCODE_CURRENCYSUBUNIT

---
-- Field SCANCODE_CURRENCYUNIT (Read only)
--
-- @field [parent=#global] #number SCANCODE_CURRENCYUNIT

---
-- Field SCANCODE_CUT (Read only)
--
-- @field [parent=#global] #number SCANCODE_CUT

---
-- Field SCANCODE_D (Read only)
--
-- @field [parent=#global] #number SCANCODE_D

---
-- Field SCANCODE_DECIMALSEPARATOR (Read only)
--
-- @field [parent=#global] #number SCANCODE_DECIMALSEPARATOR

---
-- Field SCANCODE_DELETE (Read only)
--
-- @field [parent=#global] #number SCANCODE_DELETE

---
-- Field SCANCODE_DISPLAYSWITCH (Read only)
--
-- @field [parent=#global] #number SCANCODE_DISPLAYSWITCH

---
-- Field SCANCODE_DOWN (Read only)
--
-- @field [parent=#global] #number SCANCODE_DOWN

---
-- Field SCANCODE_E (Read only)
--
-- @field [parent=#global] #number SCANCODE_E

---
-- Field SCANCODE_EJECT (Read only)
--
-- @field [parent=#global] #number SCANCODE_EJECT

---
-- Field SCANCODE_END (Read only)
--
-- @field [parent=#global] #number SCANCODE_END

---
-- Field SCANCODE_EQUALS (Read only)
--
-- @field [parent=#global] #number SCANCODE_EQUALS

---
-- Field SCANCODE_ESCAPE (Read only)
--
-- @field [parent=#global] #number SCANCODE_ESCAPE

---
-- Field SCANCODE_EXECUTE (Read only)
--
-- @field [parent=#global] #number SCANCODE_EXECUTE

---
-- Field SCANCODE_EXSEL (Read only)
--
-- @field [parent=#global] #number SCANCODE_EXSEL

---
-- Field SCANCODE_F (Read only)
--
-- @field [parent=#global] #number SCANCODE_F

---
-- Field SCANCODE_F1 (Read only)
--
-- @field [parent=#global] #number SCANCODE_F1

---
-- Field SCANCODE_F10 (Read only)
--
-- @field [parent=#global] #number SCANCODE_F10

---
-- Field SCANCODE_F11 (Read only)
--
-- @field [parent=#global] #number SCANCODE_F11

---
-- Field SCANCODE_F12 (Read only)
--
-- @field [parent=#global] #number SCANCODE_F12

---
-- Field SCANCODE_F13 (Read only)
--
-- @field [parent=#global] #number SCANCODE_F13

---
-- Field SCANCODE_F14 (Read only)
--
-- @field [parent=#global] #number SCANCODE_F14

---
-- Field SCANCODE_F15 (Read only)
--
-- @field [parent=#global] #number SCANCODE_F15

---
-- Field SCANCODE_F16 (Read only)
--
-- @field [parent=#global] #number SCANCODE_F16

---
-- Field SCANCODE_F17 (Read only)
--
-- @field [parent=#global] #number SCANCODE_F17

---
-- Field SCANCODE_F18 (Read only)
--
-- @field [parent=#global] #number SCANCODE_F18

---
-- Field SCANCODE_F19 (Read only)
--
-- @field [parent=#global] #number SCANCODE_F19

---
-- Field SCANCODE_F2 (Read only)
--
-- @field [parent=#global] #number SCANCODE_F2

---
-- Field SCANCODE_F20 (Read only)
--
-- @field [parent=#global] #number SCANCODE_F20

---
-- Field SCANCODE_F21 (Read only)
--
-- @field [parent=#global] #number SCANCODE_F21

---
-- Field SCANCODE_F22 (Read only)
--
-- @field [parent=#global] #number SCANCODE_F22

---
-- Field SCANCODE_F23 (Read only)
--
-- @field [parent=#global] #number SCANCODE_F23

---
-- Field SCANCODE_F24 (Read only)
--
-- @field [parent=#global] #number SCANCODE_F24

---
-- Field SCANCODE_F3 (Read only)
--
-- @field [parent=#global] #number SCANCODE_F3

---
-- Field SCANCODE_F4 (Read only)
--
-- @field [parent=#global] #number SCANCODE_F4

---
-- Field SCANCODE_F5 (Read only)
--
-- @field [parent=#global] #number SCANCODE_F5

---
-- Field SCANCODE_F6 (Read only)
--
-- @field [parent=#global] #number SCANCODE_F6

---
-- Field SCANCODE_F7 (Read only)
--
-- @field [parent=#global] #number SCANCODE_F7

---
-- Field SCANCODE_F8 (Read only)
--
-- @field [parent=#global] #number SCANCODE_F8

---
-- Field SCANCODE_F9 (Read only)
--
-- @field [parent=#global] #number SCANCODE_F9

---
-- Field SCANCODE_FIND (Read only)
--
-- @field [parent=#global] #number SCANCODE_FIND

---
-- Field SCANCODE_G (Read only)
--
-- @field [parent=#global] #number SCANCODE_G

---
-- Field SCANCODE_GRAVE (Read only)
--
-- @field [parent=#global] #number SCANCODE_GRAVE

---
-- Field SCANCODE_GUI (Read only)
--
-- @field [parent=#global] #number SCANCODE_GUI

---
-- Field SCANCODE_H (Read only)
--
-- @field [parent=#global] #number SCANCODE_H

---
-- Field SCANCODE_HELP (Read only)
--
-- @field [parent=#global] #number SCANCODE_HELP

---
-- Field SCANCODE_HOME (Read only)
--
-- @field [parent=#global] #number SCANCODE_HOME

---
-- Field SCANCODE_I (Read only)
--
-- @field [parent=#global] #number SCANCODE_I

---
-- Field SCANCODE_INSERT (Read only)
--
-- @field [parent=#global] #number SCANCODE_INSERT

---
-- Field SCANCODE_INTERNATIONAL1 (Read only)
--
-- @field [parent=#global] #number SCANCODE_INTERNATIONAL1

---
-- Field SCANCODE_INTERNATIONAL2 (Read only)
--
-- @field [parent=#global] #number SCANCODE_INTERNATIONAL2

---
-- Field SCANCODE_INTERNATIONAL3 (Read only)
--
-- @field [parent=#global] #number SCANCODE_INTERNATIONAL3

---
-- Field SCANCODE_INTERNATIONAL4 (Read only)
--
-- @field [parent=#global] #number SCANCODE_INTERNATIONAL4

---
-- Field SCANCODE_INTERNATIONAL5 (Read only)
--
-- @field [parent=#global] #number SCANCODE_INTERNATIONAL5

---
-- Field SCANCODE_INTERNATIONAL6 (Read only)
--
-- @field [parent=#global] #number SCANCODE_INTERNATIONAL6

---
-- Field SCANCODE_INTERNATIONAL7 (Read only)
--
-- @field [parent=#global] #number SCANCODE_INTERNATIONAL7

---
-- Field SCANCODE_INTERNATIONAL8 (Read only)
--
-- @field [parent=#global] #number SCANCODE_INTERNATIONAL8

---
-- Field SCANCODE_INTERNATIONAL9 (Read only)
--
-- @field [parent=#global] #number SCANCODE_INTERNATIONAL9

---
-- Field SCANCODE_J (Read only)
--
-- @field [parent=#global] #number SCANCODE_J

---
-- Field SCANCODE_K (Read only)
--
-- @field [parent=#global] #number SCANCODE_K

---
-- Field SCANCODE_KBDILLUMDOWN (Read only)
--
-- @field [parent=#global] #number SCANCODE_KBDILLUMDOWN

---
-- Field SCANCODE_KBDILLUMTOGGLE (Read only)
--
-- @field [parent=#global] #number SCANCODE_KBDILLUMTOGGLE

---
-- Field SCANCODE_KBDILLUMUP (Read only)
--
-- @field [parent=#global] #number SCANCODE_KBDILLUMUP

---
-- Field SCANCODE_KP_0 (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_0

---
-- Field SCANCODE_KP_00 (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_00

---
-- Field SCANCODE_KP_000 (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_000

---
-- Field SCANCODE_KP_1 (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_1

---
-- Field SCANCODE_KP_2 (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_2

---
-- Field SCANCODE_KP_3 (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_3

---
-- Field SCANCODE_KP_4 (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_4

---
-- Field SCANCODE_KP_5 (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_5

---
-- Field SCANCODE_KP_6 (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_6

---
-- Field SCANCODE_KP_7 (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_7

---
-- Field SCANCODE_KP_8 (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_8

---
-- Field SCANCODE_KP_9 (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_9

---
-- Field SCANCODE_KP_A (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_A

---
-- Field SCANCODE_KP_AMPERSAND (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_AMPERSAND

---
-- Field SCANCODE_KP_AT (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_AT

---
-- Field SCANCODE_KP_B (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_B

---
-- Field SCANCODE_KP_BACKSPACE (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_BACKSPACE

---
-- Field SCANCODE_KP_BINARY (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_BINARY

---
-- Field SCANCODE_KP_C (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_C

---
-- Field SCANCODE_KP_CLEAR (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_CLEAR

---
-- Field SCANCODE_KP_CLEARENTRY (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_CLEARENTRY

---
-- Field SCANCODE_KP_COLON (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_COLON

---
-- Field SCANCODE_KP_COMMA (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_COMMA

---
-- Field SCANCODE_KP_D (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_D

---
-- Field SCANCODE_KP_DBLAMPERSAND (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_DBLAMPERSAND

---
-- Field SCANCODE_KP_DBLVERTICALBAR (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_DBLVERTICALBAR

---
-- Field SCANCODE_KP_DECIMAL (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_DECIMAL

---
-- Field SCANCODE_KP_DIVIDE (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_DIVIDE

---
-- Field SCANCODE_KP_E (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_E

---
-- Field SCANCODE_KP_ENTER (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_ENTER

---
-- Field SCANCODE_KP_EQUALS (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_EQUALS

---
-- Field SCANCODE_KP_EQUALSAS400 (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_EQUALSAS400

---
-- Field SCANCODE_KP_EXCLAM (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_EXCLAM

---
-- Field SCANCODE_KP_F (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_F

---
-- Field SCANCODE_KP_GREATER (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_GREATER

---
-- Field SCANCODE_KP_HASH (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_HASH

---
-- Field SCANCODE_KP_HEXADECIMAL (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_HEXADECIMAL

---
-- Field SCANCODE_KP_LEFTBRACE (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_LEFTBRACE

---
-- Field SCANCODE_KP_LEFTPAREN (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_LEFTPAREN

---
-- Field SCANCODE_KP_LESS (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_LESS

---
-- Field SCANCODE_KP_MEMADD (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_MEMADD

---
-- Field SCANCODE_KP_MEMCLEAR (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_MEMCLEAR

---
-- Field SCANCODE_KP_MEMDIVIDE (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_MEMDIVIDE

---
-- Field SCANCODE_KP_MEMMULTIPLY (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_MEMMULTIPLY

---
-- Field SCANCODE_KP_MEMRECALL (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_MEMRECALL

---
-- Field SCANCODE_KP_MEMSTORE (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_MEMSTORE

---
-- Field SCANCODE_KP_MEMSUBTRACT (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_MEMSUBTRACT

---
-- Field SCANCODE_KP_MINUS (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_MINUS

---
-- Field SCANCODE_KP_MULTIPLY (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_MULTIPLY

---
-- Field SCANCODE_KP_OCTAL (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_OCTAL

---
-- Field SCANCODE_KP_PERCENT (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_PERCENT

---
-- Field SCANCODE_KP_PERIOD (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_PERIOD

---
-- Field SCANCODE_KP_PLUS (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_PLUS

---
-- Field SCANCODE_KP_PLUSMINUS (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_PLUSMINUS

---
-- Field SCANCODE_KP_POWER (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_POWER

---
-- Field SCANCODE_KP_RIGHTBRACE (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_RIGHTBRACE

---
-- Field SCANCODE_KP_RIGHTPAREN (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_RIGHTPAREN

---
-- Field SCANCODE_KP_SPACE (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_SPACE

---
-- Field SCANCODE_KP_TAB (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_TAB

---
-- Field SCANCODE_KP_VERTICALBAR (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_VERTICALBAR

---
-- Field SCANCODE_KP_XOR (Read only)
--
-- @field [parent=#global] #number SCANCODE_KP_XOR

---
-- Field SCANCODE_L (Read only)
--
-- @field [parent=#global] #number SCANCODE_L

---
-- Field SCANCODE_LALT (Read only)
--
-- @field [parent=#global] #number SCANCODE_LALT

---
-- Field SCANCODE_LANG1 (Read only)
--
-- @field [parent=#global] #number SCANCODE_LANG1

---
-- Field SCANCODE_LANG2 (Read only)
--
-- @field [parent=#global] #number SCANCODE_LANG2

---
-- Field SCANCODE_LANG3 (Read only)
--
-- @field [parent=#global] #number SCANCODE_LANG3

---
-- Field SCANCODE_LANG4 (Read only)
--
-- @field [parent=#global] #number SCANCODE_LANG4

---
-- Field SCANCODE_LANG5 (Read only)
--
-- @field [parent=#global] #number SCANCODE_LANG5

---
-- Field SCANCODE_LANG6 (Read only)
--
-- @field [parent=#global] #number SCANCODE_LANG6

---
-- Field SCANCODE_LANG7 (Read only)
--
-- @field [parent=#global] #number SCANCODE_LANG7

---
-- Field SCANCODE_LANG8 (Read only)
--
-- @field [parent=#global] #number SCANCODE_LANG8

---
-- Field SCANCODE_LANG9 (Read only)
--
-- @field [parent=#global] #number SCANCODE_LANG9

---
-- Field SCANCODE_LCTRL (Read only)
--
-- @field [parent=#global] #number SCANCODE_LCTRL

---
-- Field SCANCODE_LEFT (Read only)
--
-- @field [parent=#global] #number SCANCODE_LEFT

---
-- Field SCANCODE_LEFTBRACKET (Read only)
--
-- @field [parent=#global] #number SCANCODE_LEFTBRACKET

---
-- Field SCANCODE_LGUI (Read only)
--
-- @field [parent=#global] #number SCANCODE_LGUI

---
-- Field SCANCODE_LSHIFT (Read only)
--
-- @field [parent=#global] #number SCANCODE_LSHIFT

---
-- Field SCANCODE_M (Read only)
--
-- @field [parent=#global] #number SCANCODE_M

---
-- Field SCANCODE_MAIL (Read only)
--
-- @field [parent=#global] #number SCANCODE_MAIL

---
-- Field SCANCODE_MEDIASELECT (Read only)
--
-- @field [parent=#global] #number SCANCODE_MEDIASELECT

---
-- Field SCANCODE_MENU (Read only)
--
-- @field [parent=#global] #number SCANCODE_MENU

---
-- Field SCANCODE_MINUS (Read only)
--
-- @field [parent=#global] #number SCANCODE_MINUS

---
-- Field SCANCODE_MODE (Read only)
--
-- @field [parent=#global] #number SCANCODE_MODE

---
-- Field SCANCODE_MUTE (Read only)
--
-- @field [parent=#global] #number SCANCODE_MUTE

---
-- Field SCANCODE_N (Read only)
--
-- @field [parent=#global] #number SCANCODE_N

---
-- Field SCANCODE_NONUSBACKSLASH (Read only)
--
-- @field [parent=#global] #number SCANCODE_NONUSBACKSLASH

---
-- Field SCANCODE_NONUSHASH (Read only)
--
-- @field [parent=#global] #number SCANCODE_NONUSHASH

---
-- Field SCANCODE_NUMLOCKCLEAR (Read only)
--
-- @field [parent=#global] #number SCANCODE_NUMLOCKCLEAR

---
-- Field SCANCODE_O (Read only)
--
-- @field [parent=#global] #number SCANCODE_O

---
-- Field SCANCODE_OPER (Read only)
--
-- @field [parent=#global] #number SCANCODE_OPER

---
-- Field SCANCODE_OUT (Read only)
--
-- @field [parent=#global] #number SCANCODE_OUT

---
-- Field SCANCODE_P (Read only)
--
-- @field [parent=#global] #number SCANCODE_P

---
-- Field SCANCODE_PAGEDOWN (Read only)
--
-- @field [parent=#global] #number SCANCODE_PAGEDOWN

---
-- Field SCANCODE_PAGEUP (Read only)
--
-- @field [parent=#global] #number SCANCODE_PAGEUP

---
-- Field SCANCODE_PASTE (Read only)
--
-- @field [parent=#global] #number SCANCODE_PASTE

---
-- Field SCANCODE_PAUSE (Read only)
--
-- @field [parent=#global] #number SCANCODE_PAUSE

---
-- Field SCANCODE_PERIOD (Read only)
--
-- @field [parent=#global] #number SCANCODE_PERIOD

---
-- Field SCANCODE_POWER (Read only)
--
-- @field [parent=#global] #number SCANCODE_POWER

---
-- Field SCANCODE_PRINTSCREEN (Read only)
--
-- @field [parent=#global] #number SCANCODE_PRINTSCREEN

---
-- Field SCANCODE_PRIOR (Read only)
--
-- @field [parent=#global] #number SCANCODE_PRIOR

---
-- Field SCANCODE_Q (Read only)
--
-- @field [parent=#global] #number SCANCODE_Q

---
-- Field SCANCODE_R (Read only)
--
-- @field [parent=#global] #number SCANCODE_R

---
-- Field SCANCODE_RALT (Read only)
--
-- @field [parent=#global] #number SCANCODE_RALT

---
-- Field SCANCODE_RCTRL (Read only)
--
-- @field [parent=#global] #number SCANCODE_RCTRL

---
-- Field SCANCODE_RETURN (Read only)
--
-- @field [parent=#global] #number SCANCODE_RETURN

---
-- Field SCANCODE_RETURN2 (Read only)
--
-- @field [parent=#global] #number SCANCODE_RETURN2

---
-- Field SCANCODE_RGUI (Read only)
--
-- @field [parent=#global] #number SCANCODE_RGUI

---
-- Field SCANCODE_RIGHT (Read only)
--
-- @field [parent=#global] #number SCANCODE_RIGHT

---
-- Field SCANCODE_RIGHTBRACKET (Read only)
--
-- @field [parent=#global] #number SCANCODE_RIGHTBRACKET

---
-- Field SCANCODE_RSHIFT (Read only)
--
-- @field [parent=#global] #number SCANCODE_RSHIFT

---
-- Field SCANCODE_S (Read only)
--
-- @field [parent=#global] #number SCANCODE_S

---
-- Field SCANCODE_SCROLLLOCK (Read only)
--
-- @field [parent=#global] #number SCANCODE_SCROLLLOCK

---
-- Field SCANCODE_SELECT (Read only)
--
-- @field [parent=#global] #number SCANCODE_SELECT

---
-- Field SCANCODE_SEMICOLON (Read only)
--
-- @field [parent=#global] #number SCANCODE_SEMICOLON

---
-- Field SCANCODE_SEPARATOR (Read only)
--
-- @field [parent=#global] #number SCANCODE_SEPARATOR

---
-- Field SCANCODE_SHIFT (Read only)
--
-- @field [parent=#global] #number SCANCODE_SHIFT

---
-- Field SCANCODE_SLASH (Read only)
--
-- @field [parent=#global] #number SCANCODE_SLASH

---
-- Field SCANCODE_SLEEP (Read only)
--
-- @field [parent=#global] #number SCANCODE_SLEEP

---
-- Field SCANCODE_SPACE (Read only)
--
-- @field [parent=#global] #number SCANCODE_SPACE

---
-- Field SCANCODE_STOP (Read only)
--
-- @field [parent=#global] #number SCANCODE_STOP

---
-- Field SCANCODE_SYSREQ (Read only)
--
-- @field [parent=#global] #number SCANCODE_SYSREQ

---
-- Field SCANCODE_T (Read only)
--
-- @field [parent=#global] #number SCANCODE_T

---
-- Field SCANCODE_TAB (Read only)
--
-- @field [parent=#global] #number SCANCODE_TAB

---
-- Field SCANCODE_THOUSANDSSEPARATOR (Read only)
--
-- @field [parent=#global] #number SCANCODE_THOUSANDSSEPARATOR

---
-- Field SCANCODE_U (Read only)
--
-- @field [parent=#global] #number SCANCODE_U

---
-- Field SCANCODE_UNDO (Read only)
--
-- @field [parent=#global] #number SCANCODE_UNDO

---
-- Field SCANCODE_UNKNOWN (Read only)
--
-- @field [parent=#global] #number SCANCODE_UNKNOWN

---
-- Field SCANCODE_UP (Read only)
--
-- @field [parent=#global] #number SCANCODE_UP

---
-- Field SCANCODE_V (Read only)
--
-- @field [parent=#global] #number SCANCODE_V

---
-- Field SCANCODE_VOLUMEDOWN (Read only)
--
-- @field [parent=#global] #number SCANCODE_VOLUMEDOWN

---
-- Field SCANCODE_VOLUMEUP (Read only)
--
-- @field [parent=#global] #number SCANCODE_VOLUMEUP

---
-- Field SCANCODE_W (Read only)
--
-- @field [parent=#global] #number SCANCODE_W

---
-- Field SCANCODE_WWW (Read only)
--
-- @field [parent=#global] #number SCANCODE_WWW

---
-- Field SCANCODE_X (Read only)
--
-- @field [parent=#global] #number SCANCODE_X

---
-- Field SCANCODE_Y (Read only)
--
-- @field [parent=#global] #number SCANCODE_Y

---
-- Field SCANCODE_Z (Read only)
--
-- @field [parent=#global] #number SCANCODE_Z

---
-- Field SCAN_DIRS (Read only)
--
-- @field [parent=#global] #number SCAN_DIRS

---
-- Field SCAN_FILES (Read only)
--
-- @field [parent=#global] #number SCAN_FILES

---
-- Field SCAN_HIDDEN (Read only)
--
-- @field [parent=#global] #number SCAN_HIDDEN

---
-- Field SHADOWQUALITY_HIGH_16BIT (Read only)
--
-- @field [parent=#global] #number SHADOWQUALITY_HIGH_16BIT

---
-- Field SHADOWQUALITY_HIGH_24BIT (Read only)
--
-- @field [parent=#global] #number SHADOWQUALITY_HIGH_24BIT

---
-- Field SHADOWQUALITY_LOW_16BIT (Read only)
--
-- @field [parent=#global] #number SHADOWQUALITY_LOW_16BIT

---
-- Field SHADOWQUALITY_LOW_24BIT (Read only)
--
-- @field [parent=#global] #number SHADOWQUALITY_LOW_24BIT

---
-- Field VO_DISABLE_OCCLUSION (Read only)
--
-- @field [parent=#global] #number VO_DISABLE_OCCLUSION

---
-- Field VO_DISABLE_SHADOWS (Read only)
--
-- @field [parent=#global] #number VO_DISABLE_SHADOWS

---
-- Field VO_LOW_MATERIAL_QUALITY (Read only)
--
-- @field [parent=#global] #number VO_LOW_MATERIAL_QUALITY

---
-- Field VO_NONE (Read only)
--
-- @field [parent=#global] #number VO_NONE


---
-- Enumeration value BlendMode.BLEND_REPLACE
--
-- @field [parent=#global] #number BLEND_REPLACE

---
-- Enumeration value BlendMode.BLEND_ADD
--
-- @field [parent=#global] #number BLEND_ADD

---
-- Enumeration value BlendMode.BLEND_MULTIPLY
--
-- @field [parent=#global] #number BLEND_MULTIPLY

---
-- Enumeration value BlendMode.BLEND_ALPHA
--
-- @field [parent=#global] #number BLEND_ALPHA

---
-- Enumeration value BlendMode.BLEND_ADDALPHA
--
-- @field [parent=#global] #number BLEND_ADDALPHA

---
-- Enumeration value BlendMode.BLEND_PREMULALPHA
--
-- @field [parent=#global] #number BLEND_PREMULALPHA

---
-- Enumeration value BlendMode.BLEND_INVDESTALPHA
--
-- @field [parent=#global] #number BLEND_INVDESTALPHA

---
-- Enumeration value BlendMode.BLEND_SUBTRACT
--
-- @field [parent=#global] #number BLEND_SUBTRACT

---
-- Enumeration value BlendMode.BLEND_SUBTRACTALPHA
--
-- @field [parent=#global] #number BLEND_SUBTRACTALPHA

---
-- Enumeration value BlendMode.MAX_BLENDMODES
--
-- @field [parent=#global] #number MAX_BLENDMODES


---
-- Enumeration value BodyType2D.BT_STATIC
--
-- @field [parent=#global] #number BT_STATIC

---
-- Enumeration value BodyType2D.BT_DYNAMIC
--
-- @field [parent=#global] #number BT_DYNAMIC

---
-- Enumeration value BodyType2D.BT_KINEMATIC
--
-- @field [parent=#global] #number BT_KINEMATIC


---
-- Enumeration value CollisionEventMode.COLLISION_NEVER
--
-- @field [parent=#global] #number COLLISION_NEVER

---
-- Enumeration value CollisionEventMode.COLLISION_ACTIVE
--
-- @field [parent=#global] #number COLLISION_ACTIVE

---
-- Enumeration value CollisionEventMode.COLLISION_ALWAYS
--
-- @field [parent=#global] #number COLLISION_ALWAYS


---
-- Enumeration value CompareMode.CMP_ALWAYS
--
-- @field [parent=#global] #number CMP_ALWAYS

---
-- Enumeration value CompareMode.CMP_EQUAL
--
-- @field [parent=#global] #number CMP_EQUAL

---
-- Enumeration value CompareMode.CMP_NOTEQUAL
--
-- @field [parent=#global] #number CMP_NOTEQUAL

---
-- Enumeration value CompareMode.CMP_LESS
--
-- @field [parent=#global] #number CMP_LESS

---
-- Enumeration value CompareMode.CMP_LESSEQUAL
--
-- @field [parent=#global] #number CMP_LESSEQUAL

---
-- Enumeration value CompareMode.CMP_GREATER
--
-- @field [parent=#global] #number CMP_GREATER

---
-- Enumeration value CompareMode.CMP_GREATEREQUAL
--
-- @field [parent=#global] #number CMP_GREATEREQUAL

---
-- Enumeration value CompareMode.MAX_COMPAREMODES
--
-- @field [parent=#global] #number MAX_COMPAREMODES


---
-- Enumeration value CompressedFormat.CF_NONE
--
-- @field [parent=#global] #number CF_NONE

---
-- Enumeration value CompressedFormat.CF_DXT1
--
-- @field [parent=#global] #number CF_DXT1

---
-- Enumeration value CompressedFormat.CF_DXT3
--
-- @field [parent=#global] #number CF_DXT3

---
-- Enumeration value CompressedFormat.CF_DXT5
--
-- @field [parent=#global] #number CF_DXT5

---
-- Enumeration value CompressedFormat.CF_ETC1
--
-- @field [parent=#global] #number CF_ETC1

---
-- Enumeration value CompressedFormat.CF_PVRTC_RGB_2BPP
--
-- @field [parent=#global] #number CF_PVRTC_RGB_2BPP

---
-- Enumeration value CompressedFormat.CF_PVRTC_RGBA_2BPP
--
-- @field [parent=#global] #number CF_PVRTC_RGBA_2BPP

---
-- Enumeration value CompressedFormat.CF_PVRTC_RGB_4BPP
--
-- @field [parent=#global] #number CF_PVRTC_RGB_4BPP

---
-- Enumeration value CompressedFormat.CF_PVRTC_RGBA_4BPP
--
-- @field [parent=#global] #number CF_PVRTC_RGBA_4BPP


---
-- Enumeration value ConstraintType.CONSTRAINT_POINT
--
-- @field [parent=#global] #number CONSTRAINT_POINT

---
-- Enumeration value ConstraintType.CONSTRAINT_HINGE
--
-- @field [parent=#global] #number CONSTRAINT_HINGE

---
-- Enumeration value ConstraintType.CONSTRAINT_SLIDER
--
-- @field [parent=#global] #number CONSTRAINT_SLIDER

---
-- Enumeration value ConstraintType.CONSTRAINT_CONETWIST
--
-- @field [parent=#global] #number CONSTRAINT_CONETWIST


---
-- Enumeration value Corner.C_TOPLEFT
--
-- @field [parent=#global] #number C_TOPLEFT

---
-- Enumeration value Corner.C_TOPRIGHT
--
-- @field [parent=#global] #number C_TOPRIGHT

---
-- Enumeration value Corner.C_BOTTOMLEFT
--
-- @field [parent=#global] #number C_BOTTOMLEFT

---
-- Enumeration value Corner.C_BOTTOMRIGHT
--
-- @field [parent=#global] #number C_BOTTOMRIGHT

---
-- Enumeration value Corner.MAX_UIELEMENT_CORNERS
--
-- @field [parent=#global] #number MAX_UIELEMENT_CORNERS


---
-- Enumeration value CreateMode.REPLICATED
--
-- @field [parent=#global] #number REPLICATED

---
-- Enumeration value CreateMode.LOCAL
--
-- @field [parent=#global] #number LOCAL


---
-- Enumeration value CubeMapFace.FACE_POSITIVE_X
--
-- @field [parent=#global] #number FACE_POSITIVE_X

---
-- Enumeration value CubeMapFace.FACE_NEGATIVE_X
--
-- @field [parent=#global] #number FACE_NEGATIVE_X

---
-- Enumeration value CubeMapFace.FACE_POSITIVE_Y
--
-- @field [parent=#global] #number FACE_POSITIVE_Y

---
-- Enumeration value CubeMapFace.FACE_NEGATIVE_Y
--
-- @field [parent=#global] #number FACE_NEGATIVE_Y

---
-- Enumeration value CubeMapFace.FACE_POSITIVE_Z
--
-- @field [parent=#global] #number FACE_POSITIVE_Z

---
-- Enumeration value CubeMapFace.FACE_NEGATIVE_Z
--
-- @field [parent=#global] #number FACE_NEGATIVE_Z

---
-- Enumeration value CubeMapFace.MAX_CUBEMAP_FACES
--
-- @field [parent=#global] #number MAX_CUBEMAP_FACES


---
-- Enumeration value CullMode.CULL_NONE
--
-- @field [parent=#global] #number CULL_NONE

---
-- Enumeration value CullMode.CULL_CCW
--
-- @field [parent=#global] #number CULL_CCW

---
-- Enumeration value CullMode.CULL_CW
--
-- @field [parent=#global] #number CULL_CW

---
-- Enumeration value CullMode.MAX_CULLMODES
--
-- @field [parent=#global] #number MAX_CULLMODES


---
-- Enumeration value CursorShape.CS_NORMAL
--
-- @field [parent=#global] #number CS_NORMAL

---
-- Enumeration value CursorShape.CS_RESIZEVERTICAL
--
-- @field [parent=#global] #number CS_RESIZEVERTICAL

---
-- Enumeration value CursorShape.CS_RESIZEDIAGONAL_TOPRIGHT
--
-- @field [parent=#global] #number CS_RESIZEDIAGONAL_TOPRIGHT

---
-- Enumeration value CursorShape.CS_RESIZEHORIZONTAL
--
-- @field [parent=#global] #number CS_RESIZEHORIZONTAL

---
-- Enumeration value CursorShape.CS_RESIZEDIAGONAL_TOPLEFT
--
-- @field [parent=#global] #number CS_RESIZEDIAGONAL_TOPLEFT

---
-- Enumeration value CursorShape.CS_ACCEPTDROP
--
-- @field [parent=#global] #number CS_ACCEPTDROP

---
-- Enumeration value CursorShape.CS_REJECTDROP
--
-- @field [parent=#global] #number CS_REJECTDROP

---
-- Enumeration value CursorShape.CS_BUSY
--
-- @field [parent=#global] #number CS_BUSY

---
-- Enumeration value CursorShape.CS_MAX_SHAPES
--
-- @field [parent=#global] #number CS_MAX_SHAPES


---
-- Enumeration value CycleMode.CM_LOOP
--
-- @field [parent=#global] #number CM_LOOP

---
-- Enumeration value CycleMode.CM_CLAMP
--
-- @field [parent=#global] #number CM_CLAMP

---
-- Enumeration value CycleMode.CM_PINGPONG
--
-- @field [parent=#global] #number CM_PINGPONG


---
-- Enumeration value EmitterType.EMITTER_SPHERE
--
-- @field [parent=#global] #number EMITTER_SPHERE

---
-- Enumeration value EmitterType.EMITTER_BOX
--
-- @field [parent=#global] #number EMITTER_BOX


---
-- Enumeration value EmitterType2D.EMITTER_TYPE_GRAVITY
--
-- @field [parent=#global] #number EMITTER_TYPE_GRAVITY

---
-- Enumeration value EmitterType2D.EMITTER_TYPE_RADIAL
--
-- @field [parent=#global] #number EMITTER_TYPE_RADIAL


---
-- Enumeration value FaceCameraMode.FC_NONE
--
-- @field [parent=#global] #number FC_NONE

---
-- Enumeration value FaceCameraMode.FC_ROTATE_XYZ
--
-- @field [parent=#global] #number FC_ROTATE_XYZ

---
-- Enumeration value FaceCameraMode.FC_ROTATE_Y
--
-- @field [parent=#global] #number FC_ROTATE_Y

---
-- Enumeration value FaceCameraMode.FC_LOOKAT_XYZ
--
-- @field [parent=#global] #number FC_LOOKAT_XYZ

---
-- Enumeration value FaceCameraMode.FC_LOOKAT_Y
--
-- @field [parent=#global] #number FC_LOOKAT_Y


---
-- Enumeration value FileMode.FILE_READ
--
-- @field [parent=#global] #number FILE_READ

---
-- Enumeration value FileMode.FILE_WRITE
--
-- @field [parent=#global] #number FILE_WRITE

---
-- Enumeration value FileMode.FILE_READWRITE
--
-- @field [parent=#global] #number FILE_READWRITE


---
-- Enumeration value FillMode.FILL_SOLID
--
-- @field [parent=#global] #number FILL_SOLID

---
-- Enumeration value FillMode.FILL_WIREFRAME
--
-- @field [parent=#global] #number FILL_WIREFRAME

---
-- Enumeration value FillMode.FILL_POINT
--
-- @field [parent=#global] #number FILL_POINT


---
-- Enumeration value FocusMode.FM_NOTFOCUSABLE
--
-- @field [parent=#global] #number FM_NOTFOCUSABLE

---
-- Enumeration value FocusMode.FM_RESETFOCUS
--
-- @field [parent=#global] #number FM_RESETFOCUS

---
-- Enumeration value FocusMode.FM_FOCUSABLE
--
-- @field [parent=#global] #number FM_FOCUSABLE

---
-- Enumeration value FocusMode.FM_FOCUSABLE_DEFOCUSABLE
--
-- @field [parent=#global] #number FM_FOCUSABLE_DEFOCUSABLE


---
-- Enumeration value FrustumPlane.PLANE_NEAR
--
-- @field [parent=#global] #number PLANE_NEAR

---
-- Enumeration value FrustumPlane.PLANE_LEFT
--
-- @field [parent=#global] #number PLANE_LEFT

---
-- Enumeration value FrustumPlane.PLANE_RIGHT
--
-- @field [parent=#global] #number PLANE_RIGHT

---
-- Enumeration value FrustumPlane.PLANE_UP
--
-- @field [parent=#global] #number PLANE_UP

---
-- Enumeration value FrustumPlane.PLANE_DOWN
--
-- @field [parent=#global] #number PLANE_DOWN

---
-- Enumeration value FrustumPlane.PLANE_FAR
--
-- @field [parent=#global] #number PLANE_FAR


---
-- Enumeration value GeometryType.GEOM_STATIC
--
-- @field [parent=#global] #number GEOM_STATIC

---
-- Enumeration value GeometryType.GEOM_SKINNED
--
-- @field [parent=#global] #number GEOM_SKINNED

---
-- Enumeration value GeometryType.GEOM_INSTANCED
--
-- @field [parent=#global] #number GEOM_INSTANCED

---
-- Enumeration value GeometryType.GEOM_BILLBOARD
--
-- @field [parent=#global] #number GEOM_BILLBOARD

---
-- Enumeration value GeometryType.GEOM_STATIC_NOINSTANCING
--
-- @field [parent=#global] #number GEOM_STATIC_NOINSTANCING

---
-- Enumeration value GeometryType.MAX_GEOMETRYTYPES
--
-- @field [parent=#global] #number MAX_GEOMETRYTYPES


---
-- Enumeration value HighlightMode.HM_NEVER
--
-- @field [parent=#global] #number HM_NEVER

---
-- Enumeration value HighlightMode.HM_FOCUS
--
-- @field [parent=#global] #number HM_FOCUS

---
-- Enumeration value HighlightMode.HM_ALWAYS
--
-- @field [parent=#global] #number HM_ALWAYS


---
-- Enumeration value HorizontalAlignment.HA_LEFT
--
-- @field [parent=#global] #number HA_LEFT

---
-- Enumeration value HorizontalAlignment.HA_CENTER
--
-- @field [parent=#global] #number HA_CENTER

---
-- Enumeration value HorizontalAlignment.HA_RIGHT
--
-- @field [parent=#global] #number HA_RIGHT


---
-- Enumeration value HttpRequestState.HTTP_INITIALIZING
--
-- @field [parent=#global] #number HTTP_INITIALIZING

---
-- Enumeration value HttpRequestState.HTTP_ERROR
--
-- @field [parent=#global] #number HTTP_ERROR

---
-- Enumeration value HttpRequestState.HTTP_OPEN
--
-- @field [parent=#global] #number HTTP_OPEN

---
-- Enumeration value HttpRequestState.HTTP_CLOSED
--
-- @field [parent=#global] #number HTTP_CLOSED


---
-- Enumeration value InterpMethod.IM_LINEAR
--
-- @field [parent=#global] #number IM_LINEAR

---
-- Enumeration value InterpMethod.IM_SPLINE
--
-- @field [parent=#global] #number IM_SPLINE


---
-- Enumeration value InterpolationMode.BEZIER_CURVE
--
-- @field [parent=#global] #number BEZIER_CURVE


---
-- Enumeration value Intersection.OUTSIDE
--
-- @field [parent=#global] #number OUTSIDE

---
-- Enumeration value Intersection.INTERSECTS
--
-- @field [parent=#global] #number INTERSECTS

---
-- Enumeration value Intersection.INSIDE
--
-- @field [parent=#global] #number INSIDE


---
-- Enumeration value JSONValueType.JSON_ANY
--
-- @field [parent=#global] #number JSON_ANY

---
-- Enumeration value JSONValueType.JSON_OBJECT
--
-- @field [parent=#global] #number JSON_OBJECT

---
-- Enumeration value JSONValueType.JSON_ARRAY
--
-- @field [parent=#global] #number JSON_ARRAY


---
-- Enumeration value LayoutMode.LM_FREE
--
-- @field [parent=#global] #number LM_FREE

---
-- Enumeration value LayoutMode.LM_HORIZONTAL
--
-- @field [parent=#global] #number LM_HORIZONTAL

---
-- Enumeration value LayoutMode.LM_VERTICAL
--
-- @field [parent=#global] #number LM_VERTICAL


---
-- Enumeration value LightType.LIGHT_DIRECTIONAL
--
-- @field [parent=#global] #number LIGHT_DIRECTIONAL

---
-- Enumeration value LightType.LIGHT_SPOT
--
-- @field [parent=#global] #number LIGHT_SPOT

---
-- Enumeration value LightType.LIGHT_POINT
--
-- @field [parent=#global] #number LIGHT_POINT


---
-- Enumeration value LockState.LOCK_NONE
--
-- @field [parent=#global] #number LOCK_NONE

---
-- Enumeration value LockState.LOCK_HARDWARE
--
-- @field [parent=#global] #number LOCK_HARDWARE

---
-- Enumeration value LockState.LOCK_SHADOW
--
-- @field [parent=#global] #number LOCK_SHADOW

---
-- Enumeration value LockState.LOCK_SCRATCH
--
-- @field [parent=#global] #number LOCK_SCRATCH


---
-- Enumeration value Orientation.O_HORIZONTAL
--
-- @field [parent=#global] #number O_HORIZONTAL

---
-- Enumeration value Orientation.O_VERTICAL
--
-- @field [parent=#global] #number O_VERTICAL


---
-- Enumeration value PassLightingMode.LIGHTING_UNLIT
--
-- @field [parent=#global] #number LIGHTING_UNLIT

---
-- Enumeration value PassLightingMode.LIGHTING_PERVERTEX
--
-- @field [parent=#global] #number LIGHTING_PERVERTEX

---
-- Enumeration value PassLightingMode.LIGHTING_PERPIXEL
--
-- @field [parent=#global] #number LIGHTING_PERPIXEL


---
-- Enumeration value PrimitiveType.TRIANGLE_LIST
--
-- @field [parent=#global] #number TRIANGLE_LIST

---
-- Enumeration value PrimitiveType.LINE_LIST
--
-- @field [parent=#global] #number LINE_LIST


---
-- Enumeration value RayQueryLevel.RAY_AABB
--
-- @field [parent=#global] #number RAY_AABB

---
-- Enumeration value RayQueryLevel.RAY_OBB
--
-- @field [parent=#global] #number RAY_OBB

---
-- Enumeration value RayQueryLevel.RAY_TRIANGLE
--
-- @field [parent=#global] #number RAY_TRIANGLE


---
-- Enumeration value RenderSurfaceUpdateMode.SURFACE_MANUALUPDATE
--
-- @field [parent=#global] #number SURFACE_MANUALUPDATE

---
-- Enumeration value RenderSurfaceUpdateMode.SURFACE_UPDATEVISIBLE
--
-- @field [parent=#global] #number SURFACE_UPDATEVISIBLE

---
-- Enumeration value RenderSurfaceUpdateMode.SURFACE_UPDATEALWAYS
--
-- @field [parent=#global] #number SURFACE_UPDATEALWAYS


---
-- Enumeration value ShaderParameterGroup.SP_FRAME
--
-- @field [parent=#global] #number SP_FRAME

---
-- Enumeration value ShaderParameterGroup.SP_CAMERA
--
-- @field [parent=#global] #number SP_CAMERA

---
-- Enumeration value ShaderParameterGroup.SP_VIEWPORT
--
-- @field [parent=#global] #number SP_VIEWPORT

---
-- Enumeration value ShaderParameterGroup.SP_ZONE
--
-- @field [parent=#global] #number SP_ZONE

---
-- Enumeration value ShaderParameterGroup.SP_LIGHT
--
-- @field [parent=#global] #number SP_LIGHT

---
-- Enumeration value ShaderParameterGroup.SP_VERTEXLIGHTS
--
-- @field [parent=#global] #number SP_VERTEXLIGHTS

---
-- Enumeration value ShaderParameterGroup.SP_MATERIAL
--
-- @field [parent=#global] #number SP_MATERIAL

---
-- Enumeration value ShaderParameterGroup.SP_OBJECTTRANSFORM
--
-- @field [parent=#global] #number SP_OBJECTTRANSFORM

---
-- Enumeration value ShaderParameterGroup.MAX_SHADER_PARAMETER_GROUPS
--
-- @field [parent=#global] #number MAX_SHADER_PARAMETER_GROUPS


---
-- Enumeration value ShaderType.VS
--
-- @field [parent=#global] #number VS

---
-- Enumeration value ShaderType.PS
--
-- @field [parent=#global] #number PS


---
-- Enumeration value ShapeType.SHAPE_BOX
--
-- @field [parent=#global] #number SHAPE_BOX

---
-- Enumeration value ShapeType.SHAPE_SPHERE
--
-- @field [parent=#global] #number SHAPE_SPHERE

---
-- Enumeration value ShapeType.SHAPE_STATICPLANE
--
-- @field [parent=#global] #number SHAPE_STATICPLANE

---
-- Enumeration value ShapeType.SHAPE_CYLINDER
--
-- @field [parent=#global] #number SHAPE_CYLINDER

---
-- Enumeration value ShapeType.SHAPE_CAPSULE
--
-- @field [parent=#global] #number SHAPE_CAPSULE

---
-- Enumeration value ShapeType.SHAPE_CONE
--
-- @field [parent=#global] #number SHAPE_CONE

---
-- Enumeration value ShapeType.SHAPE_TRIANGLEMESH
--
-- @field [parent=#global] #number SHAPE_TRIANGLEMESH

---
-- Enumeration value ShapeType.SHAPE_CONVEXHULL
--
-- @field [parent=#global] #number SHAPE_CONVEXHULL

---
-- Enumeration value ShapeType.SHAPE_TERRAIN
--
-- @field [parent=#global] #number SHAPE_TERRAIN


---
-- Enumeration value SoundType.SOUND_EFFECT
--
-- @field [parent=#global] #number SOUND_EFFECT

---
-- Enumeration value SoundType.SOUND_AMBIENT
--
-- @field [parent=#global] #number SOUND_AMBIENT

---
-- Enumeration value SoundType.SOUND_VOICE
--
-- @field [parent=#global] #number SOUND_VOICE

---
-- Enumeration value SoundType.SOUND_MUSIC
--
-- @field [parent=#global] #number SOUND_MUSIC

---
-- Enumeration value SoundType.SOUND_MASTER
--
-- @field [parent=#global] #number SOUND_MASTER

---
-- Enumeration value SoundType.MAX_SOUND_TYPES
--
-- @field [parent=#global] #number MAX_SOUND_TYPES


---
-- Enumeration value StencilOp.OP_KEEP
--
-- @field [parent=#global] #number OP_KEEP

---
-- Enumeration value StencilOp.OP_ZERO
--
-- @field [parent=#global] #number OP_ZERO

---
-- Enumeration value StencilOp.OP_REF
--
-- @field [parent=#global] #number OP_REF

---
-- Enumeration value StencilOp.OP_INCR
--
-- @field [parent=#global] #number OP_INCR

---
-- Enumeration value StencilOp.OP_DECR
--
-- @field [parent=#global] #number OP_DECR


---
-- Enumeration value TextEffect.TE_NONE
--
-- @field [parent=#global] #number TE_NONE

---
-- Enumeration value TextEffect.TE_SHADOW
--
-- @field [parent=#global] #number TE_SHADOW

---
-- Enumeration value TextEffect.TE_STROKE
--
-- @field [parent=#global] #number TE_STROKE


---
-- Enumeration value TextureAddressMode.ADDRESS_WRAP
--
-- @field [parent=#global] #number ADDRESS_WRAP

---
-- Enumeration value TextureAddressMode.ADDRESS_MIRROR
--
-- @field [parent=#global] #number ADDRESS_MIRROR

---
-- Enumeration value TextureAddressMode.ADDRESS_CLAMP
--
-- @field [parent=#global] #number ADDRESS_CLAMP

---
-- Enumeration value TextureAddressMode.ADDRESS_BORDER
--
-- @field [parent=#global] #number ADDRESS_BORDER

---
-- Enumeration value TextureAddressMode.MAX_ADDRESSMODES
--
-- @field [parent=#global] #number MAX_ADDRESSMODES


---
-- Enumeration value TextureCoordinate.COORD_U
--
-- @field [parent=#global] #number COORD_U

---
-- Enumeration value TextureCoordinate.COORD_V
--
-- @field [parent=#global] #number COORD_V

---
-- Enumeration value TextureCoordinate.COORD_W
--
-- @field [parent=#global] #number COORD_W

---
-- Enumeration value TextureCoordinate.MAX_COORDS
--
-- @field [parent=#global] #number MAX_COORDS


---
-- Enumeration value TextureFilterMode.FILTER_NEAREST
--
-- @field [parent=#global] #number FILTER_NEAREST

---
-- Enumeration value TextureFilterMode.FILTER_BILINEAR
--
-- @field [parent=#global] #number FILTER_BILINEAR

---
-- Enumeration value TextureFilterMode.FILTER_TRILINEAR
--
-- @field [parent=#global] #number FILTER_TRILINEAR

---
-- Enumeration value TextureFilterMode.FILTER_ANISOTROPIC
--
-- @field [parent=#global] #number FILTER_ANISOTROPIC

---
-- Enumeration value TextureFilterMode.FILTER_DEFAULT
--
-- @field [parent=#global] #number FILTER_DEFAULT

---
-- Enumeration value TextureFilterMode.MAX_FILTERMODES
--
-- @field [parent=#global] #number MAX_FILTERMODES


---
-- Enumeration value TextureUnit.TU_DIFFUSE
--
-- @field [parent=#global] #number TU_DIFFUSE

---
-- Enumeration value TextureUnit.TU_ALBEDOBUFFER
--
-- @field [parent=#global] #number TU_ALBEDOBUFFER

---
-- Enumeration value TextureUnit.TU_NORMAL
--
-- @field [parent=#global] #number TU_NORMAL

---
-- Enumeration value TextureUnit.TU_NORMALBUFFER
--
-- @field [parent=#global] #number TU_NORMALBUFFER

---
-- Enumeration value TextureUnit.TU_SPECULAR
--
-- @field [parent=#global] #number TU_SPECULAR

---
-- Enumeration value TextureUnit.TU_EMISSIVE
--
-- @field [parent=#global] #number TU_EMISSIVE

---
-- Enumeration value TextureUnit.TU_ENVIRONMENT
--
-- @field [parent=#global] #number TU_ENVIRONMENT

---
-- Enumeration value TextureUnit.MAX_MATERIAL_TEXTURE_UNITS
--
-- @field [parent=#global] #number MAX_MATERIAL_TEXTURE_UNITS

---
-- Enumeration value TextureUnit.TU_LIGHTRAMP
--
-- @field [parent=#global] #number TU_LIGHTRAMP

---
-- Enumeration value TextureUnit.TU_LIGHTSHAPE
--
-- @field [parent=#global] #number TU_LIGHTSHAPE

---
-- Enumeration value TextureUnit.TU_SHADOWMAP
--
-- @field [parent=#global] #number TU_SHADOWMAP

---
-- Enumeration value TextureUnit.TU_FACESELECT
--
-- @field [parent=#global] #number TU_FACESELECT

---
-- Enumeration value TextureUnit.TU_INDIRECTION
--
-- @field [parent=#global] #number TU_INDIRECTION

---
-- Enumeration value TextureUnit.TU_DEPTHBUFFER
--
-- @field [parent=#global] #number TU_DEPTHBUFFER

---
-- Enumeration value TextureUnit.TU_LIGHTBUFFER
--
-- @field [parent=#global] #number TU_LIGHTBUFFER

---
-- Enumeration value TextureUnit.TU_VOLUMEMAP
--
-- @field [parent=#global] #number TU_VOLUMEMAP

---
-- Enumeration value TextureUnit.MAX_TEXTURE_UNITS
--
-- @field [parent=#global] #number MAX_TEXTURE_UNITS


---
-- Enumeration value TextureUsage.TEXTURE_STATIC
--
-- @field [parent=#global] #number TEXTURE_STATIC

---
-- Enumeration value TextureUsage.TEXTURE_DYNAMIC
--
-- @field [parent=#global] #number TEXTURE_DYNAMIC

---
-- Enumeration value TextureUsage.TEXTURE_RENDERTARGET
--
-- @field [parent=#global] #number TEXTURE_RENDERTARGET

---
-- Enumeration value TextureUsage.TEXTURE_DEPTHSTENCIL
--
-- @field [parent=#global] #number TEXTURE_DEPTHSTENCIL


---
-- Enumeration value TransformSpace.TS_LOCAL
--
-- @field [parent=#global] #number TS_LOCAL

---
-- Enumeration value TransformSpace.TS_PARENT
--
-- @field [parent=#global] #number TS_PARENT

---
-- Enumeration value TransformSpace.TS_WORLD
--
-- @field [parent=#global] #number TS_WORLD


---
-- Enumeration value TraversalMode.TM_BREADTH_FIRST
--
-- @field [parent=#global] #number TM_BREADTH_FIRST

---
-- Enumeration value TraversalMode.TM_DEPTH_FIRST
--
-- @field [parent=#global] #number TM_DEPTH_FIRST


---
-- Enumeration value VariantType.VAR_NONE
--
-- @field [parent=#global] #number VAR_NONE

---
-- Enumeration value VariantType.VAR_INT
--
-- @field [parent=#global] #number VAR_INT

---
-- Enumeration value VariantType.VAR_BOOL
--
-- @field [parent=#global] #number VAR_BOOL

---
-- Enumeration value VariantType.VAR_FLOAT
--
-- @field [parent=#global] #number VAR_FLOAT

---
-- Enumeration value VariantType.VAR_VECTOR2
--
-- @field [parent=#global] #number VAR_VECTOR2

---
-- Enumeration value VariantType.VAR_VECTOR3
--
-- @field [parent=#global] #number VAR_VECTOR3

---
-- Enumeration value VariantType.VAR_VECTOR4
--
-- @field [parent=#global] #number VAR_VECTOR4

---
-- Enumeration value VariantType.VAR_QUATERNION
--
-- @field [parent=#global] #number VAR_QUATERNION

---
-- Enumeration value VariantType.VAR_COLOR
--
-- @field [parent=#global] #number VAR_COLOR

---
-- Enumeration value VariantType.VAR_STRING
--
-- @field [parent=#global] #number VAR_STRING

---
-- Enumeration value VariantType.VAR_BUFFER
--
-- @field [parent=#global] #number VAR_BUFFER

---
-- Enumeration value VariantType.VAR_VOIDPTR
--
-- @field [parent=#global] #number VAR_VOIDPTR

---
-- Enumeration value VariantType.VAR_RESOURCEREF
--
-- @field [parent=#global] #number VAR_RESOURCEREF

---
-- Enumeration value VariantType.VAR_RESOURCEREFLIST
--
-- @field [parent=#global] #number VAR_RESOURCEREFLIST

---
-- Enumeration value VariantType.VAR_VARIANTVECTOR
--
-- @field [parent=#global] #number VAR_VARIANTVECTOR

---
-- Enumeration value VariantType.VAR_VARIANTMAP
--
-- @field [parent=#global] #number VAR_VARIANTMAP

---
-- Enumeration value VariantType.VAR_INTRECT
--
-- @field [parent=#global] #number VAR_INTRECT

---
-- Enumeration value VariantType.VAR_INTVECTOR2
--
-- @field [parent=#global] #number VAR_INTVECTOR2

---
-- Enumeration value VariantType.VAR_PTR
--
-- @field [parent=#global] #number VAR_PTR

---
-- Enumeration value VariantType.VAR_MATRIX3
--
-- @field [parent=#global] #number VAR_MATRIX3

---
-- Enumeration value VariantType.VAR_MATRIX3X4
--
-- @field [parent=#global] #number VAR_MATRIX3X4

---
-- Enumeration value VariantType.VAR_MATRIX4
--
-- @field [parent=#global] #number VAR_MATRIX4

---
-- Enumeration value VariantType.MAX_VAR_TYPES
--
-- @field [parent=#global] #number MAX_VAR_TYPES


---
-- Enumeration value VertexElement.ELEMENT_POSITION
--
-- @field [parent=#global] #number ELEMENT_POSITION

---
-- Enumeration value VertexElement.ELEMENT_NORMAL
--
-- @field [parent=#global] #number ELEMENT_NORMAL

---
-- Enumeration value VertexElement.ELEMENT_COLOR
--
-- @field [parent=#global] #number ELEMENT_COLOR

---
-- Enumeration value VertexElement.ELEMENT_TEXCOORD1
--
-- @field [parent=#global] #number ELEMENT_TEXCOORD1

---
-- Enumeration value VertexElement.ELEMENT_TEXCOORD2
--
-- @field [parent=#global] #number ELEMENT_TEXCOORD2

---
-- Enumeration value VertexElement.ELEMENT_CUBETEXCOORD1
--
-- @field [parent=#global] #number ELEMENT_CUBETEXCOORD1

---
-- Enumeration value VertexElement.ELEMENT_CUBETEXCOORD2
--
-- @field [parent=#global] #number ELEMENT_CUBETEXCOORD2

---
-- Enumeration value VertexElement.ELEMENT_TANGENT
--
-- @field [parent=#global] #number ELEMENT_TANGENT

---
-- Enumeration value VertexElement.ELEMENT_BLENDWEIGHTS
--
-- @field [parent=#global] #number ELEMENT_BLENDWEIGHTS

---
-- Enumeration value VertexElement.ELEMENT_BLENDINDICES
--
-- @field [parent=#global] #number ELEMENT_BLENDINDICES

---
-- Enumeration value VertexElement.ELEMENT_INSTANCEMATRIX1
--
-- @field [parent=#global] #number ELEMENT_INSTANCEMATRIX1

---
-- Enumeration value VertexElement.ELEMENT_INSTANCEMATRIX2
--
-- @field [parent=#global] #number ELEMENT_INSTANCEMATRIX2

---
-- Enumeration value VertexElement.ELEMENT_INSTANCEMATRIX3
--
-- @field [parent=#global] #number ELEMENT_INSTANCEMATRIX3

---
-- Enumeration value VertexElement.MAX_VERTEX_ELEMENTS
--
-- @field [parent=#global] #number MAX_VERTEX_ELEMENTS


---
-- Enumeration value VerticalAlignment.VA_TOP
--
-- @field [parent=#global] #number VA_TOP

---
-- Enumeration value VerticalAlignment.VA_CENTER
--
-- @field [parent=#global] #number VA_CENTER

---
-- Enumeration value VerticalAlignment.VA_BOTTOM
--
-- @field [parent=#global] #number VA_BOTTOM


---
-- Enumeration value WindowDragMode.DRAG_NONE
--
-- @field [parent=#global] #number DRAG_NONE

---
-- Enumeration value WindowDragMode.DRAG_MOVE
--
-- @field [parent=#global] #number DRAG_MOVE

---
-- Enumeration value WindowDragMode.DRAG_RESIZE_TOPLEFT
--
-- @field [parent=#global] #number DRAG_RESIZE_TOPLEFT

---
-- Enumeration value WindowDragMode.DRAG_RESIZE_TOP
--
-- @field [parent=#global] #number DRAG_RESIZE_TOP

---
-- Enumeration value WindowDragMode.DRAG_RESIZE_TOPRIGHT
--
-- @field [parent=#global] #number DRAG_RESIZE_TOPRIGHT

---
-- Enumeration value WindowDragMode.DRAG_RESIZE_RIGHT
--
-- @field [parent=#global] #number DRAG_RESIZE_RIGHT

---
-- Enumeration value WindowDragMode.DRAG_RESIZE_BOTTOMRIGHT
--
-- @field [parent=#global] #number DRAG_RESIZE_BOTTOMRIGHT

---
-- Enumeration value WindowDragMode.DRAG_RESIZE_BOTTOM
--
-- @field [parent=#global] #number DRAG_RESIZE_BOTTOM

---
-- Enumeration value WindowDragMode.DRAG_RESIZE_BOTTOMLEFT
--
-- @field [parent=#global] #number DRAG_RESIZE_BOTTOMLEFT

---
-- Enumeration value WindowDragMode.DRAG_RESIZE_LEFT
--
-- @field [parent=#global] #number DRAG_RESIZE_LEFT


---
-- Enumeration value WrapMode.WM_LOOP
--
-- @field [parent=#global] #number WM_LOOP

---
-- Enumeration value WrapMode.WM_ONCE
--
-- @field [parent=#global] #number WM_ONCE

---
-- Enumeration value WrapMode.WM_CLAMP
--
-- @field [parent=#global] #number WM_CLAMP


return nil
