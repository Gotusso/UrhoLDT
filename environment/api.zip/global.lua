-------------------------------------------------------------------------------
-- Lua global variables.
-- The basic library provides some core functions to Lua.
-- All the preloaded module of Lua are declared here.
-- @module global

------------------------------------------------------------------------------
-- This library provides generic functions for coroutine manipulation.
-- This is a global variable which hold the preloaded @{coroutine} module.
-- @field[parent = #global] coroutine#coroutine coroutine preloaded module

------------------------------------------------------------------------------
-- The package library provides basic facilities for loading and building modules in Lua.
-- This is a global variable which hold the preloaded @{package} module.
-- @field[parent = #global] package#package package preloaded module

------------------------------------------------------------------------------
-- This library provides generic functions for string manipulation.
-- This is a global variable which hold the preloaded @{string} module.
-- @field[parent = #global] string#string string preloaded module

------------------------------------------------------------------------------
-- This library provides generic functions for table manipulation.
-- This is a global variable which hold the preloaded @{table} module.
-- @field[parent = #global] table#table table preloaded module

------------------------------------------------------------------------------
-- This library is an interface to the standard C math library.
-- This is a global variable which hold the preloaded @{math} module.
-- @field[parent = #global] math#math math preloaded module

------------------------------------------------------------------------------
-- The I/O library provides function for file manipulation.
-- This is a global variable which hold the preloaded @{io} module.
-- @field[parent = #global] io#io io preloaded module

------------------------------------------------------------------------------
-- Operating System Facilities.
-- This is a global variable which hold the preloaded @{os} module.
-- @field[parent = #global] os#os os preloaded module

------------------------------------------------------------------------------
-- The Debug Library.
-- This is a  global variable which hold the preloaded @{debug} module.
-- @field[parent = #global] debug#debug debug preloaded module

-------------------------------------------------------------------------------
-- Issues an error when the value of its argument `v` is false (i.e.,
-- **nil** or **false**); otherwise, returns all its arguments. `message` is an error
-- message; when absent, it defaults to *"assertion failed!"*.
-- @function [parent=#global] assert
-- @param v if this argument is false an error is issued.
-- @param #string message an error message. defaults value is *"assertion failed"*.
-- @return All its arguments.

-------------------------------------------------------------------------------
-- This function is a generic interface to the garbage collector.
-- It performs different functions according to its first argument, `opt`:
--
--   * **"stop":** stops the garbage collector.
--   * **"restart":** restarts the garbage collector.
--   * **"collect":** performs a full garbage-collection cycle.
--   * **"count":** returns the total memory in use by Lua (in Kbytes).
--   * **"step":** performs a garbage-collection step. The step "size" is controlled
--       by `arg` (larger values mean more steps) in a non-specified way. If you
--       want to control the step size you must experimentally tune the value of
--      `arg`. Returns true if the step finished a collection cycle.
--   * **"setpause":** sets `arg` as the new value for the *pause* of the collector.
--       Returns the previous value for *pause*.
--   * **"setstepmul":** sets `arg` as the new value for the *step multiplier*
--       of the collector. Returns the previous value for *step*.
-- @function [parent=#global] collectgarbage
-- @param #string opt the command to send.
-- @param arg the argument of the command. (optional)

-------------------------------------------------------------------------------
-- Opens the named file and executes its contents as a Lua chunk. When
-- called without arguments,
-- `dofile` executes the contents of the standard input (`stdin`). Returns
-- all values returned by the chunk. In case of errors, `dofile` propagates
-- the error to its caller (that is, `dofile` does not run in protected mode).
-- @function [parent=#global] dofile
-- @param #string filename the path to the file. (optional)

-------------------------------------------------------------------------------
-- Terminates the last protected function called and returns `message`
-- as the error message. Function `error` never returns.
--
-- Usually, `error` adds some information about the error position at the
-- beginning of the message. The `level` argument specifies how to get the
-- error position.  
-- With level 1 (the default), the error position is where the
-- `error` function was called.  
-- Level 2 points the error to where the function
-- that called `error` was called; and so on.  
-- Passing a level 0 avoids the addition of error position information to the message.
-- @function [parent=#global] error
-- @param #string message an error message.
-- @param #number level specifies how to get the error position, default value is `1`.

-------------------------------------------------------------------------------
-- A global variable (not a function) that holds the global environment
-- (that is, `_G._G = _G`). Lua itself does not use this variable; changing
-- its value does not affect any environment, nor vice-versa. (Use `setfenv`
-- to change environments.)
-- @field [parent = #global] #table _G

-------------------------------------------------------------------------------
-- Returns the current environment in use by the function.
-- @function [parent=#global] getfenv
-- @param f can be a Lua function or a number that specifies the function at that
-- stack level: Level 1 is the function calling `getfenv`. If the given
-- function is not a Lua function, or if `f` is `0`, `getfenv` returns the
-- global environment. The default for `f` is `1`.

-------------------------------------------------------------------------------
-- If `object` does not have a metatable, returns nil. Otherwise, if the
-- object's metatable has a `"__metatable"` field, returns the associated
-- value. Otherwise, returns the metatable of the given object.
-- @function [parent=#global] getmetatable
-- @param object
-- @return #table the metatable of object.

-------------------------------------------------------------------------------
-- Use to iterate over a table by index.
-- Returns three values: an iterator function, the table `t`, and 0,
-- so that the construction :
-- 
--     for i,v in ipairs(t) do *body* end
-- will iterate over the pairs (`1,t[1]`), (`2,t[2]`), ..., up to the
-- first integer key absent from the table.
-- @function [parent=#global] ipairs
-- @param #table t a table by index.

-------------------------------------------------------------------------------
-- Loads a chunk using function `func` to get its pieces. Each call to
-- `func` must return a string that concatenates with previous results. A
-- return of an empty string, **nil,** or no value signals the end of the chunk.
--
-- If there are no errors, returns the compiled chunk as a function; otherwise,
-- returns nil plus the error message. The environment of the returned function
-- is the global environment.
--
-- `chunkname` is used as the chunk name for error messages and debug
-- information. When absent, it defaults to "`=(load)`".
-- @function [parent=#global] load
-- @param func function which loads the chunk.
-- @param #string chunkname chunk name used for error messages and debug information, default value is "`=(load)`".

-------------------------------------------------------------------------------
-- Similar to `load`, but gets the chunk from file `filename` or from the
-- standard input, if no file name is given.
-- @function [parent=#global] loadfile
-- @param #string filename the path to the file. (optional)

-------------------------------------------------------------------------------
-- Similar to `load`, but gets the chunk from the given string.
-- To load and run a given string, use the idiom  
-- 
--     assert(loadstring(s))()
-- When absent, `chunkname` defaults to the given string.
-- @function [parent=#global] loadstring
-- @param #string string lua code to load.
-- @param #string chunkname chunk name used for error messages and debug information, default value is the given string.

-------------------------------------------------------------------------------
-- Allows a program to traverse all fields of a table. Its first argument is
-- a table and its second argument is an index in this table. `next` returns
-- the next index of the table and its associated value.
--
-- When called with nil
-- as its second argument, `next` returns an initial index and its associated
-- value. When called with the last index, or with nil in an empty table, `next`
-- returns nil.
--
-- If the second argument is absent, then it is interpreted as
-- nil. In particular, you can use `next(t)` to check whether a table is empty.
-- The order in which the indices are enumerated is not specified, *even for
-- numeric indices*. (To traverse a table in numeric order, use a numerical
-- for or the `ipairs` function.)
--
-- The behavior of `next` is *undefined* if, during the traversal, you assign
-- any value to a non-existent field in the table. You may however modify
-- existing fields. In particular, you may clear existing fields.
-- @function [parent=#global] next
-- @param #table table table to traverse.
-- @param index initial index.

-------------------------------------------------------------------------------
-- Use to iterate over a table.
-- Returns three values: the `next` function, the table `t`, and nil,
-- so that the construction :
-- 
--     for k,v in pairs(t) do *body* end
-- will iterate over all key-value pairs of table `t`.
-- 
-- See function `next` for the caveats of modifying the table during its
-- traversal.
-- @function [parent=#global] pairs
-- @param #table t table to traverse.

-------------------------------------------------------------------------------
-- Calls function `f` with the given arguments in *protected mode*. This
-- means that any error inside `f` is not propagated; instead, `pcall` catches
-- the error and returns a status code. Its first result is the status code (a
-- boolean), which is true if the call succeeds without errors. In such case,
-- `pcall` also returns all results from the call, after this first result. In
-- case of any error, `pcall` returns false plus the error message.
-- @function [parent=#global] pcall
-- @param f function to be call in *protected mode*.
-- @param ... function arguments.
-- @return #boolean true plus the result of `f` function if its call succeeds without errors.
-- @return #boolean,#string  false plus the error message in case of any error.

-------------------------------------------------------------------------------
-- Receives any number of arguments, and prints their values to `stdout`,
-- using the `tostring` function to convert them to strings. `print` is not
-- intended for formatted output, but only as a quick way to show a value,
-- typically for debugging. For formatted output, use `string.format`.
-- @function [parent=#global] print
-- @param ... values to print to `stdout`.

-------------------------------------------------------------------------------
-- Checks whether `v1` is equal to `v2`, without invoking any
-- metamethod. Returns a boolean.
-- @function [parent=#global] rawequal
-- @param v1
-- @param v2
-- @return #boolean true if `v1` is equal to `v2`. 

-------------------------------------------------------------------------------
-- Gets the real value of `table[index]`, without invoking any
-- metamethod. `table` must be a table; `index` may be any value.
-- @function [parent=#global] rawget
-- @param #table table
-- @param index may be any value.
-- @return The real value of `table[index]`, without invoking any
-- metamethod.

-------------------------------------------------------------------------------
-- Sets the real value of `table[index]` to `value`, without invoking any
-- metamethod. `table` must be a table, `index` any value different from nil,
-- and `value` any Lua value.  
-- This function returns `table`.
-- @function [parent=#global] rawset
-- @param #table table
-- @param index any value different from nil.
-- @param value any Lua value.

-------------------------------------------------------------------------------
-- If `index` is a number, returns all arguments after argument number
-- `index`. Otherwise, `index` must be the string `"#"`, and `select` returns
-- the total number of extra arguments it received.
-- @function [parent=#global] select
-- @param index a number or the string `"#"`
-- @param ...

-------------------------------------------------------------------------------
-- Sets the environment to be used by the given function. `f` can be a Lua
-- function or a number that specifies the function at that stack level: Level
-- 1 is the function calling `setfenv`. `setfenv` returns the given function.  
-- As a special case, when `f` is 0 `setfenv` changes the environment of the
-- running thread. In this case, `setfenv` returns no values.
-- @function [parent=#global] setfenv
-- @param f a Lua function or a number that specifies the stack level.
-- @param #table table used as environment for `f`.
-- @return The given function.

-------------------------------------------------------------------------------
-- Sets the metatable for the given table. (You cannot change the metatable
-- of other types from Lua, only from C.) If `metatable` is nil, removes the
-- metatable of the given table. If the original metatable has a `"__metatable"`
-- field, raises an error.  
-- This function returns `table`.
-- @function [parent=#global] setmetatable
-- @param #table table 
-- @param #table metatable
-- @return The first argument `table`. 

-------------------------------------------------------------------------------
-- Tries to convert its argument to a number. If the argument is already
-- a number or a string convertible to a number, then `tonumber` returns this
-- number; otherwise, it returns **nil.**
--
-- An optional argument specifies the base to interpret the numeral. The base
-- may be any integer between 2 and 36, inclusive. In bases above 10, the
-- letter '`A`' (in either upper or lower case) represents 10, '`B`' represents
-- 11, and so forth, with '`Z`' representing 35. In base 10 (the default),
-- the number can have a decimal part, as well as an optional exponent part.
-- In other bases, only unsigned integers are accepted.
-- @function [parent=#global] tonumber
-- @param e a number or string to convert to a number.
-- @param #number base the base to interpret the numeral, any integer between 2 and 36.(default is 10).
-- @return #number a number if conversion succeeds else **nil**.

-------------------------------------------------------------------------------
-- Receives an argument of any type and converts it to a string in a
-- reasonable format. For complete control of how numbers are converted, use
-- `string.format`.
--
-- If the metatable of `e` has a `"__tostring"` field, then `tostring` calls
-- the corresponding value with `e` as argument, and uses the result of the
-- call as its result.
-- @function [parent=#global] tostring
-- @param e an argument of any type.
-- @return #string a string in a reasonable format.

-------------------------------------------------------------------------------
-- Returns the type of its only argument, coded as a string. The possible
-- results of this function are "
-- `nil`" (a string, not the value nil), "`number`", "`string`", "`boolean`",
-- "`table`", "`function`", "`thread`", and "`userdata`".
-- @function [parent=#global] type
-- @param v any value.
-- @return #string the type of `v`.

-------------------------------------------------------------------------------
-- Returns the elements from the given table. This function is equivalent to
-- 
--     return list[i], list[i+1], ..., list[j]
-- except that the above code can be written only for a fixed number of
-- elements. By default, `i` is 1 and `j` is the length of the list, as
-- defined by the length operator.
-- @function [parent=#global] unpack
-- @param #table list a table by index
-- @param i index of first value.
-- @param j index of last value.

-------------------------------------------------------------------------------
-- A global variable (not a function) that holds a string containing the
-- current interpreter version. The current contents of this variable is
-- "`Lua 5.1`".
-- @field [parent = #global] #string _VERSION

-------------------------------------------------------------------------------
-- This function is similar to `pcall`, except that you can set a new
-- error handler.
--
-- `xpcall` calls function `f` in protected mode, using `err` as the error
-- handler. Any error inside `f` is not propagated; instead, `xpcall` catches
-- the error, calls the `err` function with the original error object, and
-- returns a status code. Its first result is the status code (a boolean),
-- which is true if the call succeeds without errors. In this case, `xpcall`
-- also returns all results from the call, after this first result. In case
-- of any error, `xpcall` returns false plus the result from `err`.
-- @function [parent=#global] xpcall
-- @param f function to be call in *protected mode*.
-- @param err function used as error handler.
-- @return #boolean true plus the result of `f` function if its call succeeds without errors.
-- @return #boolean,#string  false plus the result of `err` function. 

-------------------------------------------------------------------------------
-- Creates a module. If there is a table in `package.loaded[name]`,
-- this table is the module. Otherwise, if there is a global table `t`
-- with the given name, this table is the module. 
-- 
-- Otherwise creates a new table `t` and sets it as the value of the global 
-- `name` and the value of `package.loaded[name]`. 
--  This function also initializes `t._NAME` with the
-- given name, `t._M` with the module (`t` itself), and `t._PACKAGE` with the
-- package name (the full module name minus last component; see below). Finally,
-- `module` sets `t` as the new environment of the current function and the
-- new value of `package.loaded[name]`, so that `require` returns `t`.
--
-- If `name` is a compound name (that is, one with components separated by
-- dots), `module` creates (or reuses, if they already exist) tables for each
-- component. For instance, if `name` is `a.b.c`, then `module` stores the
-- module table in field `c` of field `b` of global `a`.
--
-- This function can receive optional *options* after the module name, where
-- each option is a function to be applied over the module.
-- @function [parent=#global] module
-- @param name the module name.

-------------------------------------------------------------------------------
-- Loads the given module. The function starts by looking into the
-- `package.loaded` table to determine whether `modname` is already
-- loaded. If it is, then `require` returns the value stored at
-- `package.loaded[modname]`. Otherwise, it tries to find a *loader* for
-- the module.
--
-- To find a loader, `require` is guided by the `package.loaders` array. By
-- changing this array, we can change how `require` looks for a module. The
-- following explanation is based on the default configuration for
-- `package.loaders`.
--
-- First `require` queries `package.preload[modname]`. If it has a value,
-- this value (which should be a function) is the loader. Otherwise `require`
-- searches for a Lua loader using the path stored in `package.path`. If
-- that also fails, it searches for a C loader using the path stored in
-- `package.cpath`. If that also fails, it tries an *all-in-one* loader (see
-- `package.loaders`).
--
-- Once a loader is found, `require` calls the loader with a single argument,
-- `modname`. If the loader returns any value, `require` assigns the returned
-- value to `package.loaded[modname]`. If the loader returns no value and
-- has not assigned any value to `package.loaded[modname]`, then `require`
-- assigns true to this entry. In any case, `require` returns the final value
-- of `package.loaded[modname]`.
--
-- If there is any error loading or running the module, or if it cannot find
-- any loader for the module, then `require` signals an error.
-- @function [parent=#global] require
-- @param #string modname name of module to load.
---
-- Function Abs
--
-- @function [parent=#global] Abs
-- @param #number valuevalue
-- @return #number

---
-- Function AddTrailingSlash
--
-- @function [parent=#global] AddTrailingSlash
-- @param #string pathNamepathName
-- @return #string

---
-- Function Clamp
--
-- @function [parent=#global] Clamp
-- @param #number valuevalue
-- @param #number minmin
-- @param #number maxmax
-- @return #number

---
-- Function Equals
--
-- @function [parent=#global] Equals
-- @param #number lhslhs
-- @param #number rhsrhs
-- @return #boolean

---
-- Function ErrorDialog
--
-- @function [parent=#global] ErrorDialog
-- @param #string titletitle
-- @param #string messagemessage

---
-- Function ErrorExit
--
-- @function [parent=#global] ErrorExit
-- @param #string messagemessage
-- @param #number exitCodeexitCode

---
-- Function GetArguments
--
-- @function [parent=#global] GetArguments
-- @return const Vector<String>#const Vector<String>

---
-- Function GetAudio
--
-- @function [parent=#global] GetAudio
-- @return Audio#Audio

---
-- Function GetCache
--
-- @function [parent=#global] GetCache
-- @return ResourceCache#ResourceCache

---
-- Function GetConsole
--
-- @function [parent=#global] GetConsole
-- @return Console#Console

---
-- Function GetConsoleInput
--
-- @function [parent=#global] GetConsoleInput
-- @return #string

---
-- Function GetContext
--
-- @function [parent=#global] GetContext
-- @return Context#Context

---
-- Function GetDebugHud
--
-- @function [parent=#global] GetDebugHud
-- @return DebugHud#DebugHud

---
-- Function GetEngine
--
-- @function [parent=#global] GetEngine
-- @return Engine#Engine

---
-- Function GetEventHandler
--
-- @function [parent=#global] GetEventHandler
-- @return EventHandler#EventHandler

---
-- Function GetEventSender
--
-- @function [parent=#global] GetEventSender
-- @return Object#Object

---
-- Function GetExtension
--
-- @function [parent=#global] GetExtension
-- @param #string fullPathfullPath
-- @param #boolean lowercaseExtensionlowercaseExtension
-- @return #string

---
-- Function GetFileName
--
-- @function [parent=#global] GetFileName
-- @param #string fullPathfullPath
-- @return #string

---
-- Function GetFileNameAndExtension
--
-- @function [parent=#global] GetFileNameAndExtension
-- @param #string fullPathfullPath
-- @param #boolean lowercaseExtensionlowercaseExtension
-- @return #string

---
-- Function GetFileSystem
--
-- @function [parent=#global] GetFileSystem
-- @return FileSystem#FileSystem

---
-- Function GetGraphics
--
-- @function [parent=#global] GetGraphics
-- @return Graphics#Graphics

---
-- Function GetInput
--
-- @function [parent=#global] GetInput
-- @return Input#Input

---
-- Function GetInternalPath
--
-- @function [parent=#global] GetInternalPath
-- @param #string pathNamepathName
-- @return #string

---
-- Function GetLog
--
-- @function [parent=#global] GetLog
-- @return Log#Log

---
-- Function GetNativePath
--
-- @function [parent=#global] GetNativePath
-- @param #string pathNamepathName
-- @return #string

---
-- Function GetNetwork
--
-- @function [parent=#global] GetNetwork
-- @return Network#Network

---
-- Function GetNumLogicalCPUs
--
-- @function [parent=#global] GetNumLogicalCPUs
-- @return #number

---
-- Function GetNumPhysicalCPUs
--
-- @function [parent=#global] GetNumPhysicalCPUs
-- @return #number

---
-- Function GetParentPath
--
-- @function [parent=#global] GetParentPath
-- @param #string pathNamepathName
-- @return #string

---
-- Function GetPath
--
-- @function [parent=#global] GetPath
-- @param #string fullPathfullPath
-- @return #string

---
-- Function GetPlatform
--
-- @function [parent=#global] GetPlatform
-- @return #string

---
-- Function GetRandomSeed
--
-- @function [parent=#global] GetRandomSeed
-- @return #number

---
-- Function GetRenderer
--
-- @function [parent=#global] GetRenderer
-- @return Renderer#Renderer

---
-- Function GetTime
--
-- @function [parent=#global] GetTime
-- @return Time#Time

---
-- Function GetUI
--
-- @function [parent=#global] GetUI
-- @return UI#UI

---
-- Function IsAbsolutePath
--
-- @function [parent=#global] IsAbsolutePath
-- @param #string pathNamepathName
-- @return #boolean

---
-- Function IsAlpha
--
-- @function [parent=#global] IsAlpha
-- @param #number chch
-- @return #boolean

---
-- Function IsDigit
--
-- @function [parent=#global] IsDigit
-- @param #number chch
-- @return #boolean

---
-- Function Lerp
--
-- @function [parent=#global] Lerp
-- @param #number lhslhs
-- @param #number rhsrhs
-- @param #number tt
-- @return #number

---
-- Function Max
--
-- @function [parent=#global] Max
-- @param #number lhslhs
-- @param #number rhsrhs
-- @return #number

---
-- Function Min
--
-- @function [parent=#global] Min
-- @param #number lhslhs
-- @param #number rhsrhs
-- @return #number

---
-- Function OpenConsoleWindow
--
-- @function [parent=#global] OpenConsoleWindow

---
-- Function PrintLine
--
-- @function [parent=#global] PrintLine
-- @param #string strstr
-- @param #boolean errorerror

---
-- Function Rand
--
-- @function [parent=#global] Rand
-- @return #number

---
-- Function RandStandardNormal
--
-- @function [parent=#global] RandStandardNormal
-- @return #number

---
-- Function Random
--
-- @function [parent=#global] Random
-- @param #number rangerange
-- @return #number

---
-- Function Random
--
-- @function [parent=#global] Random
-- @param #number minmin
-- @param #number maxmax
-- @return #number

---
-- Function Random
--
-- @function [parent=#global] Random
-- @return #number

---
-- Function RandomInt
--
-- @function [parent=#global] RandomInt
-- @param #number minmin
-- @param #number maxmax
-- @return #number

---
-- Function RandomInt
--
-- @function [parent=#global] RandomInt
-- @param #number rangerange
-- @return #number

---
-- Function RandomNormal
--
-- @function [parent=#global] RandomNormal
-- @param #number meanValuemeanValue
-- @param #number variancevariance
-- @return #number

---
-- Function RemoveTrailingSlash
--
-- @function [parent=#global] RemoveTrailingSlash
-- @param #string pathNamepathName
-- @return #string

---
-- Function ReplaceExtension
--
-- @function [parent=#global] ReplaceExtension
-- @param #string fullPathfullPath
-- @param #string newExtensionnewExtension
-- @return #string

---
-- Function SendEvent
--
-- @function [parent=#global] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Function SetRandomSeed
--
-- @function [parent=#global] SetRandomSeed
-- @param #number seedseed

---
-- Function Sign
--
-- @function [parent=#global] Sign
-- @param #number valuevalue
-- @return #number

---
-- Function SmoothStep
--
-- @function [parent=#global] SmoothStep
-- @param #number lhslhs
-- @param #number rhsrhs
-- @param #number tt
-- @return #number

---
-- Function SubscribeToEvent
--
-- @function [parent=#global] SubscribeToEvent
-- @param #string eventNameeventName
-- @param #string functionNamefunctionName

---
-- Function SubscribeToEvent
--
-- @function [parent=#global] SubscribeToEvent
-- @param void*#void* sendersender
-- @param #string eventNameeventName
-- @param #string functionNamefunctionName

---
-- Function ToBool
--
-- @function [parent=#global] ToBool
-- @param #string sourcesource
-- @return #boolean

---
-- Function ToColor
--
-- @function [parent=#global] ToColor
-- @param #string sourcesource
-- @return Color#Color

---
-- Function ToFloat
--
-- @function [parent=#global] ToFloat
-- @param #string sourcesource
-- @return #number

---
-- Function ToInt
--
-- @function [parent=#global] ToInt
-- @param #string sourcesource
-- @return #number

---
-- Function ToIntRect
--
-- @function [parent=#global] ToIntRect
-- @param #string sourcesource
-- @return IntRect#IntRect

---
-- Function ToIntVector2
--
-- @function [parent=#global] ToIntVector2
-- @param #string sourcesource
-- @return IntVector2#IntVector2

---
-- Function ToLower
--
-- @function [parent=#global] ToLower
-- @param #number chch
-- @return #number

---
-- Function ToQuaternion
--
-- @function [parent=#global] ToQuaternion
-- @param #string sourcesource
-- @return Quaternion#Quaternion

---
-- Function ToRect
--
-- @function [parent=#global] ToRect
-- @param #string sourcesource
-- @return Rect#Rect

---
-- Function ToString
--
-- @function [parent=#global] ToString
-- @param void*#void* valuevalue
-- @return #string

---
-- Function ToStringHex
--
-- @function [parent=#global] ToStringHex
-- @param #number valuevalue
-- @return #string

---
-- Function ToUInt
--
-- @function [parent=#global] ToUInt
-- @param #string sourcesource
-- @return #number

---
-- Function ToUpper
--
-- @function [parent=#global] ToUpper
-- @param #number chch
-- @return #number

---
-- Function ToVector2
--
-- @function [parent=#global] ToVector2
-- @param #string sourcesource
-- @return Vector2#Vector2

---
-- Function ToVector3
--
-- @function [parent=#global] ToVector3
-- @param #string sourcesource
-- @return Vector3#Vector3

---
-- Function ToVector4
--
-- @function [parent=#global] ToVector4
-- @param #string sourcesource
-- @param #boolean allowMissingCoordsallowMissingCoords
-- @return Vector4#Vector4

---
-- Function UnsubscribeFromAllEvents
--
-- @function [parent=#global] UnsubscribeFromAllEvents

---
-- Function UnsubscribeFromEvent
--
-- @function [parent=#global] UnsubscribeFromEvent
-- @param void*#void* sendersender
-- @param #string eventNameeventName

---
-- Function UnsubscribeFromEvent
--
-- @function [parent=#global] UnsubscribeFromEvent
-- @param #string eventNameeventName

---
-- Function UnsubscribeFromEvents
--
-- @function [parent=#global] UnsubscribeFromEvents
-- @param void*#void* sendersender


---
-- Field audio (Read only)
--
-- @field [parent=#global] Audio#Audio audio

---
-- Field cache (Read only)
--
-- @field [parent=#global] ResourceCache#ResourceCache cache

---
-- Field console (Read only)
--
-- @field [parent=#global] Console#Console console

---
-- Field debugHud (Read only)
--
-- @field [parent=#global] DebugHud#DebugHud debugHud

---
-- Field engine (Read only)
--
-- @field [parent=#global] Engine#Engine engine

---
-- Field fileSystem (Read only)
--
-- @field [parent=#global] FileSystem#FileSystem fileSystem

---
-- Field graphics (Read only)
--
-- @field [parent=#global] Graphics#Graphics graphics

---
-- Field input (Read only)
--
-- @field [parent=#global] Input#Input input

---
-- Field log (Read only)
--
-- @field [parent=#global] Log#Log log

---
-- Field network (Read only)
--
-- @field [parent=#global] Network#Network network

---
-- Field renderer (Read only)
--
-- @field [parent=#global] Renderer#Renderer renderer

---
-- Field time (Read only)
--
-- @field [parent=#global] Time#Time time

---
-- Field ui (Read only)
--
-- @field [parent=#global] UI#UI ui

---
-- Field ANIMATION_LOD_BASESCALE (Read only)
--
-- @field [parent=#global] #number ANIMATION_LOD_BASESCALE

---
-- Field CHANNEL_POSITION (Read only)
--
-- @field [parent=#global] #string CHANNEL_POSITION

---
-- Field CHANNEL_ROTATION (Read only)
--
-- @field [parent=#global] #string CHANNEL_ROTATION

---
-- Field CHANNEL_SCALE (Read only)
--
-- @field [parent=#global] #string CHANNEL_SCALE

---
-- Field CLEAR_COLOR (Read only)
--
-- @field [parent=#global] #number CLEAR_COLOR

---
-- Field CLEAR_DEPTH (Read only)
--
-- @field [parent=#global] #number CLEAR_DEPTH

---
-- Field CLEAR_STENCIL (Read only)
--
-- @field [parent=#global] #number CLEAR_STENCIL

---
-- Field CONTROLLER_AXIS_LEFTX (Read only)
--
-- @field [parent=#global] #number CONTROLLER_AXIS_LEFTX

---
-- Field CONTROLLER_AXIS_LEFTY (Read only)
--
-- @field [parent=#global] #number CONTROLLER_AXIS_LEFTY

---
-- Field CONTROLLER_AXIS_RIGHTX (Read only)
--
-- @field [parent=#global] #number CONTROLLER_AXIS_RIGHTX

---
-- Field CONTROLLER_AXIS_RIGHTY (Read only)
--
-- @field [parent=#global] #number CONTROLLER_AXIS_RIGHTY

---
-- Field CONTROLLER_AXIS_TRIGGERLEFT (Read only)
--
-- @field [parent=#global] #number CONTROLLER_AXIS_TRIGGERLEFT

---
-- Field CONTROLLER_AXIS_TRIGGERRIGHT (Read only)
--
-- @field [parent=#global] #number CONTROLLER_AXIS_TRIGGERRIGHT

---
-- Field CONTROLLER_BUTTON_A (Read only)
--
-- @field [parent=#global] #number CONTROLLER_BUTTON_A

---
-- Field CONTROLLER_BUTTON_B (Read only)
--
-- @field [parent=#global] #number CONTROLLER_BUTTON_B

---
-- Field CONTROLLER_BUTTON_BACK (Read only)
--
-- @field [parent=#global] #number CONTROLLER_BUTTON_BACK

---
-- Field CONTROLLER_BUTTON_DPAD_DOWN (Read only)
--
-- @field [parent=#global] #number CONTROLLER_BUTTON_DPAD_DOWN

---
-- Field CONTROLLER_BUTTON_DPAD_LEFT (Read only)
--
-- @field [parent=#global] #number CONTROLLER_BUTTON_DPAD_LEFT

---
-- Field CONTROLLER_BUTTON_DPAD_RIGHT (Read only)
--
-- @field [parent=#global] #number CONTROLLER_BUTTON_DPAD_RIGHT

---
-- Field CONTROLLER_BUTTON_DPAD_UP (Read only)
--
-- @field [parent=#global] #number CONTROLLER_BUTTON_DPAD_UP

---
-- Field CONTROLLER_BUTTON_GUIDE (Read only)
--
-- @field [parent=#global] #number CONTROLLER_BUTTON_GUIDE

---
-- Field CONTROLLER_BUTTON_LEFTSHOULDER (Read only)
--
-- @field [parent=#global] #number CONTROLLER_BUTTON_LEFTSHOULDER

---
-- Field CONTROLLER_BUTTON_LEFTSTICK (Read only)
--
-- @field [parent=#global] #number CONTROLLER_BUTTON_LEFTSTICK

---
-- Field CONTROLLER_BUTTON_RIGHTSHOULDER (Read only)
--
-- @field [parent=#global] #number CONTROLLER_BUTTON_RIGHTSHOULDER

---
-- Field CONTROLLER_BUTTON_RIGHTSTICK (Read only)
--
-- @field [parent=#global] #number CONTROLLER_BUTTON_RIGHTSTICK

---
-- Field CONTROLLER_BUTTON_START (Read only)
--
-- @field [parent=#global] #number CONTROLLER_BUTTON_START

---
-- Field CONTROLLER_BUTTON_X (Read only)
--
-- @field [parent=#global] #number CONTROLLER_BUTTON_X

---
-- Field CONTROLLER_BUTTON_Y (Read only)
--
-- @field [parent=#global] #number CONTROLLER_BUTTON_Y

---
-- Field DD_DISABLED (Read only)
--
-- @field [parent=#global] #number DD_DISABLED

---
-- Field DD_SOURCE (Read only)
--
-- @field [parent=#global] #number DD_SOURCE

---
-- Field DD_SOURCE_AND_TARGET (Read only)
--
-- @field [parent=#global] #number DD_SOURCE_AND_TARGET

---
-- Field DD_TARGET (Read only)
--
-- @field [parent=#global] #number DD_TARGET

---
-- Field DEBUGHUD_SHOW_ALL (Read only)
--
-- @field [parent=#global] #number DEBUGHUD_SHOW_ALL

---
-- Field DEBUGHUD_SHOW_MODE (Read only)
--
-- @field [parent=#global] #number DEBUGHUD_SHOW_MODE

---
-- Field DEBUGHUD_SHOW_NONE (Read only)
--
-- @field [parent=#global] #number DEBUGHUD_SHOW_NONE

---
-- Field DEBUGHUD_SHOW_PROFILER (Read only)
--
-- @field [parent=#global] #number DEBUGHUD_SHOW_PROFILER

---
-- Field DEBUGHUD_SHOW_STATS (Read only)
--
-- @field [parent=#global] #number DEBUGHUD_SHOW_STATS

---
-- Field DEFAULT_LIGHTMASK (Read only)
--
-- @field [parent=#global] #number DEFAULT_LIGHTMASK

---
-- Field DEFAULT_SHADOWMASK (Read only)
--
-- @field [parent=#global] #number DEFAULT_SHADOWMASK

---
-- Field DEFAULT_VIEWMASK (Read only)
--
-- @field [parent=#global] #number DEFAULT_VIEWMASK

---
-- Field DEFAULT_ZONEMASK (Read only)
--
-- @field [parent=#global] #number DEFAULT_ZONEMASK

---
-- Field DRAWABLE_ANY (Read only)
--
-- @field [parent=#global] #number DRAWABLE_ANY

---
-- Field DRAWABLE_GEOMETRY (Read only)
--
-- @field [parent=#global] #number DRAWABLE_GEOMETRY

---
-- Field DRAWABLE_LIGHT (Read only)
--
-- @field [parent=#global] #number DRAWABLE_LIGHT

---
-- Field DRAWABLE_ZONE (Read only)
--
-- @field [parent=#global] #number DRAWABLE_ZONE

---
-- Field FIRST_LOCAL_ID (Read only)
--
-- @field [parent=#global] #number FIRST_LOCAL_ID

---
-- Field FIRST_REPLICATED_ID (Read only)
--
-- @field [parent=#global] #number FIRST_REPLICATED_ID

---
-- Field HAT_CENTER (Read only)
--
-- @field [parent=#global] #number HAT_CENTER

---
-- Field HAT_DOWN (Read only)
--
-- @field [parent=#global] #number HAT_DOWN

---
-- Field HAT_LEFT (Read only)
--
-- @field [parent=#global] #number HAT_LEFT

---
-- Field HAT_RIGHT (Read only)
--
-- @field [parent=#global] #number HAT_RIGHT

---
-- Field HAT_UP (Read only)
--
-- @field [parent=#global] #number HAT_UP

---
-- Field INSTANCING_BUFFER_DEFAULT_SIZE (Read only)
--
-- @field [parent=#global] #number INSTANCING_BUFFER_DEFAULT_SIZE

---
-- Field KEY_0 (Read only)
--
-- @field [parent=#global] #number KEY_0

---
-- Field KEY_1 (Read only)
--
-- @field [parent=#global] #number KEY_1

---
-- Field KEY_2 (Read only)
--
-- @field [parent=#global] #number KEY_2

---
-- Field KEY_3 (Read only)
--
-- @field [parent=#global] #number KEY_3

---
-- Field KEY_4 (Read only)
--
-- @field [parent=#global] #number KEY_4

---
-- Field KEY_5 (Read only)
--
-- @field [parent=#global] #number KEY_5

---
-- Field KEY_6 (Read only)
--
-- @field [parent=#global] #number KEY_6

---
-- Field KEY_7 (Read only)
--
-- @field [parent=#global] #number KEY_7

---
-- Field KEY_8 (Read only)
--
-- @field [parent=#global] #number KEY_8

---
-- Field KEY_9 (Read only)
--
-- @field [parent=#global] #number KEY_9

---
-- Field KEY_A (Read only)
--
-- @field [parent=#global] #number KEY_A

---
-- Field KEY_ADD (Read only)
--
-- @field [parent=#global] #number KEY_ADD

---
-- Field KEY_ALT (Read only)
--
-- @field [parent=#global] #number KEY_ALT

---
-- Field KEY_APPS (Read only)
--
-- @field [parent=#global] #number KEY_APPS

---
-- Field KEY_B (Read only)
--
-- @field [parent=#global] #number KEY_B

---
-- Field KEY_BACKSPACE (Read only)
--
-- @field [parent=#global] #number KEY_BACKSPACE

---
-- Field KEY_C (Read only)
--
-- @field [parent=#global] #number KEY_C

---
-- Field KEY_CAPSLOCK (Read only)
--
-- @field [parent=#global] #number KEY_CAPSLOCK

---
-- Field KEY_CTRL (Read only)
--
-- @field [parent=#global] #number KEY_CTRL

---
-- Field KEY_D (Read only)
--
-- @field [parent=#global] #number KEY_D

---
-- Field KEY_DECIMAL (Read only)
--
-- @field [parent=#global] #number KEY_DECIMAL

---
-- Field KEY_DELETE (Read only)
--
-- @field [parent=#global] #number KEY_DELETE

---
-- Field KEY_DIVIDE (Read only)
--
-- @field [parent=#global] #number KEY_DIVIDE

---
-- Field KEY_DOWN (Read only)
--
-- @field [parent=#global] #number KEY_DOWN

---
-- Field KEY_E (Read only)
--
-- @field [parent=#global] #number KEY_E

---
-- Field KEY_END (Read only)
--
-- @field [parent=#global] #number KEY_END

---
-- Field KEY_ESC (Read only)
--
-- @field [parent=#global] #number KEY_ESC

---
-- Field KEY_F (Read only)
--
-- @field [parent=#global] #number KEY_F

---
-- Field KEY_F1 (Read only)
--
-- @field [parent=#global] #number KEY_F1

---
-- Field KEY_F10 (Read only)
--
-- @field [parent=#global] #number KEY_F10

---
-- Field KEY_F11 (Read only)
--
-- @field [parent=#global] #number KEY_F11

---
-- Field KEY_F12 (Read only)
--
-- @field [parent=#global] #number KEY_F12

---
-- Field KEY_F13 (Read only)
--
-- @field [parent=#global] #number KEY_F13

---
-- Field KEY_F14 (Read only)
--
-- @field [parent=#global] #number KEY_F14

---
-- Field KEY_F15 (Read only)
--
-- @field [parent=#global] #number KEY_F15

---
-- Field KEY_F16 (Read only)
--
-- @field [parent=#global] #number KEY_F16

---
-- Field KEY_F17 (Read only)
--
-- @field [parent=#global] #number KEY_F17

---
-- Field KEY_F18 (Read only)
--
-- @field [parent=#global] #number KEY_F18

---
-- Field KEY_F19 (Read only)
--
-- @field [parent=#global] #number KEY_F19

---
-- Field KEY_F2 (Read only)
--
-- @field [parent=#global] #number KEY_F2

---
-- Field KEY_F20 (Read only)
--
-- @field [parent=#global] #number KEY_F20

---
-- Field KEY_F21 (Read only)
--
-- @field [parent=#global] #number KEY_F21

---
-- Field KEY_F22 (Read only)
--
-- @field [parent=#global] #number KEY_F22

---
-- Field KEY_F23 (Read only)
--
-- @field [parent=#global] #number KEY_F23

---
-- Field KEY_F24 (Read only)
--
-- @field [parent=#global] #number KEY_F24

---
-- Field KEY_F3 (Read only)
--
-- @field [parent=#global] #number KEY_F3

---
-- Field KEY_F4 (Read only)
--
-- @field [parent=#global] #number KEY_F4

---
-- Field KEY_F5 (Read only)
--
-- @field [parent=#global] #number KEY_F5

---
-- Field KEY_F6 (Read only)
--
-- @field [parent=#global] #number KEY_F6

---
-- Field KEY_F7 (Read only)
--
-- @field [parent=#global] #number KEY_F7

---
-- Field KEY_F8 (Read only)
--
-- @field [parent=#global] #number KEY_F8

---
-- Field KEY_F9 (Read only)
--
-- @field [parent=#global] #number KEY_F9

---
-- Field KEY_G (Read only)
--
-- @field [parent=#global] #number KEY_G

---
-- Field KEY_H (Read only)
--
-- @field [parent=#global] #number KEY_H

---
-- Field KEY_HOME (Read only)
--
-- @field [parent=#global] #number KEY_HOME

---
-- Field KEY_I (Read only)
--
-- @field [parent=#global] #number KEY_I

---
-- Field KEY_INSERT (Read only)
--
-- @field [parent=#global] #number KEY_INSERT

---
-- Field KEY_J (Read only)
--
-- @field [parent=#global] #number KEY_J

---
-- Field KEY_K (Read only)
--
-- @field [parent=#global] #number KEY_K

---
-- Field KEY_KP_ENTER (Read only)
--
-- @field [parent=#global] #number KEY_KP_ENTER

---
-- Field KEY_L (Read only)
--
-- @field [parent=#global] #number KEY_L

---
-- Field KEY_LALT (Read only)
--
-- @field [parent=#global] #number KEY_LALT

---
-- Field KEY_LCTRL (Read only)
--
-- @field [parent=#global] #number KEY_LCTRL

---
-- Field KEY_LEFT (Read only)
--
-- @field [parent=#global] #number KEY_LEFT

---
-- Field KEY_LSHIFT (Read only)
--
-- @field [parent=#global] #number KEY_LSHIFT

---
-- Field KEY_LWIN (Read only)
--
-- @field [parent=#global] #number KEY_LWIN

---
-- Field KEY_M (Read only)
--
-- @field [parent=#global] #number KEY_M

---
-- Field KEY_MULTIPLY (Read only)
--
-- @field [parent=#global] #number KEY_MULTIPLY

---
-- Field KEY_N (Read only)
--
-- @field [parent=#global] #number KEY_N

---
-- Field KEY_NUMLOCK (Read only)
--
-- @field [parent=#global] #number KEY_NUMLOCK

---
-- Field KEY_NUMPAD0 (Read only)
--
-- @field [parent=#global] #number KEY_NUMPAD0

---
-- Field KEY_NUMPAD1 (Read only)
--
-- @field [parent=#global] #number KEY_NUMPAD1

---
-- Field KEY_NUMPAD2 (Read only)
--
-- @field [parent=#global] #number KEY_NUMPAD2

---
-- Field KEY_NUMPAD3 (Read only)
--
-- @field [parent=#global] #number KEY_NUMPAD3

---
-- Field KEY_NUMPAD4 (Read only)
--
-- @field [parent=#global] #number KEY_NUMPAD4

---
-- Field KEY_NUMPAD5 (Read only)
--
-- @field [parent=#global] #number KEY_NUMPAD5

---
-- Field KEY_NUMPAD6 (Read only)
--
-- @field [parent=#global] #number KEY_NUMPAD6

---
-- Field KEY_NUMPAD7 (Read only)
--
-- @field [parent=#global] #number KEY_NUMPAD7

---
-- Field KEY_NUMPAD8 (Read only)
--
-- @field [parent=#global] #number KEY_NUMPAD8

---
-- Field KEY_NUMPAD9 (Read only)
--
-- @field [parent=#global] #number KEY_NUMPAD9

---
-- Field KEY_O (Read only)
--
-- @field [parent=#global] #number KEY_O

---
-- Field KEY_P (Read only)
--
-- @field [parent=#global] #number KEY_P

---
-- Field KEY_PAGEDOWN (Read only)
--
-- @field [parent=#global] #number KEY_PAGEDOWN

---
-- Field KEY_PAGEUP (Read only)
--
-- @field [parent=#global] #number KEY_PAGEUP

---
-- Field KEY_PAUSE (Read only)
--
-- @field [parent=#global] #number KEY_PAUSE

---
-- Field KEY_PRINTSCREEN (Read only)
--
-- @field [parent=#global] #number KEY_PRINTSCREEN

---
-- Field KEY_Q (Read only)
--
-- @field [parent=#global] #number KEY_Q

---
-- Field KEY_R (Read only)
--
-- @field [parent=#global] #number KEY_R

---
-- Field KEY_RALT (Read only)
--
-- @field [parent=#global] #number KEY_RALT

---
-- Field KEY_RCTRL (Read only)
--
-- @field [parent=#global] #number KEY_RCTRL

---
-- Field KEY_RETURN (Read only)
--
-- @field [parent=#global] #number KEY_RETURN

---
-- Field KEY_RETURN2 (Read only)
--
-- @field [parent=#global] #number KEY_RETURN2

---
-- Field KEY_RIGHT (Read only)
--
-- @field [parent=#global] #number KEY_RIGHT

---
-- Field KEY_RSHIFT (Read only)
--
-- @field [parent=#global] #number KEY_RSHIFT

---
-- Field KEY_RWIN (Read only)
--
-- @field [parent=#global] #number KEY_RWIN

---
-- Field KEY_S (Read only)
--
-- @field [parent=#global] #number KEY_S

---
-- Field KEY_SCROLLLOCK (Read only)
--
-- @field [parent=#global] #number KEY_SCROLLLOCK

---
-- Field KEY_SELECT (Read only)
--
-- @field [parent=#global] #number KEY_SELECT

---
-- Field KEY_SHIFT (Read only)
--
-- @field [parent=#global] #number KEY_SHIFT

---
-- Field KEY_SPACE (Read only)
--
-- @field [parent=#global] #number KEY_SPACE

---
-- Field KEY_SUBTRACT (Read only)
--
-- @field [parent=#global] #number KEY_SUBTRACT

---
-- Field KEY_T (Read only)
--
-- @field [parent=#global] #number KEY_T

---
-- Field KEY_TAB (Read only)
--
-- @field [parent=#global] #number KEY_TAB

---
-- Field KEY_U (Read only)
--
-- @field [parent=#global] #number KEY_U

---
-- Field KEY_UP (Read only)
--
-- @field [parent=#global] #number KEY_UP

---
-- Field KEY_V (Read only)
--
-- @field [parent=#global] #number KEY_V

---
-- Field KEY_W (Read only)
--
-- @field [parent=#global] #number KEY_W

---
-- Field KEY_X (Read only)
--
-- @field [parent=#global] #number KEY_X

---
-- Field KEY_Y (Read only)
--
-- @field [parent=#global] #number KEY_Y

---
-- Field KEY_Z (Read only)
--
-- @field [parent=#global] #number KEY_Z

---
-- Field LAST_LOCAL_ID (Read only)
--
-- @field [parent=#global] #number LAST_LOCAL_ID

---
-- Field LAST_REPLICATED_ID (Read only)
--
-- @field [parent=#global] #number LAST_REPLICATED_ID

---
-- Field LOG_DEBUG (Read only)
--
-- @field [parent=#global] #number LOG_DEBUG

---
-- Field LOG_ERROR (Read only)
--
-- @field [parent=#global] #number LOG_ERROR

---
-- Field LOG_INFO (Read only)
--
-- @field [parent=#global] #number LOG_INFO

---
-- Field LOG_NONE (Read only)
--
-- @field [parent=#global] #number LOG_NONE

---
-- Field LOG_WARNING (Read only)
--
-- @field [parent=#global] #number LOG_WARNING

---
-- Field MAX_VERTEX_LIGHTS (Read only)
--
-- @field [parent=#global] #number MAX_VERTEX_LIGHTS

---
-- Field MOUSEB_LEFT (Read only)
--
-- @field [parent=#global] #number MOUSEB_LEFT

---
-- Field MOUSEB_MIDDLE (Read only)
--
-- @field [parent=#global] #number MOUSEB_MIDDLE

---
-- Field MOUSEB_RIGHT (Read only)
--
-- @field [parent=#global] #number MOUSEB_RIGHT

---
-- Field M_DEGTORAD (Read only)
--
-- @field [parent=#global] #number M_DEGTORAD

---
-- Field M_DEGTORAD_2 (Read only)
--
-- @field [parent=#global] #number M_DEGTORAD_2

---
-- Field M_EPSILON (Read only)
--
-- @field [parent=#global] #number M_EPSILON

---
-- Field M_INFINITY (Read only)
--
-- @field [parent=#global] #number M_INFINITY

---
-- Field M_LARGE_EPSILON (Read only)
--
-- @field [parent=#global] #number M_LARGE_EPSILON

---
-- Field M_LARGE_VALUE (Read only)
--
-- @field [parent=#global] #number M_LARGE_VALUE

---
-- Field M_MAX_FOV (Read only)
--
-- @field [parent=#global] #number M_MAX_FOV

---
-- Field M_MAX_INT (Read only)
--
-- @field [parent=#global] #number M_MAX_INT

---
-- Field M_MAX_UNSIGNED (Read only)
--
-- @field [parent=#global] #number M_MAX_UNSIGNED

---
-- Field M_MIN_INT (Read only)
--
-- @field [parent=#global] #number M_MIN_INT

---
-- Field M_MIN_NEARCLIP (Read only)
--
-- @field [parent=#global] #number M_MIN_NEARCLIP

---
-- Field M_MIN_UNSIGNED (Read only)
--
-- @field [parent=#global] #number M_MIN_UNSIGNED

---
-- Field M_PI (Read only)
--
-- @field [parent=#global] #number M_PI

---
-- Field M_RADTODEG (Read only)
--
-- @field [parent=#global] #number M_RADTODEG

---
-- Field NUM_FRUSTUM_PLANES (Read only)
--
-- @field [parent=#global] #number NUM_FRUSTUM_PLANES

---
-- Field NUM_FRUSTUM_VERTICES (Read only)
--
-- @field [parent=#global] #number NUM_FRUSTUM_VERTICES

---
-- Field QUALITY_HIGH (Read only)
--
-- @field [parent=#global] #number QUALITY_HIGH

---
-- Field QUALITY_LOW (Read only)
--
-- @field [parent=#global] #number QUALITY_LOW

---
-- Field QUALITY_MAX (Read only)
--
-- @field [parent=#global] #number QUALITY_MAX

---
-- Field QUALITY_MEDIUM (Read only)
--
-- @field [parent=#global] #number QUALITY_MEDIUM

---
-- Field QUAL_ALT (Read only)
--
-- @field [parent=#global] #number QUAL_ALT

---
-- Field QUAL_ANY (Read only)
--
-- @field [parent=#global] #number QUAL_ANY

---
-- Field QUAL_CTRL (Read only)
--
-- @field [parent=#global] #number QUAL_CTRL

---
-- Field QUAL_SHIFT (Read only)
--
-- @field [parent=#global] #number QUAL_SHIFT

---
-- Field SCAN_DIRS (Read only)
--
-- @field [parent=#global] #number SCAN_DIRS

---
-- Field SCAN_FILES (Read only)
--
-- @field [parent=#global] #number SCAN_FILES

---
-- Field SCAN_HIDDEN (Read only)
--
-- @field [parent=#global] #number SCAN_HIDDEN

---
-- Field SHADOWQUALITY_HIGH_16BIT (Read only)
--
-- @field [parent=#global] #number SHADOWQUALITY_HIGH_16BIT

---
-- Field SHADOWQUALITY_HIGH_24BIT (Read only)
--
-- @field [parent=#global] #number SHADOWQUALITY_HIGH_24BIT

---
-- Field SHADOWQUALITY_LOW_16BIT (Read only)
--
-- @field [parent=#global] #number SHADOWQUALITY_LOW_16BIT

---
-- Field SHADOWQUALITY_LOW_24BIT (Read only)
--
-- @field [parent=#global] #number SHADOWQUALITY_LOW_24BIT

---
-- Field SHADOW_MIN_PIXELS (Read only)
--
-- @field [parent=#global] #number SHADOW_MIN_PIXELS

---
-- Field VO_DISABLE_OCCLUSION (Read only)
--
-- @field [parent=#global] #number VO_DISABLE_OCCLUSION

---
-- Field VO_DISABLE_SHADOWS (Read only)
--
-- @field [parent=#global] #number VO_DISABLE_SHADOWS

---
-- Field VO_LOW_MATERIAL_QUALITY (Read only)
--
-- @field [parent=#global] #number VO_LOW_MATERIAL_QUALITY

---
-- Field VO_NONE (Read only)
--
-- @field [parent=#global] #number VO_NONE


return nil
