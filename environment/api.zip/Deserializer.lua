---
-- Module Deserializer
-- Generated on 2014-03-13
--
-- @module Deserializer

---
-- Function Read
--
-- @function [parent=#Deserializer] Read
-- @param self Self reference
-- @param #number size size
-- @return VectorBuffer#VectorBuffer

---
-- Function Seek
--
-- @function [parent=#Deserializer] Seek
-- @param self Self reference
-- @param #number position position
-- @return #number

---
-- Function GetName
--
-- @function [parent=#Deserializer] GetName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetChecksum
--
-- @function [parent=#Deserializer] GetChecksum
-- @param self Self reference
-- @return #number

---
-- Function GetPosition
--
-- @function [parent=#Deserializer] GetPosition
-- @param self Self reference
-- @return #number

---
-- Function GetSize
--
-- @function [parent=#Deserializer] GetSize
-- @param self Self reference
-- @return #number

---
-- Function IsEof
--
-- @function [parent=#Deserializer] IsEof
-- @param self Self reference
-- @return #boolean

---
-- Function ReadInt
--
-- @function [parent=#Deserializer] ReadInt
-- @param self Self reference
-- @return #number

---
-- Function ReadShort
--
-- @function [parent=#Deserializer] ReadShort
-- @param self Self reference
-- @return short#short

---
-- Function ReadByte
--
-- @function [parent=#Deserializer] ReadByte
-- @param self Self reference
-- @return #string

---
-- Function ReadUInt
--
-- @function [parent=#Deserializer] ReadUInt
-- @param self Self reference
-- @return #number

---
-- Function ReadUShort
--
-- @function [parent=#Deserializer] ReadUShort
-- @param self Self reference
-- @return short#short

---
-- Function ReadUByte
--
-- @function [parent=#Deserializer] ReadUByte
-- @param self Self reference
-- @return #string

---
-- Function ReadBool
--
-- @function [parent=#Deserializer] ReadBool
-- @param self Self reference
-- @return #boolean

---
-- Function ReadFloat
--
-- @function [parent=#Deserializer] ReadFloat
-- @param self Self reference
-- @return #number

---
-- Function ReadIntRect
--
-- @function [parent=#Deserializer] ReadIntRect
-- @param self Self reference
-- @return IntRect#IntRect

---
-- Function ReadIntVector2
--
-- @function [parent=#Deserializer] ReadIntVector2
-- @param self Self reference
-- @return IntVector2#IntVector2

---
-- Function ReadRect
--
-- @function [parent=#Deserializer] ReadRect
-- @param self Self reference
-- @return Rect#Rect

---
-- Function ReadVector2
--
-- @function [parent=#Deserializer] ReadVector2
-- @param self Self reference
-- @return Vector2#Vector2

---
-- Function ReadVector3
--
-- @function [parent=#Deserializer] ReadVector3
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function ReadPackedVector3
--
-- @function [parent=#Deserializer] ReadPackedVector3
-- @param self Self reference
-- @param #number maxAbsCoord maxAbsCoord
-- @return Vector3#Vector3

---
-- Function ReadVector4
--
-- @function [parent=#Deserializer] ReadVector4
-- @param self Self reference
-- @return Vector4#Vector4

---
-- Function ReadQuaternion
--
-- @function [parent=#Deserializer] ReadQuaternion
-- @param self Self reference
-- @return Quaternion#Quaternion

---
-- Function ReadPackedQuaternion
--
-- @function [parent=#Deserializer] ReadPackedQuaternion
-- @param self Self reference
-- @return Quaternion#Quaternion

---
-- Function ReadColor
--
-- @function [parent=#Deserializer] ReadColor
-- @param self Self reference
-- @return Color#Color

---
-- Function ReadBoundingBox
--
-- @function [parent=#Deserializer] ReadBoundingBox
-- @param self Self reference
-- @return BoundingBox#BoundingBox

---
-- Function ReadString
--
-- @function [parent=#Deserializer] ReadString
-- @param self Self reference
-- @return #string

---
-- Function ReadFileID
--
-- @function [parent=#Deserializer] ReadFileID
-- @param self Self reference
-- @return #string

---
-- Function ReadStringHash
--
-- @function [parent=#Deserializer] ReadStringHash
-- @param self Self reference
-- @return StringHash#StringHash

---
-- Function ReadShortStringHash
--
-- @function [parent=#Deserializer] ReadShortStringHash
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function ReadBuffer
--
-- @function [parent=#Deserializer] ReadBuffer
-- @param self Self reference
-- @return VectorBuffer#VectorBuffer

---
-- Function ReadResourceRef
--
-- @function [parent=#Deserializer] ReadResourceRef
-- @param self Self reference
-- @return ResourceRef#ResourceRef

---
-- Function ReadResourceRefList
--
-- @function [parent=#Deserializer] ReadResourceRefList
-- @param self Self reference
-- @return ResourceRefList#ResourceRefList

---
-- Function ReadVariant
--
-- @function [parent=#Deserializer] ReadVariant
-- @param self Self reference
-- @return Variant#Variant

---
-- Function ReadVariant
--
-- @function [parent=#Deserializer] ReadVariant
-- @param self Self reference
-- @param VariantType#VariantType type type
-- @return Variant#Variant

---
-- Function ReadVariantVector
--
-- @function [parent=#Deserializer] ReadVariantVector
-- @param self Self reference
-- @return VariantVector#VariantVector

---
-- Function ReadVariantMap
--
-- @function [parent=#Deserializer] ReadVariantMap
-- @param self Self reference
-- @return VariantMap#VariantMap

---
-- Function ReadVLE
--
-- @function [parent=#Deserializer] ReadVLE
-- @param self Self reference
-- @return #number

---
-- Function ReadNetID
--
-- @function [parent=#Deserializer] ReadNetID
-- @param self Self reference
-- @return #number

---
-- Function ReadLine
--
-- @function [parent=#Deserializer] ReadLine
-- @param self Self reference
-- @return #string

---
-- Field name (Read only)
--
-- @field [parent=#Deserializer] #string name

---
-- Field checksum (Read only)
--
-- @field [parent=#Deserializer] #number checksum

---
-- Field position (Read only)
--
-- @field [parent=#Deserializer] #number position

---
-- Field size (Read only)
--
-- @field [parent=#Deserializer] #number size

---
-- Field eof (Read only)
--
-- @field [parent=#Deserializer] #boolean eof


return nil
