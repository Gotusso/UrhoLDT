---
-- Module Deserializer
-- Generated on 2014-05-31
--
-- @module Deserializer

---
-- Function Read()
--
-- @function [parent=#Deserializer] Read
-- @param self Self reference
-- @param #number size size
-- @return VectorBuffer#VectorBuffer

---
-- Function Seek()
-- Set position from the beginning of the stream.
--
-- @function [parent=#Deserializer] Seek
-- @param self Self reference
-- @param #number position position
-- @return #number

---
-- Function GetName()
-- Return name of the stream.
--
-- @function [parent=#Deserializer] GetName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetChecksum()
-- Return a checksum if applicable.
--
-- @function [parent=#Deserializer] GetChecksum
-- @param self Self reference
-- @return #number

---
-- Function GetPosition()
-- Return current position.
--
-- @function [parent=#Deserializer] GetPosition
-- @param self Self reference
-- @return #number

---
-- Function GetSize()
-- Return size.
--
-- @function [parent=#Deserializer] GetSize
-- @param self Self reference
-- @return #number

---
-- Function IsEof()
-- Return whether the end of stream has been reached.
--
-- @function [parent=#Deserializer] IsEof
-- @param self Self reference
-- @return #boolean

---
-- Function ReadInt()
-- Read a 32-bit integer.
--
-- @function [parent=#Deserializer] ReadInt
-- @param self Self reference
-- @return #number

---
-- Function ReadShort()
-- Read a 16-bit integer.
--
-- @function [parent=#Deserializer] ReadShort
-- @param self Self reference
-- @return short#short

---
-- Function ReadByte()
-- Read an 8-bit integer.
--
-- @function [parent=#Deserializer] ReadByte
-- @param self Self reference
-- @return #string

---
-- Function ReadUInt()
-- Read a 32-bit unsigned integer.
--
-- @function [parent=#Deserializer] ReadUInt
-- @param self Self reference
-- @return #number

---
-- Function ReadUShort()
-- Read a 16-bit unsigned integer.
--
-- @function [parent=#Deserializer] ReadUShort
-- @param self Self reference
-- @return short#short

---
-- Function ReadUByte()
-- Read an 8-bit unsigned integer.
--
-- @function [parent=#Deserializer] ReadUByte
-- @param self Self reference
-- @return #string

---
-- Function ReadBool()
-- Read a bool.
--
-- @function [parent=#Deserializer] ReadBool
-- @param self Self reference
-- @return #boolean

---
-- Function ReadFloat()
-- Read a float.
--
-- @function [parent=#Deserializer] ReadFloat
-- @param self Self reference
-- @return #number

---
-- Function ReadIntRect()
-- Read an IntRect.
--
-- @function [parent=#Deserializer] ReadIntRect
-- @param self Self reference
-- @return IntRect#IntRect

---
-- Function ReadIntVector2()
-- Read an IntVector2.
--
-- @function [parent=#Deserializer] ReadIntVector2
-- @param self Self reference
-- @return IntVector2#IntVector2

---
-- Function ReadRect()
-- Read a Rect.
--
-- @function [parent=#Deserializer] ReadRect
-- @param self Self reference
-- @return Rect#Rect

---
-- Function ReadVector2()
-- Read a Vector2.
--
-- @function [parent=#Deserializer] ReadVector2
-- @param self Self reference
-- @return Vector2#Vector2

---
-- Function ReadVector3()
-- Read a Vector3.
--
-- @function [parent=#Deserializer] ReadVector3
-- @param self Self reference
-- @return Vector3#Vector3

---
-- Function ReadPackedVector3()
-- Read a Vector3 packed into 3 x 16 bits with the specified maximum absolute range.
--
-- @function [parent=#Deserializer] ReadPackedVector3
-- @param self Self reference
-- @param #number maxAbsCoord maxAbsCoord
-- @return Vector3#Vector3

---
-- Function ReadVector4()
-- Read a Vector4.
--
-- @function [parent=#Deserializer] ReadVector4
-- @param self Self reference
-- @return Vector4#Vector4

---
-- Function ReadQuaternion()
-- Read a quaternion.
--
-- @function [parent=#Deserializer] ReadQuaternion
-- @param self Self reference
-- @return Quaternion#Quaternion

---
-- Function ReadPackedQuaternion()
-- Read a quaternion with each component packed in 16 bits.
--
-- @function [parent=#Deserializer] ReadPackedQuaternion
-- @param self Self reference
-- @return Quaternion#Quaternion

---
-- Function ReadMatrix3()
-- Read a Matrix3.
--
-- @function [parent=#Deserializer] ReadMatrix3
-- @param self Self reference
-- @return Matrix3#Matrix3

---
-- Function ReadMatrix3x4()
-- Read a Matrix3x4.
--
-- @function [parent=#Deserializer] ReadMatrix3x4
-- @param self Self reference
-- @return Matrix3x4#Matrix3x4

---
-- Function ReadMatrix4()
-- Read a Matrix4.
--
-- @function [parent=#Deserializer] ReadMatrix4
-- @param self Self reference
-- @return Matrix4#Matrix4

---
-- Function ReadColor()
-- Read a color.
--
-- @function [parent=#Deserializer] ReadColor
-- @param self Self reference
-- @return Color#Color

---
-- Function ReadBoundingBox()
-- Read a bounding box.
--
-- @function [parent=#Deserializer] ReadBoundingBox
-- @param self Self reference
-- @return BoundingBox#BoundingBox

---
-- Function ReadString()
-- Read a null-terminated string.
--
-- @function [parent=#Deserializer] ReadString
-- @param self Self reference
-- @return #string

---
-- Function ReadFileID()
-- Read a four-letter file ID.
--
-- @function [parent=#Deserializer] ReadFileID
-- @param self Self reference
-- @return #string

---
-- Function ReadStringHash()
-- Read a 32-bit StringHash.
--
-- @function [parent=#Deserializer] ReadStringHash
-- @param self Self reference
-- @return StringHash#StringHash

---
-- Function ReadShortStringHash()
-- Read a 16-bit ShortStringHash.
--
-- @function [parent=#Deserializer] ReadShortStringHash
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function ReadBuffer()
-- Read a buffer with size encoded as VLE.
--
-- @function [parent=#Deserializer] ReadBuffer
-- @param self Self reference
-- @return VectorBuffer#VectorBuffer

---
-- Function ReadResourceRef()
-- Read a resource reference.
--
-- @function [parent=#Deserializer] ReadResourceRef
-- @param self Self reference
-- @return ResourceRef#ResourceRef

---
-- Function ReadResourceRefList()
-- Read a resource reference list.
--
-- @function [parent=#Deserializer] ReadResourceRefList
-- @param self Self reference
-- @return ResourceRefList#ResourceRefList

---
-- Function ReadVariant()
-- Read a variant.
--
-- @function [parent=#Deserializer] ReadVariant
-- @param self Self reference
-- @return Variant#Variant

---
-- Function ReadVariant()
-- Read a variant whose type is already known.
--
-- @function [parent=#Deserializer] ReadVariant
-- @param self Self reference
-- @param VariantType#VariantType type type
-- @return Variant#Variant

---
-- Function ReadVariantVector()
-- Read a variant vector.
--
-- @function [parent=#Deserializer] ReadVariantVector
-- @param self Self reference
-- @return VariantVector#VariantVector

---
-- Function ReadVariantMap()
-- Read a variant map.
--
-- @function [parent=#Deserializer] ReadVariantMap
-- @param self Self reference
-- @return VariantMap#VariantMap

---
-- Function ReadVLE()
-- Read a variable-length encoded unsigned integer, which can use 29 bits maximum.
--
-- @function [parent=#Deserializer] ReadVLE
-- @param self Self reference
-- @return #number

---
-- Function ReadNetID()
-- Read a 24-bit network object ID.
--
-- @function [parent=#Deserializer] ReadNetID
-- @param self Self reference
-- @return #number

---
-- Function ReadLine()
-- Read a text line.
--
-- @function [parent=#Deserializer] ReadLine
-- @param self Self reference
-- @return #string

---
-- Field name (Read only)
--
-- @field [parent=#Deserializer] #string name

---
-- Field checksum (Read only)
--
-- @field [parent=#Deserializer] #number checksum

---
-- Field position (Read only)
--
-- @field [parent=#Deserializer] #number position

---
-- Field size (Read only)
--
-- @field [parent=#Deserializer] #number size

---
-- Field eof (Read only)
--
-- @field [parent=#Deserializer] #boolean eof


return nil
