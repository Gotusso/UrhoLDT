---
-- Module Deserializer
--
-- @module Deserializer

---
-- Function Read
--
-- @function [parent=#Deserializer] Read
-- @param #number sizesize
-- @return VectorBuffer#VectorBuffer

---
-- Function Seek
--
-- @function [parent=#Deserializer] Seek
-- @param #number positionposition
-- @return #number

---
-- Function GetName
--
-- @function [parent=#Deserializer] GetName
-- @return const String#const String

---
-- Function GetChecksum
--
-- @function [parent=#Deserializer] GetChecksum
-- @return #number

---
-- Function GetPosition
--
-- @function [parent=#Deserializer] GetPosition
-- @return #number

---
-- Function GetSize
--
-- @function [parent=#Deserializer] GetSize
-- @return #number

---
-- Function IsEof
--
-- @function [parent=#Deserializer] IsEof
-- @return #boolean

---
-- Function ReadInt
--
-- @function [parent=#Deserializer] ReadInt
-- @return #number

---
-- Function ReadShort
--
-- @function [parent=#Deserializer] ReadShort
-- @return short#short

---
-- Function ReadByte
--
-- @function [parent=#Deserializer] ReadByte
-- @return #string

---
-- Function ReadUInt
--
-- @function [parent=#Deserializer] ReadUInt
-- @return #number

---
-- Function ReadUShort
--
-- @function [parent=#Deserializer] ReadUShort
-- @return short#short

---
-- Function ReadUByte
--
-- @function [parent=#Deserializer] ReadUByte
-- @return #string

---
-- Function ReadBool
--
-- @function [parent=#Deserializer] ReadBool
-- @return #boolean

---
-- Function ReadFloat
--
-- @function [parent=#Deserializer] ReadFloat
-- @return #number

---
-- Function ReadIntRect
--
-- @function [parent=#Deserializer] ReadIntRect
-- @return IntRect#IntRect

---
-- Function ReadIntVector2
--
-- @function [parent=#Deserializer] ReadIntVector2
-- @return IntVector2#IntVector2

---
-- Function ReadRect
--
-- @function [parent=#Deserializer] ReadRect
-- @return Rect#Rect

---
-- Function ReadVector2
--
-- @function [parent=#Deserializer] ReadVector2
-- @return Vector2#Vector2

---
-- Function ReadVector3
--
-- @function [parent=#Deserializer] ReadVector3
-- @return Vector3#Vector3

---
-- Function ReadPackedVector3
--
-- @function [parent=#Deserializer] ReadPackedVector3
-- @param #number maxAbsCoordmaxAbsCoord
-- @return Vector3#Vector3

---
-- Function ReadVector4
--
-- @function [parent=#Deserializer] ReadVector4
-- @return Vector4#Vector4

---
-- Function ReadQuaternion
--
-- @function [parent=#Deserializer] ReadQuaternion
-- @return Quaternion#Quaternion

---
-- Function ReadPackedQuaternion
--
-- @function [parent=#Deserializer] ReadPackedQuaternion
-- @return Quaternion#Quaternion

---
-- Function ReadColor
--
-- @function [parent=#Deserializer] ReadColor
-- @return Color#Color

---
-- Function ReadBoundingBox
--
-- @function [parent=#Deserializer] ReadBoundingBox
-- @return BoundingBox#BoundingBox

---
-- Function ReadString
--
-- @function [parent=#Deserializer] ReadString
-- @return #string

---
-- Function ReadFileID
--
-- @function [parent=#Deserializer] ReadFileID
-- @return #string

---
-- Function ReadStringHash
--
-- @function [parent=#Deserializer] ReadStringHash
-- @return StringHash#StringHash

---
-- Function ReadShortStringHash
--
-- @function [parent=#Deserializer] ReadShortStringHash
-- @return ShortStringHash#ShortStringHash

---
-- Function ReadBuffer
--
-- @function [parent=#Deserializer] ReadBuffer
-- @return VectorBuffer#VectorBuffer

---
-- Function ReadResourceRef
--
-- @function [parent=#Deserializer] ReadResourceRef
-- @return ResourceRef#ResourceRef

---
-- Function ReadResourceRefList
--
-- @function [parent=#Deserializer] ReadResourceRefList
-- @return ResourceRefList#ResourceRefList

---
-- Function ReadVariant
--
-- @function [parent=#Deserializer] ReadVariant
-- @return Variant#Variant

---
-- Function ReadVariant
--
-- @function [parent=#Deserializer] ReadVariant
-- @param VariantType#VariantType typetype
-- @return Variant#Variant

---
-- Function ReadVariantVector
--
-- @function [parent=#Deserializer] ReadVariantVector
-- @return VariantVector#VariantVector

---
-- Function ReadVariantMap
--
-- @function [parent=#Deserializer] ReadVariantMap
-- @return VariantMap#VariantMap

---
-- Function ReadVLE
--
-- @function [parent=#Deserializer] ReadVLE
-- @return #number

---
-- Function ReadNetID
--
-- @function [parent=#Deserializer] ReadNetID
-- @return #number

---
-- Function ReadLine
--
-- @function [parent=#Deserializer] ReadLine
-- @return #string

---
-- Field name (Read only)
--
-- @field [parent=#Deserializer] #string name

---
-- Field checksum (Read only)
--
-- @field [parent=#Deserializer] #number checksum

---
-- Field position (Read only)
--
-- @field [parent=#Deserializer] #number position

---
-- Field size (Read only)
--
-- @field [parent=#Deserializer] #number size

---
-- Field eof (Read only)
--
-- @field [parent=#Deserializer] #boolean eof


return nil
