---
-- Module StaticModelGroup
-- Extends StaticModel
--
-- @module StaticModelGroup

---
-- Function AddInstanceNode
--
-- @function [parent=#StaticModelGroup] AddInstanceNode
-- @param Node#Node nodenode

---
-- Function RemoveInstanceNode
--
-- @function [parent=#StaticModelGroup] RemoveInstanceNode
-- @param Node#Node nodenode

---
-- Function RemoveAllInstanceNodes
--
-- @function [parent=#StaticModelGroup] RemoveAllInstanceNodes

---
-- Function GetNumInstanceNodes
--
-- @function [parent=#StaticModelGroup] GetNumInstanceNodes
-- @return #number

---
-- Function GetInstanceNode
--
-- @function [parent=#StaticModelGroup] GetInstanceNode
-- @param #number indexindex
-- @return Node#Node

---
-- Field numInstanceNodes (Read only)
--
-- @field [parent=#StaticModelGroup] #number numInstanceNodes


return nil
