---
-- Module StaticModelGroup
-- Module StaticModelGroup extends StaticModel
-- Generated on 2014-05-31
--
-- @module StaticModelGroup

---
-- Function AddInstanceNode()
-- Add an instance scene node. It does not need any drawable components of its own.
--
-- @function [parent=#StaticModelGroup] AddInstanceNode
-- @param self Self reference
-- @param Node#Node node node

---
-- Function RemoveInstanceNode()
-- Remove an instance scene node.
--
-- @function [parent=#StaticModelGroup] RemoveInstanceNode
-- @param self Self reference
-- @param Node#Node node node

---
-- Function RemoveAllInstanceNodes()
-- Remove all instance scene nodes.
--
-- @function [parent=#StaticModelGroup] RemoveAllInstanceNodes
-- @param self Self reference

---
-- Function GetNumInstanceNodes()
-- Return number of instance nodes.
--
-- @function [parent=#StaticModelGroup] GetNumInstanceNodes
-- @param self Self reference
-- @return #number

---
-- Function GetInstanceNode()
-- Return instance node by index.
--
-- @function [parent=#StaticModelGroup] GetInstanceNode
-- @param self Self reference
-- @param #number index index
-- @return Node#Node

---
-- Field numInstanceNodes (Read only)
--
-- @field [parent=#StaticModelGroup] #number numInstanceNodes


return nil
