---
-- Module StaticModelGroup
-- extends StaticModel
--
-- @module StaticModelGroup

---
-- Function AddInstanceNode
--
-- @function [parent=#StaticModelGroup] AddInstanceNode
-- @param Node#Node nodenode

---
-- Function RemoveInstanceNode
--
-- @function [parent=#StaticModelGroup] RemoveInstanceNode
-- @param Node#Node nodenode

---
-- Function RemoveAllInstanceNodes
--
-- @function [parent=#StaticModelGroup] RemoveAllInstanceNodes

---
-- Function GetNumInstanceNodes
--
-- @function [parent=#StaticModelGroup] GetNumInstanceNodes
-- @return #number

---
-- Function GetInstanceNode
--
-- @function [parent=#StaticModelGroup] GetInstanceNode
-- @param #number indexindex
-- @return Node#Node

---
-- Field numInstanceNodes (Read only)
--
-- @field [parent=#StaticModelGroup] #number numInstanceNodes

---
-- Function SetModel
--
-- @function [parent=#StaticModelGroup] SetModel
-- @param Model#Model modelmodel

---
-- Function SetMaterial
--
-- @function [parent=#StaticModelGroup] SetMaterial
-- @param Material#Material materialmaterial

---
-- Function SetMaterial
--
-- @function [parent=#StaticModelGroup] SetMaterial
-- @param #number indexindex
-- @param Material#Material materialmaterial
-- @return #boolean

---
-- Function SetOcclusionLodLevel
--
-- @function [parent=#StaticModelGroup] SetOcclusionLodLevel
-- @param #number levellevel

---
-- Function ApplyMaterialList
--
-- @function [parent=#StaticModelGroup] ApplyMaterialList
-- @param #string fileNamefileName

---
-- Function GetModel
--
-- @function [parent=#StaticModelGroup] GetModel
-- @return Model#Model

---
-- Function GetNumGeometries
--
-- @function [parent=#StaticModelGroup] GetNumGeometries
-- @return #number

---
-- Function GetMaterial
--
-- @function [parent=#StaticModelGroup] GetMaterial
-- @param #number indexindex
-- @return Material#Material

---
-- Function GetOcclusionLodLevel
--
-- @function [parent=#StaticModelGroup] GetOcclusionLodLevel
-- @return #number

---
-- Function IsInside
--
-- @function [parent=#StaticModelGroup] IsInside
-- @param Vector3#Vector3 pointpoint
-- @return #boolean

---
-- Function IsInsideLocal
--
-- @function [parent=#StaticModelGroup] IsInsideLocal
-- @param Vector3#Vector3 pointpoint
-- @return #boolean

---
-- Field model
--
-- @field [parent=#StaticModelGroup] Model#Model model

---
-- Field material
--
-- @field [parent=#StaticModelGroup] Material#Material material

---
-- Field boundingBox (Read only)
--
-- @field [parent=#StaticModelGroup] BoundingBox#BoundingBox boundingBox

---
-- Field numGeometries (Read only)
--
-- @field [parent=#StaticModelGroup] #number numGeometries

---
-- Field occlusionLodLevel
--
-- @field [parent=#StaticModelGroup] #number occlusionLodLevel

---
-- Function SetDrawDistance
--
-- @function [parent=#StaticModelGroup] SetDrawDistance
-- @param #number distancedistance

---
-- Function SetShadowDistance
--
-- @function [parent=#StaticModelGroup] SetShadowDistance
-- @param #number distancedistance

---
-- Function SetLodBias
--
-- @function [parent=#StaticModelGroup] SetLodBias
-- @param #number biasbias

---
-- Function SetViewMask
--
-- @function [parent=#StaticModelGroup] SetViewMask
-- @param #number maskmask

---
-- Function SetLightMask
--
-- @function [parent=#StaticModelGroup] SetLightMask
-- @param #number maskmask

---
-- Function SetShadowMask
--
-- @function [parent=#StaticModelGroup] SetShadowMask
-- @param #number maskmask

---
-- Function SetZoneMask
--
-- @function [parent=#StaticModelGroup] SetZoneMask
-- @param #number maskmask

---
-- Function SetMaxLights
--
-- @function [parent=#StaticModelGroup] SetMaxLights
-- @param #number numnum

---
-- Function SetCastShadows
--
-- @function [parent=#StaticModelGroup] SetCastShadows
-- @param #boolean enableenable

---
-- Function SetOccluder
--
-- @function [parent=#StaticModelGroup] SetOccluder
-- @param #boolean enableenable

---
-- Function SetOccludee
--
-- @function [parent=#StaticModelGroup] SetOccludee
-- @param #boolean enableenable

---
-- Function MarkForUpdate
--
-- @function [parent=#StaticModelGroup] MarkForUpdate

---
-- Function GetBoundingBox
--
-- @function [parent=#StaticModelGroup] GetBoundingBox
-- @return const BoundingBox#const BoundingBox

---
-- Function GetWorldBoundingBox
--
-- @function [parent=#StaticModelGroup] GetWorldBoundingBox
-- @return const BoundingBox#const BoundingBox

---
-- Function GetDrawableFlags
--
-- @function [parent=#StaticModelGroup] GetDrawableFlags
-- @return #string

---
-- Function GetDrawDistance
--
-- @function [parent=#StaticModelGroup] GetDrawDistance
-- @return #number

---
-- Function GetShadowDistance
--
-- @function [parent=#StaticModelGroup] GetShadowDistance
-- @return #number

---
-- Function GetLodBias
--
-- @function [parent=#StaticModelGroup] GetLodBias
-- @return #number

---
-- Function GetViewMask
--
-- @function [parent=#StaticModelGroup] GetViewMask
-- @return #number

---
-- Function GetLightMask
--
-- @function [parent=#StaticModelGroup] GetLightMask
-- @return #number

---
-- Function GetShadowMask
--
-- @function [parent=#StaticModelGroup] GetShadowMask
-- @return #number

---
-- Function GetZoneMask
--
-- @function [parent=#StaticModelGroup] GetZoneMask
-- @return #number

---
-- Function GetMaxLights
--
-- @function [parent=#StaticModelGroup] GetMaxLights
-- @return #number

---
-- Function GetCastShadows
--
-- @function [parent=#StaticModelGroup] GetCastShadows
-- @return #boolean

---
-- Function IsOccluder
--
-- @function [parent=#StaticModelGroup] IsOccluder
-- @return #boolean

---
-- Function IsOccludee
--
-- @function [parent=#StaticModelGroup] IsOccludee
-- @return #boolean

---
-- Function SetZone
--
-- @function [parent=#StaticModelGroup] SetZone
-- @param Zone#Zone zonezone
-- @param #boolean temporarytemporary

---
-- Function SetSortValue
--
-- @function [parent=#StaticModelGroup] SetSortValue
-- @param #number valuevalue

---
-- Function SetMinMaxZ
--
-- @function [parent=#StaticModelGroup] SetMinMaxZ
-- @param #number minZminZ
-- @param #number maxZmaxZ

---
-- Function MarkInView
--
-- @function [parent=#StaticModelGroup] MarkInView
-- @param FrameInfo#FrameInfo frameframe
-- @param #boolean mainViewmainView

---
-- Function ClearLights
--
-- @function [parent=#StaticModelGroup] ClearLights

---
-- Function AddLight
--
-- @function [parent=#StaticModelGroup] AddLight
-- @param Light#Light lightlight

---
-- Function AddVertexLight
--
-- @function [parent=#StaticModelGroup] AddVertexLight
-- @param Light#Light lightlight

---
-- Function LimitLights
--
-- @function [parent=#StaticModelGroup] LimitLights

---
-- Function LimitVertexLights
--
-- @function [parent=#StaticModelGroup] LimitVertexLights

---
-- Function SetBasePass
--
-- @function [parent=#StaticModelGroup] SetBasePass
-- @param #number batchIndexbatchIndex

---
-- Function GetOctant
--
-- @function [parent=#StaticModelGroup] GetOctant
-- @return Octant#Octant

---
-- Function GetZone
--
-- @function [parent=#StaticModelGroup] GetZone
-- @return Zone#Zone

---
-- Function GetLastZone
--
-- @function [parent=#StaticModelGroup] GetLastZone
-- @return Zone#Zone

---
-- Function IsZoneDirty
--
-- @function [parent=#StaticModelGroup] IsZoneDirty
-- @return #boolean

---
-- Function GetDistance
--
-- @function [parent=#StaticModelGroup] GetDistance
-- @return #number

---
-- Function GetLodDistance
--
-- @function [parent=#StaticModelGroup] GetLodDistance
-- @return #number

---
-- Function GetSortValue
--
-- @function [parent=#StaticModelGroup] GetSortValue
-- @return #number

---
-- Function IsInView
--
-- @function [parent=#StaticModelGroup] IsInView
-- @param #number frameNumberframeNumber
-- @return #boolean

---
-- Function IsInView
--
-- @function [parent=#StaticModelGroup] IsInView
-- @param FrameInfo#FrameInfo frameframe
-- @param #boolean mainViewmainView
-- @return #boolean

---
-- Function HasBasePass
--
-- @function [parent=#StaticModelGroup] HasBasePass
-- @param #number batchIndexbatchIndex
-- @return #boolean

---
-- Function GetFirstLight
--
-- @function [parent=#StaticModelGroup] GetFirstLight
-- @return Light#Light

---
-- Function GetMinZ
--
-- @function [parent=#StaticModelGroup] GetMinZ
-- @return #number

---
-- Function GetMaxZ
--
-- @function [parent=#StaticModelGroup] GetMaxZ
-- @return #number

---
-- Field worldBoundingBox (Read only)
--
-- @field [parent=#StaticModelGroup] BoundingBox#BoundingBox worldBoundingBox

---
-- Field drawableFlags (Read only)
--
-- @field [parent=#StaticModelGroup] #string drawableFlags

---
-- Field drawDistance
--
-- @field [parent=#StaticModelGroup] #number drawDistance

---
-- Field shadowDistance
--
-- @field [parent=#StaticModelGroup] #number shadowDistance

---
-- Field lodBias
--
-- @field [parent=#StaticModelGroup] #number lodBias

---
-- Field viewMask
--
-- @field [parent=#StaticModelGroup] #number viewMask

---
-- Field lightMask
--
-- @field [parent=#StaticModelGroup] #number lightMask

---
-- Field shadowMask
--
-- @field [parent=#StaticModelGroup] #number shadowMask

---
-- Field zoneMask
--
-- @field [parent=#StaticModelGroup] #number zoneMask

---
-- Field maxLights
--
-- @field [parent=#StaticModelGroup] #number maxLights

---
-- Field castShadows
--
-- @field [parent=#StaticModelGroup] #boolean castShadows

---
-- Field occluder
--
-- @field [parent=#StaticModelGroup] #boolean occluder

---
-- Field occludee
--
-- @field [parent=#StaticModelGroup] #boolean occludee

---
-- Field octant (Read only)
--
-- @field [parent=#StaticModelGroup] Octant#Octant octant

---
-- Field zone
--
-- @field [parent=#StaticModelGroup] Zone#Zone zone

---
-- Field lastZone (Read only)
--
-- @field [parent=#StaticModelGroup] Zone#Zone lastZone

---
-- Field zoneDirty (Read only)
--
-- @field [parent=#StaticModelGroup] #boolean zoneDirty

---
-- Field distance (Read only)
--
-- @field [parent=#StaticModelGroup] #number distance

---
-- Field lodDistance (Read only)
--
-- @field [parent=#StaticModelGroup] #number lodDistance

---
-- Field sortValue
--
-- @field [parent=#StaticModelGroup] #number sortValue

---
-- Field firstLight (Read only)
--
-- @field [parent=#StaticModelGroup] Light#Light firstLight

---
-- Field minZ (Read only)
--
-- @field [parent=#StaticModelGroup] #number minZ

---
-- Field maxZ (Read only)
--
-- @field [parent=#StaticModelGroup] #number maxZ

---
-- Function SetEnabled
--
-- @function [parent=#StaticModelGroup] SetEnabled
-- @param #boolean enableenable

---
-- Function Remove
--
-- @function [parent=#StaticModelGroup] Remove

---
-- Function GetID
--
-- @function [parent=#StaticModelGroup] GetID
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#StaticModelGroup] GetNode
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#StaticModelGroup] GetScene
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#StaticModelGroup] IsEnabled
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#StaticModelGroup] IsEnabledEffective
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#StaticModelGroup] GetComponent
-- @param ShortStringHash#ShortStringHash typetype
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#StaticModelGroup] GetComponent
-- @param #string typetype
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#StaticModelGroup] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#StaticModelGroup] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#StaticModelGroup] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#StaticModelGroup] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#StaticModelGroup] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#StaticModelGroup] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#StaticModelGroup] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#StaticModelGroup] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#StaticModelGroup] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#StaticModelGroup] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#StaticModelGroup] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#StaticModelGroup] #string category


return nil
