---
-- Module StaticModelGroup
-- Module StaticModelGroup extends StaticModel
-- Generated on 2014-03-13
--
-- @module StaticModelGroup

---
-- Function AddInstanceNode
--
-- @function [parent=#StaticModelGroup] AddInstanceNode
-- @param self Self reference
-- @param Node#Node node node

---
-- Function RemoveInstanceNode
--
-- @function [parent=#StaticModelGroup] RemoveInstanceNode
-- @param self Self reference
-- @param Node#Node node node

---
-- Function RemoveAllInstanceNodes
--
-- @function [parent=#StaticModelGroup] RemoveAllInstanceNodes
-- @param self Self reference

---
-- Function GetNumInstanceNodes
--
-- @function [parent=#StaticModelGroup] GetNumInstanceNodes
-- @param self Self reference
-- @return #number

---
-- Function GetInstanceNode
--
-- @function [parent=#StaticModelGroup] GetInstanceNode
-- @param self Self reference
-- @param #number index index
-- @return Node#Node

---
-- Field numInstanceNodes (Read only)
--
-- @field [parent=#StaticModelGroup] #number numInstanceNodes

---
-- Function SetModel
--
-- @function [parent=#StaticModelGroup] SetModel
-- @param self Self reference
-- @param Model#Model model model

---
-- Function SetMaterial
--
-- @function [parent=#StaticModelGroup] SetMaterial
-- @param self Self reference
-- @param Material#Material material material

---
-- Function SetMaterial
--
-- @function [parent=#StaticModelGroup] SetMaterial
-- @param self Self reference
-- @param #number index index
-- @param Material#Material material material
-- @return #boolean

---
-- Function SetOcclusionLodLevel
--
-- @function [parent=#StaticModelGroup] SetOcclusionLodLevel
-- @param self Self reference
-- @param #number level level

---
-- Function ApplyMaterialList
--
-- @function [parent=#StaticModelGroup] ApplyMaterialList
-- @param self Self reference
-- @param #string fileName fileName

---
-- Function GetModel
--
-- @function [parent=#StaticModelGroup] GetModel
-- @param self Self reference
-- @return Model#Model

---
-- Function GetNumGeometries
--
-- @function [parent=#StaticModelGroup] GetNumGeometries
-- @param self Self reference
-- @return #number

---
-- Function GetMaterial
--
-- @function [parent=#StaticModelGroup] GetMaterial
-- @param self Self reference
-- @param #number index index
-- @return Material#Material

---
-- Function GetOcclusionLodLevel
--
-- @function [parent=#StaticModelGroup] GetOcclusionLodLevel
-- @param self Self reference
-- @return #number

---
-- Function IsInside
--
-- @function [parent=#StaticModelGroup] IsInside
-- @param self Self reference
-- @param Vector3#Vector3 point point
-- @return #boolean

---
-- Function IsInsideLocal
--
-- @function [parent=#StaticModelGroup] IsInsideLocal
-- @param self Self reference
-- @param Vector3#Vector3 point point
-- @return #boolean

---
-- Field model
--
-- @field [parent=#StaticModelGroup] Model#Model model

---
-- Field material
--
-- @field [parent=#StaticModelGroup] Material#Material material

---
-- Field boundingBox (Read only)
--
-- @field [parent=#StaticModelGroup] BoundingBox#BoundingBox boundingBox

---
-- Field numGeometries (Read only)
--
-- @field [parent=#StaticModelGroup] #number numGeometries

---
-- Field occlusionLodLevel
--
-- @field [parent=#StaticModelGroup] #number occlusionLodLevel

---
-- Function SetDrawDistance
--
-- @function [parent=#StaticModelGroup] SetDrawDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetShadowDistance
--
-- @function [parent=#StaticModelGroup] SetShadowDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetLodBias
--
-- @function [parent=#StaticModelGroup] SetLodBias
-- @param self Self reference
-- @param #number bias bias

---
-- Function SetViewMask
--
-- @function [parent=#StaticModelGroup] SetViewMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetLightMask
--
-- @function [parent=#StaticModelGroup] SetLightMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetShadowMask
--
-- @function [parent=#StaticModelGroup] SetShadowMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetZoneMask
--
-- @function [parent=#StaticModelGroup] SetZoneMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetMaxLights
--
-- @function [parent=#StaticModelGroup] SetMaxLights
-- @param self Self reference
-- @param #number num num

---
-- Function SetCastShadows
--
-- @function [parent=#StaticModelGroup] SetCastShadows
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetOccluder
--
-- @function [parent=#StaticModelGroup] SetOccluder
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetOccludee
--
-- @function [parent=#StaticModelGroup] SetOccludee
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function MarkForUpdate
--
-- @function [parent=#StaticModelGroup] MarkForUpdate
-- @param self Self reference

---
-- Function GetBoundingBox
--
-- @function [parent=#StaticModelGroup] GetBoundingBox
-- @param self Self reference
-- @return const BoundingBox#const BoundingBox

---
-- Function GetWorldBoundingBox
--
-- @function [parent=#StaticModelGroup] GetWorldBoundingBox
-- @param self Self reference
-- @return const BoundingBox#const BoundingBox

---
-- Function GetDrawableFlags
--
-- @function [parent=#StaticModelGroup] GetDrawableFlags
-- @param self Self reference
-- @return #string

---
-- Function GetDrawDistance
--
-- @function [parent=#StaticModelGroup] GetDrawDistance
-- @param self Self reference
-- @return #number

---
-- Function GetShadowDistance
--
-- @function [parent=#StaticModelGroup] GetShadowDistance
-- @param self Self reference
-- @return #number

---
-- Function GetLodBias
--
-- @function [parent=#StaticModelGroup] GetLodBias
-- @param self Self reference
-- @return #number

---
-- Function GetViewMask
--
-- @function [parent=#StaticModelGroup] GetViewMask
-- @param self Self reference
-- @return #number

---
-- Function GetLightMask
--
-- @function [parent=#StaticModelGroup] GetLightMask
-- @param self Self reference
-- @return #number

---
-- Function GetShadowMask
--
-- @function [parent=#StaticModelGroup] GetShadowMask
-- @param self Self reference
-- @return #number

---
-- Function GetZoneMask
--
-- @function [parent=#StaticModelGroup] GetZoneMask
-- @param self Self reference
-- @return #number

---
-- Function GetMaxLights
--
-- @function [parent=#StaticModelGroup] GetMaxLights
-- @param self Self reference
-- @return #number

---
-- Function GetCastShadows
--
-- @function [parent=#StaticModelGroup] GetCastShadows
-- @param self Self reference
-- @return #boolean

---
-- Function IsOccluder
--
-- @function [parent=#StaticModelGroup] IsOccluder
-- @param self Self reference
-- @return #boolean

---
-- Function IsOccludee
--
-- @function [parent=#StaticModelGroup] IsOccludee
-- @param self Self reference
-- @return #boolean

---
-- Function SetZone
--
-- @function [parent=#StaticModelGroup] SetZone
-- @param self Self reference
-- @param Zone#Zone zone zone
-- @param #boolean temporary temporary

---
-- Function SetSortValue
--
-- @function [parent=#StaticModelGroup] SetSortValue
-- @param self Self reference
-- @param #number value value

---
-- Function SetMinMaxZ
--
-- @function [parent=#StaticModelGroup] SetMinMaxZ
-- @param self Self reference
-- @param #number minZ minZ
-- @param #number maxZ maxZ

---
-- Function MarkInView
--
-- @function [parent=#StaticModelGroup] MarkInView
-- @param self Self reference
-- @param FrameInfo#FrameInfo frame frame
-- @param #boolean mainView mainView

---
-- Function ClearLights
--
-- @function [parent=#StaticModelGroup] ClearLights
-- @param self Self reference

---
-- Function AddLight
--
-- @function [parent=#StaticModelGroup] AddLight
-- @param self Self reference
-- @param Light#Light light light

---
-- Function AddVertexLight
--
-- @function [parent=#StaticModelGroup] AddVertexLight
-- @param self Self reference
-- @param Light#Light light light

---
-- Function LimitLights
--
-- @function [parent=#StaticModelGroup] LimitLights
-- @param self Self reference

---
-- Function LimitVertexLights
--
-- @function [parent=#StaticModelGroup] LimitVertexLights
-- @param self Self reference

---
-- Function SetBasePass
--
-- @function [parent=#StaticModelGroup] SetBasePass
-- @param self Self reference
-- @param #number batchIndex batchIndex

---
-- Function GetOctant
--
-- @function [parent=#StaticModelGroup] GetOctant
-- @param self Self reference
-- @return Octant#Octant

---
-- Function GetZone
--
-- @function [parent=#StaticModelGroup] GetZone
-- @param self Self reference
-- @return Zone#Zone

---
-- Function GetLastZone
--
-- @function [parent=#StaticModelGroup] GetLastZone
-- @param self Self reference
-- @return Zone#Zone

---
-- Function IsZoneDirty
--
-- @function [parent=#StaticModelGroup] IsZoneDirty
-- @param self Self reference
-- @return #boolean

---
-- Function GetDistance
--
-- @function [parent=#StaticModelGroup] GetDistance
-- @param self Self reference
-- @return #number

---
-- Function GetLodDistance
--
-- @function [parent=#StaticModelGroup] GetLodDistance
-- @param self Self reference
-- @return #number

---
-- Function GetSortValue
--
-- @function [parent=#StaticModelGroup] GetSortValue
-- @param self Self reference
-- @return #number

---
-- Function IsInView
--
-- @function [parent=#StaticModelGroup] IsInView
-- @param self Self reference
-- @param #number frameNumber frameNumber
-- @return #boolean

---
-- Function IsInView
--
-- @function [parent=#StaticModelGroup] IsInView
-- @param self Self reference
-- @param FrameInfo#FrameInfo frame frame
-- @param #boolean mainView mainView
-- @return #boolean

---
-- Function HasBasePass
--
-- @function [parent=#StaticModelGroup] HasBasePass
-- @param self Self reference
-- @param #number batchIndex batchIndex
-- @return #boolean

---
-- Function GetFirstLight
--
-- @function [parent=#StaticModelGroup] GetFirstLight
-- @param self Self reference
-- @return Light#Light

---
-- Function GetMinZ
--
-- @function [parent=#StaticModelGroup] GetMinZ
-- @param self Self reference
-- @return #number

---
-- Function GetMaxZ
--
-- @function [parent=#StaticModelGroup] GetMaxZ
-- @param self Self reference
-- @return #number

---
-- Field worldBoundingBox (Read only)
--
-- @field [parent=#StaticModelGroup] BoundingBox#BoundingBox worldBoundingBox

---
-- Field drawableFlags (Read only)
--
-- @field [parent=#StaticModelGroup] #string drawableFlags

---
-- Field drawDistance
--
-- @field [parent=#StaticModelGroup] #number drawDistance

---
-- Field shadowDistance
--
-- @field [parent=#StaticModelGroup] #number shadowDistance

---
-- Field lodBias
--
-- @field [parent=#StaticModelGroup] #number lodBias

---
-- Field viewMask
--
-- @field [parent=#StaticModelGroup] #number viewMask

---
-- Field lightMask
--
-- @field [parent=#StaticModelGroup] #number lightMask

---
-- Field shadowMask
--
-- @field [parent=#StaticModelGroup] #number shadowMask

---
-- Field zoneMask
--
-- @field [parent=#StaticModelGroup] #number zoneMask

---
-- Field maxLights
--
-- @field [parent=#StaticModelGroup] #number maxLights

---
-- Field castShadows
--
-- @field [parent=#StaticModelGroup] #boolean castShadows

---
-- Field occluder
--
-- @field [parent=#StaticModelGroup] #boolean occluder

---
-- Field occludee
--
-- @field [parent=#StaticModelGroup] #boolean occludee

---
-- Field octant (Read only)
--
-- @field [parent=#StaticModelGroup] Octant#Octant octant

---
-- Field zone
--
-- @field [parent=#StaticModelGroup] Zone#Zone zone

---
-- Field lastZone (Read only)
--
-- @field [parent=#StaticModelGroup] Zone#Zone lastZone

---
-- Field zoneDirty (Read only)
--
-- @field [parent=#StaticModelGroup] #boolean zoneDirty

---
-- Field distance (Read only)
--
-- @field [parent=#StaticModelGroup] #number distance

---
-- Field lodDistance (Read only)
--
-- @field [parent=#StaticModelGroup] #number lodDistance

---
-- Field sortValue
--
-- @field [parent=#StaticModelGroup] #number sortValue

---
-- Field firstLight (Read only)
--
-- @field [parent=#StaticModelGroup] Light#Light firstLight

---
-- Field minZ (Read only)
--
-- @field [parent=#StaticModelGroup] #number minZ

---
-- Field maxZ (Read only)
--
-- @field [parent=#StaticModelGroup] #number maxZ

---
-- Function SetEnabled
--
-- @function [parent=#StaticModelGroup] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Remove
--
-- @function [parent=#StaticModelGroup] Remove
-- @param self Self reference

---
-- Function GetID
--
-- @function [parent=#StaticModelGroup] GetID
-- @param self Self reference
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#StaticModelGroup] GetNode
-- @param self Self reference
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#StaticModelGroup] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#StaticModelGroup] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#StaticModelGroup] IsEnabledEffective
-- @param self Self reference
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#StaticModelGroup] GetComponent
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#StaticModelGroup] GetComponent
-- @param self Self reference
-- @param #string type type
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#StaticModelGroup] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#StaticModelGroup] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#StaticModelGroup] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#StaticModelGroup] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#StaticModelGroup] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#StaticModelGroup] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#StaticModelGroup] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#StaticModelGroup] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#StaticModelGroup] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#StaticModelGroup] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#StaticModelGroup] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#StaticModelGroup] #string category


return nil
