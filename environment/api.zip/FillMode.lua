---
-- Enumeration FillMode
--
-- @module FillMode

---
-- Enumeration value FILL_SOLID
--
-- @field [parent=#FillMode] #number FILL_SOLID

---
-- Enumeration value FILL_WIREFRAME
--
-- @field [parent=#FillMode] #number FILL_WIREFRAME

---
-- Enumeration value FILL_POINT
--
-- @field [parent=#FillMode] #number FILL_POINT


return nil
