---
-- Module Animation
-- Extends Resource
--
-- @module Animation

---
-- Function GetAnimationName
--
-- @function [parent=#Animation] GetAnimationName
-- @return const String#const String

---
-- Function GetAnimationNameHash
--
-- @function [parent=#Animation] GetAnimationNameHash
-- @return StringHash#StringHash

---
-- Function GetLength
--
-- @function [parent=#Animation] GetLength
-- @return #number

---
-- Function GetNumTracks
--
-- @function [parent=#Animation] GetNumTracks
-- @return #number

---
-- Function GetTrack
--
-- @function [parent=#Animation] GetTrack
-- @param #string namename
-- @return const AnimationTrack#const AnimationTrack

---
-- Function GetTrack
--
-- @function [parent=#Animation] GetTrack
-- @param StringHash#StringHash nameHashnameHash
-- @return const AnimationTrack#const AnimationTrack

---
-- Function GetTrack
--
-- @function [parent=#Animation] GetTrack
-- @param #number indexindex
-- @return const AnimationTrack#const AnimationTrack

---
-- Function GetNumTriggers
--
-- @function [parent=#Animation] GetNumTriggers
-- @return #number

---
-- Field animationName (Read only)
--
-- @field [parent=#Animation] #string animationName

---
-- Field animationNameHash (Read only)
--
-- @field [parent=#Animation] StringHash#StringHash animationNameHash

---
-- Field length (Read only)
--
-- @field [parent=#Animation] #number length

---
-- Field numTracks (Read only)
--
-- @field [parent=#Animation] #number numTracks

---
-- Field numTriggers (Read only)
--
-- @field [parent=#Animation] #number numTriggers


return nil
