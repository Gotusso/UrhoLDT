---
-- Module Animation
-- Module Animation extends Resource
-- Generated on 2014-03-13
--
-- @module Animation

---
-- Function GetAnimationName
--
-- @function [parent=#Animation] GetAnimationName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetAnimationNameHash
--
-- @function [parent=#Animation] GetAnimationNameHash
-- @param self Self reference
-- @return StringHash#StringHash

---
-- Function GetLength
--
-- @function [parent=#Animation] GetLength
-- @param self Self reference
-- @return #number

---
-- Function GetNumTracks
--
-- @function [parent=#Animation] GetNumTracks
-- @param self Self reference
-- @return #number

---
-- Function GetTrack
--
-- @function [parent=#Animation] GetTrack
-- @param self Self reference
-- @param #string name name
-- @return const AnimationTrack#const AnimationTrack

---
-- Function GetTrack
--
-- @function [parent=#Animation] GetTrack
-- @param self Self reference
-- @param StringHash#StringHash nameHash nameHash
-- @return const AnimationTrack#const AnimationTrack

---
-- Function GetTrack
--
-- @function [parent=#Animation] GetTrack
-- @param self Self reference
-- @param #number index index
-- @return const AnimationTrack#const AnimationTrack

---
-- Function GetNumTriggers
--
-- @function [parent=#Animation] GetNumTriggers
-- @param self Self reference
-- @return #number

---
-- Field animationName (Read only)
--
-- @field [parent=#Animation] #string animationName

---
-- Field animationNameHash (Read only)
--
-- @field [parent=#Animation] StringHash#StringHash animationNameHash

---
-- Field length (Read only)
--
-- @field [parent=#Animation] #number length

---
-- Field numTracks (Read only)
--
-- @field [parent=#Animation] #number numTracks

---
-- Field numTriggers (Read only)
--
-- @field [parent=#Animation] #number numTriggers

---
-- Function Load
--
-- @function [parent=#Animation] Load
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#Animation] Save
-- @param self Self reference
-- @param Serializer#Serializer dest dest
-- @return #boolean

---
-- Function Load
--
-- @function [parent=#Animation] Load
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function Save
--
-- @function [parent=#Animation] Save
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function GetName
--
-- @function [parent=#Animation] GetName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetNameHash
--
-- @function [parent=#Animation] GetNameHash
-- @param self Self reference
-- @return StringHash#StringHash

---
-- Function GetMemoryUse
--
-- @function [parent=#Animation] GetMemoryUse
-- @param self Self reference
-- @return #number

---
-- Field name (Read only)
--
-- @field [parent=#Animation] #string name

---
-- Field nameHash (Read only)
--
-- @field [parent=#Animation] StringHash#StringHash nameHash

---
-- Field memoryUse (Read only)
--
-- @field [parent=#Animation] #number memoryUse


return nil
