---
-- Module Animation
-- Module Animation extends Resource
-- Generated on 2014-05-31
--
-- @module Animation

---
-- Function GetAnimationName()
-- Return animation name.
--
-- @function [parent=#Animation] GetAnimationName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetAnimationNameHash()
-- Return animation name hash.
--
-- @function [parent=#Animation] GetAnimationNameHash
-- @param self Self reference
-- @return StringHash#StringHash

---
-- Function GetLength()
-- Return animation length.
--
-- @function [parent=#Animation] GetLength
-- @param self Self reference
-- @return #number

---
-- Function GetNumTracks()
-- Return number of animation tracks.
--
-- @function [parent=#Animation] GetNumTracks
-- @param self Self reference
-- @return #number

---
-- Function GetTrack()
-- Return animation track by bone name.
--
-- @function [parent=#Animation] GetTrack
-- @param self Self reference
-- @param #string name name
-- @return const AnimationTrack#const AnimationTrack

---
-- Function GetTrack()
-- Return animation track by bone name hash.
--
-- @function [parent=#Animation] GetTrack
-- @param self Self reference
-- @param StringHash#StringHash nameHash nameHash
-- @return const AnimationTrack#const AnimationTrack

---
-- Function GetTrack()
-- Return animation track by index.
--
-- @function [parent=#Animation] GetTrack
-- @param self Self reference
-- @param #number index index
-- @return const AnimationTrack#const AnimationTrack

---
-- Function GetNumTriggers()
-- Return number of animation trigger points.
--
-- @function [parent=#Animation] GetNumTriggers
-- @param self Self reference
-- @return #number

---
-- Field animationName (Read only)
--
-- @field [parent=#Animation] #string animationName

---
-- Field animationNameHash (Read only)
--
-- @field [parent=#Animation] StringHash#StringHash animationNameHash

---
-- Field length (Read only)
--
-- @field [parent=#Animation] #number length

---
-- Field numTracks (Read only)
--
-- @field [parent=#Animation] #number numTracks

---
-- Field numTriggers (Read only)
--
-- @field [parent=#Animation] #number numTriggers


return nil
