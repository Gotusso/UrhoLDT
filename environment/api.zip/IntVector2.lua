---
-- Module IntVector2
--
-- @module IntVector2

---
-- Function IntVector2
--
-- @function [parent=#IntVector2] IntVector2

---
-- Function new
--
-- @function [parent=#IntVector2] new
-- @return IntVector2#IntVector2

---
-- Function IntVector2
--
-- @function [parent=#IntVector2] IntVector2
-- @param #number xx
-- @param #number yy

---
-- Function new
--
-- @function [parent=#IntVector2] new
-- @param #number xx
-- @param #number yy
-- @return IntVector2#IntVector2

---
-- Function IntVector2
--
-- @function [parent=#IntVector2] IntVector2
-- @param IntVector2#IntVector2 rhsrhs

---
-- Function new
--
-- @function [parent=#IntVector2] new
-- @param IntVector2#IntVector2 rhsrhs
-- @return IntVector2#IntVector2

---
-- Function delete
--
-- @function [parent=#IntVector2] delete

---
-- Function operator==
--
-- @function [parent=#IntVector2] operator==
-- @param IntVector2#IntVector2 rhsrhs
-- @return #boolean

---
-- Function operator+
--
-- @function [parent=#IntVector2] operator+
-- @param IntVector2#IntVector2 rhsrhs
-- @return IntVector2#IntVector2

---
-- Function operator-
--
-- @function [parent=#IntVector2] operator-
-- @return IntVector2#IntVector2

---
-- Function operator-
--
-- @function [parent=#IntVector2] operator-
-- @param IntVector2#IntVector2 rhsrhs
-- @return IntVector2#IntVector2

---
-- Function operator*
--
-- @function [parent=#IntVector2] operator*
-- @param #number rhsrhs
-- @return IntVector2#IntVector2

---
-- Function operator/
--
-- @function [parent=#IntVector2] operator/
-- @param #number rhsrhs
-- @return IntVector2#IntVector2

---
-- Function operator/
--
-- @function [parent=#IntVector2] operator/
-- @param #number rhsrhs
-- @return IntVector2#IntVector2

---
-- Function ToString
--
-- @function [parent=#IntVector2] ToString
-- @return #string

---
-- Field x
--
-- @field [parent=#IntVector2] #number x

---
-- Field y
--
-- @field [parent=#IntVector2] #number y

---
-- Field ZERO
--
-- @field [parent=#IntVector2] IntVector2#IntVector2 ZERO


return nil
