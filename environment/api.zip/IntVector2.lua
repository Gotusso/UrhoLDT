---
-- Module IntVector2
-- Generated on 2014-05-31
--
-- @module IntVector2

---
-- Function IntVector2()
-- Construct a zero vector.
--
-- @function [parent=#IntVector2] IntVector2
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#IntVector2] new
-- @param self Self reference
-- @return IntVector2#IntVector2

---
-- Function IntVector2()
--
-- @function [parent=#IntVector2] IntVector2
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function new()
--
-- @function [parent=#IntVector2] new
-- @param self Self reference
-- @param #number x x
-- @param #number y y
-- @return IntVector2#IntVector2

---
-- Function IntVector2()
--
-- @function [parent=#IntVector2] IntVector2
-- @param self Self reference
-- @param IntVector2#IntVector2 rhs rhs

---
-- Function new()
--
-- @function [parent=#IntVector2] new
-- @param self Self reference
-- @param IntVector2#IntVector2 rhs rhs
-- @return IntVector2#IntVector2

---
-- Function delete()
--
-- @function [parent=#IntVector2] delete
-- @param self Self reference

---
-- Function operator==()
--
-- @function [parent=#IntVector2] operator==
-- @param self Self reference
-- @param IntVector2#IntVector2 rhs rhs
-- @return #boolean

---
-- Function operator+()
--
-- @function [parent=#IntVector2] operator+
-- @param self Self reference
-- @param IntVector2#IntVector2 rhs rhs
-- @return IntVector2#IntVector2

---
-- Function operator-()
--
-- @function [parent=#IntVector2] operator-
-- @param self Self reference
-- @return IntVector2#IntVector2

---
-- Function operator-()
--
-- @function [parent=#IntVector2] operator-
-- @param self Self reference
-- @param IntVector2#IntVector2 rhs rhs
-- @return IntVector2#IntVector2

---
-- Function operator*()
--
-- @function [parent=#IntVector2] operator*
-- @param self Self reference
-- @param #number rhs rhs
-- @return IntVector2#IntVector2

---
-- Function operator/()
--
-- @function [parent=#IntVector2] operator/
-- @param self Self reference
-- @param #number rhs rhs
-- @return IntVector2#IntVector2

---
-- Function operator/()
--
-- @function [parent=#IntVector2] operator/
-- @param self Self reference
-- @param #number rhs rhs
-- @return IntVector2#IntVector2

---
-- Function ToString()
--
-- @function [parent=#IntVector2] ToString
-- @param self Self reference
-- @return #string

---
-- Field x
--
-- @field [parent=#IntVector2] #number x

---
-- Field y
--
-- @field [parent=#IntVector2] #number y

---
-- Field ZERO
--
-- @field [parent=#IntVector2] IntVector2#IntVector2 ZERO


return nil
