---
-- Module SpriteSheet2D
-- Module SpriteSheet2D extends Resource
-- Generated on 2014-05-31
--
-- @module SpriteSheet2D

---
-- Function GetTexture()
-- Return texture.
--
-- @function [parent=#SpriteSheet2D] GetTexture
-- @param self Self reference
-- @return Texture2D#Texture2D

---
-- Function GetSprite()
-- Return sprite.
--
-- @function [parent=#SpriteSheet2D] GetSprite
-- @param self Self reference
-- @param #string name name
-- @return Sprite2D#Sprite2D

---
-- Function DefineSprite()
--
-- @function [parent=#SpriteSheet2D] DefineSprite
-- @param self Self reference
-- @param #string name name
-- @param IntRect#IntRect rectangle rectangle

---
-- Function DefineSprite()
--
-- @function [parent=#SpriteSheet2D] DefineSprite
-- @param self Self reference
-- @param #string name name
-- @param IntRect#IntRect rectangle rectangle
-- @param Vector2#Vector2 hotSpot hotSpot

---
-- Function UpdateSprite()
--
-- @function [parent=#SpriteSheet2D] UpdateSprite
-- @param self Self reference
-- @param #string name name
-- @param IntRect#IntRect rectangle rectangle

---
-- Function UpdateSprite()
--
-- @function [parent=#SpriteSheet2D] UpdateSprite
-- @param self Self reference
-- @param #string name name
-- @param IntRect#IntRect rectangle rectangle
-- @param Vector2#Vector2 hotSpot hotSpot


return nil
