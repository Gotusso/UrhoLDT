---
-- Module Window
-- extends BorderImage
--
-- @module Window

---
-- Function Window
--
-- @function [parent=#Window] Window

---
-- Function new
--
-- @function [parent=#Window] new
-- @return Window#Window

---
-- Function delete
--
-- @function [parent=#Window] delete

---
-- Function SetMovable
--
-- @function [parent=#Window] SetMovable
-- @param #boolean enableenable

---
-- Function SetResizable
--
-- @function [parent=#Window] SetResizable
-- @param #boolean enableenable

---
-- Function SetFixedWidthResizing
--
-- @function [parent=#Window] SetFixedWidthResizing
-- @param #boolean enableenable

---
-- Function SetFixedHeightResizing
--
-- @function [parent=#Window] SetFixedHeightResizing
-- @param #boolean enableenable

---
-- Function SetResizeBorder
--
-- @function [parent=#Window] SetResizeBorder
-- @param IntRect#IntRect rectrect

---
-- Function SetModal
--
-- @function [parent=#Window] SetModal
-- @param #boolean modalmodal

---
-- Function SetModalShadeColor
--
-- @function [parent=#Window] SetModalShadeColor
-- @param Color#Color colorcolor

---
-- Function SetModalFrameColor
--
-- @function [parent=#Window] SetModalFrameColor
-- @param Color#Color colorcolor

---
-- Function SetModalFrameSize
--
-- @function [parent=#Window] SetModalFrameSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function IsMovable
--
-- @function [parent=#Window] IsMovable
-- @return #boolean

---
-- Function IsResizable
--
-- @function [parent=#Window] IsResizable
-- @return #boolean

---
-- Function GetFixedWidthResizing
--
-- @function [parent=#Window] GetFixedWidthResizing
-- @return #boolean

---
-- Function GetFixedHeightResizing
--
-- @function [parent=#Window] GetFixedHeightResizing
-- @return #boolean

---
-- Function GetResizeBorder
--
-- @function [parent=#Window] GetResizeBorder
-- @return const IntRect#const IntRect

---
-- Function IsModal
--
-- @function [parent=#Window] IsModal
-- @return #boolean

---
-- Function GetModalShadeColor
--
-- @function [parent=#Window] GetModalShadeColor
-- @return const Color#const Color

---
-- Function GetModalFrameColor
--
-- @function [parent=#Window] GetModalFrameColor
-- @return const Color#const Color

---
-- Function GetModalFrameSize
--
-- @function [parent=#Window] GetModalFrameSize
-- @return const IntVector2#const IntVector2

---
-- Field movable
--
-- @field [parent=#Window] #boolean movable

---
-- Field resizable
--
-- @field [parent=#Window] #boolean resizable

---
-- Field fixedWidthResizing
--
-- @field [parent=#Window] #boolean fixedWidthResizing

---
-- Field fixedHeightResizing
--
-- @field [parent=#Window] #boolean fixedHeightResizing

---
-- Field resizeBorder
--
-- @field [parent=#Window] IntRect#IntRect resizeBorder

---
-- Field modal
--
-- @field [parent=#Window] #boolean modal

---
-- Field modalShadeColor
--
-- @field [parent=#Window] Color#Color modalShadeColor

---
-- Field modalFrameColor
--
-- @field [parent=#Window] Color#Color modalFrameColor

---
-- Field modalFrameSize
--
-- @field [parent=#Window] IntVector2#IntVector2 modalFrameSize

---
-- Function BorderImage
--
-- @function [parent=#Window] BorderImage

---
-- Function new
--
-- @function [parent=#Window] new
-- @return BorderImage#BorderImage

---
-- Function delete
--
-- @function [parent=#Window] delete

---
-- Function SetTexture
--
-- @function [parent=#Window] SetTexture
-- @param Texture#Texture texturetexture

---
-- Function SetImageRect
--
-- @function [parent=#Window] SetImageRect
-- @param IntRect#IntRect rectrect

---
-- Function SetFullImageRect
--
-- @function [parent=#Window] SetFullImageRect

---
-- Function SetBorder
--
-- @function [parent=#Window] SetBorder
-- @param IntRect#IntRect rectrect

---
-- Function SetHoverOffset
--
-- @function [parent=#Window] SetHoverOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetHoverOffset
--
-- @function [parent=#Window] SetHoverOffset
-- @param #number xx
-- @param #number yy

---
-- Function SetBlendMode
--
-- @function [parent=#Window] SetBlendMode
-- @param BlendMode#BlendMode modemode

---
-- Function SetTiled
--
-- @function [parent=#Window] SetTiled
-- @param #boolean enableenable

---
-- Function GetTexture
--
-- @function [parent=#Window] GetTexture
-- @return Texture#Texture

---
-- Function GetImageRect
--
-- @function [parent=#Window] GetImageRect
-- @return const IntRect#const IntRect

---
-- Function GetBorder
--
-- @function [parent=#Window] GetBorder
-- @return const IntRect#const IntRect

---
-- Function GetHoverOffset
--
-- @function [parent=#Window] GetHoverOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetBlendMode
--
-- @function [parent=#Window] GetBlendMode
-- @return BlendMode#BlendMode

---
-- Function IsTiled
--
-- @function [parent=#Window] IsTiled
-- @return #boolean

---
-- Field texture
--
-- @field [parent=#Window] Texture#Texture texture

---
-- Field imageRect
--
-- @field [parent=#Window] IntRect#IntRect imageRect

---
-- Field border
--
-- @field [parent=#Window] IntRect#IntRect border

---
-- Field hoverOffset
--
-- @field [parent=#Window] IntVector2#IntVector2 hoverOffset

---
-- Field blendMode
--
-- @field [parent=#Window] BlendMode#BlendMode blendMode

---
-- Field tiled
--
-- @field [parent=#Window] #boolean tiled

---
-- Function UIElement
--
-- @function [parent=#Window] UIElement

---
-- Function new
--
-- @function [parent=#Window] new
-- @return UIElement#UIElement

---
-- Function delete
--
-- @function [parent=#Window] delete

---
-- Function GetScreenPosition
--
-- @function [parent=#Window] GetScreenPosition
-- @return const IntVector2#const IntVector2

---
-- Function LoadXML
--
-- @function [parent=#Window] LoadXML
-- @param Deserializer#Deserializer sourcesource
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#Window] SaveXML
-- @param Serializer#Serializer destdest
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#Window] LoadXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#Window] SaveXML
-- @param #string fileNamefileName
-- @return #boolean

---
-- Function FilterAttributes
--
-- @function [parent=#Window] FilterAttributes
-- @param XMLElement#XMLElement destdest
-- @return #boolean

---
-- Function SetName
--
-- @function [parent=#Window] SetName
-- @param #string namename

---
-- Function SetPosition
--
-- @function [parent=#Window] SetPosition
-- @param IntVector2#IntVector2 positionposition

---
-- Function SetPosition
--
-- @function [parent=#Window] SetPosition
-- @param #number xx
-- @param #number yy

---
-- Function SetSize
--
-- @function [parent=#Window] SetSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function SetSize
--
-- @function [parent=#Window] SetSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetWidth
--
-- @function [parent=#Window] SetWidth
-- @param #number widthwidth

---
-- Function SetHeight
--
-- @function [parent=#Window] SetHeight
-- @param #number heightheight

---
-- Function SetMinSize
--
-- @function [parent=#Window] SetMinSize
-- @param IntVector2#IntVector2 minSizeminSize

---
-- Function SetMinSize
--
-- @function [parent=#Window] SetMinSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetMinWidth
--
-- @function [parent=#Window] SetMinWidth
-- @param #number widthwidth

---
-- Function SetMinHeight
--
-- @function [parent=#Window] SetMinHeight
-- @param #number heightheight

---
-- Function SetMaxSize
--
-- @function [parent=#Window] SetMaxSize
-- @param IntVector2#IntVector2 maxSizemaxSize

---
-- Function SetMaxSize
--
-- @function [parent=#Window] SetMaxSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetMaxWidth
--
-- @function [parent=#Window] SetMaxWidth
-- @param #number widthwidth

---
-- Function SetMaxHeight
--
-- @function [parent=#Window] SetMaxHeight
-- @param #number heightheight

---
-- Function SetFixedSize
--
-- @function [parent=#Window] SetFixedSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function SetFixedSize
--
-- @function [parent=#Window] SetFixedSize
-- @param #number widthwidth
-- @param #number heightheight

---
-- Function SetFixedWidth
--
-- @function [parent=#Window] SetFixedWidth
-- @param #number widthwidth

---
-- Function SetFixedHeight
--
-- @function [parent=#Window] SetFixedHeight
-- @param #number heightheight

---
-- Function SetAlignment
--
-- @function [parent=#Window] SetAlignment
-- @param HorizontalAlignment#HorizontalAlignment hAlignhAlign
-- @param VerticalAlignment#VerticalAlignment vAlignvAlign

---
-- Function SetHorizontalAlignment
--
-- @function [parent=#Window] SetHorizontalAlignment
-- @param HorizontalAlignment#HorizontalAlignment alignalign

---
-- Function SetVerticalAlignment
--
-- @function [parent=#Window] SetVerticalAlignment
-- @param VerticalAlignment#VerticalAlignment alignalign

---
-- Function SetClipBorder
--
-- @function [parent=#Window] SetClipBorder
-- @param IntRect#IntRect rectrect

---
-- Function SetColor
--
-- @function [parent=#Window] SetColor
-- @param Color#Color colorcolor

---
-- Function SetColor
--
-- @function [parent=#Window] SetColor
-- @param Corner#Corner cornercorner
-- @param Color#Color colorcolor

---
-- Function SetPriority
--
-- @function [parent=#Window] SetPriority
-- @param #number prioritypriority

---
-- Function SetOpacity
--
-- @function [parent=#Window] SetOpacity
-- @param #number opacityopacity

---
-- Function SetBringToFront
--
-- @function [parent=#Window] SetBringToFront
-- @param #boolean enableenable

---
-- Function SetBringToBack
--
-- @function [parent=#Window] SetBringToBack
-- @param #boolean enableenable

---
-- Function SetClipChildren
--
-- @function [parent=#Window] SetClipChildren
-- @param #boolean enableenable

---
-- Function SetSortChildren
--
-- @function [parent=#Window] SetSortChildren
-- @param #boolean enableenable

---
-- Function SetUseDerivedOpacity
--
-- @function [parent=#Window] SetUseDerivedOpacity
-- @param #boolean enableenable

---
-- Function SetEnabled
--
-- @function [parent=#Window] SetEnabled
-- @param #boolean enableenable

---
-- Function SetEditable
--
-- @function [parent=#Window] SetEditable
-- @param #boolean enableenable

---
-- Function SetFocus
--
-- @function [parent=#Window] SetFocus
-- @param #boolean enableenable

---
-- Function SetSelected
--
-- @function [parent=#Window] SetSelected
-- @param #boolean enableenable

---
-- Function SetVisible
--
-- @function [parent=#Window] SetVisible
-- @param #boolean enableenable

---
-- Function SetFocusMode
--
-- @function [parent=#Window] SetFocusMode
-- @param FocusMode#FocusMode modemode

---
-- Function SetDragDropMode
--
-- @function [parent=#Window] SetDragDropMode
-- @param #number modemode

---
-- Function SetStyle
--
-- @function [parent=#Window] SetStyle
-- @param #string styleNamestyleName
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetStyle
--
-- @function [parent=#Window] SetStyle
-- @param XMLElement#XMLElement elementelement
-- @return #boolean

---
-- Function SetStyleAuto
--
-- @function [parent=#Window] SetStyleAuto
-- @param XMLFile#XMLFile filefile
-- @return #boolean

---
-- Function SetDefaultStyle
--
-- @function [parent=#Window] SetDefaultStyle
-- @param XMLFile#XMLFile stylestyle

---
-- Function SetLayout
--
-- @function [parent=#Window] SetLayout
-- @param LayoutMode#LayoutMode modemode
-- @param #number spacingspacing

---
-- Function SetLayout
--
-- @function [parent=#Window] SetLayout
-- @param LayoutMode#LayoutMode modemode
-- @param #number spacingspacing
-- @param IntRect#IntRect borderborder

---
-- Function SetLayoutMode
--
-- @function [parent=#Window] SetLayoutMode
-- @param LayoutMode#LayoutMode modemode

---
-- Function SetLayoutSpacing
--
-- @function [parent=#Window] SetLayoutSpacing
-- @param #number spacingspacing

---
-- Function SetLayoutBorder
--
-- @function [parent=#Window] SetLayoutBorder
-- @param IntRect#IntRect borderborder

---
-- Function SetIndent
--
-- @function [parent=#Window] SetIndent
-- @param #number indentindent

---
-- Function SetIndentSpacing
--
-- @function [parent=#Window] SetIndentSpacing
-- @param #number indentSpacingindentSpacing

---
-- Function UpdateLayout
--
-- @function [parent=#Window] UpdateLayout

---
-- Function DisableLayoutUpdate
--
-- @function [parent=#Window] DisableLayoutUpdate

---
-- Function EnableLayoutUpdate
--
-- @function [parent=#Window] EnableLayoutUpdate

---
-- Function BringToFront
--
-- @function [parent=#Window] BringToFront

---
-- Function CreateChild
--
-- @function [parent=#Window] CreateChild
-- @param #string typetype
-- @param #string namename
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function AddChild
--
-- @function [parent=#Window] AddChild
-- @param UIElement#UIElement elementelement

---
-- Function InsertChild
--
-- @function [parent=#Window] InsertChild
-- @param #number indexindex
-- @param UIElement#UIElement elementelement

---
-- Function RemoveChild
--
-- @function [parent=#Window] RemoveChild
-- @param UIElement#UIElement elementelement
-- @param #number indexindex

---
-- Function RemoveChildAtIndex
--
-- @function [parent=#Window] RemoveChildAtIndex
-- @param #number indexindex

---
-- Function RemoveAllChildren
--
-- @function [parent=#Window] RemoveAllChildren

---
-- Function Remove
--
-- @function [parent=#Window] Remove

---
-- Function FindChild
--
-- @function [parent=#Window] FindChild
-- @param UIElement#UIElement elementelement
-- @return #number

---
-- Function SetParent
--
-- @function [parent=#Window] SetParent
-- @param UIElement#UIElement parentparent
-- @param #number indexindex

---
-- Function SetVar
--
-- @function [parent=#Window] SetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @param Variant#Variant valuevalue

---
-- Function SetInternal
--
-- @function [parent=#Window] SetInternal
-- @param #boolean enableenable

---
-- Function SetTraversalMode
--
-- @function [parent=#Window] SetTraversalMode
-- @param TraversalMode#TraversalMode traversalModetraversalMode

---
-- Function SetElementEventSender
--
-- @function [parent=#Window] SetElementEventSender
-- @param #boolean flagflag

---
-- Function GetName
--
-- @function [parent=#Window] GetName
-- @return const String#const String

---
-- Function GetPosition
--
-- @function [parent=#Window] GetPosition
-- @return const IntVector2#const IntVector2

---
-- Function GetSize
--
-- @function [parent=#Window] GetSize
-- @return const IntVector2#const IntVector2

---
-- Function GetWidth
--
-- @function [parent=#Window] GetWidth
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#Window] GetHeight
-- @return #number

---
-- Function GetMinSize
--
-- @function [parent=#Window] GetMinSize
-- @return const IntVector2#const IntVector2

---
-- Function GetMinWidth
--
-- @function [parent=#Window] GetMinWidth
-- @return #number

---
-- Function GetMinHeight
--
-- @function [parent=#Window] GetMinHeight
-- @return #number

---
-- Function GetMaxSize
--
-- @function [parent=#Window] GetMaxSize
-- @return const IntVector2#const IntVector2

---
-- Function GetMaxWidth
--
-- @function [parent=#Window] GetMaxWidth
-- @return #number

---
-- Function GetMaxHeight
--
-- @function [parent=#Window] GetMaxHeight
-- @return #number

---
-- Function IsFixedSize
--
-- @function [parent=#Window] IsFixedSize
-- @return #boolean

---
-- Function IsFixedWidth
--
-- @function [parent=#Window] IsFixedWidth
-- @return #boolean

---
-- Function IsFixedHeight
--
-- @function [parent=#Window] IsFixedHeight
-- @return #boolean

---
-- Function GetChildOffset
--
-- @function [parent=#Window] GetChildOffset
-- @return const IntVector2#const IntVector2

---
-- Function GetHorizontalAlignment
--
-- @function [parent=#Window] GetHorizontalAlignment
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetVerticalAlignment
--
-- @function [parent=#Window] GetVerticalAlignment
-- @return VerticalAlignment#VerticalAlignment

---
-- Function GetClipBorder
--
-- @function [parent=#Window] GetClipBorder
-- @return const IntRect#const IntRect

---
-- Function GetColor
--
-- @function [parent=#Window] GetColor
-- @param Corner#Corner cornercorner
-- @return const Color#const Color

---
-- Function GetPriority
--
-- @function [parent=#Window] GetPriority
-- @return #number

---
-- Function GetOpacity
--
-- @function [parent=#Window] GetOpacity
-- @return #number

---
-- Function GetDerivedOpacity
--
-- @function [parent=#Window] GetDerivedOpacity
-- @return #number

---
-- Function GetBringToFront
--
-- @function [parent=#Window] GetBringToFront
-- @return #boolean

---
-- Function GetBringToBack
--
-- @function [parent=#Window] GetBringToBack
-- @return #boolean

---
-- Function GetClipChildren
--
-- @function [parent=#Window] GetClipChildren
-- @return #boolean

---
-- Function GetSortChildren
--
-- @function [parent=#Window] GetSortChildren
-- @return #boolean

---
-- Function GetUseDerivedOpacity
--
-- @function [parent=#Window] GetUseDerivedOpacity
-- @return #boolean

---
-- Function HasFocus
--
-- @function [parent=#Window] HasFocus
-- @return #boolean

---
-- Function IsEnabled
--
-- @function [parent=#Window] IsEnabled
-- @return #boolean

---
-- Function IsEditable
--
-- @function [parent=#Window] IsEditable
-- @return #boolean

---
-- Function IsSelected
--
-- @function [parent=#Window] IsSelected
-- @return #boolean

---
-- Function IsVisible
--
-- @function [parent=#Window] IsVisible
-- @return #boolean

---
-- Function IsHovering
--
-- @function [parent=#Window] IsHovering
-- @return #boolean

---
-- Function IsInternal
--
-- @function [parent=#Window] IsInternal
-- @return #boolean

---
-- Function HasColorGradient
--
-- @function [parent=#Window] HasColorGradient
-- @return #boolean

---
-- Function GetFocusMode
--
-- @function [parent=#Window] GetFocusMode
-- @return FocusMode#FocusMode

---
-- Function GetDragDropMode
--
-- @function [parent=#Window] GetDragDropMode
-- @return #number

---
-- Function GetAppliedStyle
--
-- @function [parent=#Window] GetAppliedStyle
-- @return const String#const String

---
-- Function GetDefaultStyle
--
-- @function [parent=#Window] GetDefaultStyle
-- @param #boolean recursiveUprecursiveUp
-- @return XMLFile#XMLFile

---
-- Function GetLayoutMode
--
-- @function [parent=#Window] GetLayoutMode
-- @return LayoutMode#LayoutMode

---
-- Function GetLayoutSpacing
--
-- @function [parent=#Window] GetLayoutSpacing
-- @return #number

---
-- Function GetLayoutBorder
--
-- @function [parent=#Window] GetLayoutBorder
-- @return const IntRect#const IntRect

---
-- Function GetNumChildren
--
-- @function [parent=#Window] GetNumChildren
-- @param #boolean recursiverecursive
-- @return #number

---
-- Function GetChild
--
-- @function [parent=#Window] GetChild
-- @param #string namename
-- @param #boolean recursiverecursive
-- @return UIElement#UIElement

---
-- Function GetChild
--
-- @function [parent=#Window] GetChild
-- @param #number indexindex
-- @return UIElement#UIElement

---
-- Function GetParent
--
-- @function [parent=#Window] GetParent
-- @return UIElement#UIElement

---
-- Function GetRoot
--
-- @function [parent=#Window] GetRoot
-- @return UIElement#UIElement

---
-- Function GetDerivedColor
--
-- @function [parent=#Window] GetDerivedColor
-- @return const Color#const Color

---
-- Function GetVar
--
-- @function [parent=#Window] GetVar
-- @param ShortStringHash#ShortStringHash keykey
-- @return const Variant#const Variant

---
-- Function GetVars
--
-- @function [parent=#Window] GetVars
-- @return const VariantMap#const VariantMap

---
-- Function ScreenToElement
--
-- @function [parent=#Window] ScreenToElement
-- @param IntVector2#IntVector2 screenPositionscreenPosition
-- @return IntVector2#IntVector2

---
-- Function ElementToScreen
--
-- @function [parent=#Window] ElementToScreen
-- @param IntVector2#IntVector2 positionposition
-- @return IntVector2#IntVector2

---
-- Function IsInside
--
-- @function [parent=#Window] IsInside
-- @param IntVector2#IntVector2 positionposition
-- @param #boolean isScreenisScreen
-- @return #boolean

---
-- Function IsInsideCombined
--
-- @function [parent=#Window] IsInsideCombined
-- @param IntVector2#IntVector2 positionposition
-- @param #boolean isScreenisScreen
-- @return #boolean

---
-- Function GetCombinedScreenRect
--
-- @function [parent=#Window] GetCombinedScreenRect
-- @return IntRect#IntRect

---
-- Function SortChildren
--
-- @function [parent=#Window] SortChildren

---
-- Function GetLayoutMinSize
--
-- @function [parent=#Window] GetLayoutMinSize
-- @return #number

---
-- Function GetIndent
--
-- @function [parent=#Window] GetIndent
-- @return #number

---
-- Function GetIndentSpacing
--
-- @function [parent=#Window] GetIndentSpacing
-- @return #number

---
-- Function GetIndentWidth
--
-- @function [parent=#Window] GetIndentWidth
-- @return #number

---
-- Function SetChildOffset
--
-- @function [parent=#Window] SetChildOffset
-- @param IntVector2#IntVector2 offsetoffset

---
-- Function SetHovering
--
-- @function [parent=#Window] SetHovering
-- @param #boolean enableenable

---
-- Function GetColor
--
-- @function [parent=#Window] GetColor
-- @return const Color#const Color

---
-- Function GetTraversalMode
--
-- @function [parent=#Window] GetTraversalMode
-- @return TraversalMode#TraversalMode

---
-- Function IsElementEventSender
--
-- @function [parent=#Window] IsElementEventSender
-- @return #boolean

---
-- Function GetElementEventSender
--
-- @function [parent=#Window] GetElementEventSender
-- @return UIElement#UIElement

---
-- Field screenPosition (Read only)
--
-- @field [parent=#Window] IntVector2#IntVector2 screenPosition

---
-- Field name
--
-- @field [parent=#Window] #string name

---
-- Field position
--
-- @field [parent=#Window] IntVector2#IntVector2 position

---
-- Field size
--
-- @field [parent=#Window] IntVector2#IntVector2 size

---
-- Field width
--
-- @field [parent=#Window] #number width

---
-- Field height
--
-- @field [parent=#Window] #number height

---
-- Field minSize
--
-- @field [parent=#Window] IntVector2#IntVector2 minSize

---
-- Field minWidth
--
-- @field [parent=#Window] #number minWidth

---
-- Field minHeight
--
-- @field [parent=#Window] #number minHeight

---
-- Field maxSize
--
-- @field [parent=#Window] IntVector2#IntVector2 maxSize

---
-- Field maxWidth
--
-- @field [parent=#Window] #number maxWidth

---
-- Field maxHeight
--
-- @field [parent=#Window] #number maxHeight

---
-- Field fixedSize (Read only)
--
-- @field [parent=#Window] #boolean fixedSize

---
-- Field fixedWidth (Read only)
--
-- @field [parent=#Window] #boolean fixedWidth

---
-- Field fixedHeight (Read only)
--
-- @field [parent=#Window] #boolean fixedHeight

---
-- Field childOffset
--
-- @field [parent=#Window] IntVector2#IntVector2 childOffset

---
-- Field horizontalAlignment
--
-- @field [parent=#Window] HorizontalAlignment#HorizontalAlignment horizontalAlignment

---
-- Field verticalAlignment
--
-- @field [parent=#Window] VerticalAlignment#VerticalAlignment verticalAlignment

---
-- Field clipBorder
--
-- @field [parent=#Window] IntRect#IntRect clipBorder

---
-- Field color
--
-- @field [parent=#Window] Color#Color color

---
-- Field priority
--
-- @field [parent=#Window] #number priority

---
-- Field opacity
--
-- @field [parent=#Window] #number opacity

---
-- Field derivedOpacity (Read only)
--
-- @field [parent=#Window] #number derivedOpacity

---
-- Field bringToFront
--
-- @field [parent=#Window] #boolean bringToFront

---
-- Field bringToBack
--
-- @field [parent=#Window] #boolean bringToBack

---
-- Field clipChildren
--
-- @field [parent=#Window] #boolean clipChildren

---
-- Field sortChildren
--
-- @field [parent=#Window] #boolean sortChildren

---
-- Field useDerivedOpacity
--
-- @field [parent=#Window] #boolean useDerivedOpacity

---
-- Field focus
--
-- @field [parent=#Window] #boolean focus

---
-- Field enabled
--
-- @field [parent=#Window] #boolean enabled

---
-- Field editable
--
-- @field [parent=#Window] #boolean editable

---
-- Field selected
--
-- @field [parent=#Window] #boolean selected

---
-- Field visible
--
-- @field [parent=#Window] #boolean visible

---
-- Field hovering
--
-- @field [parent=#Window] #boolean hovering

---
-- Field internal
--
-- @field [parent=#Window] #boolean internal

---
-- Field colorGradient (Read only)
--
-- @field [parent=#Window] #boolean colorGradient

---
-- Field focusMode
--
-- @field [parent=#Window] FocusMode#FocusMode focusMode

---
-- Field dragDropMode
--
-- @field [parent=#Window] #number dragDropMode

---
-- Field style
--
-- @field [parent=#Window] #string style

---
-- Field defaultStyle
--
-- @field [parent=#Window] XMLFile#XMLFile defaultStyle

---
-- Field layoutMode
--
-- @field [parent=#Window] LayoutMode#LayoutMode layoutMode

---
-- Field layoutSpacing
--
-- @field [parent=#Window] #number layoutSpacing

---
-- Field layoutBorder
--
-- @field [parent=#Window] IntRect#IntRect layoutBorder

---
-- Field numChildren (Read only)
--
-- @field [parent=#Window] #number numChildren

---
-- Field parent
--
-- @field [parent=#Window] UIElement#UIElement parent

---
-- Field root (Read only)
--
-- @field [parent=#Window] UIElement#UIElement root

---
-- Field derivedColor (Read only)
--
-- @field [parent=#Window] Color#Color derivedColor

---
-- Field combinedScreenRect (Read only)
--
-- @field [parent=#Window] IntRect#IntRect combinedScreenRect

---
-- Field layoutMinSize (Read only)
--
-- @field [parent=#Window] #number layoutMinSize

---
-- Field indent
--
-- @field [parent=#Window] #number indent

---
-- Field indentSpacing
--
-- @field [parent=#Window] #number indentSpacing

---
-- Field indentWidth (Read only)
--
-- @field [parent=#Window] #number indentWidth

---
-- Field traversalMode
--
-- @field [parent=#Window] TraversalMode#TraversalMode traversalMode

---
-- Field elementEventSender
--
-- @field [parent=#Window] #boolean elementEventSender

---
-- Function SetTemporary
--
-- @function [parent=#Window] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#Window] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Window] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Window] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Window] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Window] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Window] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Window] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#Window] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Window] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Window] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Window] #string category


return nil
