---
-- Module Window
-- Module Window extends BorderImage
-- Generated on 2014-03-13
--
-- @module Window

---
-- Function Window
--
-- @function [parent=#Window] Window
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#Window] new
-- @param self Self reference
-- @return Window#Window

---
-- Function delete
--
-- @function [parent=#Window] delete
-- @param self Self reference

---
-- Function SetMovable
--
-- @function [parent=#Window] SetMovable
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetResizable
--
-- @function [parent=#Window] SetResizable
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetFixedWidthResizing
--
-- @function [parent=#Window] SetFixedWidthResizing
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetFixedHeightResizing
--
-- @function [parent=#Window] SetFixedHeightResizing
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetResizeBorder
--
-- @function [parent=#Window] SetResizeBorder
-- @param self Self reference
-- @param IntRect#IntRect rect rect

---
-- Function SetModal
--
-- @function [parent=#Window] SetModal
-- @param self Self reference
-- @param #boolean modal modal

---
-- Function SetModalShadeColor
--
-- @function [parent=#Window] SetModalShadeColor
-- @param self Self reference
-- @param Color#Color color color

---
-- Function SetModalFrameColor
--
-- @function [parent=#Window] SetModalFrameColor
-- @param self Self reference
-- @param Color#Color color color

---
-- Function SetModalFrameSize
--
-- @function [parent=#Window] SetModalFrameSize
-- @param self Self reference
-- @param IntVector2#IntVector2 size size

---
-- Function IsMovable
--
-- @function [parent=#Window] IsMovable
-- @param self Self reference
-- @return #boolean

---
-- Function IsResizable
--
-- @function [parent=#Window] IsResizable
-- @param self Self reference
-- @return #boolean

---
-- Function GetFixedWidthResizing
--
-- @function [parent=#Window] GetFixedWidthResizing
-- @param self Self reference
-- @return #boolean

---
-- Function GetFixedHeightResizing
--
-- @function [parent=#Window] GetFixedHeightResizing
-- @param self Self reference
-- @return #boolean

---
-- Function GetResizeBorder
--
-- @function [parent=#Window] GetResizeBorder
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function IsModal
--
-- @function [parent=#Window] IsModal
-- @param self Self reference
-- @return #boolean

---
-- Function GetModalShadeColor
--
-- @function [parent=#Window] GetModalShadeColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetModalFrameColor
--
-- @function [parent=#Window] GetModalFrameColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetModalFrameSize
--
-- @function [parent=#Window] GetModalFrameSize
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Field movable
--
-- @field [parent=#Window] #boolean movable

---
-- Field resizable
--
-- @field [parent=#Window] #boolean resizable

---
-- Field fixedWidthResizing
--
-- @field [parent=#Window] #boolean fixedWidthResizing

---
-- Field fixedHeightResizing
--
-- @field [parent=#Window] #boolean fixedHeightResizing

---
-- Field resizeBorder
--
-- @field [parent=#Window] IntRect#IntRect resizeBorder

---
-- Field modal
--
-- @field [parent=#Window] #boolean modal

---
-- Field modalShadeColor
--
-- @field [parent=#Window] Color#Color modalShadeColor

---
-- Field modalFrameColor
--
-- @field [parent=#Window] Color#Color modalFrameColor

---
-- Field modalFrameSize
--
-- @field [parent=#Window] IntVector2#IntVector2 modalFrameSize

---
-- Function BorderImage
--
-- @function [parent=#Window] BorderImage
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#Window] new
-- @param self Self reference
-- @return BorderImage#BorderImage

---
-- Function delete
--
-- @function [parent=#Window] delete
-- @param self Self reference

---
-- Function SetTexture
--
-- @function [parent=#Window] SetTexture
-- @param self Self reference
-- @param Texture#Texture texture texture

---
-- Function SetImageRect
--
-- @function [parent=#Window] SetImageRect
-- @param self Self reference
-- @param IntRect#IntRect rect rect

---
-- Function SetFullImageRect
--
-- @function [parent=#Window] SetFullImageRect
-- @param self Self reference

---
-- Function SetBorder
--
-- @function [parent=#Window] SetBorder
-- @param self Self reference
-- @param IntRect#IntRect rect rect

---
-- Function SetHoverOffset
--
-- @function [parent=#Window] SetHoverOffset
-- @param self Self reference
-- @param IntVector2#IntVector2 offset offset

---
-- Function SetHoverOffset
--
-- @function [parent=#Window] SetHoverOffset
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function SetBlendMode
--
-- @function [parent=#Window] SetBlendMode
-- @param self Self reference
-- @param BlendMode#BlendMode mode mode

---
-- Function SetTiled
--
-- @function [parent=#Window] SetTiled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function GetTexture
--
-- @function [parent=#Window] GetTexture
-- @param self Self reference
-- @return Texture#Texture

---
-- Function GetImageRect
--
-- @function [parent=#Window] GetImageRect
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetBorder
--
-- @function [parent=#Window] GetBorder
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetHoverOffset
--
-- @function [parent=#Window] GetHoverOffset
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetBlendMode
--
-- @function [parent=#Window] GetBlendMode
-- @param self Self reference
-- @return BlendMode#BlendMode

---
-- Function IsTiled
--
-- @function [parent=#Window] IsTiled
-- @param self Self reference
-- @return #boolean

---
-- Field texture
--
-- @field [parent=#Window] Texture#Texture texture

---
-- Field imageRect
--
-- @field [parent=#Window] IntRect#IntRect imageRect

---
-- Field border
--
-- @field [parent=#Window] IntRect#IntRect border

---
-- Field hoverOffset
--
-- @field [parent=#Window] IntVector2#IntVector2 hoverOffset

---
-- Field blendMode
--
-- @field [parent=#Window] BlendMode#BlendMode blendMode

---
-- Field tiled
--
-- @field [parent=#Window] #boolean tiled

---
-- Function UIElement
--
-- @function [parent=#Window] UIElement
-- @param self Self reference

---
-- Function new
--
-- @function [parent=#Window] new
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function delete
--
-- @function [parent=#Window] delete
-- @param self Self reference

---
-- Function GetScreenPosition
--
-- @function [parent=#Window] GetScreenPosition
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function LoadXML
--
-- @function [parent=#Window] LoadXML
-- @param self Self reference
-- @param Deserializer#Deserializer source source
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#Window] SaveXML
-- @param self Self reference
-- @param Serializer#Serializer dest dest
-- @return #boolean

---
-- Function LoadXML
--
-- @function [parent=#Window] LoadXML
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function SaveXML
--
-- @function [parent=#Window] SaveXML
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function FilterAttributes
--
-- @function [parent=#Window] FilterAttributes
-- @param self Self reference
-- @param XMLElement#XMLElement dest dest
-- @return #boolean

---
-- Function SetName
--
-- @function [parent=#Window] SetName
-- @param self Self reference
-- @param #string name name

---
-- Function SetPosition
--
-- @function [parent=#Window] SetPosition
-- @param self Self reference
-- @param IntVector2#IntVector2 position position

---
-- Function SetPosition
--
-- @function [parent=#Window] SetPosition
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function SetSize
--
-- @function [parent=#Window] SetSize
-- @param self Self reference
-- @param IntVector2#IntVector2 size size

---
-- Function SetSize
--
-- @function [parent=#Window] SetSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetWidth
--
-- @function [parent=#Window] SetWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetHeight
--
-- @function [parent=#Window] SetHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetMinSize
--
-- @function [parent=#Window] SetMinSize
-- @param self Self reference
-- @param IntVector2#IntVector2 minSize minSize

---
-- Function SetMinSize
--
-- @function [parent=#Window] SetMinSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetMinWidth
--
-- @function [parent=#Window] SetMinWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetMinHeight
--
-- @function [parent=#Window] SetMinHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetMaxSize
--
-- @function [parent=#Window] SetMaxSize
-- @param self Self reference
-- @param IntVector2#IntVector2 maxSize maxSize

---
-- Function SetMaxSize
--
-- @function [parent=#Window] SetMaxSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetMaxWidth
--
-- @function [parent=#Window] SetMaxWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetMaxHeight
--
-- @function [parent=#Window] SetMaxHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetFixedSize
--
-- @function [parent=#Window] SetFixedSize
-- @param self Self reference
-- @param IntVector2#IntVector2 size size

---
-- Function SetFixedSize
--
-- @function [parent=#Window] SetFixedSize
-- @param self Self reference
-- @param #number width width
-- @param #number height height

---
-- Function SetFixedWidth
--
-- @function [parent=#Window] SetFixedWidth
-- @param self Self reference
-- @param #number width width

---
-- Function SetFixedHeight
--
-- @function [parent=#Window] SetFixedHeight
-- @param self Self reference
-- @param #number height height

---
-- Function SetAlignment
--
-- @function [parent=#Window] SetAlignment
-- @param self Self reference
-- @param HorizontalAlignment#HorizontalAlignment hAlign hAlign
-- @param VerticalAlignment#VerticalAlignment vAlign vAlign

---
-- Function SetHorizontalAlignment
--
-- @function [parent=#Window] SetHorizontalAlignment
-- @param self Self reference
-- @param HorizontalAlignment#HorizontalAlignment align align

---
-- Function SetVerticalAlignment
--
-- @function [parent=#Window] SetVerticalAlignment
-- @param self Self reference
-- @param VerticalAlignment#VerticalAlignment align align

---
-- Function SetClipBorder
--
-- @function [parent=#Window] SetClipBorder
-- @param self Self reference
-- @param IntRect#IntRect rect rect

---
-- Function SetColor
--
-- @function [parent=#Window] SetColor
-- @param self Self reference
-- @param Color#Color color color

---
-- Function SetColor
--
-- @function [parent=#Window] SetColor
-- @param self Self reference
-- @param Corner#Corner corner corner
-- @param Color#Color color color

---
-- Function SetPriority
--
-- @function [parent=#Window] SetPriority
-- @param self Self reference
-- @param #number priority priority

---
-- Function SetOpacity
--
-- @function [parent=#Window] SetOpacity
-- @param self Self reference
-- @param #number opacity opacity

---
-- Function SetBringToFront
--
-- @function [parent=#Window] SetBringToFront
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetBringToBack
--
-- @function [parent=#Window] SetBringToBack
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetClipChildren
--
-- @function [parent=#Window] SetClipChildren
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetSortChildren
--
-- @function [parent=#Window] SetSortChildren
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetUseDerivedOpacity
--
-- @function [parent=#Window] SetUseDerivedOpacity
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetEnabled
--
-- @function [parent=#Window] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetEditable
--
-- @function [parent=#Window] SetEditable
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetFocus
--
-- @function [parent=#Window] SetFocus
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetSelected
--
-- @function [parent=#Window] SetSelected
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetVisible
--
-- @function [parent=#Window] SetVisible
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetFocusMode
--
-- @function [parent=#Window] SetFocusMode
-- @param self Self reference
-- @param FocusMode#FocusMode mode mode

---
-- Function SetDragDropMode
--
-- @function [parent=#Window] SetDragDropMode
-- @param self Self reference
-- @param #number mode mode

---
-- Function SetStyle
--
-- @function [parent=#Window] SetStyle
-- @param self Self reference
-- @param #string styleName styleName
-- @param XMLFile#XMLFile file file
-- @return #boolean

---
-- Function SetStyle
--
-- @function [parent=#Window] SetStyle
-- @param self Self reference
-- @param XMLElement#XMLElement element element
-- @return #boolean

---
-- Function SetStyleAuto
--
-- @function [parent=#Window] SetStyleAuto
-- @param self Self reference
-- @param XMLFile#XMLFile file file
-- @return #boolean

---
-- Function SetDefaultStyle
--
-- @function [parent=#Window] SetDefaultStyle
-- @param self Self reference
-- @param XMLFile#XMLFile style style

---
-- Function SetLayout
--
-- @function [parent=#Window] SetLayout
-- @param self Self reference
-- @param LayoutMode#LayoutMode mode mode
-- @param #number spacing spacing

---
-- Function SetLayout
--
-- @function [parent=#Window] SetLayout
-- @param self Self reference
-- @param LayoutMode#LayoutMode mode mode
-- @param #number spacing spacing
-- @param IntRect#IntRect border border

---
-- Function SetLayoutMode
--
-- @function [parent=#Window] SetLayoutMode
-- @param self Self reference
-- @param LayoutMode#LayoutMode mode mode

---
-- Function SetLayoutSpacing
--
-- @function [parent=#Window] SetLayoutSpacing
-- @param self Self reference
-- @param #number spacing spacing

---
-- Function SetLayoutBorder
--
-- @function [parent=#Window] SetLayoutBorder
-- @param self Self reference
-- @param IntRect#IntRect border border

---
-- Function SetIndent
--
-- @function [parent=#Window] SetIndent
-- @param self Self reference
-- @param #number indent indent

---
-- Function SetIndentSpacing
--
-- @function [parent=#Window] SetIndentSpacing
-- @param self Self reference
-- @param #number indentSpacing indentSpacing

---
-- Function UpdateLayout
--
-- @function [parent=#Window] UpdateLayout
-- @param self Self reference

---
-- Function DisableLayoutUpdate
--
-- @function [parent=#Window] DisableLayoutUpdate
-- @param self Self reference

---
-- Function EnableLayoutUpdate
--
-- @function [parent=#Window] EnableLayoutUpdate
-- @param self Self reference

---
-- Function BringToFront
--
-- @function [parent=#Window] BringToFront
-- @param self Self reference

---
-- Function CreateChild
--
-- @function [parent=#Window] CreateChild
-- @param self Self reference
-- @param #string type type
-- @param #string name name
-- @param #number index index
-- @return UIElement#UIElement

---
-- Function AddChild
--
-- @function [parent=#Window] AddChild
-- @param self Self reference
-- @param UIElement#UIElement element element

---
-- Function InsertChild
--
-- @function [parent=#Window] InsertChild
-- @param self Self reference
-- @param #number index index
-- @param UIElement#UIElement element element

---
-- Function RemoveChild
--
-- @function [parent=#Window] RemoveChild
-- @param self Self reference
-- @param UIElement#UIElement element element
-- @param #number index index

---
-- Function RemoveChildAtIndex
--
-- @function [parent=#Window] RemoveChildAtIndex
-- @param self Self reference
-- @param #number index index

---
-- Function RemoveAllChildren
--
-- @function [parent=#Window] RemoveAllChildren
-- @param self Self reference

---
-- Function Remove
--
-- @function [parent=#Window] Remove
-- @param self Self reference

---
-- Function FindChild
--
-- @function [parent=#Window] FindChild
-- @param self Self reference
-- @param UIElement#UIElement element element
-- @return #number

---
-- Function SetParent
--
-- @function [parent=#Window] SetParent
-- @param self Self reference
-- @param UIElement#UIElement parent parent
-- @param #number index index

---
-- Function SetVar
--
-- @function [parent=#Window] SetVar
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash key key
-- @param Variant#Variant value value

---
-- Function SetInternal
--
-- @function [parent=#Window] SetInternal
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetTraversalMode
--
-- @function [parent=#Window] SetTraversalMode
-- @param self Self reference
-- @param TraversalMode#TraversalMode traversalMode traversalMode

---
-- Function SetElementEventSender
--
-- @function [parent=#Window] SetElementEventSender
-- @param self Self reference
-- @param #boolean flag flag

---
-- Function GetName
--
-- @function [parent=#Window] GetName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetPosition
--
-- @function [parent=#Window] GetPosition
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetSize
--
-- @function [parent=#Window] GetSize
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetWidth
--
-- @function [parent=#Window] GetWidth
-- @param self Self reference
-- @return #number

---
-- Function GetHeight
--
-- @function [parent=#Window] GetHeight
-- @param self Self reference
-- @return #number

---
-- Function GetMinSize
--
-- @function [parent=#Window] GetMinSize
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetMinWidth
--
-- @function [parent=#Window] GetMinWidth
-- @param self Self reference
-- @return #number

---
-- Function GetMinHeight
--
-- @function [parent=#Window] GetMinHeight
-- @param self Self reference
-- @return #number

---
-- Function GetMaxSize
--
-- @function [parent=#Window] GetMaxSize
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetMaxWidth
--
-- @function [parent=#Window] GetMaxWidth
-- @param self Self reference
-- @return #number

---
-- Function GetMaxHeight
--
-- @function [parent=#Window] GetMaxHeight
-- @param self Self reference
-- @return #number

---
-- Function IsFixedSize
--
-- @function [parent=#Window] IsFixedSize
-- @param self Self reference
-- @return #boolean

---
-- Function IsFixedWidth
--
-- @function [parent=#Window] IsFixedWidth
-- @param self Self reference
-- @return #boolean

---
-- Function IsFixedHeight
--
-- @function [parent=#Window] IsFixedHeight
-- @param self Self reference
-- @return #boolean

---
-- Function GetChildOffset
--
-- @function [parent=#Window] GetChildOffset
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetHorizontalAlignment
--
-- @function [parent=#Window] GetHorizontalAlignment
-- @param self Self reference
-- @return HorizontalAlignment#HorizontalAlignment

---
-- Function GetVerticalAlignment
--
-- @function [parent=#Window] GetVerticalAlignment
-- @param self Self reference
-- @return VerticalAlignment#VerticalAlignment

---
-- Function GetClipBorder
--
-- @function [parent=#Window] GetClipBorder
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetColor
--
-- @function [parent=#Window] GetColor
-- @param self Self reference
-- @param Corner#Corner corner corner
-- @return const Color#const Color

---
-- Function GetPriority
--
-- @function [parent=#Window] GetPriority
-- @param self Self reference
-- @return #number

---
-- Function GetOpacity
--
-- @function [parent=#Window] GetOpacity
-- @param self Self reference
-- @return #number

---
-- Function GetDerivedOpacity
--
-- @function [parent=#Window] GetDerivedOpacity
-- @param self Self reference
-- @return #number

---
-- Function GetBringToFront
--
-- @function [parent=#Window] GetBringToFront
-- @param self Self reference
-- @return #boolean

---
-- Function GetBringToBack
--
-- @function [parent=#Window] GetBringToBack
-- @param self Self reference
-- @return #boolean

---
-- Function GetClipChildren
--
-- @function [parent=#Window] GetClipChildren
-- @param self Self reference
-- @return #boolean

---
-- Function GetSortChildren
--
-- @function [parent=#Window] GetSortChildren
-- @param self Self reference
-- @return #boolean

---
-- Function GetUseDerivedOpacity
--
-- @function [parent=#Window] GetUseDerivedOpacity
-- @param self Self reference
-- @return #boolean

---
-- Function HasFocus
--
-- @function [parent=#Window] HasFocus
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabled
--
-- @function [parent=#Window] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEditable
--
-- @function [parent=#Window] IsEditable
-- @param self Self reference
-- @return #boolean

---
-- Function IsSelected
--
-- @function [parent=#Window] IsSelected
-- @param self Self reference
-- @return #boolean

---
-- Function IsVisible
--
-- @function [parent=#Window] IsVisible
-- @param self Self reference
-- @return #boolean

---
-- Function IsHovering
--
-- @function [parent=#Window] IsHovering
-- @param self Self reference
-- @return #boolean

---
-- Function IsInternal
--
-- @function [parent=#Window] IsInternal
-- @param self Self reference
-- @return #boolean

---
-- Function HasColorGradient
--
-- @function [parent=#Window] HasColorGradient
-- @param self Self reference
-- @return #boolean

---
-- Function GetFocusMode
--
-- @function [parent=#Window] GetFocusMode
-- @param self Self reference
-- @return FocusMode#FocusMode

---
-- Function GetDragDropMode
--
-- @function [parent=#Window] GetDragDropMode
-- @param self Self reference
-- @return #number

---
-- Function GetAppliedStyle
--
-- @function [parent=#Window] GetAppliedStyle
-- @param self Self reference
-- @return const String#const String

---
-- Function GetDefaultStyle
--
-- @function [parent=#Window] GetDefaultStyle
-- @param self Self reference
-- @param #boolean recursiveUp recursiveUp
-- @return XMLFile#XMLFile

---
-- Function GetLayoutMode
--
-- @function [parent=#Window] GetLayoutMode
-- @param self Self reference
-- @return LayoutMode#LayoutMode

---
-- Function GetLayoutSpacing
--
-- @function [parent=#Window] GetLayoutSpacing
-- @param self Self reference
-- @return #number

---
-- Function GetLayoutBorder
--
-- @function [parent=#Window] GetLayoutBorder
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function GetNumChildren
--
-- @function [parent=#Window] GetNumChildren
-- @param self Self reference
-- @param #boolean recursive recursive
-- @return #number

---
-- Function GetChild
--
-- @function [parent=#Window] GetChild
-- @param self Self reference
-- @param #string name name
-- @param #boolean recursive recursive
-- @return UIElement#UIElement

---
-- Function GetChild
--
-- @function [parent=#Window] GetChild
-- @param self Self reference
-- @param #number index index
-- @return UIElement#UIElement

---
-- Function GetParent
--
-- @function [parent=#Window] GetParent
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetRoot
--
-- @function [parent=#Window] GetRoot
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Function GetDerivedColor
--
-- @function [parent=#Window] GetDerivedColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetVar
--
-- @function [parent=#Window] GetVar
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash key key
-- @return const Variant#const Variant

---
-- Function GetVars
--
-- @function [parent=#Window] GetVars
-- @param self Self reference
-- @return const VariantMap#const VariantMap

---
-- Function ScreenToElement
--
-- @function [parent=#Window] ScreenToElement
-- @param self Self reference
-- @param IntVector2#IntVector2 screenPosition screenPosition
-- @return IntVector2#IntVector2

---
-- Function ElementToScreen
--
-- @function [parent=#Window] ElementToScreen
-- @param self Self reference
-- @param IntVector2#IntVector2 position position
-- @return IntVector2#IntVector2

---
-- Function IsInside
--
-- @function [parent=#Window] IsInside
-- @param self Self reference
-- @param IntVector2#IntVector2 position position
-- @param #boolean isScreen isScreen
-- @return #boolean

---
-- Function IsInsideCombined
--
-- @function [parent=#Window] IsInsideCombined
-- @param self Self reference
-- @param IntVector2#IntVector2 position position
-- @param #boolean isScreen isScreen
-- @return #boolean

---
-- Function GetCombinedScreenRect
--
-- @function [parent=#Window] GetCombinedScreenRect
-- @param self Self reference
-- @return IntRect#IntRect

---
-- Function SortChildren
--
-- @function [parent=#Window] SortChildren
-- @param self Self reference

---
-- Function GetLayoutMinSize
--
-- @function [parent=#Window] GetLayoutMinSize
-- @param self Self reference
-- @return #number

---
-- Function GetIndent
--
-- @function [parent=#Window] GetIndent
-- @param self Self reference
-- @return #number

---
-- Function GetIndentSpacing
--
-- @function [parent=#Window] GetIndentSpacing
-- @param self Self reference
-- @return #number

---
-- Function GetIndentWidth
--
-- @function [parent=#Window] GetIndentWidth
-- @param self Self reference
-- @return #number

---
-- Function SetChildOffset
--
-- @function [parent=#Window] SetChildOffset
-- @param self Self reference
-- @param IntVector2#IntVector2 offset offset

---
-- Function SetHovering
--
-- @function [parent=#Window] SetHovering
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function GetColor
--
-- @function [parent=#Window] GetColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetTraversalMode
--
-- @function [parent=#Window] GetTraversalMode
-- @param self Self reference
-- @return TraversalMode#TraversalMode

---
-- Function IsElementEventSender
--
-- @function [parent=#Window] IsElementEventSender
-- @param self Self reference
-- @return #boolean

---
-- Function GetElementEventSender
--
-- @function [parent=#Window] GetElementEventSender
-- @param self Self reference
-- @return UIElement#UIElement

---
-- Field screenPosition (Read only)
--
-- @field [parent=#Window] IntVector2#IntVector2 screenPosition

---
-- Field name
--
-- @field [parent=#Window] #string name

---
-- Field position
--
-- @field [parent=#Window] IntVector2#IntVector2 position

---
-- Field size
--
-- @field [parent=#Window] IntVector2#IntVector2 size

---
-- Field width
--
-- @field [parent=#Window] #number width

---
-- Field height
--
-- @field [parent=#Window] #number height

---
-- Field minSize
--
-- @field [parent=#Window] IntVector2#IntVector2 minSize

---
-- Field minWidth
--
-- @field [parent=#Window] #number minWidth

---
-- Field minHeight
--
-- @field [parent=#Window] #number minHeight

---
-- Field maxSize
--
-- @field [parent=#Window] IntVector2#IntVector2 maxSize

---
-- Field maxWidth
--
-- @field [parent=#Window] #number maxWidth

---
-- Field maxHeight
--
-- @field [parent=#Window] #number maxHeight

---
-- Field fixedSize (Read only)
--
-- @field [parent=#Window] #boolean fixedSize

---
-- Field fixedWidth (Read only)
--
-- @field [parent=#Window] #boolean fixedWidth

---
-- Field fixedHeight (Read only)
--
-- @field [parent=#Window] #boolean fixedHeight

---
-- Field childOffset
--
-- @field [parent=#Window] IntVector2#IntVector2 childOffset

---
-- Field horizontalAlignment
--
-- @field [parent=#Window] HorizontalAlignment#HorizontalAlignment horizontalAlignment

---
-- Field verticalAlignment
--
-- @field [parent=#Window] VerticalAlignment#VerticalAlignment verticalAlignment

---
-- Field clipBorder
--
-- @field [parent=#Window] IntRect#IntRect clipBorder

---
-- Field color
--
-- @field [parent=#Window] Color#Color color

---
-- Field priority
--
-- @field [parent=#Window] #number priority

---
-- Field opacity
--
-- @field [parent=#Window] #number opacity

---
-- Field derivedOpacity (Read only)
--
-- @field [parent=#Window] #number derivedOpacity

---
-- Field bringToFront
--
-- @field [parent=#Window] #boolean bringToFront

---
-- Field bringToBack
--
-- @field [parent=#Window] #boolean bringToBack

---
-- Field clipChildren
--
-- @field [parent=#Window] #boolean clipChildren

---
-- Field sortChildren
--
-- @field [parent=#Window] #boolean sortChildren

---
-- Field useDerivedOpacity
--
-- @field [parent=#Window] #boolean useDerivedOpacity

---
-- Field focus
--
-- @field [parent=#Window] #boolean focus

---
-- Field enabled
--
-- @field [parent=#Window] #boolean enabled

---
-- Field editable
--
-- @field [parent=#Window] #boolean editable

---
-- Field selected
--
-- @field [parent=#Window] #boolean selected

---
-- Field visible
--
-- @field [parent=#Window] #boolean visible

---
-- Field hovering
--
-- @field [parent=#Window] #boolean hovering

---
-- Field internal
--
-- @field [parent=#Window] #boolean internal

---
-- Field colorGradient (Read only)
--
-- @field [parent=#Window] #boolean colorGradient

---
-- Field focusMode
--
-- @field [parent=#Window] FocusMode#FocusMode focusMode

---
-- Field dragDropMode
--
-- @field [parent=#Window] #number dragDropMode

---
-- Field style
--
-- @field [parent=#Window] #string style

---
-- Field defaultStyle
--
-- @field [parent=#Window] XMLFile#XMLFile defaultStyle

---
-- Field layoutMode
--
-- @field [parent=#Window] LayoutMode#LayoutMode layoutMode

---
-- Field layoutSpacing
--
-- @field [parent=#Window] #number layoutSpacing

---
-- Field layoutBorder
--
-- @field [parent=#Window] IntRect#IntRect layoutBorder

---
-- Field numChildren (Read only)
--
-- @field [parent=#Window] #number numChildren

---
-- Field parent
--
-- @field [parent=#Window] UIElement#UIElement parent

---
-- Field root (Read only)
--
-- @field [parent=#Window] UIElement#UIElement root

---
-- Field derivedColor (Read only)
--
-- @field [parent=#Window] Color#Color derivedColor

---
-- Field combinedScreenRect (Read only)
--
-- @field [parent=#Window] IntRect#IntRect combinedScreenRect

---
-- Field layoutMinSize (Read only)
--
-- @field [parent=#Window] #number layoutMinSize

---
-- Field indent
--
-- @field [parent=#Window] #number indent

---
-- Field indentSpacing
--
-- @field [parent=#Window] #number indentSpacing

---
-- Field indentWidth (Read only)
--
-- @field [parent=#Window] #number indentWidth

---
-- Field traversalMode
--
-- @field [parent=#Window] TraversalMode#TraversalMode traversalMode

---
-- Field elementEventSender
--
-- @field [parent=#Window] #boolean elementEventSender

---
-- Function SetTemporary
--
-- @function [parent=#Window] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#Window] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#Window] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#Window] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Window] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Window] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Window] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Window] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#Window] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Window] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Window] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Window] #string category


return nil
