---
-- Module Window
-- Module Window extends BorderImage
-- Generated on 2014-05-31
--
-- @module Window

---
-- Function Window()
--
-- @function [parent=#Window] Window
-- @param self Self reference

---
-- Function new()
--
-- @function [parent=#Window] new
-- @param self Self reference
-- @return Window#Window

---
-- Function delete()
--
-- @function [parent=#Window] delete
-- @param self Self reference

---
-- Function SetMovable()
-- Set whether can be moved.
--
-- @function [parent=#Window] SetMovable
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetResizable()
-- Set whether can be resized.
--
-- @function [parent=#Window] SetResizable
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetFixedWidthResizing()
-- Set whether resizing width is fixed.
--
-- @function [parent=#Window] SetFixedWidthResizing
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetFixedHeightResizing()
-- Set whether resizing height is fixed.
--
-- @function [parent=#Window] SetFixedHeightResizing
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetResizeBorder()
-- Set resize area width at edges.
--
-- @function [parent=#Window] SetResizeBorder
-- @param self Self reference
-- @param IntRect#IntRect rect rect

---
-- Function SetModal()
-- Set modal flag. When the modal flag is set, the focused window needs to be dismissed first to allow other UI elements to gain focus.
--
-- @function [parent=#Window] SetModal
-- @param self Self reference
-- @param #boolean modal modal

---
-- Function SetModalShadeColor()
-- Set modal shade color.
--
-- @function [parent=#Window] SetModalShadeColor
-- @param self Self reference
-- @param Color#Color color color

---
-- Function SetModalFrameColor()
-- Set modal frame color.
--
-- @function [parent=#Window] SetModalFrameColor
-- @param self Self reference
-- @param Color#Color color color

---
-- Function SetModalFrameSize()
-- Set modal frame size.
--
-- @function [parent=#Window] SetModalFrameSize
-- @param self Self reference
-- @param IntVector2#IntVector2 size size

---
-- Function IsMovable()
-- Return whether is movable.
--
-- @function [parent=#Window] IsMovable
-- @param self Self reference
-- @return #boolean

---
-- Function IsResizable()
-- Return whether is resizable.
--
-- @function [parent=#Window] IsResizable
-- @param self Self reference
-- @return #boolean

---
-- Function GetFixedWidthResizing()
-- Return whether is resizing width is fixed.
--
-- @function [parent=#Window] GetFixedWidthResizing
-- @param self Self reference
-- @return #boolean

---
-- Function GetFixedHeightResizing()
-- Return whether is resizing height is fixed.
--
-- @function [parent=#Window] GetFixedHeightResizing
-- @param self Self reference
-- @return #boolean

---
-- Function GetResizeBorder()
-- Return resize area width at edges.
--
-- @function [parent=#Window] GetResizeBorder
-- @param self Self reference
-- @return const IntRect#const IntRect

---
-- Function IsModal()
-- Return modal flag.
--
-- @function [parent=#Window] IsModal
-- @param self Self reference
-- @return #boolean

---
-- Function GetModalShadeColor()
-- Get modal shade color.
--
-- @function [parent=#Window] GetModalShadeColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetModalFrameColor()
-- Get modal frame color.
--
-- @function [parent=#Window] GetModalFrameColor
-- @param self Self reference
-- @return const Color#const Color

---
-- Function GetModalFrameSize()
-- Get modal frame size.
--
-- @function [parent=#Window] GetModalFrameSize
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Field movable
--
-- @field [parent=#Window] #boolean movable

---
-- Field resizable
--
-- @field [parent=#Window] #boolean resizable

---
-- Field fixedWidthResizing
--
-- @field [parent=#Window] #boolean fixedWidthResizing

---
-- Field fixedHeightResizing
--
-- @field [parent=#Window] #boolean fixedHeightResizing

---
-- Field resizeBorder
--
-- @field [parent=#Window] IntRect#IntRect resizeBorder

---
-- Field modal
--
-- @field [parent=#Window] #boolean modal

---
-- Field modalShadeColor
--
-- @field [parent=#Window] Color#Color modalShadeColor

---
-- Field modalFrameColor
--
-- @field [parent=#Window] Color#Color modalFrameColor

---
-- Field modalFrameSize
--
-- @field [parent=#Window] IntVector2#IntVector2 modalFrameSize


return nil
