---
-- Module Window
-- Extends BorderImage
--
-- @module Window

---
-- Function Window
--
-- @function [parent=#Window] Window

---
-- Function new
--
-- @function [parent=#Window] new
-- @return Window#Window

---
-- Function delete
--
-- @function [parent=#Window] delete

---
-- Function SetMovable
--
-- @function [parent=#Window] SetMovable
-- @param #boolean enableenable

---
-- Function SetResizable
--
-- @function [parent=#Window] SetResizable
-- @param #boolean enableenable

---
-- Function SetFixedWidthResizing
--
-- @function [parent=#Window] SetFixedWidthResizing
-- @param #boolean enableenable

---
-- Function SetFixedHeightResizing
--
-- @function [parent=#Window] SetFixedHeightResizing
-- @param #boolean enableenable

---
-- Function SetResizeBorder
--
-- @function [parent=#Window] SetResizeBorder
-- @param IntRect#IntRect rectrect

---
-- Function SetModal
--
-- @function [parent=#Window] SetModal
-- @param #boolean modalmodal

---
-- Function SetModalShadeColor
--
-- @function [parent=#Window] SetModalShadeColor
-- @param Color#Color colorcolor

---
-- Function SetModalFrameColor
--
-- @function [parent=#Window] SetModalFrameColor
-- @param Color#Color colorcolor

---
-- Function SetModalFrameSize
--
-- @function [parent=#Window] SetModalFrameSize
-- @param IntVector2#IntVector2 sizesize

---
-- Function IsMovable
--
-- @function [parent=#Window] IsMovable
-- @return #boolean

---
-- Function IsResizable
--
-- @function [parent=#Window] IsResizable
-- @return #boolean

---
-- Function GetFixedWidthResizing
--
-- @function [parent=#Window] GetFixedWidthResizing
-- @return #boolean

---
-- Function GetFixedHeightResizing
--
-- @function [parent=#Window] GetFixedHeightResizing
-- @return #boolean

---
-- Function GetResizeBorder
--
-- @function [parent=#Window] GetResizeBorder
-- @return const IntRect#const IntRect

---
-- Function IsModal
--
-- @function [parent=#Window] IsModal
-- @return #boolean

---
-- Function GetModalShadeColor
--
-- @function [parent=#Window] GetModalShadeColor
-- @return const Color#const Color

---
-- Function GetModalFrameColor
--
-- @function [parent=#Window] GetModalFrameColor
-- @return const Color#const Color

---
-- Function GetModalFrameSize
--
-- @function [parent=#Window] GetModalFrameSize
-- @return const IntVector2#const IntVector2

---
-- Field movable
--
-- @field [parent=#Window] #boolean movable

---
-- Field resizable
--
-- @field [parent=#Window] #boolean resizable

---
-- Field fixedWidthResizing
--
-- @field [parent=#Window] #boolean fixedWidthResizing

---
-- Field fixedHeightResizing
--
-- @field [parent=#Window] #boolean fixedHeightResizing

---
-- Field resizeBorder
--
-- @field [parent=#Window] IntRect#IntRect resizeBorder

---
-- Field modal
--
-- @field [parent=#Window] #boolean modal

---
-- Field modalShadeColor
--
-- @field [parent=#Window] Color#Color modalShadeColor

---
-- Field modalFrameColor
--
-- @field [parent=#Window] Color#Color modalFrameColor

---
-- Field modalFrameSize
--
-- @field [parent=#Window] IntVector2#IntVector2 modalFrameSize


return nil
