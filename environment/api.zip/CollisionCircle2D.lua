---
-- Module CollisionCircle2D
-- Module CollisionCircle2D extends CollisionShape2D
-- Generated on 2014-05-31
--
-- @module CollisionCircle2D

---
-- Function SetRadius()
-- Set radius.
--
-- @function [parent=#CollisionCircle2D] SetRadius
-- @param self Self reference
-- @param #number radius radius

---
-- Function SetCenter()
-- Set center.
--
-- @function [parent=#CollisionCircle2D] SetCenter
-- @param self Self reference
-- @param Vector2#Vector2 center center

---
-- Function SetCenter()
-- Set center.
--
-- @function [parent=#CollisionCircle2D] SetCenter
-- @param self Self reference
-- @param #number x x
-- @param #number y y

---
-- Function GetRadius()
-- Return radius.
--
-- @function [parent=#CollisionCircle2D] GetRadius
-- @param self Self reference
-- @return #number

---
-- Function GetCenter()
-- Return center.
--
-- @function [parent=#CollisionCircle2D] GetCenter
-- @param self Self reference
-- @return const Vector2#const Vector2

---
-- Field radius
--
-- @field [parent=#CollisionCircle2D] #number radius

---
-- Field center
--
-- @field [parent=#CollisionCircle2D] Vector2#Vector2 center


return nil
