---
-- Module CollisionChain2D
-- Module CollisionChain2D extends CollisionShape2D
-- Generated on 2014-05-31
--
-- @module CollisionChain2D

---
-- Function SetLoop()
-- Set loop.
--
-- @function [parent=#CollisionChain2D] SetLoop
-- @param self Self reference
-- @param #boolean loop loop

---
-- Function SetVertexCount()
-- Set vertex count.
--
-- @function [parent=#CollisionChain2D] SetVertexCount
-- @param self Self reference
-- @param #number count count

---
-- Function SetVertex()
-- Set vertex.
--
-- @function [parent=#CollisionChain2D] SetVertex
-- @param self Self reference
-- @param #number index index
-- @param Vector2#Vector2 vertex vertex

---
-- Function SetVertices()
--
-- @function [parent=#CollisionChain2D] SetVertices
-- @param self Self reference
-- @param PODVector<Vector2>#PODVector<Vector2> vertices vertices

---
-- Function GetLoop()
-- Return loop.
--
-- @function [parent=#CollisionChain2D] GetLoop
-- @param self Self reference
-- @return #boolean

---
-- Function GetVertexCount()
-- Return vertex count.
--
-- @function [parent=#CollisionChain2D] GetVertexCount
-- @param self Self reference
-- @return #number

---
-- Function GetVertex()
--
-- @function [parent=#CollisionChain2D] GetVertex
-- @param self Self reference
-- @param #number index index
-- @return const Vector2#const Vector2

---
-- Field loop
--
-- @field [parent=#CollisionChain2D] #boolean loop

---
-- Field vertexCount
--
-- @field [parent=#CollisionChain2D] #number vertexCount


return nil
