---
-- Module Input
-- Extends Object
--
-- @module Input

---
-- Function SetToggleFullscreen
--
-- @function [parent=#Input] SetToggleFullscreen
-- @param #boolean enableenable

---
-- Function SetMouseVisible
--
-- @function [parent=#Input] SetMouseVisible
-- @param #boolean enableenable

---
-- Function OpenJoystick
--
-- @function [parent=#Input] OpenJoystick
-- @param #number indexindex
-- @return #boolean

---
-- Function CloseJoystick
--
-- @function [parent=#Input] CloseJoystick
-- @param #number indexindex

---
-- Function DetectJoysticks
--
-- @function [parent=#Input] DetectJoysticks
-- @return #boolean

---
-- Function SetScreenKeyboardVisible
--
-- @function [parent=#Input] SetScreenKeyboardVisible
-- @param #boolean enableenable

---
-- Function GetKeyDown
--
-- @function [parent=#Input] GetKeyDown
-- @param #number keykey
-- @return #boolean

---
-- Function GetKeyPress
--
-- @function [parent=#Input] GetKeyPress
-- @param #number keykey
-- @return #boolean

---
-- Function GetMouseButtonDown
--
-- @function [parent=#Input] GetMouseButtonDown
-- @param #number buttonbutton
-- @return #boolean

---
-- Function GetMouseButtonPress
--
-- @function [parent=#Input] GetMouseButtonPress
-- @param #number buttonbutton
-- @return #boolean

---
-- Function GetQualifierDown
--
-- @function [parent=#Input] GetQualifierDown
-- @param #number qualifierqualifier
-- @return #boolean

---
-- Function GetQualifierPress
--
-- @function [parent=#Input] GetQualifierPress
-- @param #number qualifierqualifier
-- @return #boolean

---
-- Function GetQualifiers
--
-- @function [parent=#Input] GetQualifiers
-- @return #number

---
-- Function GetMousePosition
--
-- @function [parent=#Input] GetMousePosition
-- @return IntVector2#IntVector2

---
-- Function GetMouseMove
--
-- @function [parent=#Input] GetMouseMove
-- @return const IntVector2#const IntVector2

---
-- Function GetMouseMoveX
--
-- @function [parent=#Input] GetMouseMoveX
-- @return #number

---
-- Function GetMouseMoveY
--
-- @function [parent=#Input] GetMouseMoveY
-- @return #number

---
-- Function GetMouseMoveWheel
--
-- @function [parent=#Input] GetMouseMoveWheel
-- @return #number

---
-- Function GetNumTouches
--
-- @function [parent=#Input] GetNumTouches
-- @return #number

---
-- Function GetTouch
--
-- @function [parent=#Input] GetTouch
-- @param #number indexindex
-- @return TouchState#TouchState

---
-- Function GetNumJoysticks
--
-- @function [parent=#Input] GetNumJoysticks
-- @return #number

---
-- Function GetJoystickName
--
-- @function [parent=#Input] GetJoystickName
-- @param #number indexindex
-- @return const String#const String

---
-- Function GetJoystick
--
-- @function [parent=#Input] GetJoystick
-- @param #number indexindex
-- @return JoystickState#JoystickState

---
-- Function GetToggleFullscreen
--
-- @function [parent=#Input] GetToggleFullscreen
-- @return #boolean

---
-- Function GetScreenKeyboardSupport
--
-- @function [parent=#Input] GetScreenKeyboardSupport
-- @return #boolean

---
-- Function IsScreenKeyboardVisible
--
-- @function [parent=#Input] IsScreenKeyboardVisible
-- @return #boolean

---
-- Function IsMouseVisible
--
-- @function [parent=#Input] IsMouseVisible
-- @return #boolean

---
-- Function HasFocus
--
-- @function [parent=#Input] HasFocus
-- @return #boolean

---
-- Function IsMinimized
--
-- @function [parent=#Input] IsMinimized
-- @return #boolean

---
-- Field qualifiers (Read only)
--
-- @field [parent=#Input] #number qualifiers

---
-- Field mousePosition (Read only)
--
-- @field [parent=#Input] IntVector2#IntVector2 mousePosition

---
-- Field mouseMove (Read only)
--
-- @field [parent=#Input] IntVector2#IntVector2 mouseMove

---
-- Field mouseMoveX (Read only)
--
-- @field [parent=#Input] #number mouseMoveX

---
-- Field mouseMoveY (Read only)
--
-- @field [parent=#Input] #number mouseMoveY

---
-- Field mouseMoveWheel (Read only)
--
-- @field [parent=#Input] #number mouseMoveWheel

---
-- Field numTouches (Read only)
--
-- @field [parent=#Input] #number numTouches

---
-- Field numJoysticks (Read only)
--
-- @field [parent=#Input] #number numJoysticks

---
-- Field toggleFullscreen (Read only)
--
-- @field [parent=#Input] #boolean toggleFullscreen

---
-- Field screenKeyboardSupport (Read only)
--
-- @field [parent=#Input] #boolean screenKeyboardSupport

---
-- Field screenKeyboardVisible
--
-- @field [parent=#Input] #boolean screenKeyboardVisible

---
-- Field mouseVisible
--
-- @field [parent=#Input] #boolean mouseVisible

---
-- Field focus (Read only)
--
-- @field [parent=#Input] #boolean focus

---
-- Field minimized (Read only)
--
-- @field [parent=#Input] #boolean minimized


return nil
