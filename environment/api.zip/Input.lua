---
-- Module Input
-- Module Input extends Object
-- Generated on 2014-05-31
--
-- @module Input

---
-- Function SetToggleFullscreen()
-- Set whether ALT-ENTER fullscreen toggle is enabled.
--
-- @function [parent=#Input] SetToggleFullscreen
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetMouseVisible()
-- Set whether the operating system mouse cursor is visible. When not visible (default), is kept centered to prevent leaving the window.
--
-- @function [parent=#Input] SetMouseVisible
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetMouseGrabbed()
-- Set whether the mouse is currently being grabbed by an operation.
--
-- @function [parent=#Input] SetMouseGrabbed
-- @param self Self reference
-- @param #boolean grab grab

---
-- Function AddScreenJoystick()
--
-- @function [parent=#Input] AddScreenJoystick
-- @param self Self reference
-- @param XMLFile#XMLFile layoutFile layoutFile
-- @param XMLFile#XMLFile styleFile styleFile
-- @return #number

---
-- Function RemoveScreenJoystick()
--
-- @function [parent=#Input] RemoveScreenJoystick
-- @param self Self reference
-- @param #number id id
-- @return #boolean

---
-- Function SetScreenJoystickVisible()
--
-- @function [parent=#Input] SetScreenJoystickVisible
-- @param self Self reference
-- @param #number id id
-- @param #boolean enable enable

---
-- Function SetScreenKeyboardVisible()
-- Show or hide on-screen keyboard on platforms that support it. When shown, keypresses from it are delivered as key events.
--
-- @function [parent=#Input] SetScreenKeyboardVisible
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetTouchEmulation()
-- Set touch emulation by mouse. Only available on desktop platforms. When enabled, actual mouse events are no longer sent and the mouse cursor is forced visible.
--
-- @function [parent=#Input] SetTouchEmulation
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function RecordGesture()
-- Begin recording a touch gesture. Return true if successful. The E_GESTURERECORDED event (which contains the ID for the new gesture) will be sent when recording finishes.
--
-- @function [parent=#Input] RecordGesture
-- @param self Self reference
-- @return #boolean

---
-- Function SaveGestures()
--
-- @function [parent=#Input] SaveGestures
-- @param self Self reference
-- @param File#File dest dest
-- @return #boolean

---
-- Function SaveGesture()
--
-- @function [parent=#Input] SaveGesture
-- @param self Self reference
-- @param File#File dest dest
-- @param #number gestureID gestureID
-- @return #boolean

---
-- Function LoadGestures()
--
-- @function [parent=#Input] LoadGestures
-- @param self Self reference
-- @param File#File source source
-- @return #number

---
-- Function SaveGestures()
--
-- @function [parent=#Input] SaveGestures
-- @param self Self reference
-- @param #string fileName fileName
-- @return #boolean

---
-- Function SaveGesture()
--
-- @function [parent=#Input] SaveGesture
-- @param self Self reference
-- @param #string fileName fileName
-- @param #number gestureID gestureID
-- @return #boolean

---
-- Function LoadGestures()
--
-- @function [parent=#Input] LoadGestures
-- @param self Self reference
-- @param #string fileName fileName
-- @return #number

---
-- Function RemoveGesture()
-- Remove an in-memory gesture by ID. Return true if was found.
--
-- @function [parent=#Input] RemoveGesture
-- @param self Self reference
-- @param #number gestureID gestureID
-- @return #boolean

---
-- Function RemoveAllGestures()
-- Remove all in-memory gestures.
--
-- @function [parent=#Input] RemoveAllGestures
-- @param self Self reference

---
-- Function GetKeyFromName()
-- Return keycode from key name.
--
-- @function [parent=#Input] GetKeyFromName
-- @param self Self reference
-- @param #string name name
-- @return #number

---
-- Function GetKeyFromScancode()
-- Return keycode from scancode.
--
-- @function [parent=#Input] GetKeyFromScancode
-- @param self Self reference
-- @param #number scancode scancode
-- @return #number

---
-- Function GetKeyName()
-- Return name of key from keycode.
--
-- @function [parent=#Input] GetKeyName
-- @param self Self reference
-- @param #number key key
-- @return #string

---
-- Function GetScancodeFromKey()
-- Return scancode from keycode.
--
-- @function [parent=#Input] GetScancodeFromKey
-- @param self Self reference
-- @param #number key key
-- @return #number

---
-- Function GetScancodeFromName()
-- Return scancode from key name.
--
-- @function [parent=#Input] GetScancodeFromName
-- @param self Self reference
-- @param #string name name
-- @return #number

---
-- Function GetScancodeName()
-- Return name of key from scancode.
--
-- @function [parent=#Input] GetScancodeName
-- @param self Self reference
-- @param #number scancode scancode
-- @return #string

---
-- Function GetKeyDown()
-- Check if a key is held down.
--
-- @function [parent=#Input] GetKeyDown
-- @param self Self reference
-- @param #number key key
-- @return #boolean

---
-- Function GetKeyPress()
-- Check if a key has been pressed on this frame.
--
-- @function [parent=#Input] GetKeyPress
-- @param self Self reference
-- @param #number key key
-- @return #boolean

---
-- Function GetScancodeDown()
-- Check if a key is held down by scancode.
--
-- @function [parent=#Input] GetScancodeDown
-- @param self Self reference
-- @param #number scancode scancode
-- @return #boolean

---
-- Function GetScancodePress()
-- Check if a key has been pressed on this frame by scancode.
--
-- @function [parent=#Input] GetScancodePress
-- @param self Self reference
-- @param #number scancode scancode
-- @return #boolean

---
-- Function GetMouseButtonDown()
-- Check if a mouse button is held down.
--
-- @function [parent=#Input] GetMouseButtonDown
-- @param self Self reference
-- @param #number button button
-- @return #boolean

---
-- Function GetMouseButtonPress()
-- Check if a mouse button has been pressed on this frame.
--
-- @function [parent=#Input] GetMouseButtonPress
-- @param self Self reference
-- @param #number button button
-- @return #boolean

---
-- Function GetQualifierDown()
-- Check if a qualifier key is held down.
--
-- @function [parent=#Input] GetQualifierDown
-- @param self Self reference
-- @param #number qualifier qualifier
-- @return #boolean

---
-- Function GetQualifierPress()
-- Check if a qualifier key has been pressed on this frame.
--
-- @function [parent=#Input] GetQualifierPress
-- @param self Self reference
-- @param #number qualifier qualifier
-- @return #boolean

---
-- Function GetQualifiers()
-- Return the currently held down qualifiers.
--
-- @function [parent=#Input] GetQualifiers
-- @param self Self reference
-- @return #number

---
-- Function GetMousePosition()
-- Return mouse position within window. Should only be used with a visible mouse cursor.
--
-- @function [parent=#Input] GetMousePosition
-- @param self Self reference
-- @return IntVector2#IntVector2

---
-- Function GetMouseMove()
-- Return mouse movement since last frame.
--
-- @function [parent=#Input] GetMouseMove
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetMouseMoveX()
-- Return horizontal mouse movement since last frame.
--
-- @function [parent=#Input] GetMouseMoveX
-- @param self Self reference
-- @return #number

---
-- Function GetMouseMoveY()
-- Return vertical mouse movement since last frame.
--
-- @function [parent=#Input] GetMouseMoveY
-- @param self Self reference
-- @return #number

---
-- Function GetMouseMoveWheel()
-- Return mouse wheel movement since last frame.
--
-- @function [parent=#Input] GetMouseMoveWheel
-- @param self Self reference
-- @return #number

---
-- Function GetNumTouches()
-- Return number of active finger touches.
--
-- @function [parent=#Input] GetNumTouches
-- @param self Self reference
-- @return #number

---
-- Function GetTouch()
-- Return active finger touch by index.
--
-- @function [parent=#Input] GetTouch
-- @param self Self reference
-- @param #number index index
-- @return TouchState#TouchState

---
-- Function GetNumJoysticks()
-- Return number of connected joysticks.
--
-- @function [parent=#Input] GetNumJoysticks
-- @param self Self reference
-- @return #number

---
-- Function GetJoystick()
--
-- @function [parent=#Input] GetJoystick
-- @param self Self reference
-- @param #number id id
-- @return JoystickState#JoystickState

---
-- Function GetJoystickByIndex()
-- Return joystick state by index, or null if does not exist. 0 = first connected joystick.
--
-- @function [parent=#Input] GetJoystickByIndex
-- @param self Self reference
-- @param #number index index
-- @return JoystickState#JoystickState

---
-- Function GetToggleFullscreen()
-- Return whether fullscreen toggle is enabled.
--
-- @function [parent=#Input] GetToggleFullscreen
-- @param self Self reference
-- @return #boolean

---
-- Function GetScreenKeyboardSupport()
-- Return whether on-screen keyboard is supported.
--
-- @function [parent=#Input] GetScreenKeyboardSupport
-- @param self Self reference
-- @return #boolean

---
-- Function IsScreenJoystickVisible()
--
-- @function [parent=#Input] IsScreenJoystickVisible
-- @param self Self reference
-- @param #number id id
-- @return #boolean

---
-- Function IsScreenKeyboardVisible()
-- Return whether on-screen keyboard is being shown.
--
-- @function [parent=#Input] IsScreenKeyboardVisible
-- @param self Self reference
-- @return #boolean

---
-- Function GetTouchEmulation()
-- Return whether touch emulation is enabled.
--
-- @function [parent=#Input] GetTouchEmulation
-- @param self Self reference
-- @return #boolean

---
-- Function IsMouseVisible()
-- Return whether the operating system mouse cursor is visible.
--
-- @function [parent=#Input] IsMouseVisible
-- @param self Self reference
-- @return #boolean

---
-- Function IsMouseGrabbed()
-- Return whether the mouse is currently being grabbed by an operation.
--
-- @function [parent=#Input] IsMouseGrabbed
-- @param self Self reference
-- @return #boolean

---
-- Function HasFocus()
-- Return whether application window has input focus.
--
-- @function [parent=#Input] HasFocus
-- @param self Self reference
-- @return #boolean

---
-- Function IsMinimized()
-- Return whether application window is minimized.
--
-- @function [parent=#Input] IsMinimized
-- @param self Self reference
-- @return #boolean

---
-- Field qualifiers (Read only)
--
-- @field [parent=#Input] #number qualifiers

---
-- Field mousePosition (Read only)
--
-- @field [parent=#Input] IntVector2#IntVector2 mousePosition

---
-- Field mouseMove (Read only)
--
-- @field [parent=#Input] IntVector2#IntVector2 mouseMove

---
-- Field mouseMoveX (Read only)
--
-- @field [parent=#Input] #number mouseMoveX

---
-- Field mouseMoveY (Read only)
--
-- @field [parent=#Input] #number mouseMoveY

---
-- Field mouseMoveWheel (Read only)
--
-- @field [parent=#Input] #number mouseMoveWheel

---
-- Field numTouches (Read only)
--
-- @field [parent=#Input] #number numTouches

---
-- Field numJoysticks (Read only)
--
-- @field [parent=#Input] #number numJoysticks

---
-- Field toggleFullscreen (Read only)
--
-- @field [parent=#Input] #boolean toggleFullscreen

---
-- Field screenKeyboardSupport (Read only)
--
-- @field [parent=#Input] #boolean screenKeyboardSupport

---
-- Field screenKeyboardVisible
--
-- @field [parent=#Input] #boolean screenKeyboardVisible

---
-- Field touchEmulation
--
-- @field [parent=#Input] #boolean touchEmulation

---
-- Field mouseVisible
--
-- @field [parent=#Input] #boolean mouseVisible

---
-- Field mouseGrabbed
--
-- @field [parent=#Input] #boolean mouseGrabbed

---
-- Field focus (Read only)
--
-- @field [parent=#Input] #boolean focus

---
-- Field minimized (Read only)
--
-- @field [parent=#Input] #boolean minimized


return nil
