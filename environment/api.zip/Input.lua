---
-- Module Input
-- Module Input extends Object
-- Generated on 2014-03-13
--
-- @module Input

---
-- Function SetToggleFullscreen
--
-- @function [parent=#Input] SetToggleFullscreen
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetMouseVisible
--
-- @function [parent=#Input] SetMouseVisible
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function OpenJoystick
--
-- @function [parent=#Input] OpenJoystick
-- @param self Self reference
-- @param #number index index
-- @return #boolean

---
-- Function CloseJoystick
--
-- @function [parent=#Input] CloseJoystick
-- @param self Self reference
-- @param #number index index

---
-- Function DetectJoysticks
--
-- @function [parent=#Input] DetectJoysticks
-- @param self Self reference
-- @return #boolean

---
-- Function SetScreenKeyboardVisible
--
-- @function [parent=#Input] SetScreenKeyboardVisible
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function GetKeyDown
--
-- @function [parent=#Input] GetKeyDown
-- @param self Self reference
-- @param #number key key
-- @return #boolean

---
-- Function GetKeyPress
--
-- @function [parent=#Input] GetKeyPress
-- @param self Self reference
-- @param #number key key
-- @return #boolean

---
-- Function GetMouseButtonDown
--
-- @function [parent=#Input] GetMouseButtonDown
-- @param self Self reference
-- @param #number button button
-- @return #boolean

---
-- Function GetMouseButtonPress
--
-- @function [parent=#Input] GetMouseButtonPress
-- @param self Self reference
-- @param #number button button
-- @return #boolean

---
-- Function GetQualifierDown
--
-- @function [parent=#Input] GetQualifierDown
-- @param self Self reference
-- @param #number qualifier qualifier
-- @return #boolean

---
-- Function GetQualifierPress
--
-- @function [parent=#Input] GetQualifierPress
-- @param self Self reference
-- @param #number qualifier qualifier
-- @return #boolean

---
-- Function GetQualifiers
--
-- @function [parent=#Input] GetQualifiers
-- @param self Self reference
-- @return #number

---
-- Function GetMousePosition
--
-- @function [parent=#Input] GetMousePosition
-- @param self Self reference
-- @return IntVector2#IntVector2

---
-- Function GetMouseMove
--
-- @function [parent=#Input] GetMouseMove
-- @param self Self reference
-- @return const IntVector2#const IntVector2

---
-- Function GetMouseMoveX
--
-- @function [parent=#Input] GetMouseMoveX
-- @param self Self reference
-- @return #number

---
-- Function GetMouseMoveY
--
-- @function [parent=#Input] GetMouseMoveY
-- @param self Self reference
-- @return #number

---
-- Function GetMouseMoveWheel
--
-- @function [parent=#Input] GetMouseMoveWheel
-- @param self Self reference
-- @return #number

---
-- Function GetNumTouches
--
-- @function [parent=#Input] GetNumTouches
-- @param self Self reference
-- @return #number

---
-- Function GetTouch
--
-- @function [parent=#Input] GetTouch
-- @param self Self reference
-- @param #number index index
-- @return TouchState#TouchState

---
-- Function GetNumJoysticks
--
-- @function [parent=#Input] GetNumJoysticks
-- @param self Self reference
-- @return #number

---
-- Function GetJoystickName
--
-- @function [parent=#Input] GetJoystickName
-- @param self Self reference
-- @param #number index index
-- @return const String#const String

---
-- Function GetJoystick
--
-- @function [parent=#Input] GetJoystick
-- @param self Self reference
-- @param #number index index
-- @return JoystickState#JoystickState

---
-- Function GetToggleFullscreen
--
-- @function [parent=#Input] GetToggleFullscreen
-- @param self Self reference
-- @return #boolean

---
-- Function GetScreenKeyboardSupport
--
-- @function [parent=#Input] GetScreenKeyboardSupport
-- @param self Self reference
-- @return #boolean

---
-- Function IsScreenKeyboardVisible
--
-- @function [parent=#Input] IsScreenKeyboardVisible
-- @param self Self reference
-- @return #boolean

---
-- Function IsMouseVisible
--
-- @function [parent=#Input] IsMouseVisible
-- @param self Self reference
-- @return #boolean

---
-- Function HasFocus
--
-- @function [parent=#Input] HasFocus
-- @param self Self reference
-- @return #boolean

---
-- Function IsMinimized
--
-- @function [parent=#Input] IsMinimized
-- @param self Self reference
-- @return #boolean

---
-- Field qualifiers (Read only)
--
-- @field [parent=#Input] #number qualifiers

---
-- Field mousePosition (Read only)
--
-- @field [parent=#Input] IntVector2#IntVector2 mousePosition

---
-- Field mouseMove (Read only)
--
-- @field [parent=#Input] IntVector2#IntVector2 mouseMove

---
-- Field mouseMoveX (Read only)
--
-- @field [parent=#Input] #number mouseMoveX

---
-- Field mouseMoveY (Read only)
--
-- @field [parent=#Input] #number mouseMoveY

---
-- Field mouseMoveWheel (Read only)
--
-- @field [parent=#Input] #number mouseMoveWheel

---
-- Field numTouches (Read only)
--
-- @field [parent=#Input] #number numTouches

---
-- Field numJoysticks (Read only)
--
-- @field [parent=#Input] #number numJoysticks

---
-- Field toggleFullscreen (Read only)
--
-- @field [parent=#Input] #boolean toggleFullscreen

---
-- Field screenKeyboardSupport (Read only)
--
-- @field [parent=#Input] #boolean screenKeyboardSupport

---
-- Field screenKeyboardVisible
--
-- @field [parent=#Input] #boolean screenKeyboardVisible

---
-- Field mouseVisible
--
-- @field [parent=#Input] #boolean mouseVisible

---
-- Field focus (Read only)
--
-- @field [parent=#Input] #boolean focus

---
-- Field minimized (Read only)
--
-- @field [parent=#Input] #boolean minimized

---
-- Function GetType
--
-- @function [parent=#Input] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#Input] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#Input] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#Input] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#Input] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#Input] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#Input] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#Input] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#Input] #string category


return nil
