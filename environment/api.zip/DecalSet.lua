---
-- Module DecalSet
-- Module DecalSet extends Drawable
-- Generated on 2014-05-31
--
-- @module DecalSet

---
-- Function SetMaterial()
-- Set material. The material should use a small negative depth bias to avoid Z-fighting.
--
-- @function [parent=#DecalSet] SetMaterial
-- @param self Self reference
-- @param Material#Material material material

---
-- Function SetMaxVertices()
-- Set maximum number of decal vertices.
--
-- @function [parent=#DecalSet] SetMaxVertices
-- @param self Self reference
-- @param #number num num

---
-- Function SetMaxIndices()
-- Set maximum number of decal vertex indices.
--
-- @function [parent=#DecalSet] SetMaxIndices
-- @param self Self reference
-- @param #number num num

---
-- Function AddDecal()
-- Add a decal at world coordinates, using a target drawable's geometry for reference. If the decal needs to move with the target, the decal component should be created to the target's node. Return true if successful.
--
-- @function [parent=#DecalSet] AddDecal
-- @param self Self reference
-- @param Drawable#Drawable target target
-- @param Vector3#Vector3 worldPosition worldPosition
-- @param Quaternion#Quaternion worldRotation worldRotation
-- @param #number size size
-- @param #number aspectRatio aspectRatio
-- @param #number depth depth
-- @param Vector2#Vector2 topLeftUV topLeftUV
-- @param Vector2#Vector2 bottomRightUV bottomRightUV
-- @param #number timeToLive timeToLive
-- @param #number normalCutoff normalCutoff
-- @param #number subGeometry subGeometry
-- @return #boolean

---
-- Function RemoveDecals()
-- Remove n oldest decals.
--
-- @function [parent=#DecalSet] RemoveDecals
-- @param self Self reference
-- @param #number num num

---
-- Function RemoveAllDecals()
-- Remove all decals.
--
-- @function [parent=#DecalSet] RemoveAllDecals
-- @param self Self reference

---
-- Function GetMaterial()
-- Return material.
--
-- @function [parent=#DecalSet] GetMaterial
-- @param self Self reference
-- @return Material#Material

---
-- Function GetNumDecals()
-- Return number of decals.
--
-- @function [parent=#DecalSet] GetNumDecals
-- @param self Self reference
-- @return #number

---
-- Function GetNumVertices()
-- Retur number of vertices in the decals.
--
-- @function [parent=#DecalSet] GetNumVertices
-- @param self Self reference
-- @return #number

---
-- Function GetNumIndices()
-- Retur number of vertex indices in the decals.
--
-- @function [parent=#DecalSet] GetNumIndices
-- @param self Self reference
-- @return #number

---
-- Function GetMaxVertices()
-- Return maximum number of decal vertices.
--
-- @function [parent=#DecalSet] GetMaxVertices
-- @param self Self reference
-- @return #number

---
-- Function GetMaxIndices()
-- Return maximum number of decal vertex indices.
--
-- @function [parent=#DecalSet] GetMaxIndices
-- @param self Self reference
-- @return #number

---
-- Field material
--
-- @field [parent=#DecalSet] Material#Material material

---
-- Field numDecals (Read only)
--
-- @field [parent=#DecalSet] #number numDecals

---
-- Field numVertices (Read only)
--
-- @field [parent=#DecalSet] #number numVertices

---
-- Field numIndices (Read only)
--
-- @field [parent=#DecalSet] #number numIndices

---
-- Field maxVertices
--
-- @field [parent=#DecalSet] #number maxVertices

---
-- Field maxIndices
--
-- @field [parent=#DecalSet] #number maxIndices


return nil
