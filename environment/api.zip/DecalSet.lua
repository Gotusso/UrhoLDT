---
-- Module DecalSet
-- Extends Drawable
--
-- @module DecalSet

---
-- Function SetMaterial
--
-- @function [parent=#DecalSet] SetMaterial
-- @param Material#Material materialmaterial

---
-- Function SetMaxVertices
--
-- @function [parent=#DecalSet] SetMaxVertices
-- @param #number numnum

---
-- Function SetMaxIndices
--
-- @function [parent=#DecalSet] SetMaxIndices
-- @param #number numnum

---
-- Function AddDecal
--
-- @function [parent=#DecalSet] AddDecal
-- @param Drawable#Drawable targettarget
-- @param Vector3#Vector3 worldPositionworldPosition
-- @param Quaternion#Quaternion worldRotationworldRotation
-- @param #number sizesize
-- @param #number aspectRatioaspectRatio
-- @param #number depthdepth
-- @param Vector2#Vector2 topLeftUVtopLeftUV
-- @param Vector2#Vector2 bottomRightUVbottomRightUV
-- @param #number timeToLivetimeToLive
-- @param #number normalCutoffnormalCutoff
-- @param #number subGeometrysubGeometry
-- @return #boolean

---
-- Function RemoveDecals
--
-- @function [parent=#DecalSet] RemoveDecals
-- @param #number numnum

---
-- Function RemoveAllDecals
--
-- @function [parent=#DecalSet] RemoveAllDecals

---
-- Function GetMaterial
--
-- @function [parent=#DecalSet] GetMaterial
-- @return Material#Material

---
-- Function GetNumDecals
--
-- @function [parent=#DecalSet] GetNumDecals
-- @return #number

---
-- Function GetNumVertices
--
-- @function [parent=#DecalSet] GetNumVertices
-- @return #number

---
-- Function GetNumIndices
--
-- @function [parent=#DecalSet] GetNumIndices
-- @return #number

---
-- Function GetMaxVertices
--
-- @function [parent=#DecalSet] GetMaxVertices
-- @return #number

---
-- Function GetMaxIndices
--
-- @function [parent=#DecalSet] GetMaxIndices
-- @return #number

---
-- Field material
--
-- @field [parent=#DecalSet] Material#Material material

---
-- Field numDecals (Read only)
--
-- @field [parent=#DecalSet] #number numDecals

---
-- Field numVertices (Read only)
--
-- @field [parent=#DecalSet] #number numVertices

---
-- Field numIndices (Read only)
--
-- @field [parent=#DecalSet] #number numIndices

---
-- Field maxVertices
--
-- @field [parent=#DecalSet] #number maxVertices

---
-- Field maxIndices
--
-- @field [parent=#DecalSet] #number maxIndices


return nil
