---
-- Module DecalSet
-- extends Drawable
--
-- @module DecalSet

---
-- Function SetMaterial
--
-- @function [parent=#DecalSet] SetMaterial
-- @param Material#Material materialmaterial

---
-- Function SetMaxVertices
--
-- @function [parent=#DecalSet] SetMaxVertices
-- @param #number numnum

---
-- Function SetMaxIndices
--
-- @function [parent=#DecalSet] SetMaxIndices
-- @param #number numnum

---
-- Function AddDecal
--
-- @function [parent=#DecalSet] AddDecal
-- @param Drawable#Drawable targettarget
-- @param Vector3#Vector3 worldPositionworldPosition
-- @param Quaternion#Quaternion worldRotationworldRotation
-- @param #number sizesize
-- @param #number aspectRatioaspectRatio
-- @param #number depthdepth
-- @param Vector2#Vector2 topLeftUVtopLeftUV
-- @param Vector2#Vector2 bottomRightUVbottomRightUV
-- @param #number timeToLivetimeToLive
-- @param #number normalCutoffnormalCutoff
-- @param #number subGeometrysubGeometry
-- @return #boolean

---
-- Function RemoveDecals
--
-- @function [parent=#DecalSet] RemoveDecals
-- @param #number numnum

---
-- Function RemoveAllDecals
--
-- @function [parent=#DecalSet] RemoveAllDecals

---
-- Function GetMaterial
--
-- @function [parent=#DecalSet] GetMaterial
-- @return Material#Material

---
-- Function GetNumDecals
--
-- @function [parent=#DecalSet] GetNumDecals
-- @return #number

---
-- Function GetNumVertices
--
-- @function [parent=#DecalSet] GetNumVertices
-- @return #number

---
-- Function GetNumIndices
--
-- @function [parent=#DecalSet] GetNumIndices
-- @return #number

---
-- Function GetMaxVertices
--
-- @function [parent=#DecalSet] GetMaxVertices
-- @return #number

---
-- Function GetMaxIndices
--
-- @function [parent=#DecalSet] GetMaxIndices
-- @return #number

---
-- Field material
--
-- @field [parent=#DecalSet] Material#Material material

---
-- Field numDecals (Read only)
--
-- @field [parent=#DecalSet] #number numDecals

---
-- Field numVertices (Read only)
--
-- @field [parent=#DecalSet] #number numVertices

---
-- Field numIndices (Read only)
--
-- @field [parent=#DecalSet] #number numIndices

---
-- Field maxVertices
--
-- @field [parent=#DecalSet] #number maxVertices

---
-- Field maxIndices
--
-- @field [parent=#DecalSet] #number maxIndices

---
-- Function SetDrawDistance
--
-- @function [parent=#DecalSet] SetDrawDistance
-- @param #number distancedistance

---
-- Function SetShadowDistance
--
-- @function [parent=#DecalSet] SetShadowDistance
-- @param #number distancedistance

---
-- Function SetLodBias
--
-- @function [parent=#DecalSet] SetLodBias
-- @param #number biasbias

---
-- Function SetViewMask
--
-- @function [parent=#DecalSet] SetViewMask
-- @param #number maskmask

---
-- Function SetLightMask
--
-- @function [parent=#DecalSet] SetLightMask
-- @param #number maskmask

---
-- Function SetShadowMask
--
-- @function [parent=#DecalSet] SetShadowMask
-- @param #number maskmask

---
-- Function SetZoneMask
--
-- @function [parent=#DecalSet] SetZoneMask
-- @param #number maskmask

---
-- Function SetMaxLights
--
-- @function [parent=#DecalSet] SetMaxLights
-- @param #number numnum

---
-- Function SetCastShadows
--
-- @function [parent=#DecalSet] SetCastShadows
-- @param #boolean enableenable

---
-- Function SetOccluder
--
-- @function [parent=#DecalSet] SetOccluder
-- @param #boolean enableenable

---
-- Function SetOccludee
--
-- @function [parent=#DecalSet] SetOccludee
-- @param #boolean enableenable

---
-- Function MarkForUpdate
--
-- @function [parent=#DecalSet] MarkForUpdate

---
-- Function GetBoundingBox
--
-- @function [parent=#DecalSet] GetBoundingBox
-- @return const BoundingBox#const BoundingBox

---
-- Function GetWorldBoundingBox
--
-- @function [parent=#DecalSet] GetWorldBoundingBox
-- @return const BoundingBox#const BoundingBox

---
-- Function GetDrawableFlags
--
-- @function [parent=#DecalSet] GetDrawableFlags
-- @return #string

---
-- Function GetDrawDistance
--
-- @function [parent=#DecalSet] GetDrawDistance
-- @return #number

---
-- Function GetShadowDistance
--
-- @function [parent=#DecalSet] GetShadowDistance
-- @return #number

---
-- Function GetLodBias
--
-- @function [parent=#DecalSet] GetLodBias
-- @return #number

---
-- Function GetViewMask
--
-- @function [parent=#DecalSet] GetViewMask
-- @return #number

---
-- Function GetLightMask
--
-- @function [parent=#DecalSet] GetLightMask
-- @return #number

---
-- Function GetShadowMask
--
-- @function [parent=#DecalSet] GetShadowMask
-- @return #number

---
-- Function GetZoneMask
--
-- @function [parent=#DecalSet] GetZoneMask
-- @return #number

---
-- Function GetMaxLights
--
-- @function [parent=#DecalSet] GetMaxLights
-- @return #number

---
-- Function GetCastShadows
--
-- @function [parent=#DecalSet] GetCastShadows
-- @return #boolean

---
-- Function IsOccluder
--
-- @function [parent=#DecalSet] IsOccluder
-- @return #boolean

---
-- Function IsOccludee
--
-- @function [parent=#DecalSet] IsOccludee
-- @return #boolean

---
-- Function SetZone
--
-- @function [parent=#DecalSet] SetZone
-- @param Zone#Zone zonezone
-- @param #boolean temporarytemporary

---
-- Function SetSortValue
--
-- @function [parent=#DecalSet] SetSortValue
-- @param #number valuevalue

---
-- Function SetMinMaxZ
--
-- @function [parent=#DecalSet] SetMinMaxZ
-- @param #number minZminZ
-- @param #number maxZmaxZ

---
-- Function MarkInView
--
-- @function [parent=#DecalSet] MarkInView
-- @param FrameInfo#FrameInfo frameframe
-- @param #boolean mainViewmainView

---
-- Function ClearLights
--
-- @function [parent=#DecalSet] ClearLights

---
-- Function AddLight
--
-- @function [parent=#DecalSet] AddLight
-- @param Light#Light lightlight

---
-- Function AddVertexLight
--
-- @function [parent=#DecalSet] AddVertexLight
-- @param Light#Light lightlight

---
-- Function LimitLights
--
-- @function [parent=#DecalSet] LimitLights

---
-- Function LimitVertexLights
--
-- @function [parent=#DecalSet] LimitVertexLights

---
-- Function SetBasePass
--
-- @function [parent=#DecalSet] SetBasePass
-- @param #number batchIndexbatchIndex

---
-- Function GetOctant
--
-- @function [parent=#DecalSet] GetOctant
-- @return Octant#Octant

---
-- Function GetZone
--
-- @function [parent=#DecalSet] GetZone
-- @return Zone#Zone

---
-- Function GetLastZone
--
-- @function [parent=#DecalSet] GetLastZone
-- @return Zone#Zone

---
-- Function IsZoneDirty
--
-- @function [parent=#DecalSet] IsZoneDirty
-- @return #boolean

---
-- Function GetDistance
--
-- @function [parent=#DecalSet] GetDistance
-- @return #number

---
-- Function GetLodDistance
--
-- @function [parent=#DecalSet] GetLodDistance
-- @return #number

---
-- Function GetSortValue
--
-- @function [parent=#DecalSet] GetSortValue
-- @return #number

---
-- Function IsInView
--
-- @function [parent=#DecalSet] IsInView
-- @param #number frameNumberframeNumber
-- @return #boolean

---
-- Function IsInView
--
-- @function [parent=#DecalSet] IsInView
-- @param FrameInfo#FrameInfo frameframe
-- @param #boolean mainViewmainView
-- @return #boolean

---
-- Function HasBasePass
--
-- @function [parent=#DecalSet] HasBasePass
-- @param #number batchIndexbatchIndex
-- @return #boolean

---
-- Function GetFirstLight
--
-- @function [parent=#DecalSet] GetFirstLight
-- @return Light#Light

---
-- Function GetMinZ
--
-- @function [parent=#DecalSet] GetMinZ
-- @return #number

---
-- Function GetMaxZ
--
-- @function [parent=#DecalSet] GetMaxZ
-- @return #number

---
-- Field worldBoundingBox (Read only)
--
-- @field [parent=#DecalSet] BoundingBox#BoundingBox worldBoundingBox

---
-- Field drawableFlags (Read only)
--
-- @field [parent=#DecalSet] #string drawableFlags

---
-- Field drawDistance
--
-- @field [parent=#DecalSet] #number drawDistance

---
-- Field shadowDistance
--
-- @field [parent=#DecalSet] #number shadowDistance

---
-- Field lodBias
--
-- @field [parent=#DecalSet] #number lodBias

---
-- Field viewMask
--
-- @field [parent=#DecalSet] #number viewMask

---
-- Field lightMask
--
-- @field [parent=#DecalSet] #number lightMask

---
-- Field shadowMask
--
-- @field [parent=#DecalSet] #number shadowMask

---
-- Field zoneMask
--
-- @field [parent=#DecalSet] #number zoneMask

---
-- Field maxLights
--
-- @field [parent=#DecalSet] #number maxLights

---
-- Field castShadows
--
-- @field [parent=#DecalSet] #boolean castShadows

---
-- Field occluder
--
-- @field [parent=#DecalSet] #boolean occluder

---
-- Field occludee
--
-- @field [parent=#DecalSet] #boolean occludee

---
-- Field octant (Read only)
--
-- @field [parent=#DecalSet] Octant#Octant octant

---
-- Field zone
--
-- @field [parent=#DecalSet] Zone#Zone zone

---
-- Field lastZone (Read only)
--
-- @field [parent=#DecalSet] Zone#Zone lastZone

---
-- Field zoneDirty (Read only)
--
-- @field [parent=#DecalSet] #boolean zoneDirty

---
-- Field distance (Read only)
--
-- @field [parent=#DecalSet] #number distance

---
-- Field lodDistance (Read only)
--
-- @field [parent=#DecalSet] #number lodDistance

---
-- Field sortValue
--
-- @field [parent=#DecalSet] #number sortValue

---
-- Field firstLight (Read only)
--
-- @field [parent=#DecalSet] Light#Light firstLight

---
-- Field minZ (Read only)
--
-- @field [parent=#DecalSet] #number minZ

---
-- Field maxZ (Read only)
--
-- @field [parent=#DecalSet] #number maxZ

---
-- Function SetEnabled
--
-- @function [parent=#DecalSet] SetEnabled
-- @param #boolean enableenable

---
-- Function Remove
--
-- @function [parent=#DecalSet] Remove

---
-- Function GetID
--
-- @function [parent=#DecalSet] GetID
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#DecalSet] GetNode
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#DecalSet] GetScene
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#DecalSet] IsEnabled
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#DecalSet] IsEnabledEffective
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#DecalSet] GetComponent
-- @param ShortStringHash#ShortStringHash typetype
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#DecalSet] GetComponent
-- @param #string typetype
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#DecalSet] SetTemporary
-- @param #boolean enableenable

---
-- Function IsTemporary
--
-- @function [parent=#DecalSet] IsTemporary
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#DecalSet] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#DecalSet] GetType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#DecalSet] GetBaseType
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#DecalSet] GetTypeName
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#DecalSet] GetCategory
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#DecalSet] SendEvent
-- @param #string eventNameeventName
-- @param VariantMap#VariantMap eventDataeventData

---
-- Field type (Read only)
--
-- @field [parent=#DecalSet] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#DecalSet] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#DecalSet] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#DecalSet] #string category


return nil
