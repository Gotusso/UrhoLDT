---
-- Module DecalSet
-- Module DecalSet extends Drawable
-- Generated on 2014-03-13
--
-- @module DecalSet

---
-- Function SetMaterial
--
-- @function [parent=#DecalSet] SetMaterial
-- @param self Self reference
-- @param Material#Material material material

---
-- Function SetMaxVertices
--
-- @function [parent=#DecalSet] SetMaxVertices
-- @param self Self reference
-- @param #number num num

---
-- Function SetMaxIndices
--
-- @function [parent=#DecalSet] SetMaxIndices
-- @param self Self reference
-- @param #number num num

---
-- Function AddDecal
--
-- @function [parent=#DecalSet] AddDecal
-- @param self Self reference
-- @param Drawable#Drawable target target
-- @param Vector3#Vector3 worldPosition worldPosition
-- @param Quaternion#Quaternion worldRotation worldRotation
-- @param #number size size
-- @param #number aspectRatio aspectRatio
-- @param #number depth depth
-- @param Vector2#Vector2 topLeftUV topLeftUV
-- @param Vector2#Vector2 bottomRightUV bottomRightUV
-- @param #number timeToLive timeToLive
-- @param #number normalCutoff normalCutoff
-- @param #number subGeometry subGeometry
-- @return #boolean

---
-- Function RemoveDecals
--
-- @function [parent=#DecalSet] RemoveDecals
-- @param self Self reference
-- @param #number num num

---
-- Function RemoveAllDecals
--
-- @function [parent=#DecalSet] RemoveAllDecals
-- @param self Self reference

---
-- Function GetMaterial
--
-- @function [parent=#DecalSet] GetMaterial
-- @param self Self reference
-- @return Material#Material

---
-- Function GetNumDecals
--
-- @function [parent=#DecalSet] GetNumDecals
-- @param self Self reference
-- @return #number

---
-- Function GetNumVertices
--
-- @function [parent=#DecalSet] GetNumVertices
-- @param self Self reference
-- @return #number

---
-- Function GetNumIndices
--
-- @function [parent=#DecalSet] GetNumIndices
-- @param self Self reference
-- @return #number

---
-- Function GetMaxVertices
--
-- @function [parent=#DecalSet] GetMaxVertices
-- @param self Self reference
-- @return #number

---
-- Function GetMaxIndices
--
-- @function [parent=#DecalSet] GetMaxIndices
-- @param self Self reference
-- @return #number

---
-- Field material
--
-- @field [parent=#DecalSet] Material#Material material

---
-- Field numDecals (Read only)
--
-- @field [parent=#DecalSet] #number numDecals

---
-- Field numVertices (Read only)
--
-- @field [parent=#DecalSet] #number numVertices

---
-- Field numIndices (Read only)
--
-- @field [parent=#DecalSet] #number numIndices

---
-- Field maxVertices
--
-- @field [parent=#DecalSet] #number maxVertices

---
-- Field maxIndices
--
-- @field [parent=#DecalSet] #number maxIndices

---
-- Function SetDrawDistance
--
-- @function [parent=#DecalSet] SetDrawDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetShadowDistance
--
-- @function [parent=#DecalSet] SetShadowDistance
-- @param self Self reference
-- @param #number distance distance

---
-- Function SetLodBias
--
-- @function [parent=#DecalSet] SetLodBias
-- @param self Self reference
-- @param #number bias bias

---
-- Function SetViewMask
--
-- @function [parent=#DecalSet] SetViewMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetLightMask
--
-- @function [parent=#DecalSet] SetLightMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetShadowMask
--
-- @function [parent=#DecalSet] SetShadowMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetZoneMask
--
-- @function [parent=#DecalSet] SetZoneMask
-- @param self Self reference
-- @param #number mask mask

---
-- Function SetMaxLights
--
-- @function [parent=#DecalSet] SetMaxLights
-- @param self Self reference
-- @param #number num num

---
-- Function SetCastShadows
--
-- @function [parent=#DecalSet] SetCastShadows
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetOccluder
--
-- @function [parent=#DecalSet] SetOccluder
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function SetOccludee
--
-- @function [parent=#DecalSet] SetOccludee
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function MarkForUpdate
--
-- @function [parent=#DecalSet] MarkForUpdate
-- @param self Self reference

---
-- Function GetBoundingBox
--
-- @function [parent=#DecalSet] GetBoundingBox
-- @param self Self reference
-- @return const BoundingBox#const BoundingBox

---
-- Function GetWorldBoundingBox
--
-- @function [parent=#DecalSet] GetWorldBoundingBox
-- @param self Self reference
-- @return const BoundingBox#const BoundingBox

---
-- Function GetDrawableFlags
--
-- @function [parent=#DecalSet] GetDrawableFlags
-- @param self Self reference
-- @return #string

---
-- Function GetDrawDistance
--
-- @function [parent=#DecalSet] GetDrawDistance
-- @param self Self reference
-- @return #number

---
-- Function GetShadowDistance
--
-- @function [parent=#DecalSet] GetShadowDistance
-- @param self Self reference
-- @return #number

---
-- Function GetLodBias
--
-- @function [parent=#DecalSet] GetLodBias
-- @param self Self reference
-- @return #number

---
-- Function GetViewMask
--
-- @function [parent=#DecalSet] GetViewMask
-- @param self Self reference
-- @return #number

---
-- Function GetLightMask
--
-- @function [parent=#DecalSet] GetLightMask
-- @param self Self reference
-- @return #number

---
-- Function GetShadowMask
--
-- @function [parent=#DecalSet] GetShadowMask
-- @param self Self reference
-- @return #number

---
-- Function GetZoneMask
--
-- @function [parent=#DecalSet] GetZoneMask
-- @param self Self reference
-- @return #number

---
-- Function GetMaxLights
--
-- @function [parent=#DecalSet] GetMaxLights
-- @param self Self reference
-- @return #number

---
-- Function GetCastShadows
--
-- @function [parent=#DecalSet] GetCastShadows
-- @param self Self reference
-- @return #boolean

---
-- Function IsOccluder
--
-- @function [parent=#DecalSet] IsOccluder
-- @param self Self reference
-- @return #boolean

---
-- Function IsOccludee
--
-- @function [parent=#DecalSet] IsOccludee
-- @param self Self reference
-- @return #boolean

---
-- Function SetZone
--
-- @function [parent=#DecalSet] SetZone
-- @param self Self reference
-- @param Zone#Zone zone zone
-- @param #boolean temporary temporary

---
-- Function SetSortValue
--
-- @function [parent=#DecalSet] SetSortValue
-- @param self Self reference
-- @param #number value value

---
-- Function SetMinMaxZ
--
-- @function [parent=#DecalSet] SetMinMaxZ
-- @param self Self reference
-- @param #number minZ minZ
-- @param #number maxZ maxZ

---
-- Function MarkInView
--
-- @function [parent=#DecalSet] MarkInView
-- @param self Self reference
-- @param FrameInfo#FrameInfo frame frame
-- @param #boolean mainView mainView

---
-- Function ClearLights
--
-- @function [parent=#DecalSet] ClearLights
-- @param self Self reference

---
-- Function AddLight
--
-- @function [parent=#DecalSet] AddLight
-- @param self Self reference
-- @param Light#Light light light

---
-- Function AddVertexLight
--
-- @function [parent=#DecalSet] AddVertexLight
-- @param self Self reference
-- @param Light#Light light light

---
-- Function LimitLights
--
-- @function [parent=#DecalSet] LimitLights
-- @param self Self reference

---
-- Function LimitVertexLights
--
-- @function [parent=#DecalSet] LimitVertexLights
-- @param self Self reference

---
-- Function SetBasePass
--
-- @function [parent=#DecalSet] SetBasePass
-- @param self Self reference
-- @param #number batchIndex batchIndex

---
-- Function GetOctant
--
-- @function [parent=#DecalSet] GetOctant
-- @param self Self reference
-- @return Octant#Octant

---
-- Function GetZone
--
-- @function [parent=#DecalSet] GetZone
-- @param self Self reference
-- @return Zone#Zone

---
-- Function GetLastZone
--
-- @function [parent=#DecalSet] GetLastZone
-- @param self Self reference
-- @return Zone#Zone

---
-- Function IsZoneDirty
--
-- @function [parent=#DecalSet] IsZoneDirty
-- @param self Self reference
-- @return #boolean

---
-- Function GetDistance
--
-- @function [parent=#DecalSet] GetDistance
-- @param self Self reference
-- @return #number

---
-- Function GetLodDistance
--
-- @function [parent=#DecalSet] GetLodDistance
-- @param self Self reference
-- @return #number

---
-- Function GetSortValue
--
-- @function [parent=#DecalSet] GetSortValue
-- @param self Self reference
-- @return #number

---
-- Function IsInView
--
-- @function [parent=#DecalSet] IsInView
-- @param self Self reference
-- @param #number frameNumber frameNumber
-- @return #boolean

---
-- Function IsInView
--
-- @function [parent=#DecalSet] IsInView
-- @param self Self reference
-- @param FrameInfo#FrameInfo frame frame
-- @param #boolean mainView mainView
-- @return #boolean

---
-- Function HasBasePass
--
-- @function [parent=#DecalSet] HasBasePass
-- @param self Self reference
-- @param #number batchIndex batchIndex
-- @return #boolean

---
-- Function GetFirstLight
--
-- @function [parent=#DecalSet] GetFirstLight
-- @param self Self reference
-- @return Light#Light

---
-- Function GetMinZ
--
-- @function [parent=#DecalSet] GetMinZ
-- @param self Self reference
-- @return #number

---
-- Function GetMaxZ
--
-- @function [parent=#DecalSet] GetMaxZ
-- @param self Self reference
-- @return #number

---
-- Field worldBoundingBox (Read only)
--
-- @field [parent=#DecalSet] BoundingBox#BoundingBox worldBoundingBox

---
-- Field drawableFlags (Read only)
--
-- @field [parent=#DecalSet] #string drawableFlags

---
-- Field drawDistance
--
-- @field [parent=#DecalSet] #number drawDistance

---
-- Field shadowDistance
--
-- @field [parent=#DecalSet] #number shadowDistance

---
-- Field lodBias
--
-- @field [parent=#DecalSet] #number lodBias

---
-- Field viewMask
--
-- @field [parent=#DecalSet] #number viewMask

---
-- Field lightMask
--
-- @field [parent=#DecalSet] #number lightMask

---
-- Field shadowMask
--
-- @field [parent=#DecalSet] #number shadowMask

---
-- Field zoneMask
--
-- @field [parent=#DecalSet] #number zoneMask

---
-- Field maxLights
--
-- @field [parent=#DecalSet] #number maxLights

---
-- Field castShadows
--
-- @field [parent=#DecalSet] #boolean castShadows

---
-- Field occluder
--
-- @field [parent=#DecalSet] #boolean occluder

---
-- Field occludee
--
-- @field [parent=#DecalSet] #boolean occludee

---
-- Field octant (Read only)
--
-- @field [parent=#DecalSet] Octant#Octant octant

---
-- Field zone
--
-- @field [parent=#DecalSet] Zone#Zone zone

---
-- Field lastZone (Read only)
--
-- @field [parent=#DecalSet] Zone#Zone lastZone

---
-- Field zoneDirty (Read only)
--
-- @field [parent=#DecalSet] #boolean zoneDirty

---
-- Field distance (Read only)
--
-- @field [parent=#DecalSet] #number distance

---
-- Field lodDistance (Read only)
--
-- @field [parent=#DecalSet] #number lodDistance

---
-- Field sortValue
--
-- @field [parent=#DecalSet] #number sortValue

---
-- Field firstLight (Read only)
--
-- @field [parent=#DecalSet] Light#Light firstLight

---
-- Field minZ (Read only)
--
-- @field [parent=#DecalSet] #number minZ

---
-- Field maxZ (Read only)
--
-- @field [parent=#DecalSet] #number maxZ

---
-- Function SetEnabled
--
-- @function [parent=#DecalSet] SetEnabled
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function Remove
--
-- @function [parent=#DecalSet] Remove
-- @param self Self reference

---
-- Function GetID
--
-- @function [parent=#DecalSet] GetID
-- @param self Self reference
-- @return #number

---
-- Function GetNode
--
-- @function [parent=#DecalSet] GetNode
-- @param self Self reference
-- @return Node#Node

---
-- Function GetScene
--
-- @function [parent=#DecalSet] GetScene
-- @param self Self reference
-- @return Scene#Scene

---
-- Function IsEnabled
--
-- @function [parent=#DecalSet] IsEnabled
-- @param self Self reference
-- @return #boolean

---
-- Function IsEnabledEffective
--
-- @function [parent=#DecalSet] IsEnabledEffective
-- @param self Self reference
-- @return #boolean

---
-- Function GetComponent
--
-- @function [parent=#DecalSet] GetComponent
-- @param self Self reference
-- @param ShortStringHash#ShortStringHash type type
-- @return Component#Component

---
-- Function GetComponent
--
-- @function [parent=#DecalSet] GetComponent
-- @param self Self reference
-- @param #string type type
-- @return Component#Component

---
-- Function SetTemporary
--
-- @function [parent=#DecalSet] SetTemporary
-- @param self Self reference
-- @param #boolean enable enable

---
-- Function IsTemporary
--
-- @function [parent=#DecalSet] IsTemporary
-- @param self Self reference
-- @return #boolean

---
-- Field temporary
--
-- @field [parent=#DecalSet] #boolean temporary

---
-- Function GetType
--
-- @function [parent=#DecalSet] GetType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetBaseType
--
-- @function [parent=#DecalSet] GetBaseType
-- @param self Self reference
-- @return ShortStringHash#ShortStringHash

---
-- Function GetTypeName
--
-- @function [parent=#DecalSet] GetTypeName
-- @param self Self reference
-- @return const String#const String

---
-- Function GetCategory
--
-- @function [parent=#DecalSet] GetCategory
-- @param self Self reference
-- @return const String#const String

---
-- Function SendEvent
--
-- @function [parent=#DecalSet] SendEvent
-- @param self Self reference
-- @param #string eventName eventName
-- @param VariantMap#VariantMap eventData eventData

---
-- Field type (Read only)
--
-- @field [parent=#DecalSet] ShortStringHash#ShortStringHash type

---
-- Field baseType (Read only)
--
-- @field [parent=#DecalSet] ShortStringHash#ShortStringHash baseType

---
-- Field typeName (Read only)
--
-- @field [parent=#DecalSet] #string typeName

---
-- Field category (Read only)
--
-- @field [parent=#DecalSet] #string category


return nil
