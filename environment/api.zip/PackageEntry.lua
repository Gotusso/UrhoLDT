---
-- Module PackageEntry
-- Generated on 2014-03-13
--
-- @module PackageEntry

---
-- Field offset
--
-- @field [parent=#PackageEntry] #number offset

---
-- Field size
--
-- @field [parent=#PackageEntry] #number size

---
-- Field checksum
--
-- @field [parent=#PackageEntry] #number checksum


return nil
